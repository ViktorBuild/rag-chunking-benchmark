---
document_id: iea_modernising-grids-in-the-age-of-electricity
title: "Iea Modernising-Grids-In-The-Age-Of-Electricity"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_modernising-grids-in-the-age-of-electricity.pdf"
tables_detected: 75
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Modernising Grids in the Age of Electricity

Scaling digital technologies and AI for better use of existing networks

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 14 Association countries and beyond.

## IEA M ember countries:

This publication, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. International Energy Agency Website: www.iea.org

IEA Accession countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Chile Colombia Costa Rica Brazil Israel

Romania

## IEA A ssociation countries:

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Abstract

The world has entered the Age of Electricity, with electricity becoming the central energy carrier for modern  economies  and  the primary driver of energy transition s . Grids  are  the  backbone  of  electricity  systems.  With  electricity demand  rising and both demand and supply becoming more  variable, it is essential to expand networks. But new infrastructure is increasingly slow and costly to build, which  means  that  making  better  use  of existing  assets  has  to  be  given  equal priority.

Artificial intelligence (AI) is having a growing impact on the electricity sector. The relationship runs both ways: the data centres behind AI are a fast-growing source of demand that can worsen grid congestion, while AI applied to energy systems holds the promise of huge potential benefits for system reliability and efficiency. Both sides are explored in the IEA's Energy and AI analysis. This report builds on that work by focusing on electricity grids and examines how network operators can leverage digital technologies (including AI) to make better use of existing grids. In this context, AI's value lies in strengthening optimisation, forecasting, situational awareness,  resilience  and  risk  management,  helping  networks  use  existing capacity more safely and efficiently.

The report presents a portfolio of digital tools (the digital grid toolkit) that allow greater value to be derived from the transmission and distribution network and can improve  how  it  is  planned,  built,  maintained  and  operated,  identifying  where improvements  transfer  most  readily  from  one  country  to  another,  and  where regulatory  reform  can  have  the  greatest  impact.  Demand-side  flexibility  and storage are also important routes to higher network utilisation, but are treated as a complementary topic covered in other IEA work. While AI is the driver of the current momentum, the report is not confined to it. The surge in data, investment and  attention  can  lift  a  wider  family  of  proven  but  underdeployed  solutions  to achieve better use of grids, from proven grid-enhancing technologies to emerging AI-enhanced applications.

## Acknowledgements

This study was prepared by the Electricity Systems and Markets (ESM) Division of  the  Directorate  of  Energy  Markets  and  Security  (EMS)  of  the  International Energy Agency (IEA). The study was directed by Jacques Warichet under the guidance of the Head of the ESM Division, Maria Sicilia, former EMS Director, Keisuke Sadamori, and EMS Director Shinichi Kihara. The main authors were Jacques Warichet, Zubin Postwalla and Jeseung Choi. Supporting authors were Esra Bozkir Broekman, Augustin Lorne, Camille Paillard and Floris Van Dedem. Other contributions from across the agency were provided by Eren Cam, Marc Casanovas, Matthew Davis, Michael Drtil, Javier Jorquera Copier, Natalie Kauf, Rebecca  Ruff,  Ors  Sumeghy  and  former  Head  of  Renewable  Integration  and Secure Electricity Pablo Hevia-Koch.

Valuable comments and feedback from across the IEA were provided by Grace Henry, Aidan Kennedy, Brendan Reidenbach, Siddarth Singh, Thomas Spencer, Ottavia Valentini, Peerapat Vithayasrichareon and Brent Wanner. The authors are grateful to colleagues from the Global Energy Relations directorate for their help in reaching out to stakeholders.

The  ESM  Division  would  like  to  thank  the  following  peer  reviewers  for  their valuable  feedback:  Yasmine  Abdennadher  (NewGrid),  Gabriel  Bareux  (RTE), Harmeet Bawa (Hitachi Energy), Liam Bennett (Ofgem), Brian Berry (Heimdall Power),  Rachel  Berryman  (50hertz),  Seong  Choi  (National  Laboratory  of  the Rockies), Alejandro Falkner (ENEL), Emeline Georges (Haulogy), Charles Girard (CTC Global), Adrian Kelly (EPRI), Nabil Khouya (Ampacimon), Naoki Kobayashi (TEPCO),  Rena  Kuwahata  (former  IEA  analyst,  Agora  Energiewende),  Luca Marchisio (Terna), Luciano Martini (RSE), Mathieu Milokovic (Siemens), Vincent Minier  (Schneider  Electric),  Susanne  Nies  (Helmholtz  Centre  Berlin),  Robert Nyíredi (Siemens), Nicolas Omont (Artelys), Alessio Pastore (former IEA analyst, World  Bank),  Luke  Robinson  (AEMO),  Pablo  Ruiz  (NewGrid),  Georg  Rute (GridRaven),  Layla  Sawyer  (CurrENT  Europe),  Anirban  Sinha  (India  Energy Stack), Marina Sommer (Netz Niederösterreich), Stavros Stamatoukos (European Commission, DG  ENER), Paulina Tapia Suvayke (Coordinador Eléctrico Nacional), Arne Svendsen (Siemens), Hadrien Thebault (European Commission, DG ENER), Jonathan Thurlwell (Ofgem), Yishen Wang and Zheng Wang (China Electric Power Research Institute), Arnaud Zinflou (HydroQuébec).

The work could not have been achieved without the support and co-operation of many  government  bodies,  organisations  and  companies  worldwide,  notably: AboitizPower; European Union Agency for the Co-operation of Energy Regulators

(ACER); Asian Development Bank (ADB); Agencija za energijo, Slovenia (agenrs);  Autoridad  Reguladora  de  los  Servicios  Publicos,  Costa  Rica  (ARESEP); ČEPS ČEZ distribuce ; ; Cigré; China Electric Power Research Institute (CEPRI); Coordinador Eléctrico Nacional (CEN); CRF India; CurrENT Europe; European Distribution System  Operators  (E.DSO);  Enel  Grids;  European  Network  of Transmission System  Operators for Electricity (ENTSO-E);  EPRI;  Energy Systems  Integration  Group  (ESIG);  Eurelectric;  European  Commission;  GE Vernova; Global Power System Transformation Consortium (G-PST); Haulogy; HEDNO;  Hitachi  Energy;  Hydro-Québec;  the  International  Smart  Grid  Action Network (ISGAN); Ministry of Economy, Trade and Industry, Japan; National Grid Corporation of the Philippines (NGCP); Netz Niederösterreich (NÖ); PJM; RMI; Réseau de Transport d'Electricité (RTE); Splight; Schneider Electric; T&amp;D Europe; the United Kingdom's AI Champion for Clean Energy.

The  ESM  Division  is  grateful  for  the  grant  provided  by  Sequoia  Climate Foundation, which has made this work possible, and the support and follow-up provided by Daniel Noll, Yinong Sun and Clay Stranger.

Thanks to the IEA Communications and Digital Office for their help in producing the report and website materials, particularly to Jethro Mullen, Maria Ahmad, Lee Bailey,  Curtis  Brainard,  Poeli  Bojorquez,  Gaelle  Bruneau,  Jon  Custer,  Astrid Dumond, Isabelle Nonain-Semelin, Andrea Pronzati, Clara Vallois, Lucile Wall and Wonjik Yang.

The report was edited by Justin French-Brooks and copyedited by Liv Gaunt.

## Table of contents

| Executive summary.................................................................................................................      |   7 |
|-----------------------------------------------------------------------------------------------------------------------------------------|-----|
| Chapter 1. The need for modern grids..................................................................................                  |  11 |
| Grids in the Age of Electricity...................................................................................................      |  11 |
| The limits of traditional grid expansion.....................................................................................           |  13 |
| Making better use of grids to complement grid expansion ......................................................                          |  13 |
| Proven benefits of the digital grid toolkit ..................................................................................          |  19 |
| Chapter 2. State of play ........................................................................................................       |  21 |
| Digitalisation policies................................................................................................................ |  22 |
| Monitoring and control systems ...............................................................................................          |  24 |
| Grid-enhancing technologies ...................................................................................................         |  33 |
| AI-enhanced solutions..............................................................................................................     |  41 |
| AI: An opportunity for emerging market and developing economies to leapfrog.....................                                        |  52 |
| Chapter 3. Estimating and unlocking the potential...............................................................                        |  56 |
| Estimating the potential of the digital grid toolkit......................................................................              |  56 |
| Enabler 1: Regulatory frameworks...........................................................................................             |  61 |
| Enabler 2: Data foundations.....................................................................................................        |  71 |
| Enabler 3: Skills and organisational readiness ........................................................................                 |  75 |
| Enabler 4: Trust, accountability and security ...........................................................................               |  78 |
| Chapter 4. Policy recommendations.....................................................................................                  |  84 |
| Abbreviations and acronyms.................................................................................................             |  91 |

## Executive summary

## Grid expansion and better use of existing infrastructure must go hand in hand

Secure and affordable electricity systems that support economic growth and development depend on grid infrastructure. Electricity  demand has grown at roughly twice the rate of overall energy demand over the past decade, driven by the electrification of end uses, by cooling and industrial expansion, and in some markets by  data  centres.  Meeting  its  expected  growth  by  2035  requires  grid  capacity  to increase by at least 30%, equivalent to adding or replacing 25 million kilometres of lines. Three quarters of the increase to 2035 is expected in emerging market and developing economies, where expanding networks will remain indispensable, while in many advanced economies demand is growing again after years of stagnation, adding pressure to networks that often also require modernisation.

Grid expansion is not keeping pace with rising electricity demand and the broader  transformation  of  energy  systems. The  consequences  are  already visible: at least 1 700 GW of advanced-stage renewable projects and 600 GW of utility-scale  batteries  were  awaiting  connection  in  2025,  while  congestion  cost USD 12 billion in the United States and EUR 4.3 billion in the European Union in 2024.  Permitting  procedures,  supply-chain  bottlenecks,  labour  shortages  and rising equipment costs all constrain delivery.

Expansion  alone  would  not  be  the  most  cost-effective  solution  even  if networks could be built faster. Removing all congestion would mean sizing the grid for peak conditions at all times, and because wind, solar, and many new loads run at full output only part of the time, such a network would be used well below capacity for most of the year. A degree of congestion is therefore efficient, and since  network  costs  make  up  a  substantial  share  of  consumer  bills,  how  well existing capacity is used directly affects affordability.

While grids are expanding, they are also becoming more complex to operate. Distributed resources, bidirectional flows and increasingly variable and concentrated  sources  of  supply  and  demand  are  making  network  conditions change more quickly and less predictably. Operators increasingly need to actively manage voltage and stability alongside power flows and thermal limits, often with incomplete visibility.

Existing networks could be used more efficiently and carry more than they do today, both by changing how risk is managed in operation and by getting more from grid assets. Operators maintain margins below the network's physical

limits to cover risks they cannot fully observe, so improved information can allow those margins to be narrowed safely. Getting greater output from existing assets means  both  carrying  more  power  through  equipment  already  in  service  and keeping  that  equipment  available  more  of  the  time,  by  reducing  outages  and shortening  restoration  and  replacement  times.  This  report  focuses  on  these network-based  solutions,  where  the  underlying  physics  and  many  operating practices are common across countries. Digitalisation, grid-enhancing technologies and AI together provide a toolkit for identifying and using this capacity safely and efficiently.

## More efficient use of existing networks could allow up to 330 GW of new supply, storage and demand to connect, in months rather than years

IEA  analysis  estimates  that  dynamic  ratings,  topology  optimisation  and advanced  power-flow  control  could  allow  up  to  330  GW  of  additional generation, storage and demand to connect to existing networks without reinforcement. This  is  roughly  equivalent  to  the  combined  installed  electricity generation capacity of France and Korea. Connecting this volume through network expansion  instead  would  require  around  USD  100  billion  of  investment.  The estimate  covers  the  three  technologies  most  widely  deployed  in  transmission networks: dynamic ratings, which adjust how much power lines and transformers can safely carry according to actual weather conditions; topology optimisation, which  reconfigures  the  network  to  route  power  around  congested  lines;  and advanced power-flow control, which pushes power onto underused paths. Other digital and grid-enhancing technologies would add further capacity.

These solutions complement grid expansion rather than replacing it. Most can  be  deployed  in  months  rather  than  years,  relieving  constraints  while  new infrastructure is being built. They can also be added to networks already in service, while asset replacement provides the lowest-cost opportunity to embed much of the required digital capability. Where conditions are favourable they can defer or avoid individual reinforcements, but the capacity they release is bounded by the physical network and varies with weather and system conditions, so they cannot deliver the step change in capability that demand growth requires.

Digitalisation and  grid-enhancing  technologies  are already delivering measurable benefits in real networks. Reported results include USD 64 million a year in avoided congestion costs from dynamic ratings in the United States, more than 2 GW of additional transfer capacity from advanced power-flow control in Great Britain, and a 70% reduction in the time needed to analyse reinforcement options using a digital twin, a detailed virtual model of the network.

However, proven technologies do not yet move consistently from individual projects  to standard  practice. Deployment  remains  highly  uneven,  and technologies  proven  at  one  site  frequently  stall  between  pilot  deployment  and standard practice, since each deployment has to be justified afresh in the absence of  established methods for valuing benefits or transferring experience between projects.

AI  adds  new  applications  and  can  make  the  wider  toolkit  easier  to  target, operate  and  scale. Network  operators  have  used  AI-based  methods  for  many years for forecasting, inspection, maintenance and planning, and recent advances allow models to process much larger and more diverse operational, weather and imagery  datasets.  AI  can  help  operators  identify  where  unused  capacity  exists, forecast when it can be used safely and test whether it would remain if equipment failed or other system conditions changed, but adoption varies by function. Planning and asset-related applications are relatively mature, while safety-critical operational control remains constrained by explainability, auditability and accountability.

## Action on five fronts will determine whether these gains are captured

The main obstacles to wider deployment are institutional and organisational,  rather  than  technological  performance. Among  surveyed network operators, 64% identified skills and organisational readiness as a major barrier,  60%  availability  and  quality  of  data,  60%  trust-related  issues  and  56% regulatory  frameworks.  These  four  conditions  apply  across  digitalisation,  gridenhancing technologies and AI, though AI places the highest demands on data quality, specialist skills, testing and assurance, and governance. Each condition points to a front for action, and international co-operation is a fifth opportunity that cuts across all of them, allowing much of what each country needs to be built once rather than developed repeatedly. Priorities will differ across countries according to  market  structure,  development  priorities  and  the  age  and  digital  maturity  of infrastructure, but the underlying challenges are widely shared.

Regulatory  frameworks  should  allow  operators  to  propose  whichever solution  best  addresses  a  given  network  need  and  efficiently  recover  its costs. Operators often face clearer pathways to deploy new physical infrastructure than digital or operational alternatives addressing the same network need. Solutions include funding rules that do not favour capital spending on new equipment over digital or operational solutions, incentives linked to measurable outcomes such as the  unlocking  of  capacity  and  avoision  of  congestion,  and  credible  methods  for valuing system-wide  benefits that would support more  efficient investment decisions. Regulatory sandboxes, which let operators trial new approaches under temporary exemptions from normal rules, and innovation funding offer a route to building evidence for tools that have yet to prove themselves.

Better data and greater visibility are most urgently needed at distribution level,  where  operators  have  limited  information  and  the  need  for  data  is increasing fastest, by rooftop solar, electric vehicles and heat pumps being connected  in  growing  numbers. Many  distribution  network  operators  lack visibility over large parts of their network, and information that does exist frequently sits in incompatible formats across organisational silos. Improved data quality and visibility,  and  interoperable  data  models  allowing  information  to  move  between systems and trusted mechanisms for sharing data would support both digitalisation and AI. Meanwhile, shared data infrastructure and testing environments can also lower costs and spread learning.

Utilities  and  regulators need to build combined power-system and digital expertise, and to adapt the processes around it. Professionals who combine the  two  disciplines  remain  scarce  and  the  grid  workforce  is  ageing,  with  the number of workers aged 55 and over rising by nearly 50% between 2015 and 2024, compared with 20% for those under 55. Training should be accompanied by changes to workflows and operational processes so that proven tools move beyond pilots and become part of routine operations.

Assurance and security should be built in from the outset and calibrated to the criticality of each application. 70% of surveyed operators use AI widely for maintenance, but only 23% use AI in real-time operations. This is a reflection of the  explainability,  auditability  and  accountability  requirements  when  AI  informs safety-critical decisions, because operators remain accountable. Common approaches to validation, certification and human oversight would support wider adoption, with cybersecurity treated as a core design requirement and particular attention to where operational data are stored, who controls the models used in critical functions and how strategic dependencies are managed.

International  co-operation  can  reduce  costs,  accelerate  deployment  and widen access to proven solutions, helping countries make more efficient use of existing infrastructure, improve affordability and accelerate electrification in a secure way. Deployment of grid-enhancing technologies has so far been concentrated in Europe and North America. Sharing expertise, testing facilities and approaches to validation and certification helps countries build trust in new technologies and manage strategic dependencies as grids come to rely more  heavily  on  software,  data  and  AI.  For  emerging  market  and  developing economies,  proven  regulatory  approaches,  shared  technical  resources  and targeted grants and below-market loans can help utilities deploy digital solutions earlier,  build  visibility  and  controllability  through  asset  replacement  cycles  and access skills that are difficult to develop alone.

## Chapter 1. The need for modern grids

This chapter sets the scene: it explains why, as electricity demand is rising faster than grids can be expanded, this creates an opportunity to use existing networks better, and how digitalisation, grid-enhancing technologies and artificial intelligence (AI) can be combined to capture it. It introduces the concepts used throughout the report, a shared toolkit and a framework of three layers of grid optimisation.

## Grids in the Age of Electricity

The  grid  is  the  critical  enabling  infrastructure  on  which  the  energy  transition depends for security, decarbonisation and affordability, as economies around the world increasingly rely on electricity. Electrification of end uses is a core pillar of the strategy selected by many jurisdictions to strengthen their energy security and cut emissions, making electricity the backbone of the transition.

Demand for electricity is rising rapidly. Electricity demand has grown at roughly twice the rate of overall energy demand over the past decade, driven in part by electrification, data centres, cooling and industrial growth. This ratio continues to widen, while new renewable generation, often built far from demand centres, is adding further need for transmission. To meet these needs, 25 million kilometres 1 of lines are expected to be added under the IEA's Current Policy Scenario (CPS), equivalent to boosting grid capacity by 30% by 2035. This is why the current period is  termed  the  Age  of  Electricity:  electricity  demand  is  decoupling  from  energy demand, and electricity is fast becoming the backbone of the energy system.

This transformation is also changing the conditions the grid has to cope with, not only  how  much  it  carries.  Distributed  energy  resources  such  as  rooftop  solar, batteries, electric vehicles (EVs) and flexible demand have turned many grids from unidirectional  systems  into  systems  with  dynamic  two-way  flows,  while  large inverter-based  power  sources  and  vast  data  centres 2 represent  a  new,  more concentrated form of generation and demand. Both trends are increasingly evident at  the  distribution  level  as  much  as  at  the  transmission  level,  creating  new challenges  for  voltage  management,  transformer  loading,  feeder  capacity  and

1 Grid additions include new lines (expansion) and replacement of existing assets (refurbishment and modernisation).

2 Data centres are among the grid users with the highest spatial concentration as they cluster near cities, near fibre networks and close to their clients.

protection settings, and both can produce sharp peaks that grids historically built for  steady,  predictable  conditions  are  not  designed  to  absorb  without  being actively managed.

## Demand growth and the need for grid expansion to 2035 in the Current Policies Scenario

<!-- image -->

Sources: IEA (2026), Electricity; IEA (2025), World Energy Outlook.

Where  the  grid  cannot  keep  pace,  the  consequences  are  well  documented: lengthening connection queues, new  housing and industrial development competing with data centres and generation projects for scarce grid capacity, and, in the most severe cases, service disruption. Left unaddressed, these circumstances risk slowing electrification plans just as they need to accelerate, with knock-on costs for competitiveness and climate goals.

Stability adds a further dimension to this complexity: operators need to ensure not only that flows stay within the thermal limits, but that the system retains enough strength to ride through disturbances. As converter-connected resources displace synchronous  generators,  several  stabilising  properties  traditionally  provided  by synchronous machines, including inertia, voltage support, fault current contribution and damping (collectively known as system strength), come under pressure. Some of these, such as inertia, are inherently linked to rotating mass; others, such  as  voltage  support  and  damping,  can  also  be  delivered  by appropriately designed converter-connected resources or dedicated equipment. These variables are faster-moving and harder to observe and model than thermal limits, raising the bar for the quality of data and validation that grid operators need to manage them. This is particularly important as AI-based tools are increasingly used to support grid operations, because their performance depends heavily on the quality of the data and models they rely on.

Meeting this growth in demand will require higher grid capacity. The question this report addresses is how to achieve this capacity growth given that expansion, that is the buildout of new infrastructure, is struggling to keep pace.

## The limits of traditional grid expansion

New grid infrastructure is failing to keep pace with the growth in new supply and demand-side assets, even as record volumes of new supply and demand are being connected. Lengthy permitting procedures, supply-chain bottlenecks, labour shortages and rising costs all weigh on the pace of new lines.

This becomes evident in two ways. Connection queues are lengthening: at least 1 700 GW  of  renewables  and  600 GW  of  utility-scale  battery  projects  at  an advanced stage 3  were awaiting connection in 2025. And network congestion 4  is becoming more frequent and costly for grid users: in 2024, grid congestion cost USD 12 billion in the United States and EUR 4.3 billion in the European Union, with Germany alone accounting for over half of the EU total. Curtailment of surplus renewables also carries an environmental cost as fossil-based production is not displaced;  curtailment  reached  over  10 TWh  in  the  European  Union  in  2024 (enough to power around three million homes for a year), while India recorded 2.3 TWh of curtailed solar generation in 2025.

Grid expansion alone is not the economically efficient answer. Building grids to eliminate all congestion would mean matching peak needs at all times, leading to low average grid usage and uneconomical outcomes; given the low load factor of many  renewable  and  demand  assets,  a  certain  level  of  congestion  is  in  fact efficient. As a result, a growing share of total grid spending will go towards the tools and resources required to dynamically operate the system, meaning that how well the existing network is used has become just as important as how much new capacity it is built.

## Making better use of grids to complement grid expansion

Where  grids  cannot  be  built  fast  enough,  the  answer  lies  in  delivering  more energy,  securely,  with  the  existing  networks.  Existing  grids  typically  contain meaningful untapped capacity, spare capacity that varies by location and time. Not all of it is usable, because it must be weighed against power quality, system

3 Projects are defined as being at an advanced stage if they are at least under review by the grid operator. This classification excludes projects in the early stages, deemed speculative or unlikely to materialise, and gives a more realistic sense of the scale involved.

4 Grid  congestion  occurs  when  the  network  lacks  the  capacity  to  safely  and  reliably  transfer  electricity  from  where  it  is generated to where it is needed, forcing the operator to take actions to balance electricity security and economics.

flexibility, stability and resilience, but it can be unlocked by improving how the system is planned and operated.

## The digital grid toolkit: Digitalisation, grid-enhancing technologies and AI

Three complementary tools can unlock the untapped grid capacity: digitalisation, grid-enhancing  technologies  (GETs)  and  artificial  intelligence  (AI),  collectively referred to here as the ' digital grid toolkit '. This section introduces what each is and how they relate; Chapter 2 gives a fuller technical treatment of each.

Digitalisation  is  the  foundation. Better  sensing,  data  and  connectivity,  for example through supervisory control and data acquisition (SCADA) and advanced metering, allow operators to see their networks far more fully and control assets remotely, enabling them to route flows, manage congestion, and support voltage and stability actively.

GETs build directly on that foundation. GETs are hardware, software or hybrid solutions that cost-effectively raise the capacity, flexibility, stability or resilience of electricity grids by revealing latent headroom and system limits, redirecting flows or making existing assets more controllable. This report focuses on GETs that offer  the  greatest  potential  for  digitalisation  and  AI  and  that  are  deployed  and controlled directly by grid operators, such as dynamic ratings, advanced powerflow  control,  topology  optimisation  and  fast  corrective  controls,  rather  than  the wider set of technologies (including advanced conductors, voltage uprating 5 and storage) sometimes included under the GET label in the literature.

AI adds a further, cross-cutting layer. It  spans  a  spectrum from rules-based systems through machine  learning  to  generative  and,  increasingly,  agentic  AI, capable of planning and acting across several steps with limited prompting. AI has been used by network operators for two decades, but what is different about the current wave of AI solutions is that new AI architectures can process large, diverse data  streams,  graphics  processing  units  (GPUs)  and  cloud  computing  have sharply improved the speed and cost of model training and inference, and utilities now hold more operational, asset, weather, imagery and customer data than in previous  technology  cycles.  AI  can  therefore  support  operators  managing  the growing grid complexity in unprecedented ways.

5 Voltage  uprating  is  a  grid  modernisation  process  that  involves  increasing  the  operating  voltage  levels  of  existing  grid infrastructure to boost its transmission capacity.

## The relationship between digitalisation, GETs and AI

<!-- image -->

IEA. CC BY 4.0.

Notes: AI = artificial intelligence. Each layer builds on the one below it. AI enhances both digitalisation and digital services.

None  of  these  substitutes  for  continued  grid  expansion.  Digital,  GET  and  AIenabled solutions unlock capacity more quickly and, in many cases, at lower cost, but traditional buildout remains indispensable; the two should be used together to prioritise, defer or target new infrastructure where appropriate.

## Three layers of grid optimisation

Better use of the existing grid, at both transmission and distribution level, can be understood as three layers, each resting on the layer below, each with a different balance between human judgement and AI, and sharing one goal: enabling higher system utilisation, in a secure way.

## Three layers of grid optimisation and the role of AI

## Flexibility

Matching load and distributed resources to spare capacity, in time and place

## Network assets

Getting more from assets already in service securely ( capacity ) and minimising their downtime ( availability )

## Operational security criteria

How risk is assessed and operating margins are set (across thermal, voltage and stability limits)

## Examples

demand response, managed EV charging, storage, energy efficiency, flexible/non-firm connections, siting new load where headroom exists

## Report focus

## Examples

Capacity : grid-enhancing technologies, storage as a transmission asset, real-time remedial actions Availability : predictive/condition-based maintenance, optimised repairs and restoration

## Examples

Planning methodologies, contingency analysis and reserve setting, real-time monitoring and forecasting of stability

Currently dynamic, data-driven limit assessment within existing frameworks In the future alternatives to the deterministic N-1 criterion

IEA. CC BY 4.0.

Notes: The layers are stacked from the operational security criteria at the bottom to flexibility at the top, each resting on the layer below. The two lower layers are the focus of this report.

Sources: IEA, adapted from: Brattle Group (2026), The Untapped Grid; A. Svendsen and R. Nyiredy (2026), The future power grid.

At the base is the operational security criteria layer , which determines how risk is assessed and operating margins are set. Traditionally, grids have been planned and operated with deterministic security margins: networks were sized to cope with the expected highest demand hour of the year, while also accounting for a defined  list  of  likely  outages  that  could  reduce  network  capacity.  A  risk-based approach instead asks how often, and by how much, the grid could be pushed further without increasing the chance of a fault, thereby replacing implicit margins with explicit, quantified decision criteria. This is a fundamental change, requiring new  planning  and  operational  methods,  but  it  is  where  the  highest  long-term returns  for  utilisation,  reliability  and  resilience  are  likely  to  sit.  The  operational security layer sets a ceiling on what the two layers above it can safely achieve.

Human sets rates,

products, connection terms, market design

Human validates and supervises

Human sets standards and limits; retains authority

AI

forecasts and co-ordinates resources; sub-second remedial action

## AI

optimises ratings, flows and configuration; predicts failures and guides operators

## AI

monitors and forecasts limits; advises

The IEA's Electricity 2026 report found that the largest gains from GETs arise precisely when they are combined with a risk-based approach to grid operation. AI and digital tools can monitor, forecast and advise on limits, but secure operation still rests on validated models, clear rules, operator authority and the ability to act under contingencies.

The network asset layer above draws more from the assets in service, through GETs,  including  automation  and  decision-support  tools,  and  keeps  assets available through predictive maintenance, early warning of developing faults and faster  restoration;  here  AI  helps  optimising  and  predicts,  while  the  operator validates and supervises.

The flexibility layer at  the  top  matches  demand-side resources, batteries and EVs, whether behind or in front of the meter, to spare capacity in time and place; co-ordination  can  rely  on  market  or  price  signals,  but  flexibility  can  also  be delivered  without  an  explicit  signal,  for  example  through  pre-agreed  operating protocols. Here AI forecasts and co-ordinates, and can act within sub-seconds, while the operator sets rules, products and market design.

Across  all  three  layers,  the  respective  roles  of  human  and  AI  are  expected  to evolve, but human oversight remains structural: operators stay accountable for system security even as AI takes on a larger operational role, and sustaining that accountability  requires  operators  to  retain  sufficient  understanding,  tools  and authority to intervene at any point, a theme this report returns to when discussing trust in AI-based decision-support tools.

Because the layers draw on the same physical headroom, gains overlap rather than  add  up;  as  the  network  asset  layer  pushes  assets  harder,  the  binding constraint  can  move  from  thermal  capacity  to  stability,  so  operational  security margins must keep pace. This is why capacity-unlocking measures need to be assessed against the operational security framework that makes them usable, and why regulators and operators need transparent methods for quantifying uncertainty,  approving  risk-based  limits  and  validating  remedial  actions  before new headroom is reflected in planning, markets or real-time operation.

This report concentrates on the two lower layers: the network itself and how it is operated, since the physics and operating practices involved are broadly common across countries and improvements transfer relatively easily. This is where the IEA's work with energy regulators can most directly help operators use existing capacity better.

While the flexibility  layer  is  an  equally important route to  higher  utilisation,  it  is more  specific  to  each  market's  design  and  involves  many  actors  beyond  the network  operator;  it  is  therefore  the  focus  of  complementary  IEA  work  and  is treated here as context.

## Moving from long-term planning to real-time operations

The opportunity to make better use of grids arises across all timeframes: longterm  planning,  operational  planning  over  horizons  ranging  from  several  weeks ahead to day-ahead, and real-time operation. Each rests on different assumptions as  uncertainties  narrow  as  the  system  approaches  real  time,  but  the  same underlying  transition  applies  throughout:  from  static,  worst-case  assumptions towards  methods  that  represent  a  wider  set  of  conditions,  including  evolving climate conditions, more realistically. The digital grid toolkit can add value at every timeframe, but only delivers that value where it is actually used. A tool proven and used in real-time operations, for instance, but absent from the planning studies conducted months or years ahead, never influences the decisions made on the basis of those studies.

## Making better use of the grid across planning and operational timeframes

| planning                                                                                                                                                                                                                                                                                                                                  | Long-term and connection studies                                                                                                                                                                                                                                                                  | Operational planning (from weeks ahead to Real-time operation                                                                |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|
| What to build, defer or connect, and location (investment focus)                                                                                                                                                                                                                                                                          | Allocating market capacity between nodes or zones, and developing remedial action plans to manage outages (security focus)                                                                                                                                                                        | Decisions the system secure conditions evolve, including automatic responses faster                                          |
| materialising or delayed, policy shifts, technology maturity,                                                                                                                                                                                                                                                                             | generation projects being and conditions Forecast error on variable demand and supply, and unplanned outages, against largely known generation schedules                                                                                                                                          | Uncertainties Evolving real-time conditions and instantaneous                                                                |
| From deterministic firm- capacity cases sized to annual minima and maxima, towards finer granularity (some operators already run cases on an hour-by- hour basis) and increasingly probabilistic and stochastic methods that represent variable demand and supply, realistic outages, and the remedial actions and technologies available | From preventive margins held in reserve, towards accounting for the large set of remedial actions already standard in many systems (topology, PST and HVDC setpoints, redispatch and countertrading) to minimise congestion management costs rather than holding conservative headroom in reserve | How practice is evolving From fixed seasonal static limits, towards dynamic limits and planned curative sequences, supported |

How the digital grid toolkit helps (digitalisation, GETs and AI)

Rationalise new build: identify faster or cheaper options and defer or avoid reinforcement, on the condition that GETs are represented in planning studies

Increase the transfer capacity made available to the market by default, while also widening the set of low-cost remedial options available should unplanned outages occur; continuously evaluating physical constraints so that assets can safely operate at their true maximum, managing line congestion dynamically

Deliver additional headroom in real time so curative actions are needed less often, and allow system operators to securely operate closer to true network limits when needed and where conditions allow

Notes: GET = grid-enhancing technology; HVDC = high-voltage direct-current; PST = phase-shifting transformer. The digital grid toolkit includes digitalisation, GETs and artificial intelligence.

## Proven benefits of the digital grid toolkit

Real-world deployments show measurable benefits across the digital grid toolkit, including  higher  transfer  capacity,  lower  congestion  costs,  faster  connection studies, improved forecasting and greater reliability.

## How the digital grid toolkit delivers system benefits

| Benefit category                         | Technology                         | Reported outcome                                                                                                                                           | Jurisdiction   |
|------------------------------------------|------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|
| Connection studies                       | Digital twin                       | 70% less time to analyse and decide where to reinforce                                                                                                     | United Kingdom |
| Transfer capacity                        | Dynamic line rating                | EUR 180 000 saved over four hours, with EUR 44 million projected annually                                                                                  | Belgium        |
| Congestion                               | Dynamic line rating                | USD 64 million a year in congestion savings for under USD 1 million invested                                                                               | United States  |
| Transfer capacity                        | Advanced power- flow control       | More than 2 GWof additional capacity to move power from north to south region                                                                              | United Kingdom |
| Congestion                               | Topology optimisation              | USD 113 million in regional congestion cost savings in 2025                                                                                                | United States  |
| Stability                                | BESS with grid- forming capability | GBP 170 million consumer savings over 15 years and avoided 2.6 million tonnes CO 2 through reduced stability, balancing, curtailment and congestion costs. | United Kingdom |
| Forecasting accuracy and balancing costs | AI-assisted wind forecasting       | Forecast error cut from 16.8% to 10.1%, saving USD 49 million over five years                                                                              | United States  |
| Reliability                              | AI-assisted vegetation management  | 30% fewer customers interrupted and 55% fewer outage minutes                                                                                               | United States  |

Notes: AI = artificial intelligence; BESS = battery energy storage system. Reported outcomes are illustrative examples from specific deployments and depend on local network conditions, the constraint addressed, the baseline, and the extent to which the tool is integrated into planning, operational planning and real-time operations. They should therefore be read as evidence of achievable gains under suitable conditions, not as transferable performance benchmarks.

These examples show that the digital grid toolkit can deliver measurable gains when  applied  to  a  clearly  identified  system  need  and  integrated  into  routine network  processes.  The  size  of  the  benefit,  however,  depends  on  the  local constraint being addressed and on whether the technology is treated as part of planning  and  operations.  This  is  why  deployment  should  start  from  a  systemneeds  assessment:  identifying  the  system  constraints,  and  then  selecting  the appropriate combination of digital, operational and physical measures.

## What this report sets out to answer

This chapter has set out the challenge and the opportunity: electricity demand is rising  rapidly,  grid  expansion  alone  cannot  keep  pace,  meaningful  untapped capacity exists in the networks that are already in place, and there is a suite of digital tools which could help unlock this capacity. The rest of this report examines how these digital tools might be used. Chapter 2 looks at the state of deployment across  the  digital  grid  toolkit,  including  the  fuller  technology  landscape  only introduced briefly here. Chapter 3 provides an estimate of the potential gains at the global level and examines the conditions needed to deploy these tools more widely and scale these gains. Finally, Chapter 4 sets out policy recommendations for operators, regulators and governments.

## Chapter 2. State of play

This  chapter  sets  out  the  current  status  of  the  digital  grid  toolkit.  The  central message is that the technologies needed to make existing grids more visible and controllable and allow them to be dynamically operated are increasingly available, but  deployment  remains  uneven  and  slower  than  the  progress  in  technology performance.  The  chapter  is  organised  around  three  groups  of  functions,  in deliberate order:

-  sensing and measurement, communications and data, monitoring, analytics and control  systems  provide  the  visibility  and  controllability  that  everything  else depends on
-  grid-enhancing technologies (GETs) then use that foundation to reveal headroom, redirect flows and automate corrective actions while maintaining secure operation
-  AI-enhanced  solutions  add  a  layer  on  top  of  both,  improving  forecasting, screening, optimisation, maintenance and decision support across the stack.

## Functional taxonomy of the digital grid toolkit in scope of the report

| Category                          | Core function                                                                                                           | Examples of technologies and applications                                                                     |
|-----------------------------------|-------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------|
|                                   | Sensing and measurement Measure conditions across the network                                                           | Meters and sensors, PMUs, weather sensors                                                                     |
| 1. Monitoring and control systems | Communications and data Move, store and integrate measurements and operational data                                     | Communication network, data platform                                                                          |
| 1. Monitoring and control systems | Monitoring, analytics and controls Monitor system conditions, analyse performance and operate assets                    | SCADA/EMS, WAMS, (A)DMS, DERMS, digital substation, situational awareness platform                            |
|                                   | Dynamic ratings Set thermal limits from actual operating and ambient conditions rather than fixed assumptions           | DLR, DTR                                                                                                      |
|                                   | Capacity allocation Allocate available capacity to network users                                                        | SATA, active network management, dynamic operating envelope                                                   |
| 2. Grid- enhancing technologies   | Power flow management Redirect flows from congested to underused paths and control transfer levels                      | Phase-shifting transformer, advanced power-flow control, topology optimisation, SSSC, TCSC, controllable HVDC |
|                                   | Stability-constrained capacity enhancement Address voltage and stability constraints that limit usable network capacity | Grid-forming inverter capability, SVC, (e-)STATCOM                                                            |
|                                   | Protection and restoration Act preventively or when faults occur                                                        | Real-time remedial action scheme, FLISR                                                                       |

3. AIenhanced solutions

## Forecasting and screening

Anticipate system conditions and assess options faster

## Asset analytics

Assess asset condition, predict risks and determine when to intervene

## Operational decision support

Rank and recommend actions to the operator

AI-based load and renewable forecasting, AI-enabled mapping, connection screening and contingency screening

Predictive maintenance, inspection analytics, vegetation management, outage prediction and analytics

Topology-optimisation support, remedial-action ranking, AI-assisted corrective control

Network modelling and simulation Represent and simulate the network for planning and operational analysis

AI-enhanced digital twin, AI-assisted hosting capacity analysis, grid foundation models

Notes: In this report, grid-enhancing technologies (GETs) are defined broadly to cover the technologies listed above. Other literature and jurisdictions sometimes define GETs more widely or narrowly. (A)DMS = (advanced) distribution management system; AI = artificial intelligence; DERMS = distributed energy resource management system; DLR = dynamic line rating; DTR = dynamic transformer rating; EMS = energy management system; (e-)STATCOM = (enhanced) static synchronous compensator; FLISR = fault location, isolation and service restoration; HVDC = high-voltage directcurrent; PMU = phasor measurement unit; SCADA = supervisory control and data acquisition; SATA = storage as a transmission asset; SSSC = static synchronous series compensator; SVC = static VAR compensator; TCSC = thyristorcontrolled series capacitor; WAMS = wide-area monitoring system.

Across  all three categories, technical capability is advancing  faster than deployment. As the examples at the end of Chapter 1 show, many tools have already  delivered  measurable  gains  in  specific  contexts.  The  constraint  is therefore rarely whether the technology can work, but whether it is matched to the right system need, embedded in routine processes and scaled beyond pilots. The maturity of AI applications is generally lower but also varies, from widely adopted forecasting  and  asset  maintenance  tools  to  emerging  applications  to  support control  room  decision  making  and the  development  of  grid foundation  models. Digital maturity is also highly uneven across countries and utilities, meaning that the barriers to scaling up differ by national context as much as by technology.

This chapter draws primarily on deployment experience in advanced economies and the People's Republic of China (hereafter, 'China'), where the majority of realworld applications are concentrated. Emerging-market experience is treated in a dedicated section highlighting the opportunity for leapfrogging.

## Digitalisation policies

Digital technologies are evolving quickly, and policy is adapting to this innovation while balancing two objectives: capturing benefits for the system needs, such as grid modernisation, better use of existing assets, faster connection and interoperability, while managing the risks it introduces, including data governance and cybersecurity.

Digitalisation policies are building the data, cyber and interoperability foundations for smarter grids. In the United States, the 2022 Inflation Reduction Act and the 2024 Grid Modernization Strategy support sensors, communications

and  intelligence  at  the  interface  with  grid  users.  Europe's  Digitalisation  of  the Energy System action plan (2022), Network and Information Systems Directive (NIS2), General Data Protection Regulation (GDPR), Critical Entities Resilience Directive and  2025  Clean  Industrial  Deal  emphasise  energy-data  spaces, cybersecurity and digital sovereignty, which the newly adopted Strategic Roadmap  for Digitalisation and AI in Energy Sector translates into an implementation strategy. China's 15th Five-Year Plan, which outlines the country's development objectives for the period 2026 to 2030, places digital platforms and real-time sensing at the centre of its power system transformation, while India's Revamped  Distribution  Sector  Scheme  (RDSS)  and  2025-2026  India  Energy Stack show a similar push toward digital public infrastructure for distribution grids.

GET-supportive policies are  increasingly  focused  on  using  existing  networks more efficiently while new infrastructure catches up. In the United States, FERC Order No. 1920 requires transmission planners to consider advanced transmission technologies in regional transmission planning, while FERC Order No.  881  requires  transmission  providers  to  implement  hourly  ambient-adjusted ratings, a step towards dynamic line rating (DLR). In Europe, the Grids Package and Electricity Market Design reform and Electrification Action Plan promote nonwire  solutions,  storage,    and  smarter  planning.  Australia's  Dynamic  Operating Envelopes workstream, and Brazil's ANEEL transmission modernisation and nonwire alternatives provide further examples. Several of these policies, along with the 2024 VoltAIc initiative, the USD 1.9 billion DOE SPARK program and India's 2019 Central Electricity Authority guidelines on high-performance conductors, also cover advanced conductors and reconductoring, hardware upgrades outside this report's core GETs scope but part of the same broader push to boost grid capacity.

There is a growing realisation that AI use in critical infrastructure requires different governance,  distinguishing  lower-risk,  productivity-focused  applications  from safety-critical  uses  that  affect  system  decisions  and  control. AI  policy is  still catching up with this realisation: general AI strategies are increasingly common, often  focused  on  promoting  innovation  while  protecting  users  in  a  context  of seeking autonomy for critical AI uses, but policies and regulations specific to AI in the energy sector remain comparatively rare. Even so, the field has moved from broad principles to more energy-relevant governance within only a few years. The United States moved from the 2023 NIST AI Risk Management Framework and AI Executive Order to DOE's 2024 AI and Energy Strategy and its 2025 Genesis Mission,  which  frame  AI  as  a  tool  for  accelerating  scientific  discovery,  grid modelling, infrastructure planning and energy-system resilience. The European Union issued in 2024 its AI Act, the world's first comprehensive legal framework that regulates AI based on a tiered risk system, followed in 2026 by its Strategic Roadmap for Digitalisation and AI in Energy, mentioned above, extending this approach to the  energy  sector  specifically.  In  the  United  Kingdom,  the  energy regulator Ofgem has been overseeing AI in the energy sector since 2023 and

published its guidance on ethical AI use in 2025. China's AI-energy plans frame AI as a core tool for dispatch, forecasting and renewable integration. The G7's own attention to this nexus, and growing engagement from Singapore, Japan and the International Solar Alliance, shows the agenda is widening beyond the largest power systems.

These policy efforts are growing and laying the groundwork for enabling the digital grid  toolkit.  However,  where these enabling conditions are weak, they become barriers to deployment, as examined in Chapter 3.

## Monitoring and control systems

Digital  infrastructure  has  enabled  the  transition  from  a  passive,  periodically surveyed network to one that can be observed, analysed and acted on in close to real time. However, not all networks have digitalised at the same pace. As power systems transform around the world, the replacement and modernisation of assets is an opportunity to accelerate digitalisation.

## Visibility and controllability are the foundations of modern grids

Modern grids require real-time visibility and responsive control. Better sensing, connectivity and data systems enable operators to see network conditions more clearly, while remotely controlled assets allow operators to act in near-real time and optimise system performance.

## Data and situational awareness

Network operators cannot optimise what they cannot measure. Real-time visibility of  the  network  is  therefore  the  foundation  for  every  downstream  application. Traditional  SCADA-EMS  are  being  complemented  by  wide-area  monitoring systems (WAMS), which combine high-frequency measurements across broad network areas to give operators a system-wide view of voltage, frequency, power flows and dynamic stability, allowing a wider array of advanced decision support tools.  The  value  of  data  depends  as  much  on  its  volume  as  on  its  quality, consistency and accessibility, which remain uneven even within a single utility. Unfortunately, a joint study of the European associations of transmission system operators  (TSOs)  and  distribution  system  operators  (DSOs)  found  that  utilities tend to treat data management as a series of disconnected processes rather than a continuous, integrated flow across departments and operators.

Digital twins (see box) are emerging to connect real-time visibility to the network studies  that  underpin  planning  and  operations.  As  monitoring  and  data  quality improve,  a  digital  twin  can  keep  the  underlying  network  model  current  as  the

system itself changes, rather than relying on periodic manual updates. It can also support control-room simulation grounded in actual measured conditions, rather than assumptions or a manually set system state.

## Controllability: Turning visibility into action

Visibility only creates value once operators, or automated systems acting on their behalf,  can  act  on  what  they  see.  This  depends  on  remotely  controllable  grid assets (breakers, switches, tap changers, protection relays and power-electronic devices), integrated with SCADA and EMS so that a detected condition can trigger a  response  in  seconds  rather  than  requiring  a  field  crew  to  be  dispatched. Controllable grid assets are not rolled out everywhere; in particular, many older distribution feeders rely on manual switching and legacy protection, constraining the response capability of the operators.

## Digital twins: Virtual replicas that enable multiple grid solutions

A digital twin is a virtual version of an asset or network, kept in step with the real thing  by  field  data.  In  the  case  of  grids,  the  twin  can  combine  electrical  data (voltages, flows) with other information such as terrain, weather, generation and demand  to  mirror  the  state  of  the  network  and  simulate  how  it  behaves  under different conditions. A digital twin is rarely a solution in its own right, but a building block that other applications run on. Digital twins are mature and already in service in  a  number  of  countries.  What  varies  is  the  application  built  on  top.  Operators typically start with a narrow use case and expand from there. Current applications include:

-  Asset monitoring: Individual transformers or cables are modelled to monitor condition and set safe loading limits. Projects delivered by Enline in Spain report a 15% cut in maintenance costs and a 25% extension of asset lifespans.
-  Line capacity: Thermal ratings are estimated section by section, in some cases without new sensors. On Ibiza, where summer loading is heavy and lines run through woodland and urban areas, a digital twin of four lines raised average capacity by around 20%.
-  Vegetation risk management: Terrain, conductor sag and vegetation growth are modelled together to manage clearances and wildfire risk. Swissgrid has recorded its entire 6 700 km network in a 3D model, so that vegetation is cut where the risk is highest rather than on a fixed cycle.

-  Network planning studies: Lines, flows and contingencies are modelled for reinforcement  studies.  In  the  United  Kingdom,  National  Grid's  Triton  brings together data from distribution operators and transmission owners and has cut the time needed to decide where to reinforce by 70%. Chile's national system operator cut simulation time by 86%, now runs 30 scenarios at once, and has used the tool in annual transmission expansion planning since 2025.
-  Connection  queue  management: Application  data  and  study  models  are consolidated  into  one  network  model.  In  the  United  States,  PJM  screened 811 applications representing 220 GW in under an hour.
-  Whole system modelling: National twins are linked to test resilience and crossborder co-ordination, the aim of the TwinEU project across 15 countries.

## Digital maturity varies considerably across grid segments and regions, and distribution is where the largest gap remains

Digital adoption is highly uneven among network operators, shaped by system needs, regulatory frameworks, investment cycles and institutional capacity. Data in this report comes from an IEA-conducted global survey of network operators in 2026, that received 25 responses: 11 from transmission operators and 14 from distribution  operators  across  Europe, North America, South America, East and Southeast Asia, and Oceania. While the sample is not statistically representative, it provides a geographically diverse snapshot of current digital maturity, deployment  priorities  and  perceived  barriers.  The  starkest  divide  is  between transmission and distribution: transmission is comparatively data-rich and easier to digitalise, since transmission networks have fewer, larger and more standardised  assets  to  instrument  than  the  myriads  of  dispersed  low-voltage assets found in distribution. It is in distribution networks, closest to fast-growing distributed  resources,  where  data  gaps  are  the  largest.  Many  surveyed  DSOs report having high ambition, including for the low-voltage grid,  with most aiming 6 to digitalise over 50% of their low-voltage substations by 2035, even for entities starting from close to zero today.

6 The survey did not systematically collect separate figures for digitalisation of substations at the mid- and low-voltage levels, but many respondents provided information spontaneously.

## Digital maturity across grid segments among surveyed network operators, 2026

<!-- image -->

IEA. CC BY 4.0.

Notes: The vertical axis represents the breakdown of network operators by response, and the colour represents the fraction of their network which they have visibility of or control over. Estimated visibility and control correspond to the following responses to the survey: Mostly = 51 to 75% of the network; Partially = 26 to 50% of the network; Rarely = under 25% of the network. For example, 60% of distribution operators have no controllability over at least half of their network. Source: IEA survey conducted for this report (2026), based on 25 network operator responses: 11 transmission operators and 14 distribution operators. Given the small sample size, these results should be read as indicative of broad patterns rather than as statistically representative.

## Transmission grids

Digital technologies already play a significant role in modern transmission grids. SCADA and EMS provide real-time monitoring and control of major assets, while digital sensors, PMUs and weather measurements add higher-resolution data on flows, voltage, frequency, equipment condition and operating limits. The use of drones  and  satellite-based  technology  enables  inspection  of  power  lines  and vegetation  management  with  lower  effort  and  reduces  exposure  of  staff  to potentially hazardous conditions.

Traditional  SCADA-EMS  relies  on  few  data  combined  with  asset  and  system models or estimated variables. For example, a line capacity is estimated based on conditions along the conductor itself, typically approximated from weather data and static assumptions, rather than continuous direct measurement of its actual condition, such as temperature, icing or ageing. The growing level of digitalisation in transmission opens the door to advanced tools such as DLR and control-room decision support. The priority is to keep pushing the integration of SCADA, EMS, PMUs, WAMS and weather and asset data into trusted planning and operational workflows, so that operators can manage flows, stability, congestion and dynamic rating across meshed networks. The main challenge is breaking down data silos,

extending monitoring to the asset level where it matters most, and giving operators confidence to act on more dynamic information.

## Distribution grids

Traditionally,  distribution  grids  had  unidirectional  flows  and  were  operated  in  a static way, with manual switching and limited automation. As more variable supply and demand connects, the flows become bidirectional and networks need to be managed more dynamically.

The challenges in distribution are similar to those in transmission, with one major addition: far more assets to instrument, finer granularity, and the task of combining fragmented feeder, substation, transformer and smart meter data into operational capability.  This  task  is  assigned  to  digital  platforms:  distribution  management system (DMS), advanced distribution management system (ADMS) and distributed  energy resource  management system (DERMS), which coordinates rooftop solar, batteries, electric vehicles and flexible demand so they can support, rather than stress, local networks.

## Distributed energy resource management system deployment snapshot

| Country        | Operator          | Deployment example                                                                   | Reported outcome                                                             |
|----------------|-------------------|--------------------------------------------------------------------------------------|------------------------------------------------------------------------------|
| Australia      | Ausgrid           | Dynamic operating envelopes replacing fixed export limits on low- voltage feeders    | Raises solar hosting capacity without breaching voltage or thermal limits    |
| United States  | Hawaiian Electric | DERMS aggregating customer solar, batteries and water heaters for grid services      | Customer-sited resources contracted for capacity and fast frequency response |
| United Kingdom | UK Power Networks | Active network management supporting flexible connections for distributed generation | More than GBP 80 million in connection costs avoided since 2014              |

Notes: DERMS = distributed energy resource management system.

Digitalisation priorities in distribution are to strengthen low-voltage visibility, putting smart  meter  data  to  operational  use  (not  only  for  billing  use)  and  deploying automation. Smart meters support load flow visibility while making consumers more aware of their consumption and enabling new billing structures. Smart meter data need to be reliable and integrated with ADMS and DERMS data into operational workflows to deliver value, but many datasets are currently isolated. Most emerging market  and  developing  economies  (EMDEs)  have  an  even  more  basic  priority: improving  feeder  and  transformer  visibility,  digitising  asset  registers,  expanding communications and building the operational capability to use data consistently. 7

7 Distribution-level challenges in EMDEs are discussed in more depth in the dedicated section later in this chapter.

## Distribution-level technologies that convert digital visibility into operational capability

| Capability area                 | Key technologies                                                                                                         | What they enable                                                                                                           | Main scaling constraint                                                                |
|---------------------------------|--------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------|
| Data and monitoring foundations | Smart meters, secondary substation monitoring, feeder sensors, asset registers and distributed energy resource registers | Visibility of loading, voltage, outages, asset condition and distributed energy resource location                          | Data quality, low- voltage topology gaps and communications coverage                   |
| Operational platforms           | DMS, ADMS and DERMS                                                                                                      | Integration of network models, switching, outage management, voltage control and distributed energy resource co-ordination | Legacy system integration, vendor interoperability and operating process change        |
| Local constraint management     | Voltage control, dynamic transformer rating and dynamic operating envelopes                                              | More dynamic use of feeders and transformers while maintaining voltage and thermal limits                                  | Reliable forecasts, controllable devices and transparent operating rules               |
| Remote asset control            | Feeder automation, reclosers, switches, FLISR and outage analytics                                                       | Faster fault location, isolation and restoration, and better response to changing conditions                               | Communications, protection co-ordination, field device availability and operator trust |

Notes: ADMS = advanced distribution management system; DERMS = distributed energy resource management system; DMS = distribution management system; FLISR = fault location, isolation and service restoration.

## Regional digitalisation adoption

The  Smart  Grid  Index  (SGI),  run  by  Singapore's  power  network  owner  and operator  SP Group,  highlights  the  pattern  of  improving  but  uneven  digital maturity. 8 The  2024  benchmark  covers  92 utilities  across  36 countries  and assesses multiple dimensions of grid smartness across seven dimensions:

-  monitoring and control
-  data analytics
-  supply reliability
-  distributed energy resource and storage integration
-  renewable and EV integration
-  cybersecurity
-  customer-facing services.

The merit  of  the  index  is  that  it  does  not  reward  the  installation  of  sensors  or meters, but rather how far the data have been put into operational use, such as hosting-capacity assessment,  voltage and congestion management,  active

8 The SGI should be read as an indicative benchmark and not as a definitive assessment of utility performance. The SGI is compiled and published by SP Group based on publicly available information about each utility, and not through independent audit or verification. SP Group's methodology acknowledges that the index criteria and weighting will need to evolve over time to keep pace with new technologies, and has not been subject to independent academic peer review.

network management, outage restoration, dynamic operating limits and secure co-ordination with distributed resources.

North America records the highest regional average score, supported by strengths in data analytics and distributed energy resource integration, while Europe shows more balanced performance across categories. Asia Pacific is closing the gap fastest, helped by rapid gains in supply reliability, a dimension where the region has improved significantly over the past decade, and rapid progress in advanced metering.  Utilities  in  Asia  Pacific  narrowed  the  gap  thanks  to  alignment  in investment, data systems and operational priorities.

<!-- image -->

## Asset replacement is the cheapest moment to modernise the grid, but does not need to wait for the end of asset lifetime

Replacing or refurbishing an asset is the moment to build in digital readiness, by embedding  sensing,  measurement,  communications  and  monitoring  tools  and controls at a fraction of the cost of a separate retrofit programme later. Missing this  window  is  costly:  once  new  equipment  goes  in  without  it,  operators  are typically locked out of embedding these capabilities for another full asset lifetime, which can run to several decades, incurring higher costs and delays later on. Since a large share of network spending is already committed to asset replacement, embedding sensors, controls and GET  compatibility into these renewal programmes  makes  modernisation  part  of  planned  investment,  rather  than  a separate upgrade requiring its own business case.

Grid  assets  and  the  demand  they  serve  operate  on  very  different  investment timelines. Power lines, transformers, substations and protection systems typically turn over across decades, far more slowly than the pace of change on the demand

side.  This  mismatch  also  applies  within  the  digital  layer  itself:  sensing  and measurement devices, communications and data systems, and monitoring and control platforms can often be refreshed faster than primary grid equipment, but their value depends on whether the underlying assets were designed to host them.

<!-- image -->

IEA. CC BY 4.0.

Notes: Lifetimes represent typical design or refresh cycles and can vary by voltage level, asset duty, regulatory framework, maintenance practice and local conditions. Data centre computing hardware includes graphics processing unit (GPUs) and servers. "Digital platforms" refers collectively to systems such as SCADA, ADMS and DERMS, as described in this chapter. ADMS = advanced distribution management system; BESS = battery energy storage system; DERMS = distributed energy resource management system; GET = grid-enhancing technology; HV = high voltage; PV = photovoltaic.

In advanced economies, there is an opportunity to modernise grids in the coming years.  Much  of  the  asset  base  is  ageing:  in  Europe  and  North  America,  a significant share of the lines and cables are approaching the end of their typical operational lifetime. In EMDEs the asset age profile is younger, with roughly 40% commissioned in the past decade and around 35% more than 20 years old. Ageing assets are more prone to faults and require investment to extend their lives, so replacement needs are increasingly converging with demand for new capacity.

Capturing  the  modernisation  opportunity  does  not  mean  waiting  passively  for assets to reach end of life. Where the case is strong, for example on corridors facing the sharpest capacity or stability pressure, utilities can bring modernisation forward, replacing or upgrading assets ahead of schedule specifically to embed digital  and  GET-ready  capability  sooner,  rather  than  only  opportunistically  as

natural replacement cycles fall due. The same long asset lives that create this opportunity also constrain how quickly it can be captured: primary equipment often remains in service for more than 40 years, and control and protection systems are typically refreshed only every 15-20 years. Modernisation therefore needs to be managed  across  overlapping  investment  cycles:  conventional  buildout  where clearly  needed,  digital-by-default  replacement  cycles  that  embed  sensing  and measurement tools, communication, data, and monitoring systems, analytics and control  capabilities,  and  GETs  and  AI-enabled  tools  that  can  act  as  near-term bridges while slower infrastructure, regulatory and manufacturing cycles catch up.

## Typical time to deploy and commission grid hardware and software, and grid user technologies

<!-- image -->

IEA. CC BY 4.0.

Notes: Ranges reflect typical projects commissioned in the past five years in advanced economies. For grid assets, deployment time includes planning, procurement, approvals, installation and commissioning where relevant; for digital tools, they reflect installation and commissioning only. Data centre computing hardware includes graphics processing unit (GPUs) and servers. BESS = battery energy storage system; GET = grid-enhancing technology; HV = high voltage; PV = photovoltaic.

## Grid-enhancing technologies

GETs are digitally enabled tools that increase the capacity, flexibility and efficiency of existing networks without waiting for major new infrastructure.  As shown in the 9 examples in Chapter 1, they can deliver substantial gains when they address a specific  constraint.  Their  safe  and  scalable  use,  however,  depends  on  coordination  across  planning,  operational  planning  and  real-time  operations,  and integration within network companies' processes.

In  practice,  GETs  and  AI  are  increasingly  complementary.  GETs  create  new controllable  options  for  operators,  for  example  by  revealing  dynamic  thermal headroom,  redirecting  flows  or  identifying  alternative  topologies,  while  AI  can improve  the  forecasts,  screening  and  decision  support  needed  to  use  those options more consistently.

## GETs give operators a proven, fast-acting tool alongside grid buildout

## Overview of selected GETs

| Technology family            | Primary function                                                                                       | Maturity (TRL) and deployment status                                                                            | Typical benefit                                                                      |
|------------------------------|--------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------|
| Dynamic ratings              | Reveals real-time thermal headroom in lines and transformers                                           | TRL 9 commercially available; strongest evidence base among GETs                                                | Higher transfer capacity, lower curtailment, deferred reinforcement                  |
| Advanced power- flow control | Redirects power away from congested circuits toward underused paths                                    | TRL 9 with targeted deployments on congested corridors and modular devices still at limited scale               | Raises boundary capacity and reduces congestion costs                                |
| Topology optimisation        | Uses switching and busbar configurations to reroute flows                                              | TRL 8-9 technically proven; but operator trust in switching is still developing                                 | Low-CAPEX congestion relief and better use of existing assets                        |
| Real-time remedial actions   | Acts rapidly to keep the system secure                                                                 | TRL 9 (5~7 for AI forms) AI-enabled forms are at an early stage and need stronger validation and override rules | Allows operation closer to limits with validated safeguards                          |
| Active network management    | Coordinates feeders, voltage, switching, outages and distributed resources through DMS, ADMS and DERMS | TRL 9 mature platforms, but scaling limited by feeder visibility and IT/OT integration                          | Higher distributed resource hosting, better voltage management and faster operations |

Notes: This report focuses on the GET applications where digitalisation and AI add the most value and that are deployed and controlled directly by grid operators. Other technologies sometimes included under the broader GETs label, such as advanced conductors and voltage uprating, are not addressed in this report. ADMS = advanced distribution management system; AI = artificial intelligence; CAPEX = capital expenditure; DERMS = distributed energy resource management system; DMS = distribution management system; GET = grid-enhancing technology; IT = information technology; OT = operational technology; TRL = technology readiness level.

9 See Chapter 1 for the full definition and the report's scope, including why conductors, voltage uprating and storage are treated separately.

A decade of deployment shows that GETs can reliably unlock substantial capacity from existing networks. Typical installation is measured in months and costs an order  of  magnitude  less  than  building  new  lines,  making  GETs  an  important complement to grid buildout, able to act on a shorter timescale. Industry coalitions and  specialist  initiatives,  such  as  the  Global  Power  System  Transformation Consortium (G-PST), CurrENT in Europe, the Utilize Coalition in North America and the WATT Coalition, are also helping build the evidence base, standardise use cases and share deployment experience across operators, regulators and technology providers.

## Comparison of technologies to add or unlock capacity

Capacity Increase

<!-- image -->

IEA. CC BY 4.0.

Note: Time to deploy covers the full path to operation, including feasibility and network studies, integration into planning and control-room tools, updates to operating processes and procedures, and, where applicable, deployment of physical assets. Firmness indicates how consistently the additional capacity is available. Low firmness means the gain depends on operating conditions, so it cannot be relied on at all times. $ signs indicate relative deployment cost, from lowest to highest. Sources: IEA (2026), Electricity 2026.

GETs deployment remains geographically concentrated. In the case of DLR, for example, three-quarters of deployment is concentrated in Europe and North America. There are several reasons for this pattern, including congestion levels, the prevalence of older grid assets that make optimisation more valuable relative to  new build,  and  the  maturity  of the regulatory frameworks needed to credit these technologies in planning and markets. However, the relationship is not  purely  a  function  of  grid  age:  some  fast-growing  systems  face  similar congestion pressures and deploy these technologies for different reasons.

## Dynamic line rating and dynamic transformer rating

Dynamic ratings reveal capacity that conservative, fixed assumptions leave unused. The capacity available between any two points on the network is set by the most limiting  piece  of  equipment  along  that  path  -  lines,  transformers  or  substation equipment - so unlocking capacity generally requires rating across the whole path. Utilities have long used seasonal ratings set to normal ambient conditions, leaving real headroom unused when actual conditions are more favourable. 10

Dynamic rating replaces fixed or seasonal assumptions with time-varying thermal limits for lines and transformers, using weather, loading and asset-condition data to  reveal  usable  headroom.  For  overhead  lines  (dynamic  line  rating  [DLR]), capacity depends on how well the conductor sheds heat, so it rises in cool or windy conditions and falls in still, hot ones. For transformers (dynamic transformer rating [DTR]), the limit is set by winding and oil temperature. Utilities have long varied transformer loading with operating conditions; what is newer is the automation and integration of this into real-time systems. Ratings can be estimated from weather data alone, measured directly with line or transformer sensors, or both combined for  greater  confidence;  the  trend  for  lines  is  towards  forecast-led  methods, reserving sensors for the most constrained corridors.

## Dynamic rating deployment snapshot

| Country        | Operator          | Deployment example                                                          | Reported outcome                                                                                                                                                                        |
|----------------|-------------------|-----------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| United States  | PPL Electric      | DLR on multiple 230 kV lines                                                | Reported 15-17% capacity increase and USD 64 million in annual congestion savings                                                                                                       |
| Belgium        | Elia              | Around 150 sensors across 30 transmission lines                             | Reported short-duration savings of EUR 180 000 over four hours and projected annual savings of EUR 44 million                                                                           |
| Norway         | Statnett          | Operational use of limit forecasts since 2023                               | Reported line capacity increases of up to 20%                                                                                                                                           |
| United Kingdom | National Grid     | DLR on a 275 kV circuit                                                     | Reported average capacity increase of 45% and estimated operating cost savings of GBP 1.4 million                                                                                       |
| Finland        | Fingrid           | Sensorless DLR across around 5 500 km of 400 kV lines                       | Additional capacity made available to day- ahead energy markets from April 2026                                                                                                         |
| United States  | Various utilities | DTR deployed on 50 existing power transformers ranging from 5 MVA to 50 MVA | Extended the useful life of existing infrastructure, provided more flexibility during planned or unplanned outages, and enhanced situational awareness through device health monitoring |

Notes: DLR = dynamic line rating; DTR = dynamic transformer rating; kV = kilovolt. Sensorless DLR operates based on publicly available weather data and AI/machine learning correction models rather than physical sensors.

10 Ratings are set conservatively to cover a wide range of likely conditions. Occasionally, in unusually hot weather, they may however exceed the true limits.

## Advanced power-flow control

A newer class of modular devices is making power-flow control faster and cheaper to deploy. Operators have been aiming to redirect power from congested circuits towards  underused  paths:  phase-shifting  transformers  and  flexible  alternatingcurrent  transmission  system  (FACTS)  devices  (including  TCSC,  STATCOMs, static VAR compensators, series compensation and unified power-flow controllers) have done this for decades, and high-voltage direct-current (HVDC) links  have  long  moved bulk  power over  long  distances  and subsea. What  has changed is the emergence of modular, series power-flow controllers that clamp onto  existing  lines  without  new  civil  works  or  substation  rebuilds,  making deployment a matter of months rather than the years a full FACTS installation or new phase-shifting transformer typically requires.

HVDC is also taking on a broader role.  Embedded and multi-terminal  links  let operators adjust power flows independently of the surrounding alternating-current network, and, with grid-forming control, contribute to system strength and stability, not  only  bulk  transfer.  As  these  schemes  multiply  into  multi-terminal  grids  and offshore  hubs,  the  co-ordinated  control  of  these  assets  becomes  both  more valuable and more complex, which is what makes them a natural fit for AI-assisted co-ordinated  control,  optimising  setpoints  across  multiple  links  and  devices  at once, something not practical to do manually at this scale.

## Advanced power-flow control deployment snapshot

Notes: FACTS = flexible alternating-current transmission system; GW = gigawatt; kV = kilovolt; MW = megawatt.

| Country        | Operator       | Deployment example                                                                      | Reported outcome                                                                                    |
|----------------|----------------|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|
| United Kingdom | National Grid  | Modular series controllers on five circuits at three substations                        | Over 2 GWof north-south capacity unlocked and GBP 390 million of estimated savings over seven years |
| United States  | Central Hudson | Fifteen series controllers on an underused 345 kV circuit                               | Around 185 MWunlocked, chosen over a fixed series capacitor for lower resonance risk                |
| Australia      | Transgrid      | Series controllers at two substations on the Victoria to New South Wales interconnector | 170 MWof additional transfer capacity for AUD 45 million without building new lines                 |

## Topology optimisation

Reconfiguring  the  network  to  relieve  congestion  is  an  old  idea  made  newly practical  by  faster  computation.  Grid  reconfiguration  has  traditionally  been  a rudimentary process, decided manually by operators based on past experience and  operational  guidelines.  Using  mathematical  modelling  to  identify  the  best switching action instead of relying on operator judgement is not itself a new idea; what  has  changed  is  tractability.  Finding  the  network  configuration  that  best relieves  congestion  is  a  genuinely  hard  computational  problem,  and  faster

computing and modern optimisation methods, increasingly AI-based, now solve it fast enough to be useful in operations, seconds to minutes, rather than only as an offline  planning  exercise.  This  is  what  is  moving  topology  optimisation  from research into real deployment.

Topology optimisation now supports long-term planning, operational planning and real-time  decision  making  in  several  US  system  operator  regions,  with  case studies concluding that recommended reconfigurations can typically be identified in seconds to minutes, expanding effective grid capability by around 5-25% while meeting reliability requirements and delivering material congestion and curtailment reductions in operational settings.

## Topology optimisation deployment snapshot

| Country       | Operator                     | Deployment example                                                                    | Reported outcome                                                                                          |
|---------------|------------------------------|---------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|
| United States | MISO                         | Economic reconfiguration process developed to facilitate use of topology optimisation | USD 113 million in regional congestion cost savings in 2025                                               |
| United States | ERCOT                        | Topology optimisation tool used to support contingency plan development               | Identified a reconfiguration solution that replaced a prior plan relying on load shedding                 |
| Colombia      | Interconexión Eléctrica S.A. | Reconfiguration at two substations to raise import capacity into Bogotá               | Import capacity increased by 7% without additional infrastructure, mitigating transmission project delays |
| Netherlands   | TenneT                       | GridOptions decision- support tool using AI-based remedial actions                    | Estimated 10-20% congestion reduction, with day-ahead plans generated in minutes                          |

Notes: ERCOT = Electric Reliability Council of Texas; MISO = Midcontinent Independent System Operator.

## Real-time remedial action

Real-time remedial  action  allows  operators  to  comply  with  operational  security criteria without holding large headroom in reserve for every contingency. A preapproved automatic action, such as tripping a specific line or adjusting a setpoint, executes  within  milliseconds  once  a  defined  trigger  condition  is  detected. Traditionally, this kind of rapid predefined response was reserved for rare, highimpact contingencies; contingencies were instead typically handled preventively, by holding headroom in reserve. Greater data availability and computing power now  make  it  possible  to  address  likely  contingencies  in  real  time,  either correctively after the event,  or preventively  through  continuous  risk-based assessment.

## Real-time remedial action deployment snapshot

| Country            | Operator                           | Deployment example                                                                              | Reported outcome                                                                                                |
|--------------------|------------------------------------|-------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|
| China              | SGCC                               | Deep reinforcement learning for fast remedial control                                           | Reported decision times below 30 ms for resolution of violations in trials and around 4% average loss reduction |
| Australia          | United Energy                      | Automated fault location, isolation and service restoration                                     | Tenfold return on investment over five years and average fault fix time reduced by 30 minutes                   |
| France             | RTE                                | Model-predictive control for zonal congestion management, using battery storage and curtailment | Provides rapid response to renewable surges and helps prevent local collapses                                   |
| Multiple countries | Several locations in South America | Dynamic congestion management using predictive AI and fast-responding assets                    | More than 3 GW of grid assets under management                                                                  |

Notes: ms = millisecond; GW = gigawatt; RTE = Réseau de Transport d'Électricité; SGCC = State Grid Corporation of China.

## Multiplying benefits by combining solutions

Combining  GETs  can  multiply  their  benefits  when  each  addresses  a  different constraint on the same network. The benefits of advanced technologies are greatest when they are deployed in co-ordination. Some gains overlap, where technologies draw on the same underlying headroom, while others compound, since capacity and stability are mutually dependent: extra headroom is only useful if voltage, protection, dynamic  stability  and  restoration  risk  remain  within  secure  limits,  so  line  ratings, power-flow devices, topology actions and automation need to be assessed together.

## Benefits resulting from combining solutions on the network

| Country        | Operator             | Deployment example                                                                                                                                                              | Reported outcome                                                                                                                                                              |
|----------------|----------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Slovenia       | ELES                 | DLR + DTR System-wide deployment of the platform dynamically rating 38 overhead transmission lines and 10 substation power transformers simultaneously                          | Unlocked a 15% to 20% median transmission capacity uplift across monitored corridors and resolved approximately 500 N-1 thermal overload situations annually                  |
| United Kingdom | National Grid        | APFC + DLR Co-ordinated deployment pairing modular series compensators across northern substations with non-contact DLR sensors on the Penwortham- Kirkby transmission corridor | Unlocked over 2 GW of boundary transfer capacity and delivered an estimated GBP 390 million in constraint cost savings and deferred capital expenditure                       |
| United States  | Southwest Power Pool | DLR + APFC + TO Modelling combining DLR, modular series power-flow controllers and TO switching software across Kansas and Oklahoma                                             | Doubled available interconnection headroom by adding 3.7 GW of renewable capacity, saving USD 175 million annually in regional production costs with a 6-month payback period |

Notes: APFC = advanced power-flow control; DLR = dynamic line rating; DTR = dynamic transformer rating; GW = gigawatt. Examples are illustrative and show how combined deployment can address different constraints on the same network.

## Unlocking capacity safely means assessing the whole network, not one constraint at a time

For every GET discussed in this chapter, revealing or creating headroom is not the  same  as  being  able  to  use  it.  How  much  can  be  credited  in  planning, operations  or  markets  depends  on  the  operational  security  layer  discussed  in Chapter 1: validated safeguards, operator trust and integration into control-room processes. GETs can also shift constraints rather than remove them: dynamic rating  can  move  a  bottleneck  from  a  line  to  a  transformer,  while  topology optimisation may require updated protection settings and switching procedures. Capacity  unlocking  therefore  needs  to  be  assessed  against  the  network's  full operating limits, not only against local constraints. This is where AI can become most valuable for GET deployment: identifying when a technology creates usable headroom, or when it simply moves the constraint elsewhere.

Stability limits also need to be considered as grid capacity is unlocked. Higher utilisation  is  only  useful if  the  system  can still  withstand  disturbances, maintain voltage and frequency, and recover securely after faults. Wide-area monitoring, drawing on PMUs and other high-speed measurements, gives operators visibility of how the system behaves dynamically, not just how loaded it is. Converting that visibility  into  secure  headroom  depends  on  assets  that  can  actively  support stability,  including  devices  that  provide  rapid  voltage  support  and  oscillation damping. Increasingly, it will also depend on converter-connected resources such as  batteries,  wind  and  solar  operating  in  grid-forming  mode,  contributing  the voltage-  and  frequency-setting  behaviour traditionally  provided  by  synchronous generators. As more of the system's capacity comes from converter-connected resources  rather  than  conventional  generation,  this  stability-support  function becomes  an  increasingly  necessary  complement  to  technologies  that  unlock thermal capacity or redirect flows.

GET priorities differ by network segment. In transmission, the main value is usually relieving  congestion,  increasing  transfer  capacity  and  reducing  curtailment,  by revealing dynamic headroom, redirecting flows or automating corrective actions. In  distribution,  the  priority  is  often  to  connect  more  demand  and  host  more distributed  resources while maintaining voltage quality, protection co-ordination and reliability. The underlying functions are therefore similar, but the operational problems, data requirements and relevant technologies differ by network level and local  constraint.  Deployment  also  varies  considerably  even  among  technically mature GETs. Chapter 3 examines why this gap between proven capability and actual deployment persists, and what would close it.

## Deployment stage of selected grid-enhancing technologies by surveyed network operators, 2026

<!-- image -->

IEA. CC BY 4.0.

Source: IEA survey conducted for this report (2026), based on 25 network operator responses: 11 transmission operators and 14 distribution operators. Given the small sample size, these results should be read as indicative of broad patterns rather than as statistically representative.

## Replication challenge

The survey results show that technical maturity does not automatically translate into  widespread  deployment.  Although  many  of  the  underlying  engineering principles  are  broadly  common  across  countries,  deployment  remains  highly uneven. This suggests that successful replication depends not only on technology performance but also on local conditions and the institutional environment. At the same time, each technology has physical preconditions that decide whether it is suitable for a particular site, and these are not barriers that policy can remove.

DLR,  which  estimates  how  much  power  a  line  can  safely  carry  under  actual weather and operating conditions, illustrates the point. Because a circuit's capacity is determined by its most restrictive element, DLR creates value only where the conductor is the main constraint and cannot address limitations elsewhere in the circuit,  such  as  substation  equipment  or  stability  limit.  Corridors  with  limited variation in wind speed and direction may offer little additional headroom, while under less favourable conditions the dynamic rating can temporarily fall below the static limit it replaces.

DTR applies the same principle to transformers, using their thermal behaviour to determine when short-term loading can safely exceed a static rating. Transformers have enough thermal mass that their temperature lags the current flowing through them, and that lag can allow a short peak to be carried before the transform cools again. The load profile therefore has to be cyclical for the method to work, as under a daytime solar profile. A flat load at full capacity leaves no opportunity for cooling.

Advanced power-flow control redirects electricity away from constrained lines and towards parts of the network with spare capacity. It therefore needs somewhere to send the power: a parallel path with enough headroom to absorb the redirected flow. On a radial line there is no alternative route, and where the parallel circuits are themselves near their limits, the diverted flow simply creates a new overload.

Topology  optimisation  changes  the  electrical  configuration  of  the  network  by opening and closing breakers to route flows more efficiently. It depends on the same meshed structure and adds a further demand: network model accuracy. The model has to represent what happens inside substations, rather than treat each substation  as  a  single  point.  Topology  optimisation  also  requires  live  breaker status and remotely operable switchgear, since a reconfiguration identified in the control room is of little use if it cannot be executed from there.

The transferable lesson for replication is therefore not the headline figure but the conditions that produced it. Operators first need to establish whether the site suits the core  function  the  technology  is  meant  to  perform:  revealing  dynamic headroom, redirecting flows, automating corrective actions or supporting stability. They  then  need  to  test  whether  that  technical  fit  translates  into  usable  value: whether congestion economics justify the investment, whether data and forecasting  are  good  enough,  whether  protection  and  control  procedures  can accommodate the change, and whether the regulatory framework lets the operator capture the benefit. Chapter 3 examines the conditions that enable this kind of replication: regulatory frameworks, data foundations, skills and organisation, and trust and security.

## AI-enhanced solutions

AI not only adds a new set of applications to the digital grid toolkit; it also helps make monitoring and control  systems  and GETs easier to  target,  operate  and scale. AI's main functions are to forecast, detect, diagnose, screen and prioritise, simulate and optimise. Applied to monitoring and control systems, these functions improve  forecasting,  data  validation,  anomaly  detection  and  asset  analytics. Applied to GETs, they help identify where latent capacity exists, forecast when it can be used, screen whether that headroom remains secure under contingencies, and rank feasible remedial actions.

AI  in  the  power  sector  spans  a  spectrum  from  rules-based  systems  through machine learning to generative and, recently, agentic AI capable of planning and acting across several steps with limited prompting. Network operators have used AI for two decades. What has changed is the scale and diversity of what models can process. New architectures can handle larger operational, asset, weather, imagery and customer data streams; GPUs and cloud computing have sharply cut the cost of training and inference; and utilities now hold more digital information

than in previous technology cycles. This is opening more of the grid to AI, but not all  applications  raise  the  same  operational  risk. As  AI moves from forecasting, detection  and  workflow  support  towards  automated  control,  the  validation, explainability, cybersecurity, fallback rules and accountability requirements become more stringent.

## Functional roles of AI in network planning and operations

<!-- image -->

Note: These functional categories do not necessarily reflect a hierarchy in maturity of applications nor the governance requirements.

## AI already works for planning, maintenance and forecasting, and is fast becoming a default productivity tool

Lower-risk  AI  applications,  such  as  forecasting,  maintenance,  inspection  and planning tools, are scaling first because they improve decisions and workflows without directly controlling the power system. Forecasting is a partial exception, since it already feeds automated market and operational processes with limited human  intervention.  These  applications  have  advanced  furthest  where  three conditions coincide: enough historical or operational data are available to train and validate models; errors (a missed inspection cycle, a forecast error) are visible and recoverable; and the output can be checked by planners, engineers or operators before it affects the system. Visual intelligence illustrates this pattern. Utilities use computer vision and deep-learning models to process drone, satellite, LIDAR and inspection imagery, helping identify vegetation encroachment, ice sleeves, asset wear, corrosion, fatigue and storm damage more quickly, and in some cases more precisely, than manual review.

Beyond network-specific applications, generative AI is also becoming a default productivity tool across utilities, as in most sectors, supporting drafting, coding, data analysis and internal knowledge management. These uses are not specific to grid operations, but they can accelerate the analytical and organisational work that surrounds them.

## Early deployment of AI applications across selected network operators

| Country                   | Operator                                                           | Deployment example                                                                        | Reported outcome   |
|---------------------------|--------------------------------------------------------------------|-------------------------------------------------------------------------------------------|--------------------|
| RTE                       | Contingency screening                                              | Around 20x faster than manual security assessment                                         | France             |
| Utilities                 | AI data platform to clean legacy grid data and create dynamic maps | Around 80% faster grid planning where legacy data gaps existed                            | India              |
| China Southern Power Grid | Visual intelligence for transmission line inspection               | Line length nearly doubled over a decade while inspection staff grew from around 60 to 80 | China              |
| NESO                      | Solar forecasting                                                  | Estimated GBP 30 million a year in reserve cost savings                                   | United Kingdom     |
| CAISO                     | Outage processing                                                  | Cut processing time from several hours to a few minutes                                   | United States      |
| PJM                       | studies                                                            | Interconnection and planning First workflow 2026, aimed studies                           | United States      |
| Southwest Power Pool      | Interconnection                                                    | studies Targets 80% moving to                                                             | United States      |

Notes: CAISO = California Independent System Operator; NESO = National Energy System Operator; RTE = Réseau de Transport d'Électricité.

## Real-time controls are AI's frontier, constrained by trust and auditability rather than accuracy

The  adoption  of  AI  is  advancing  unevenly  and  the  reason  is  not  model performance. In lower-risk applications, AI is already trusted because it forecasts, detects, diagnoses or prioritises information for decisions still made by planners and  operators.  Safety-critical  AI,  closer  to  real-time  control,  remains  far  more tentative. Here, accuracy is necessary but not sufficient: models also need to be explainable,  auditable,  secure  against  manipulation,  bounded  by  deterministic fallback rules and embedded in clear chains of accountability before operators can rely on them for decisions with immediate system consequences.

## Adoption of selected AI applications in electricity networks across operational timeframes and AI functional roles, 2026

IEA. CC BY 4.0.

<!-- image -->

Notes: DERMS = distributed energy resource management system. Adoption today is derived from the IEA survey conducted for this report (2026). The adoption score reflects a weighted sum of the maturity stage reported by surveyed network operators for each technology: routine full deployment (3), operational trial (2), or pilot (1).

## Overview of selected AI applications

| Technology                       | Primary function                                                            | Maturity (TRL) and deployment status                                                                                                                     | Typical benefit                                              |
|----------------------------------|-----------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------|
| Lower-risk AI applications       | Improve maintenance, inspection and forecasting, planning workflow          | TRL 7-9 Most mature category of AI use; scaling fastest in production where data quality is adequate and skilled workforce is available                  | Better decisions, faster studies and lower operational costs |
| Safety- critical AI applications | Support contingency screening, remedial actions and control- room decisions | TRL 3-6 Emerging in pilot/decision- support stage; full scaling requires robust explainability, deterministic fallback rules and verification frameworks | High potential value, higher governance burden               |

Notes: AI = artificial intelligence; TRL = technology readiness level.

## Operational security

The clearest opportunity, and the clearest test, sits in the operational security layer introduced  in  Chapter 1's  three-layer  framework.  This  is  where  the  long-term potential  is  the  greatest,  because  it  is  where  the  sector  could  move  from deterministic,  worst-case  margins  towards  more  risk-based  and  probabilistic decisions about how grid assets can be used safely. AI can support this shift by synthesising  large  volumes  of  probabilistic  information,  flagging  risk-relevant conditions and ranking feasible remedial actions for operators but the operator retains authority and accountability throughout. Widespread deployment at this level will therefore depend on stronger data, validation, governance and trust. In the near term, AI is more likely to augment engineering judgement than replace it.

## Emerging control-room and planning applications

Emerging  applications  sit  at  the  frontier  between  planning  and  control-room operation. In the control room, AI can help screen contingencies, prioritise alarms, identifying topology actions and translate simulations into clearer recommendations in the control room. In planning, it can accelerate power-flow studies, scenario generation and connection assessments. None of this removes the need for engineering judgement; the near-term role is to help operators and planners examine more options, more quickly, and focus human attention on the decisions that matter most.

Market-related  applications  are  emerging  too,  including  price  forecasting  and anomaly  detection  in  bidding  and  dispatch,  although  public  evidence  remains limited.  Disruption-preparedness  tools  follow  the  same  lower-risk  pattern:  by combining weather, asset, terrain and customer data, they help operators preposition  crews  and  plan  outage  response  more  quickly,  without  taking  direct control-room decisions. This makes them well suited to today's evidence and trust

constraints, and a possible template for higher-consequence resilience applications once validation improves.

For policy makers, the practical implication is staged adoption: decision-support tools can scale first, while automated switching or self-learning operation require validated limits, cybersecurity assurance and clear accountability before they can be  trusted  in  safety-critical  environments,  requirements  that  are  feeding  the emerging field of trustworthy AI.

## AI moving toward system-critical grid functions

| Country       | Operator                 | Application                                                                                                                  | Reported outcome                                                                                                                        |
|---------------|--------------------------|------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| China         | State Grid               | Guangming power model: Multi- modal model across planning, operations, asset management and customer service (see China box) | Overload risk analysis in Fujian reduced from around 20 working days to five; transformer diagnostics drawing on 154 measurement points |
| Netherlands   | TenneT                   | Situational awareness and operator decision support, including a topology optimisation workstream                            | Significant gains expected; no public performance figures available yet                                                                 |
| Australia     | AEMO and other operators | Operations technology and control-room capability roadmaps                                                                   | Roadmap towards integrated operational technology platforms and advanced situational awareness                                          |
| United States | ERCOT                    | Energy price anomaly detection                                                                                               | Pilot stage; no public figures available yet                                                                                            |

Notes: AEMO = Australian Energy Market Operator; ERCOT = Electric Reliability Council of Texas.

## Deployment stage of selected AI applications by surveyed network operators, 2026

<!-- image -->

IEA. CC BY 4.0.

Source: IEA survey conducted for this report (2026), based on 25 network operator responses: 11 transmission operators and 14 distribution operators. Given the small sample size, these results should be read as indicative of broad patterns rather than as statistically representative.

## Governance and network readiness

AI  also  introduces  risks  that  governance  needs  to  address  directly  before applications  move  deeper  into  grid  operations. These  risks  differ  by  use  case. Consumer-facing  automation  raises  concerns  around  bias,  discrimination  and poorly automated decisions. Utility-level deployment raises cybersecurity, safety and accountability risks. Market-facing tools can create risks around algorithmic collusion or distorted competition. At system level, AI also has indirect effects on grids due to rising data-centre electricity demand and environmental pressures. Frameworks such as the EU AI Act, which sets obligations where AI is classified as a "safety  component", and guidance from regulators such as Ofgem in the United Kingdom point to the same conclusion: governance requirements rise as AI moves closer to safety-critical grid functions.

In both transmission and distribution, scaling depends less on the AI model than on  whether  the  network  is  observable,  data  are  reliable  and  outputs  can  be integrated into operational systems. A model can only forecast, detect, optimise or prioritise conditions that the operator can observe and act on. In distribution, this makes feeder visibility, data granularity, controllable assets and integration with DMS, ADMS and DERMS platforms especially important.

## AI priorities according to network segment

| Segment      | Priority applications                                                                                                                                                                                                                                             |
|--------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Transmission | Renewables and demand forecasting, dynamic-rating forecasts, contingency screening and dynamic security assessment, topology recommendations, congestion management, year-ahead grid planning including interconnection studies and control-room decision support |
| Distribution | Local forecasting, asset inspection, outage management, voltage control, hosting-capacity analysis and distributed energy resource co-ordination through DMS, ADMS, DERMS, FLISR, dynamic operating envelopes and smart-meter analytics                           |

The pace of adoption depends on the enabling conditions around it: regulatory frameworks,  data  foundations,  skills  and  organisational  readiness,  and  trust, cybersecurity and interoperability. These conditions apply to the digital grid toolkit as a whole, but AI faces them in a sharper form. Models depend on data quality and continuity in ways static hardware and software do not, their outputs can be harder to explain and audit, and the resulting questions of accountability are more demanding when recommendations begin to affect operational decisions.

This operational caution should not obscure the scale of innovation underway. Grid-related AI patenting grew by more than 500% in the five years to 2022 and is now the most active area of patenting among enabling digital technologies, led by the  United States  and  China.  The  research  and  investment  momentum  is

therefore  already  substantial,  even  while  deployment  in  safety-critical  grid functions remains more cautious.

## The growing impact of AI on grid innovation

<!-- image -->

IEA. CC BY 4.0.

Note: IPF = International patent families; AI = Artificial Intelligence; EV = Electric vehicle

Sources: IEA and European Patent Office (2024), Patents for Enhanced Electricity Grids; updated figures from the European Patent Office (2026)

## A more ambitious generation of AI agentic systems and foundation models is emerging but not yet operational

Most existing AI applications in grids are narrow models built for a specific role, such  as  forecasting  demand  or  detecting  equipment  faults  from  imagery.  Two more ambitious directions point beyond this. Agentic AI (see box) moves from advising on a single task towards pursuing a goal across several tools and steps, observing conditions, co-ordinating systems and taking contextual decisions with limited prompting, still under human oversight. Grid foundation models (see box) move from one model per task towards a general-purpose model pre-trained on broad grid data and adapted to many downstream uses. Both remain at proof-ofconcept or pilot stage. Neither removes the trust and auditability gate described above; they raise the stakes, because a system able to act across several tasks needs validation, fallback rules and operator override safeguards across a wider operational surface.

## Emerging AI solutions (research or pilot stage)

| Solution                    | Problem it tries to solve                                                                                                                                                                                                                                                                                                         | Promise and challenges                                                                                                                                                                                                                                                                                                                                                                                       |
|-----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| AI decision- support agents | The control room receives large volumes of alarms, forecasts and constraint warning, but the choice of remedial action depends on operator judgement. As networks become more dynamic, the number of switching, redispatch and setpoint combinations can become too large to assess manually in the time available.               | AI agents could screen many feasible actions and present ranked options for operator approval, helping reduce response times and make better use of existing assets. Their use in real-time operations remains constrained by the need for explainability, auditability and clear accountability, and robust safeguards against unsafe recommendations.                                                      |
| Grid foundation models      | Many AI tools for grids are still developed for one task at a time, such as forecasting, asset inspection, dynamic ratings or fault diagnosis. This can make deployment costly and slow, especially when models need to be rebuilt or retrained as network conditions, data sources or operating practices change.                | Foundation models could provide a common model base that is adapted to multiple grid tasks with limited fine-tuning, lowering development costs and spreading learning across applications. Their value will depend on access to high-quality and representative grid data, strong validation against physical constraints, cybersecurity protection and operator confidence in how results are produced.    |
| World models                | Contingency assessment and what-if analysis mostly rely on detailed physical simulators run case by case. Screening very large numbers of disturbances, operating points and remedial actions can be computationally demanding, limiting their use close to real time.                                                            | World models could learn how the grid responds over time and make scenario exploration much faster, supporting operational planning and decision support. The core challenge is that learned dynamics approximate system behaviour rather than guaranteeing physical consistency, so extensive testing, boundary checks and integration with trusted simulators would still be needed.                       |
| Neuro- symbolic AI          | Conventional machine-learning models can detect useful patterns in operational data but may not know why an answer follows or whether it respects grid rules. In critical operations, this creates a risk that recommendations appear accurate statistically but breach operating limits or are difficult for operators to trust. | Neuro-symbolic AI could combine pattern recognition with explicit grid rules, operating limits and physical constraints, making outputs easier to trace and keep within safe bounds. The approach is promising for trust and assurance, but integrating symbolic logic with deep learning at full network scale remains technically complex and still largely at research stage.                             |
| Federated learning          | Training stronger AI models often requires pooling data from several operators, but operational data is sensitive and may be restricted by cybersecurity, privacy, commercial or sovereignty concerns. As a result, each utility may have too little data to train robust models on uncommon but important events.                | Federated learning allows models to be trained across several organisations without centralising the underlying data, which could support shared learning while reducing data- sharing barriers. Its deployment still requires common data standards, strong governance, secure model exchange, careful treatment of bias across participants and agreement on how benefits and responsibilities are shared. |

Note: Examples are illustrative and mostly reflect research or early-stage demonstrations rather than widespread utility deployment. These solutions are complementary and hybrid designs are an active research area. World models and grid foundation models, for example, describe different axes and are not mutually exclusive: the first refers to what a model learns - an internal predictive representation of a system's dynamics, enabling counterfactual roll-out - while the second refers to how a model is trained, through broad self-supervised pre-training on grid data adapted to many downstream tasks. A grid foundation model can also be a world model. Physics coupling is a separate question: in both approaches dynamics are learned from data, whereas neuro-symbolic AI encodes physical constraints and operational grid rules.

## The potential for an agentic grid

Most AI in grids today advises or optimises within a single defined task. Agentic AI points to systems that pursue a goal across several tools and steps: observing their  environment,  adapting  to  changing  conditions,  co-ordinating  with  other systems  and  taking  contextual  decisions  with  little  prompting,  albeit  still  under human oversight.

Early examples are beginning to appear but remain at proof-of-concept or pilot stage: customer support agents, agents that help with equipment fault diagnosis by  combining  data  ingestion  with  specialised  analytical  tools  and  workflow automation, operator-support agents layered over advanced distribution management systems that gather data and brief the operator, and agents that synthesise risk information ahead of extreme weather.

The  promise  is  to  alleviate  cumbersome  tasks,  such  as  assembling  data  and juggling  tools,  so  that  operators  can  focus  on  judgement.  The  vision  can  be illustrated with an agent that detects a transformer anomaly, schedules a repair crew, reroutes power to limit customer impact and logs the event for review, with a human able to step in at any point.

For the operator, the role shifts from manual control towards strategic oversight: supervising  autonomous  systems  and  owning  governance,  compliance  and assurance. This could preserve expert knowledge as the workforce ages and free staff for higher-value work. But it demands new skills and continuous training, and sharpens questions of explainability, accountability and the power to override in safety-critical  moments.  In  a  profession  built  on  caution  and  clear  lines  of responsibility, such change may meet resistance and should be phased, auditable and supported by evidence before it is adopted more widely.

Sources: Framing draws on S. K. Simon and B. Soehren Jones (2026), 'The Agentic Grid: The Next Evolution of Energy Infrastructure', Climate and Energy, Vol. 42, Issue 10; examples from Eurelectric AI use-case catalogue.

## Grid foundation models: A future step up for AI applications

Most AI in power systems today is task-specific where a separate model is built and  maintained  for  each  application.  Foundation  models  adopt  the  opposite approach where a single large model is pre-trained on broad grid data (network topology, time series from SCADA and phasor measurement units, weather, and text such as logs and manuals) and then adapted to many tasks with relatively little extra data. Tasks could include forecasting, power-flow and contingency analysis, state  estimation,  predictive  maintenance  and  anomaly  detection,  congestion management and planning. Unlike the large language models that dominate public use,  a  grid  foundation  model  is  built  for  the  physics  and  numerical  data  of  the network rather than for text, and a central research challenge is to keep what it learns consistent with physical laws.

The appeal goes beyond faster computation. A single model trained once can transfer  knowledge  across  utilities,  lowering  the  cost  of  applying  AI  for  smaller operators who hold too little data to train a capable model of their own, in principle giving every utility a path to benefit from AI, not only those able to invest heavily upfront. The same underlying model can also support a wider range of tasks than the narrow, single-purpose tools this is replacing, from forecasting and situational awareness to security assessment and decision support.

The principle is promising but still largely pre-deployment. Progress depends on both data and modelling, and neither is solved. On data, foundation models need large,  high-quality,  interoperable  datasets  that  no  single  operator  holds;  so progress depends on the willingness to share data - directly or through synthetic data, data spaces and federated learning - and on the governance that makes this possible. On modelling, genuine open challenges remain specific to this domain: embedding physical laws and conservation constraints, handling networks whose topology varies from one system to another, quantifying uncertainty, and validating a model's outputs before it can be trusted in operations

Two initiatives illustrate the field. GridFM, hosted by LF Energy, is an open-source effort to build a shared foundation-model technology base, originated by IBM with Hydro-Québec and contributors including Argonne National Laboratory. In Europe, AI.grids, co-ordinated by CRESYM under the European Commission (DG ENER), aims  to  build  the  first  pan-European  AI  foundation  model  for  grid  operations, bringing together some  48 organisations,  including TSOs,  DSOs,  research organisations  and  industry  associations,  trained  on  European  data  and  run  on EuroHPC AI Factories and Energy Testing and Experimentation Facilities. Both confront  the  same  data-sharing  and  governance  questions  that  will  determine whether the technology reaches operation.

## AI: An opportunity for emerging market and developing economies to leapfrog

In  EMDEs,  AI  and  digital  tools  offer  the  opportunity  to  leapfrog  parts  of  the traditional grid development path, and indeed some utilities are already doing so. Rather than waiting to complete the capital-intensive rollout of metering, sensing and control that earlier grid development relied on, some operators are using AIbased  estimation  and  simulation,  drawing  on  satellite  and  drone  imagery, computer  vision  and  third-party  behind-the-meter  data  to  gain  partial  visibility where SCADA or metering coverage remains incomplete.

This does not mean AI can substitute for data quality: as set out earlier in the report, data quality remains a determining factor for how far AI can be pushed, in EMDEs as much as anywhere. What leapfrogging changes is the path to adequate data. Waiting for full metering rollout before acting would delay the benefits of digitalisation. EMDE utilities are therefore sequencing investment differently: they first use lower-cost proxy data sources to reach the data quality a specific limited application needs, and then direct scarce capital to the parts of the network where better data or control would create the most value. As the benefits become clearer, this can strengthen the case for further digital investment.

## Starting points and priorities for emerging markets and developing economies differ from advanced economies

Distribution system reliability and efficiency are lagging in EMDEs, so priority AI applications  are  directed  at  loss  reduction  (including  energy  theft),  predictive maintenance,  self-healing  and  service  quality.  These  applications  can  deliver visible benefits to consumers quickly, which matters for sustaining political and public support, and where utilities are vertically integrated, as they are in many EMDEs, the operator captures the gains directly, easing some of the incentive problems seen in unbundled systems.

## Regional AI development overview

| Region         | Status                                                             | Illustrative deployments                                                                                                                                                                                                                                                                                         | Main constraints                                                                           |
|----------------|--------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|
| Southeast Asia | Multi-speed: mostly pilots; Malaysia and Thailand advancing faster | Wide-area monitoring (EGAT, Thailand); centralised substation monitoring and automation (NGCP, Philippines); AI asset and climate-risk monitoring (AboitizPower, Philippines); third-party behind-the-meter data in place of mass smart metering; widespread solar forecasting (Philippines, Malaysia, Thailand) | CAPEX-biased regulation; fragmented data/AI rules; markets too small for bespoke solutions |

| India         | Large ambitions, sharp public- private divide                                 | Predictive maintenance and renewable forecasting led by private utilities (Tata Power, Adani); rapid smart-meter rollout                                                                                                                                                                 | Limited public- sector capability; cross-subsidised tariffs; smart- meter data underused   |
|---------------|-------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|
| Latin America | Piloted around renewables integration; some tools moving into operational use | AI-enabled transmission planning and real-time tools (ONS, Brazil); AI- enhanced fault detection and monitoring (Eletrobras, Brazil); proof of concept for AI forecasting and congestion prediction, and a transmission planning tool (CEN, Chile); regulator-led AI pilots (Costa Rica) | CAPEX-biased regulation; thin innovation ecosystems; data quality and observability        |

Notes: Examples are illustrative and not exhaustive. CEN = Coordinador Eléctrico Nacional; EGAT = Electricity Generating Authority of Thailand; NGCP = National Grid Corporation of the Philippines; ONS = Operador Nacional do Sistema Elétrico. Sources: IEA analysis based on public utility and regulator material (links), and discussions with regional stakeholders.

A  CAPEX  bias  in  regulation  is  a  recurring  feature  across  EMDE  regions.  Tariff frameworks  reward  new  physical  assets  more  clearly  than  software  and  data investment, echoing the regulatory gap identified across this report, leaving thin cost recovery  for  the  operational  tools  that  would  extract  more  value  from  existing networks.  In  Latin  America  this is compounded  by  relatively  thin  innovation ecosystems; and in Southeast Asia by fragmented national data, cyber and AI rules and by underfunded ageing grids. Regulatory sandboxes are controlled spaces where a utility can test a new tool or process outside standard rules before regulators decide whether to extend it more broadly (discussed further in Chapter 3). They are gaining interest  in  both  regions  as  a  way  to  give  risk-averse  utilities  room  to  experiment, though  few  regulators  yet  offer  them.  Chile's  national  operator,  CEN,  has  a partnership with an external AI developer for transmission planning, a rare example of a project moving from prototype towards planned operational use in 2027.

Progress is uneven, both between countries and within them. In Southeast Asia, Malaysia and Thailand are advancing faster than other emerging economies on the back of stronger digital infrastructure, and private utilities across the region often move ahead of state-owned ones, reading their networks through alternative data sources rather than waiting for full instrumentation. India shows the same pattern:  leading  private  utilities  such  as  Tata  Power  and  Adani  are  already applying AI in  operations,  while many  state  distribution  companies face  tighter capability and financial constraints, and progress varies widely from state to state.

A further pattern is the gap between collecting data and using it. India's smart-meter rollout  is  expanding  rapidly  under  the  national  Revamped  Distribution  Sector Scheme,  but  converting  these  data  into  operational  value  has  lagged  behind installation; even the more advanced utilities use less than a quarter of the data now available to them, a gap attributed mainly to a shortage of dedicated analytics teams and institutional capacity. This is not an EMDE-specific problem: similar underuse of smart-meter data has been reported in advanced-economy rollouts, suggesting a pattern of underinvestment in analytical and organisational capacity.

## Skills and financing hold adoption back

The opportunity in EMDEs is real, but realising it is more dependent on enabling conditions than in advanced economies. A decisive question is whether digital and AI solutions can be treated as investable grid assets earning a regulated return, rather than discretionary IT expenditure. The conditions that determine this are as set out in Chapter 3, but two weigh most heavily in EMDEs, and especially in stateowned public-sector utilities: skills and financing.

Skills are a major constraint in most EMDEs, though not universally - India's leading private  utilities  are  a  notable  exception  -  and  are  generally  more  acute  than  in advanced economies (as elaborated in Chapter 3). The energy sector already trails other sectors in digital talent: in the period 2018-2024 the share of workers in AIrelated roles in utilities, oil, gas and mining ran around 40% below sectors such as finance, technology and media, and the gap is wider still in EMDE utilities, especially state-owned ones, where pay and career structures make specialists hard to attract and retain.  This  deepens  dependence  on  vendors  and  reinforces  caution  about entrusting AI with core operations, strengthening the case for capacity-building to be embedded in projects from the outset and for pooling skills regionally.

Financing is  another  cross-cutting  constraint,  and  is  tightly  bound  up  with  how networks  are  regulated.  High  costs  of  capital,  tariff  structures  biased  towards CAPEX, and limited or slow cost recovery for software and data mean that even where a digital investment would pay for itself quickly in operational terms, utilities often cannot recover the cost from consumers fast enough to justify it upfront, particularly where public budgets are stretched.

## International co-operation to ease skills and financing constraints

International co-operation can ease skills constraints by pooling scarce capability and spreading proven approaches across utilities rather than leaving each to build capacity alone. The IEA and its Technology Collaboration Programmes, including ISGAN, already support cross-country knowledge exchange on grid digitalisation and AI, alongside platforms such as the Global Power System Transformation Consortium (G-PST) and Mission Innovation's work on power system digitalisation. Open-source initiatives like LF Energy's GridFM support pooling in a  different  way,  making  shared  tools  and  models  openly  available  rather  than requiring each utility to build its own capability from scratch.

International  co-operation  can  also  help  spread  learning.  Mission  Innovation's work on power system digitalisation and related smart-grid collaborations provides a model for pooling use cases, test environments, standards and lessons across countries, so that smaller utilities and emerging economies do not have to develop every tool, dataset or assurance process from scratch.

Blended or concessional finance can ease the financing constraint: grants, belowmarket-rate loans and guarantees can de-risk early digital and AI deployment and cover the higher up-front costs or longer payback periods that a purely commercial lender might not accept, particularly where tariff structures do not allow full or fast cost recovery.

Development finance and philanthropic programmes often address both constraints,  as  they  usually  attach  technical  assistance  to  a  financed  project, allowing proven approaches to cascade between utilities.

## China: Rapid, co-ordinated and sequenced AI deployment

China provides one of the clearest examples of large-scale AI deployment in electricity networks. National policy documents increasingly position AI as a strategic tool for power-system planning, operation and asset management, while major utilities have launched dedicated programmes to integrate AI across their business functions.

The first wave of deployment has focused on applications with immediate operational benefits  and  limited  implications  for  system  security.  China  Southern  Grid  reports extensive  use  of  AI-assisted  inspection  and  monitoring  tools,  including  computer vision  applications  for  transmission  assets  and  equipment  condition  assessment. Similarly,  State  Grid  Corporation  of  China  has  developed  the  Guangming  power model,  a  sector-specific  foundation  model  designed  to  support  planning,  grid operations, asset management, customer services and business processes.

According to publicly reported information from State Grid, the Guangming model has been applied across more than 600 use cases. Reported examples include reducing  overload-risk  assessment  times  in  Fujian  Province  from  around  20 working days to five days and supporting transformer diagnostics using more than 150 operational parameters.

These deployments confirm the pattern observed throughout this study. Utilities are scaling lower-risk applications first, including forecasting, inspection, diagnostics,  planning  support  and  workflow  automation.  These  applications generate operational benefits while helping utilities improve data quality, develop internal expertise and build confidence in AI systems.

More  operationally critical applications, such as congestion management, remedial-action support, dynamic operating limits and real-time decision support, are also being explored but remain subject to stronger requirements for validation, explainability, operator oversight and cybersecurity.

Sources: China's 15 th Five-Year Plan; High-Quality development of the 'AI Plus' strategy in the Energy Sector; State Grid Corporation of China; China Southern Power Grid; Guangming power model public information.

## Chapter 3. Estimating and unlocking the potential

This chapter first estimates the scale of that potential globally, then examines why technologies that are technically proven and based on broadly shared engineering principles  remain  unevenly  deployed.  Realising  the  potential  of  the  digital  grid toolkit depends  on  four enabling conditions: regulatory frameworks, data foundations,  skills  and  organisational  readiness,  and  trust,  accountability  and security. These conditions apply to the toolkit as a whole, but AI tests each of them most acutely. Where they are weak, they become barriers to deployment; where they are strengthened, they allow proven technologies to move from pilots and local successes to routine operational use.

## Estimating the potential of the digital grid toolkit

Individual deployments of the digital grid toolkit already show measured benefits at the level of a network corridor, substation, control area or utility, including higher transfer capacity, lower congestion costs, faster connection studies and improved reliability,  as  summarised  in  Chapter  1.  These  examples  demonstrate  that  the toolkit can unlock real system value when applied to a clearly identified constraint. They should not, however, be read as directly transferable benchmarks for global scaling.  The  estimate  in  this  section  is  therefore  not  derived  by  extrapolating reported project outcomes, but from an IEA assessment of where selected GETs could technically unlock additional capacity on existing networks.

## The digital grid toolkit can unlock substantial hosting capacity and expansion savings

IEA analysis estimates that GETs - dynamic ratings, topology optimisation and advanced power-flow controls - could unlock up to 330 GW of additional hosting capacity globally today for generation, storage and demand on existing network while maintaining secure operation. These capacity gains are equivalent to those that would otherwise require around USD 100 billion in grid expansion investment, but  could  be  delivered  at  a  fraction  of  that  cost.  The  avoided  or deferred  investment  could  instead  be  redirected  toward  modernising  ageing networks.

This  potential  is  highly  relevant  to  the  pressures  facing  policy  makers  today: mounting connection queues that delay new supply, demand and storage assets, and  rising  grid  infrastructure  costs  caused  by  project  delays,  supply-chain constraints and higher equipment prices. GETs do not remove the need for new grid  infrastructure,  but  they  can  help  use  existing  assets  more  efficiently  while slower buildout catches up.

AI adds to this potential, although its contribution is difficult to estimate separately because  it  is  closely  intertwined  with  the  digital  tools  it  enhances.  Sharper forecasting, faster screening and AI-assisted analytics can improve how GETs are targeted and operated: identifying dynamic-rating opportunities more accurately, locating available capacity faster and screening remedial actions more efficiently in operational timeframes. Some of these enhancements are already delivering benefits.  As  AI  capabilities  continue  to  improve,  they  may  raise  the  practical potential of GETs further, but this analysis does not quantify a separate AI uplift.

## Estimated grid hosting capacity that can be unlocked globally with grid-enhancing technologies, 2025

<!-- image -->

IEA. CC BY 4.0

Notes: Values represent indicative global hosting-capacity gains from deploying grid-enhancing technologies in existing networks at voltage levels 70 kV and above. The combined estimate is lower than the sum of individual technology estimates because multiple technologies may address the same network constraint. Estimates are based on regional network characteristics and technology-specific assumptions regarding capacity increases and deployment coverage. Results exclude system-specific constraints such as voltage limits, fault levels, substation capacity and local generationload characteristics, which require detailed network studies.

## Methodology and assumptions

The estimate presented here is derived from the IEA's Electricity 2026 assessment retaining  only  the  technologies  that  fall  within  this  report's  definition  of  GETs. Electricity 2026 found a combined global potential of 450-700 GW for a broader portfolio  of  technologies  and  network  upgrades,  including  GETs,  storage  as  a transmission asset (SATA), reconductoring and voltage uprating. The estimate

presented in this report is a subset of that broader assessment. Applying the same methodology and assumptions as Electricity  2026,  but restricting the  scope  to dynamic ratings, topology optimisation and advanced power-flow control, yields an estimated potential of 190-330 GW, of which the upper end (330 GW) is used as the headline figure throughout this report.

The ranges in Electricity 2026 reflect different assumptions regarding the capacity increase delivered by each technology and the share of the network on which it can be deployed with meaningful gains. This report uses the upper end of that range as its headline figure. The estimated hosting capacity is then converted into an  equivalent  length  of  new  transmission  line  avoided  and  priced  against representative unit construction costs.

The combined potential should not be interpreted as the sum of the individual technology potentials. Multiple GETs may address the same network constraint and their impacts can overlap. As a result, the combined capacity gain is lower than the arithmetic sum of standalone estimates.

The  underlying  model  estimates,  for  each  technology,  how  much  additional capacity could be unlocked across the network segments where it applies. It is based on:

-  high-voltage network characteristics as of 2025, covering networks of 70 kV and above,  including  network  length,  voltage  levels,  loading  levels  and  congestion indicators
-  technology-specific assumptions on achievable capacity increases and applicable network  coverage,  consistent  with the deployment  and  maturity  evidence discussed in Chapter 2
-  exclusion  of  system-specific  characteristics,  such  as  generation-load  patterns, detailed contingency constraints and local operating limits, which would require detailed, network-specific studies.

## Non-firm grid connections: Unlocking the flexibility layer

The IEA's Electricity 2026 report found that non-firm grid connection arrangements could  unlock  an additional  750-900 GW of  grid  capacity  globally,  beyond  the potential  unlocked  through  GETs  and  larger  physical  upgrades  (SATA,  voltage uprating and reconductoring). Together, these approaches could unlock 1 200 to 1 600 GW of hosting capacity, enough to connect a large share of the advancedstage generation, storage and demand projects currently waiting in grid connection queues.

A non-firm connection is an arrangement between a network operator and a grid user, such as a generator, storage facility or electricity consumer, that enables earlier or larger grid access on the condition that output or consumption can be limited when network constraints arise. Unlike GETs, which increase the amount of power the network can safely carry, non-firm connections increase the utilisation of available network capacity by managing how and when users access available capacity.

Because non-firm connections rely on market design, contractual arrangements and regulatory frameworks that vary considerably across jurisdictions, they are not analysed further in this report but in other IEA work.

Digitalisation  is  a  pre-condition  to  non-firm  connections,  as  grid  users  must  be responsive to signals reflecting the network conditions, but AI can strengthen the value of non-firm connections. More accurate forecasting of demand, renewable generation and network conditions allows operators to estimate available capacity more precisely and reduce unnecessary curtailment. AI-enabled hosting-capacity assessment, congestion forecasting and dynamic operating envelopes can also increase  confidence  that  additional  users  can  be  connected  while  maintaining secure operation.

In  the  three-layer  framework  introduced  in  Chapter  1,  GETs  assessed  in  this chapter operate mainly within the network asset layer by increasing the capacity that  the  network  can  safely  carry.  Non-firm  connections  increase  the  extent  to which that capacity can be shared across grid users over time and belong primarily to  the  flexibility  layer.  This  illustrates  an  important  feature  of  the  three-layer framework: gains in grid utilisation can be achieved by pursuing improvements in each  of  the  layers,  but  the  largest  gains  come  from  addressing  all  three  in symphony.

<!-- image -->

Technical  capability  runs  ahead  of  deployment:  only  a  fraction  of  the  toolkit's proven capacity, documented in Chapter 2, is used today. The central challenge is moving solutions already proven at individual sites into routine grid planning and operation everywhere else.

## Unlocking the potential of the digital grid toolkit rests on four critical enablers

The  barriers  to  scaling  the  digital  grid  toolkit  are  largely  structural  rather  than technical. Four themes emerge consistently across the evidence reviewed for this report, which determine whether the potential just estimated is actually captured: regulatory frameworks, data foundations, skills and organisational readiness, and trust,  accountability  and  security.  In  its  interim  report,  the  United  Kingdom's  AI Champion  for  clean  energy  reached  the  same  conclusion.  These  findings  are reinforced by the IEA survey conducted for this report, in which network operators most frequently identified skills and organisational readiness (64% of respondents), data foundations and trust-related issues (both 60%), and regulatory frameworks (56%) as major barriers to deployment.

## Enabler 1: Regulatory frameworks

Regulatory frameworks emerged as a recurring concern among surveyed network operators, with more than half identifying them as a significant barrier to wider deployment. The challenge is the difficulty of valuing and remunerating operational,  software  and  data-driven  solutions  within  frameworks  historically designed around physical asset investment.

Transmission  and  distribution networks  are natural monopolies,  and  their development is shaped in large part by the regulatory and policy framework within which they operate. Regulatory frameworks determine what operators invest in, how  they  recover  their  costs,  and  the  balance  between  better  use  of  existing assets  and  building  new  infrastructure.  Even  when  digital  solutions  create substantial system-wide value, they are unlikely to scale beyond demonstration projects unless that value can be recognised and rewarded within the regulatory model.

## Key regulatory frictions between how digital tools create value and how regulator frameworks recognise them

## 1  Capital expenditure bias

## 2  Mismatch between risk and reward

Regulated returns often attach more directly to physical assets, while digital and operational solutions may sit outside the spending categories that earn a return

## 3  Measurement gap

Many benefits are preventive: reliability metrics record failures that occurred, while congestion, outages or instability that were avoided may remain invisible

Operators bear deployment and performance risks, but capture only part of the system-wide benefit, weakening the incentive to act

## 4  Evidence-before-approval barrier

Approval rules may require proven benefits before a tool enters routine operation, yet that evidence can often only be built through staged, real-world deployment

IEA. CC BY 4.0.

Four  frictions  often  recur  between  how  digital  tools  create  value  and  how regulatory  frameworks  recognise  them.  These  frictions  are  especially  acute  in distribution. Many of the investments needed to modernise distribution networks, from  data  and  communications  technologies  through  to  the  automation  and co-ordination tools described in Chapter 2, are software-heavy, data-intensive or operational  in  nature.  If  these  are  treated  as  discretionary  IT  or  short-lived operating  costs  -  rather  than  being  eligible  for  capitalisation,  recognised  in network development plans and assessed as alternatives to physical reinforcement - DSOs will struggle to scale up the visibility and controllability they need for active distribution management.

This section sets out where the mismatch creates barriers, the mechanisms that can realign incentives, and the valuation and assessment practices on which many of  them  depend.  Approaches  differ  widely  across  systems,  and  the  examples below are illustrative of both advanced and emerging economies alike.

## Main regulatory framework models and their implications for the digital grid toolkit

| Regulatory framework model                                                                                                                                                                                                          | Incentive implications for the digital grid toolkit                                                                                                                                                                                                                                                             | Examples                                       |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------|
| Cost-of-service/cost-plus The operator recovers its actual costs and earns a rate of return on the expenses included in the regulated asset base. Other eligible costs are passed through to consumers but do not generate profits. | Weak incentives for efficient decision considering all existing alternatives Software and service costs are by default excluded from the regulated asset base. They can be passed through to consumers and recovered, but without a profit, so are less attractive than building new assets, even when cheaper. | Several US states, Croatia, Ukraine            |
| Price cap                                                                                                                                                                                                                           | Moderate in the period                                                                                                                                                                                                                                                                                          | Netherlands                                    |
| Revenue cap Maximum yearly revenues for each network operator are set for a period of several years ahead. Contrary to a price cap, revenue is in principle independent of volume delivered.                                        | Removes the volume disincentive of a price cap Decoupling revenue from throughput removes the disincentive to reduce volumes observed in a price cap.                                                                                                                                                           | France, Germany, Norway, Sweden, Great Britain |

## Frameworks built for capital investment hold back better use of existing assets

The remuneration scheme a regulator adopts strongly shapes whether operators favour building new assets or making better use of existing ones, alongside the scope  allowed  by  planning  and  approval  processes  and  the  operator's  own capability to optimise the network. The two most common schemes pull in different directions.

Under cost-of-service (or cost-plus) models, the operator typically earns a return only on the capital added to the regulated asset base (RAB). Other costs, including software  and  digital  services,  are  passed  through  to  consumers  but  earn  no margin. As a result, building new physical assets is often more rewarding to the network operator than a cheaper digital alternative.

Price- and revenue-cap schemes attempt to correct this. Under these schemes, the network operator keeps a share of cost savings made within a given regulatory period. This rewards the use of cost-efficient solutions. However, in absence of performance or output measures, improvements in service quality and innovation that benefit customers or the wider system rather than reducing the operator's own costs go unrewarded.

## CAPEX bias and the treatment of digital expenditure

A CAPEX bias can occur when CAPEX and operational expenditure (OPEX) are remunerated differently through the regulatory framework of network operators. In such frameworks, CAPEX is typically added to the RAB, on which the operator can  earn  a  profit  margin.  By  contrast,  OPEX  costs  are  often  recovered  in  the period in which they are incurred but earn no additional return. Where CAPEX and OPEX are remunerated differently, an operator that could lower total expenditure through  OPEX  solutions  may  still  find  the  physical  asset  build-out  the  more rewarding regulatory choice.

This bias is particularly relevant for digital tools. Indeed, digital tools such as cloud software,  AI  models  and  communication  platforms  are  more  often  treated  as OPEX, particularly when they are procured as a service, such as cloud computing, software subscriptions and access to AI models, rather than owned outright.

In addition, differences in asset lifetimes can also affect the choice of CAPEX- or OPEX-based  solutions,  even  in  absence  of  remuneration  treatment.  Digital equipment can become obsolete within four to six years as technology progresses, especially for frontier AI, whereas frameworks are calibrated to physical assets with  design  lives  of  several  decades,  such  as  50  to  80 years  for  high-voltage overhead lines and 40 to 60 years for transformers, as presented in Chapter 2. Long asset lifetime in the RAB ensures a long-term revenue stream to network operators, while shorter term solutions bear greater risk.

## Assessing traditional network solutions against all alternatives

As  a  safeguard  against  CAPEX  bias  in  network  investment  decisions,  several systems  embed  an  assessment  of  non-wire  options  before  new  physical infrastructure  is  approved.  The  emerging  regulatory  practice  is  to  mandate operators to conduct a cost-benefit analysis of non-wire solutions as an alternative to new build with incentives to support efficient infrastructure deployment.

Through  the  Distributed  Resource  Plan  and  Integrated  Distributed  Energy Resources proceedings, launched by the California Public Utilities Commission, the state requires utilities to assess and report on non-wire alternatives so that distributed energy resources can be competitively procured in place of upgrades. A number of US states use the National Standard Practice Manual (NSPM) to

apply cost-benefit methods consistently, with Colorado weighing non-wire options in distribution planning and Hawaii modelling avoided costs.

Great Britain applies a standardised cost-benefit analysis framework called the Network  Options  Assessment,  which  compares  forecast  capital  costs  against monetised benefits in future energy scenarios and identifies the combination of options delivering the most value to consumers. In the United States, FERC Order No. 1920  makes  the  comparison  itself mandatory,  requiring transmission providers  to  evaluate  dynamic  line  ratings  and  advanced  power-flow control  in their planning, and to explain how they do so.

## Obligations to consider non-wire solutions

Going beyond options assessments, some regulatory frameworks are starting to embed direct obligations to deploy mature non-wire solutions. For instance, in the United  States,  FERC  Order  No.  881  requires  deployment  of  ambient-adjusted ratings and corresponding hourly adjusted transmission capacities.

In Germany, the NOVA principle goes one step further, requiring network planners to  prioritise  optimisation  before  reinforcement  and  expansion.  This  obligation stems from a working assumption that optimisation  solutions  are  cheaper  and faster to deploy than grid reinforcement and expansion.

## Performance-based regulation and benefit-sharing can realign incentives

Addressing the CAPEX bias places digital and innovative solutions on a more equal  footing  with  conventional  network  reinforcement.  Neutral  cost  treatment alone  does  not,  however,  secure  an  efficient  choice.  The  operator  carries  the delivery risk of a contracted or digital solution, while much of the resulting value, whether deferred investment, lower bills or additional system flexibility, accrues to consumers  and  other  market  participants.  Regulators  have  therefore  layered complementary  instruments  onto  the  underlying  revenue  framework,  including output-based  performance  incentives  and  shared-savings  arrangements  that allow the operator to retain part of the value it delivers. The Netherlands offers one example: redispatch and congestion-management costs of the TSO TenneT are benchmarked against efficient allowances, so costs above the benchmark are not automatically passed through to tariffs. This exposes the TSO to part of the cost of  inefficient  congestion  management  and  incentivises  lower-cost  operational solutions.

The table below summarises how selected regulatory mechanisms influence grid operator behaviours towards innovation, enabling better use of existing assets.

## Selected regulatory mechanisms and their implications for the digital grid toolkit

Note: A regulatory framework can combine more than one mechanism to achieve its goals.

| Regulatory mechanism                                                                                                                                    | Incentive implications for the digital grid toolkit                                                                                                                                                                     | Examples                                      |
|---------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------|
| Benchmarking or yardstick regulation Allowed costs are set by reference to the performance of comparable operators rather than to the                   | Pulls the lagging utilities up towards peers Where peers deploying non-wire                                                                                                                                             | Germany, Netherlands, Norway                  |
| TOTEX (total expenditure) Capital and operating expenditure are treated as a single envelope, with a fixed share capitalised whichever way it is spent. | Strong on cost neutrality Spending on digital tools or operational expenditure is assessed on the same basis as capital, so all solutions compete on cost rather than on accounting category.                           | Italy, Germany, Norway, Sweden, Great Britain |
| Output or performance-based mechanisms Part of allowed revenue is tied to delivered outcomes (such as system performance) rather than to expenditure.   | Values benefits delivered Rewards what the solution delivers rather than what it costs. This requires careful calibration of the baseline and incentives of the mechanism.                                              | Hawaii, Great Britain                         |
| Benefit sharing The operator retains a share of the assessed net benefit delivered, such as avoided reinforcement, paid over a defined number of years. | Extends the reach of the incentive Digital solutions deliver value that does not always appear as the operator's own saving. Benefit sharing rewards it, but depends on a counterfactual the operator largely supplies. | Italy, Slovenia                               |

## Misalignment between risk and reward for network operators

In  unbundled  systems much of the system-wide value that digital tools create, such as reduced congestion, avoided renewables curtailment and lower balancing costs, accrues mainly to generators and consumers rather than to the operator that deploys the tools. Through simple cost-of-service or revenue-cap models, the operator may capture little of the value it creates, which leads to weak incentives to invest adequately.

This  issue  is  particularly  acute  for  digital  tools,  or  innovative  solutions  more generally. The operator funds the deployment upfront and carries the technology and performance risk, recovering the cost only through subsequent allowances, while a digital technology that substitutes for new build also forgoes the return the avoided  asset  would  have  earned.  The  investment  case  therefore  does  not provide the same financial incentives as the conventional alternative.

A misalignment between risk and reward can also occur due to inflexibilities in multi-year regulatory periods. Price and revenue caps are calibrated against the baseline outputs defined at the start  of  the  regulatory  period,  so  where a  new obligation  is  imposed  mid-period,  for  instance  a  mandated  smart-meter  rollout whose benefits  accrue  mainly  to  others,  the  allowance  does  not  automatically follow it, and the operator may carry the new cost until allowances are next reset, unless the framework provides a within-period mechanism.

AI tools add their own version of the problem. AI models need regular updating to counter drift, yet frameworks that fix operating budgets for several years at a time leave little room for that adaptation. Multi-year control periods give operators a stable, predictable basis to plan and invest, but often lack adjustment mechanisms within it.

## TOTEX mechanism

A  total  expenditure  (TOTEX)  approach  aims  to  overcome  the  CAPEX  bias  by treating  capital  and  operating  spend  as  a  single  envelope,  so  an  operator  can choose the digital or physical option on its merits and, in a price- or revenue-cap framework, keep a share of any efficiency gain.

Great Britain was among the first to adopt a full TOTEX scheme for electricity, under Ofgem's RIIO model (see box), and it remains the most developed example. The use of TOTEX regulation is not universal, however. In Europe, ACER notes that 17 of 28 countries surveyed still have no mechanism in revenue setting to remove or reduce CAPEX bias for distribution networks.

The  successful  implementation  of  TOTEX  is  not  straightforward.  Setting  the revenue allowance for several years ahead requires robust cost assessments for regulators, since they hold less information than the operators they assess. This is particularly challenging for digital tools and innovative solutions, as a TOTEX regulatory framework requires regulators to assess the potential efficiency gains from optimising across CAPEX and OPEX to set the revenue allowance.

Simpler measures also exist as an alternative to a full transition to TOTEX. A ringfenced digital cost item within the revenue cap can protect qualifying investments, such as the regulatory proposal for Spain's 2026-2030 period. OPEX capitalisation can place a defined share of operating or innovation costs into the asset base to earn a regulated return, as applied to research and pilot costs in Italy and the United Kingdom. Another option is explicit cost-recovery treatment for software, cloud services, licences, model maintenance, data cleansing and cybersecurity, so  that  digital  and  AI  tools  are  not  disadvantaged  simply  because  they  are procured  as  services  or  require  recurring  expenditure.  The  key  principle  is regulatory  neutrality  when  a  digital  or  operational  measure  delivers  the  same network output more efficiently than conventional reinforcement.

## Performance-based regulation

Performance-based, or output-based, regulation help address the risk and reward mismatch.  Under  these  mechanisms,  part  of  the  revenue  earned  by  network operators is tied to delivered outcomes rather than to expenditure. As a result, system benefits such as quality of service, reduced losses, customer satisfaction and innovation to accelerate electrification of end uses can be rewarded alongside cost control. Operators that meet their outputs for less than the attached rewards increase their return, which creates a direct reward for efficient and innovative choices.

## Ofgem's experience with the RIIO framework

RIIO, short for revenue = incentives + innovation + output incentives, combines a TOTEX approach with output-based incentives for reliability, customer satisfaction and network efficiency. It has been applied to the electricity transmission system (RIIO-ET) in Great Britain since 2013 and the electricity distribution system (RIIOED) since 2015.

During the first transmission period (RIIO-ET1, 2013-2021), transmission owners earned GBP 180 million in cumulative incentive payments. Total expenditure came in  below  the  adjusted  allowance  across  all  three  owners,  and  Ofgem  calculated returns on regulated equity at between 9.4% and 11.3%, against an allowed cost of equity of 6% to 7%.

During  the  first electricity distribution period  (RIIO-ED1,  2015-2023),  Ofgem reduced  distribution  operators'  proposed  spending  by  GBP 1.43 billion  through benchmarking of costs, and operators identified a further GBP 700 million in savings themselves,  including  through  the  deployment  of  smart  grids.  Service  quality improved  over  the  same  period:  customer  interruptions  fell  by  20%  and  their average duration of interruptions by 13%.

Across much of the first RIIO, operators consistently outperformed their targets and earned returns well above the baseline. This was not a flaw in TOTEX itself (letting operators keep genuine savings within a period is a deliberate feature of TOTEX, meant to reveal efficient costs), but the result of specific design choices,  allowances and  performance  targets  that,  in  hindsight,  proved  easier  to  outperform  than expected.

Ofgem responded for the second period by lowering the baseline return, setting more  ambitious  output  targets,  capping  total  returns  and  shortening  the  control period from eight years to five. Enhancements in RIIO ED2 (2023-2028) include a -wider range of rewards and penalties, and a mechanism protecting both consumers and operators against large deviations from the performance expected at the outset.

## Benefit-sharing mechanisms

Some countries incentivise cost savings from digital tools or innovative solutions through benefit-sharing mechanisms. Under price- and revenue-cap regulation an operator  can  retain  part  of  the  efficiency  savings  it  achieves  against  its  initial allowed  revenue  across  a  regulatory  period.  Benefit-sharing  mechanisms  go further, allowing network operators to retain a share of the net benefits of choosing a cheaper solution than a defined traditional solution counterfactual.

For instance, in Italy, realised investment outcomes are benchmarked against a reference conventional solution to test whether the same functional benefit could be delivered more efficiently. The TSO earns a premium for meeting its capacity targets, and a second premium for meeting them below the reference costs the regulator has set. Since 2020 this approach has delivered around ten capital-light projects, unlocking over 3 GW of cross-zonal capacity. One such project involving dynamic line rating and digital upgrades to defence systems raised cross-zonal capacity by 1 450 MW and earned Terna, the Italian TSO, a premium of around EUR 143 million against estimated system savings above EUR 1 billion.

Slovenia  has  recently  introduced  a  comparable  mechanism:  the  net  benefit  of choosing an advanced grid solution over the conventional one is split between consumers and the operator at a nationally set ratio, measured against the cost difference  between  the  two  options,  so  that  the  more  efficient  the  choice,  the greater the operator's reward.

Two design questions become decisive for any such scheme. The first is how the counterfactual  baseline  is  set,  since  the  reward  depends  entirely  on  what  the alternative is assumed to have cost. The second is how the sharing ratio is struck: a  larger  share  for  the  operator  strengthens  the  incentive  to  adopt  the  efficient solution but leaves a smaller, less immediately visible saving for consumers, so regulators  need  to  balance  driving  adoption  against  maximising  the  near-term consumer  benefit.  Incentives  of  this  kind  also  need  care  where  value  is  not immediate:  investment  made  ahead  of  demand,  or  for  resilience,  may  reduce measured utilisation in the short term, but can still lower long-run consumer costs and reliability risks by avoiding emergency reinforcement, curtailment or outage impacts.

## Robust valuation of benefits help build the regulatory case

Addressing  the  risk-reward  mismatch  discussed  above  requires  regulatory frameworks  that reward the outcomes  digital solutions deliver. Yet such mechanisms depend on the ability to quantify those outcomes. The challenge is that many of the applications of the digital grid toolkit remain only partially visible through existing regulatory metrics.

## Issues with existing metrics

Incentives need measurable outcomes, but the reliability indices most widely used on the grid do not fully capture the full value of digital tools. The applications whose benefits are captured by existing metrics are precisely the ones already scaling. Meanwhile, the applications with the largest system value are often the ones the measurement framework cannot see at all. Where the digital grid toolkit shortens or  prevents  an  interruption,  its  benefit  registers  directly  in  the  system  average interruption  duration  index  (SAIDI),  the  system  average  interruption  frequency index (SAIFI) or energy not served, giving the operator a clear, verifiable business case.

However, the metrics do not yet measure other benefits that the digital grid toolkit can actually deliver, such as curtailment avoided, congestion relieved before it ever causes an outage, or capacity utilisation improved without any interruption occurring at all.  None of this shows up in traditional reliability indices because nothing was interrupted, so operators struggle to build a credible business case and regulators struggle to verify one.

AI raises a further, more specific difficulty. Its behaviour can be probabilistic, in that identical inputs do not always produce identical outputs, and where models are retrained their performance shifts over time. This makes it harder to isolate the counterfactual - what would have happened without the tool - since the tool itself is not a fixed reference point the way a piece of conventional equipment is.

## Standardised metrics and credible baselines

Monitoring the benefit of better grid use means shifting from input metrics towards output indicators, judged against a credible counterfactual (a simulated reference case of conventional operation or investment) so that gains can be attributed to the  digital  toolkit  rather  than  to  other  factors.  ACER,  the  EU  Agency  for  the Cooperation of Energy Regulators, has proposed a small set of output indicators for transmission grids that compares available capacity, the cost of remedial action and  total  investment  cost  against  standardised  conventional  baselines.  The current emphasis is on agreeing what to measure and against which baseline to build the evidence that performance-based regulation will eventually require.

## Regulatory mechanisms can also support earlier-stage innovation

Effective regulatory frameworks need to support innovation across its full lifecycle. Incentive  mechanisms  can  encourage  deployment  once  value  is  proven,  but earlier-stage  technologies  can  also  face  funding,  regulatory  and  operational barriers that prevent them from progressing beyond pilots. Specific mechanisms in the regulatory frameworks can help bridge this gap.

## Innovation funding in regulatory frameworks

At  the  discovery  and  pilot  stages,  operators  whose  incentives  are  built  around controlling costs and maintaining reliability have weak incentives to carry the risk of  unproven  solutions.  Explicit  innovation  funding  helps  address  this  gap.  For instance, Ofgem's Network Innovation Allowance provides ring-fenced funding for small-scale  projects,  and  operators  can  also  compete  for  a  separate,  larger innovation fund, which de-risks innovation and supports a culture of experimentation  that  short-term  cost  pressure  would  otherwise  discourage. Combined with appropriate incentives to roll out efficient solutions in regulatory frameworks, innovation support is more likely to sustain innovation across its full cycle, from early risk-taking through to mature, rewarded deployment.

## Regulatory sandboxes and structured experimentation

Regulatory  sandboxes  can  help  unlock  the  deployment  of  digital  tools  where existing  rules  and  regulations  are  a  barrier.  Sandboxes  give  operators  a  safe space to test a tool, service or business model with real customers for a limited time, under temporary exemption from rules that might otherwise block it. This allows  operators  and  the  regulator  to  learn  before  any  permanent  regulatory change  occurs.  For  instance,  Ofgem's  Innovation  Link  supports  trials  of  new products, and Germany's SINTEG programme offered an experimentation clause to test new market designs. Sandboxes are also being formalised at the European level specifically for AI under the EU AI Act, requesting member states to set up at least one AI regulatory sandbox to support evidence-based regulatory learning.

Experience with sandboxes emphasises the need for careful design. Early results from programmes  such  as  SINTEG  were  judged  disappointing, and the Netherlands, an early mover, has since closed its sandbox programme. Sandbox design  features  include  who  administers  the  scheme,  which  derogations  are allowed, how operators apply and, crucially, how lessons are reported back. The recurring weakness is the latter. Feeding positive experimentation results into the standard framework can face barriers because responsibility for experimentation and implementation may sit across different parts of the regulator. This leads to promising trials failing to scale to the point where they would reach consumers.

Where performance or innovation incentives exist, they may be too weak or even pull in the wrong direction. In many jurisdictions, innovation costs are typically only passed through, with no reward attached to what they deliver, leaving the incentive signal far weaker than guaranteed returns on capital. More targeted instruments are emerging  to  close  that  gap.  Proposals  developed  for  German  transmission operators include an experimentation budget to compensate third parties for taking part in a trial, a regulatory innovation trial that tests changes to the rules themselves before they are written into law, and a pioneer bonus that lets several operators co-

fund one that runs an innovation on their behalf. A shared feature is that they can operate across operators, which opens the door to cross-border collaboration.

## Enabler 2: Data foundations

Data foundations were identified by 60% of surveyed operators as a major barrier to  scaling  digital  solutions.  This  reflects  a  common  challenge  across  both transmission and distribution systems: data are increasingly available, but often remain fragmented across platforms, incomplete, inconsistent or difficult to access in operational workflows.

Data are fundamental to making better use of the grid, and need to be gathered in the first place, be of high quality and be accessible to those who need them. This applies to the entire digital toolkit, but the constraint is particularly acute for AI,  the  most  data-hungry  of  these  tools.  Across  electricity  networks,  datasets remain uneven, fragmented and hard to share, and these gaps are worst at the distribution level, precisely where demand and distributed resources are growing fastest.

## Data quality and availability are a binding precondition and both are the weakest in distribution

Transmission  networks  are  generally  well  instrumented,  but  many  distribution operators still lack observability over large parts of their network (see Chapter 2). This observability gap is the greatest data obstacle to AI delivering value at the distribution level, where demand is growing fastest. Low-voltage grids are the least visible of all. Distributed resources such as rooftop solar, EVs and heat pumps often  behave  as  "black  boxes",  creating  blind  spots  during  disturbances  and weakening load forecasts, while actual consumption from large new loads such as data centres is not always known. More data are not the sole answer: small, physics-informed models are easier to understand and validate than large, generic AI models, and need less data to deliver improved visibility.

The biggest data gap, therefore, sits in distribution. What is needed is granular, feeder-level  visibility. Without  trusted  feeder,  transformer,  smart-meter  and distributed  energy  resource  data,  AI  cannot  support  hosting-capacity  analysis, flexible  connections,  voltage  management  or  local  congestion  management. Distribution-level data foundations need to be built as an operational asset. This means accurate, up-to-date network and asset data and models, from topology and meter readings to registers of distributed energy resources; secure interfaces with  aggregators  and  flexibility  providers;  and  clear  governance  covering  data ownership, access, quality and responsibility.

Operators  may  be  rich  in  data  but  poor  in  insights  as  data  quality  can  be insufficient. During a pilot project to evaluate AI-based forecasting, Chile's national system  operator  (CEN)  identified  data  quality  as  the  main  implementation challenge: approximately 30-50% of data incoming from renewable power plants required validation or correction before model training, extending project timelines and resource needs. Such upstream data quality problems are widespread in data science, where practitioners commonly spend around 80% of their time finding and  cleaning  data  rather  than  analysing  it,  a  figure  echoed  by  distribution operators  that  described  dedicating  teams  to  several  months  of  data  cleaning before a single project could begin.

Open data for third-party innovation is scarce: only around a tenth of the world's electricity is covered by open-data policies, limiting the data available to train and validate independent tools. New sensing and digital infrastructure can narrow this gap,  but  only  if  paired  with  the  governance  to  make  the  data  usable.  The United Kingdom's Data Sharing Infrastructure initiative is one example, providing the secure, standardised connections that allow data to be discovered and shared across the sector.

## Fragmentation and weak interoperability deny AI the system-wide view it needs

Even  where  data exist, they are dispersed across legacy systems and organisational silos, so operators hold large volumes of data yet struggle to align, link and standardise it. These silos persist even within a single vertically integrated utility,  with  reported  barriers  to  exchanging data between the transmission and distribution divisions of the same company. The TSO-DSO interface is a recurring weak point, and it matters more as new actors such as aggregators come to need access to distribution-connected assets.

The IEA  survey  conducted  for  this  report  shows  why  stronger  TSO-DSO  data sharing  is  becoming  urgent.  Among  surveyed  operators,  distribution  networks remain much less visible  and  controllable  than  transmission  networks:  60%  of DSOs report having no controllability over at least half of their networks, and lowvoltage grids are the least digitalised. Yet distributed energy resources such as EVs,  heat  pumps  and  flexible  demand  are  making  distribution  conditions increasingly  relevant  for  system-wide  operation.  TSOs  need  more  granular distribution data to forecast flows and manage security, while DSOs need better information  on  transmission  constraints  and  market  signals  to  manage  local flexibility and connections. Without common data models, interoperable platforms and  clear  governance  for  operational  data  exchange,  AI  tools  will  struggle  to provide the system-wide view needed to optimise the grid safely.

Some operators are beginning to overcome this fragmentation by consolidating data at scale. China's State Grid has built its Guangming model (see Chapter 2) on  a  unified  data  foundation  spanning  planning,  operation  and  maintenance, integrating large volumes of previously siloed data across its vast network - the kind of system-wide view that AI needs but most operators lack. Elsewhere, where no  single  operator  holds  enough  data,  the  route  is  federated  rather  than centralised. Shared environments such as the European AI.grids initiative pool heterogeneous  data,  from  time-series  measurements  and  network  topology  to market  signals,  weather  forecasts  and  operational  reports,  from  across  many operators to assemble a comparable foundation without consolidating it in one place. The challenge here is not only the number of operators involved, but the heterogeneity of their data.

Semantics and interoperability are greater constraints than the volume of data. Underlying  this  is  the  absence  of  common  data  models:  inconsistent  formats, protocols, labels and timestamps, often proprietary to individual vendors, make integration  costly  and  slow.  Utilities  struggle  to  reconcile  inconsistent  asset definitions and formats across departments and tools, which is more difficult to resolve than simply collecting more data. Efforts to develop common standards and interfaces are multiplying, although the critical industry need is less for heavier top-down standardisation  than for  practical,  open  and  interoperable  interfaces: machine-readable registries paired with documented, vendor-neutral application programming interfaces (APIs) that let operators combine and swap tools without being locked into one vendor. The TROLIE specification is one example: an open standard developed under Linux Foundation Energy for exchanging transmission line rating data. It was created to meet the United States' FERC Order No. 881, which requires transmission providers to use ambient-data ratings instead of static seasonal ratings. The legacy point-to-point approach proved unable to carry the required  data  volumes,  since  an  hourly  240-hour  forecast  for  every  line  would otherwise demand hundreds of SCADA points per circuit. Vendors are responding with  similar  'data  hubs'  and  orchestration  architectures  that  connect  existing systems  around  a  common  meta-model,  without  replacing  or  updating  legacy tools.

## Sharing data for AI means managing security, sovereignty and privacy, not avoiding them

Many AI  applications  need  timely,  granular  information  on  network  status,  yet access  is constrained by cybersecurity, commercial  and  national security considerations.  Operators  face  strict  obligations  on  the  security  of  operational technology,  which  can  directly  limit  the  data  sharing  that  real-time  AI  would require. In some jurisdictions, legal rules prevent operators from releasing data even when they are willing to. For consumer data, the trend is to consider the

consumer as the data owner and to require its consent for data to be used. Data sovereignty  requirements  and  privacy  rules  add  further  constraints  across borders,  and  these  are  especially  acute  in  distribution,  which  sits  closest  to consumers. The same considerations can also require systems to be kept onpremises rather than in the cloud, as under some critical-infrastructure security standards. This adds cost and can cap the size of models an operator is able to run. These are tensions to be managed, not ignored.

Trusted  environments  offer  a  way  to  keep  sharing  data  while  managing  these risks.  Anonymisation,  synthetic  data  and  federated  approaches,  which  train models without moving raw data, let an operator contribute without exposing itself to commercial or security risk. Such environments can also work with imperfect data while gradually improving their quality, turning data sharing from an all-ornothing  decision  into  a  graduated  one.  These  approaches  have  their  own limitations: synthetic data can fill gaps or protect sensitive information, but models trained on it may be misleading if the generated data do not reproduce the physical behaviour  of  real  networks.  Federated  learning  avoids  moving  raw  data,  but participants' datasets often differ in structure, quality, time resolution and network representation, making the shared model harder to train, validate and transfer. It also requires repeated exchanges  of model updates, adding operational complexity and cybersecurity requirements even when raw data are not shared.

## Shared infrastructure, benchmarks and governance can lower costs and spread learning

Power systems still lack standardised benchmarks against which AI tools can be objectively validated before deployment. As a result, each operator often has to re-validate new tools against its own legacy models, existing tools, historical cases and engineering judgement before they can be trusted. Real-world performance can diverge from vendor claims and pilot results, which points to a broader need for shared, collectively built performance  data  rather  than each  operator generating  its  own.  Sharing  failure  data,  too,  such  as  faults,  near-misses  and extreme-weather  and  cyber  events,  is  especially  valuable  for  training  robust models, yet such data are rare and seldom pooled, so collective learning suffers.

Governance frameworks that enable trusted sharing are emerging but are not yet standard,  although  they  are  beginning  to  shift  from  voluntary  codes  towards mandated  frameworks.  The  Common  European  Energy  Data  Space  and federated initiatives such as the European AI.grids effort point the way, as does the  United  Kingdom's  Data  Sharing  Infrastructure,  which  builds  the  common connections  that  allow  data  to  be  discovered  and  shared  across  operators. Underlying all of this is clarity on data ownership and access terms, without which sharing stalls.

Fragmentation across many operators raises the fixed cost of digital infrastructure and slows the spread of learning, making a strong case for shared platforms and cost-sharing. A  shared  testing framework,  built around  common  baseline scenarios  and  metrics  with  utilities  involved  from  the  outset,  could  let  this benchmarking happen collectively rather than operator by operator. The point is sharpest for grid foundation models (see box in Chapter 2): no single operator holds sufficient high-quality interoperable data to train them alone, which is why the leading initiatives are collaborative by design.

## Enabler 3: Skills and organisational readiness

Skills and organisational readiness were the most frequently cited barrier in the survey,  identified  by  64%  of  respondents.  While  many  of  the  technologies discussed  in  this  report  are  commercially  available,  deploying  them  at  scale requires  new  capabilities  that  combine  power-system  expertise,  data  science, software engineering and change management, skills that remain scarce across much of the sector.

## Staff who bridge power systems and data science are a scarce resource

Building the workforce is as decisive as the technology itself, as network operators face a chronic shortage of professionals who combine power system expertise with  data  science  skills.  Power  grids  already  employ  around  8.5 million people globally, a figure rising with record grid investment (USD 450 billion in 2025), and the availability of adequately trained personnel is becoming a limiting factor in both delivering infrastructure on time and integrating new technologies. The constraint is most acute for the rare professionals who combine power system expertise with data  science,  and  it  is  compounded  by  an  ageing  workforce:  the  IEA's  World Energy  Employment  report  finds  that,  globally  between  2015  and  2024,  the fastest-growing age groups in the grid workforce were the older age groups: the workforce aged 55 and over grew by nearly 50%, while the workforce aged under 55 only grew by 20%.

Network operators struggle to hire, held back by a lack of grid-specific technical skills and  a  limited  pool  of  qualified  applicants.  The  IEA's  2025  Industry Employment Survey found that over 40% of surveyed grid companies report "high" or  "very  high"  competition  for  skilled  staff,  regularly  losing  candidates  to  other employers. The most cited recruitment barriers are a lack of grid-specific technical skills (48%), too small an applicant pool (37%) and an inability to offer competitive salaries (28%), and half of respondents (51%) have already had to lower or adjust hiring requirements because of shortages. The problem is not only attracting data

scientists, but also finding people who understand the grid, too. Part of the difficulty is self-inflicted: utilities have been slower than other sectors to seek digital talent at all. IEA labour market analysis shows that digital roles represented only around 11% of utility job postings, well below finance (approaching 16%), and demand for the newest skills, in AI and machine learning, remains very low even where firms have  invested  in  digital  equipment.  Hiring  intensity  varies  sharply  between countries, suggesting the gap reflects strategy as much as scarcity.

## Barriers to hiring or retaining qualified AI and digital talent among grid operators, 2025

<!-- image -->

Source: IEA (2025), Industry Employment Survey.

## Training across field, control room and planning

AI and digital tools can scale only as fast as an organisation is ready to use them responsibly, which makes  workforce  readiness as much  a  constraint on deployment as data availability or regulation. The sector's needs span the whole workforce, not just specialist hires for digital tasks. Field crews need to install and maintain new equipment, control-room operators need to interpret and challenge AI outputs, and planners need to weigh options such as GETs that are not yet routine  in  interconnection  studies.  Some  operators  are  building  this  capability through dedicated training academies, university partnerships and "AI ambassador" schemes that spread practical AI literacy across operational teams rather than concentrating it in a single specialist unit. However, public-sector and smaller operators often lack the capacity to train at all, making targeted capabilitybuilding and pooled programmes especially important.

DSOs need a distinctive capability model. Compared with TSOs, they operate at far  greater  scale,  with  more  assets,  more  distributed  assets,  more  customer interfaces  and more  smart  meter  devices.  This raises the  need for  DSO  dataengineering  teams,  field  crews  trained  to  install  and  maintain  sensors  and communications and automated equipment, planners able to use hosting-capacity and  flexibility  tools,  control-room  staff  able  to  operate  advanced  distribution

management  system  (ADMS)  and  distributed  energy  resource  management system (DERMS) platforms, and cybersecurity specialists focused on operational technology across thousands or millions of devices.

Institutional capacity matters beyond utilities, too: regulators need to understand how these technologies create value in order to assess them with confidence. China offers a contrasting example of co-ordinated workforce development, with the  state,  utilities,  industry  and  academia  aligned  through  sector-specific  AI programmes,  university  partnerships  and  training  pipelines  that  link  business needs to deployment. This does not remove the need for validation, explainability and operator trust,  but  it  shows  how  skills  can  be  built  deliberately  across  the sector rather than left to individual utilities.

## Organisational processes must adapt to capture AI's full value

Even where regulation does not stand in the way, the organisational processes built around traditional grid planning and operation can default to conventional grid expansion, leaving GETs and AI tools underused or assessed too narrowly. The main challenge is not only to procure new tools, but to absorb them into the way planners and operators actually work.

Most AI uses in grids today still focus on automating existing tasks: improving a forecast, detecting an anomaly, identifying vegetation near a line or accelerating a connection study. Larger gains are possible when operators redesign processes around what AI can do. In connection queues, for example, AI can do more than speed up individual studies: it can screen applications, group projects that create similar constraints, fast-track low-impact connections and identify where flexible or  non-firm  offers  may  avoid  reinforcement.  In  asset  management,  predictive models  create  value  only  if  they  change  inspection  schedules,  spare-parts planning, crew allocation and replacement priorities. In vegetation management, image recognition matters most when it enables a shift from fixed-cycle cutting to risk-based  intervention.  Many  deployments  simply  substitute  AI  in  place  of conventional algorithms without rethinking the workflow, capturing only a fraction of the available value.

The redesign of business processes is a cultural shift, and operators are finding it has to be managed actively. Elia Group (Belgium and Germany), for example, established its AI centre of excellence in 2018, and has recently paired it with a central  "AI  enablement  and  governance"  function  tasked  with  building  staff capability  while  ensuring  compliance,  addressing  what  it  describes  as  the challenge  of  enabling  and  complying  at  the  same  time  through  a  risk-based approach  to  every  use  case.  Embedding  change  agents  or  "AI  ambassadors" within operational teams, as done in several European TSOs, allows trust in new

tools to be earned incrementally, spreading through peers who understand both the technology and the control room.

## Enabler 4: Trust, accountability and security

Trust, accountability and security concerns were identified by 60% of respondents, placing them alongside data foundations as one of the most significant barriers to deployment. These concerns become more acute as solutions move closer to operational decision making and real-time control, where explainability, governance and cybersecurity become prerequisites for adoption.

Realising  the  digital  grid  toolkit's  potential  for  system  efficiency,  resilience  and consumer outcomes, set out earlier in this report, is not unconditional. It depends on network operators being able to rely on, explain and defend the tools they adopt, with security that is designed in from the outset rather than retrofitted, as connectivity broadens the grid's attack surface.

AI  adds  further,  more  specific  conditions.  Because  its  outputs  are  harder  to interpret  and  audit  than  those  of  conventional  tools,  accountability  for  an  AIassisted decision, and protection for the consumers ultimately affected by it, must remain clear when something goes wrong. Ethical AI in grids is not only a matter of regulatory  compliance:  it  requires  judgement  about  whether  AI-assisted decisions  are  safe,  fair,  transparent,  robust  and  accountable,  including  who benefits from them and who bears the risks when they fail. Because its behaviour is  probabilistic  and  can  drift  over  time  in  a  way  physical  equipment  does  not, human oversight, validation and certification need to keep pace with the tool rather than  be  fixed  once  at  approval.  And  because  AI  is  increasingly  supplied  and hosted by vendors, and in some cases governments, outside an operator's own jurisdiction,  the  ability  to  maintain  genuine  control  over  the  tool  becomes  a prerequisite for its safe use - a concern that digitalisation raises too, but which AI sharpens further given how central it is becoming to critical decisions.

For safety-critical applications such as control-room decision support, the bar is higher as they may carry direct consequences for system reliability and safety. AI enhancements are the most difficult to validate from a security and accountability perspective  because  AI's  outputs  are  the  least  transparent.  Answers  to  these questions remain in their infancy, but are gaining increased attention: assurance, oversight, security design and sovereignty-conscious choices can help operators and regulators earn a place for AI in their toolbox.

## Explainability and accountability constrain AI use in critical operations

Investment in explainability, uncertainty quantification and audit trails is more likely to unlock wider adoption of AI for real-time applications than further gains in raw model performance alone. Operators have already adopted AI for tasks that do not bear directly on real-time control. According to the survey in the IEA's 2025 report Energy and AI, 54% of surveyed operators use AI for long-term planning and 70% for maintenance, but only 23% use it in real-time operations, reflecting a cautious culture that places system reliability and human safety above all else. The barrier is rarely the model's accuracy; it is trust and auditability - whether an operator can understand why a tool produced a given output (explainability) and verify that reasoning after the fact (auditability).

Accountability for AI-assisted decisions rests primarily with the human operators, utilities  and  regulators  overseeing  them. 11 Most  current  frameworks  require  a written, auditable justification for operational decisions that today's models cannot reliably produce on their own. The EU AI Act reinforces this by classifying grid monitoring  and  operation  as  "high  risk",  mandating  transparency,  technical documentation and rigorous risk management. To trace decisions back to their origin,  operators  increasingly  look  to  audit  trails  that  log  data  sources,  model versions, decision logic and human interventions. Jurisdictions are beginning to codify sector-specific rules, such as Ofgem's guidance on ethical AI use in the United Kingdom or China's "6541" framework that includes the electricity sector's first dedicated Power AI Ethics Guide.

The  concern  is  sharpened  by  how  AI  can  fail.  Large  language  models  can 'hallucinate', producing plausible-sounding but false outputs with no signal to the user that anything is wrong; more broadly, any model, including forecasting tools that are not language models, can produce a confidently wrong output outside the conditions it  was trained on. In the electricity system, where a single fault can cascade into further disturbances and reactions elsewhere, an initially small model error  can  compound  into  consequences  well  beyond  the  point  where  it  first occurred. Models may also disregard the physical laws operators must respect. This is why explainable and physics-informed models, whose outputs an engineer can check against the underlying assumptions (such as grid foundation models), are widely seen as the precondition for trusting AI in critical roles.

11 Responsibility can be shared with vendors or platform providers depending on the regulatory regime and how a failure occurred.

## Trust is built incrementally, through human oversight, validation and certification

In the near term, trust is preserved by keeping the human at the centre of decision chains, with AI augmenting rather than replacing operator judgement. The IEA survey  of  grid  operators  conducted  for  this  report  found  a  near-unanimous preference for keeping humans firmly in the loop, treating AI as decision support rather  than  an  autonomous  agent.  Where  operators  look  further  ahead,  they foresee the same workforce pressures discussed in this chapter's skills section, not  a  preference  for  automation  over  people:  as  demand  for  skilled  engineers grows  faster  than  utilities  can  hire,  some  operators  expect  more  autonomous agentic tools to become a necessary complement to a workforce that cannot scale as fast as the tasks in front of it, rather than a substitute for it. Frameworks that distinguish between degrees of human oversight - informing, supervising, or fully automating a decision - help here because they let regulators govern the function and the  level  of  autonomy  rather  than  prescribe  a  particular  technology,  as  in Ofgem's guidance on the ethical use of AI. This keeps the accountable human in place while the technology matures.

Beyond  oversight,  the  tools  for  assurance  are  largely  missing:  standardised safety-validation and certification frameworks for AI in critical operations barely exist, and their absence holds adoption back. Network operators are unlikely to assume  a  vendor-supplied  AI  component  is  safe  simply  because  it  was successfully  deployed  elsewhere;  often  they  are  constrained  to  selecting  from certified lists of suppliers and products co-ordinated at the national level or through network operator associations. Because AI can be probabilistic, as noted above, and its performance can shift as models are retrained, certification cannot be a one-off event in the way it can for a piece of conventional equipment; it needs to be  lifecycle-based,  with  version  tracking,  defined  rollback  procedures,  and reapproval triggered whenever a model changes materially. In practice, trust in any  new  tool  is  earned  incrementally:  operators  monitor  a  tool  closely  before relying on it, and relax oversight only once it has proven reliable.

Shared testing environments can accelerate trust and validation of AI models. EUfunded projects 12 are building networked Testing and Experimentation Facilities for energy and AI, offering a pre-deployment setting in which tools are validated against realistic conditions before they touch live systems; for emerging approaches, such as grid foundation models, common benchmarks and safe test beds of this kind will be essential to move them out of the laboratory (see box in Chapter 2). Certification and testing for AI specifically remains a young but fastgrowing field of attention across sectors, not only electricity; the staged approach

12 The EU is funding three projects in parallel: EnerTEF, AI-EFFECT and EnergyGuard.

already  described  above,  where  oversight  relaxes  only  as  a  tool  proves  itself, echoes how aviation and automotive safety certification build trust incrementally for autonomous and semi-autonomous systems. What is largely absent today is the  connective  layer  between  these  efforts:  shared  standards,  certification schemes and the means to carry a validated tool from one operator's test bed into another's control room, so that trust, once earned, can travel rather than being rebuilt operator by operator. Regulatory sandboxes, discussed in the regulatory frameworks  section  above,  can  play  a  role  here  too,  giving  operators  and regulators a structured space to test AI-enabled tools and work through the risk questions before wider deployment.

## Security becomes a core design requirement as AI enters operations

Greater  connectivity  and  software-defined  control  expand  the  attack  surface across  devices,  substations,  aggregators  and  platforms.  Millions  of  customer metering  assets,  such  as  EV  chargers,  solar  inverters,  batteries,  metering infrastructure and digital platforms, become potential entry points, and some of them are never fully patched: vendors may stop releasing firmware updates for equipment when the product is no longer sold, and utilities may lack the staff to patch myriads of ageing devices even where a fix exists. Software vulnerabilities can translate into physical consequences such as remote outages or equipment damage, and the convergence of information and operational technology exposes SCADA systems that were once isolated. The United Kingdom's National Risk Register rates a cyberattack on critical infrastructure as of moderate likelihood but potentially devastating consequence, up to loss of life.

The distribution edge makes this challenge sharper. EV chargers, smart inverters, behind-the-meter  batteries,  aggregators,  DERMS  platforms  and  smart  meters create new cyber interfaces close to consumers and outside traditional controlroom  boundaries.  Distribution  data  are  also  more  sensitive  because  they  can reveal consumer behaviour. Security and privacy governance therefore need to cover third-party platforms and smart meter devices, not only utility control centres, including the growing use of cloud-hosted AI models whose provider and data location may sit outside the operator's own jurisdiction, a point developed below.

Cybersecurity is increasingly becoming a core design requirement, rather than an add-on  applied  after  digital  systems  are  installed.  For  example,  Portuguese distribution operator E-REDES runs a dedicated cybersecurity training centre for its staff, alongside continuous vulnerability testing and a team monitoring its grids around the clock from an integrated supervision centre. P rotection is cheaper and more effective when it is built into systems from the start. This means checking who and what can access critical systems, separating the most sensitive control functions from less critical networks, protecting communication  links, and

embedding security requirements in procurement and supply-chain management so  that  vulnerabilities  are  reduced  before  equipment,  software  or  services  are deployed. Established standards such as NERC's Critical Infrastructure Protection requirements and the NIST framework are being adapted so that AI and digital tools  are  subject  to  protections  comparable  to  those  applied  to  physical  grid assets.

As  AI  is  embedded  into  system  operations,  the  integrity  and  robustness  of  AI models become more important. Adversarial attacks such as data poisoning deliberately corrupting the data a model learns from so that it later makes a wrong decision  when  triggered  -  exploit  weaknesses  that  conventional  cybersecurity does not fully address, and a model's failure modes can stay hidden until they matter  in  a  way  a  physical  asset's  typically  do  not.  Countermeasures  such  as adversarial training, deliberately exposing a model to manipulated inputs during development so it learns to resist them, are one response, drawing on wider work securing industrial control systems.

## Sovereignty and strategic dependence

Sovereignty  drives  domestic  development  of  AI  and  cloud-based  services  to mitigate  risk of dependency  on  foreign  suppliers  and  governments.  AI  is increasingly delivered as a cloud-based service controlled by a vendor, and in some cases a foreign government, sitting outside the operator's own jurisdiction. This creates a risk that a tool an operator has learned to validate and rely on can be withdrawn for reasons entirely outside its control. Switching to an alternative is rarely quick given how deeply an AI tool can become embedded in operational workflows once adopted, a form of vendor lock-in that compounds the underlying dependency. Where data also leave the operator's jurisdiction for processing or storage by that vendor, jurisdictional control adds a further layer to the risk, since the operator may have limited visibility or legal recourse over how those data are handled once they cross a border.

Operators  already  navigate  this  trade-off  in  practice,  not  only  in  theory.  Dataprotection  and  security  rules  can  limit  how  much  an  operator  relies  on  cloudhosted AI services, and by extension the size and sophistication of the model it can run, since the most capable models are typically cloud-based and impractical to run on an operator's own infrastructure. Keeping a model on-premises avoids the  jurisdictional  and  continuity  risks  described  above  but  is  markedly  more expensive and constrains which tools an operator can access, a reminder that sovereignty, security and capability are directly linked, not three separate choices made independently of one another.

AI, like other strategic technologies before it, can become a point of geopolitical leverage precisely because it is so widely relied upon. GPS (Global Positioning

System) offers a precedent: US military control of the system led other jurisdictions to  build  independent  alternatives,  including  the  EU's  Galileo  and  the  Russian Federation's GLONASS. The AI-specific version of this risk was demonstrated in June 2026, when a US export control directive forced a leading AI provider to suspend global access to two of its most advanced models for all foreign users with only hours' notice, reportedly the first such use of export controls against a commercially available AI service. Governments are responding accordingly. The EU's Tech Sovereignty Package and proposed Cloud and AI Development Act, both published in June 2026, aim to reduce dependence on third-country cloud and AI providers for critical infrastructure such as grids.

## Chapter 4. Policy recommendations

Grids have constrained the energy transition for over a decade, and building new physical  infrastructure  takes  longer  than  the  changes  occurring  around  it; anticipatory investment and improved planning help accelerate the buildout, but do not close the gap entirely. The digital grid toolkit, a family of solutions including grid-enhancing technologies (GETs), digitalisation and artificial intelligence (AI), gives  operators  an  additional,  faster-acting  level:  it  can  release  substantial additional capacity from existing networks securely, often in months rather than years and at a fraction of the cost of new build. Building more grid capacity remains necessary but it is not sufficient, and the toolkit is a complement to it, buying time and lowering cost while new infrastructure is built.

Capturing this opportunity means creating the conditions for these technologies to succeed at scale. A central finding of this report is that many solutions in the digital grid toolkit rely on engineering principles that are broadly common across power systems,  yet  deployment  remains  highly  uneven.  For  proven  and  emerging technologies alike, what holds them back is regulation that rewards building more over  improving  efficiency,  weak  data  foundations,  scarce  skills  and  weak organisational capacity, and, particularly in the case of AI, unresolved questions of trust, security and dependency.

Addressing these barriers requires co-operation across the sector's stakeholders, and policy makers and regulators play a significant role. The policies that matter most depend on local context: the prevailing market structure, the age and digital maturity of existing infrastructure, and the gap between advanced and emerging economies all shape what should be done first.

Notwithstanding local context, five priority areas of action can unlock the digital grid toolkit: reforming regulatory frameworks and incentives, building robust data foundations,  investing  in  skills  and  organisational  readiness,  building  trust, assurance and security, and strengthening international co-operation.

## Reform regulatory frameworks

Regulation  strongly  influences  whether  operators  make  better  use  of  existing networks or default to building additional capacity. Traditional frameworks governing grid  monopolies  were  calibrated  for  physical  infrastructure:  capital  expenditure enters the regulated asset base and earns a return, whereas digital tools are treated

as  operating  expenditure  without  returns.  Operators  respond  by  favouring  the physical option even where a digital one would lower total system cost.

Further gaps reinforce the bias between solutions. The regulatory framework can create a mismatch between the benefits brought by the digital grid toolkit and the costs and risks borne by network operators, which may disincentivise their use. In addition, evidence of these benefits are hard to assemble without agreed valuation methods and credible baselines. Finally, rules that require proven benefits before a tool can enter operation constrain solutions whose evidence base can only be built through staged deployment.

Reforming these frameworks is a high-effort, high-impact lever available to policy makers. Priorities for regulatory reform are:

-  Calibrate  regulatory  frameworks  to  incentivise  efficient  network  operator decisions across all  possible  solutions,  including  the  digital  grid  toolkit. Reform regulatory frameworks that bias network operators to favour physical grid investments where other solutions are more cost-efficient. Consider technologyneutral total expenditure frameworks that incentivise network operators to select the most efficient solutions across software, digitalisation, GETs and conventional solutions.
-  Incentivise decisions and investments that better reflect the value delivered to the system, not only the expenditure incurred. Shift towards output- and performance-based  regulation  that  links  allowed  revenues  and  incentives  to measurable  outcomes,  such  as  capacity unlocked, grid capacity utilised, congestion, curtailment and connection queues reduced, and reliability delivered.
-  Require advanced technologies to be assessed in planning. Mandate that GETs, digital tools and non-wire alternatives be evaluated in connection studies, reinforcement  decisions  and  asset  replacement  programmes,  recognising  that these solutions complement rather than replace new build. This requires planning methods that can represent them: more granular and increasingly probabilistic methods able to credit variable conditions, realistic outages and remedial actions. In the  case  of  technologies  with  a  well-established  case,  consider  direct obligations instead of relying on incentives alone.
-  Develop standardised valuation methods for advanced grid technologies, covering avoided  congestion, deferred reinforcement, reduced  curtailment, improved  reliability,  faster  connections,  greater  resilience  and  operational  risk reduction. These valuation methods would help assess solutions in the digital grid toolkit  against  conventional  ones,  and  build  regulatory  mechanisms  able  to incentivise the delivery of additional system benefits.
-  Use  regulatory sandboxes  and  dedicated  innovation  funding to trial technologies  and  rule  changes  in  controlled  real-world  settings,  with  clear pathways to feed successful trials into standard practice rather than leaving them as isolated pilots.

## Build robust, shared data foundations

Data scarcity holds back better use of grids. The digital grid toolkit can only be trained, validated and trusted on data that are of good quality and accessible, yet across most networks datasets are uneven, fragmented and hard to share. They are weakest at the distribution level, where demand and distributed resources are growing fastest. Where data exist, quality is often the deeper problem.

Fragmentation compounds scarcity. Data typically sit in incompatible formats and organisational silos, including between transmission and distribution functions, so the  system-wide  view  that  AI  needs  is  rarely  available.  Sharing  data  raises legitimate concerns over cybersecurity, sovereignty and  privacy, and the benchmarks and shared infrastructure that would let operators validate tools and pool  costs  are  largely  absent.  These  are  no-regrets  enablers:  stronger  data foundations pay off whichever technologies ultimately scale.

Priorities for building robust, shared data foundations are:

-  Extend  monitoring  and  instrumentation  at  the  distribution  level,  where visibility  is  weakest. Build  on  the  replacement  cycle  to  embed  sensors, secondary-substation  monitoring  and  -  alongside  privacy  protection  -  smartmeter data for operational use, not only billing.
-  Prioritise data quality through validation, cleansing and standard data-quality metrics.
-  Support interoperability through common  data  models, documented application programming interfaces (APIs) and vendor-neutral architectures, favouring practical, open  interfaces over heavier top-down standardisation, and developing them collaboratively, as in open standards such as LF Energy's TROLIE.
-  Enable trusted data sharing , pairing data-quality requirements with frameworks that move from voluntary codes to mandated rules, and defining governance that balances transparency with cybersecurity, privacy and national security.
-  Support  shared  and  pooled  data  infrastructure to  spread  fixed  costs  and learning across operators, and develop mechanisms to share lessons from failed pilots as well as successes.

## Invest in skills and organisational readiness

People and processes strongly influence whether technology is able to deliver its potential, and both are under strain. The professionals who combine power system expertise  with  data  science  are  scarce,  and  utilities  compete  for  them  against better-paying sectors while their own workforce ages. The sector has also been slow to seek digital talent, leaving gaps across the whole deployment chain, from control-room  operators  and  planners  to  field  crews,  cybersecurity  teams  and regulators.

Skills alone are not enough. The way operators procure and adopt technology can blunt  its  value.  The  largest  gains  may  come  from  going  beyond  automating existing tasks, and redesigning the processes around what the technology can do. This  is  a  more  difficult  organisational  change  that  deployment  typically  fails  to address, meaning that pilots stall at the point of integration into control rooms and existing  workflows.  Developing  a  skilled  grid  workforce  and  the  organisational capacity to deploy their skills effectively requires deliberate action.

Priorities for skills and organisational readiness are:

-  Treat  digital  and  AI  skills  as  a  strategic  workforce  priority. Take  stock  of existing skills, define digital career paths and make utility roles attractive against the  tech-sector  competition.  Invest  across  the  full  deployment  chain,  including operators,  planners,  protection  engineers,  field  crews,  cybersecurity  teams, regulators and suppliers, and not only data scientists.
-  Build and retain combined power system and data science capability through training academies, university partnerships and cross-disciplinary roles; require project  budgets  to  include  appropriate  training  as  a  condition  for  scaling;  pool scarce  capability  regionally;  and  plan  for  workforce  renewal  as  much  of  the workforce nears retirement.
-  Make replacement investment digital by default. Require sensors, communication interfaces, interoperable data structures, cybersecurity provisions and control-room integration to be considered whenever major substations, lines, transformers, protection systems  or  distribution assets  are refurbished or replaced.  Capturing  the  replacement  cycle  is  often  the  lowest-cost  route  to building observability, controllability and data quality over time, provided digital requirements are specific early in asset and procurement.
-  Treat the digital grid toolkit deployment as an organisational and process project, planned over the long term, not a technology purchase. Budget for workflow redesign and control-room integration, the point where most pilots stall. Build  the  internal  culture  with  dedicated  teams  that  support  and  oversee  AI adoption (AI ambassadors and central governance functions), so that new tools are trusted and adopted incrementally and securely. This also means planning over longer horizons than a single technology cycle, while keeping the flexibility to adopt rapidly evolving tools continuously, and embedding structured pathways that move proven solutions from pilot into standard operating practice.
-  Move  towards  more  dynamic  operating  and  market  rules. Implement probabilistic  ratings,  risk-based  congestion  management,  probabilistic  security assessment and dynamic operating limits, and ensure regulatory acceptance of these methods to enable improved grid utilisation, as they provide a systematic basis for identifying and managing usable operational headroom.

## Build trust, assurance and security

Trust and security set the pace at which AI enters critical operations, and both are underdeveloped. Operators have adopted AI readily for tasks that do not bear directly  on  real-time  control,  but  remain  cautious  where  errors  could  threaten supply, because accountability cannot be delegated to an algorithm and many AI outputs cannot be fully explained or audited. The tools that would build confidence, namely standardised validation and certification, barely exist, so trust accrues only slowly.

Cybersecurity  concerns  need  to  be  considered  at  the  design  stage:  as  grids become more connected and software-defined, the attack surface expands across grid-edge devices, substations and platforms, and the convergence of information and operational technology exposes systems that were once isolated. AI adds risks of its own, from data poisoning to opaque failure modes, that conventional cybersecurity does not fully address. A related trend is the growing reliance of AI tools on vendors and platforms outside an operator's own jurisdiction, raising the same kind of dependency risk long familiar with other strategic technologies such as navigation systems and defence.

Priorities for building trust, assurance and security are:

-  Calibrate AI governance and human oversight to the criticality of the grid function. Adopt function-based governance that focuses on what a system does, rather  than  what  technology  it  uses,  distinguishing  between  tools  that  inform, supervise or automate decisions. Governance should keep an accountable human in  place  as  tools  mature,  while  clarifying  approval  processes,  model  change controls,  incident  reporting,  audit  trails  and  fallback  arrangements  for  safetycritical functions.
-  Clarify accountability, liability and risk allocation for AI-assisted decisions. Extend  existing  legal  and  regulatory  frameworks  to  grid  applications  of  AI, including  product-liability  approaches  such  as  the  EU's  2024  Product  Liability Directive,  which  explicitly  covers  software  and  AI  systems.  Regulators  and governments should also examine whether insurance, guarantees or other risktransfer mechanisms are needed for harms linked to AI in critical infrastructure, without  allowing  them  to  substitute  for  robust  assurance,  cybersecurity  and operational accountability.
-  Embed cybersecurity by design , including in replacement investment decisions, server architectures and supply-chain and procurement requirements, building on established frameworks such as NERC CIP and NIST.
-  Apply  risk-based  governance that  assures  the  integrity  and  robustness  of models  in  proportion  to  the  criticality  of  each  function,  protecting  the  system without needlessly blocking the data-sharing that AI depends on.
-  Favour explainable, physics-informed model design to ease explainability and strengthen trust. Direct funding, procurement criteria and research support

towards  models  that  embed  known  grid  physics  rather  than  learn  system behaviour purely from data, particularly at the distribution level where data are scarcest.  This  can  reduce  data  requirements,  improve  auditability  and  give operators  outputs  that  they  can  check  directly  against  underlying  engineering assumptions,  complementing  the  data  foundation  work  above  rather  than substituting it.

-  Manage AI and cloud dependency through diversification, predictability and co-operation. The  same  principles  that  underpin  energy  security  apply  to  AI: diversify providers, models and deployment options rather than relying on a single vendor or jurisdiction;  seek  predictable,  transparent  terms  of  engagement  with technology  and  data  partners;  and  use  international  co-operation  to  share experience  and  de-risk  dependency  collectively  rather  than  through  unilateral retreat.  Weigh  these  risks  deliberately  when  adopting  AI  in  critical  operations, without treating dependency itself as a reason to avoid the benefits AI can bring.

## Strengthen international co-operation

Some of the recommendations in this report can be built once and shared, rather than  repeated  by  every  country  and  utility  independently,  both  for  the  shared technical foundations AI increasingly depends on, and for the wider deployment challenge,  where  advanced  economies  have  already  tested  approaches  that emerging  market  and  developing  economies  (EMDEs)  can  adapt  rather  than reinvent. The barriers set out in Chapter 3 are more constraining in EMDEs: skills are scarcer, while financing is limited by high capital costs and weak cost recovery for software and data.

Priorities for strengthening international co-operation are:

-  Pool data, compute and expertise to build shared AI foundations for grids. Support  international  collaboration,  including  open-source  initiatives,  shared benchmarks and research partnerships, to develop and validate general-purpose grid AI models and physics-informed approaches jointly, rather than duplicating this costly effort in every country; embed interdisciplinary co-operation between power-system and AI specialists as a design principle underlying these efforts, not an afterthought.
-  Develop standardised validation and certification procedures for AI and digital tools  in  critical  operations,  using  shared  test  environments,  such  as  the  EU's Testing and Experimentation Facilities, and common benchmarks.
-  Adapt  proven  approaches  rather  than  reinventing  them , particularly  for EMDEs  Successful deployment of a technology in advanced economies provides . evidence that it works, reducing perceived risks and technology costs in other countries, and proven regulatory templates - from output-based remuneration to sandboxes - can be adapted to local conditions.
-  Mobilise  international  co-operation  and  blended  finance  for  EMDEs. Use concessional finance and regional capability pooling to de-risk early deployment;

share scarce skills, tools and the cost of experimentation across utilities, funders and technology providers.

-  In  EMDEs,  place  strong  emphasis  on  distribution-level  applications  with visible consumer benefits ,  such as loss reduction and improved reliability, to build the political and public support that sustains digital investment.
-  Build observability through the replacement cycle in EMDEs ,  applying  the digital-by-default principle as a low-cost way to accumulate visibility over time, rather than through wholesale new instrumentation that strained budgets cannot fund.

## Abbreviations and acronyms

ADMS

advanced distribution management system

AI

artificial intelligence

API

application programming interface

BESS

battery energy storage system

CAPEX

capital expenditure

CIP

critical infrastructure protection

DERMS

distributed energy resource management system

DLR

dynamic line rating

DMS

distribution management system

DSO

distribution system operator

DTR

dynamic transformer rating

EMDE

emerging market and developing economy

EMS

energy management system

e-STATCOM

enhanced static synchronous compensator

EV

electric vehicle

FACTS

flexible alternating-current transmission system

FLISR

fault location, isolation and service restoration

GET

grid-enhancing technology

GPU

graphics processing unit

HVDC

high-voltage direct-current

IEA

International Energy Agency

IT

information technology

NERC

North American Electric Reliability Corporation

NIST

(US) National Institute of Standards and Technology

OPEX

operational expenditure

OT

operational technology

PMU

phasor measurement unit

PST

phase-shifting transformer

PV

photovoltaic

RAB

regulated asset base

RDSS

Revamped distribution sector scheme

RIIO

revenue = investment + innovation + output incentives

SATA

storage as a transmission asset

SCADA

supervisory control and data acquisition

SGI

Smart Grid Index

SSSC

static synchronous series compensator

STATCOM

static synchronous compensator

TCSC

thyristor-controlled series capacitor

TOTEX

total expenditure

TRL

technology readiness level

TROLIE

transmission ratings and operating limits information exchange

TSO

transmission system operator

UPFC

unified power-flow controller

V2G

vehicle-to-grid

WAMS

wide-area monitoring system

GW

Gigawatt

km

Kilometre

kV

Kilovolt

ms

Millisecond

MW

Megawatt

See the IEA glossary for a further explanation of many of the terms used in this report.

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual Member countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject  to  the  IEA's  Notice  for  CC-licenced  Content,  this  work is licenced under  a  Creative  Commons  Attribution  4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area. Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA -

September 202 6

Cover design: IEA

Photo credits: ©

Shutterstock

<!-- image -->