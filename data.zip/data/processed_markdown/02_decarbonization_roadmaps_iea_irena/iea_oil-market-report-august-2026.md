---
document_id: iea_oil-market-report-august-2026
title: "Iea Oil-Market-Report-August-2026"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_oil-market-report-august-2026.pdf"
tables_detected: 64
converted_with: "Docling v2.32 (TableFormer)"
---

Title of the Report

<!-- image -->

Methodology Notes

Oil Industry and Markets Division

June 2026

<!-- image -->

<!-- image -->

Highlights

## Contents

| Introduction (updated) ..........................................................................................................................................3      |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Refining hubs ........................................................................................................................................................4 |
| Refinery configuration and product yields (updated) ..............................................................................................4                     |
| Crude grades (updated).........................................................................................................................................5        |
| Petrochemical margins..........................................................................................................................................6        |
| Emission costs (updated).......................................................................................................................................7        |
| Energy consumption costs (updated) .....................................................................................................................8               |
| Refinery margin calculation (updated) .................................................................................................................10               |
| Changes compared to July 2022 model (updated) ................................................................................................ 10                       |

## Introduction

The Oil Industry and Markets Division of the International Energy Agency has published refinery margins  since  June  1992  in  its  monthly Oil  Market  Report.  In  2022,  the  IEA  refining  margins calculation was revised (Methodology 2022) to provide a n indicative site average margin based on three criteria:

- -Geography, namely: Mediterranean, North West Europe, Singapore, the US Gulf Coast, and the US Midcontinent
- -Crude  processed:  selection  based  on  typical  regional  crude  slate,  accessibility, API  and sulphur composition
- -Refinery complexity profile: Hydroskimming, catalytic cracking, coking and petrochemicals integration

August 2024 methodology updates (Figure 1) include:

- -the utility costs on top of the existing calculation such as natural gas , refinery fuel gas, LPG, fuel oil, electricity, petroleum coke , imported steam
- -a new yield structure based on empirical data
- -some prices adjustments

May 2026 methodology updates include:

- -Carbon ETS cost calculation updated with a new methodology for Europe

To avoid double counting, initial energy use assumptions and hydrogen needs calculations have been removed from the new process. The objective is to provide a more realistic refining margin driven by the commodity market.

In order to get the utilities data, the source that has been chosen is the IEA World Energy Statistics. This country level dataset is calculated from the annual submission by the OECD members. It -contains the throughput and the consumption of all types of energy quoted above on a country level .

IEA refinery margins remain strictly indicative, however, and do not include the full spectrum of other  nonenergy variable costs (such as chemicals or catalysts) , capital  expenditures or  man hours costs.

These margins should be referenced as IEA Global Indicator Refinery Margins. On the charts and tables, referenced in IEA publications, the source should be identified as IEA/Argus Media Group prices.

## Figure 1: IEA refinery margins calculation workflow

<!-- image -->

## Refining hubs

For  now,  the  IEA  will  continue  assessing  refinery  margins  for  five  regions,  including  only Singapore from East of Suez refining hubs.

-  Northwest Europe
-  Mediterranean Europe
-  US Gulf Coast
-  US Midcontinent
-  Singapore

## Refinery configuration and product yields

Two to three types of refinery configurations are selected per region, based on the characteristics of existing refinery capacity. For example, coking facilities are not very common in Northwest Europe, while hydroskimming refineries are rare in the US.

| Refinery configuration by region   | Refinery configuration by region   | Refinery configuration by region   | Refinery configuration by region   | Refinery configuration by region   |
|------------------------------------|------------------------------------|------------------------------------|------------------------------------|------------------------------------|
|                                    | Hydroskimming                      | Cracking/ Hydrocracking            | Coking                             | Petrochemical component            |
| NW Europe                          | X                                  | X                                  |                                    | X                                  |
| Mediterranean                      | X                                  | X                                  |                                    |                                    |
| US Gulf Coast                      |                                    | X                                  | X                                  |                                    |
| US Midcontinent                    |                                    | X                                  | X                                  |                                    |
| Singapore                          |                                    | X                                  |                                    | X                                  |

Our main purpose is to track a hypothetical average refinery, based on prevailing crude diets and typical product outputs in each refining centre. Yields take into account both long -term structural changes and the impact on demand and refinery operations/product configurations and will be reassessed on an annual basis.

Initially,  t he methodology was diverting  from  software simulated  refinery  yields  where  the -specified configuration and crude grade drive the outputs. The methodology now implements some empirical features to calculate the yields. For some regions, the yields are now adjusted depending on the available data. For instance, USGC and USMC yields are obtained f rom U.S. Energy  Information Administration  (EIA)  publications. Northwest  Europe  and  Mediterranean cracking/hydrocracking refinery yields are based on refinery input and output data from the IEA's Monthly Oil Statistics,  with  adjustments  for  sweet  and  sour  crude  grades. Singapore  refinery margins are based on average yield statistics for several Asian countries, where reliable datasets are available.

Observed product yields are simplified to include only major traded products.

Refining crude oil usually results in a volumetric expansion as products coming out of the process, and in general, products used in various sectors, tend to be lighter than crude oil. It also results in losses as sulphur, hydrogen, and other non hydrocarbon gases, water, and various impurities are -removed in the refining process. We use the difference in densities of a standard product basket and the given crude oil type to calculate the volumetric expansion. Calculated values of sulphur removed are used t o estimate processing losses.

For US refineries, we assume a neutral standing with regards to the renewable fuel obligations. This  means  that  an  average  US  refinery  is  assumed neither to have a deficit nor excess of Renewable Identification Numbers.

The yield table is available below .

## Crude grades

Instead of tying refinery margin calculations to a specific grade, our new methodology is based on types of crude. We consider light sweet, medium sour and heavy sour grades, which may be a chronological composite of several crude grades that reflect evolving crude oil supply and trade dynamics. For example, Singapore light sweet grade is composed of Tapis quotes until mid -2019 and then replaced by WTI quotes on a cost and freight (CFR) Singapore basis. We have similar developments  in  product  prices  where,  for  example,  different  diesel  or  gasoil  quotes  are concatenated to form a continuous time series of diesel prices. Our crude oil, refined products, freight and natural gas composite price series have been developed in consultation with leading energy and commodity price reporting agency Argus, our market data provider.

| Crude types with respective grades   | Crude types with respective grades   |
|--------------------------------------|--------------------------------------|
| NWE light sweet                      | North Sea Dated                      |
| NWE medium sour                      | Johan Sverdrup                       |
| MED light sweet*                     | Saharan Blend                        |
| MED medium sour*                     | Basrah Medium                        |
| USGC light sweet                     | WTI                                  |
| USGC medium sour                     | Mars                                 |
| USGC heavy sour*                     | WCS                                  |

| USMC light sweet       | WTI          |
|------------------------|--------------|
| USMC heavy sour*       | WCS          |
| Singapore light sweet* | WTI          |
| Singapore medium sour  | Dubai        |
| Singapore heavy sour*  | Basrah Heavy |

*Composite types, preceded by one or more other crude quotes

## Petrochemical margins

To quantify the contribution from integrated petrochemical operations, we have introduced a simplified petrochemical margin component for Northwest Europe and Singapore. It assumes that naphtha produced in the refinery is used as feedstock in an integrated cracker (except for volumes  diverted  to  gasoline  production).  By product  hydrogen  is  accounted  for  as  'free' -hydrogen supply for refinery uses and is reflected in savings on natural gas purchases for petrochemically integrated refineries. -

Petrochemical margin components

<!-- image -->

## Emission costs

Since 1 January 2005, the European Union has implemented the EU Emissions Trading System (ETS) to support the reduction of greenhouse gas emissions from major industrial sectors. The system is based on a cap -andtrade mechanism, whereby emission allowances are allocated to  installations  and  can  be  traded  on  the  market  depending  on  their  actual  emissions. The European  Environment  Agency's  (EEA)  provides  emissions  and  allowances  data  for  the European refineries.  This methodology excludes the allowances from the emissions cost to picture a margin when the EU will phase out the free allowances.

EU ETS a re tracked by the EEA available on this website. The data available are:

- -Historical CO2 Emissions by industry by country
- -Allowances given by industry by country

The  industry  used  for  the  model  is  Refining  of  mineral  oil,  the  data  available  are  for  EU countries and the granularity is yearly.

The methodology consists of calculating the quantity of CO2 emitted by barrel of oil processed by country.

BES data is used to get the crude throughput on a yearly basis.

The emissions per barrel of oil are then multiplied by the CO2 ETS price provided by Argus Media Group.

<!-- formula-not-decoded -->

𝐸𝐸ℎ𝑀𝑀𝐸𝐸𝑟𝑟𝑀𝑀ℎ𝑝𝑝𝑟𝑟𝐶𝐶 𝑥𝑥 ( 𝑏𝑏𝑀𝑀 )

With x the country.

The countries are grouped in the two regions, Northwest Europe and Mediterranean.

| Margin type                             |   CO2 ETS ($/bbl) | Countries                                      |
|-----------------------------------------|-------------------|------------------------------------------------|
| NW Europe light sweet hydroskimming     |              1.73 | Ireland                                        |
| NW Europe light sweet cracking          |              1.68 | Belgium, Finland, France, Germany, Netherlands |
| NW Europe medium sour cracking          |              1.68 | Belgium, Finland, France, Germany, Netherlands |
| Mediterranean light sweet hydroskimming |              1.73 | Ireland                                        |
| Mediterranean light sweet cracking      |              1.67 | Greece, Italy, Spain,Turkiye                   |
| Mediterranean medium sour cracking      |              1.67 | Greece, Italy, Spain,Turkiye                   |

Data based on EEA 2025.

The  following  table  summarises  final  yields  used  for  margin  calculations  and  emission  cost parameters.

<!-- image -->

|                           | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   | IEA Global Indicator Refinery Margin Yields and Cost Parameters 2026   |
|---------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|
|                           | LPG                                                                    | Naphtha                                                                | Gasoline                                                               | Jet/Kero                                                               | Diesel                                                                 | Heat Oil                                                               | LSFO                                                                   | HSFO                                                                   | Petcoke                                                                | Total                                                                  |
| NWEurope                  |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |
| Light sweet hydroskimming | 6.0%                                                                   | 7.0%                                                                   | 20.0%                                                                  | 12.0%                                                                  | 20.0%                                                                  | 7.0%                                                                   | 28.0%                                                                  | 0.0%                                                                   | 0.0%                                                                   | 100.0%                                                                 |
| Light sweet cracking      | 7.0%                                                                   | 6.0%                                                                   | 28.0%                                                                  | 12.0%                                                                  | 28.0%                                                                  | 7.0%                                                                   | 14.0%                                                                  | 0.0%                                                                   | 0.0%                                                                   | 102.0%                                                                 |
| Medium sour cracking      | 7.0%                                                                   | 8.0%                                                                   | 23.0%                                                                  | 7.7%                                                                   | 25.0%                                                                  | 14.3%                                                                  | 0.0%                                                                   | 17.0%                                                                  | 0.0%                                                                   | 102.0%                                                                 |
| Mediterranean             |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |
| Light sweet hydroskimming | 3.6%                                                                   | 6.1%                                                                   | 14.8%                                                                  | 10.1%                                                                  | 30.7%                                                                  | 0.1%                                                                   | 34.5%                                                                  | 0.0%                                                                   | 0.0%                                                                   | 100.0%                                                                 |
| Light sweet cracking      | 4.2%                                                                   | 8.5%                                                                   | 20.7%                                                                  | 11.7%                                                                  | 27.2%                                                                  | 16.4%                                                                  | 12.4%                                                                  | 0.0%                                                                   | 0.0%                                                                   | 101.2%                                                                 |
| Medium sour cracking      | 7.0%                                                                   | 8.0%                                                                   | 21.3%                                                                  | 8.0%                                                                   | 26.3%                                                                  | 14.3%                                                                  | 0.0%                                                                   | 17.0%                                                                  | 0.0%                                                                   | 101.9%                                                                 |
| US Gulf Coast             |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |
| Light sweet cracking      | 7.0%                                                                   | 4.0%                                                                   | 44.0%                                                                  | 10.0%                                                                  | 25.2%                                                                  | 5.2%                                                                   | 4.5%                                                                   | 2.0%                                                                   | 0.0%                                                                   | 102.0%                                                                 |
| Medium sour cracking      | 7.0%                                                                   | 3.9%                                                                   | 41.7%                                                                  | 7.0%                                                                   | 27.3%                                                                  | 6.3%                                                                   | 0.0%                                                                   | 7.4%                                                                   | 0.0%                                                                   | 100.7%                                                                 |
| Heavy sour coking         | 10.0%                                                                  | 0.0%                                                                   | 43.0%                                                                  | 10.5%                                                                  | 30.0%                                                                  | 2.5%                                                                   | 0.0%                                                                   | 0.0%                                                                   | 8.0%                                                                   | 104.0%                                                                 |
| US Midwest                |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |
| Light sweet cracking      | 10.0%                                                                  | 1.0%                                                                   | 47.6%                                                                  | 7.0%                                                                   | 25.7%                                                                  | 2.7%                                                                   | 8.0%                                                                   | 0.0%                                                                   | 0.0%                                                                   | 102.0%                                                                 |
| Heavy sour coking         | 7.0%                                                                   | 0.0%                                                                   | 50.0%                                                                  | 7.0%                                                                   | 24.9%                                                                  | 4.6%                                                                   | 0.0%                                                                   | 0.0%                                                                   | 10.0%                                                                  | 103.5%                                                                 |
| Singapore                 |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |                                                                        |
| Light sweet cracking      | 7.0%                                                                   | 13.4%                                                                  | 26.0%                                                                  | 11.1%                                                                  | 18.1%                                                                  | 15.0%                                                                  | 9.0%                                                                   | 2.3%                                                                   | 0.0%                                                                   | 102.0%                                                                 |
| Medium sour cracking      | 6.3%                                                                   | 13.3%                                                                  | 23.2%                                                                  | 12.2%                                                                  | 19.2%                                                                  | 13.2%                                                                  | 0.0%                                                                   | 14.1%                                                                  | 0.0%                                                                   | 101.5%                                                                 |
| Heavy sour coking         | 7.0%                                                                   | 8.7%                                                                   | 28.0%                                                                  | 12.0%                                                                  | 27.0%                                                                  | 14.4%                                                                  | 0.0%                                                                   | 0.0%                                                                   | 7.0%                                                                   | 104.1%                                                                 |

Copyright @ 2026 IEA - All rights Reserved.

## Energy consumption costs

In the new methodology, the utility consumption costs are now included in the refinery margin calculation.

The marginal impact of energy costs over the refinery's gross margin is driven by:

- o The average energy consumption by barrel of crude processed
- o The regional daily price by utility

Given that the World Energy Statistics granularity is based on a country level, a list of selected representative countries (figure below) has been chosen to get the Marginal Energy Consumption (MJ/bl of crude processed) by region.

| National data used as the basis for modelling refinery energy costs   | National data used as the basis for modelling refinery energy costs   | National data used as the basis for modelling refinery energy costs   | National data used as the basis for modelling refinery energy costs   | National data used as the basis for modelling refinery energy costs   | National data used as the basis for modelling refinery energy costs   |
|-----------------------------------------------------------------------|-----------------------------------------------------------------------|-----------------------------------------------------------------------|-----------------------------------------------------------------------|-----------------------------------------------------------------------|-----------------------------------------------------------------------|
|                                                                       | Northwest Europe                                                      | Mediterranean                                                         | Singapore                                                             | US Gulf Coast                                                         | US Midcontinent                                                       |
| Hydroskimming                                                         | Ireland                                                               | Ireland                                                               | Korea                                                                 | N/A                                                                   | N/A                                                                   |
| Catalytic Cracking                                                    | France/Germany/ Belgium/Netherlands/ Finland                          | Italy/Greece/ Turkiye/Hungary/ Spain                                  |                                                                       |                                                                       |                                                                       |
|                                                                       |                                                                       |                                                                       | Korea                                                                 | US                                                                    | US                                                                    |
| Coking                                                                | N/A                                                                   | Hungary                                                               | Korea                                                                 | US                                                                    | US                                                                    |

Source: IEA World Energy Statistics.

The selection by country is based on the number of available refineries, their configuration and their  location. For  example,  Ireland  is  one  of  the  only  European  countries  in  the OECD that possesses one refinery that is configured as hydroskimming (HSK). This is why it is used for NWE HSK and MED HSK utility costs calculation .  In  the meantime, Hungary is also a particular case where the only operational refinery uses a Delayed Coker.

Once the countries are selected by region, a weighted average is calculated to get the marginal consumption by energy in MJ by barrel of crude processed (table below).

| Marginal Energy Consumption by region (MJ/bl of crude processed)   | Marginal Energy Consumption by region (MJ/bl of crude processed)   | Marginal Energy Consumption by region (MJ/bl of crude processed)   | Marginal Energy Consumption by region (MJ/bl of crude processed)   | Marginal Energy Consumption by region (MJ/bl of crude processed)   |
|--------------------------------------------------------------------|--------------------------------------------------------------------|--------------------------------------------------------------------|--------------------------------------------------------------------|--------------------------------------------------------------------|
| Energy \ Region                                                    | NWE                                                                | MED                                                                | SING                                                               | US                                                                 |
| NATGAS                                                             | 51.0                                                               | 93.7                                                               | 64.1                                                               | 185.7                                                              |
| FUEL GAS                                                           | 205.1                                                              | 250.0                                                              | 179.7                                                              | 105.0                                                              |
| ETHANE                                                             | 0.0                                                                | 0.0                                                                | 0.0                                                                | 0.0                                                                |
| LPG                                                                | 8.3                                                                | 14.3                                                               | 4.0                                                                | 1.2                                                                |
| FUEL OIL                                                           | 13.4                                                               | 12.4                                                               | 2.5                                                                | 0.1                                                                |
| ELECTRICITY                                                        | 26.7                                                               | 31.2                                                               | 49.0                                                               | 32.1                                                               |
| PETCOKE                                                            | 25.8                                                               | 28.5                                                               | 9.8                                                                | 69.8                                                               |
| IMPORTED STEAM                                                     | 8.5                                                                | 4.6                                                                | 1.3                                                                | 9.3                                                                |
| TOTAL                                                              | 338.9                                                              | 434.7                                                              | 310.5                                                              | 403.1                                                              |

Source: IEA World Energy Statistics 2023 data

The first step is to get the  marginal consumption by energy ,  the  second  step  is  to  choose  an adequate price for each utility (table below). Most of the prices come from Argus Media Group, the few exceptions that are provided by Bloomberg concern prices that are not available from 2010 to 2020.

| Mapping between energy type and selected price   | Mapping between energy type and selected price   | Mapping between energy type and selected price   | Mapping between energy type and selected price   | Mapping between energy type and selected price   | Mapping between energy type and selected price   |
|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Energy type                                      | Price type                                       | NWE                                              | MED                                              | SING                                             | US                                               |
| Natural Gas                                      | Natural Gas                                      | TTF                                              | PVB                                              | LNG Northeast Asia                               | Nymex                                            |
| Fuel Gas                                         | LPG                                              | Propane coaster NWE                              | Propane coaster MED                              | Propane Argus far east                           | Propane Mt Belvieu LST                           |
| LPG                                              | LPG                                              | Propane coaster NWE                              | Propane coaster MED                              | Propane Argus far east                           | Propane Mt Belvieu LST                           |
| Fuel Oil                                         | HSFO                                             | 3.5%S 380cst cargo NWE                           | 3.5%S 380cst cargo WMED                          | Fuel oil 3.5%S 380cst cargo SING                 | 3.0%S barge USGC                                 |
| Petcoke                                          | Petcoke                                          | x                                                | PetCoke Turkey 5.5%S                             | PetCoke I ndia 4.5%S                             | PetCoke USGC6.5%S                                |
| Electricity                                      | Electricity                                      | French OTC                                       | Spanish OTC                                      | JEPX                                             | Power PJMWest                                    |
| I mported Steam                                  | Natural Gas                                      | TTF                                              | PVB                                              | LNG Northeast Asia                               | Nymex                                            |

Source: Argus Media Group, Bloomberg

Once the marginal consumption by energy and the prices are obtained, the Total Marginal Energy Cost by country is calculated following the mathematical relationship:

<!-- formula-not-decoded -->

With x country, i the type of energy .

The main advantage of this methodology resides in the quality of the dataset. The IEA spends a lot of time and resources on the data consolidation in order to provide the World Energy Statistics. Also, the dataset is based on data provided by the OECD members which makes this approach empirical and not t heoretical anymore.

However, a few downsides remain in this methodology:

- o The granularity is by year and the last data available is often two years before publication
- o There are approximative assumptions as it is based on a country level. The pool by country implies  that  many  refineries  with  different  configurations,  crude  assays,  locations  and

markets are in the same bucket. Which means that two different refinery configurations can have the same marginal energy cost despite the different operational conditions ,  crude processed or market shared. It can result in an energy cost overestimation

- o The lack  of  information  regarding  the  natural  gas  required  for  hydrogen  production  via steam methane reforming for some countries. This part will be improved with the IEA's Energy Data Centre in order to clarify what is behind the natural gas energy flow

## Refinery margin calculation

Once the yields, the prices and all the costs related obtained (Figure 1) ,  the refinery margin is calculated as followed:

<!-- formula-not-decoded -->

## Changes compared to July 2022 model

What changed compared to July 2022 model is the:

- o Addition of the marginal energy cost
- o Revision of the yields structure based on an empirical approach
- o Substitution of some prices that were considered outdated or not adapted to the market

Each region's sensitivity responded differently to the three main changes.

T he energy assessment underlines the disparities between the different region of the globe (see table below). Northwest Europe, Mediterranean basin and Singapore see the largest impact to margins, given that energy costs are higher here. Furthermore, this change in the methodology underscores the significant cost advantage that the USA enjoys over the rest of the regions, given that natural gas and LPG are significantly cheaper.

| Marginal Energy Cost of a Medium Sour FCC profile by region ($/bl of crude processed)   | Marginal Energy Cost of a Medium Sour FCC profile by region ($/bl of crude processed)   | Marginal Energy Cost of a Medium Sour FCC profile by region ($/bl of crude processed)   | Marginal Energy Cost of a Medium Sour FCC profile by region ($/bl of crude processed)   | Marginal Energy Cost of a Medium Sour FCC profile by region ($/bl of crude processed)   |
|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|
| Energy \ Region                                                                         | NWE                                                                                     | MED                                                                                     | SING                                                                                    | US                                                                                      |
| NATGAS                                                                                  | 0.51                                                                                    | 0.81                                                                                    | 0.59                                                                                    | 0.35                                                                                    |
| FUEL GAS                                                                                | 1.88                                                                                    | 2.37                                                                                    | 1.84                                                                                    | 0.69                                                                                    |
| ETHANE                                                                                  | 0.00                                                                                    | 0.00                                                                                    | 0.00                                                                                    | 0.00                                                                                    |
| LPG                                                                                     | 0.10                                                                                    | 0.12                                                                                    | 0.04                                                                                    | 0.01                                                                                    |
| FUEL OIL                                                                                | 0.11                                                                                    | 0.12                                                                                    | 0.02                                                                                    | 0.00                                                                                    |
| ELECTRICITY                                                                             | 0.85                                                                                    | 0.73                                                                                    | 1.04                                                                                    | 0.19                                                                                    |
| PETCOKE                                                                                 | 0.09                                                                                    | 0.09                                                                                    | 0.03                                                                                    | 0.13                                                                                    |
| IMPORTED STEAM                                                                          | 0.10                                                                                    | 0.04                                                                                    | 0.01                                                                                    | 0.02                                                                                    |
| TOTAL                                                                                   | 3.63                                                                                    | 4.29                                                                                    | 3.57                                                                                    | 1.39                                                                                    |

Source: IEA Monthly Oil Statistics, IEA World Energy Statistics, EIA, Argus Media Group

The next table shows the difference of margins between the former methodology and the new one. For NWE, MED and SING most of the difference is explained by the marginal energy cost subtraction .

Regarding the US, the revision of the yields has a substantial impact on the USGC and USMC margins. The yields are now aligned with EIA publications which pulls the margins down. The

biggest  contributor  is  the  Gasoline  yield  that  was  higher  than  the  US  Gulf  Coast  and  Mid Continent yearly average.

## IEA Margins New VS Old differential (Left) and New Margin (Right)

| $/bbl                          | 2021   | 2021   | 2022   | 2022   | 2023   | 2023   | 4Q23   | 4Q23   | 1Q24   | 1Q24   | 2Q24   | 2Q24   | Jul 24   | Jul 24   |
|--------------------------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|----------|----------|
| NWEurope                       | Diff   | New    | Diff   | New    | Diff   | New    | Diff   | New    | Diff   | New    | Diff   | New    | Diff     | New      |
| Light sweet hydroskimming      | -2.32  | 0.21   | -2.80  | 7.26   | -2.25  | 5.57   | -2.17  | 4.14   | -2.25  | 4.63   | -2.25  | 1.83   | -2.45    | 0.57     |
| Light sweet cracking           | -3.61  | -0.10  | -6.91  | 9.32   | -2.62  | 9.19   | -2.91  | 7.50   | -2.29  | 8.71   | -1.41  | 5.79   | -2.01    | 3.87     |
| Light sweet cracking + Petchem | -2.03  | 4.52   | -7.61  | 10.83  | -2.96  | 8.90   | -3.27  | 7.41   | -2.31  | 8.92   | -1.41  | 6.17   | -1.66    | 3.98     |
| Medium sour cracking           | -6.49  | -0.38  | -9.13  | 30.00  | -9.91  | 7.65   | -10.20 | 6.84   | -10.02 | 8.44   | -8.55  | 4.31   | -8.71    | 2.95     |
| Mediumsour cracking + Petchem  | -1.47  | 7.60   | -3.48  | 37.80  | -4.85  | 12.76  | -5.21  | 12.10  | -4.77  | 13.93  | -3.31  | 9.92   | -3.36    | 8.07     |
| Mediterranean                  |        |        |        |        |        |        |        |        |        |        |        |        |          |          |
| Light sweet hydroskimming      | -2.26  | 0.64   | -3.18  | 5.91   | -2.49  | 5.68   | -2.38  | 4.03   | -2.30  | 4.60   | -1.95  | 2.71   | -2.33    | 1.05     |
| Light sweet cracking           | -7.40  | -2.44  | -9.46  | 7.35   | -5.84  | 8.12   | -5.68  | 6.07   | -4.93  | 7.33   | -4.34  | 5.17   | -4.88    | 2.75     |
| Medium sour cracking           | -8.34  | -2.66  | -11.58 | 10.08  | -10.69 | 6.64   | -10.15 | 4.55   | -10.59 | 7.79   | -8.81  | 3.43   | -8.62    | 2.39     |
| US Gulf Coast                  |        |        |        |        |        |        |        |        |        |        |        |        |          |          |
| Light sweet cracking           | -2.89  | 8.15   | -4.56  | 22.08  | -3.65  | 16.82  | -1.28  | 10.16  | -1.29  | 15.41  | -1.55  | 10.86  | -1.33    | 11.08    |
| Medium sour cracking           | -8.13  | 7.66   | -12.38 | 23.31  | -10.30 | 16.18  | -8.61  | 9.67   | -8.68  | 14.59  | -7.89  | 9.38   | -7.58    | 10.65    |
| Heavy sour coking              | -9.68  | 10.30  | -14.50 | 31.42  | -11.87 | 22.74  | -10.57 | 15.78  | -10.96 | 20.26  | -10.56 | 14.93  | -11.67   | 15.76    |
| US Midwest                     |        |        |        |        |        |        |        |        |        |        |        |        |          |          |
| Light sweet cracking           | -0.39  | 11.94  | -4.34  | 25.56  | -2.77  | 16.75  | -2.22  | 8.20   | -3.37  | 14.68  | -5.26  | 14.27  | -6.23    | 16.75    |
| Heavy sour coking              | -11.98 | 14.03  | -16.50 | 34.11  | -14.42 | 22.18  | -14.03 | 13.05  | -17.19 | 17.95  | -18.59 | 18.28  | -19.72   | 22.65    |
| Singapore                      |        |        |        |        |        |        |        |        |        |        |        |        |          |          |
| Light sweet cracking           | -2.89  | 0.21   | -2.48  | 8.99   | -1.29  | 5.97   | -1.52  | 5.21   | -0.52  | 6.90   | -0.56  | 1.79   | -1.16    | 1.78     |
| Light sweet cracking + Petchem | -2.67  | 2.14   | -2.07  | 10.87  | -0.92  | 7.15   | -1.13  | 6.22   | -0.26  | 7.63   | -0.32  | 2.28   | -0.92    | 2.08     |
| Medium sour cracking           | -5.60  | -1.68  | -6.16  | 6.65   | -5.88  | 3.14   | -5.94  | 1.85   | -5.67  | 4.35   | -5.15  | -0.33  | -5.52    | 0.73     |
| Medium sour cracking + Petchem | -3.33  | 2.29   | -1.97  | 12.30  | -2.68  | 7.14   | -2.73  | 5.66   | -2.52  | 7.95   | -2.36  | 2.71   | -2.76    | 3.55     |

Source: IEA analysis based on price assessments from Argus Media Group.

Another contributor to the US margins reduction is the revision of some prices. The prices have been changed to better reflect the biggest amount of sells among USGC and USMC markets. Here is the list of what changed:

- o Gasoline 87 conv entional Colonial M pipe to Gasoline 87 conv entional USGC Waterbo rne
- o Diesel ULSD Colonial 61 pipe to Diesel ULSD 62 USGC Waterborne
- o Gasoline 89 premium to Gasoline 87 conventional USMC

On the other side of the Atlantic, as showed in the Table 15MED Medium Sour FCC is the refinery profile that has been the most impacted among MED, NWE and SING regions. This significant difference is explained by the changing of crude and consequently the freight :

- o Argus Brent Sour to Basrah Medium for MED Medium Sour
- o Basrah Medium to Basrah Heavy for MED Heavy sour

## Changes compared to August 2024 model

The model takes into account a new methodology for emissions cost calculations. Integrating now EEA data with no appliance of the allowances and an integration of a cost by region such as Northwest Europe and Mediterranean.

EU Emissions Trading System (ETS) are tracked by the European Environment Agency available on this website. The data available are:

- o Historical CO2 Emissions by industry by country
- o Allowances given by industry by country

The industry used for the model is Refining of mineral oil, the data available are for EU countries and the UK and the granularity is yearly.

The methodology consists of calculating the quantity of CO2 emitted by barrel of oil processed by country.

BES data is used to get the crude throughput on a yearly basis .

## 𝐶𝐶𝐶𝐶 2 𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸 𝑀𝑀𝑀𝑀𝑀𝑀𝑀𝑀𝐸𝐸𝐸𝐸𝑀𝑀𝑀𝑀 𝐶𝐶𝐸𝐸𝐸𝐸𝐶𝐶 𝑥𝑥 ( 𝑈𝑈𝑈𝑈 $/ 𝑏𝑏𝑀𝑀 )

=

( 𝐶𝐶𝐶𝐶 2 𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸 𝑥𝑥 ( 𝐶𝐶𝐸𝐸𝐸𝐸 ) × 𝐶𝐶𝐶𝐶 2 𝐸𝐸𝐸𝐸𝑈𝑈 𝑃𝑃𝑀𝑀𝐸𝐸𝑃𝑃𝑃𝑃 𝑥𝑥 ( 𝑈𝑈𝑈𝑈 $/ 𝐶𝐶𝐸𝐸𝐸𝐸 )

𝐸𝐸ℎ𝑀𝑀𝐸𝐸𝑟𝑟𝑀𝑀ℎ𝑝𝑝𝑟𝑟𝐶𝐶 𝑥𝑥 ( 𝑏𝑏𝑀𝑀 )

With x the country.

As the data is by country, there is no detail by crude processed or refinery configuration. As said, the CO2 marginal cost will be the same for every refinery profile within the same region and only for European countries. In 2025, the allowances represented about 72% of the total emissions, reducing considerably the marginal cost. The Northwest Europe Light Sweet Hydro skimming profile, represented by Ireland, was about $20cts/bbl in the former methodology. With the EEA data  without  the  allowances,  the  car bon  cost  is  now  about  $1. 73 /bbl  and  $40cts/bbl  with  the allowances.

| Margin type                             |   CO2 ETS ($/bbl) | Countries                                      |
|-----------------------------------------|-------------------|------------------------------------------------|
| NW Europe light sweet hydroskimming     |              1.73 | Ireland                                        |
| NW Europe light sweet cracking          |              1.68 | Belgium, Finland, France, Germany, Netherlands |
| NW Europe medium sour cracking          |              1.68 | Belgium, Finland, France, Germany, Netherlands |
| Mediterranean light sweet hydroskimming |              1.73 | Ireland                                        |
| Mediterranean light sweet cracking      |              1.67 | Greece, Italy, Spain,Turkiye                   |
| Mediterranean medium sour cracking      |              1.67 | Greece, Italy, Spain,Turkiye                   |

Data based on EEA 2025.