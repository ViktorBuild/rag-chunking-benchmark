---
document_id: ghg_scope3_ch12_end_of_life
title: "Scope 3 Guidance - Category 12: End-of-Life Treatment of Sold Products"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat12_end_of_life_products.pdf"
tables_detected: 4
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

C sold by the reporting company (in the reporting year) at the end of their life. This ategory 12 includes emissions from the waste disposal and treatment of products category includes the total expected end-of-life emissions from all products sold in the reporting year. (See section 5.4 of the Scope 3 Standard for more information on the time boundary of scope 3 categories.)

End-of-life treatment methods (e.g., landfilling, incineration, and recycling) are described in category 5 (Waste generated in operations) and apply to both category 5 and category 12. Calculating emissions from category 12 requires assumptions about the end-of-life treatment methods used by consumers. Companies are required to report a description of the methodologies and assumptions used to calculate emissions (see chapter 11 of the Scope 3 Standard ).

For sold intermediate products, companies should account for the emissions from disposing of the intermediate product at the end of its life, not the final product.

## Calculating emissions from end-of-life treatment of sold products

The emissions from downstream end-of-life treatment of sold products should follow the calculation methods in category 5 (Waste generated in operations), with the difference that instead of collecting data on total mass of waste generated in operations, companies should collect data on total mass of sold products (and packaging) from the point of sale by the reporting company through the end of life after use by consumers.

The major difference between calculating upstream and downstream emissions of waste treatment is likely to be the availability and quality of waste activity data. Whereas the reporting company is likely have specific waste type and waste treatment data from its own operations, this information is likely to be more difficult to obtain for sold products. Although the reporting company may know the product's components, it may not know how the waste-disposal behavior of consumers and retailers varies across geographic regions.

If the reporting company sells intermediate products, it is required to account for emissions from disposing of the sold intermediate products at the end of their life.

## Activity data needed

Companies should collect:

- · Total mass of sold products and packaging from the point of sale by the reporting company to the end-of-life after consumer use (e.g., packaging used to transport products through to the point of retail and any packaging that is disposed of prior to the end-of-life of the final product
- · Proportion of this waste being treated by different methods (e.g., percent landfilled, incinerated, recycled).

## Emission factors needed

Companies should collect:

- · Average waste-treatment specific-emission factors based on all waste treatment types.

## Data collection guidance

When collecting data on total waste produced, the reporting company should collect data on the waste type(s) and amounts after it sells the products through to the end-of-life disposal by consumers. This data should include any packaging and product waste. For food and drink items, companies should refer to average proportion of food/drinks wasted. In many cases, total waste will be equal to the total products sold in reporting year. However, if the product is actually consumed (e.g., food and drink) the total waste is likely to be lower, and in other cases, such as products combusted to generate energy, could even be zero.

When collecting data on the proportion of waste treated by different methods, companies may refer to:

- · Company's own research and internal data on how its products are treated after consumption
- · Specific government directives on waste treatment of certain products (e.g., the European Union's 'Waste Electrical and Electronic Equipment Directive')
- · Industry associations or organizations that have conducted research into consumer disposal patterns of specific products
- · Average data on waste treatment from the point that the products are sold by the reporting company through to the end of life after consumer use.

## Calculation resources include:

- · The European Union publishes data on average end-of-life treatment scenarios of different product groups in EU member countries (see http://epp.eurostat.ec.europa.eu/portal/page/portal/waste/introduction/)
- · The U.S. Environmental Protection Agency also publishes data on waste generation, recycling, and disposal statistics, available at: http://www.epa.gov/osw/nonhaz/municipal/msw99.htm
- · Waste Resources and Action Programme (WRAP) publishes average food and drinks waste as a proportion of purchased amount in the UK economy, which may be used in the absence of product-specific data (see http://www. wrap.org.uk/retail\_supply\_chain/research\_tools/research/report\_household.html).

## Calculation formula [12.1] Waste-type-specific method

## CO 2 e emissions from end-of-life treatment of sold products =

## sum across waste treatment methods:

∑ (total mass of sold products and packaging from point of sale to end of life after consumer use (kg) × % of total waste being treated by waste treatment method × emission factor of waste treatment method (kg CO e/kg)) 2

## Example [12.1] Calculating emissions from the end-of-life treatment of sold products

nd consumers. The company also collects data for emission factors associated with each of the disposal methods for Company A sells paper that is laminated in a way that does not allow recycling. In the reporting period, Company A sold 10,000 tonnes of product. The company conducts consumer research to understand the disposal methods used by e laminated paper products from a life cycle assessment database:

| Mass of waste after consumer use (kg)   | Waste treatment   |   Proportion of waste produced (percent) |   Emission factor of waste treatment method (kg CO 2 e/kg ) |
|-----------------------------------------|-------------------|------------------------------------------|-------------------------------------------------------------|
|                                         | Landfill          |                                       90 |                                                         0.3 |
| 10,000                                  | Incinerated       |                                       10 |                                                         1   |
|                                         | Recycled          |                                        0 |                                                         0   |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

∑ (total mass of sold products at end of life after consumer use (kg) × % of total waste being treated by waste treatment method × emission factor of waste treatment method (kg CO e/kg)) 2 = (10,000 × 90% × 0.3) + (10,000 × 10% × 1) + (10,000 × 0% × 0) = 3,700 kg CO e

2