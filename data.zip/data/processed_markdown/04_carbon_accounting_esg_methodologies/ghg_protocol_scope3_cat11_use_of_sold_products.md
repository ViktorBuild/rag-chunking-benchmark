---
document_id: ghg_scope3_ch11_use_sold_products
title: "Scope 3 Guidance - Category 11: Use of Sold Products"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat11_use_of_sold_products.pdf"
tables_detected: 19
converted_with: "Docling v2.32 (TableFormer)"
---

11

## Category 11: Use of Sold Products

## Category description

T company in the reporting year. A reporting company's scope 3 emissions from use of his category includes emissions from the use of goods and services sold by the reporting sold products include the scope 1 and scope 2 emissions of end users. End users include both	consumers	and	business	customers	that	use	final	products.

The Scope 3 Standard divides emissions from the use of sold products into two types (see also table 11.1):

- · Direct use-phase emissions
- · Indirect use-phase emissions.

In category 11, companies are required to include direct use-phase emissions of sold products. Companies may also account for indirect use-phase emissions of sold products, and should do so when indirect use-phase emissions are expected to be significant. See table 11.1 for descriptions and examples of direct and indirect use-phase emissions.

Category 11 includes the total expected lifetime emissions from all relevant products sold in the reporting year across the company's product portfolio. (Refer to chapter 5.4 of the Scope 3 Standard for more information on the time boundary of scope 3 categories.) See box 11.1 in this chapter for an example of reporting product lifetime emissions and box 11.2 for guidance related to product lifetime and durability. The GHG Protocol Product Standard provides information on accounting for life cycle GHG emissions from individual products.

Companies may optionally include emissions associated with maintenance of sold products during use.

See section 5.6 of the Scope 3 Standard for guidance on the applicability of category 11 to final products and intermediate products sold by the reporting company.

## Table [11.1] Emissions from use of sold products

| Type of Emissions                         | Product Type                                                                                    | Examples                                                                                                                                                             |
|-------------------------------------------|-------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Direct use-phase emissions ( required )   | Products that directly consume energy (fuels or electricity) during use                         | Automobiles, aircraft, engines, motors, power plants, buildings, appliances, electronics, lighting, data centers, web-based software                                 |
|                                           | Fuels and feedstocks                                                                            | Petroleum products, natural gas, coal, biofuels, and crude oil                                                                                                       |
|                                           | Greenhouse gases and products that contain or form greenhouse gases that are emitted during use | CO 2 , CH 4 , N 2 O, HFCs, PFCs, SF 6 , refrigeration and air-conditioning equipment, industrial gases, fire extinguishers, fertilizers                              |
| Indirect use-phase emissions ( optional ) | Products that indirectly consume energy (fuels or electricity) during use                       | Apparel (requires washing and drying), food (re- quires cooking and refrigeration), pots and pans (require heating), and soaps and detergents (require heated water) |

Source: Table 5.8 from the Scope 3 Standard.

Calculating emissions from category 11 typically requires product design specifications and assumptions about how consumers use products (e.g., use profiles, assumed product lifetimes). Companies are required to report a description of the methodologies and assumptions used to calculate emissions (see chapter 11 of the Scope 3 Standard ).

Where relevant, companies should report additional information on product performance when reporting scope 3 emissions to provide additional transparency on steps companies are taking to reduce GHG emissions from sold products. Such information may include GHG intensity metrics, energy intensity metrics, and annual emissions from the use of sold products (see section 11.3 of the Scope 3 Standard ). See section 9.3 of the Scope 3 Standard for guidance on recalculating base year emissions when methodologies or assumptions related to category 11 change over time.

Any claims of avoided emissions related to a company's sold products must be reported separately from the company's scope 1, scope 2, and scope 3 inventories. (For more information, see section 9.5 of the Scope 3 Standard )

## Box [11.1] Example of reporting product lifetime emissions

lso reports corporate average fuel economy (km per liter) and corporate average emissions (kg CO e/km) as relevant An automaker sells 1 million cars in 2010. Each car has an expected lifetime of 10 years. The company reports the anticipated use-phase emissions of the 1 million cars it sold in 2010 over their 10-year expected lifetime. The company a 2 emissions-intensity metrics.

Source: Box 5.7 from the Scope 3 Standard.

## Box [11.2] Product lifetime and durability

emissions increase, assuming all else is constant. To reduce the potential for emissions data to be misinterpreted, Because the scope 3 inventory accounts for total lifetime emissions of sold products, companies that produce more durable products with longer lifetimes could appear to be penalized because, as product lifetimes increase, scope 3 companies should also report relevant information such as product lifetimes and emissions intensity metrics to demonstrate product performance over time. Relevant emissions intensity metrics may include annual emissions per product, energy efficiency per product, emissions per hour of use, emissions per kilometer driven, emissions per functional unit, etc.

Source: Box 5.8 from the Scope 3 Standard.

This section provides guidance of the following:

- · What should be included in the emissions from use of sold products
- · Guidance on what to include in a use profile
- · Reporting guidance
- · Guidance on how to assess uncertainty on the product's use profile.

## Calculating emissions from use of sold products

This guidance provides calculation methods to calculate a company's:

- · Direct use-phase emissions
- · Indirect use-phase emissions.

## Calculation methods for direct use-phase emissions

Companies should first determine in which categories their products belong. The following products have direct-use phase emissions:

- · Products that directly consume energy (fuels or electricity) during use: involves breaking down the use phase, measuring emissions per product, and aggregating emissions
- · Fuels and feedstocks: involves collecting fuel use data and multiplying them by representative fuel emission factors
- · Greenhouse gases and products that contain or form greenhouse gases that are emitted during use : involves collecting data on the GHG contained in the product and multiplying them by the percent of GHGs released and GHG emission factors.

If a company sells a large selection of products, or if the use phase of multiple products is similar, it may choose to group similar products and use average statistics for a typical product in the product group. For example, a fast-moving consumer goods company selling carbonated drinks may decide to group products by packaging types and treat all products within that group with the same use profile.

## Calculation method for direct use-phase emissions from products that directly consume energy (fuels or electricity) during use

In this method, the company multiplies the lifetime number of uses of each product by the amount sold and an emission factor per use. Companies should then aggregate use-phase emissions of all products.

## Activity data needed

- · Total lifetime expected uses of product(s)
- · Quantities of products sold
- · Fuel used per use of product
- · Electricity consumption per use of product
- · Refrigerant leakage per use of product.

## Emission factors needed

- · Life cycle emission factors for fuels
- · Life cycle emission factors for electricity
- · Global warming potential of refrigerants.

## Data collection guidance

- · Data sources for activity data include:
- · Internal data systems
- · Sales records
- · Surveys
- · Industry associations.

Data sources for emission factors include:

- · The GHG Protocol website (www.ghgprotocol.org)
- · Life cycle databases
- · Company or supplier developed emission factors
- · Industry associations.

It is important to consider the region where products are used, especially if the product consumes electricity because electricity grid emission factors can vary significantly. If its product is used globally, a company may consider using a global average electricity emission factor but estimating product use at a more granular level (either regional or national) and applying regional or national electricity grid emission factors would result in more accurate emissions estimates for this category. Scenario uncertainty can also be helpful here.

## Calculation formula [11.1]   Direct use-phase emissions from products that directly consume energy (fuels or electricity) during use

## CO 2 e emissions from use of sold products =

## sum across fuels consumed from use of products:

- ∑ (total lifetime expected uses of product × number sold in reporting period

× fuel consumed per use (kWh) × emission factor for fuel (kg CO e/kWh))

- 2

+

## sum across electricity consumed from use of products:

∑ (total lifetime expected uses of product × number sold in reporting period × electricity consumed per use (kWh) × emission factor for electricity (kg CO e/kWh)) 2

+

## sum across refrigerant leakage from use of products:

- ∑ (total lifetime expected uses of product × number sold in reporting period

× refrigerant leakage per use (kg) × global warming potential (kg CO e/kg)) 2

## Example [11.1]   Calculating direct use-phase emissions from products that directly consume energy (fuels or electricity) during use

Company A is a manufacturer of electrical appliances such as washing machines and irons. It collects sales records of quantities sold as well as average lifetime uses for each of its products. It sources data on electricity consumed per use from industry reports and electricity emission factors from government data. The results are summarized in the table below:

| Product              | Total uses over lifetime   | Number sold   |   Electricity consumed per use (kWh) |   Electricity emission factor (kg CO 2 e/kWh) |
|----------------------|----------------------------|---------------|--------------------------------------|-----------------------------------------------|
| Washing machine X100 | 1,000                      | 11,500        |                                  1.3 |                                           0.5 |
| Washing machine X200 | 1,100                      | 1,900         |                                  1.5 |                                           0.5 |
| Iron Y123            | 2,000                      | 20,000        |                                  0.2 |                                           0.5 |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

## Example [11.1]   Calculating direct use-phase emissions from products that directly consume energy (fuels or electricity) during use (continued)

## Emissions for each product are calculated using the following formula:

∑ (total lifetime expected uses of product × number sold in reporting period × electricity consumed per use (kWh) × emission factor for electricity (kg CO e/kWh)) 2

## Washing machine X100:

= 1,000 × 11,500 × 1.3 × 0.5 = 7,475,000 kg CO e 2

## Washing machine X200:

= 1,100 × 1,900 × 1.5 × 0.5 = 1,567,500 kg CO e 2

## Iron Y123:

= 2,000 × 20,000 × 0.2 × 0.5 = 4,000,000 kg CO e 2

## total emissions from use of sold products

= emissions from X100 + emissions from X200 + emissions from Y123

= 7,475,000 + 1,567,500 + 4,000,000 = 13,042,500 kg CO e

2

## Calculation method for direct use-phase emissions from fuels and feedstocks

Feedstock refers to starting materials that are used to make fuels, power and/or products. These may include biomass for producing power, crops for producing biofuels, or crude oil for producing plastic products. If the reporting company is a producer of fuels and/or feedstocks, the use-phase emissions are calculated by multiplying the quantities of fuels/ feedstocks by the combustion emission factors for the fuels/feedstocks. If the feedstock is not combusted during the use phase, no emissions should be calculated.

Note that only the combustion emissions should be reported in this category, not the upstream emissions associated with the feedstock/fuel. This method avoids double counting as the upstream emissions associated with the production of the feedstock/fuel were already included in the reporting company's scope 1 and scope 2, as well as other scope 3 categories.

## Activity data needed

- · Total quantities of fuels/feedstocks sold.

## Emission factors needed

- · Combustion emission factors of fuel/feedstock.

## Data collection guidance

Combustion emission factors for fuel/feedstock are well documented by many internationally recognized sources such as the IPCC Fourth Assessment Report and those factors included in the GHG Protocol calculation tools. In practice, the emissions vary between applications and countries based on the following:

- · Technology : the completeness of combustion may vary from application to application
- · Exact fuel mix : the precise fuel mix may vary from region to region and company to company; for example, the types of aromatic hydrocarbon mixed with gasoline may alter the combustion emissions.

Because of this variation companies should use the most representative emission factors for their fuel.

## Calculation formula 11.2: Direct use-phase emissions from combusted fuels and feedstocks

## CO 2 e emissions from fuel =

## sum across fuels/feedstocks:

∑ (total quantity of fuel/feedstock sold (e.g., kWh) × combustion emission factor for fuel/feedstock (e.g., kg CO e/kWh)) 2

## Calculation method for direct use-phase emissions from greenhouse gases and products that contain or form greenhouse gases that are emitted during use

Some products may contain GHGs which are emitted during use or at the end of the product's useful life (e.g. products that contain refrigerents).

If the reporting company is a producer of products containing GHGs, use-phase emissions are calculated by multiplying the quantities of products sold by the percentage of GHGs released per unit of GHG contained in the product and by the global warming potential (GWP) of the greenhouse gases released.

## Activity data needed

- · Total quantities of products sold
- · Quantities of GHGs contained per product
- · Percentage of GHGs released throughout the lifetime of the product.

## Emission factors needed

- · GWP of the GHGs contained in the product, expressed in units of carbon dioxide per unit kilogram of the GHG (e.g., 25 kg CO e/kg) 2

Note: If different GHGs are released by the product, the total carbon dioxide equivalent should be reported and the breakdown of GHGs (e.g., CO , CH , N O) may be reported separately (see chapter 8 of the 2 4 2 Scope 3 Standard ).

The company should first account for all the different types of GHGs contained in a product, then aggregate for all products. If the use phase of a product is likely to be similar for multiple products, companies may group similar products.

Calculation formula [11.3]   Direct use-phase emissions from greenhouse gases and products that contain or form greenhouse gases that are emitted during use

## CO 2 e emissions from greenhouse gases and products that contain or form greenhouse gases that are emitted during use =

## sum across GHGs released in a product or product group:

∑ (GHG contained per product × Total Number of products sold × % of GHG released during lifetime use of product × GWP of the GHG)

## then:

sum across products or product groups: ∑ (use phase emissions from product or product group 1,2,3…)

Note: if the % released is unknown 100% should be assumed.

## Calculation methods for indirect use-phase emissions

## Calculation method for indirect use-phase emissions from products that indirectly consume energy (fuels or electricity) during use

For products that indirectly consume energy or emit GHGs (see table 11.1), the reporting company should calculate emissions by creating or obtaining a typical use-phase profile over the lifetime of the product and multiplying by relevant emission factors.

## Activity data needed

- · Average number of uses over lifetime of product
- · Average use scenarios (e.g., weighted average of scenarios)
- · Fuel consumed in use scenarios
- · Electricity consumed in use scenarios
- · Refrigerant leakage in use scenarios
- · GHGs emitted indirectly in use scenarios.

## Emission factors needed

- · Combustion emission factors of fuels and electricity.

Ideally agreement should be reached by a sector (e.g., industry associations and trade bodies) on common rules for usephase assumptions. These assumptions can then be verified by an independent third party to improve consistency and comparability.

The emission factors applied should be representative of the geography of where the product is sold as well as the reporting year.

## Data collection guidance

The generation of a typical use phase may be difficult because the same product may consume more or less energy depending on the conditions in which it is used. For example, a potato may be roasted, boiled, or microwaved, each cooking method using a different amount of energy and thus producing different levels of emissions.

Therefore, it is important to generate a use profile that is representative of use scenarios over the lifetime of the product by the intended consumer population. These may come from sources such as:

- · Industry recognized benchmark testing specifications
- · Product category rules
- · Previous emissions studies
- · Consumer studies.

Companies may choose to identify several different use-phase scenarios for a product and create a weighted average based upon actual activity.

## Calculation formula [11.4]   Indirect use-phase emissions from products that indirectly consume energy (fuels or electricity) during use

## Indirect use-phase CO e emissions of products = 2

## sum across fuels consumed from use scenarios:

∑ (total lifetime expected uses of product × % of total lifetime uses using this scenario × number sold in reporting period × fuel consumed per use in this scenario (e.g., kWh) × emission factor for fuel (e.g., kg CO e/kWh)) 2

+

## sum across electricity consumed from use scenarios:

∑ (total lifetime expected uses of product × % of total lifetime uses using this scenario × number sold in reporting period × electricity consumed per use in this scenario (kWh) × emission factor for electricity (kg CO e/kWh)) 2

+

## sum across refrigerant leakage from use scenarios:

∑ (total lifetime expected uses of product × % of total lifetime uses using this scenario × number sold in reporting period × refrigerant leakage per use in this scenario (kg) × emission factor for refrigerant (kg CO e/kg)) 2

+

## sum across GHG emitted indirectly from use scenarios:

∑ (total lifetime expected uses of product × % of total lifetime uses using this scenario × number sold in reporting period × GHG emitted indirectly (kg) × GWP of the GHG)

## Example [11.2]   Calculating indirect use-phase emissions from products that indirectly consume energy (fuels or electricity) during use

lectricity emission factors from life cycle databases. The data is summarized in the table below: Company A produces laundry soap, which indirectly entails consumption of electricity during the use phase. Company A collects data from consumer journals regarding the average consumer behavior in washing clothes and obtains average e

| Usage tempera- ture setting   | Lifetime uses per product (washes)   |   Consumers using temperature setting (percent) | Products sold   |   Electricity consumed per use (kWh) |   Emission factor (kg CO 2 e/kWh) |
|-------------------------------|--------------------------------------|-------------------------------------------------|-----------------|--------------------------------------|-----------------------------------|
| 30°C cotton wash              |                                      |                                              20 |                 |                                  0.4 |                               0.5 |
| 40°C cotton wash              | 1,000                                |                                              40 | 2,000           |                                  0.5 |                               0.5 |
| 90°C cotton wash              |                                      |                                              40 |                 |                                  1.2 |                               0.5 |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

## emissions for each use phase scenario is calculated as follows:

∑ (total lifetime expected uses of product × % of total lifetime uses using this scenario × number sold in reporting period × electricity consumed per use in this scenario (kWh) × emission factor for electricity (kg CO e/kWh)) 2

30°C cotton wash: 1,000 × 0.2 × 2,000 × 0.4 × 0.5 = 80,000 kg CO e 2

40°C cotton wash: 1,000 × 0.4 × 2,000 × 0.5 × 0.5 = 200,000 kg CO e 2

90°C cotton wash: 1,000 × 0.4 × 2,000 × 1.2 × 0.5 = 480,000 kg CO e 2

## total emissions from use of sold products

= emissions from 30°C + emissions from 40°C + emissions from 90°C = 80,000 + 200,000 + 480,000 = 760,000 kg CO e

2

## Calculation method for sold intermediate products

When a company sells an intermediate product that directly emits GHGs in its use phase, it is required to account for direct use-phase emissions of the intermediate product by the end user, (i.e., emissions resulting from: the use of the sold intermediate product that directly consumes fuel or electricity during use; fuels and feedstocks; GHGs released during product use). Companies may optionally include the indirect use-phase emissions of sold intermediate products.

In certain cases, the eventual end use of sold intermediate products may be unknown. For example, a company may produce an intermediate product with many potential downstream applications, each of which has a different GHG emissions profile and be unable to reasonably estimate the downstream emissions associated with the various possible end uses. In such a case, companies may disclose and justify the exclusion of all downstream emissions related to sold intermediate products. For more information, see section 6.4 of the Scope 3 Standard (Accounting for downstream emissions).

## Activity data needed

- · Type(s) of final product(s) produced from reporting company's intermediate product(s)
- · Percentage of reporting company's intermediate product sales going to each type of final product
- · Activity data required to calculate the use-phase emission of the final product will be the same as described previously in this chapter.

## Emission factors needed

- · Depending on the type of final product, emission factors required will be the same as described earlier in this chapter.

## Calculation formula [11.5] Use-phase emissions from sold intermediate products

## Use-phase CO e emissions of sold intermediate products = 2

## sum across sold intermediate products total use phase emissions:

∑ (total intermediate products sold × total lifetime uses of final sold product × emissions per use of sold intermediate product (kg CO e/use)) 2

## Example [11.3] Calculating use-phase emissions from sold intermediate products

Company A manufactures engines used in airplanes. It sold 10 engines to an airplane manufacturer.

|   Number of engines sold |   Weight of each airplane (tonnes) |   Weight of each engine (tonnes) | Total lifetime uses of final products (km flown by airplane)   |   Emissions per use of final product (kg CO 2 e/km flown) |
|--------------------------|------------------------------------|----------------------------------|----------------------------------------------------------------|-----------------------------------------------------------|
|                       10 |                                500 |                               20 | 300,000                                                        |                                                       0.3 |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data

## Company A works out the direct use-phase emissions of its sold engines as follows:

total use phase emissions = ∑ (total intermediate products sold

× total lifetime uses of final sold product

× emissions per use of sold intermediate product (kg CO e/use) 2

× (weight of engine / weight of airplane))

<!-- formula-not-decoded -->

In this example, physical allocation is most suitable. The allocation is based on the weight of the engine as a proportion of the total weight of the airplane. For allocation rules refer to section 8 of the Scope 3 Standard .