---
document_id: sbti_supplier_engagement
title: "Supplier Engagement Guidance: Cascading Climate Action Across the Supply Chain"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "SBTi / CDP"
year: 2023
original_file: "sbti_supplier_engagement_guidance.pdf"
tables_detected: 24
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## ENGAGING SUPPLY CHAINS ON THE DECARBONIZATION JOURNEY

A GUIDE TO DEVELOPING AND ACHIEVING SCOPE 3 SUPPLIER ENGAGEMENT TARGETS

VERSION 1.1

JULY 2025

## ACKNOWLEDGEMENTS

This guidance was developed by the World Wide Fund for Nature (WWF) on behalf of the Science Based Targets initiative (SBTi). The SBTi is a global body enabling businesses to set ambitious emissions reductions targets in line with the latest climate science. It is focused on accelerating the progress of companies across the world to halve emissions before 2030 and achieve net-zero emissions before 2050.

The initiative is a collaboration between CDP, the United Nations Global Compact, World Resources Institute (WRI) and World Wide Fund for Nature (WWF), and is one of the We Mean Business Coalition commitments. The SBTi defines and promotes best practice in science-based target setting, offers resources and guidance to reduce barriers to adoption, and independently assesses and approves companies' targets.

Primary SBTi Authors: McKenna Smith

Paulina Moreno López

Other contributing authors and technical reviewers:

Alexander Farsan Cynthia Cummis Paola Delgado Luna

Zniko Nhlapho

We also would like to acknowledge the technical review team for this publication:

Emma Watson

Maria Outters

Paulina Tarrant

Supply chain engagement experts from Anthesis and Guidehouse supported the development of this guide. We would like to acknowledge the individuals from these teams who contributed to this project: Amanda Fefferman, Elena Kocherovsky, Hope Bristow, Jeroen Scheepmaker, Matthew Banks, Nicole DelSasso, Nicole Labutong, Shyama Srikkanth, Vincent Hoen.

Finally, we would also like to thank the following companies and institutional contributors which supported this guidance by providing important knowledge and resources: AstraZeneca, Decathlon, Exponential Roadmap Initiative, Fisher &amp; Paykel Healthcare Corporation Limited (F&amp;P), Hennes &amp; Mauritz AB (H&amp;M), Lidl Belgium GmbH. &amp; Co. KG (Lidl Belgium), Salesforce.com Inc. (Salesforce), and Viña Concha y Toro.

## CONTENTS

| 1. Introduction                                                |   4 |
|----------------------------------------------------------------|-----|
| 1.1 WhySupplier Engagement Matters                             |   5 |
| 1.2 About this Guidance                                        |   6 |
| 2. Selecting the right suppliers for the right target          |   7 |
| 2.1 Calculating Scope 3 Emissions                              |   8 |
| 2.2 Determining if a Supplier Engagement Target is Appropriate |  11 |
| 2.3 Identifying Suppliers to Include in the Target             |  15 |
| 3. Securing Internal Buy-In                                    |  17 |
| 3.1 Identifying Internal Stakeholders                          |  18 |
| 3.2 What to Consider When Securing Buy-In                      |  19 |
| 4. Target Implementation                                       |  22 |
| 4.1 Team Roles and Responsibilities                            |  24 |
| 4.2 Defining Supplier Expectations                             |  25 |
| 4.3 Supplier Communications                                    |  25 |
| 4.4 Supplier Resources                                         |  26 |
| 4.5 Selecting a Supplier Data Collection Solution              |  26 |
| 5. Enabling and Tracking Supplier Performance                  |  31 |
| 5.1 Supplier Capacity-Building                                 |  32 |
| 5.2 Supplier Performance Tracking                              |  33 |
| 5.3 Supplier Incentives                                        |  34 |
| 5.4 Reviewing Supplier Science-Based Targets                   |  35 |
| 5.5 Supplier Engagement Program Refinement                     |  36 |
| 6. Monitoring and Reporting Target Progress                    |  37 |
| 6.1 Tracking Progress on Engagement Targets                    |  38 |
| 6.2 Supplier List Management over Time                         |  39 |
| 7. Additional Resources                                        |  40 |
| Climate/GHG Introductory Resources                             |  41 |
| GHG Inventory                                                  |  41 |
| Science-Based Targets                                          |  42 |
| Scope 3 Emission Reductions                                    |  42 |
| Supplier Engagement                                            |  42 |
| Glossary                                                       |  43 |

## 1. INTRODUCTION

## 1. INTRODUCTION

<!-- image -->

## 1.1 WHY SUPPLIER ENGAGEMENT MATTERS

Cross-industry momentum to mitigate climate change and achieve net-zero emissions globally by 2050 continues to grow. However, the acceleration and scale of reduction efforts needs to increase if we are to limit warming to 1.5°C℃. For many companies, supply chain-related emissions are their largest source of emissions, and the most challenging to reduce. Supply chain emissions are on average 11.4 times larger than direct emissions from operations. 1 Activating wide-scale decarbonization efforts across supply chains is one of the most critical, effective pathways to reach global net-zero.

<!-- image -->

Addressing supply chain emissions feels like a daunting task for many companies, often due to their limited visibility and perceptions of limited influence on emission reduction measures. Supplier engagement targets offer a way to influence decarbonization efforts within companies' supply chain when granular emissions data is challenging to track or unavailable. These targets focus on engaging a defined set of suppliers in the near-term to set their own science-based targets on all applicable scopes and categories.

While considerable effort, investment, and internal buy-in is required to create a supplier engagement initiative, companies benefit from building higher-quality supplier relationships, which will enhance efficiency, transparency, and resiliency across the value chain. These efforts build credibility with key stakeholder groups such as investors, customers and employees who increasingly expect companies to take broader responsibility for impacts across their value chain. Supplier engagement also drives a reinforcing feedback mechanism - the more stakeholders taking action on climate change, the easier it becomes for others to work toward similar goals. Companies find that these targets are easier to track, as they only need to ensure that suppliers have set targets aligned to SBTi Criteria. In future resource updates, the SBTi will also be providing more guidance on what is expected of suppliers that are setting targets as part of a company's supplier engagement target program.

1 CDP, 'Scoping Out: Tracking Nature Across the Supply Chain - CDP Global Supply Chain Report 2022," March 2023',

## 1.2 ABOUT THIS GUIDANCE

This guide targets two types of audiences: companies that are considering or are already implementing their SBTi scope 3 supplier engagement targets, as well as companies interested in exploring different supplier engagement tactics to address scope 3 emissions reduction.

This guide outlines how to evaluate and set supplier engagement targets, implement related initiatives and ensure companies fully understand what it takes to achieve these goals. Focusing on supplier engagement targets, this guide will not go in-depth into other scope 3 target-setting approaches. Other supplementary resources to this guide include:

- Slide deck: for companies to use when educating their suppliers on SBTs Case studies : of companies that have supplier engagement targets

This guide is organized following the key stages of the supplier engagement journey, addressing how to:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Companies should also familiarize themselves with other key SBTi resources to ensure they know the basics of what SBTs are, the target criteria, and how to set them

<!-- image -->

## 2. SELECTING THE RIGHT SUPPLIERS FOR THE RIGHT TARGET

<!-- image -->

## 2. SELECTING THE RIGHT SUPPLIERS FOR THE RIGHT TARGET

## 2.1 CALCULATING SCOPE 3 EMISSIONS

<!-- image -->

Before setting any supply chain emission reduction targets, companies must complete a full scope 3 greenhouse gas (GHG) inventory, following the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard, as summarized in Figure 1 below.

Scope 3 emissions must be included in a company's near-term SBT if these emissions represent 40% or more of total scope 1, 2, and 3 emissions. Scope 3 targets must then cover a minimum 67% of total scope 3 emissions, per SBTi near-term Criteria.

Figure 1. The scope 3 inventory process

<!-- image -->

## Value chain mapping

To calculate scope 3 emissions, the first step is to complete a value chain mapping exercise. Companies should review each scope 3 category defined in the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard and identify the complete list of its upstream and downstream activities associated with each.

Figure 2. Overview of GHG Protocol scope 1-3 definitions and activities

<!-- image -->

Source: WRI/WBCSD Corporate Value Chain (Scope 3) Accounting and Reporting Standard(PDF), page 5

## Scope 3 screening

The next step is to conduct a scope 3 screening, which provides an initial emissions estimate across scope 3 categories. This will evaluate which categories are most significant, offer the greatest reduction opportunities, and are most relevant to the company's business goals.

Companies should firstly identify which GHG estimation method will be used and the relevant data owners for each source. Scope 3 screening exercises are normally based on procurement spend data i.e. the total annual amount spent on goods and services, that are converted to GHG emissions using Environmentally Extended Input-Output (EEIO) conversions. Other estimation methods such as industry averages or other proxy data can also be used.

The GHG Protocal Scope 3 Evaluator Tool can help companies start this process - Figure 3 below provides an overview of key criteria needed to determine the relevancy of emission sources.GHG Protocol Scope 3 Standard).

## Figure 3. Criteria for identifying relevant scope 3 activities

| CRITERIA        | DESCRIPTION                                                                                                                                                                                             |
|-----------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Size            | Activities contribute significantly to the company's total anticipated scope 3 emissions                                                                                                                |
| Influence       | There are potential emissions reductions that could be undertaken or influenced by the company                                                                                                          |
| Risk            | Activities contribute to the company's risk exposure (e.g. climate change-related risks such as financial, regulatory, supply chain, product and customer, litigation, and reputational risks)          |
| Stakeholders    | Activities are deemed critical by key stakeholders (e.g. customers, suppliers, investors, or civil society)                                                                                             |
| Outsourcing     | Outsourced activities previously performed in-house. Alternatively, they are activities outsourced by the reporting company that are typically performed in-house by other companies in the same sector |
| Sector guidance | They have been identified as significant by sector-specific guidance                                                                                                                                    |
| Other           | They meet any additional criteria for determining relevance developed by the company or industry sector                                                                                                 |

## Refine scope 3 calculations

Once the screening exercise results have been finalized, companies will understand which scope 3 categories should be prioritized for further scope 3 calculation refinement. The GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard describes the various calculation methodologies that can be used as well as the data required. Companies should ensure both direct and indirect procurement is included, and that all tiers of the supply chain are accounted for. Regardless of methodology, the data feeding the analysis should be easily sortable by supplier for relevant categories (for example, using procurement spend data that can be categorized by supplier as well.

## Continuous data quality improvement

Once all scope 3 calculations are finalized, they are pulled together into a complete scope 3 GHG inventory. The total scope 3 emissions can then be set as the baseline year for reduction targets. As scope 3 emissions are calculated every year, companies should strive for continuous improvement in data quality feeding the inventory as this will enable more robust tracking of emission reduction measures over time.

## 2.2 DETERMINING IF A SUPPLIER ENGAGEMENT TARGET IS APPROPRIATE

For most companies, supply chain-related emissions will represent a substantial portion of their scope 3 emissions. The following categories often make up the greatest share of supply chain emissions:

- Category 1 - Purchased Goods and Services: All upstream (cradle-to-gate 3 ) emissions resulting from of services and products purchased by the company, covering both direct and indirect procurement
- Category 2 - Capital Goods: All upstream (cradle-to-gate) emissions from the production of capital goods purchased by the company, such as facilities, buildings, vehicles, and equipment
- Category 4 -  Upstream Transportation and Distribution: Emissions from all third-party transportation and distribution of products purchased by the company
- 3 Cradle-to-gate covers all production stages, from raw material extraction to the manufacturing of the product/material/component being delivered to your company

<!-- image -->

When a company's supply chain emissions are significant, the next step is to understand whether a supplier engagement target is the best target-setting approach.4 Companies can use a combination of methods as shown in Table 1 below.

## Figure 4. SBTi scope 3 near-term target-setting methodologies (see also SBTi resources)

|            | ABSOLUTE EMISSIONS REDUCTION                                                                                                                | EMISSIONS INTENSITY REDUCTION                                                                                                                              | SUPPLIER ORCUSTOMER ENGAGEMENT                                                                               |
|------------|---------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|
| Definition | Overall %reduction in GHGemissions emitted to the atmosphere in the target year, irrespective of business growth, relative to the base year | %reduction in emissions relative to a specific business metric, either a physical unit of product or per economic $ value added, relative to the base year | Targets to engage a targeted population of suppliers or customers to set their own SBTs                      |
| Example    | Reduce absolute scope 3 emissions from Purchased Goods and Services 45% by 2030 from a 2020 base year                                       | Reduce scope 3 emissions by 50% per unit of product by 2030, from a 2020 base year                                                                         | Suppliers covering 70% of emissions from Purchased Goods and Services will set science-based targets by 2027 |

Companies typically choose the supplier engagement method where:

- There is limited access to primary supplier or product-specific emissions data resulting in a spend-based calculation for related categories (inhibiting the ability to track supplier - or product-level emission reduction measures)
- The supply chain or product mix is extremely complex, which makes tracking supplier or product-specific emission reductions cumbersome and costly
- The company does not produce physical goods, resulting in a footprint primarily driven by indirect procurement. Influence over suppliers - and therefore emissions reduction - may be limited
- Specific emissions reduction levers to achieve the minimum absolute or intensity-based scope 3 targets are not yet identified or difficult to implement
- 4 Consult the SBTi Target Validation Protocol and the Corporate Manual for further information on scope 3 target-setting methods

<!-- image -->

It is vital for companies to know that supplier engagement targets must be achieved within five years of target setting , whereas absolute and/or intensity-based target timeframes can span 5-10 years. Businesses should also consider that:

- Companies are still required to gather and track more granular primary data in the long-term as supplier engagement targets are only valid as a method in near-term target setting. They cannot be used for longterm net-zero targets5
- Supplier engagement targets require a substantial amount of time and resources to implement
- A supplier engagement program will substantially impact Sourcing and Procurement teams and suppliers (as described in sections 3 and 4 of this guide)

## Figure 5. SBT criteria needed to define supplier engagement

<!-- image -->

Boundary: Engagement targets can be used across scope 3 categories where the company has some level of credible engagement with those supplier activities

<!-- image -->

<!-- image -->

Formulation: The target should state what percentage of emissions from relevant categories are covered by the engagement target - or if emissions information is unavailable, what percentage of annual procurement spend is covered (see more in section 2.3)

Timeframe: Engagement targets must be achieved within five years from the target submission date

<!-- image -->

Level of ambition: Suppliers must set targets aligned with the current SBTi Criteria. As SBTi Criteria are occasionally updated, all new supplier targets reported should align with the latest criteria.

5 Consult the SBTi Net-Zero Standard for more information

<!-- image -->

Additionally, suppliers included in supplier engagement targets are expected to:

- Set science-based-aligned scope 1 and 2 targets as a minimum requirement. Inclusion of scope 3 targets are required if these emissions are greater than 40% of a company's total emissions - typically the case for most suppliers
- Review targets to confirm alignment with SBTi Criteria and Guidelines. Validation of supplier targets through the SBTi is recommended but not required6 - if targets are not validated the company must develop a process to review them
- Report progress against their target on an annual basis (either publicly or through the annual data collection process)
- 6 Small and medium-sized enterprise (SME) suppliers have the option of validating targets through the SBTi SME streamlined route (the "SME validation option" section can be consulted in the SBTi Corporate Manual)

<!-- image -->

## 2.3 IDENTIFYING SUPPLIERS TO INCLUDE IN THE TARGET

When creating a supplier engagement target, the next step is deciding who should be included. This analysis determines which elements should be analyzed to decide whether to proceed with a supplier engagement target, such as the total number, type, and size of suppliers that will need to be engaged. Other important factors include the strategic status of the supplier or their GHG program maturity.

As shown in Figure 5, the GHG Protocol's recommended approach is to rank suppliers highest to lowest according to their portion of total emissions, then selecting the total number of suppliers that cumulatively achieve desired scope 3 emissions coverage (i.e. over 67% of total scope 3 emissions to meet the SBTi Criteria). The scope 3 screening and inventory process described in section 2.1 will guide this analysis. However, if a company has trouble screening its value chain or calculating product life-cycle emissions, the simplest selection process is to rank suppliers according to annual spend and selecting those that cumulatively make up a designated percentage of the company's total supplier spend.

Figure 6. Illustrative example of sorting suppliers by scope 3 emissions

Cumulative number of suppliers by scope 3 coverage

<!-- image -->

Number of suppliers

There may be other factors to consider when selecting suppliers to include within the target boundary:

- Leverage over suppliers: How much influence the company has over suppliers and the likelihood that they will respond to the request to set SBTs
- Strategic status of suppliers: Some companies identify strategic suppliers for various business reasons. This can correlate with a willingness on the supplier's side to invest in meeting its customers' SBT expectations
- Sourcing/Procurement trends: It is not uncommon for the supplier list to fluctuate over the five-year timespan of an engagement target. Understanding whether business teams intend to expand or contract relationships with suppliers can help refine the list of which suppliers to target (i.e. including a supplier who may be below the spend threshold in the baseline year, but is expected to gain more business in future years)
- Supplier GHG program maturity: Businesses can evaluate the level of maturity of GHG-related programs by screening suppliers' CDP scores/responses, Environmental, Social and Governance (ESG) reports, or other available questionnaires. Supplier program maturity can help inform SBTs' engagement strategy. Some suppliers may already have SBTs in place, automatically delivering progress towards a supplier engagement target, which can be checked via the SBTi's Target Dashboard. For suppliers without SBTs, it is likely higher-maturity suppliers will require relatively less engagement, whereas middle- or low-maturity suppliers will require more
- Categorizing suppliers: Some companies may segment suppliers per product, by sourcing, or creating sector categories to better tailor the engagement approach. For example, a retailer might track segments such as Food &amp; Beverage, Apparel &amp; Footwear, Home Furnishings, etc. Businesses might prioritize one category over another based on the number of suppliers included, the relative emissions represented, or relevance to the company's priorities and goals
- Suppliers' risk levels: For companies that have conducted climate or environmental risk assessments across their supply chain, the relative level of risk associated with a supplier may influence their decision on which suppliers to include in engagement efforts

Determining the final list of suppliers requires balancing SBTi scope 3 coverage requirements with the business implications of engaging the targeted group of suppliers. This should be reviewed and discussed with key stakeholders across Sourcing and Procurement, and any other relevant business teams prior to committing to a supplier engagement goal. The next section will cover best practices related to such internal alignment

<!-- image -->

## 3. SECURING INTERNAL BUY-IN

<!-- image -->

## 3.1 IDENTIFYING INTERNAL STAKEHOLDERS

Understanding whether to proceed with a supplier engagement target is a decision which should not be made in isolation by sustainability teams. Achieving these targets requires all relevant business teams to understand them and commit to playing their part. It is critical to identify these internal stakeholders, understand their perspectives as well as define their roles and responsibilities in implementing a supplier engagement program - from the start.

<!-- image -->

Every company is structured differently, so various types of stakeholders may need to be selected. Companies should consider SBT emission categories, what measures would need to be taken to address them, and who needs to be engaged in the process. For supply chain-related emissions - and specifically supplier engagement targets - relevant teams include:

- Relevant senior leadership
- Sustainability/ESG teams
- Sourcing and Procurement
- Compliance/Legal
- Product
- Accounting/Finance

Senior leaders and other individuals playing a key role in implementing the program should be engaged during the target evaluation process. Ideally, a multi-stakeholder team can support the program's deployment and is held accountable through leadership oversight and performance incentives.

## 3.2 WHAT TO CONSIDER WHEN SECURING BUY-IN

When working with these leaders and business teams, it's important to understand the perspective and priorities of these individuals, such as:

- What are these audiences' primary concerns?
- What level of SBT knowledge-building is required?
- How should the benefits or opportunities of the new initiative be framed for each group?

## Figure 7. Examples of stakeholder perspectives related to supplier engagement

| STAKEHOLDER                                                                                                                                                                  | ROLE IN SUPPLIER ENGAGEMENT                                                                                                                                             | PRIORITIES HOWTOFRAMETHE INITIATIVE                                                                                                 |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------|
| Initial driver for setting an SBT Technical support and training on GHGemissions and SBTs Calculating and tracks scope 3 emissions                                           | Driving the company's sustainability performance and implement associated initiatives Ensuring climate leadership and credibility                                       | ESG & Sustainability A leading practice in sustainability and GHG management                                                        |
| Sign off on SBTs Program oversight and performance tracking Resource enablement                                                                                              | Business performance and meeting objectives External stakeholder expectations Company credibility and reputation                                                        | Senior leadership Creating business value Meeting external stakeholder expectations                                                 |
| Primary contact for suppliers, managing contracts Integrating supplier expectations and requirements into existing processes Supporting supplier training and accountability | Streamlining procurement processes Ensuring teams understand supplier expectations and are supported in the process Getting technical support from sustainability teams | Sourcing & Procurement Opportunity to enhance supplier quality, relationships, and collaboration Prioritize folding initiative into |
| Supplying annual direct and indirect procurement spend data Implementing any financial supplier incentives (i.e. payment terms)                                              | Ensuring no interruptions to supplier business agreements or processes Understanding required data needs and timing                                                     | Accounting & Finance Present a clear timeline on annual data request and requirements                                               |

Preparing appropriately for stakeholder conversations and framing the tasks to address their perspectives and priorities will increase the likelihood that buy-in for the goal is eventually secured.

## Figure 8. Materials companies need to prepare for internal stakeholder conversations

<!-- image -->

<!-- image -->

Thinking through the supplier engagement strategy and implementation plan ahead of securing buy-in will enable more productive conversations with stakeholders and the ability to set realistic expectations of what it will take to achieve the goal. At this stage, the strategy does not need to be detailed. However, core aspects of the program should be considered, such as defining supplier expectations, channels, and frequency of supplier communications and data collection, and what resources are required to support suppliers.

There will be varying perspectives on how much to invest in the effort as well as the level of engagement that can and should be delivered to suppliers throughout the journey. However, simply asking suppliers to set SBTs is unlikely to drive the level of action required to meet these goals within five years. Supplier training, capacitybuilding, and incentives will likely be required to drive action, although these efforts can be built up progressively over time. Further information is covered in section 5 of this guide.

Once successful buy-in is secured for proceeding with the SBT, the targets can be submitted to the SBTi for final validation. Detailed resources and forms for this process are listed on the SBTi Services website.

<!-- image -->

## 4. TARGET IMPLEMENTATION

<!-- image -->

## 4. TARGET

## IMPLEMENTATION

Preparation for supplier engagement target implementation should begin as soon as there is internal buy-in to proceed.

## Figure 9. Key program components required to define an implementation plan

<!-- image -->

<!-- image -->

## TEAM ROLES AND RESPONSIBILITIES

Implementing a supplier engagement program is a team effort. However, there should be one individual who is the primary program manager to ensure successful progress towards meeting the company's target. Ideally, this individual is someone embedded within the Sourcing and Procurement team to ensure smooth integration with existing supplier relationship management processes and systems.

Nevertheless, identifying someone in this role may be difficult and could require identifying someone who is passionate about sustainability and the capacity to take on the required responsibilities. It could also mean creating and hiring for a new role to manage the program.

The program manager should already have a solid understanding of SBT-related topics or will be closely supported by experts in the sustainability team. Embedding formal objectives and incentives for this individual to drive the progress forward will further ensure accountability and the program's success.

Representatives from the stakeholder groups described in section 3 will typically make up the supplier engagement program team and support the program's implementation. It is important to align team members' roles and responsibilities to ensure expectations are set from the start. Designated roles in this type of program include:

- The program manager: Brings together the implementation team, leads the program's management and develops accountability and monitoring frameworks
- The program sponsor and other leadership stakeholders: Senior oversight of monitoring program progress and helps secure resources and budget
- Sourcing and Procurement category leads and/or managers: Primary point of contact for suppliers, likely to manage communications to suppliers and fielding their questions
- SBT/GHG technical expert: Typically, someone from the sustainability/ESG team who understands technical SBT requirements and can support internal teams and suppliers on these topics
- Communications support: Leads development of supplier-facing communications and potentially supports external reporting of the program's progress
- Data management/analytics support: Leads or supports supplier data collection, creates and implements data collection solution, analyzes supplier data to determine performance and progress
- Legal: Supports any component of the program involving contracts, codes of conduct, or other agreements

Teams must be trained on new supplier expectations, how to provide support to suppliers, and share relevant resources. Developing internal materials, such as a one-page program overview or FAQs, may be helpful for suppliers.

<!-- image -->

## DEFINING SUPPLIER EXPECTATIONS AND TIMELINES

There is just one core criteria for supplier engagement targets: whether the supplier has set an SBTi-aligned target within the five-year target timeframe. However, there may be other supplier expectations that support this objective that teams will need to define upon program initiation. For example, there will need to be a mechanism to gather information from suppliers on where they are in the process of setting SBTs.

The team needs to determine how often and through which channels suppliers need to report this data. The team also needs to align on how expectations will be framed to suppliers: is setting and reporting SBTs positioned as a 'requirement', 'expectation', or 'encouraged'? This has implications for procurement processes, such as updates to supplier contracts and codes of conduct, as well as enforcement mechanisms.  More on this topic is covered in the 'Supplier Incentives' section 5.3 below.

<!-- image -->

## SUPPLIER COMMUNICATIONS

It is important to keep suppliers informed on SBT expectations, including why the initiative is being prioritized, providing them with relevant materials and making clear why certain data and information will be requested.

Follow-up information-sharing and reminders may come from other contacts, such as the primary Sourcing and Procurement manager(s) who typically interact with the suppliers. These teams should be prepared to respond to suppliers' questions, and know where to find additional information.

Companies should determine where this information communications should come from and how frequently it should be delivered.

A strong initial statement which explains what SBTs are will set the tone for the initiative. Ideally, this message should come from a senior leader and demonstrate the company's commitment, set the context for the initiative, and provide helpful information for suppliers to understand SBTs.

Lastly, it is worth noting that identifying the most adequate supplier contact may take some time. Often, the existing business contact will not have the knowledge or capacity to respond to SBTrelated requests, and will need to provide another sustainability-related contact.

<!-- image -->

## SUPPLIER RESOURCES

SBTs and GHG emissions topics may be unfamiliar for many suppliers. Simply asking suppliers to set SBTs may be difficult as many suppliers may not know how to get started. Even more advanced suppliers may not understand what qualifies a GHG reduction goal as 'science-based'.

Developing resources to guide suppliers in the SBT-setting process is key. There are many, helpful external documents in the 'Additional Resources' section at the end of this guide.

Resources should support suppliers along the journey from understanding basic climate-related topics, to calculating their GHG emissions, through to setting and implementing science-based targets. Companies may find it helpful to consider which resources were most valuable in their own journey to setting SBTs. Such materials can be delivered to suppliers progressively over time. However, providing suppliers with resources at the start ensures they are well-informed from the beginning of the process. Additional information on more active forms of training and capacity-building are covered in section 5.

<!-- image -->

## SELECTING A SUPPLIER DATA COLLECTION SOLUTION

To track progress towards supplier engagement targets, companies need to implement an effective supplier information or data-collection solution. This data is critical to building an effective supplier engagement program, both for target-tracking purposes and to enable visibility of supplier GHG program maturity. This step will also gather primary emissions data that can be used to refine the company's own GHG emissions calculations and reduction tracking in the future.

<!-- image -->

When identifying a data collection solution, companies should consider the following questions:

- Is the aim to gather only climate-related data, or will there be other ESG data needs?
- Does the company want to use an existing 'out-of-the-box' solution or a proprietary questionnaire?
- Is there an industry reporting tool which could be used to avoid duplicate requests across shared suppliers?

Suppliers are likely facing a variety of similar ESG-related requests from their customers. Identifying a solution which addresses survey burdens increases the probability of collecting more data of a higher quality. Numerous supplier data collection tools which address this through standardized surveys that can be shared with customers, are already available. An additional benefit is that companies do not need to invest time in developing their own questionnaire. The trade-off is that standardized questionnaires may not perfectly meet the company's data needs and tend to be more extensive to meet a wider stakeholder groups' needs.

## Figure 10. Examples of existing standardized supplier data collection solutions

<!-- image -->

| TOOL                 | ESG TOPICS INCLUDED                | DESCRIPTION                                                                                                                                                     |
|----------------------|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| CDP Supply Chain     | Climate, water, forests            | Allows companies to request data from hundreds of key suppliers through CDP questionnaires and receive support from CDP through the supplier engagement process |
| EcoVadis             | Various sector-specific ESG topics | Helps companies manage their supply chains by increasing coordination with suppliers and ensuring they adhere to company standards                              |
| Guidehouse Papaya TM | Climate                            | Sustainability platform which enables the collection of supplier data, management of GHGfootprinting, and tracking of ESG metrics                               |
| RBA-Online           | Various ESGtopics                  | Enables reporting and environmental data sharing of a company's carbon emissions, water use, and waste generated                                                |
| SupplyShift          | Various ESGtopics                  | Enables suppliers and businesses to develop transparency in their supply chain efforts while working to minimize risks                                          |
| Higg Index           | Various ESGtopics                  | Provides companies with access to Higg tools, granting companies access to production data at supplier facilities                                               |

If a proprietary data collection solution is preferred, companies should align their questions with more commonly-used, standardized surveys to ensure suppliers can leverage information they are already collecting, which will reduce 'survey fatigue'.

Beyond data collection, companies should consider whether their selected solution supports other aspects of their engagement program. For example a solution that has capabilities to provide support with supplier communications, sharing of resources, data analytics, and data verification.

Working with key internal stakeholders such as sustainability and compliance teams early in the process, to determine whether other ESG data may be required, will streamline supplier data requests, and optimize the company's systems, processes, and costs.

Data collected from suppliers should at least provide information on their GHG emission reduction targets so they can be validated against SBTi Criteria.

## Figure 11. Data required from suppliers to set SBTs

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|       | Whether the supplier has an emission reduction target In addition to yes/no options - including the options to state either that a target is in the process of being developed or planned to be developed within 1-2 years - will help provide insight of where suppliers are in their journey   |
|-------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|       | Target boundary Which scopes and emissions categories are covered and whether the target is at the corporate or facility level                                                                                                                                                                   |
|       | Target coverage What portion of included scopes and categories are covered                                                                                                                                                                                                                       |
| A I E | Target type Absolute, intensity, or engagement ( see Table 1 )                                                                                                                                                                                                                                   |
|       | Baseline year The base year from which progress is measured                                                                                                                                                                                                                                      |
|       | Target year The year in which the target will be achieved                                                                                                                                                                                                                                        |
|       | Targeted reduction/ambition The targeted percentage reduction from the baseline. Provide the option to report an intensity unit if an intensity target is selected (e.g. reduction per unit/currency)                                                                                            |
|       | Whether the target has been validated by the SBTi                                                                                                                                                                                                                                                |

In addition to collecting supplier target details, companies may choose to gather additional quantitative data, such as supplier GHG emissions, to understand suppliers' climate programs. Businesses should carefully consider how they will use and analyze the data collected from suppliers to avoid gathering data just for data's sake. Working with an expert that can help evaluate and guide this process is recommended

<!-- image -->

Suppliers should have the option to report multiple targets (for example, a scope 1 and 2 target and a separate scope 3 target).

Although primary GHG emissions data is not required to track progress against a supplier engagement target in the near-term, in the long-term it will be necessary to track reductions in supply chain emissions. It is also an indicator of where suppliers are in their journey and enables review of the quality of emissions data being reported.

## Figure 12. Aspects of supplier GHG emissions to consider collecting

<!-- image -->

## Total annual scope 1 and 2 emissions

## Total scope 3 emissions

<!-- image -->

- Scope 1 and 2 emissions broken down by sources (i.e. fuel types)
- Any emission sources excluded from the quantities reported
- Scope 1 and 2 emissions intensity (per selected unit or currency)
- Scope 1 and 2 emissions allocated/apportioned to the customer 7
- A description of methodologies followed in calculating scope 1 and 2
- Scope 3 emissions broken down by category
- Any emission sources excluded from the quantities reported across categories
- Scope 3 emissions intensity (per selected unit or currency)

Scope 3 emissions allocated/apportioned to the customer 8

- A description of methodologies followed in calculating scope 3 categories

<!-- image -->

Any product-level Life-Cycle Assessment (LCA) data, if available

Which portion of emissions have been third-party verified, if any

<!-- image -->

- 7 Methodologies to allocate emissions to a particular customer may include as a percentage of revenue or production, or by using production process-level emissions data if available
- 8   If scope 3 emissions are greater than 40% of total greenhouse gas emissions

Once a data collection solution has been identified, the timeline should be integrated into the overall program implementation plan. Some companies may choose a phased approach for data collection, starting with a subset of targeted suppliers in the first year to test the process, then progressively expand to a wider range of suppliers each subsequent year. Others prefer to initiate data collection with all targeted suppliers straight away.

Companies may face concerns from suppliers about data confidentiality. Suppliers may be sensitive to sharing more granular GHG inventory data (for example, emissions specifically allocated to their customer) as this information could be reverse-engineered to estimate percentage of production and other sensitive business information. To build trust and mitigate these issues, companies should consider the following guidelines:

## Figure 13. Guidelines for companies to consider

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Demonstrate the company's own actions to track and manage emissions

Companies must share how they manage GHG emissions within their own organizational boundaries if they are to credibly ask suppliers to do the same

## Consider the type of data being requested

Survey questions requesting details regarding production (percentage of unit volumes, specific locations, proprietary product information, etc.) should be carefully considered for privacy reasons

## Respect business-sensitive information

Establish internal processes to ensure suppliers' data is only used for environmental tracking purposes and will not be shared with individuals or teams that may mishandle the information. Communicate what measures are being taken to protect sensitive information with suppliers

## Leverage technology

External solutions such as the CDP Supply Chain, RBA-Online, the Higg Index, and other similar systems offer an added layer of functionality that help maintain supplier data ownership and confidentiality

<!-- image -->

## 5. ENABLING AND TRACKING SUPPLIER PERFORMANCE

<!-- image -->

## 5. ENABLING AND TRACKING SUPPLIER PERFORMANCE

## 5.1 SUPPLIER CAPACITY-BUILDING

Once a supplier engagement program has been launched, companies must assess approaches to drive progress towards their goal. Engagement strategies should take into account that suppliers are at varying stages of their climate journey, and require varying levels of guidance and support. Although supplier resources provided in section 4.4 are a useful starting point for most suppliers, they may not be enough to drive the level of action required to meet engagement targets. More direct, hands-on training on how to calculate emissions and set SBTs may be required with targeted groups of suppliers.

Methods for delivering capacity-building training can include:

- Workshops
- One-on-one coaching
- Expert 'office hours' or email support
- E-learning and other online-based training such as webinars

For most companies deploying these programs, time and resource availability will dictate the extent to which they can develop and deploy such training. Companies should be strategic in prioritizing methods of supplier capacity-building support, and which suppliers to offer the training to. Internal or external sustainability experts can also be leveraged to support these efforts and ensure effective delivery of technical information. To pool resources, companies can also reach out to industry peers to deliver collaborative training.

E

## 5.2 SUPPLIER PERFORMANCE TRACKING

## Figure 14. The stages of a supplier's journey towards SBTs

<!-- image -->

Although it may take suppliers more time, tracking and addressing these emissions is required to achieve longer-term targets. Companies should consider encouraging suppliers to conduct scope 3 screenings earlier in the process to determine if they will need to address these emissions in their targets.

The data collected from suppliers (described in section 4.5) should help track where suppliers are in this journey. As data is gathered, companies can develop a framework to categorize performance based on indicators of program maturity. For example, developing defined categories for low/medium/high maturity based on factors such as the status of their GHG inventory, target-setting, and reporting.

Tracking how many suppliers are in each performance category, e.g. by spend or emissions, allows for a systematic way to monitor progress, determine the type of training that may be useful at each stage, and prioritize where to emphasize efforts. Some companies choose to convert this type of performance tracking into a supplier scorecard, which can be an effective way of holding suppliers accountable to demonstrating progress. A scorecard also provides Sourcing and Procurement teams with a clear metric to facilitate engagement.

<!-- image -->

## Figure 15. Illustrative example of a climate maturity progress tracking dashboard

<!-- image -->

## 5.3 SUPPLIER INCENTIVES

Deploying incentives to drive supplier action to track emissions and set SBTs can be a powerful mechanism to accelerate progress. Approaches can vary, from 'carrot' measures that reward suppliers for demonstrating climate leadership, versus 'stick' approaches that penalize suppliers who have not made sufficient progress. Companies should work with internal stakeholders to determine which measures are feasible within their organization, and how to implement them.

Incentive mechanisms to consider:

- Supplier recognition: Rewarding suppliers that demonstrate leadership, whether publicly or amongst key audiences such as other suppliers, industry peers, and investors
- Supplier scorecards: Defining key performance indicators (KPIs) and metrics that provide a snapshot of supplier performance in a scorecard format, shared with the suppliers and their relevant Sourcing and Procurement contacts. Such KPIs can be integrated into broader supplier performance scorecards if they are used by the business, and reviewed during regular business reviews
- Supplier benchmarking: Sharing anonymized benchmarking reports that show suppliers how they are performing against their peers across key performance metrics. These can be similar to KPIs used in supplier scorecards
- Adding requirements to supplier contracts: Including requirements related to climate action in supplier Codes of Conduct and/or contracts that suppliers must agree to maintain the business relationship
- Business benefits tied to performance: Any measures that reward suppliers' climate performance with more work or preferential business terms, such as longer term contracts or shorter payment terms
- Business penalties: Financial or other business penalties for supplier inaction, such as escalation through Sourcing and Procurement leadership, less attractive business terms, and - at the most extreme level - contract termination

- Other financial incentives: Leveraging external partners providing financial or business benefits, such as better financing terms or faster order payouts
- Industry coalitions: Forming an alliance with industry peers who share suppliers to motivate suppliers to set targets - the more customers signal this is a priority, the more likely the supplier will take action

Additional approaches are outlined in The World Business Council for Sustainable Development's (WBCSD's) Reaching Net Zero: Incentives for Supply Chain Decarbonization report.

Incentives should be clearly and consistently communicated to suppliers to ensure the implications of meeting expectations. Some companies may progressively layer in new incentives as their program matures to enhance the impact of these measures.

## 5.4 REVIEWING SUPPLIER SCIENCE-BASED TARGETS

As engagement programs progress, companies need an approach to ensure supplier SBTs align with SBTi Criteria to credibly contribute towards their engagement target. Validation of supplier targets through the SBTi is encouraged but not required - although this level of validation offers an effective way for companies to count supplier targets against their engagement goal. Companies may find that some of their suppliers have already set SBTi-validated targets, and can check their supplier list on SBTi's Target Dashboard. SME suppliers can opt for the SBTi's streamlined SME route.

Suppliers who do not validate targets via the SBTi need to submit their target details through the data collection process. It is important to ensure that the right level of target detail is collected to enable cross-checking against SBTi Criteria, as mentioned in section 4.5. Companies should check that suppliers' targets meet the latest SBTi boundary, timeframe, and ambition criteria.

Companies should clearly communicate the results of SBT reviews with suppliers and provide explicit feedback if certain criteria are not met, so the supplier can course-correct. If targets are met, the supplier should be positively acknowledged for progress made and encouraged to continue reporting progress. When targets do not meet criteria, companies may want to consider offering a method for correcting and resubmitting the target, as opposed to waiting for the next annual data collection cycle. This is also an excellent opportunity to provide capacity-building engagement and support these suppliers in understanding the criteria, rationale, and implications of these targets.

As suppliers successfully set SBT-aligned goals, companies need to develop a central, systematic way of tracking this progress. More detail on this is provided in section 6

<!-- image -->

## 5.5 SUPPLIER ENGAGEMENT PROGRAM REFINEMENT

Every year, companies should review how their supplier engagement program is performing to see what has worked and what needs to be improved. Companies may want to work with internal stakeholders on a program debrief to check on communicating with suppliers, training and capacity-building, data collection, and supplier incentives, to identify improvements. Some companies may engage directly with suppliers to collect feedback on what will support suppliers along their journey most effectively. Companies should also look at supplier performance data to determine whether there are certain categories needing additional support, and whether an engagement re-prioritization is necessary.

Once opportunities for improvement are identified, a revised annual engagement plan can be developed that details the timing and processes for the various program components, and who is responsible for seeing those through. Reviewing and refining the program each year is crucial to ensuring suppliers stay on track to meeting their own SBTs.

<!-- image -->

## 6. MONITORING AND REPORTING TARGET PROGRESS

<!-- image -->

## 6. MONITORING AND REPORTING TARGET PROGRESS

## 6.1  TRACKING PROGRESS ON ENGAGEMENT TARGETS

The data which companies need to collect from suppliers are essential to track progress. Companies will need to analyze and report progress annually to satisfy basic requirements from the SBTi. For any SBT, it is best practice to transparently report on methodologies, assumptions, and data sources used for tracking annual performance. For engagement targets, companies should report how they are tracking and qualifying supplier SBTs towards their own goal.

To do this effectively, it is best to create a central repository for tracking all supplier targets and performance that is actively managed and updated by the core engagement team.

The tracker should include the full list of suppliers that are in scope, any relevant categorization or identification information (% of emissions, % of spend, supplier IDs, categories, etc.), and their current SBT status. Including additional climate maturity indicators may also be helpful. This tracker's goal is to summarize how many suppliers have set SBTs as a percentage of total emissions or spend, and 'house' data used determine how the company is progressing towards achieving its supplier engagement target. It is critical for companies to define a systematic and auditable process for updating and maintaining this data over time to ensure credible reporting of engagement target progress. This will prepare companies for any future SBTi Measurement, Reporting, and Validation (MRV) framework for assessing progress against such targets.

## Figure 16. Key considerations in target progress monitoring and reporting

<!-- image -->

Report on methodologies, assumptions, and data sources used for tracking annual performance against targets

<!-- image -->

<!-- image -->

<!-- image -->

Define a systematic and auditable process for updating and maintaining supplier list data

Refresh scope 3 inventory and related supplier data annually over the target timeframe

Consider third-party verification on scope 3 calculations that determine the targeted list of suppliers

## 6.2 CONTINUOUS SUPPLIER LIST MANAGEMENT

Companies should also acknowledge that their supplier list will fluctuate every year, which may impact performance against an engagement target. Companies will need to refresh their scope 3 inventories and related supplier data annually over the target timeframe.

This will determine which suppliers add up to the required threshold of emissions or spend stated in the target, and how this impacts overall tracking of the percentage of suppliers that have set SBTs. For example, if a company sets a goal to target 70% of its suppliers by emissions, then it will recalculate the portion of scope 3 emissions each supplier represents annually, and tally up the list until the 70% threshold is covered. This means that there may be new suppliers added to the list, other suppliers that shift beyond the emissions/spend threshold, and others that the company may discontinue business with. Best practices in managing annual changes to the supplier list include:

- Inviting new suppliers to set SBTs each year if they enter the target threshold 9
- Continuing to engage any suppliers that fall below the target threshold but were already invited to set SBTs
- Working with Sourcing and Procurement teams to anticipate future business trends with targeted suppliers and adjust engagement prioritization accordingly

Such changes should be easily visible in the central target progress tracking solution, and results should be recalculated and reported annually. Companies can report target progress through their preferred sustainability and climate reporting channels. Companies can work with third parties to validate scope 3 calculations that determine the targeted list of suppliers each year. They can offer an additional layer of confidence that credible and effective target reporting is maintained.

- 9 Suppliers should be given at least two years to set SBTs to provide sufficient time to set a baseline GHG emissions and establish SBTs. Companies should still invite new suppliers to set targets within the last two years of their engagement target, but should allow suppliers more time to do this

## 7. ADDITIONAL RESOURCES

<!-- image -->

## 7. ADDITIONAL RESOURCES

| CLIMATE/GHG INTRODUCTORY RESOURCES              |
|-------------------------------------------------|
| Project Drawdown Climate Solutions              |
| GHG INVENTORY                                   |
| The Greenhouse Gas Protocol                     |
| The Corporate Accounting and Reporting Standard |
| Corporate Scope 3 Standard                      |
| Scope 3 Evaluator Tool                          |
| US EPA GHGInventory Development Guidance        |
| US EPA GHGCalculator                            |
| EPA Emissions Factors                           |
| DEFRA Emission Conversions                      |
| WWFEmission Possible                            |
| GZA Scope 3 Calculator                          |

| SCIENCE-BASED TARGETS       |
|-----------------------------|
|                             |
|                             |
|                             |
|                             |
|                             |
| SCOPE 3 EMISSION REDUCTIONS |
|                             |
|                             |
|                             |
|                             |
| SUPPLIER ENGAGEMENT         |
|                             |
|                             |
|                             |
|                             |

<!-- image -->

## GLOSSARY

## GLOSSARY

| TERM                       | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
|----------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ABSOLUTE EMISSIONS TARGET  | A target that aims to reduce GHGemissions a company emits by a set amount, by a target year, relative to levels in a selected base year                                                                                                                                                                                                                                                                                                                       |
| BASE YEAR                  | The period in history against which a company tracks performance over time                                                                                                                                                                                                                                                                                                                                                                                    |
| CO2 EQUIVALENT (CO2e)      | A unit used to express the global warming potential of different greenhouse gasses as a single figure, namely the equivalent amount or concentration of carbon dioxide                                                                                                                                                                                                                                                                                        |
| EEIO                       | Environmentally extended input-output                                                                                                                                                                                                                                                                                                                                                                                                                         |
| EMISSIONS INTENSITY TARGET | A reduction in emissions relative to a specific business metric, such as production output or a company's financial performance (e.g. tonne CO 2 e per tonne product produced or value added). The target is achieved by a target year relative to levels in a base year                                                                                                                                                                                      |
| GREENHOUSE GAS (GHG)       | A gas that absorbs and emits radiation in the atmosphere, contributing to the greenhouse effect. GHGs include water vapor, carbon dioxide, methane, nitrous oxide, ozone, and chlorofluorocarbons (CFCs)                                                                                                                                                                                                                                                      |
| NET-ZERO                   | The SBTi Net-Zero Standard defines corporate net-zero as: Reducing scope 1, 2, and 3 emissions to zero or to a residual level that is consistent with reaching net-zero emissions at the global or sector level in eligible 1.5°C-aligned pathways Neutralizing any residual emissions at the net-zero target year and any GHG emissions released into the atmosphere thereafter For more detailed definitions, refer to the SBTi Corporate Net-Zero Standard |
| REDUCTION LEVERS           | Approaches to reduce a company's climate impact. Can refer to projects, programs, business decisions or other actions that reduce emissions. These approaches can either reduce the activity driving emissions, improve the GHGintensity of those activities, or both                                                                                                                                                                                         |
| SCIENCE-BASED TARGETS      | Emissions reduction targets in line with what the latest climate science deems necessary to meet the goals of the Paris Agreement - limiting global warming to 1.5°C                                                                                                                                                                                                                                                                                          |
| SCOPE 1 EMISSIONS          | Greenhouse gas emissions from sources owned or controlled by the reporting company                                                                                                                                                                                                                                                                                                                                                                            |
| SCOPE 2 EMISSIONS          | Greenhouse gas emissions from generation of electricity, heat, or steam purchased by the reporting company                                                                                                                                                                                                                                                                                                                                                    |

## GLOSSARY

| TERM                   | DEFINITION                                                                                                                                                                                                                                                                                                                                                                          |
|------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| SCOPE 3 EMISSIONS      | All other indirect greenhouse gas emissions from sources located along the reporting company's value chain                                                                                                                                                                                                                                                                          |
| SPEND DATA             | Data on the amount of money a company spends on various purchased goods and services                                                                                                                                                                                                                                                                                                |
| SUPPLY CHAIN EMISSIONS | In the context of this guide, these are upstream emissions in category 1 - purchased goods and services, of the GHGProtocol Corporate Value Chain Accounting and Reporting (scope 3) Standard. However, as per the SBTi Criteria and Recommendations, companies may include other supplier-related upstream scope 3 categories in the boundary of their supplier engagement targets |
| TARGET YEAR            | The year by which a company intends to meet the emissions reduction committed to a target                                                                                                                                                                                                                                                                                           |
| TIER 1 SUPPLIERS       | Companies that the reporting company has a purchase order with for goods or services (e.g. materials, parts, components, etc.)                                                                                                                                                                                                                                                      |
| TIER 2 SUPPLIERS       | Companies that supply goods and services to Tier 1 suppliers (i.e. companies that Tier 1 suppliers have a purchase order with for goods and services)                                                                                                                                                                                                                               |

<!-- image -->

## LIST OF ABBREVIATIONS

| ABBREVIATION   | MEANING                                   |
|----------------|-------------------------------------------|
| CFCS           | Chlorofluorocarbons                       |
| CO2            | Carbon dioxide                            |
| CO2e           | Carbon dioxide-equivalent                 |
| EEIO           | Environmentally extended input-output     |
| ESG            | Environmental, Social and Governance      |
| GHG            | Greenhouse gas                            |
| IPCC           | Intergovernmental Panel on Climate Change |
| KPI            | Key performance indicator                 |
| LCA            | Life-cycle assessment                     |
| MRV            | Measurement, reporting and verification   |
| RFP            | Request for proposals                     |
| SME            | Small- and medium-sized enterprises       |
| SBT            | Science-based target                      |

<!-- image -->

For general information and technical queries contact us at: info@sciencebasedtargets.org

<!-- image -->

@ScienceTargets

/science-based-targets

<!-- image -->

<!-- image -->

Partner Organizations:

<!-- image -->

<!-- image -->

Science Based Targets

<!-- image -->

<!-- image -->

In collaboration with:

<!-- image -->