---
document_id: ghg_scope3_ch02_capital_goods
title: "Scope 3 Guidance - Category 2: Capital Goods"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat02_capital_goods.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

2

## Category 2: Capital Goods

## Category description

<!-- image -->

T his  category  includes  all  upstream  (i.e.,  cradle-to-gate)  emissions  from  the production of capital goods purchased or acquired by the reporting company in the reporting year. Emissions from the use of capital goods by the reporting company are accounted for in either scope 1 (e.g., for fuel use) or scope 2 (e.g., for electricity use), rather than in scope 3.

Capital goods are final products that have an extended life and are used by the company to manufacture a product; provide a service; or sell, store, and deliver merchandise. In financial accounting, capital goods are treated as fixed assets or as plant, property, and equipment (PP&amp;E). Examples of capital goods include equipment, machinery, buildings, facilities, and vehicles.

In certain cases, there may be ambiguity over whether a particular purchased product is a capital good (to be reported in category 2) or a purchased good (to be reported in category 1). Companies should follow their own financial accounting procedures to determine whether to account for a purchased product as a capital good in this category or as a purchased good or service in category 1. Companies should not double count emissions between category 1 and category 2. See box 2.1 for accounting for emissions from capital goods.

## Box [2.1] Accounting for emissions from capital goods

In financial accounting, capital goods (sometimes called 'capital assets') are typically depreciated or amortized over the life of the asset. For purposes of accounting for scope 3 emissions, companies should not depreciate, discount, or amortize the emissions from the production of capital goods over time. Instead companies should account for the total cradle-to-gate emissions of purchased capital goods in the year of acquisition, the same way the company accounts for emissions from other purchased products in category 1. If major capital purchases occur only once every few years, scope 3 emissions from capital goods may fluctuate significantly from year to year. Companies should provide appropriate context in the public report (e.g., by highlighting exceptional or non-recurring capital investments).

Source: Box 5.4 from the Scope 3 Standard

## Calculating emissions from capital goods

Companies may use the following methods to calculate scope 3 emissions from capital goods:

- · Supplier-specific method , which involves collecting product-level cradle-to-gate GHG inventory data from goods suppliers
- · Hybrid method , which involves a combination of supplier-specific activity data (as available) and using secondary data to fill the gaps. This method involves:
- · collecting allocated scope 1 and scope 2 emissions from suppliers
- · calculating upstream emissions of goods by collecting available data from suppliers on the amount of materials, fuel, electricity used, distance transported, and waste generated from the production of goods and applying appropriate emission factors
- · using secondary data to calculate upstream emissions wherever supplier-specific data is not available.
- · Average-product method , which involves estimating emissions for goods by collecting data on the mass or other relevant units of goods purchased and multiplying by relevant secondary (e.g., industry average) emission factors (e.g., average emissions per unit of good)
- · Average spend-based method , which involves estimating emissions for goods by collecting data on the economic value of goods purchased and multiplying by relevant secondary (e.g., industry average) emission factors (e.g., average emissions per monetary value of goods).

The calculation methods for category 1 (Purchased goods and services) and category 2 (Capital goods) are the same. For guidance on calculating emissions from category 2 (Capital goods), refer to the guidance in the previous section for category 1 (Purchased goods and services).