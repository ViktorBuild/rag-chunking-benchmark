---
document_id: sbti_steel_guidance
title: "Steel Science-Based Target-Setting Guidance"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "SBTi"
year: 2023
original_file: "sbti_steel_sector_guidance.pdf"
tables_detected: 55
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## ACKNOWLEDGMENTS

The SBTi is a global body enabling businesses to set ambitious emissions reductions targets in line with the latest climate science. It is focused on accelerating the progress of companies across the world to halve emissions before 2030 and achieve net-zero emissions before 2050.

The initiative is a collaboration between CDP, the United Nations Global Compact (UNGC), World Resources Institute (WRI) and World Wildlife Fund for Nature (WWF) and is one of the We Mean Business Coalition (WMB) commitments. The SBTi defines and promotes best practice in sciencebased target-setting, offers resources and guidance to reduce barriers to adoption, and independently assesses and validates companies' targets.

During the development of this work, we engaged Energy Transitions Commission (part of Mission Possible Partnership [MPP]) as our technical partner to develop the methodology and pathways. We would like to acknowledge their in-depth knowledge and contribution to this project. Special thanks go to Alasdair Graham and Faustine Delasalle who have steered the SBTi and MPP collaboration behind the scenes.

In September 2022, the MPP and the SBTi formed a technical collaboration to enhance the compatibility of the SBTi Sector Projects and MPP Sector Transition Strategies, to provide companies in high-emitting sectors with a simplified roadmap to scale climate actions and accelerate decarbonization in line with 1.5°C. This project on steel is the first fruit of that partnership, as the development of the pathways with ETC built upon previous work by MPP.

For this guidance and throughout the methodology development process, we received invaluable insights and technical review from our Expert Advisory Group (EAG) through the monthly meetings, bilateral exchange, in person discussion and email communications. We are truly grateful for all their contributions of time and expertise. A two-month public consultation held in November 2022 to January 2023 proved to be beneficial to gain broader inputs and comments from all stakeholders in the steel sector and the supply chain.

<!-- image -->

## Primary authors:

Brenda Chan, CDP Karl Downey, CDP Rafal Malinowski, ETC Sophie Slot, ETC

## Review team:

Ayla Dincay, WMB Fernando Rangel Villasana, WWF Lucas Bartol-Bibb, CDP Michael Danielson, WRI Peter Nyström, WWF Zola Berger-Schmitz, WRI

## Other contributors:

Aamir Khan, CDP Alasdair Graham, ETC Paulina Moreno, WWF

Last but not least, we would like to acknowledge the SBTi Technical Review Team for their time and support to review this guidance and improve its clarity.

<!-- image -->

## CONTENTS

ㄓ

| ACKNOWLEDGMENTS                                                        |   2 |
|------------------------------------------------------------------------|-----|
| SUMMARYOFSECTOR-SPECIFIC CRITERIAAND RECOMMENDATIONS                   |   4 |
| NORMATIVE AND INFORMATIVE ELEMENTS OFTHIS DOCUMENT                     |   8 |
| INTRODUCTION                                                           |  10 |
| NEAR-TERM, LONG-TERMAND NET-ZERO SCIENCE-BASED TARGETS                 |  15 |
| STEEL DECARBONIZATION PATHWAYS                                         |  18 |
| HOWTOSETASCIENCE-BASEDTARGET                                           |  25 |
| Step 1: Determine scopes, target boundaries and target-setting methods |  28 |
| Step 2: Calculate emissions inventory                                  |  37 |
| Step 3: Construct targets                                              |  40 |
| Step 4: Submit targets to the SBTi                                     |  45 |
| GLOSSARY                                                               |  50 |
| BIBLIOGRAPHY                                                           |  52 |
| APPENDICES                                                             |  55 |
| Development of the pathways                                            |  56 |
| Howwas the sector 1.5ºC pathway disaggregated into two pathways?       |  58 |
| Development of the iron & steel core SDA boundary                      |  63 |

Partner Organizations:

In collaboration with:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## SUMMARY OF SECTOR-SPECIFIC CRITERIA AND RECOMMENDATIONS

<!-- image -->

## SUMMARY OF SECTOR-SPECIFIC CRITERIA AND RECOMMENDATIONS

The table below provides a quick-reference summary of the sector-specific criteria and recommendations discussed in this guidance that apply in addition to the SBTi Criteria and Net-Zero Standard Criteria. 'C' designates a criterion (i.e., it is mandatory); 'R' designates a recommendation.

Table 1:  Summary of the sector-specific criteria and recommendations

| TOPIC                                  | CRITERIA   | DESCRIPTION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|----------------------------------------|------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Use of system boundary                 | Steel-C1   | Where the iron &steel SDA is used for target-setting, the emissions covered shall align with the iron &steel core boundary as defined in this document. The intensity denominator is hot rolled steel. Steelmakers that choose to use the absolute contraction method rather than the SDA to set targets for activities within the iron &steel core boundary shall include all activities within the boundary in this target.                                                                                                                                                                                                                                     |
| Limitations in use of iron & steel SDA | Steel-C2   | The iron &steel SDA may be used for target-setting covering emissions included in the iron &steel core boundary where the final product is steel. If scope 1 and 2 emissions from activities in the iron &steel core boundary make up less than 95% of a company's total scope 1 and 2 emissions, then the remainder shall be covered by a different target using the SBTi's cross-sector methods or relevant sector-specific methods. If scope 1 and 2 emissions from activities in the iron &steel core boundary make up more than 95% of the company's total scope 1 and 2 emissions, the company may include those emissions within core boundary and target. |

| TOPIC                                                                                     | CRITERIA   | DESCRIPTION                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
|-------------------------------------------------------------------------------------------|------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Near-term scope 3 coverage: purchased intermediate products                               | Steel-C3   | Where the iron &steel core boundary is used by iron &steelmakers for near-term target-setting, company science-based targets shall include suppliers' upstream emissions for purchased intermediate products falling within the iron &steel core boundary, irrespective of whether the share of these emissions compared to the total scope 1, 2 and 3 emissions of the company is above 40%, and irrespective of the scope 3 coverage reached by other scope 3 targets.   |
| Near-term scope 3 coverage: sold intermediate products                                    | Steel-C4   | Where the iron & steel SDA is used by steelmakers for near-term target-setting, science-based targets shall include downstream emissions associated with the further processing of sold intermediate products falling within the iron & steel core boundary, irrespective of whether the share of these emissions compared to the total scope 1, 2 and 3 emissions of the company is above 40%, and irrespective of the scope 3 coverage reached by other scope 3 targets. |
| Near-term scope 3 target covering category 3: upstream fuel- and energy-related emissions | Steel-C5   | Near-term iron & steelmakers science-based targets shall include a scope 3 target that covers all scope 3 category 3 'fuel- and energy-related emissions not included in scope 1 or scope 2' according to the GHGProtocol.                                                                                                                                                                                                                                                 |
| Forecast growth                                                                           | Steel-C6   | Where the iron &steel SDAis used for target-setting, the company shall provide, in their target submission, justification of the growth projection used to calculate the target, including public or internal documents where growth projections are mentioned if relevant.                                                                                                                                                                                                |
| Target wording                                                                            | Steel-C7   | Where the iron &steel SDAis used by iron- or steelmakers for target-setting, the fact that the target calculation depends on the scrap share shall be included in the target wording.                                                                                                                                                                                                                                                                                      |
| Annual emissions and scrap input reporting                                                | Steel-C8   | Where the iron &steel SDA is used by iron- or steelmakers for target-setting, annual disclosure of both the emissions and scrap ratio aligned with the boundary of the target is mandatory.                                                                                                                                                                                                                                                                                |
| Justification in the case of decreasing scrap ratio                                       | Steel-C9   | Iron- or steelmakers planning a reduction in their scrap ratio included in their target shall submit justification of this scrap ratio reduction when submitting their target for validation, and disclose the fact that the calculation was based on a decreasing scrap ratio in public documents.                                                                                                                                                                        |

| TOPIC                                         | RECOMMENDATION   | DESCRIPTION                                                                                                                                                                                                                                                                                                    |
|-----------------------------------------------|------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Near-term scope 3 target covering ferroalloys | Steel-R1         | Stainless or high-alloy steel company near-term science-based targets should include a scope 3 target that covers scope 3 category 1 'purchased goods and services' covering ferroalloys sourcing, irrespective of the share of the total scope 1, 2 and 3 emissions for which they are responsible.           |
| Investment in breakthrough technologies       | Steel-R2         | Steel companies should disclose information such as planned milestones and near-term investments that demonstrate the integrity of commitments to ensure any breakthrough technology required to meet their target ambition will become available in the timeframe expected.                                   |
| Information on absolute emissions reductions  | Steel-R3         | In order to demonstrate that intensity targets also lead to absolute emissions reductions, and to demonstrate progress through optimization of material use, companies whose targets are expressed in intensity terms should publish the absolute emissions reductions that will be achieved by their targets. |

<!-- image -->

## NORMATIVE AND INFORMATIVE ELEMENTS OF THIS DOCUMENT

## NORMATIVE AND INFORMATIVE ELEMENTS OF THIS DOCUMENT

<!-- image -->

## FOR WHICH USERS IS THIS GUIDANCE MANDATORY?

For iron- and steelmakers, all criteria in this document (as summarized in Table 1) must be applied in order to develop targets for validation. Where applicable, the criteria in this document supplement criteria outlined in the SBTi Net Zero Standard and SBTi Near-Term Criteria. For these users, these documents need to be used in conjunction when preparing target submissions.

- Definition of 'steelmaker' for the purposes of this guidance: company that produces steel in any form from iron ore and/or scrap by undertaking some or all of the activities under 'iron &amp; steelmaking' in Figure 3.
- Definition of 'ironmaker' for the purposes of this guidance: company that produces pig iron or sponge iron (e.g. Hot Briquetted Iron, [HBI]) from iron ore for the purposes of further processing into steel; or producers of other forms of iron whose final form is not steel, such as cast iron and wrought iron.

## FOR WHICH USERS IS THIS GUIDANCE OPTIONAL?

Companies in the iron &amp; steel value chain that do not fit the definition of iron- or steelmakers above, must follow the SBTi criteria in the SBTi Net Zero Standard and SBTi Near-Term Criteria, and may (but are not obliged to) use elements of this guidance where specified in the document. For example:

- Companies upstream of iron- and steelmaking, such as iron ore suppliers, may use the iron &amp; steel pathways to set their scope 3 category 10 (processing of sold products) target. See section on how to set a science-based target.
- Companies downstream of iron- and steelmaking that purchase steel, such as automakers, may use the steel pathway to set scope 3 category 1 (purchased goods and services) targets for their purchased steel. See section on how to set a science-based target.
- Financial Institutions (FIs) may use the iron &amp; steel pathways to set scope 3 category 15 targets for their investment and lending activities to steel companies. See section on how to set a science-based target.

## DATE OF APPLICATION OF THE GUIDANCE

Iron &amp; steelmakers must apply this guidance document in full for target submissions or re-submission from 30 days after the date of publication, that is, from 17 August 2023.

## Use of terms 'shall', 'must', 'should' and 'may'

The terms 'shall' and 'must' are used throughout this document to indicate what is required for targets to be in conformance with the criteria, whereas the term 'should' is used to describe recommendations. The SBTi recommendations are important for transparency and best practices but are not required. The term 'may' is used to indicate an option that is permissible or allowable.

## INTRODUCTION

<!-- image -->

Science-based targets (SBTs) specify how much and how quickly a company would need to reduce its greenhouse gas (GHG) emissions in order to align with the goals of the Paris Agreement.

Globally, the steel sector's direct carbon dioxide (CO ) emissions amounted 2 to 2.6 Gt in 2019, equivalent to about 7% of total energy sector emissions and 25% of industrial CO  emissions with a further 1.1 Gt CO  of indirect 2 2 emissions from electricity consumption (IEA, 2020). Demand for steel is projected to grow by approximately 12% by 2050 under a 1.5°C scenario (IEA, 2021) and even more under a business-as-usual scenario. Meeting this demand while reducing GHG emissions is a significant challenge.

<!-- image -->

For these reasons, urgent action is needed for steel companies to decarbonize. Science-based targets allow companies to show that their plans align with the latest climate science.

The purpose of this guidance document and accompanying tools is to provide companies with the resources they need to set 1.5°C-aligned near- and long-term climate targets at a corporate level. This document is structured as follows:

- The first section summarizes the sector-specific GHG accounting criteria and recommendations.
- The second section explains how this document should be understood in terms of normative and informative aspects.
- The third section gives an overview of the development process of this guidance.
- The fourth section provides the context of near-term, long-term and net-zero science-based targets.
- The fifth section explains the scientific basis for sector-specific 1.5°C decarbonization pathways, the Sectoral Decarbonization Approach (SDA), the iron &amp; steel core boundary and scrap-input-dependent pathways.
- The sixth section forms the main part of this guidance on target-setting: this includes emissions inventory and how to deal with issues that are specific to the steel sector, with examples on how different types of companies can use the tools, and guidance for submitting a target for validation.

## OVERVIEW OF THE DEVELOPMENT PROCESS

This guidance is the result of a technical partnership between the SBTi and the Energy Transitions Commission (ETC) (as part of MPP 1 ), who provided technical support on developing 1.5ºC decarbonization pathways for the iron &amp; steel sector.

A transparent multi-stakeholder development process is central to all the SBTi's sector projects. The steel project was accompanied by an Expert Advisory Group (EAG) composed of 28 organizations from industry, civil society and academia, who provided detailed input during the development of this guidance and tool. EAG members were selected and invited to join the expert group based on their expertise, geographic location, relationship to and influence in the sector, as well as companies' ambition to align their organization with the 1.5°C climate goals.

## Table 2:  List of EAG members

| EAG MEMBERORGANIZATIONS                     | EAG MEMBERORGANIZATIONS                       |
|---------------------------------------------|-----------------------------------------------|
| Aceros AZA S.A.                             | Nippon Steel Corporation                      |
| Aperam                                      | Outokumpu Oyj                                 |
| ArcelorMittal                               | Ovako                                         |
| Baoshan Iron &Steel Co Ltd (Baosteel)       | POSCO                                         |
| Bellona                                     | Potsdam Institute for Climate Impact Research |
| BlueScope Steel Limited                     | ResponsibleSteel                              |
| Cleveland Cliffs                            | Rocky Mountain Institute (RMI)                |
| E3G                                         | Severstal PAO                                 |
| Energy Transitions Commission (ETC)         | Tata Steel                                    |
| Environmental Coalition on Standards (ECOS) | Transition Pathway Initiative                 |
| Gerdau                                      | Vallourec                                     |
| Imperial College                            | Voestalpine AG                                |
| JSW Steel Ltd                               | World Steel Association                       |
| Liberty Steel UK                            | WWF(Finland)                                  |

- 1  The Mission Possible Partnership (MPP) and the Science Based Targets initiative (SBTi) have formed a technical collaboration to enhance the compatibility of the SBTi Sector Projects and MPP Sector Transition Strategies, providing companies in high-emitting sectors with a simplified roadmap to scale climate actions and accelerate decarbonization in line with 1.5⁰C.

The SBTi is very grateful for the input and engagement from EAG members. The EAG's role was advisory and final sign-off for deliverables is by the SBTi. Therefore, opinions expressed within this document may not represent the views of every EAG organization.

Funding for this project was provided by ArcelorMittal. Providing funding did not confer on ArcelorMittal any special position in the governance of the project.

Public webinars were held on 23 November 2022 to launch the public consultation period, which was open from 23 November 2022 to 23 January 2023, in order to obtain input from stakeholders on the draft guidance document and the accompanying target-setting tool.

## WHY DOES STEEL WARRANT DEDICATED PATHWAYS AND TOOLS?

As a large industrial sector, iron &amp; steel production contributes a significant source of carbon emissions, driven mainly by the reduction of iron ore with carbon in the form of metallurgical coal, but also from fuels and electricity. Therefore, the rate at which the sector can decarbonize may differ from the overall rate of decarbonization possible by society as a whole, as reflected by multiple pathways available in the literature. The steel industry relies on capital intensive, long-lived assets; the bulk of its decarbonization relies on technologies that are yet to be deployed on a commercial scale, and shared infrastructure that may be challenging to develop. It is estimated the majority of the expenditure required to decarbonize the steel sector may actually lie outside of steel plants, bringing additional financing and coordination challenges (MPP, 2022). For these reasons, a dedicated steel pathway and specific guidance to allow companies to set science-based targets is justified.

## WHY IS THE STEEL SECTOR DIVIDED INTO TWO DECARBONIZATION PATHWAYS?

The pathway for well-below 2°C (WB2C) for the iron &amp; steel sector provided by the SBTi in the past did not differentiate between the two major production processes:

- Primary, iron-ore based steel production.
- Secondary, scrap-based steel production.

Ore-based and scrap-based steelmaking could be considered two separate industries with vastly different processes and carbon footprints, but their products overlap and many assets can move in a continuous fashion from production using 0% to 100% scrap-based inputs.

The vast majority of iron &amp; steel production and emissions result from ore-based steelmaking and thus to ensure the sector meets the 1.5°C budget, ore-based steelmaking must decarbonize faster than scrap-based steelmaking. However, scrap-based producers likely have the ability to decarbonize faster than ore-based producers: their production is mostly electricity-based and thus switching to renewable sources serves as the main decarbonization lever, rather than costly replacement of coal-based assets like in case of incumbent ore-based steelmaking.

Considering the future global steel demand and the availability of scrap, it is recognized that an appropriate disaggregation of the pathway into such sub-industries would encourage diverse types of companies in the sector to set science-based targets, while incentivizing three important aspects and at the same time conserving the carbon budget for the sector:

2 A general sectoral shift towards greater circularity in line with 1.5°C pathways.

3 Decarbonization of secondary scrap-based production.

1

Decarbonization of ore-based assets.

For the reasons outlined above, this guidance document provides scrap-input-dependent decarbonization pathways, where each individual company's pathway will depend on its scrap share in both its base and target years. For more details on the rationale for this approach, see Appendix 2.

## HOW DOES THIS GUIDANCE CHANGE TARGET-SETTING REQUIREMENTS COMPARED TO PREVIOUS PRACTICE?

The SBTi already offered WB2C pathways for steel prior to publication of this detailed guidance. This guidance offers a more granular methodology by introducing an iron &amp; steel core boundary, differentiated pathways based on scrap input, and a mandatory scope 3 target covering upstream emissions from fuels, as well as aligning to the latest SBTi Criteria, Net-Zero Standard and 1.5°C ambition. Although the publication of this guidance does not oblige companies that have already set 2°C or WB2C targets to recalculate their targets ahead of normal update schedules 2 , they are encouraged to do so. Target submissions and target re-submissions by iron and steelmakers must be developed according to the requirements specified in this document from 30 days from the date of publication.

## HOW IS THIS GUIDANCE COMPARABLE TO OTHER STEEL DECARBONIZATION INITIATIVES?

This document provides guidance for setting forward-looking science-based targets at the ompany level. It therefore has a different purpose to other initiatives which assess companies' performance today, or which assess individual plants or products. Effort has been made in the development of this guidance to align with other schemes as far as possible, while recognizing that these different purposes mean that full alignment may not always be possible or desirable. For a discussion of differences with other schemes, please see Appendix 3.

- 2  According to the SBTi general criteria, existing targets should be recalculated if there are significant changes that could compromise relevance and consistency of the existing target, or at least every 5 years.

## NEAR-TERM, LONG-TERM AND NET-ZERO SCIENCE-BASED TARGETS

## NEAR-TERM,

<!-- image -->

## LONG-TERM AND NET-ZERO SCIENCE-BASED TARGETS

The SBTi Net-Zero Standard was published in October 2021 and revised in April 2023. It was developed to guide corporates towards a state of net-zero that is consistent with societal climate and sustainability goals.

The Net-Zero Standard sets out four key elements that make up a corporate net-zero target as depicted in Figure 1:

It makes a distinction between near-term and long-term science-based targets:

- Near-term science-based target. 1
- Long-term science-based target. 2
- Beyond value chain mitigation (optional). 3
- Neutralization of any residual emissions. 4

Companies wishing to set a net-zero target must set both near-term and long-term targets. Alternatively, companies may choose to set just a near-term target (but they cannot set only a long-term target).

<!-- image -->

<!-- image -->

A long-term science-based target is a target to reach the residual emissions level 3 by 2050 at the latest, and commit to neutralizing these residual emissions to reach net-zero.

- 3  Residual emissions are emissions sources that remain unabated in a specific year of a mitigation scenario. Long-term science-based targets are consistent with the level of residual emissions in the year of global or sector net-zero in 1.5°C-aligned mitigation pathways with low or no overshoot.

A near-term science-based target sets reductions to be achieved by 10 years or fewer from the date of submission.

## Figure 1:  Key elements of the Net-Zero Standard

<!-- image -->

- To set near-term science-based targets: 5-10 year emission reduction targets in line with 1.5°C pathways. 1
- To set long-term science-based targets: Target to reduce emissions to a residual level in line with 1.5°C scenarios by no later than 2050. 2
- Beyond value chain mitigation: In the transition to net-zero, companies should take action to mitigate emissions beyond their value chains. For example, purchasing high-quality, jurisdictional REDD+ credits or investing in direct air capture (DAC) and geologic storage. 3
- Neutralization of residual emissions: GHGs released into the atmosphere when the company has achieved their 4

long-term SBT must be counterbalanced through the permanent removal and storage of carbon from the atmosphere.

## NEUTRALIZATION OF RESIDUAL EMISSIONS

According to the SBTi Net-Zero Standard, residual emissions, i.e. GHGs still being released into the atmosphere when the company has achieved its long-term science-based target, must be counterbalanced through the permanent removal and storage of carbon from the atmosphere to reach net-zero emissions (Figure 1).

Examples of neutralization include, but are not limited to: direct air capture (DAC) and storage; bioenergy with carbon capture and storage (BECCS); improved soil management; improved forest management; and land restoration (e.g., of peatlands, terrestrial forests or mangroves).

Further guidance on neutralization is being developed and will be published by the SBTi in 2024.

## STEEL DECARBONIZATION PATHWAYS

<!-- image -->

## STEEL DECARBONIZATION PATHWAYS

To create tools that companies can use to calculate science-based targets, three steps are followed by the SBTi:

- The global carbon budget and its allocation to the sector is determined.
- An emissions scenario describing a plausible decarbonization trajectory pathway that fits within the sector budget is chosen based on a comparison with different scenarios and discussion with the EAG.
- Target-setting methods such as the SDA are used to translate the sector pathway into company targets.

## TARGET-SETTING METHOD: SECTORAL DECARBONIZATION APPROACH (SDA)

The SDA, also known as the 'sector-specific intensity convergence' approach, is a target-setting methodology allowing companies to model physical intensity GHG reduction targets that align with the sector-specific pathway of an underlying climate scenario.

In the SDA, annual emissions pathways are divided by projected industry activity to define a carbon intensity curve. Targets are set by assuming that all companies converge to the same intensity level as the sector by the year 2050. Science-based targets are set in the near-term (5 to 10 years from the date of submission) along this convergence path, the steepness of which is defined by the relative intensity of the company compared to the sector in the base year and the rate of forecasted company activity growth (Figure 2). The further a company is above the curve in the base year, the more stringent the percentage intensity reduction required. If the company has a greater growth forecast compared to the sector growth in the pathway, steeper emission intensity reductions will be required. Thus, a company's particular situation is considered in calculating the emissions intensity target.

The SDA is used for homogenous sectors that have a dedicated decarbonization pathway. Most other sectors, such as those that do not have a sector pathway, may use the cross-sector Absolute Contraction Approach (ACA), which requires absolute emissions reductions at a fixed annual rate 4 .

Figure 2: Illustration of an intensity convergence pathway - companies should converge to the sector average intensity (red line) by 2050

<!-- image -->

## IRON &amp; STEEL CORE BOUNDARY

The iron &amp; steel sector is characterized by varying levels of vertical integration 5 and different types of technology. To ensure that the iron &amp; steel SDA is based on consistent accounting and creates a level playing field for both integrated and non-integrated companies, this guidance provides a standardized iron &amp; steel core boundary, which is aligned with the carbon budget. The iron &amp; steel core boundary can be found in Figure 3 and its justification is discussed in Appendix 3.

## Figure 3: Iron &amp; steel core boundary

<!-- image -->

- 5  While some companies own and control the full production process from iron ore to finished steel, other companies only produce an intermediate product such as HBI or buy large amounts of merchant iron, moving related emissions from scope 1 to scope 3.

## SCRAP-INPUT-DEPENDENT PATHWAYS

To account for the vastly different emission profiles of ore- and scrap-based steelmaking and the different challenges to decarbonize each of these production routes, the iron &amp; steel SDA is based on a scrap-inputdependent pathways 6 . This pathway is company-specific and is calculated based on two separate, fixed, 1.5°C-aligned sector pathways: a 100% scrap-based (secondary) pathway and a 0% scrap-based (primary) pathway. The shape of scrap-input-dependent pathway for a company will be a weighted average of the primary and secondary pathways, depending on the ratio between scrap- and ore-based metallics input and how this ratio changes over time. This is the principle of the scrap-input-dependent pathway: there are separate pathways for scrap- and ore-based production, and a company producing, for example, from 30% scrap and 70% ore-based inputs will have a pathway converging to point between those two separate pathways (Figure 4).

## Figure 4: Company targets are calculated from convergence towards a scrapinput-dependent 1.5ºC pathway

(This example is based on a company with 0% activity growth over 2020-30 and constant scrap input of 30%)

<!-- image -->

The target-setting tool accompanying this guidance provides the iron &amp; steel sector intensity pathways to be used with the SDA. Full data can be accessed in the Steel Science-Based Target-Setting Tool. Details of how the pathways were derived can be found in Appendix 1.

- 6  Systems similar to what is described here are often referred to as a 'sliding scale' and they are used for setting product-level standards, which is not the goal of the SBTi nor this guidance. To emphasize that the system derives a company-specific 1.5ºC decarbonization pathway that depends on the scrap input, we call it here a 'scrap-input-dependent pathways'.

## THE STEEL DECARBONIZATION CHALLENGE

Emissions scenarios describing paths for the iron &amp; steel sector to reach the level of deep decarbonization required by the 1.5°C goal present a wide range of opportunities to reduce emissions.

Many of these opportunities are already being implemented today, such as increasing scrap use and energy efficiency, fuel switching to fossil-free electricity, introducing top gas recycling, or replacing injected coal in blast furnaces with sustainably sourced biofuels. However, these methods can likely deliver only an incremental decrease in emissions, especially in the case of ironmaking. Breakthrough technologies such as green hydrogen 7 -based direct or smelting reduction, carbon capture and permanent geological storage (CCS), bioenergy with carbon capture and storage, direct electrolysis of molten iron ore, carbon looping (Kildahl et al., 2023), and electrolysis of water-borne iron ore (Lopes, Lisenkov &amp; Kavaleuski, 2023), still need to develop and/or scale up to provide a clear pathway to deep emission reduction in the sector.

<!-- image -->

Therefore, the challenge to decarbonize steel is considerable, both from the perspective of individual companies and for the sector as a whole. For individual companies, challenges will include (among others):

- Significant capital expenditure.
- R&amp;D into breakthrough technologies.
- Long lead time from demonstration phase to commercial phase.
- Sourcing of alternative raw materials, fuels and decarbonized electricity.
- Restrictive trade policies in different regions.

For the sector as a whole, and the wider economy, challenges include (among others):

- Deploying new infrastructure for green hydrogen or CCS and its impact on social and employment prospects.
- Circular economy practices to ensure scrap becomes available to be used.
- Increasing smart design in construction and automotive industries for material efficiency and longevity.

All this needs to happen in a regulatory environment which in some parts of the world does not yet support deep decarbonization.

7  Green hydrogen is defined as hydrogen produced from electrolysis of water using renewable electricity.

Of the extensive current pipeline of announced low-emission commercial-size projects, only three have broken ground after securing final investment decisions to proceed (ETC, 2023), showing how challenging the transition is even in developed steel economies.

Multilateral collaboration of steelmakers, OEMs, buyers, governments, financial institutions and other participants in the value chain are required to drive these investments forward - and time is of the essence. Science-based targets should be used by companies as a way of demonstrating their ambition to stakeholders, to call for the supportive environment needed for decarbonization.

This guidance aims to help companies understand the level of emissions reductions required to align with science but does not prescribe which emissions reduction levers should be prioritized or utilized, as this is up to the individual strategy of each company.

<!-- image -->

## HOW TO SET A SCIENCE-BASED TARGET

<!-- image -->

## HOW TO SET A SCIENCE-BASED TARGET

Companies are invited to familiarize themselves with the SBTi crosssector resources ㄎand the SBTi Getting Started Guide, followed by reviewing the requirements of target-setting in the SBTi Criteria or NetZero Standard Criteria. To understand these requirements in more depth, companies should then review the Target Validation Protocol and use the cross-sector near-term target-setting tool, the Steel Science-Based Target-Setting Tool, and the Net-Zero Tool to begin developing targets.

This section provides additional guidance for companies in the iron &amp; steel sector and its value chain to set science-based targets. Four steps are described:

- Determine target boundaries, scopes and target-setting methods: Review the generic SBTi Criteria and this sector-specific guidance document to determine how to set target(s) across relevant activities and scopes. 1
- Calculate emissions inventory: Calculate base year and most recent year emissions inventories and activity following guidance provided by the GHG Protocol and below. 2
- Construct targets: Model SDA target(s) using the Steel Science-Based Target-Setting Tool. Additional targets may also be needed to address emissions not covered by the iron &amp; steel SDA to meet the SBTi Criteria and can be modelled with the cross-sector near-term target-setting tool. 3
- Submit targets to the SBTi: Send a completed Target Submission Form to the SBTi. 4

## Figure 5: Steps for companies in the iron &amp; steel sector to set science-based targets*

<!-- image -->

## Determine target boundaries, scopes and target-setting methods

<!-- image -->

<!-- image -->

## For base year

## Calculate emissions inventory

Note: Use the sheet 'Iron &amp; Steelmaker Tool' to calculate targets for activities within the core boundary

## Construct targets

Review the target modelling results in section 3 in the 'Iron &amp; Steelmaker Tool' sheet

Submit targets to the SBTi

<!-- image -->

<!-- image -->

<!-- image -->

Enter the activity output

(tonnes of hot rolled steel)

## For target year

Enter the type of activity projection

## For scrap ratio

Base year

Enter a value between 0

Enter the emissions with the core boundary*

(tCO e)

2

Enter the activity output

(if 'T arget year output' option is chosen)

Target year

Enter a value between 0 and and 100%

100%

Steel purchasers can use the " Steel Procurement Tool " to calculate scope 3 category 1 targets for purchased steel

SDA intensity (SBTi 1.5°C)

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Submit

## Communicate

## Disclose

Present your target to the SBTi for official validation

Announce your target and inform your stakeholders once they have been validated by the SBTi

Report company-wide emissions and progress against targets on an annual basis

For near-term and net-zero target-setting

- * Users should refer to relevant sections of the document for full guidance

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## DETERMINE SCOPES, TARGET BOUNDARIES AND TARGET-SETTING METHODS

The following steps should be followed to determine which emissions should be covered by science-based targets, and which approaches to use when calculating science-based targets.

- Decide whether to set a near-term target only, or a net-zero target (which includes a near- and a longterm target). 1
- Decide on a base year and target year for each target. Near-term targets must have a timeframe of 5-10 years from the date of submission, and the long-term target year must be 2050 or sooner. Rules for this can be found in the SBTi Criteria and Net-Zero Standard Criteria. 2
- Determine which scope 3 targets are desired/optional or required. See sector-specific guidance below. 3
- Determine which emissions fall inside or outside target boundaries: that is, which emissions will be included in the iron &amp; steel core boundary according to this guidance, and which other emissions may also be required to be covered by targets according to the SBTi Criteria, and Net-Zero Standard Criteria. 4
- Determine which target-setting method will be used for each target. 5

## SCOPES REQUIRED

General criteria on the scopes required is set out in the SBTi Criteria and Net-Zero Standard Criteria. In summary:

## For near-term targets:

- All scope 1 and 2 emissions shall be included 8 .
- If a company's relevant scope 3 emissions are 40% or more of total scope 1, 2 and 3 emissions, a scope 3 target is required. The coverage must be at least 67%. For calculation of the 40% threshold and the 67% coverage rate, scope 3 emissions from both inside and outside the iron &amp; steel core boundary are to be considered.
- All companies involved in the sale or distribution of natural gas and/or other fossil fuels shall set 1.5°C-aligned scope 3 targets for the use of sold products, covering the combustion emissions of any sold or distributed fossil fuels, irrespective of the share of these emissions compared to the total scope 1, 2 and 3 emissions of the company.
- 8  Unless otherwise stated, as per SBTi general criterion C5, emissions inventories for scope 1, 2 or scope 3 categories shall be complete. Companies may exclude up to 5% of scope 1 and scope 2 emissions combined in the boundary of the  inventory and target.

<!-- image -->

Additional requirements to these generic rules applying to steel producers are set out in this guidance document, and can be summarized as follows:

<!-- image -->

Steelmakers must include all emissions from activities falling under the iron &amp; steel core boundary in targets, regardless of whether these are scope 1, 2 or 3 emissions. This means companies shall adjust their emissions for purchased and sold products.

- Near-term steel company science-based targets shall include emissions from their purchased intermediate products falling within the core boundary (e.g., emissions from purchased merchant iron, which would otherwise be considered scope 3 category 1 'purchased goods and services', must be included in the SDA intensity target).
- Near-term steel company science-based targets shall include emissions from their sold intermediate products falling within the core boundary (e.g., emissions from sales of surplus coke, which would otherwise be considered scope 3 category 10 'processing of sold products').
- Iron &amp; steelmakers must set a scope 3 target that covers category 3 'fuel- and energy-related emissions' not covered in other targets. Category 3 coverage shall be 100% of the inventory 9 . The category 3 target may be combined with other scope 3 categories (e.g. category 1) to form a broad scope 3 target. 2

<!-- image -->

Note that all requirements for emissions coverage, ambition, etc., set out in this section and this guidance document should be considered the minimum: companies are encouraged to go beyond this and to set targets that are more ambitious and cover all scopes and categories.

## For long-term targets:

Scope 1, 2 and 3 shall be included. The coverage shall be at least 90% for scope 3 emissions. Iron &amp; steel producers shall follow cross-sector guidance for setting long-term targets, and may use the Net-Zero Tool to set their long-term target.

- 9  As per the SBTi general criterion C5, companies may exclude a maximum of 5% of emissions from their total scope 3 inventory. 100% of the relevant inventory should be included in the relevant target boundary.

<!-- image -->

## IRON &amp; STEEL CORE BOUNDARY

For steelmakers, all processes included in the iron &amp; steel core boundary will fall under iron &amp; steel target-setting, irrespective of whether they are scope 1, 2 or 3 emissions for a given entity. Upstream emissions from purchased products and downstream emissions from processing of sold products, falling within the core boundary will also be included. The company must ensure that &gt;95% of the emissions within the iron &amp; steel core boundary are included in the iron &amp; steel SDA target as well as meeting the general minimum coverage for scope 1, 2 and 3 inventories.

<!-- image -->

## How to include emissions from purchased products

Steelmakers purchasing intermediate products within the iron &amp; steel core boundary shall include emissions from these products in their target boundary.

This measure is introduced not only to reduce the risk of 'scope leakage', in which a company could reduce scope 1 emissions by shifting from producing inputs to purchasing inputs, but also provides a level playing field between integrated and non-integrated players, which may differ only in asset ownership structure rather than processes to make steel.

Therefore, iron &amp; steel core boundary targets shall include at least 95% of emissions from purchased:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Coke

Syngas

Hydrogen

Power

Lime and/or Dolomite 5

Oxygen

Iron ore pellets or any other form of agglomerated iron ore (i.e., sinter) 7

HBI or any other form of iron (i.e., pig iron)

1

2

3

4

6

8

<!-- image -->

The emissions to be included shall be all the emissions associated with producing the intermediate product(s) that result from processes inside the core boundary (i.e., cradle-to-gate emissions of these products are not mandatory to be included in the core boundary, although they may be relevant for scope 3 targets where these are set). This also means that in some cases, indirect suppliers' emissions need to be included. To make sure that emissions accounting remains manageable, organizations are permitted to use reference emission factors.

## How to include emissions from sold intermediate products

For some iron- and steelmaking companies that have a surplus of intermediate products (coke, sinter, pellets, etc.) and therefore sell them to other iron &amp; steel companies, the processes used to transform those intermediate products into hot rolled steel fall under the iron &amp; steel core boundary described in Figure 3. These products include:

- Coke and other chemical agents used for reduction of iron ore.
- Iron ore pellets or any other form of agglomerated iron ore (i.e., sinter).
- HBI or any other form of iron (i.e., pig iron).
- Any form of crude steel sold for hot rolling (i.e., billets).

If the company is using the iron &amp; steel SDA for its own activities but some of this activity produces intermediate products that are sold to be processed into hot rolled steel by another company, the first company must expand its emissions 10  associated with the production of this hot rolled steel.

Companies are encouraged to use primary data from downstream processes provided by customers to make hot rolled steel, if possible. Widely accepted reference emission factors may also be used for this adjustment.

## How to cover emissions outside the boundary in targets

Emissions outside the iron &amp; steel core boundary will be dealt with according to their scope. For scope 1 and 2 emissions outside the boundary and not falling under other sector-specific requirements, the company will use one of the SBTi cross-sector methods to set targets.

For scope 3 emissions outside the boundary, the general SBTi guidelines stipulate that if a company's scope 3 emissions account for more than 40% of a company's total (scopes 1, 2 and 3) emissions, the company will need to set a near-term scope 3 target (for emissions outside the boundary; emissions inside the boundary are covered with the core boundary target) 11 .

For upstream fuel- and energy-related emissions and emissions from purchased fuel 12  and electricity not already included in another target , a scope 3 category 3 target shall be set by iron- and steelmakers, regardless of their share of the company's total emissions.

For ferroalloys production emissions occurring upstream, it is recommended that steelmakers set a scope 3 target, regardless of their share of the company's total emissions.

An overview of the types of emissions and their recommended target approach has been included in Table 3.

10  While including the further processing emissions is mandatory, expanding the activity is not: companies can opt to simply add the further processing emissions to its emissions inventory without adjusting its activity to hot rolled steel. In that case the company likely ends up with a slightly stricter target, but its accounting is simplified.

11  To determine if the 40% threshold is reached, scope 3 emissions from both inside and outside the iron &amp; steel core boundary are summed and divided by the total scope 1, 2 and 3 emissions. If this 40% is reached, the minimum coverage of scope 3 emissions in targets shall be 67%. To calculate this 67% minimum, companies should sum the scope 3 emissions from within the core boundary, and from the mandatory scope 3 category 3 target, and any other optional scope 3 categories covered by scope 3 targets.

12  The term 'fuel' covers all types of fuels and feedstock being used for iron &amp; steel production, including metallurgical coal, coke and bio-based options such as charcoal.

## Table 3:  Overview of emission types and approaches

| EMISSION TYPE                                                             | EXAMPLE                                                                 | TARGET-SETTING APPROACH                              |
|---------------------------------------------------------------------------|-------------------------------------------------------------------------|------------------------------------------------------|
| Scope 1 emissions inside SDA boundary                                     | Emissions from sintering                                                | Iron &steel SDA or cross-sector ACA (1.5°C- aligned) |
| Scope 1 emissions outside SDA boundary                                    | Emissions from coating                                                  | Cross-sector ACA (1.5°C-aligned)                     |
| Scope 2 emissions inside SDA boundary                                     | Emissions from purchased power for EAF (electric arc furnace)           | Iron &steel SDA or cross-sector ACA (1.5°C -aligned) |
| Scope 2 emissions for company operations outside SDA boundary             | Emissions from purchased power for cold rolling                         | Cross-sector ACA (1.5°C- aligned)                    |
| Production of purchased intermediate products falling inside SDA boundary | Emissions from purchased HBI                                            | Iron &steel SDA or cross-sector ACA (1.5°C-aligned)  |
| Scope 3 emissions outside SDA boundary                                    | Emissions from transport of scrap                                       | Cross-sector scope 3 target approaches               |
| Scope 3 emissions outside SDA boundary                                    | Required scope 3 category 3 target (fuel- and energy-related emissions) | Cross-sector scope 3 target approaches               |
| Scope 3 emissions outside SDA boundary                                    | ferroalloys Other relevant scope 3 categories (e.g.,                    | Cross-sector scope 3 target approaches               |
| Scope 3 emissions outside SDA boundary                                    | downstream transportation and distribution, waste generated)            | Cross-sector scope 3 target approaches               |

## Co-products

While the recognition of the positive impact of co-products such as off-gases and blast-furnace slag in decarbonizing other industries is worthwhile, it is excluded from the context of science-based target-setting as avoided emissions fall under a separate accounting system from corporate inventories and do not count toward science-based targets (SBTi Criteria).

## High-alloy, stainless steel and ferroalloy production

Cradle-to-gate emissions for high-alloy steels differ from those from carbon steel for two reasons:

<!-- image -->

Production of the ferroalloys used as the source of non-ferrous elements is typically more emissionintensive than production of iron &amp; steel, with ferroalloy sourcing often being the major contributor to the cradle-to-gate emissions of stainless steel. 1

<!-- image -->

In addition, in steelmaking, the carbon content of ferroalloys is released as CO  ('process emissions'). 2

As can be seen in Figure 3, ferroalloy production is excluded from the core boundary, due to the lack of a widely accepted 1.5ºC decarbonization pathway for ferroalloy production. Therefore, high-alloy steel producers have two options for setting science-based targets:

## OPTION 1

## OPTION 2

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Set a target for steelmaking activities within the iron &amp; steel core boundary using the SDA.

Set a target for own ferroalloy production scope 1 and 2 emissions using 1.5°C cross-sector absolute reduction.

Set a scope 3 target covering cradle-to-gate emissions of purchased ferroalloys using any of the relevant scope 3 methods.

(Optional) Convert targets to absolute numbers and combine into one target.

Set scope 1, 2 and 3 targets using cross-sector absolute reduction approaches, at 1.5°C ambition for scope 1 and 2, and at least well-below 2°C ambition for scope 3.

## TARGET-SETTING METHODS

The permitted target-setting methods for scope 1, 2 and 3 emissions are laid out below. The SBTi recommends using the most ambitious method that leads to the earliest reductions and the least cumulative emissions.

<!-- image -->

## Scope 1 and 2

Iron- and steelmakers may use either the iron &amp; steel SDA or ACA to set near- or longterm scope 1, 2 and 3 targets for all activities and emissions within the iron &amp; steel core boundary.

Steelmakers must use the core boundary regardless of whether the target-setting method is SDA or ACA. Ironmakers must use the core boundary if they use the SDA target-setting method; if they use the ACA they should set scope 1 and 2 targets according to SBTi generic criteria.

For all other processes not included in the core boundary, companies must use the cross-sector ACA at a 1.5°C ambition level for scope 1 and 2 targets.

Targets to actively source renewable electricity at a rate that is consistent with 1.5°C scenarios are an acceptable alternative to scope 2 emission reduction targets (see SBTi Criteria) for purchased electricity emissions.

## Figure 6: Flowchart for near-term target-setting for iron- and steelmakers*

<!-- image -->

<!-- image -->

If a company uses the iron &amp; steel SDA, all scope 3 emissions occurring within the core boundary must be included in the SDA target.

Near-term targets for scope 3 emissions outside the core boundary may be set using one of five approaches: Absolute Reduction, Physical Intensity Convergence (SDA), Physical Intensity Reduction, Economic Intensity Reduction, or Supplier Engagement. Please refer to p. 22-24 in the SBTi Corporate Manual for details.

Scope 3 long-term targets may be set using one of four approaches: Absolute Reduction, Physical Intensity Convergence (SDA), Physical Intensity Reduction or Economic Intensity Reduction.

General rules are found in the SBTi Criteria and Net-Zero Standard Criteria.

If physical intensity reduction is chosen, an appropriate denominator that is relevant to the target should be chosen. Denominators that are likely to vary significantly with no link to the real decarbonization of the scope 3 category should be avoided, as this risks giving the impression of progress towards targets where no real effort to decarbonize has been made.

Some examples for the steel sector could include:

Table 4:  Scope 3 denominator examples

| SCOPE 3 TARGET COVERAGE                           | PHYSICAL INTENSITY REDUCTION DENOMINATOR EXAMPLES   |
|---------------------------------------------------|-----------------------------------------------------|
| Category 3: Upstream emissions from fuels         | Purchased fuels (t) Purchased fuels (MJ)            |
| Category 4: Upstream transport and distribution   | Materials transported (t)                           |
| Category 9: Downstream transport and distribution | Materials transported (t)                           |

## Limitations in the use of the iron &amp; steel SDA

The iron &amp; steel SDA may be used by companies whose main activity is the production of iron or steel.

Companies for which &gt;95% of their scope 1 and 2 emissions results from iron- and steelmaking processes falling under the iron &amp; steel core boundary can set a target using only the iron &amp; steel SDA; companies for which 5-95% of their scope 1 and 2 emissions results from iron- and steelmaking processes can use the iron &amp; steel SDA for the share of their emissions that falls under the iron &amp; steel core boundary.

Companies making an iron-bearing sector-specific intermediate product (i.e., HBI and pig iron or any potential future form of iron) may also use the SDA for these activities, given that the majority of the sector emissions result from ironmaking. However, these companies may only use the SDA if they expand their accounting to include the emissions associated with processing the intermediate product into hot rolled steel. They may use widely accepted reference emission values for this adjustment.

The iron &amp; steel SDA may be used by stainless steel producers for processes included within the iron &amp; steel core boundary.

Companies making a form of iron that is not further processed into steel may not use the iron &amp; steel SDA and should use the SBTi cross-sector methods. All other criteria in this guidance applicable to ironmakers apply.

Hydrogen and syngas producers cannot use the iron &amp; steel SDA as they produce sector-agnostic intermediate products.

## How can companies combine the iron &amp; steel SDA with the other SBTi target-setting approaches?

The cross-sector ACA or other relevant SDA shall be used for target-setting for scope 1 and 2 emissions from activities outside the iron &amp; steel core boundary. In Table 3, an overview of the different types of emissions a company can have, and their recommended target-setting approach has been included.

Detailed examples of target-setting for different types of companies are shown in the worked examples in a standalone document available on the SBTi webpage.

Companies wishing to combine or aggregate targets set using different methods (e.g., targets set using the iron &amp; steel SDA and the cross-sector ACA), are permitted to do so, under the following conditions:

- Data is submitted for validation that allows the ambition level of each element to be checked separately.
- Aggregation is technically feasible. Two different SDA-based targets such as tCO /t hot rolled steel and 2 tCO /t cement cannot be aggregated as intensity targets as the denominators are different, whereas two 2 absolute targets could be aggregated into one.
- When intensity targets are converted to absolute targets, it is required to also report the underlying intensity targets or sub-targets.

<!-- image -->

## CALCULATE EMISSIONS INVENTORY

In this step, companies should collect data for emissions, production volumes, and scrap ratios for their base year and most recent year, applying the criteria below regarding product definitions, emissions included, etc.

All GHG accounting for target-setting shall follow the SBTi Target Validation Protocol, the GHG Protocol Corporate Accounting and Reporting Standard, Scope 2 Guidance and Corporate Value Chain (Scope 3) Standard. Targets must cover all relevant GHGs as required by the GHG Protocol Corporate Standard and the SBTi Criteria.

## NECESSARY DATA POINTS FOR COMPANIES TO USE THE IRON &amp; STEEL SDA

For setting a target, companies will need to calculate their emissions inventory. This inventory should contain or be accompanied by the following data:

- Base year emissions as defined by the iron &amp; steel core boundary.
- Base year production (Mt hot rolled steel).
- Target year expected production (Mt hot rolled steel).
- Base year scrap ratio (%) - While companies are not obliged to disclose their base year scrap ratio when announcing their targets, it is needed for the target calculation, and companies are required to report their scrap ratio annually, starting from the base year of the target.
- Target year expected scrap ratio (%) - While companies are not obliged to disclose their expected target year scrap ratio when announcing their targets, it is needed for the target calculation, and companies are required to report their scrap ratio annually, starting from the base year of the target.

## ACCOUNTING METHOD FOR EMISSIONS DATA COLLECTION

All GHG accounting for target-setting shall follow the SBTi Criteria, the SBTi Target Validation Protocol, the GHG Protocol Corporate Accounting and Reporting Standard and the requirements set out by this document.

Companies should aim to collect emissions data for purchased products or processes that are included in the iron &amp; steel core boundary directly from the vendor. This emissions data should be based only on the processes included within the iron &amp; steel core boundary. If collecting data from vendors and/or customers is not possible, companies may use reference values for processing emissions and yield factors.

## DETERMINE SCRAP RATIO

## Figure 7: Flow of scrap in the steel sector 13

<!-- image -->

Four distinct types of scrap are used in the iron &amp; steel industry (as per Figure 7):

- Internal scrap, which is generated during manufacturing of crude steel, up to and including casting. This scrap is most often recycled immediately at the same facility it was created.
- Home scrap, which is generated during rolling and finishing of steel. This scrap is most often recycled immediately at the same facility it was created. Home scrap is counted towards the scrap irrespective of whether it comes from the company's own rolling facilities or an external rolling facility.
- Prompt scrap, also known as pre-consumer manufacturing scrap, is generated during the manufacturing of steel products by customers.
- End-of-life scrap, also known as post-consumer scrap, is generated at the end-of-life of a steel product.

13  Source: ETC and RMI for MPP.

For determining the scrap ratio, only home scrap, prompt scrap and end-of-life scrap entering the melt shop should be included.

To calculate the scrap ratio, only the ferrous metallics should be included. Because ferroalloys production is excluded from the iron &amp; steel core boundary, only the ferrous metallics should be included in the calculation of the scrap ratio.

The scrap ratio can be calculated with the following formula:

Total iron content of the scrap-based inputs

## Scrap ratio =

<!-- image -->

=

Total iron content of the scrap-based inputs + the ore-based inputs

<!-- image -->

Companies will likely have their own yield factors to calculate their scrap's ferrous content and total metallics inputs. If they cannot do so, the yield factors provided below can be used, but actual data should be always used if available.

<!-- image -->

Scrap steel: 98% Fe

<!-- image -->

<!-- image -->

Pig iron: 94% Fe 14

HBI and direct reduced iron (DRI): 90% Fe 14

- 14  Based on International Iron Metallics Association values found on www.metallics.org. See Appendix 2 for why these scrap streams are included in the scrap ratio calculation.

<!-- image -->

## CONSTRUCT TARGETS

To construct their science-based targets, companies should follow these steps:

<!-- image -->

Collect data for production forecasts to the target year.

- Input the emissions inventory and accompanying data from the previous steps into the target-setting tools to calculate the reductions required for valid targets for scope 1, 2 and 3, following the additional guidance in this document. 2
- Decide on target wording according to the SBTi submission form, this guidance and examples given on the steel webpage. 3

## HOW THE SCRAP-INPUT-DEPENDENT PATHWAY SHOULD BE USED BY DIFFERENT TYPES OF STEEL COMPANIES

Using the scrap-input-dependent pathway, companies will construct their own target pathway depending on their scrap use. In Figure 8 below, examples have been included for four distinct types of steel companies. The required intensity reduction by 2030 for the four types of companies is shown in Table 5.

## Figure 8: Use of the scrap-input-dependent pathway for four different types of steelmaking companies

<!-- image -->

## Table 5: Examples of using the scrap-input-dependent pathway for different types of companies*

| COMPANY   | PRODUCTION TYPE (STABLE SCRAP SHARE BETWEEN TARGET YEAR AND BASE YEAR)   |   BASE YEAR (2020) EMISSION INTENSITY (KG CO 2 eq/T HOT ROLLED STEEL) | REQUIRED INTENSITY REDUCTION BY 2030 VS 2020 (%)   |
|-----------|--------------------------------------------------------------------------|-----------------------------------------------------------------------|----------------------------------------------------|
| A         | 100% scrap-based                                                         |                                                                   500 | 26.1%                                              |
| B         | 100% scrap-based                                                         |                                                                   800 | 28.8%                                              |
| C         | 0% scrap-based                                                           |                                                                  1900 | 29.0%                                              |
| D         | 0% scrap-based                                                           |                                                                  2500 | 29.4%                                              |
| E         | 20% scrap-based                                                          |                                                                  1700 | 28.9%                                              |
| F         | 30% scrap-based                                                          |                                                                  1700 | 28.9%                                              |
| G         | 60% scrap-based                                                          |                                                                   900 | 27.5%                                              |
| H         | 50% scrap-based                                                          |                                                                   900 | 27.3%                                              |

* No production growth has been assumed. These are only illustrative examples.

## HOW FEEDSTOCK CHANGE AFFECTS TARGETS

Changes in emissions which happen only due to changes in feedstock (e.g., replacing coal with green hydrogen) do not trigger recalculation. However, targets calculations do depend on both the base and target year scrap input. Thus, for transparency and robustness it is necessary for companies to publish information on the scrap ratio considered in their target annually. If this were not the case, a company could calculate unambitious targets by assuming a minor increase in their scrap share, and then use increasing scrap to create a false perception that the target is met. Therefore, target wording must include a sentence indicating that the target depends on the scrap ratio. In addition, once the company has set targets, it must publish its scrap ratio annually thereafter 15 .

For reference, and so that external stakeholders can quickly understand how scrap share changes over time affect the reduction needed in a target, Table 6 shows examples of relative intensity reduction targets for the timeframe 2020-2030 for different base and target year scrap shares. Further examples can be calculated using the Steel Science-Based Target-Setting Tool.

15  Companies are not obliged to publish the activity or scrap share projections used to calculate the target. Stakeholders may wish to ask companies for this information if they have doubts about the projections used in the calculation.

Table 6:  Examples of relative intensity reduction targets for different base and target year scrap shares over the timeframe 2020-30*

|                         | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   | BASE YEAR SCRAP SHARE   |
|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|
| TARGET YEAR SCRAP SHARE | 0%                      | 10%                     | 20%                     | 30%                     | 40%                     | 50%                     | 60%                     | 70%                     | 80%                     | 90%                     | 100%                    |
| 0%                      | 29%                     | 23%                     | 16%                     | 7%                      | 0%                      | 0%                      | 0%                      | 0%                      | 0%                      | 0%                      | 0%                      |
| 10%                     | 35%                     | 29%                     | 23%                     | 15%                     | 5%                      | 0%                      | 0%                      | 0%                      | 0%                      | 0%                      | 0%                      |
| 20%                     | 40%                     | 35%                     | 30%                     | 22%                     | 13%                     | 1%                      | 0%                      | 0%                      | 0%                      | 0%                      | 0%                      |
| 30%                     | 46%                     | 42%                     | 36%                     | 30%                     | 21%                     | 11%                     | 0%                      | 0%                      | 0%                      | 0%                      | 0%                      |
| 40%                     | 52%                     | 48%                     | 43%                     | 37%                     | 30%                     | 20%                     | 8%                      | 0%                      | 0%                      | 0%                      | 0%                      |
| 50%                     | 57%                     | 54%                     | 49%                     | 44%                     | 38%                     | 30%                     | 19%                     | 4%                      | 0%                      | 0%                      | 0%                      |
| 60%                     | 63%                     | 60%                     | 56%                     | 52%                     | 46%                     | 39%                     | 30%                     | 17%                     | 0%                      | 0%                      | 0%                      |
| 70%                     | 68%                     | 66%                     | 63%                     | 59%                     | 55%                     | 49%                     | 41%                     | 30%                     | 14%                     | 0%                      | 0%                      |
| 80%                     | 74%                     | 72%                     | 69%                     | 66%                     | 63%                     | 58%                     | 52%                     | 43%                     | 30%                     | 9%                      | 0%                      |
| 90%                     | 79%                     | 78%                     | 76%                     | 74%                     | 71%                     | 68%                     | 63%                     | 57%                     | 47%                     | 31%                     | 0%                      |
| 100%                    | 85%                     | 84%                     | 83%                     | 81%                     | 79%                     | 77%                     | 74%                     | 70%                     | 63%                     | 53%                     | 32%                     |

* These examples were calculated on the basis of 2.4 tCO /t base year emissions intensity, and no growth; 2 companies in different situations will have different targets. (As a target must not lead to higher emissions than in the base year even where the scrap share is decreasing, targets are capped at 0%.)

## USING THE TARGET-SETTING TOOLS

The permitted target-setting methods for scope 1, 2 and 3 emissions are laid out below. The SBTi recommends using the most ambitious method that leads to the earliest reductions and the least cumulative emissions.

<!-- image -->

## Near-term target-setting tool

A standalone Steel Science-Based Target-Setting Tool is published alongside this guidance.

Iron- &amp; steelmakers using the iron &amp; steel SDA to calculate targets for activities within the core boundary should use the sheet entitled 'Iron &amp; Steelmaker Tool'.

Purchasers of steel using the iron &amp; steel SDA to calculate scope 3 category 1 targets for purchased steel should use the sheet entitled 'Steel Procurement Tool'.

Iron &amp; steelmakers using the ACA to calculate targets for activities within the core boundary should use the SBTi cross-sector tool and enter all core boundary emissions as if they were scope 1.

## Selecting the correct growth rate in the tool

The tool offers two options to input a company's growth rate/activity projection as part of the target calculation: 'fixed market share', where the company's percentage change in output over the target timeframe is assumed to be the same as the rate associated with the global pathway, or 'target year output', where the company should input its own projected output for its target year. Care should be taken to choose the correct option, as growth rate relative to the global rate will affect the intensity target calculated. If the company's growth is expected to be different from the global rate associated with the pathway, the 'target year output' option should be chosen.

(For reference, the global growth from 2019 to 2030 when 'fixed market share' is chosen for the 1.5°C steel pathway is 3.6%. To find the rate for other timeframes, select the desired timeframe in the tab 'Iron &amp; Steelmaker Tool'. The growth rate will be shown in tab 'Calculations'.)

## Net-zero target-setting tool

The Net-Zero Tool is found here and contains instructions for calculating long-term targets.

<!-- image -->

<!-- image -->

## Justification of projected growth

In the target-setting tools, there are two options for companies to project their activity in the target year, either fixed market share (assuming company's activity in line with the market share) or entering their target year output. Correct growth projection is important to ensure that absolute emissions do not exceed the carbon budget. The SDA calculation includes a correction to the emissions intensity pathway if a company's growth forecast is greater than that by the industry as a whole, so faster-growing companies must reduce their emissions intensity faster.

Therefore, companies submitting targets shall provide justification for the growth forecast used in their target submission, including public or internal documents where growth projections are mentioned if relevant.

As a voluntary safeguard, companies may wish to make public the absolute emissions that their intensity target would lead to, so that stakeholders can see that it leads to absolute reductions.

## Justification if scrap ratio is decreasing

In the case of a company whose scrap ratio decreases over the target timeframe, the minimum emission reduction required may be less than the case where the scrap ratio stays constant or increases. This flexibility allows for companies that, for example, might want to move from scrap-based production into ironmaking-and does not remove the obligation for such companies to decarbonize the primary ironmaking stage.

However, to avoid a situation where  companies could set seemingly lenient targets without justification, companies planning a reduction in their scrap ratio shall submit a description of why they plan on this to the Target Validation Team (TVT) when submitting their target  (e.g., press releases confirming investment in ironmaking capacity). Companies shall also disclose the fact that their target has been calculated on the basis of a decreasing scrap ratio in public documents alongside their target.

Additionally, the target is never allowed to become negative, meaning that a company's emission intensity can never increase during the target timeframe.

## EXAMPLES OF TARGET WORDING

## Target wording should use the following format:

'Company X commits to reduce scope 1, 2 and 3 GHG emissions covered by the iron &amp; steel core boundary 35% per tonne of hot rolled steel by 2030 from a 2020 base year. As this target calculation depends on the scrap ratio projection, company X will publish the scrap ratio associated with this target annually starting from the base year.'

'Company X also commits to reduce all other scope 1 and 2 GHG emissions 42% over the same timeframe.'

'Company X further commits to reduce scope 3 GHG emissions from fuel- and energy-related emissions 25% over the same timeframe.'

For further examples, see the worked examples on the steel webpage.

<!-- image -->

## SUBMIT TARGETS TO THE SBTi

Companies should follow the general SBTi guidelines for submitting a target for validation. The following sections include some additional criteria and recommendations for steel companies.

## ENSURING NEAR-TERM TARGETS CONTRIBUTE TO LONG-TERM PROGRESS

Long-term steel decarbonization roadmaps rely on breakthrough technologies such as CCS and green hydrogen that do not yet exist at scale before 2030, or rely on infrastructure that is yet to develop. Because of this, during the first few years of the iron &amp; steel SDA, it might be possible for companies to comply with the SDA and be validated without any plan to invest in breakthrough technologies, effectively postponing decarbonization measures. There is a credibility issue in claiming such targets are science-based. Furthermore, in order to ensure that the emissions reductions required post-2030 materialize, all investments, even in the short term, must be in line with the emissions reductions pathway of the 2030s. For example, before 2030, 71% of existing coal-based blast furnaces will reach the end of their lifetimes and require major investments (Agora Energiewende, 2022).

To deal with the risks described above, steel companies submitting near-term or long-term targets should provide additional qualitative evidence that demonstrates the integrity of commitments to prepare for implementing new technology as part of a plan to reach net-zero. Such evidence could include:

- Published R&amp;D spend in breakthrough technologies.
- Assessment of 'readiness for net-zero' by other third party initiatives, such as ACT.
- Published plans to invest in net-zero emissions iron- or steelmaking capacity.

<!-- image -->

## UPDATING A TARGET

When a company changes the target-setting methods used compared to its previous targets, they should demonstrate that the ambition level (in terms of both the relative reduction in absolute and intensity emissions, and target-year emissions level) of the new targets are more ambitious than the company's targets previous to the update. This increased ambition should be clearly evident to stakeholders reading the target wording.

<!-- image -->

## What counts to meet a science-based target?

This guidance document provides criteria and recommendations to help companies in the steel sector and its value chain set near- and long-term science-based targets that are aligned with a 1.5°C ambition. It does not go into details about the decarbonization levers that may be used to achieve targets, as these will be up to each individual company's strategy.

All decarbonization levers that lead to an emissions reduction in scope 1, 2 and/or 3 according to the SBTi Criteria and GHG Protocol accounting rules are valid. These may include increasing scrap use and energy efficiency, fuel switching to fossil-free electricity, introducing top gas recycling, replacing injected coal in blast furnaces with sustainably sourced biofuels as well as breakthrough technologies such as CCS and BECCS 16 .

## Upstream biogenic emissions

The use of biomass, such as biochar, as fuels and carbon-containing raw materials may be a significant decarbonization lever for iron &amp; steel production.

The rules laid out in the SBTi Criteria C10 shall be followed when accounting for emissions associated with biomass feedstocks, which include emissions and removals from land use, emissions from processing and distribution, and combustion emissions. Companies should also follow the SBTi Criteria recommendations R3 and R4. For further guidance, companies should refer to the Target Validation Protocol. Any form of biomass that contributes to the degradation of loss of natural forests or competition for land use between fuel and food should be avoided.

Companies are required to set Forest, Land and Agriculture (FLAG) targets if their FLAG-related emissions 17   total 20% or more of the overall emissions across the scopes. Please refer to the SBTi FLAG Guidance for details.

16  SBTi Criteria shall be followed with regard to bioenergy accounting.

17  FLAG-related emission includes Land Use Change (LUC) CO  emissions, land management emissions, carbon removal and storage. 2

<!-- image -->

<!-- image -->

## Raw material preparation (e.g., beneficiation)

Coal mining, iron ore mining and beneficiation (remove of gangue minerals which results in a highergrade ore concentrate, including crushing and grinding, hydroclassification, magnetic separation, and flotation) are outside the iron &amp; steel core boundary. The definition of pelletization/pellet plant operations is based on the European Union's Best Available Techniques reference documents (BREF, 2013) which consists of drying and grinding/dewatering steps after the upgrading of iron ore (from magnetic separation, flotation, etc.) feed preparation (e.g., wetting and mixing with binders), balling, induration, and screening steps to produce the pellets.

Source: Sustainable Steel Principles (RMI, 2022)

<!-- image -->

## USE OF IRON &amp; STEEL SDA BY UPSTREAM AND DOWNSTREAM COMPANIES

## Upstream iron ore suppliers and hydrogen producers

Iron ore suppliers may use the irons &amp; steel SDA to set their scope 3 category 10 'processing of sold products' target, and the ambition level must be 1.5°C-aligned. When using the iron &amp; steel SDA, iron ore suppliers need to incorporate all further downstream processing emissions included in the core boundary. Alternatively, they can use the other scope 3 target-setting methods (please refer to Table 7 for more details).

Hydrogen and syngas producers cannot use the iron &amp; steel SDA as they produce sector-agnostic intermediate products. Other scope 3 methods should be used (Table 7) unless they can prove their products are solely (&gt;95%) used in manufacturing of iron &amp; steel.

## Downstream companies (e.g., construction and automotive companies)

Emissions from the manufacturing of steel may be a relevant source of scope 3 emissions for companies in other sectors, such as the automotive and construction value chain. The 'Steel SDA - for steel purchasers' , rather than the generic scope 3 methods, may be used for scope 3 target-setting where the emissions concerned are from the manufacture of steel and occur inside the core boundary.

However, as reduction of the use of steel can be a key lever for reducing scope 3 emissions for these types of companies, target-setters should ensure the target-setting method reflects this. Therefore, a scope 3 absolute target may be more appropriate, and provide companies more levers to reduce emissions, than an intensity target. Table 7 shows a summary of the target-setting methods and ambition levels for these upstream and downstream suppliers.

Future sector-specific guidance, such as for the buildings sector, may prohibit the use of the 'Steel SDA - for steel purchasers' for scope 3 target-setting for construction if it is deemed not appropriate due to the importance of demand reduction.

Table 7:  Target-setting methods for upstream and downstream companies

| COMPANY TYPE                                                               | TARGET-SETTING METHODS                                                                                                                                       | AMBITION      |
|----------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|
|                                                                            | Iron &steel SDAcan be used for scope 3 emissions in the core boundary                                                                                        | 1.5°C         |
| Iron ore supplier (Category 10: processing of sold products)               | Other scope 3 methods: Cross-sector absolute reduction Physical intensity (7% annual reduction) Economic intensity (7% annual reduction) Supplier engagement | WB2Cor1.5ºC   |
| Hydrogen producer (considered as sector agnostic products)                 | Cannot use the iron &steel SDA unless they can prove their products are solely used for the iron &steel producers: Use other scope 3 methods                 | WB2C          |
|                                                                            | Steel SDA - for steel purchasers, can be used for scope 3 emissions in the core boundary                                                                     | 1.5°C         |
| Automaker, construction company (Category 1: purchased goods and services) | Other scope 3 methods Cross-sector absolute reduction Physical intensity (7% annual reduction) Economic intensity (7% annual reduction) Supplier engagement  | WB2C or 1.5ºC |

An option 'Steel SDA - for steel purchasers' is found in the Steel Science-Based Target-Setting Tool, in the 'Steel Procurement Tool' tab. For simplicity, the tool does not differentiate targets based on the scrap share. The 'output' considered should be tonnes of purchased hot rolled steel 18 . As per the GHG Protocol, emissions under scope 3 category 1 'purchased goods and services' must be accounted for on a cradle-to-gate basis.  For companies using the 'Steel SDA - for steel purchasers' to set their scope 3 emissions target, the ambition level will be 1.5°C-aligned (as the iron &amp; steel SDA methodology is 1.5°C-aligned by design). A worked example for steel purchasers is found on the steel webpage.

## Financial institutions (FIs)

FIs can use the iron &amp; steel SDA to set scope 3 category 15 targets for their investment and lending activities to steel companies. Detailed steps on how to calculate the physical emissions intensity for SDA targets for FIs can be found in the Financial Sector Science-Based Targets Guidance. This requires scope 1 and 2 emissions from borrowers/investees and annual activity or output data per company in the base year (i.e., tonnes of hot rolled steel 19 ). A relevant attribution factor 20 is applied to both absolute emissions and activity, and used as input into the SBTi tools to calculate the emissions intensity in the base year. FIs will also need to acquire information about the scrap share for the activity/output. If this information is not available, a default value for scrap share of 0%  should be used.

## Target wording should use the following format:

FI X commits to reduce GHG emissions from the steel sector in its equity portfolio / within its corporate lending portfolio by Y% per tonne of hot rolled steel by 2030 from a 2020 base year.

18  For simplicity, other units of purchased steel, such as crude steel, cold-rolled steel or steel products may be used as the output unit in the tool for steel purchasers.

19  FIs should strive to use hot rolled steel as the denominator when applying the SDA. However, for simplicity, other units of produced steel, such as crude steel, cold-rolled steel or steel products may be used as the activity unit in the SDA by FIs.

20  See the Financial Sector Science-Based Targets Guidance for how to calculate attribution factors.

<!-- image -->

## GLOSSARY

## GLOSSARY

| TERM   | DEFINITION                                               |
|--------|----------------------------------------------------------|
| ACA    | Absolute Contraction Approach                            |
| BECCS  | Bioenergy, carbon capture and storage                    |
| BF-BOF | Blast furnace-basic oxygen furnace                       |
| BOF    | Basic oxygen furnace                                     |
| CCS    | Carbon capture and storage                               |
| CCU    | Carbon capture and use                                   |
| DAC    | Direct air capture                                       |
| DRI    | Direct reduced iron                                      |
| EAF    | Electric arc furnace                                     |
| GHG    | Greenhouse gas                                           |
| HBI    | Hot briquetted iron                                      |
| IEA    | International Energy Agency                              |
| IPCC   | United Nations Intergovernmental Panel on Climate Change |
| SBT    | Science-based target                                     |
| SDA    | Sectoral Decarbonization Approach                        |
| WB2C   | Well below 2°C                                           |

## BIBLIOGRAPHY

## BIBLIOGRAPHY

Agora Energiewende, 2022, Global Steel Transformation Tracker, last updated 11 August 2022. Available at: https:/ / www.agora-energiewende.de/en/service/global-steel-transformation-tracker/#:~:text=Before%202030%2C%20 71%25%20of%20existing,170%20Mt%20of%20new%20capacity

BREF, 2013. Best Available Techniques (BAT) Reference Document for Iron and Steel Production, Industrial Emissions Directive 2010/75/EU (Integrated Pollution Prevention and Control), European Commission, Joint Research Centre. Available at: https:/ /eippcb.jrc.ec.europa.eu/sites/default/files/2019-11/IS\_Adopted\_03\_2012.pdf

E3G &amp; PNNL, 2021. 1.5°C Steel: decarbonising the steel sector in Paris-compatible pathways. Available at: https:/ / www.e3g.org/publications/1-5c-steel-decarbonising-the-steel-sector-in-paris-compatible-pathways/

ETC, 2023, Energy Transitions Commission - Unlocking The First Wave of Breakthrough Steel Investments International Opportunities, The United Kingdom, Spain, France, and the United States. Available at: https:/ /www. energy-transitions.org/publications/breakthrough-steel/#download-form

GHG Protocol, Greenhouse Gas Protocol Corporate Accounting Standard - Revised Standard. Available at: https:/ / ghgprotocol.org/corporate-standard

IDDRI, 2021. Global Facility Level Net-Zero Steel Pathways. Available at: http:/ /netzerosteel.org/wp-content/ uploads/pdf/net\_zero\_steel\_report.pdf

IEA, 2017. Energy Technology Perspectives 2017. Catalysing Energy Technology Transformations, IEA, Paris. Available at: https:/ /doi.org/10.1787/energy\_tech-2017-en

IEA, 2020. Iron and Steel Technology Roadmap, IEA Paris. Available at: https:/ /www.iea.org/reports/iron-and-steeltechnology-roadmap, Licence: CC BY 4.0

IEA, 2021. Net Zero by 2050. Available at: https:/ /iea.blob.core.windows.net/assets/deebef5d-0c34-4539-9d0c10b13d840027/NetZeroby2050-ARoadmapfortheGlobalEnergySector\_CORR.pdf

IEA, 2022a. World Energy Outlook, October 2022. Available at: https:/ /iea.blob.core.windows.net/assets/830fe0995530-48f2-a7c1-11f35d510983/WorldEnergyOutlook2022.pdf

IEA, 2022b. Achieving Net Zero Heavy Industry Sectors in G7 Members, IEA Paris. Available at: https:/ /www.iea.org/ reports/achieving-net-zero-heavy-industry-sectors-in-g7-members, Licence: CC BY 4.0

IPCC, 2021. Climate Change 2021: The Physical Science Basis. Contribution of Working Group I to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. Cambridge University Press. Available at: Climate Change 2021: The Physical Science Basis | Climate Change 2021: The Physical Science Basis (ipcc.ch)

Kildahl, H., Wang, L., Tong, L. and Ding, YL. 2023. Cost effective decarbonisation of blast furnace - basic oxygen furnace steel production through thermochemical sector coupling. Journal of Cleaner Production , (2023) 289:135963. DOI:10.1016/j.jclepro.2023.135963 Available at:  https:/ /www.researchgate.net/ publication/366898849\_Cost\_effective\_decarbonisation\_of\_blast\_furnace\_-\_Basic\_oxygen\_furnace\_steel\_ production\_through\_thermochemical\_sector\_coupling

Lopes, D., Lisenkov, A. and Kavaleuski, A. 2023. SIDERWIN project: A breakthrough technology to decarbonize primary steel production through direct electrification. Concluding webinar on 23 March, 2023. Available at: https:/ / zenodo.org/record/7785032#.ZFRL43bMKUl

MPP, 2021. Mission Possible Partnership - Net-Zero Steel Sector Transition Strategy. Available at: https:/ /www. energy-transitions.org/publications/the-net-zero-steel-sector-transition-strategy/

MPP, 2022. Making Net-Zero Steel Possible - An industry-backed, 1.5°C-aligned transition strategy. Available at: https:/ /missionpossiblepartnership.org/wp-content/uploads/2022/09/Making-Net-Zero-Steel-possible.pdf

NZS PMP, 2021. The Net-Zero Steel Pathway Methodology Project Final Report and Recommendations. Available at: https:/ /www.netzerosteelpathwayproject.com/

OECM, ISF, 2020. Sectoral Pathways to Net Zero Emissions. Available at: https:/ /www.uts.edu.au/sites/default/ files/2020-12/OECM%20Sector%20Pathways%20Report%20FINAL.pdf

OECM, ISF, 2022. Limit Global Warming to 1.5°C. Available at: https:/ /www.uts.edu.au/sites/default/ files/2022-07/2622%20UTS%20Limit%20Global%20Warming%20report%20mr%2005b\_UPLOAD%5B64%5D.pdf

ResponsibleSteel, 2022. ResponsibleSteel International Standard Version 2.0. Available at: https:/ /www. responsiblesteel.org/wp-content/uploads/2022/10/ResponsibleSteel-Standard-2.0.1.pdf

RMI, 2022, The Sustainable STEEL Principles, September 2022. Available at: https:/ /climatealignment.org/wpcontent/uploads/2022/06/sustainable\_steel\_principles\_framework.pdf

WSA, 2022. World Steel Association CO  Data collection system https:/ /worldsteel.org/wp-content/uploads/CO2\_ 2 User\_Guide\_V11.pdf

## Photo credits

Boris Bukovský. Metallurgy-2932943. Image from Pixabay

Boris Bukovský. Metallurgy-2932947. Image from Pixabay

Kateryna Babaieva. Man Standing Near Fire. Image from Pexels

Photo by Angie-Cruz on Unsplash

Photo by Ant Rozetsky on Unsplash

Photo by Alex Simpson on Unsplash

Photo by Daniel Wiadro on Unsplash

Photo by Robin Sommer on Unsplash

Photo by Zhu Hongzhi on Unsplash

## APPENDIX 1: DEVELOPMENT OF THE PATHWAYS

## APPENDIX 1:

## DEVELOPMENT OF THE PATHWAYS

## GLOBAL CARBON BUDGET AND ITS ALLOCATION TO THE SECTOR

The SBTi published an assessment of possible 1.5 C emissions scenarios for all sectors in its Pathways to Net-Zero: ° SBTi Technical Summary (2021). This reviewed estimates of the remaining emissions budget, top-down mitigation scenarios, and sectoral studies to determine 1.5 C-aligned pathways at the global and sectoral level. According ° to the Intergovernmental Panel on Climate Change (IPCC), the remaining budget to limit global warming to 1.5 C ° with a 50% probability is about 500 GT of CO  (IPCC 2021). In aggregate, 1.5 C-aligned pathways used by the SBTi 2 ° stay within the 500 GT carbon budget and reach net-zero CO  at the global level by 2050, under the assumption of 2 at least 1-4 GT CO  removal per year by 2050. Within this framework, the SBTi developed a cross-sector emissions 2 corridor that covers CO , CH , and N O emissions from energy supply, buildings, industry and transport based on 2 4 2 published studies and expert judgement.

The Pathways to Net-Zero: SBTi Technical Summary determines that the range of 1.5 C-aligned cumulative 2020-2050 ° direct emissions for steel in the literature is 20-40 GT CO . Therefore, emissions scenarios with these cumulative direct 2 emissions (or lower) could be considered as a potential scenario for 1.5 C science-based target-setting by the SBTi. °

## CHOICE OF EMISSIONS SCENARIOS FOR 1.5 C ⁰

Emissions scenarios for science-based target-setting should meet the criteria of plausibility (credibility of narrative), responsibility (reduced risk of not meeting the 1.5 C goal), objectivity (not biased towards any particular industry or ° organization) and consistency (they should have a strong internal logic) 21 .

Several organizations have created decarbonization pathways for the iron &amp; steel industry. The most well-known 1.5°C aligned pathways include the IEA's Net Zero Emissions scenario (IEA, 2021), the Global Steel Facility Level Net-Zero Steel Pathways by IDDRI (IDDRI, 2021), the One Earth Climate Model (OECM, 2020 &amp; 2022) and the Mission Possible Project's Sector Transition Strategy for Iron &amp; Steel (Carbon Cost scenario) (MPP, 2021).

We have reviewed seven pathways describing scenarios for the iron &amp; steel sector to reduce emissions 22 . These pathways include a wide range of opportunities available to the iron &amp; steel sector to transform its processes towards near-net-zero steel production, often coupled with demand-side measures such as lightweighting and creating more durable products. The sector can realize initial emission reductions by increasing scrap use and energy efficiency, and by switching to fossil-free electricity for mainly electricity-based processes such as EAF production. Decommissioning sintering plants in favour of pelletizers, introducing top gas recycling, and replacing injected coal in blast furnaces with sustainably sourced biofuels (e.g., wood charcoal) and electrolytic hydrogen can also serve as intermediate solutions.

21  For more details, see: Foundations of Science Based Target-Setting.

22  The seven pathways were (not all are 1.5°C-aligned):  Net Zero by 2050 (IEA, 2021), 1.5°C Steel (E3G &amp; PNNL, 2021), Global Facility Level Net-Zero Steel Pathways (IDDRI, Bataille et al., 2021), Net-Zero Steel Sector Transition Strategy (MPP,  2021), Sectoral Pathways to Net Zero Emissions (OECM, ISF 2020), Limit Global Warming to 1.5°C (OECM, ISF 2022), Energy Technology Perspectives (IEA, 2017).

However, to eliminate the major share of emissions, implementation of breakthrough technologies, such as using exclusively electrolytic hydrogen as a reductant or applying CCS (carbon capture and storage) with high capture rates, becomes crucial. The reviewed pathways agree that investments in unabated BF-BOF (blast furnace-basic oxygen furnace) production need to cease sooner rather than later, because of the long investment cycles in the industry.

After the analysis of the different pathways, the iron &amp; steel SDA was based on the IEA NZE scenario 23 due to the fact that it aligns with the SBTi's principles for the choice of scenarios: plausibility, responsibility, objectivity and consistency.

## THE IEA NET ZERO BY 2050 REPORT

The IEA Net Zero by 2050 report (IEA, 2021) was developed to show an achievable pathway for the global energy sector and selected sectors to achieve net-zero emissions by 2050. The pathway includes the iron &amp; steel sector, providing global direct CO  emissions 24  on a 10-year increment between 2020-2050. 2

## ON WHICH KEY ASSUMPTIONS WAS THE SCENARIO BUILT?

The IEA NZE scenario assumes growth in steel demand to slow down: between 2020-2030, the sector will grow at a compound annual growth rate (CAGR) of 0.8%, and between 2030-2050 at 0.1%, resulting in 2050 steel demand of 1,987 Mt.

On the production side, the IEA NZE scenario assumes an increase of scrap use: scrap as share of input climbs from 32% in 2020 to 46% in 2050. The IEA also expects a radical technological transformation of iron &amp; steel production.

Technologies such as scrap-based EAFs, H -based DRI, iron ore electrolysis and further electrification of 2 processes will shift a large share of energy use from coal to electricity.

## ADJUSTMENTS TO IEA NET ZERO BY 2050 DATA

The data from the IEA Net Zero by 2050 report were modified for the purposes of defining a pathway to be used in the SDA in order to align to the core boundary. To do this, 1.5ºC-aligned scenarios for self-generated and purchased electricity, as well as hydrogen and syngas, were developed and attributed to the sector, while emissions from ferroalloy production were estimated and subtracted. The total budget for the iron &amp; steel core boundary aligned emissions pathway between 2020-2050 is 53.2 Gt.

23  The latest IEA NZE sector budgets in the recent World Energy Outlook 2022 report in Oct 2022 (IEA, 2022a) shows a 15% increase in the carbon budget from 2020 - 2050 in comparison to the IEA NZE report (IEA, 2021). To be consistent with other already published sector guidance based on the IEA NZE 2021 carbon budget, it was decided not to use the latest figures in this steel guidance.

24  The IEA NZE boundary includes hot rolling in the scope 1 emissions (from discussion with the IEA).

APPENDIX 2: HOW WAS THE SECTOR 1.5ºC PATHWAY DISAGGREGATED INTO TWO PATHWAYS?

## APPENDIX 2:

## HOW WAS THE SECTOR 1.5ºC PATHWAY DISAGGREGATED INTO TWO PATHWAYS?

## HOW WERE THE 100% ORE-BASED AND 100% SCRAP-BASED TARGET EMISSION PATHWAYS ESTABLISHED?

To construct the primary and secondary emission pathways from the sector pathway, the following steps were followed:

- Establish current and 2050 100% scrap-based steelmaking emission intensity, and determine the intensity reduction trajectory (the steeper it is, the less incentive to use scrap).
- Multiply scrap consumption by scrap-based steelmaking emission intensity to arrive at annual scrapbased steelmaking emissions.
- Deduct annual scrap-based steelmaking emissions from the total emissions pathway for all iron &amp; steel production: the result is the 100% ore-based emissions pathway.

In this method, the selection of an emission intensity pathway for 100% scrap-based steelmaking is key to ensuring the right behavior is promoted. The scrap-based steelmaking pathway was adjusted to find the balance between:

- Sufficiently ambitious emissions intensity targets to incentivize both primary and secondary steelmakers to decarbonize.
- Sufficiently lenient emissions intensity targets to incentivize steelmakers to increase their scrap ratio, and not punish high scrap ratios with stricter targets.

This was achieved by setting a starting point (2020) for the 100% scrap-based pathway at the median emission intensity (~500 kg CO e / t hot rolled steel), and the convergence point in 2050 at the same level for both the 2 primary and scrap-based pathways (109 kg CO e/ t hot rolled steel). 2

<!-- image -->

## REASONS FOR AND AGAINST SCRAP-INPUT-DEPENDENT PATHWAYS

The system proposed in this guidance provides a varying decarbonization pathway depending on the scrap input used by the steelmaker in question. This system is preferable to a single pathway, in order to ensure primary production is decarbonized.

- A single pathway would lead to targets for primary-based producers that can be achieved by increasing the scrap input alone, which means there is a smaller incentive to reduce the carbon intensity of ironmaking, which is the most challenging and emissions-intensive part of the process.
- A single pathway puts little pressure on scrap-based producers to reduce emissions, and yet emissions from these production routes are far from negligible today, even if they compare favourably with orebased production.

Some reasons for why a single pathway might be preferable are put forward below, with a response as to how these concerns are addressed.

## Table 8: Responses to concerns of having scrap-input-dependent pathways

| CONCERNS AROUND THE SCRAP- INPUT-DEPENDENT PATHWAYS                                                                                                                                                                          | RESPONSE                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 'If the disaggregated pathways are not calibrated well, they fully neutralize any benefit to shifting to using more scrap, and therefore the shift to more circularity needed in the sector as a whole will not materialize' | The pathways have been calibrated carefully so that, while they partially neutralize the effect of scrap to encourage decarbonization of ore-based production (discussed above), they nevertheless do encourage a generalized increase in scrap use in the sector for two reasons: the shape of the scrap- based curve means that as a company moves towards this by increasing its scrap, minimum target ambition decreases; and levers available for decarbonizing scrap-based production are 'easier' than for ore-based, and so pressure to decarbonize will always incentivize a general move towards these production routes. The abatement potential of scrap, by avoiding the production of primary iron units, is the highest when scrap is used directly at the most emission-intensive steel production sites. If the SDA were to aggressively incentivize scrap use at the company level, 'scrap drain' would likely occur: scrap flowing from non-science-based target-setting companies to science-based target-setting companies, increasing emissions intensities and/or production volumes of the most emission-intensive steel production. Additionally, companies intending to use a significant increase in scrap share as a decarbonization lever always have the option to use the ACA at 1.5°C instead of the iron &steel SDA. |
| The disaggregated pathways are unfair to primarily scrap-based producers, because the primarily ore-based producer is 'permitted' a much higher emission intensity                                                           | Science-based targets are forward-looking targets and cannot be used for product comparisons or comparisons of companies' current emission intensity. Science-based targets are expressed as a relative reduction in emissions over a timeframe, and are individual to each company based on their starting emissions and activity growth. The SDA methodology recognizes various starting points of companies and simply assumes that by 2050 they should converge to a single point.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| A higher-intensity ore-based path gives ore-based producers a 'free pass' to continue business as usual                                                                                                                      | The ore-based path requires even steeper near-term emissions reductions than the scrap-based path, in relative terms. Dynamic scrap ratio-driven adjustment to targets ensures that ore-based assets will have to be decarbonized to a significant degree, irrespective of the mix of input metallics, or replaced with scrap-based capacity which then can be decarbonized using renewable electricity.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |

## DEFINITION OF SCRAP RATIO FOR TARGET CALCULATION

The scrap input to be used in a company's target calculation is intended to align approximately with the core boundary and carbon budget, and so it represents all scrap entering the system from an external source. The reason for this is that internally-produced scrap should be minimized and reused internally by companies. Including internally-produced scrap in the scrap ratio calculation would introduce a perverse incentive to increase this in order to have a higher scrap ratio.

The exception to this is 'home scrap', which is included in the scrap ratio calculation. The reasons for its inclusion is simply for practical reasons for accounting, as it is often impractical to separate scrap produced before or after the hot rolling step.

Therefore, for determining the scrap ratio, only home scrap, prompt scrap and end-of-life scrap entering the melt shop should be included. This method is aligned with ResponsibleSteel's standard and with the IEA Net Zero by 2050 pathway.

## THE STEEL SECTOR 1.5ºC PATHWAYS

Table 9 shows the emission intensity for the steel sector 1.5°C pathways for 100% ore-based and 100% scrap-based production from 2020 to 2050, with percentage of reduction illustrated in Figure 9.

## Table 9:  The emission intensity for 1.5ºC pathway*

| PRODUCTION ROUTE                                                       |   2020 |   2030 |   2040 |   2050 |
|------------------------------------------------------------------------|--------|--------|--------|--------|
| Sector - 100%ore-based emissions intensity (tCO 2 /t hot rolled steel) |   2.42 |   1.71 |   0.77 |   0.11 |
| 100% scrap-based emissions intensity (tCO 2 /t hot rolled steel)       |   0.5  |   0.37 |   0.24 |   0.11 |

- * Full data can be found in the target-setting tool

## Figure 9: Steel sector 1.5ºC pathways

<!-- image -->

## APPENDIX 3: DEVELOPMENT OF THE IRON &amp; STEEL CORE BOUNDARY

## APPENDIX 3:

## DEVELOPMENT OF THE IRON &amp; STEEL CORE BOUNDARY

The iron &amp; steel core boundary was designed to include the most material sources of emissions, to enable all types of iron &amp; steel makers to set science-based targets and to harmonize the activities included by different types of companies.

## INCLUSION OF HOT ROLLING

The boundary has been set based on the assumption that it covers the largest sources of emissions in the steel industry while also covering the process steps shared between most steel products. To start with, almost every steel product will go through the steps required to make hot rolled steel, in contrast with downstream processing steps (e.g., galvanization or cold rolling), which can differ significantly per product and per company. Second, emissions from hot rolling are substantial. Third, one of the main sources of variation in hot rolling emissions is whether a company uses blast furnace off-gases as fuel as part of the process. Since off-gases are an important part of integrated steelmaking's carbon footprint, hot rolling has to be included to make sure the boundary enables consistent treatment of off-gases irrespective of where in the plant they are used.

<!-- image -->

## EXCLUSION OF FERROALLOYS

Ferroalloy production is excluded from the core boundary and the sector carbon budget for the following reasons:

- The emissions profile of ferroalloys production and high-alloy steels is vastly different from the production of regular carbon steel, and there is currently no widely accepted decarbonization pathway for them, and therefore the sector pathway is not necessarily appropriate.
- Including ferroalloys production would effectively shift a large part of the decarbonization burden for high-alloy steel producers to scope 3, which, according to the SBTi criteria generally has a lower ambition level and a lower data quality requirement.

Therefore, instead of including ferroalloy production in the core boundary, high-alloy steel producers are recommended to set a separate scope 3 target covering these emissions (and in many cases this will effectively be a requirement if these emissions mean the company's scope 3 is greater than 40% of scope 1, 2 and 3).

## METHANE FROM FOSSIL FUEL EXTRACTION

Upstream emissions from the extraction and production of fuels, energy, iron ore and metallurgical coal are material, but lack sufficiently accurate and stable data. Adjusting the carbon budget to include these emissions is therefore risky, as it could lead to a substantial under- or overstatement of the budget available to the iron &amp; steel sector. Therefore, it was decided to keep these emissions outside the core boundary and the emissions budget, and instead require a separate scope 3 target that would include these emissions.

The inclusion of this mandatory target may support increased data availability. The UN Methane Partnership can be considered as one of the best practices in addressing methane emissions. As data on upstream methane emissions will likely improve greatly within the next few years, the SBTi steel guidance should be updated within two years to review the ambition level.

## COMPARISON OF THE IRON &amp; STEEL CORE BOUNDARY WITH OTHER EXISTING BOUNDARIES AND REPORTING METHODS

The boundary used in this guidance was designed for the purpose of setting a company-level emission reduction target. Boundaries used by other organizations have different purposes: for example, ResponsibleSteel aims to certify sites and benchmark products.

The EAG discussed whether further effort should be made to align the boundary with other systems, and decided that as the purpose of other systems is not the same, full alignment is neither possible nor desirable.

Overall, companies setting a science-based target will report in agreement with the GHG Protocol Corporate Accounting Standard. The iron &amp; steel core boundary can also be related to other iron &amp; steel emission pathways and reporting efforts, as has been done in Table 10 for the sources of emissions that vary the most between the different system boundaries compared.

<!-- image -->

The system boundary suggested by the NZS PMP (NZS PMP, 2021) 25 , is similar to the iron &amp; steel core boundary, with the difference that the SBTi excludes emissions from the production of biomass, biogas and ferroalloys, and includes hot rolling. The iron &amp; steel core boundary closely matches the ResponsibleSteel Standard boundary (ResponsibleSteel, 2022), with the exception of the inclusion of hot rolling for the SBTi, and the inclusion of upstream emissions for ResponsibleSteel. When compared to the Sustainable STEEL Principles (RMI, 2022) and World Steel Association CO  Data collection system (WSA, 2022), the iron &amp; steel core boundary includes fewer 2 downstream emissions: Sustainable STEEL Principles and WSA includes cold rolling and coating. Another key difference is that the WSA only collects CO  data, and does not include other GHG emissions. 2

The iron &amp; steel core boundary closely matches the IEA 26  'crude steel' system boundary (IEA, 2022b) for near zero emission steel production, with the exception of upstream emissions from fossil fuel supply, which the IEA includes. The iron &amp; steel core boundary is broader than the boundary used in the IEA Net Zero by 2050 model (IEA, 2021), which only includes scope 1 emissions for iron &amp; steel making. All scope 2 emissions are counted towards the power sector by the IEA.

This boundary will be used to compare emissions at the company level, and it may not interfere in site-level reporting required by governments or industry associations. These reporting schemes may be used to reduce the administrative burden where possible (i.e., by providing reference values for purchased products within the iron &amp; steel core boundary).

- 25  The Net Zero Steel Pathway Methodology Project has made recommendations on developing guidance for steelmakers who wish to make a commitment to set a net-zero or a near-term science-based target.
- 26  As proposed by the IEA in 'Achieving Net Zero Heavy Industry Sectors in G7 Members (2022).

## Table 10: Comparison of the iron &amp; steel core boundary and other initiatives' boundaries, on the processes that show the largest differences*

| PROCESSES                                                    | IRON & STEEL SDA   | WSA   | IEA NZE DIRECT   | IEA NZE INDIRECT   | IEA ACHIEVING NET ZERO HEAVY INDUSTRY (G7)   | RESPONSIBLE STEEL   | SUSTAINABLE STEEL PRINCIPLES   | NZAPMP CRUDE STEEL BOUNDARY   |
|--------------------------------------------------------------|--------------------|-------|------------------|--------------------|----------------------------------------------|---------------------|--------------------------------|-------------------------------|
| Extraction, processing and transportation of material inputs | Χ                  | Χ     | Χ                | Χ                  | √                                            | √                   | Χ                              | Χ                             |
| Emissions from extraction/ processing of fuels/ reductants   | Χ                  | √     | Χ                | Χ                  | √                                            | √                   | Χ                              | Χ                             |
| Credits for electricity emissions exported                   | Χ                  | √     | Χ                | Χ                  | Χ                                            | √                   | Χ                              | √                             |
| Credits for slag exported                                    | Χ                  | √     | Χ                | Χ                  | Χ                                            | Χ                   | Χ                              | Χ                             |
| On-site generation of electricity and steam                  | √                  | √     | Χ                | √                  | √                                            | √                   | √                              | √                             |
| Off-site generation of electricity                           | √                  | √     | Χ                | √                  | √                                            | √                   | √                              | √                             |
| Off-site generation of heat                                  | √                  | √     | √                | Χ                  | √                                            | √                   | √                              | √                             |
| Hot rolling                                                  | √                  | √     | √                | Χ                  | Χ                                            | Χ                   | √                              | Χ                             |
| Cold rolling and coating                                     | Χ                  | √     | Χ                | Χ                  | Χ                                            | Χ                   | √                              | Χ                             |
| Production of inputs for ferroalloys (e.g., stainless steel) | Χ                  | √     | Χ                | Χ                  | Χ                                            | Χ                   | Χ                              | √                             |

- * Note that not all elements included in the system boundary are compared.
- Only extraction and processing of iron ore, limestone supply and fossil fuel supply are included.
- √   Emissions included in system boundary
- Χ   Emissions not included in system boundary

<!-- image -->

For general information and technical queries contact us at: info@sciencebasedtargets.org

<!-- image -->

@ScienceTargets

/science-based-targets

<!-- image -->

<!-- image -->

Partner Organizations:

<!-- image -->

<!-- image -->

Science Based Targets

<!-- image -->

sciencebasedtargets.org/sectors/steel

In collaboration with:

<!-- image -->

<!-- image -->