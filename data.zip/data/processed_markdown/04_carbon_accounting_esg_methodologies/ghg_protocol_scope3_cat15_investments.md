---
document_id: ghg_scope3_ch15_investments
title: "Scope 3 Guidance - Category 15: Investments (Financed Emissions)"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat15_investments.pdf"
tables_detected: 33
converted_with: "Docling v2.32 (TableFormer)"
---

15

## Category 15: Investments

<!-- image -->

## Category description

T investments in the reporting  year,  not  already  included  in  scope  1  or  scope  2. his category includes scope 3 emissions associated with the reporting company's This category is applicable to investors (i.e., companies that make an investment with	the	objective	of	making	a	profit)	and	companies	that	provide	financial	services.	This category	also	applies	to	investors	that	are	not	profit	driven	(e.g.	multilateral	development banks), and the same calculation methods should be used. Investments are categorized as a	downstream	scope	3	category	because	providing	capital	or	financing	is	a	service	provided by the reporting company.

Category 15 is designed primarily for private financial institutions (e.g., commercial banks), but is also relevant to public financial institutions (e.g., multilateral development banks, export credit agencies) and other entities with investments not included in scope 1 and scope 2.

Investments may be included in a company's scope 1 or scope 2 inventory depending on how the company defines its organizational boundaries. For example, companies that use the equity-share approach include emissions from equity investments in scope 1 and scope 2. Companies that use a control approach account only for those equity investments that are under the company's control in scope 1 and scope 2. Investments not included in the company's scope 1 or scope 2 emissions are included in scope 3, in this category. A reporting company's scope 3 emissions from investments are the scope 1 and scope 2 emissions of investees.

For purposes of GHG accounting, this standard divides financial investments into four types:

- · Equity investments
- · Debt investments
- · Project finance
- · Managed investments and client services.

Tables 15.1 and 15.2 provide GHG accounting guidance for each type of financial investment. Table 15.1 provides the types of investments required to be accounted for in this category. Table 15.2 identifies types of investments that companies may optionally report.

Emissions from investments should be allocated to the reporting company based on the reporting company's proportional share of investment in the investee. Because investment portfolios are dynamic and can change frequently throughout the reporting year, companies should identify investments by choosing a fixed point in time, such as December 31 of the reporting year, or by using a representative average over the course of the reporting year.

## Table [15.1] Accounting for emissions from investments (required)

| Financial investment/ service   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | GHG accounting approach (required)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|---------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Equity investments              | Equity investments made by the reporting company using the company's own capital and balance sheet, including: • Equity investments in subsidiaries (or group companies) where the reporting company has financial control (typically more than 50 percent ownership) • Equity investments in associate companies (or affiliated companies), where the reporting com- pany has significant influence but not financial control (typically 20-50 percent ownership) • Equity investments in joint ventures (non-incor- porated joint ventures/partnerships/ operations), where partners have joint financial control | In general, companies in the financial services sector should account for emis- sions from equity investments in scope 1 and scope 2 by using the equity share consolidation approach to obtain represen- tative scope 1 and scope 2 inventories. If emissions from equity investments are not included in scope 1 or scope 2 (because the reporting company uses either the opera- tional control or financial control consoli- dation approach and does not have control over the investee), account for proportional scope 1 and scope 2 emissions of equity in- vestments* that occur in the reporting year in scope 3, category 15 (Investments). |
|                                 | Equity investments made by the reporting company using the company's own capital and balance sheet, where the reporting company has neither financial control nor significant influence over the emitting entity (and typically has less than 20 percent ownership).                                                                                                                                                                                                                                                                                                                                                | If not included in the reporting company's scope 1 and scope 2 inventories: Account for proportional scope 1 and scope 2 emissions of equity investments* that occur in the re- porting year in scope 3, category 15 (Invest- ments). Companies may establish a threshold (e.g., equity share of 1 percent) below which the company excludes equity investments from the inventory, if disclosed and justified.                                                                                                                                                                                                                                        |

## Table [15.1] Accounting for emissions from investments (required) (continued)

| Financial investment/ service                 | Description                                                                                                                                                                                                                                                                                                                                | GHG accounting approach (required)                                                                                                                                                                                                                                                                                                                                 |
|-----------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Debt investments (with known use of proceeds) | Corporate debt holdings held in the reporting company's portfolio, including corporate debt instruments (such as bonds or convertible bonds prior to conversion) or commercial loans, with known use of proceeds (i.e., where the use of proceeds is identified as going to a particular project, such as to build a specific power plant) | For each year during the term of the investment, companies should account for proportional scope 1 and scope 2 emissions of relevant projects* that occur in the reporting year in scope 3, category 15 (Investments). In addition, if the reporting company is an initial sponsor or lender of a project: Also ac- count for the total projected lifetime scope 1 |
| Project finance                               | Long-term financing of projects (e.g., infrastruc- ture and industrial projects) by the reporting company as either an equity investor (sponsor) or debt investor (financier)                                                                                                                                                              | and scope 2 emissions of relevant projects* fi- nanced during the reporting year and report those emissions separately from scope 3.                                                                                                                                                                                                                               |

Source: Table 5.9 from the Scope 3 Standard

## Notes:

In the case of insurance companies, insurance premiums should be regarded as the insurance company's own capital. Therefore equity investments made by insurance companies using insurance premiums are required to be reported (although companies may establish a threshold for equity investments). Accounting for emissions from insurance contracts is not required.

- *Additional guidance on key concepts italicized is provided below.
- · Proportional emissions from equity investments should be allocated to the investor based on the investor's proportional share of equity in the investee. Proportional emissions from project finance and debt investments with known use of proceeds should be allocated to the investor based on the investor's proportional share of total project costs (total equity plus debt). Companies may separately report additional metrics, such as total emissions of the investee, the investor's proportional share of capital investment in the investee, etc.
- · Scope 1 and scope 2 emissions include the direct (scope 1) emissions of the investee or project, as well as the indirect (scope 2) emissions from the generation of electricity consumed by the investee or project. If relevant, companies should also account for the scope 3 emissions of the investee or project. For example, if a financial institution provides equity or debt financing to a light bulb manufacturer, the financial institution is required to account for the proportional scope 1 and scope 2 emissions of the light bulb manufacturer (i.e., direct emissions during manufacturing and indirect emissions from electricity consumed during manufacturing). The financial institution should account for the scope 3 emissions of the light bulb producer (e.g., scope 3 emissions from consumer use of light bulbs sold by the manufacturer) when scope 3 emissions are significant compared to other source of emissions or otherwise relevant
- · Relevant projects include those in GHG-intensive sectors (e.g., power generation), projects exceeding a specified emissions threshold (defined by the company or industry sector), or projects that meet other criteria developed by the company or industry sector. Companies should account for emissions from the GHG-emitting project financed by the reporting company, regardless of any financial intermediaries involved in the transaction.
- · Total projected lifetime emissions are reported in the initial year the project is financed, not in subsequent years. If a project's anticipated lifetime is uncertain, companies may report a range of likely values (e.g., for a coal-fired power plant, a company may report a range over a 30- to 60-year time period). Companies should report the assumptions used to estimate total anticipated lifetime emissions. If project financing occurs only once every few years, emissions from project finance may fluctuate significantly from year to year. Companies should provide appropriate context in the public report (e.g., by highlighting exceptional or non-recurring project financing). See section 5.4 of the Scope 3 Standard for more information on the time boundary of scope 3 categories.

Table [15.2] Accounting for emissions from investments (optional)

| Financial investment/ service                    | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | GHG accounting approach (optional)                                                                                                               |
|--------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|
| Debt investments (without known use of proceeds) | General corporate purposes debt holdings (such as bonds or loans) held in the reporting company's portfolio where the use of proceeds is not specified                                                                                                                                                                                                                                                                                                                                                     | Companies may account for scope 1 and scope 2 emissions of the invest- ee that occur in the reporting year in scope 3, category 15 (Investments) |
| Managed investments and client services          | Investments managed by the reporting company on behalf of clients (using clients' capital a ) or services provided by the reporting company to clients, including: • Investment and asset management (equity or fixed income funds managed on behalf of clients, using clients' capital) • Corporate underwriting and issuance for clients seeking equity or debt capital • Financial advisory services for clients seeking assistance with mergers and acquisitions or requesting other advisory services | Companies may account for emissions from managed invest- ments and client services in scope 3, category 15 (Investments)                         |
| Other investments or financial services          | All other types of investments, financial contracts, or financial services not included above (e.g., pension funds, retirement accounts, securitized products, insurance con- tracts, credit guarantees, financial guarantees, export credit insurance, credit default swaps, etc.)                                                                                                                                                                                                                        | Companies may account for emissions from other investments in scope 3, category 15 (Investments)                                                 |

Source: Table 5.10 from the Scope 3 Standard

## Notes:

a.   Client's capital in this context refers to any capital that is not the reporting company's own capital, e.g., equity and fixed income fund managers investing the capital of the fund's investors.

This document provides detailed guidance only on the types of investments required to be reported in a scope 3 inventory (see table 15.1), it does not provide calculation guidance for many of the investment types that may be optionally reported. See table15.2. GHG Protocol may develop further guidance for calculating category 15 emissions. Check the GHG Protocol website for the latest guidance for accounting for GHG emissions associated with lending and investments: http://www.ghgprotocol.org/feature/financial-sector-guidance-corporate-value-chain-scope-3-accountingand-reporting.

Because financial services companies may have a large number of investments, investments should be screened to prioritize investments that are likely to contribute most significantly to total GHG emissions. It is recommended that a screening, using the average-data methods described below, be carried out as a first step to calculating emissions from investments. This screening should enable financial institutions to identify their investments with the highest emissions and focus on these for primary data collection.

## Calculating emissions from equity investments

It is a requirement of the Scope 3 Standard to report emissions from equity investments made by the reporting company using the company's own capital and balance sheet, including:

- · Equity investments in subsidiaries (or group companies), where the reporting company has financial control (typically more than 50 percent ownership)
- · Equity investments in associate companies (or affiliated companies), where the reporting company has significant influence but not financial control (typically 20-50 percent ownership)
- · Equity investments in joint ventures (non-incorporated joint ventures/partnerships/ operations), where partners have joint financial control
- · Equity investments where the reporting company has neither financial control nor significant influence over the emitting entity (and typically has less than 20 percent ownership). For these equity investments, companies may establish a threshold (e.g., equity share of 1 percent) below which the company excludes equity investments from the inventory, if disclosed and justified.

Companies should account for the proportional scope 1 and scope 2 emissions of the investments that occur in the reporting year. Proportional emissions from equity investments should be allocated to the investor based on the investor's proportional share of equity in the investee. Figure 15.1 shows a decision tree for selecting a calculation method for emissions from equity investments. Companies may use the following methods:

- · Investment-specific method , which involves collecting scope 1 and scope 2 emissions from the investee company and allocating the emissions based upon the share of investment; or
- · Average-data method , which involves using revenue data combined with EEIO data to estimate the scope 1 and scope 2 emissions from the investee company and allocating emissions based upon share of investment.

Companies should account for the proportional scope 1 and scope 2 emissions of the investments that occur in the reporting year. Companies should account for emissions from the GHG-emitting business activity, regardless of any financial intermediaries involved in the transaction. When scope 3 emissions are significant compared to other sources of emissions, investors should also account for the scope 3 emissions of the investee company. Calculating GHG emissions throughout the value chain of investee companies can help the investor understand and manage the climate change-related risks associated with his or her investments. If the majority of an investee company's emissions are associated with its value chain, then only focusing on scope 1 and scope 2 emissions will not provide the full picture of the company's risks. If the investor wants to understand the full GHG impact of the investee companies across their full value chain, for example, to identify hotspots for further engagement, including scope 3 may be more appropriate.

The GHG Protocol does not set a threshold above which scope 3 emissions should be included; instead, reporting companies should develop their own significance threshold based on their business goals. EEIO data can be used to quickly estimate the relative size of scope 3 emissions compared to scope 1 and scope 2 emissions for any sector.

## Box [15.1] Applicability of calculation methods to managed investments (e.g. mutual funds)

Whether an organization is required to report on equity investments depends on whose capital is being invested. Asset owners are investing their own capital, so they are required to report emissions from equity investments (although they may establish a threshold, as described in table 15.1).

Asset managers investing clients' capital may optionally report on emissions from equity investments managed on behalf of clients (e.g., mutual funds). Emissions from these types of equity investments can be calculated using the methods described in this section, however it should be noted that mutual funds and other funds managed on behalf of clients are not the primary audience for the calculation methods described here and some of their specific issues have not been addressed, including the business goals relevant to a fund manager and the appropriate use of inventory results.

## Figure [15.1] Decision tree for selecting a calculation method for emissions from equity investments

Does the equity investment contribute significantly to scope 3 emissions (based on screening) or is engagement  with the investee company otherwise relevant to the business goals?

Use investmentspecific approach

Can the investee company provide scope 1 and scope 2 data?

yes yes

no no

Use average-data method

## Investment-specific method

The investment-specific method involves collecting scope 1 and scope 2 emissions directly from investee companies and allocating these emissions based upon the proportion of the investment.

## Activity data needed

Companies should collect:

- · Scope 1 and scope 2 emissions of investee company
- · The investor's proportional share of equity in the investee
- · If significant, companies should also collect scope 3 emissions of the investee company (if investee companies are unable to provide scope 3 emissions data, scope 3 emissions may need to be estimated using the average-data method described in option 2).

## Emission factors needed

If using the investment-specific method, the reporting company collects emissions data from investees, thus no emission factors are required.

## Data collection guidance

Sources for data may include:

- · GHG inventory reports of investee companies
- · Financial records of the reporting company.

## Calculation formula [15.1] Investment-specific method for calculating emissions from equity investments

## Emissions from equity investments =

## sum across equity investments:

∑ (scope 1 and scope 2 emissions of equity investment × share of equity (%))

## Example [15.1] Calculating emissions from equity investments using the investment-specific method

ompany A, therefore, includes emissions associated with these four investments in its scope 3 inventory. Company A Company A has two subsidiaries and two joint ventures. Company A used the control approach to determine its boundaries, so it did not include these subsidiaries and joint ventures in its scope 1 and scope 2 emissions inventory. C collects scope 1 and scope 2 emissions associated with the investments from the GHG inventory reports of the investees, and obtains information on the share of the investments from its financial records.

| Investment                                                             | Investment type                                                        | Scope 1 and scope 2 emissions of investee company in reporting year (tonnes CO 2 e)   | Reporting company's share of equity (percent)                          |
|------------------------------------------------------------------------|------------------------------------------------------------------------|---------------------------------------------------------------------------------------|------------------------------------------------------------------------|
| 1                                                                      | Equity Investment in subsidiary                                        | 120,000                                                                               | 40                                                                     |
| 2                                                                      | Equity Investment in subsidiary                                        | 200,000                                                                               | 15                                                                     |
| 3                                                                      | Equity investment in joint venture                                     | 1,600,000                                                                             | 25                                                                     |
| 4                                                                      | Equity investment in joint venture                                     | 60,000                                                                                | 25                                                                     |
| Note: The data are illustrative only, and do not refer to actual data. | Note: The data are illustrative only, and do not refer to actual data. | Note: The data are illustrative only, and do not refer to actual data.                | Note: The data are illustrative only, and do not refer to actual data. |

## Example [15.1]   Calculating emissions from equity investments using the investment-specific method (continued)

## emissions from equity investments:

∑ (scope 1 and scope 2 emissions of equity investment × share of equity (%)) = (120,000 × 40%) + (200,000 × 15%) + (1,600,000 × 25%) + (60,000 × 25%) = 48,000 + 30,000 + 400,000 + 15,000 = 493,000 tonnes CO e

2

## Average-data method

The average-data method uses Environmentally-extended input-output (EEIO) data to estimate the scope 1 and scope 2 emissions associated with equity investments. The revenue of the investee company should be multiplied by the appropriate EEIO emission factor that is representative of the investee company's sector of the economy. For example, an apparel manufacturer should use an EEIO emission factor for apparel manufacturing. The reporting company should then use its proportional share of equity to allocate the estimated scope 1 and scope 2 emissions of the investee company.

Using EEIO data has limitations. EEIO databases contain average emission factors for each sector; therefore, when EEIO data is used to estimate emissions from investments, it is not possible to differentiate between investments within a particular sector. Using EEIO data can enable an investor to identify which sectors contribute most to its scope 3 investments category emissions, but investee-specific data would be required to identify the emissions hotspots within a particular sector. Another limitation is that the use of EEIO data will not enable the investor to track the GHG emissions of investee companies over time. See 'Environmentally-extended input output (EEIO) data,' in the Introduction for a broader discussion of the limitations of EEIO data.

## Activity data needed

The reporting company should collect;

- · Sector(s) the investee company operates in
- · Revenue of investee company (if the investee company operates in more than one sector, the reporting company should collect data on the revenue for each sector in which it operates)
- · The investor's proportional share of equity in the investee.

## Emission factors needed

The reporting company should collect:

- · EEIO emission factors for the sectors of the economy that the investments are related to (kg CO e/$ revenue). 2

The minimum boundary for reporting is the scope 1 and scope 2 emissions of the investee company. However, EEIO databases provide emission factors that include all upstream emissions. Therefore, if the investor is reporting only scope 1 and scope 2 emissions of the investee company, the EEIO emissions factor will need to be disaggregated to separate scope 1 and scope 2 emissions from all other upstream scope 3 emissions. Disaggregating the EEIO emission factor enables reporting companies to separate the scope 1 and scope 2 emissions from all other upstream scope 3 emissions, although sufficient information to do this may not be available. If disaggregation of the EEIO emission is not possible, reporting companies should use the full EEIO emission factor (i.e. include all upstream emissions). Reporting companies should clearly disclose the boundary used (either scope 1 and scope 2, or all upstream emissions).

When scope 3 emissions are significant compared with other sources of emissions, investors should also account for the scope 3 emissions of the investee company. Including upstream scope 3 emissions is simple when using EEIO databases because the EEIO emission factors include all upstream emissions.

Reporting companies should account for any significant changes in exchange rates and inflation rates over time. If possible, the EEIO data should be representative of the geographic region in which the investee company is located.

## Data collection guidance

Data may be collected from the following sources:

- · Revenue data and equity share data will be available from financial records of the reporting company and the investee company
- · Emission factors are available from EEIO databases (a list of databases is provided on the GHG Protocol website (http://www.ghgprotocol.org/Third-Party-Databases). Additional databases may be added periodically, so continue to check the website.

Calculation formula [15.2] Average-data method for calculating emissions from equity investments

## Emissions from equity investments =

## sum across equity investments:

- ∑ ((investee company total revenue ($) × emission factor for investee's sector (kg CO e/$ revenue)) 2 × share of equity (%))

## Example [15.2] Calculating emissions from equity investments using the average-data method

s investments by the sectors of the economy in which the investees are engaged. It collects EEIO emission factors for Company A is an investment bank. It has a broad portfolio of proprietary equity investments in dozens of companies across geographic regions. Company A is unable to collect the scope 1 and scope 2 emissions of its investments because most investees have not completed GHG inventories. Company A decides to use the economic data method by grouping it corresponding sectors by reference to EEIO databases. Company A obtains information on the share of the investments from its financial records and the financial reports of the investee companies.

The information is summarized as follows:

|   Investee company | Revenue of investee company ($)   |   Reporting company's share of equity (percent) | Investee company's sector(s) of operation   |   Investee company's revenue in sector (percent) |   Scope 1andscope 2emission factor of sector (kgCO 2 e/$revenue) |
|--------------------|-----------------------------------|-------------------------------------------------|---------------------------------------------|--------------------------------------------------|------------------------------------------------------------------|
|                  1 | 3,000,000                         |                                               5 | Telecommunication                           |                                              100 |                                                              0.6 |
|                  2 | 7,500,000                         |                                              15 | Pharmaceutical                              |                                              100 |                                                              0.5 |
|                  3 | 1,150,000                         |                                              20 | Energy generation                           |                                              100 |                                                              3   |
|                  4 | 5,500,000                         |                                              10 | Food and beverage Apparel                   |                                               60 |                                                              2   |

Note: The activity data and emissions factors are illustrative only and do not refer to actual data.

## Emissions from equity investments:

∑ ((investee company revenue ($) × emission factor for investee's sector (kg CO e/$)) × share of equity) 2

= (3,000,000 × 0.60) × 0.05

+ (7,500,000 × 0.5) × 0.15

+ (1,150,000 × 3) × 0.20

+ ((5,500,000 × 0.6 × 2) + (5,500,000 × 0.4 × 1.5)) × 0.10

= 90,000 + 562,500 + 690,000 + 900,000 = 2,242,500 tonnes CO e 2

## Calculating emissions from project finance and from debt investments with known use of proceeds

This section describes calculation methods used to calculate emissions from:

- · Project finance
- · Debt investments with known use of proceeds.

Project finance is defined in the Scope 3 Standard as long-term financing of projects (e.g., infrastructure and industrial projects) by the reporting company as either an equity investor (sponsor) or debt investor (financier). Corporate debt holdings with known use of proceeds are defined in the Scope 3 Standard as debt investments where the use of proceeds is identified as going to a particular project, such as to build a specific power plant.

For each year during the term of the investment, companies should account for proportional scope 1 and scope 2 emissions of relevant projects that occur in the reporting year. Proportional emissions from project finance and debt investments with known use of proceeds should be allocated to the investor based on the investor's proportional share of total project costs (total equity plus debt).

If scope 3 emissions of projects are significant compared to scope 1 and scope 2 emissions, investors should also account for proportional scope 3 emissions of projects that occur in the reporting year. This accounting could be particularly relevant for infrastructure projects like highways or bridges, where the scope 1 and scope 2 emissions during the operational phase of the projects are minimal compared with the scope 3 emissions from the use of the infrastructure (i.e., the emissions from the vehicles driving on the highway or bridge).

Figure 15.2 shows a decision tree for selecting a calculation method for emissions from project finance and debt investments with known use of proceeds. Companies may use the following methods:

- · Project-specific method , which involves collecting scope 1 and scope 2 emissions for the relevant project(s) and allocating these emissions based on the investor's proportional share of total project costs (total equity plus debt)
- · Average-data method , which involves using EEIO data to estimate the scope 1 and scope 2 emissions from the investee company and allocating emissions based on share of total project costs (total equity plus debt).

If the reporting company is an initial sponsor or lender of a project, it should also account for the total projected lifetime scope 1 and scope 2 emissions of relevant projects financed during the reporting year, and report those emissions separately from scope 3. The methods for calculating total projected lifetime emissions of projects are described in a subsequent section of this chapter Calculating total projected lifetime emissions from project finance and debt investments with known use of proceeds .

## Box [15.2] Calculating emissions from general corporate purposes debt investments

The Scope 3 Standard distinguishes debt investments with known use of proceeds from general corporate purposes debt holdings (see tables 15.1 and 15.2). General corporate purposes debt holdings (such as bonds or loans) where the use of proceeds is not specified can optionally be reported in a reporting company's scope 3 inventory.

Calculating emissions from debt investments where the use of proceeds is not specified should use the methods described for equity investments in section 15.1 ( Calculating emissions from equity investments ) except that the proportional share should be calculated based on the investor's proportional share of total equity plus debt . It should be noted that the calculation methodologies described in this guidance apply to long-term debt. Short-term debt (such as revolving credit facilities) would pose additional accounting challenges that are not addressed in this guidance.

## Figure [15.2]   Decision tree for selecting a calculation method for emissions from project finance and debt investments with known use of proceeds

<!-- image -->

## Project-specific method

The project-specific method involves collecting scope 1 and scope 2 emissions directly from the investee company for the relevant project(s) and allocating these emissions based on the investor's proportional share of total project costs (total equity plus debt).

## Activity data needed

Companies should collect:

- · Scope 1 and scope 2 emissions that occur in the reporting year for the relevant projects
- · The investor's proportional share of total project costs (total equity plus debt).

## Emission factors needed

If using the project-specific method, the reporting company collects emissions data from investees, so no emission factors are required.

## Data collection guidance

Sources for data may include:

- · GHG inventory reports of investee companies
- · Financial records of the reporting company
- · A number countries and regions now have mandatory GHG reporting requirements for facilities over a certain size. These databases are usually available to the public.

Calculation formula [15.3]   Project-specific method for calculating emissions from project finance and debt investments with known use of proceeds

## CO 2 e emissions from projects =

## sum across projects:

∑ (scope 1 and scope 2 emissions of relevant project in the reporting year × share of total project costs (%))

## Example [15.3]   Calculating emissions from project finance and debt investments with known use of proceeds using the project-specific method

ompanies on the projects for which the investment bank provided debt capital. Company A is an investment bank. It makes debt investments in a number of utility and infrastructure companies for specific projects (such as building a new power plant). Company A collects scope 1 and scope 2 emissions data from the c

The information is summarized as follows:

|   Investee company | Scope 1 and scope 2 emissions of project in reporting year (tonnes CO 2 e)   | Value of debt invest- ment ($)   | Total project costs (total equi- ty plus debt) ($)   |   Share of total project costs (percent) |
|--------------------|------------------------------------------------------------------------------|----------------------------------|------------------------------------------------------|------------------------------------------|
|                  1 | 200,000                                                                      | 1,000,000                        | 20,000,000                                           |                                     5    |
|                  2 | 10,000                                                                       | 5,000,000                        | 50,000,000                                           |                                    10    |
|                  3 | 250,000                                                                      | 3,000,000                        | 60,000,000                                           |                                     5    |
|                  4 | 30,000                                                                       | 10,000,000                       | 90,000,000                                           |                                    11.11 |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

emissions from debt investments with known use of proceeds = (200,000 × 0.05) + (10,000 × 0.1) + (250,000 × 0.05) + (30,000 × 0.1111) = 10,000 + 1,000 + 12,500 + 3,333 = 26,833 tonnes CO e

2

## Average-data method

The average-data method uses environmentally-extended input output (EEIO) data to estimate the scope 1 and scope 2 emissions from projects. The project cost should be multiplied by appropriate emission factors that are representative of the sectors of the economy to which the project relates. For example, for a manufacturing facility construction project, an EEIO emission factor for 'Construction of nonresidential manufacturing structures' should be used. The reporting company should then use its proportional share of total project costs (total equity plus debt) to allocate the project's emissions.

Using EEIO data has limitations (see ' Environmentally-extended input output (EEIO) data ,' in the Introduction for more information), so this option should only be used as a last resort if project-specific data is not available. Companies should clearly report on the methodology and assumptions used to calculate their emissions within this category.

## Activity data needed

The reporting company should collect:

- · Project costs in the reporting year (if the project is in the construction phase); or
- · Revenue of the project (if the project is in the operational phase); and
- · The investor's proportional share of total project costs (total equity plus debt).

## Emission factors needed

The reporting company should collect one of the following:

- · EEIO emission factors for the relevant construction sector that the investments are related to (kg CO e/$) (if the 2 project is in the construction phase)
- · EEIO emission factors for the relevant operating sector that the investments are related to (kg CO e/$) (if the project 2 is in the operational phase).

Reporting companies should ensure that EEIO data is up-to-date and account for any significant changes in exchange rates and inflation rates over time. If possible, the EEIO data should be representative of the e geographic region where the project is located.

If a project (e.g., certain infrastructure projects) does not generate revenue during its operational phase then EEIO data cannot be used to estimate emissions. In these cases, other data or assumptions, such as industry or government studies of similar projects, can be used to estimate emissions from the operational phase.

## Data collection guidance

Data may be collected from the following sources:

- · Project cost and investment share data will be available from financial records of the reporting company and the investee company
- · Emission factors from EEIO databases (a list of databases is provided on the GHG Protocol website ttp://www. h ghgprotocol.org/Third-Party-Databases). Additional databases may be added periodically, so continue to check the website.

## Calculation formula [15.4]   Average-data method for calculating emissions from project finance and debt investments with known use of proceeds

## Emissions from project finance and debt investments with known use proceeds =

## sum across projects in the construction phase:

∑ ((project construction cost in the reporting year ($) x emission factor of relevant construction sector (kg CO e/$ revenue)) 2 x share of total project costs (%))

## sum across projects in the operational phase:

∑ ((project revenue in the reporting year ($) x emission factor of relevant operating sector (kg CO e/$ revenue)) 2 x share of total project costs (%))

## Example [15.4]   Calculating emissions from project finance and debt investments with known use of proceeds using the average data method

esource constraints, it decided not to engage with the investee companies, but instead wants to use secondary data to stimate emissions. Company A states that it will consider engagement with investee companies in future years. Company A is an investment bank. It makes debt investments in a number of companies for specific projects (such as building a new power plant). This is the first year Company A has carried out a scope 3 inventory and due to time and r e

Company A collects data from its internal data management system. The information is summarized as follows:

| Type of project                | Project phase   |   Project con- struction cost or project revenue in reporting year ($ million) | Relevant EEIO sector                                                    | EEIO emission factor (scope 1 and scope 2 emissions only) (tonnes CO 2 e / $ millions)   |   Share of total project costs (value of debt investment / total equity plus debt) (percent) |
|--------------------------------|-----------------|--------------------------------------------------------------------------------|-------------------------------------------------------------------------|------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|
| Bridge                         | Construc- tion  |                                                                             20 | Other non-residential structures                                        | 310                                                                                      |                                                                                            7 |
| Hospital                       | Construc- tion  |                                                                              8 | Construction of non-residential com- mercial and health care structures | 325                                                                                      |                                                                                           10 |
| Paper man- ufacturing facility | Operation       |                                                                              3 | Paper mills                                                             | 500                                                                                      |                                                                                            5 |
| Coal-fired power plant         | Operation       |                                                                             15 | Power generation and supply                                             | 9,000                                                                                    |                                                                                            5 |

## Example [15.4]   Calculating emissions from project finance and debt investments with known use of proceeds using the average data method (continued)

## emissions from debt investments with known use of proceeds

= ∑ ((project construction costs in the reporting year or project revenue in reporting year ($) × emission factor of sector (kg CO e/$)) x share of total project costs) 2

= ((20 x 310) x 0.07) + ((8 x 325) x 0.10) + ((3 x 500) x 0.05) + ((15 x 9,000) x 0.05) = 434 + 260 + 75 + 6,750 = 7,519 tonnes CO e

2

## Calculating total projected lifetime emissions from project finance and debt investments with known use of proceeds

If the reporting company is an initial sponsor or lender of a project, it should also account for the total projected lifetime scope 1 and scope 2 emissions of relevant projects financed during the reporting year, and report those emissions separately from scope 3. Accounting for the projected lifetime emissions reflects the longer term nature of these forms of investment. Accounting for total projected lifetime emissions is in addition to (and separate from) accounting for annual scope 1 and scope 2 emissions of projects for each year during the term of the investment (as described in the previous section Calculating emissions from project finance and from debt investments with known use of proceeds).

Total projected lifetime emissions are reported in the initial year the project is financed, not in subsequent years, and emissions should not be amortized or discounted. As it is required for companies to account for proportional scope 1 and scope 2 emissions of projects for each year during the term of the investment, reporting amortized projected lifetime emissions each year during the term of the investment in addition to annual scope 1 and scope 2 emissions would result in double counting. Once the project has been constructed and is operational, the lifetime emissions have been locked in, so it is in the initial stage of a project where total lifetime emissions should be taken into consideration. Companies should report the assumptions used to estimate total anticipated lifetime scope 1 and scope 2 emissions.

When scope 3 emissions of projects are significant compared to scope 1 and scope 2 emissions, investors should also account for total projected lifetime scope 3 emissions of projects. This could be particularly relevant for infrastructure projects like highways or bridges, where the scope 1 and scope 2 emissions of the projects during the operational phase are minimal compared to the scope 3 emissions from the use of the infrastructure (i.e., the emissions from the vehicles driving on the highway or bridge).

Any claims of avoided emissions related to a project must be reported separately from the company's scope 1, scope 2, and scope 3 inventories. (For more information, see section 9.5 of the Scope 3 Standard ).

Calculating projected lifetime emissions typically requires making assumptions about the operation of the asset and its expected lifetime. The data needed to calculate expected emissions will depend on the type of project.

## Companies should collect:

- · Expected average annual emissions of project. For power plants for example, emissions can be derived from the plant's capacity and heat rate, the carbon content of the fuel, and projected capacity utilization
- · Expected lifetime of project.

If there is uncertainty around a project's anticipated lifetime, companies may report a range of likely values (e.g., for a coal-fired power plant, a company may report a range of 30- to 60-years).

## Calculation formula [15.4]   Method for calculating projected total lifetime emissions from project finance and debt investments with known use of proceeds

## Projected total lifetime emissions from project finance and debt investments with known use proceeds =

- ∑ ((projected annual emissions of project x projected lifetime of project) x share of total project costs)

Note that project total lifetime emissions are only required to be reported in the initial year the project is financed, so the share of total project costs (total equity plus debt) refers only to initial sponsors/lenders.

## Example [15.5]   Calculating projected total lifetime emissions from project finance and debt investments with known use of proceeds

Company A is an investment bank. In the reporting year, the bank project financed the construction of one power plant as an initial lender.

The information is summarized as follows:

| Expected annual emissions (tonnes)   | Expected lifetime of project (years)   |   Proportional share of total project costs (total equity plus debt) (percent) |
|--------------------------------------|----------------------------------------|--------------------------------------------------------------------------------|
| 7,000,000                            | 30-60                                  |                                                                             15 |

Note: The data are illustrative only, and do not refer to actual data

Projected lifetime emissions of projects financed in the reporting year

- = (projected annual emissions of project x projected lifetime of project) x share of total project costs

30 year lifetime:

(7,000,000 x 30) x 0.15 = 31,500,000 tonnes CO e 2

60 year lifetime: (7,000,000 x 60) x 0.15 = 63,000,000 tonnes CO e 2