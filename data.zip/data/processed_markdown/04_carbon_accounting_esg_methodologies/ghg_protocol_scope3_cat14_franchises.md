---
document_id: ghg_scope3_ch14_franchises
title: "Scope 3 Guidance - Category 14: Franchises"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat14_franchises.pdf"
tables_detected: 7
converted_with: "Docling v2.32 (TableFormer)"
---

14

## Category 14: Franchises

## Category description

<!-- image -->

C 1 or scope 2. A franchise is a business operating under a license to sell or distribute ategory 14 includes emissions from the operation of franchises not included in scope another  company's  goods  or  services  within  a  certain  location.  This  category  is applicable to franchisors (i.e., companies that grant licenses to other entities to sell or distribute its goods or services in return for payments, such as royalties for the use of trademarks and other services).  Franchisors  should  account  for  emissions  that  occur  from  the  operation  of franchises (i.e., the scope 1 and scope 2 emissions of franchisees) in this category.

Franchisees (i.e., companies that operate franchises and pay fees to a franchisor) should include emissions from operations under their control in this category if they have not included those emissions in scope 1 and scope 2 due to their choice of consolidation approach. Franchisees may optionally report upstream scope 3 emissions associated with the franchisor's operations (i.e., the scope 1 and scope 2 emissions of the franchisor) in category 1 (Purchased goods and services).

## Calculating emissions from franchises

Companies may use either of two methods to calculate emissions from franchises:

- · Franchise-specific method , which involves collecting site-specific activity data or scope 1 and scope 2 emissions data from franchisees
- · Average-data method , which involves estimating emissions for each franchise, or groups of franchises, based on average statistics, such as average emissions per franchise type or floor space.

## Franchise-specific method

The franchise-specific method involves collecting scope 1 and scope 2 emissions from franchisees. If franchisees have conducted corporate scope 1 and scope 2 GHG inventory report(s), the data can be applied immediately. If such reports are not available, site-specific fuel and energy data from individual franchises should be collected. The reporting company should determine whether the franchisee delivers business solely for the reporting company (i.e., franchisor), and if not, the franchisee or the reporting company should allocate the emissions accordingly. Guidance on allocation is provided in chapter 8 of the Scope 3 Standard .

If significant upstream emissions result from the purchase of goods and services by franchisees, the franchisor developing the scope 3 inventory should include these emissions in this category. For example, a large fast-food franchise should account for the upstream emissions associated with the beef purchased by its franchise restaurants.

## Activity data needed

Companies should collect data on either:

- · Scope 1, scope 2, and (optionally) scope 3 emissions data from franchisees
- · Site-specific fuel use, electricity use, and process and fugitive emissions activity data if applicable.

## Emission factors needed

If collecting fuel and energy data, companies should also collect:

- · Site- or regionally-specific emission factors for energy sources (e.g., electricity and fuels) per unit of consumption (e.g., kg CO e/kWh for electricity, kg CO e/liter for diesel) 2 2
- · Emission factors of process emissions and fugitive emissions (e.g., refrigeration and air conditioning)
- · Upstream emission factors.

## Data collection guidance

- · Data sources for activity data include:
- · Public GHG inventory reports accessible through GHG reporting programs
- · Utility bills
- · Purchase records
- · Meter readings
- · Internal IT systems.

Data sources for emission factors include:

- · The GHG Protocol websites (http://www.ghgprotocol.org/calculation-tools/all-tools and http://www.ghgprotocol. org/standards/scope-3-standard)
- · Company-specific emission factors
- · Industry associations
- · Government agencies (e.g., Defra provides emission factors for the United Kingdom)
- · For activity data, emission factors, and formulas for process and fugitive emissions, see the GHG Protocol website (http://www.ghgprotocol.org/calculation-tools/all-tools) and the IPCC 2006 Guidelines (http://www.ipcc-nggip.iges. or.jp/public/2006gl/index.html).

## Calculation formula [14.1] Franchise-specific method

## CO 2 e emissions from franchises =

## sum across franchises:

∑ (scope 1 emissions + scope 2 emissions of each franchise (kg CO e)) 2

To calculate scope 3 emissions from franchises, aggregate the scope 1 and scope 2 emissions of all franchises, using the formula above.

Franchises that operate in a portion of a building where energy use is not separately sub-metered may estimate energy consumed using the franchise's share of the building's total floor space and total building energy use, following this formula:

## Calculation formula [14.2] Allocating emissions from franchise buildings that are not sub-metered

## CO 2 e emissions allocated to franchise =

energy use from franchise (kWh)

franchise's area (m 2 )

= building's total area (m 2 ) × building's occupancy rate (e.g., 0.75) ×  building's total energy use (kWh)

## Using Samples

If a company has a large number of individual franchises, it may not be practical to collect data from each franchise. Therefore, companies may use appropriate sampling techniques when collecting data to represent all franchises from a representative sample of franchises. See Appendix A for more information on sampling.

Companies may also choose to categorize franchises into similar groups for data collection. The grouping strategy should group franchises with similar anticipated emissions intensities. Below is a non-exclusive list of possible ways to group franchises:

- · Location, (e.g., country - particularly if electricity emission factors differ significantly among countries)
- · Building type (e.g., free-standing buildings; leased shop space in shopping centres; shop-front at base of a larger city building)
- · Floor space
- · Financial turnover
- · Product volume
- · Customer numbers
- · Distinctive characteristics (e.g., gyms with saunas, hotels with pools).

## Calculation formula [14.3] Extrapolating emissions from sample groups

## CO 2 e emissions from franchises =

## Step 1: aggregation of franchise emissions per group:

total emissions from sampled franchises within group × total number of franchises within group number of franchises sampled within group

## Step 2: aggregation of total franchise emissions across all groups:

∑ total scope 1 and scope 2 emissions from each asset group

Companies that extrapolate from a representative sample within a franchise group should use the formula 14.2 to calculate emissions from sampled franchises within a group, then apply the formula in Step 1 above to estimate emissions for a franchise group. Companies should then use the formula in Step 2 above to aggregate franchise groups to the company's total emissions from franchises.

## Example [14.1] Calculating the emissions from franchises using the franchise-specific method

Company A has multiple franchisees that operate restaurants. Company A requests the total scope 1 and scope 2 emissions of each of the franchisees:

|   Franchisee | Scope 1 emissions (kg CO 2 e)   | Scope 2 emissions (kg CO 2 e)   |
|--------------|---------------------------------|---------------------------------|
|            1 | 100,000                         | 20,000                          |
|            2 | 25,000                          | 10,000                          |
|            3 | 30,000                          | 10,000                          |
|            4 | 90,000                          | 30,000                          |
|            5 | 30,000                          | 10,000                          |

Note: emissions are for illustrative purposes only, and do not refer to actual data.

## company A can then perform the following calculation:

∑ total scope 1 and scope 2 emissions from franchisees (kg CO e) 2 = (100,000 + 20,000) + (25,000 + 10,000) + (30,000 + 10,000) + (90,000 + 30,000) + (30,000 + 10,000) = 355,000 kg CO e

2

## Average-data method

The average-data approach involves estimating emissions for each franchise, or groups of franchises, based on average statistics, such as average emissions per building type, floor space, or franchise type. This approach should be used when purchase records, electricity bills, or meter readings of fuel or energy use are not available or applicable. Approaches include:

- · Estimated emissions based on occupied floor space by building type
- · Estimated emissions based on number and type of franchises.

Note that the average-data approach may be relatively inaccurate and limits the ability of companies to track performance of GHG reduction actions.

## Activity data needed

Depending on the type of asset that is leased, companies may need to collect data on:

- · Floor space of each franchise, by floor space
- · Number of franchises, by building type
- · Number of franchise assets that give rise to GHG emissions (e.g., company cars, trucks).

## Emission factors needed

Depending on the type of asset that is leased companies may need to collect:

- · Average emission factors by floor space, expressed in units of emissions per area per time period (e.g., kg CO e/m 2 /day) 2
- · Average emission factors by building type, expressed in units of emissions per building per time period (e.g., kg CO e/small office block/year) 2
- · Emission factors by asset type, expressed in units of emissions per asset type per time period (e.g., kg COe/car/year). 2

## Data collection guidance

Data sources for emission factors include:

- · Industry bodies (e.g., building industry)
- · National statistics published by government agencies
- · The U.S. Energy Information Administration dataset on average energy use by building type, Commercial Buildings Energy Consumption Survey, at: http://www.eia.doe.gov/emeu/cbecs.

Calculation formula [14.4] Average data method for leased buildings (if floor space data is available)

## CO 2 e emissions from franchises =

## sum across building types:

- ∑ (total floor space of building type (m 2 ) × average emission factor for building type (kg CO e/m 2 /year)) 2

Calculation formula [14.5]   Average data method for other asset types or for leased buildings where floor space data is not available

## CO 2 e emissions from franchises =

## sum across building/asset types:

∑ (number of buildings or assets

× average emissions per building or asset type per year (kg CO e/building or asset type/year)) 2

## Example 14.2: Calculating the emissions from franchises using the average data method

Company A has multiple franchisees that operate a combination of food outlets and clothing outlets. To calculate emissions from franchises, Company A collects the following data:

|   Franchisee | Type            |   Shop area (m 2 ) | Emission factor (kg CO 2 e/m 2 /year)   |
|--------------|-----------------|--------------------|-----------------------------------------|
|            1 | Food outlet     |                100 | 30,000                                  |
|            2 | Food outlet     |                150 | 30,000                                  |
|            3 | Clothing outlet |                400 | 10,000                                  |
|            4 | Clothing outlet |                700 | 10,000                                  |
|            5 | Clothing outlet |                500 | 10,000                                  |

Note that all emissions factors are used for illustrative purposes only

## Company A can then perform the following calculation:

emissions from franchises

= ∑ (building or type × average emissions per building or asset type (kg CO e/building or asset type)) 2 = (100 × 30,000) + (150 × 30,000) + (400 × 10,000) + (700 × 10,000) + (500 × 10,000) = 23,500,000 kg CO e

2