---
document_id: ghg_scope3_ch08_upstream_leased_assets
title: "Scope 3 Guidance - Category 8: Upstream Leased Assets"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat08_upstream_leased_assets.pdf"
tables_detected: 7
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Category descrip tion

C reporting company in the reporting year and not already included in the reporting ategory 8 includes emissions from the operation of assets that are leased by the company's scope 1 or scope 2 inventories. This category is applicable only to companies that operate leased assets (i.e., lessees). For companies that own and lease assets to others (i.e., lessors), see category 13 (Downstream leased assets).

Leased assets may be included in a company's scope 1 or scope 2 inventory depending on the type of lease and the consolidation approach the company uses to define its organizational boundaries (see section 5.2 of the Scope 3 Standard ).

If the reporting company leases an asset for only part of the reporting year, it should account for emissions for the portion of the year that the asset was leased. A reporting company's scope 3 emissions from upstream leased assets include the scope 1 and scope 2 emissions of lessors (depending on the lessor's consolidation approach).

See Appendix A of the Scope 3 Standard for more information on accounting for emissions from leased assets.

## Calculating emissions from leased assets

Figure 8.1 shows a decision tree for selecting a calculation method for emissions from upstream leased assets. Companies may use one of the following methods:

- · Asset-specific method , which involves collecting asset-specific (e.g., site-specific) fuel and energy use data and process and fugitive emissions data or scope 1 and scope 2 emissions data from individual leased assets
- · Lessor-specific method , which involves collecting the scope 1 and scope 2 emissions from lessor(s) and allocating emissions to the relevant leased asset(s)

- · Average data method , which involves estimating emissions for each leased asset, or groups of leased assets, based on average data, such as average emissions per asset type or floor space.

Companies may also calculate the life cycle emissions associated with manufacturing or constructing leased assets.

## Figure [8.1] Decision tree for selecting a calculation method for emissions from upstream leased assets

<!-- image -->

## Asset-specific method

This method involves collecting asset-specific (e.g., site-specific) fuel and energy and/or scope 1 and scope 2 emissions data from individual leased assets.

## Activity data needed

Companies should collect scope 1 and scope 2 emissions data, or activity data on:

- · Asset-specific fuel use and electricity, steam, heating and cooling use
- · If applicable, activity data related to non-combustion emissions (i.e., industrial process or fugitive emissions).

## Emission factors needed

Companies should collect:

- · Site or regionally specific emission factors for energy sources (e.g., electricity and fuels) per unit of consumption (e.g., kg CO e/kWh for electricity, kg CO e/liter for diesel) 2 2
- · Emission factors of fugitive and process emissions.

To optionally calculate emissions associated with manufacturing or construction of leased assets, companies should use life cycle emission factors that include manufacturing and construction.

## Data collection guidance

Data sources for activity data may include:

- · Utility bills
- · Purchase records
- · Meter readings
- · Internal IT systems.

Data sources for emission factors include:

- · Life cycle databases. A list of life cycle databases is provided on the GHG Protocol website (http://www.ghgprotocol. org/Third-Party-Databases). Additional databases may be added periodically, so continue to check the website.
- · Company-developed emission factors
- · Government agencies (e.g., Defra provides emission factors for the UK)
- · Industry associations
- · For activity data, emission factors, and formulas for process and fugitive emissions, see the GHG Protocol website (http://www.ghgprotocol.org/calculation-tools/all-tools ) and the IPCC 2006 Guidelines (http://www.ipcc-nggip.iges. or.jp/public/2006gl/index.html).

To calculate scope 3 emissions from leased assets, aggregate the scope 1 and scope 2 emissions across all of the reporting company's leased assets, using this formula:

## Calculation formula [8.1] Asset-specific method

## CO 2 e emissions from upstream leased assets =

## calculate the scope 1 and scope 2 emissions associated with each leased asset:

scope 1 emissions of leased asset

= ∑ (quantity of fuel consumed (e.g., liter) × emission factor for fuel source (e.g., kg CO e/liter)) 2 + ∑ ((quantity of refrigerant leakage (kg) × emission factor for refrigerant (kg CO e/kg)) 2 + process emissions)

scope 2 emissions of leased asset

= ∑ (quantity of electricity, steam, heating, cooling consumed (e.g., kWh)

× emission factor for electricity, steam, heating, cooling (e.g., kg CO e/kWh)) 2

## then sum across leased assets:

∑ scope 1 and scope 2 emissions of each leased asset

Companies that lease a portion of a building (e.g., an office building) where energy use is not separately sub-metered by the tenant may estimate energy consumed using the reporting company's share of the building's total floor space and total building energy use, following this formula:

## Calculation formula [8.2] Allocating emissions from leased buildings that are not sub-metered

## energy use from leased space (kWh) =

(reporting company's area (m 2 )) / (building's total area (m 2 ) × building's occupancy rate (e.g., 0.75)) × building's total energy use (kWh)

## Example [8.1] Calculating emissions from upstream leased assets using the asset-specific method

uilding's total area of 2,000 m 2 Company B leases an entire floor of office space from Company D for one year. Company B is able to collect data on the fuel, electricity, and fugitive emissions of the entire building for the reporting year. Company B leases 200 m 2  of the b . The occupancy rate of the building is 75%.

Data is summarized in the table below:

|          | Natural gas (kWh)   |   Natural gas emission factor (kg CO 2 e/kWh) | Electricity (kWh)   |   Electricity emission factor (kg CO 2 e/kWh) |   Fugitive emissions | Fugitive emission factor   |
|----------|---------------------|-----------------------------------------------|---------------------|-----------------------------------------------|----------------------|----------------------------|
| Building | 1,500               |                                           0.2 | 3,000               |                                           0.7 |                    5 | 1,500                      |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

## Example [8.1] Calculating emissions from upstream leased assets using the asset-specific method (continued)

## Total natural gas allocation to company B:

```
(reporting company's area (m 2 ) building's total area (m 2 ) × building's occupancy rate (e.g., 0.75) × building's total natural gas use = 200 / (2000 × 0.75) × 1500 = 200 kWh
```

## total electricity allocation to company B:

reporting company's area (m 2 )

building's total area (m 2 )  × building's occupancy rate (e.g., 0.75)

× building's total electricity use

<!-- formula-not-decoded -->

= 400 kWh

## total fugitives allocation to company B:

reporting company's area (m 2 )

building's total area (m 2 ) building's occupancy rate (e.g., 0.75)

× building's total fugitive emissions

<!-- formula-not-decoded -->

## total emissions of leased asset:

<!-- formula-not-decoded -->

## Lessor-specific method

The lessor-specific method involves collecting the scope 1 and scope 2 emissions from lessor(s) and allocating emissions to the relevant leased asset(s). This method is relevant in cases where, for example, office space is leased in a building that is not sub-metered. If the lessor company has data available at the building- or company-level, allocation techniques can be used to apportion emissions to the office space leased by the reporting company.

## Activity data needed

Companies should collect lessors' total scope 1 and scope 2 emissions data, or activity data on:

- · Lessor's total fuel use and electricity use
- · Lessor's fugitive emissions (e.g., from refrigerants)
- · Lessor's process emissions (if applicable).

## Emission factors needed

- · Site or regionally specific emission factors for energy sources (e.g., electricity and fuels) per unit of consumption (e.g., kg CO e/kWh for electricity, kg CO e/liter for diesel) 2 2
- · Emission factors of fugitive and process emissions.

To allocate emissions, companies should collect data on:

- · Total area/volume/quantity of lessors' assets
- · Total area/volume/quantity of the reporting company's leased assets.

For guidance on allocating emissions, refer to chapter 8 of the Scope 3 Standard.

## Calculation formula [8.3] Lessor-specific method

## CO 2 e emissions from leased assets =

## calculate the scope 1 and scope 2 emissions associated with each lessor:

scope 1 emissions of lessor

= ∑ (quantity of fuel consumed (e.g., liter) × emission factor for fuel source (e.g., kg CO e/liter))

2 + ∑ (quantity of refrigerant leakage (kg) × emission factor for refrigerant (kg CO e/kg)) 2 + process emissions scope 2 emissions of lessor

= ∑ (quantity of electricity, steam, heating, cooling consumed (e.g., kWh) × emission factor for electricity, steam, heating, cooling (e.g., kg CO e/kWh))

2

## then allocate emissions from each lessor and then sum across lessors:

```
∑ (scope 1 and scope 2 emissions of lessor (kg CO e) 2 × ( area, volume, quantity, etc., of the leased asset total area, volume, quantity, etc., of lessor assets )
```

## Average-data method

The average-data method involves estimating emissions for each leased asset, or groups of leased assets, based on average statistics and secondary data, such as average emissions per asset type or floor space. The average-data method should be used when purchase records, electricity bills, or meter readings of fuel or energy use are not available or applicable. Approaches include:

- · Estimated emissions based on occupied floor space by asset/building type (for leased buildings)
- · Estimated emissions based on number and type of leased assets.

Note that the average-data method is less accurate than the lessor-specific method and limits the ability of companies to track their performance of GHG reduction actions.

## Activity data needed

Companies should collect data on:

- · Floor space of each leased building
- · Number of leased buildings, by building type (e.g., office, retail, warehouse, factory, etc.)
- · Number and type of leased assets other than buildings that give rise to scope 1 or scope 2 emissions (e.g., company cars, trucks).

## Emission factors needed

Companies should collect:

- · Average emission factors by floor space, expressed in units of emissions per square meter, square foot occupied (e.g., kg CO e/m 2 /year) 2
- · Average emission factors by building type, expressed in units of emissions per building (e.g., kg CO e/small office 2 block/year)
- · Emission factors by asset type, expressed in units of emissions per asset (e.g., kg CO e/car/year). 2

## Data collection guidance

The U.S. Energy Information Administration has developed a dataset on average energy use by building type. Commercial Buildings Energy Consumption Survey, at: http://www.eia.doe.gov/emeu/cbecs

Calculation formula [8.4] Average-data method for leased buildings (where floor space data is available)

## CO 2 e emissions from leased assets =

## sum across building types:

∑ (total floor space of building type (m 2 ) × average emission factor for building type (kg CO e/m 2 /year)) 2

Calculation formula [8.5]   Average-data method for leased assets other than buildings and for leased buildings where floor space data is unavailable

## CO 2 e emissions from leased assets =

## sum across asset types:

∑ (number of assets x average emissions per asset type (kg CO e/asset type/year)) 2