---
document_id: ghg_scope3_ch03_fuel_energy
title: "Scope 3 Guidance - Category 3: Fuel- and Energy-Related Activities Not Included in Scope 1 or 2"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat03_fuel_energy_activities.pdf"
tables_detected: 15
converted_with: "Docling v2.32 (TableFormer)"
---

3

## Category 3:

<!-- image -->

## Fuel- and Energy-Related Activities Not Included in Scope 1 or Scope 2

## Category description

his  category  includes  emissions  related  to  the  production  of  fuels  and  energy purchased and consumed by the reporting company in the reporting year that are not included in scope 1 or scope 2.

T

Category 3 excludes emissions from the combustion of fuels or electricity consumed by the reporting company because they are already included in scope 1 or scope 2. Scope 1 includes emissions from the combustion of fuels by sources owned or controlled by the reporting company. Scope 2 includes the emissions from the combustion of fuels to generate electricity, steam, heating, and cooling purchased and consumed by the reporting company.

This category includes emissions from four activities (see table 3.1).

Table [3.1]   Activities included in category 3 (Fuel- and energy-related emissions not included in scope 1 or scope 2)

| Activity                                                         | Description                                                                                                                                                                                                                                                                                                                                                                                   | Applicability                                                       |
|------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------|
| A. Upstream emissions of purchased fuels                         | Extraction, production, and transportation of fuels consumed by the reporting company Examples include mining of coal, refining of gasoline, transmission and distribution of natural gas, production of biofuels, etc.                                                                                                                                                                       | Applicable to end users of fuels                                    |
| B. Upstream emissions of purchased electricity                   | Extraction, production, and transportation of fuels consumed in the gen- eration of electricity, steam, heating, and cooling that is consumed by the reporting company Examples include mining of coal, refining of fuels, extraction of natural gas, etc.                                                                                                                                    | Applicable to end users of electricity, steam, heating, and cooling |
| C. Transmission and distribution (T&D) losses                    | Generation (upstream activities and combustion) of electricity, steam, heating, and cooling that is consumed (i.e., lost) in a T&D system - report- ed by end user                                                                                                                                                                                                                            | Applicable to end users of electricity, steam, heating, and cooling |
| D. Generation of purchased electricity that is sold to end users | Generation (upstream activities and combustion) of electricity, steam, heating, and cooling that is purchased by the reporting company and sold to end users - reported by utility company or energy retailer Note: This activity is particularly relevant for utility companies that pur- chase wholesale electricity supplied by independent power producers for resale to their customers. | Applicable to utility companies and en- ergy retailers*             |

Source: Table 5.5 from the Scope 3 Standard.

Note: * Energy retailers include any company selling excess power to the grid.

Table 3.2 explains how each company accounts for GHG emissions. In this example, the emission factor of the electricity sold by Company B is 1 tonne (t) CO e/MWh. All numbers are illustrative only. 2

Table [3.2] Accounting for emissions across an electricity value chain

| Reporting company                                  | Scope 1                                         | Scope 2                                                                            | Scope 3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|----------------------------------------------------|-------------------------------------------------|------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Coal mining, processing, and transport (Company A) | 5 t CO 2 e                                      | 0 t CO 2 e (unless electricity is used during coal min- ing and processing)        | 100tCOefromthe 2 combustion of sold products (i.e., coal) Reported in category 11 (Use of sold products)                                                                                                                                                                                                                                                                                                                                                                                                          |
| Power generator (Company B)                        | 100 t CO 2 e                                    | 0 t CO 2 e                                                                         | 5 t COefromtheextraction, 2 production, andtransporta- tion of fuel (i.e., coal) consumed by the reporting company Reported in Category 3 (Fuel- and energy-related activi- ties not included in scope 1 or scope 2) Note: The generator does not account for scope 3 emissions associated with sold electricity because the emissions are already accounted for in scope 1.                                                                                                                                      |
| Utility (Company C)                                | 0 (unless SF 6 is released from the T&D system) | 10 t COefrom 2 the generation of elec- tricity purchased and consumed by Company C | 0.5 t COefrom 2 the extraction, production, and trans- portation of fuels (i.e., coal) consumed in the gener- ation of electricity consumed by Company C (5 tons from coal mining x 10 percent of electricity generated by B that is consumed by C) 94.5 t COefrom 2 the generation (life cycle, i.e., upstream activities and combustion) of electricity pur- chased by Company C and sold to Company D Both are reported in category 3 (Fuel- and energy-related activities not included in scope 1 or scope 2) |
| End consumer of electricity (Company D)            | 0                                               | 90 t COefrom 2 the generation of elec- tricity purchased and consumed by Company D | 4.5 t COefrom 2 the extraction, production, and transportation of coal consumed in the generation of electricity consumed by Company D 10.5 t COefrom 2 the generation (life cycle, i.e., upstream activities and combustion) of electricity that is con- sumed (i.e., lost) in transmission and distribution Both are reported in category 3 (Fuel- and energy-related activities not included in scope 1 or scope 2)                                                                                            |

Source: Table 5.6 from the Scope 3 Standard.

## Calculating upstream emissions of purchased fuels (activity A of table 3.1)

This activity includes the extraction, production, and transportation of fuels consumed by the reporting company. Companies may use either of the following methods to calculate scope 3 emissions from upstream emissions of purchased fuels:

- · Supplier-specific method , which involves collecting data from fuel providers on upstream emissions (extraction, production and transportation) of fuel consumed by the reporting company
- · Average-data method , which involves estimating emissions by using secondary (e.g., industry average) emission factors for upstream emissions per unit of consumption (e.g., kg CO e/kWh). 2

## Activity data needed

Companies should collect data on:

- · Quantities and types of fuel consumed.

## Emission factors needed

To calculate emissions from this activity, companies should use life cycle emission factors that exclude emissions from combustion, since emissions from combustion are accounted for in scope 1 (in the case of fossil fuels) or in a separate memo item (in the case of direct CO  emissions from combustion of biomass or biofuels). 2

If using the supplier-specific method, companies should use fuel-provider-specific emission factors for extraction, production, and transportation of fuels per unit of fuel consumed (e.g., kg CO e/kWh), by fuel type and country/region. 2

If using the average-data method companies should use average emission factors for upstream emissions per unit of , consumption (e.g., kg CO e/kWh). 2

## Data collection guidance

Companies may obtain data by:

- · Reference to their scope 1 GHG inventory, including quantities, sources and types of fuels consumed
- · Collecting data from their fuel procurement departments
- · If necessary, collecting data from fuel suppliers
- · Reference to life cycle databases.

A list of third-party databases is on the GHG Protocol website (http://www.ghgprotocol.org/Third-Party-Databases). Additional databases may be added periodically, so continue to check the website.

Some sources of emission factors may provide upstream emissions of purchased fuels, excluding emissions from combustion. If this is not the case, companies should determine upstream emissions from purchased fuels (excluding emissions from combustion) using the following formula.

## Calculation formula [3.1] Upstream emissions of purchased fuels

## Upstream CO e emissions of purchased fuels (extraction, production, and transportation of fuels 2 consumed by the reporting company) =

## sum across each fuel type consumed:

∑ (fuel consumed (e.g., kWh) × upstream fuel emission factor (kg CO e)/kWh)) 2

## where:

upstream fuel emission factor = life cycle emission factor - combustion emission factor.

If possible, the combustion and life cycle emission factors should be from the same temporal, technical, and geographic representativeness (see table 7.6 of the Scope 3 Standard ).

## Calculating upstream emissions of purchased electricity (activity B of table 3.1)

This activity includes the extraction, production, and transportation of fuels consumed in the generation of electricity, steam, heating, and cooling that is consumed by the reporting company. Companies may use either of the following methods to calculate scope 3 emissions from upstream emissions of purchased electricity:

- · Supplier-specific method , which involves collecting data from electricity providers on upstream emissions (extraction, production, and transportation) of electricity consumed by the reporting company
- · Average-data method , which involves estimating emissions by using secondary (e.g., industry average) emission factors for upstream emissions per unit of consumption (e.g., kg CO e/kWh). 2

## Activity data needed

Companies should collect data on:

- · Total quantities of electricity, steam, heating, and cooling purchased and consumed per unit of consumption (e.g., MWh), broken down by supplier, grid region, or country.

## Emission factors needed

To calculate emissions from this activity, companies should use life cycle emission factors that exclude emissions from combustion, since emissions from combustion are accounted for in scope 2 (in the case of electricity).

Companies should select an emission factor using one of the following approaches:

## Supplier-specific method

- · Utility-specific emission factors for extraction, production and transportation of fuels consumed per MWh of electricity, steam, heating, or cooling generated.

If data for the above is not available or applicable, companies should use the following approach:

## Average-data method

- · Grid-region, country, or regional emission factors for extraction, production, and transportation of fuels per unit of consumption (e.g., kg CO e/kWh) of electricity, steam, heating, or cooling generated. 2

Companies should ensure that emission factors used to calculate upstream emissions of purchased electricity do not include emissions from combustion because emissions from combustion to generate electricity are accounted for in scope 2 (see figure 3.1).

1

4

1

2

5

2

3

6

1. wheat

2. tree

3. mountains

3

4. glass bottle

5. plastic bottle

6. aluminium can

7. factory

8. lorry

9. cloud reversed)

12. wind turbines

13. chicken

14. cow 1

1. wheat

2. tree

3. mountains

4. glass bottle

5. plastic bottle

8. lorry

9. cloud

10. recycling bin

15. cow 2

Figure [3.1] Energy emission factors to use for different activities within scope 3 category 3 16. shop 17. factory showing carbon emissions (carbon 4 5 6 reversed) 12. wind turbines

1. wheat

2. tree

3. mountains

4. glass bottle

5. plastic bottle

6. aluminium can emissions are shown in

orange)

7. factory

8. lorry

13. chicken

<!-- image -->

## Data collection guidance

Companies should disaggregate the total amount of electricity, steam, heating, or cooling purchased, by characteristics such as supplier, grid region, or country. Energy consumption data should then be multiplied by representative emission factors (e.g., supplier or grid region) to calculate emissions.

Data sources for activity data include:

- · Reference to their scope 2 GHG inventories, including quantity and sources of electricity, steam, heat, and cooling consumption and the grid mix where the electricity was consumed
- · National statistics published by government agencies
- · Government agency energy management departments
- · If necessary, energy suppliers or generators.

Data sources for emission factors include:

- · Supplier developed emission factors for life cycle of fuels
- · Life cycle databases - excluding emissions from fuel combusted to generate electricity and transmission and distribution (T&amp;D) losses.

2

11. recycling bin (colours

1

3

The combustion and life cycle emission factors should be from the same temporal, technical, and geographic representativeness (see table 7.6 of the Scope 3 Standard ).

Scope 2 includes emissions from the generation of purchased electricity, steam, heating, and cooling consumed by the reporting company. In some regions, electricity emission factors include life cycle activities related to electricity, such as transmission and distribution of electricity, or extraction, processing and transportation of fuels used to generate electricity. Non-generation activities related to electricity are accounted for in scope 3, category 3 (Fuel- and energyrelated activities not included in scope 1 or scope 2), rather than in scope 2. As a result, companies should seek (and emission factor developers should provide) transparent, disaggregated electricity emission factors that allow separate accounting of emissions from electricity generation in scope 2 and non-generation activities related to electricity in scope 3. Proper accounting creates consistency in scope 2 accounting and reporting among companies and avoids double counting of the same emission within scope 2 by more than one company. See figure 7.2 in the Scope 3 Standard for more information on different types of electricity emission factors.

## Calculation formula [3.2] Upstream emissions of purchased electricity

## Upstream CO e emissions of purchased electricity 2

(Extraction, production, and transportation of fuels consumed in the generation of electricity, steam, heating, and cooling that is consumed by the reporting company) =

## sum across suppliers, regions, or countries:

- ∑ (electricity consumed (kWh) × upstream electricity emission factor (kgCO e)/kWh)) 2
- + (steam consumed (kWh) × upstream steam emission factor (kg CO e)/kWh)) 2
- + (heating consumed (kWh) × upstream heating emission factor (kg CO e)/kWh)) 2
- + (cooling consumed (kWh) × upstream cooling emission factor (kg CO e)/kWh)) 2

## where:

upstream emission factor = life cycle emission factor - combustion emissions factor - T&amp;D losses

Note: T&amp;D losses need to be subtracted only if they are included in the life cycle emission factor. Companies should check the emission factor to establish whether or not T&amp;D losses have been taken into account.

## Calculating emissions from transmission and distribution losses (activity C in table 3.1)

This activity includes the lifecycle emissions of electricity, steam, heating, and cooling that is consumed (i.e., lost) in a transmission and distribution (T&amp;D) system.

Companies may use the following methods to calculate scope 3 emissions from T&amp;D losses:

- · Supplier-specific method , which involves collecting data from electricity providers on T&amp;D loss rates of grids where electricity is consumed by the reporting company
- · Average-data method , which involves estimating emissions by using average T&amp;D loss rates (e.g., national, regional, or global averages, depending on data availability).

## Activity data needed

Companies should collect data on:

- · Electricity, steam, heating, and cooling per unit of consumption (e.g., MWh), broken down by grid region or country.

## Emission factors needed

Companies should collect combustion emission factors for electricity, steam, heating, and cooling, and also use the approaches below to collect data on T&amp;D loss rates.

## Supplier-specific method

- · Utility-specific T&amp;D loss rate (percent), specific to the grid where energy is generated and consumed.

If data for the above is not available or applicable, the following approach should be used:

## Average-data method

- · Country average T&amp;D loss rate (percent)
- · Regional average T&amp;D loss rate (percent)
- · Global average T&amp;D loss rate (percent)

## Data Collection Guidance

A World Bank database provides T&amp;D loss rates by country (http://data.worldbank.org/indicator/EG.ELC.LOSS. ZS?order=wbapi\_data\_value\_2009+wbapi\_data\_value+wbapi\_data\_value-last&amp;sort=desc).

## Calculation formula [3.3] Transmission and distribution losses

## CO 2 e emissions from energy (generation of electricity, steam, heating, and cooling that is consumed (i.e., lost) in a T&amp;D system) =

## sum across suppliers, regions, or countries:

∑ (electricity consumed (kWh) × electricity life cycle emission factor ((kg CO2e)/kWh)

× T&amp;D loss rate (%))

- + (steam consumed (kWh) × steam life cycle emission factor ((kg CO2e)/kWh) × T&amp;D loss rate (%))
- + (heating consumed (kWh) × heating life cycle emission factor ((kg CO2e)/kWh) × T&amp;D loss rate (%))
- + (cooling consumed (kWh) × cooling life cycle emission factor ((kg CO2e)/kWh) × T&amp;D loss rate (%))

## Example [3.1] Calculating upstream emissions of purchased electricity

Company A operates data center services in 10 countries. It purchases electricity, and in some countries, district heating, to run its data centers (district heating is a centrally operated heating system that services entire cities or other large areas). It is able to collect primary data on all electricity purchased through an energy tracking system, and uses an average-data method for relevant emission factors.

Note that this is an example for category 3 as a whole. As Company A does not sell purchased electricity, it does not have any emissions associated with category 3 activity D (life cycle emissions of power that is purchased and sold).

| Country       | Electricity purchased (kWh)   | District heating purchased (kWh)   |
|---------------|-------------------------------|------------------------------------|
| Australia     | 500,000                       | N/A                                |
| Canada        | 600,000                       | 50,000                             |
| India         | 400,000                       | N/A                                |
| United States | 5,500,000                     | N/A                                |
| Turkey        | 200,000                       | N/A                                |

Note: the activity data are illustrative only, and do not refer to actual data.

Company A sources emission factors for extraction-, production-, and transportation-related emissions of fuels for producing electricity/heating, as well as T&amp;D losses:

| Country       |   Upstream emission factor of purchased electricity (kg CO2e/kWh) | Electricity/heat combustion emis- sion factor (kg CO2e/kWh)   | T&D loss rate (percent)   | Upstream emission factor of purchased heating (kg CO2e/ kWh)   |
|---------------|-------------------------------------------------------------------|---------------------------------------------------------------|---------------------------|----------------------------------------------------------------|
| Australia     |                                                              0.12 | 0.8 (electricity)                                             | 10 (electricity)          | N/A                                                            |
| Canada        |                                                              0.1  | 0.4 (electricity) 0.15 (heat)                                 | 13 (electricity) 5 (heat) | 0.05                                                           |
| India         |                                                              0.15 | 0.8 (electricity)                                             | 15 (electricity)          | N/A                                                            |
| United States |                                                              0.1  | 0.5 (electricity)                                             | 10 (electricity)          | N/A                                                            |
| Turkey        |                                                              0.05 | 0.4 (electricity)                                             | 12 (electricity)          | N/A                                                            |

Note: the emissions factors are illustrative only, and do not refer to actual data.

## Example [3.1] Calculating upstream emissions of purchased electricity (continued)

## upstream emissions from purchased electricity (category 3, activity B):

= (500,000 × 0.12) + (600,000 × 0.1) + (400,000 × 0.15) + (5,500,000 × 0.1) + (200,000 × 0.05) = 740,000 kg CO e

2

## life cycle emissions from transmission and distribution losses (category 3, activity C):

= (500,000 × 0.8 × 0.1) + (600,000 × 0.4 × 0.13) + (50,000 × 0.15 × 0.05) + (400,000 × 0.8 × 0.15) + (5,500,000 × 0.5 × 0.1) + (200,000 × 0.4 × 0.12) = 404,175 kg CO e

2

## upstream emissions from purchased heating (category 3, activity B):

= 50,000 × 0.05

= 2,500 kg CO e 2

## total emissions from upstream purchased electricity and heat including transmission and distribution losses is calculated as follows:

= 740,000 + 404,175 + 2,500 = 1,146,675 kg CO e

2

## Calculating life cycle emissions from power that is purchased and sold (activity D in table 3.1)

This activity includes the generation of electricity, steam, heating, and cooling that is purchased by the reporting company and sold to end users (reported by a utility company or energy retailer).

Companies may use the following methods to calculate scope 3 emissions from power that is purchased and sold:

- · Supplier-specific method , which involves collecting emissions data from power generators
- · Average-data method , which involves estimating emissions by using grid average emission rates.

## Activity data needed

Companies should collect data on:

- · Quantities and specific source (e.g., generation unit) of electricity purchased and re-sold.

## Emission factors needed

Companies should collect data using one of the following approaches:

## Supplier-specific method

- · Specific CO , CH , and N O emissions data for generation units from which purchased power is produced. 2 4 2

If data for the above is not available or applicable, the following approach may be used.

## Average-data method

- · Grid average emission factor for the origin of purchased power.

## Calculation formula [3.4] Emissions from power that is purchased and sold

## CO 2 e emissions from power that is purchased and sold (generation of electricity, steam, heating, and cooling that is purchased by the reporting company and sold to end users (reported by utility company or energy retailer)) =

## sum across suppliers, regions or countries:

- ∑ (electricity purchased for resale (kWh) × electricity life cycle emission factor (kg CO e)/kWh)) 2
- + (steam purchased for resale (kWh) × steam life cycle emission factor (kg CO e)/kWh)) 2
- + (heating purchased for resale (kWh) × heating life cycle emission factor (kg CO e)/kWh)) 2
- + (cooling purchased for resale (kWh) × cooling life cycle emission factor (kg CO e)/kWh)) 2