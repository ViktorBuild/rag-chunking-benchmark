---
document_id: eu_epbd_2024_1275
title: "Directive (EU) 2024/1275 on the Energy Performance of Buildings (EPBD Recast)"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "European Parliament and Council"
year: 2024
original_file: "eu_energy_performance_of_buildings_directive_2024_1275.pdf"
tables_detected: 28
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## 2024/1275

## DIRECTIVE (EU) 2024/1275 OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL

## of  24  April  2024

## on the energy performance of buildings

## (recast)

## (Text  with  EEA relevance)

THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,

Having regard to the Treaty on the  Functioning  of  the  European  Union, and  in particular  Article  194(2)  thereof,

Having regard to the proposal  from the  European Commission,

After  transmission  of  the  draft  legislative  act  to  the  national  parliaments,

Having regard to the opinion of  the European  Economic and Social Committee ( ), 1

Having regard to the opinion of  the Committee of  the Regions ( ), 2

Acting  in  accordance  with  the  ordinary  legislative  procedure ( ), 3

## Whereas:

- (1) Directive  2010/31/EU  of  the  European  Parliament  and  of  the  Council ( )  has  been  substantially  amended  several 4 times ( ).  Since  further  amendments  are  to  be  made,  that  Directive  should  be  recast  in  the  interests  of  clarity. 5
- (2) Under  the  Paris  Agreement ( ),  adopted  in  December  2015  under  the  United  Nations  Framework  Convention  on 6 Climate Change (UNFCCC) (the 'Paris Agreement'), its Parties have agreed to hold the increase in the global average temperature well  below  2  C  above  pre-industrial  levels  and  to  pursue  efforts  to  limit  the  temperature  increase  to o 1,5  C above pre-industrial levels. Reaching the objectives of the Paris Agreement is at the core of the Commission o communication of 11 December 2019 entitled 'The European Green Deal' (the 'European Green Deal'). The Union committed  itself  to  reducing  the  Union's  economy-wide  net  greenhouse  gas  emissions  by  at  least  55 %  by  2030 below  1990  levels  in  the  updated  nationally  determined  contribution  submitted  to  the  UNFCCC  Secretariat  on 17 December 2020.
- (3) As  announced  in  the  European  Green  Deal,  the  Commission  presented  its  Renovation  Wave  strategy  in  its communication of  14  October  2020  entitled  'A  Renovation  Wave  for  Europe  -  greening  our  buildings,  creating jobs, improving lives'. The Renovation Wave strategy contains an action plan with concrete regulatory, financing and enabling measures, with the objective to at least double the annual energy renovation rate of buildings by 2030 and to foster deep renovations, resulting in 35 million building units renovated by 2030 and the creation of jobs in the construction sector. The revision of Directive 2010/31/EU is necessary as one of the vehicles by which to deliver on the Renovation Wave. It will also contribute to delivering on the New European Bauhaus initiative, presented in the Commission  communication  of  15  September  2021  entitled  'New  European  Bauhaus  -  Beautiful,  Sustainable,
- ( 1 ) OJ C 290, 29.7.2022, p. 114.
- ( 2 ) OJ C 375, 30.9.2022, p. 64.
- ( 3 ) Position  of  the  European  Parliament  of  12  March  2024  (not  yet  published  in  the  Official  Journal)  and  decision  of  the  Council  of 12 April 2024.
- ( 4 ) Directive 2010/31/EU of the European Parliament and of the Council of 19 May 2010 on the energy performance of buildings (OJ L  153,  18.6.2010,  p.  13).
- ( 5 ) See  Annex  IX,  Part  A.
- ( 6 ) OJ L  282,  19.10.2016,  p.  4.

8.5.2024

Together'  and  the  European  mission  on  climate-neutral  and  smart  cities.  The  New  European  Bauhaus  initiative  is intended to foster a more inclusive society that promotes the wellbeing of all in keeping with the historical Bauhaus, which contributed to social inclusion and the well-being of citizens, in particular worker communities. By facilitating training, networks and providing guidelines to architects, students, engineers and designers under  the principles of sustainability,  aesthetics  and  inclusion,  the  New  European  Bauhaus  initiative  can  empower  local  authorities  to develop innovative and cultural  solutions  in  creating  a  more  sustainable  built  environment.

- (4) Regulation (EU) 2021/1119 of the European Parliament and of the Council ( ) enshrines in Union law the target of 7 economy-wide  climate  neutrality  by  2050  at  the  latest  and  establishes  a  binding  Union  domestic  reduction commitment of  net  greenhouse  gas  emissions  (emissions  after  the  deduction  of  removals)  of  at  least  55 %  below 1990 levels  by  2030.
- (5) The 'Fit  for  55'  legislative  package,  announced  by means  of  the  Commission  communication of 19 October  2020 entitled 'Commission Work Programme 2021 - A Union of vitality in a world of fragility', aims to implement those objectives. That package covers a range of policy areas including energy efficiency, renewable energy, land use, land change  and  forestry,  energy  taxation,  effort  sharing,  emissions  trading  and  alternative  fuels  infrastructure.  The revision of Directive 2010/31/EU is an integral part of that package. Building on the 'Fit for 55' legislative package, the REPowerEU plan contained in the Commission communication of 18 May 2022 entitled 'REPowerEU Plan' put forward an additional set of actions to save energy, diversify supplies, quickly substitute fossil fuels by accelerating Europe's  clean  energy  transition  and  smartly  combine  investments  and  reforms.  It  contained  new  legislative proposals  and  targeted  recommendations  by  which  to  increase  ambition  with  regard  to  energy  efficiency  and savings.  The  communication  also  referred  to  taxation  measures  as  means  to  provide  incentives  for  energy  savings and reduce fossil  fuel  consumption.
- (6) Buildings account for 40 % of final energy consumption in the Union and 36 % of its energy-related greenhouse gas emissions while 75 % of Union buildings are still energy-inefficient. Natural gas plays the largest role in the heating of buildings, accounting for around 39 % of energy consumption used for space heating in the residential sector. Oil is  the  second  most  important  fossil  fuel  for  heating,  accounting  for  11 %  and  coal  accounts  for  around  3 %. Therefore,  reduction  of  energy  consumption,  in  line  with  the  'energy  efficiency  first'  principle  as  laid  down  in Article  3  of  Directive  (EU)  2023/1791  of  the  European  Parliament  and  of  the  Council ( )  and  defined  in  Article  2, 8 point (18), of Regulation (EU) 2018/1999 of the European Parliament and of the Council ( ) and the use of energy 9 from  renewable  sources  in  the  buildings  sector  constitute  important  measures  needed  to  reduce  greenhouse  gas emissions  and  energy  poverty  in  the  Union.  Reduced  energy  consumption  and  an  increased  use  of  energy  from renewable sources, especially solar energy, also have a key role to play in reducing the Union's energy dependency on fossil fuels overall and on imports especially, promoting security of energy supply in line with the objectives set out in  the  REPowerEU  plan,  fostering  technological  developments  and  in  creating  opportunities  for  employment  and regional  development,  in particular  in  islands,  rural  areas  and  off-grid  communities.
- (7) Buildings are responsible for greenhouse gas emissions before, during and after their operational lifetime. The 2050 vision  for  a  decarbonised  building  stock  goes  beyond  the  current  focus  on  operational  greenhouse  gas  emissions. The whole-life-cycle emissions of buildings should therefore progressively be taken into account, starting with new buildings.  Buildings  are  a  significant  material  bank,  being  repositories  for  resources  over  many  decades,  and  the design options and choices of materials largely influence the whole-life-cycle emissions both for new buildings and renovations.  The  whole-life-cycle  performance  of  buildings  should  be  taken  into  account  not  only  in  new construction,  but  also  in  renovations  through  the  inclusion  of  policies  for  the  reduction  of  whole-life-cycle greenhouse gas  emissions in  Member  States'  national  building  renovation plans.

( 7 ) Regulation  (EU)  2021/1119  of  the  European  Parliament  and  of  the  Council  of  30  June  2021  establishing  the  framework  for achieving climate neutrality and amending Regulations (EC) No 401/2009 and (EU) 2018/1999 ('European Climate Law') (OJ L 243, 9.7.2021,  p.  1).

( 8 ) Directive (EU) 2023/1791 of the European Parliament and of the Council of 13 September 2023 on energy efficiency and amending Regulation (EU) 2023/955 (OJ L 231, 20.9.2023, p. 1).

( 9 ) Regulation (EU) 2018/1999 of the European Parliament and of the Council of 11 December 2018 on the Governance of the Energy Union and Climate Action, amending Regulations (EC) No 663/2009 and (EC) No 715/2009 of the European Parliament and of the Council,  Directives  94/22/EC,  98/70/EC,  2009/31/EC,  2009/73/EC,  2010/31/EU,  2012/27/EU  and  2013/30/EU  of  the  European Parliament and of the Council, Council Directives 2009/119/EC and (EU) 2015/652 and repealing Regulation (EU) No 525/2013 of the  European  Parliament  and  of  the  Council  (OJ  L  328,  21.12.2018,  p.  1).

- (8) Minimising  the  whole-life-cycle  greenhouse  gas  emissions  of  buildings  requires  resource  efficiency  and  circularity. This  can  also  be  combined  with  turning  parts  of  the  building  stock  into  a  temporary carbon  sink.
- (9) The global warming potential (GWP) over a building's whole life cycle indicates the building's overall contribution to emissions  that  lead  to  climate  change.  It  brings  together  greenhouse  gas  emissions  embodied  in  construction products with direct and indirect emissions from the use stage. A requirement to calculate the life-cycle GWP of new buildings  therefore  constitutes  a  first  step  towards  increased  consideration  of  the  whole-life-cycle  performance  of buildings  and  a  circular  economy.
- (10) Buildings are responsible for about half of primary fine particulate matter (PM 2,5 )  emissions in the Union that cause premature  death  and  illness.  Improving  the  energy  performance  of  buildings  can  and  should  reduce  pollutant emissions  at  the  same  time,  in  accordance  with  Directive  (EU)  2016/2284  of  the  European  Parliament  and  of  the Council ( 10 ).
- (11) Measures  to  improve  further  the  energy  performance  of  buildings  should  take  into  account  climatic  conditions, including adaptation to climate change, local conditions as well as the indoor climate and cost-effectiveness. Those measures  should  not  affect  other  requirements  concerning  buildings  such  as  accessibility,  fire  safety  and  seismic safety  and  the  intended  use  of  the  building.
- (12) The  energy  performance  of  buildings  should  be  calculated  on  the  basis  of  a  methodology,  which  may  be differentiated at national and regional level. That methodology should include, in addition to thermal characteristics, other factors that play an increasingly important role such as urban heat island effect, heating and air-conditioning installations,  the  use  of  energy  from  renewable  sources,  building  automation  and  control  systems,  heat  recovery from exhaust air or  waste water, system balancing, smart solutions, passive heating and cooling elements, shading, indoor environmental quality, adequate natural light and design of the building. The methodology for calculating the energy  performance  of  buildings  should  be  based  not  only  on  the  season  in  which  heating  or  air-conditioning  is required,  but  should  cover  the  annual  energy  performance  of  a  building.  It  should  take  into  account  existing European standards. The methodology should ensure the representation of actual operating conditions and enable the use of metered energy to verify correctness and for comparability, and should be based on monthly, hourly or sub-hourly calculation intervals.  In  order  to  encourage the  use  of on-site  renewable  energy,  and  in  addition  to  the common general framework,  Member States  should  take  the  necessary  measures  to  the  effect  that  the  benefits  of maximising the use of on-site renewable energy, including for other uses, such as electric vehicle recharging points, are  recognised  and  accounted  for  in  the  calculation  methodology.
- (13) Member  States  should  set  minimum  energy  performance  requirements  for  buildings  and  building  elements  with a view  to  achieving  the  cost-optimal  balance  between  the  investments  involved  and  the  energy  costs  saved throughout the life  cycle  of  the  building,  without  prejudice  to  the  right  of  Member  States  to  set  minimum  energy performance  requirements  which  are  more  energy-efficient  than  cost-optimal  energy  efficiency  levels.  Provision should  be  made  for  the  possibility  for  Member  States  to  review  regularly  their  minimum  energy  performance requirements for  buildings  in  light  of  technical  progress.
- (14) Two  thirds  of  the  energy  used  for  heating  and  cooling  of  buildings  still  comes  from  fossil  fuels.  In  order  to decarbonise  the  building  sector,  it  is  of  particular  importance  to  phase  out  fossil  fuel  in  heating  and  cooling. Therefore, Member States should indicate their national policies and measures to phase out fossil fuels in heating and cooling in their national building renovation plans. They should strive to phase out stand-alone boilers powered by fossil  fuels,  and,  as  a  first  step,  they  should  not  provide,  from  2025,  financial  incentives  for  the  installation  of stand-alone boilers powered by fossil fuels, with the exception of those selected for investment, before 2025, under the Recovery and Resilience Facility established by Regulation (EU) 2021/241 of the European Parliament and of the Council ( 11 ), and  the  European  Regional  Development  Fund  and  the  Cohesion  Fund  under  Regulation  (EU) 2021/1058  of  the  European  Parliament  and  of  the  Council ( 12 ). It  should  still  be  possible  to  provide  financial incentives for  the installation of hybrid heating systems with a considerable share of renewable energy, such as the

( 10 ) Directive  (EU)  2016/2284  of  the  European  Parliament  and  of  the  Council  of  14  December  2016  on  the  reduction  of  national emissions  of  certain  atmospheric  pollutants,  amending  Directive  2003/35/EC  and  repealing  Directive  2001/81/EC  (OJ  L  344, 17.12.2016, p.  1).

( 11 ) Regulation  (EU)  2021/241  of  the  European  Parliament  and  of  the  Council  of  12  February  2021  establishing  the  Recovery  and Resilience  Facility  (OJ  L  57,  18.2.2021,  p.  17).

( 12 ) Regulation  (EU)  2021/1058  of  the  European  Parliament  and  of  the  Council  of  24  June  2021  on  the  European  Regional Development Fund and on the Cohesion Fund (OJ L 231, 30.6.2021, p. 60).

- combination  of  a  boiler  with  solar  thermal  or  with  a  heat  pump.  A  clear  legal  basis  for  the  banning  of  heat generators on the basis of their greenhouse gas emissions, the type of fuel used or to the minimum part of renewable energy used for  heating at  building's  level  should  support  national  phase-out  policies  and  measures.
- (15) Domestic hot-water generation is one of the main sources of energy consumption for high-performing buildings. In most  cases,  that  energy  is  not  recovered.  Harvesting  heat  from  domestic  hot-water  drains  in  buildings  could  be a  simple  and  cost-effective  way  to  save  energy.
- (16) Energy  performance  requirements  for  technical  building  systems  should  apply  to  whole  systems,  as  installed  in buildings,  and  not  to  the  performance  of  standalone  components,  which  fall  under  the  scope  of  product-specific regulations under Directive 2009/125/EC of the European Parliament and of the Council ( 13 ).  When setting energy performance  requirements for technical building systems, Member  States  should use, where  available and appropriate,  harmonised  instruments,  in  particular  testing  and  calculation  methods  and  energy  efficiency  classes developed under measures implementing Directive 2009/125/EC and Regulation (EU) 2017/1369 of the European Parliament and of the Council ( 14 ),  with  a view to ensuring consistency with related initiatives and minimise, to the extent possible, potential fragmentation of the market. Energy-saving technologies with very short payback periods, such  as  the  installation  or  replacement  of  thermostatic  control  valves  or  heat  recovery  from  exhaust  air  or  waste water,  are  given  insufficient  consideration  today.  When  estimating  the  effective  rated  output  for  heating  systems, air-conditioning systems, systems for combined space heating and ventilation, or systems for combined air-conditioning and ventilation systems, in a given building or building unit the effective rated output of different generators  of  the  same  system  should  be  added  together.
- (17) This Directive is without prejudice to Articles 107 and 108 of the Treaty on the Functioning of the European Union (TFEU).  The  term  'incentive'  as  used  in  this  Directive  should  not  therefore  be  interpreted  as  constituting  State  aid.
- (18) The  Commission  should  lay  down  a  comparative  methodology  framework  for  calculating  cost-optimal  levels  of minimum  energy  performance  requirements.  A  review  of  that  framework  should  enable  the  calculation  of  both energy and emission performance and should take into account environmental and health externalities, as well as the extension of the emission trading system and carbon prices. Member States should use that framework to compare the  results  with  the  minimum  energy  performance  requirements  which  they  have  adopted.  Should  there  be significant  discrepancies,  namely  discrepancies  that  exceed  15 %,  between  the  calculated  cost-optimal  levels  of minimum energy performance requirements and the minimum energy performance requirements in force, Member States should justify the difference or plan appropriate steps to reduce the discrepancy. The estimated economic life cycle  of  a  building  or  building  element  should  be  determined  by  Member  States,  taking  into  account  current practices and experience in defining typical economic life cycles. Member States should submit to the Commission, on  a  regular  basis,  the  results  of  that  comparison  and  the  data  used  to  reach  those  results.  Those  reports  should enable  the  Commission  to  assess  and  report  on  the  progress  of  Member  States  in  reaching  cost-optimal  levels  of minimum energy performance requirements.
- (19) Major  renovations  of  existing  buildings,  regardless  of  their  size,  provide  an  opportunity  to  take  cost-effective measures  to  enhance  energy  performance.  For  reasons  of  cost-effectiveness,  it  should  be  possible  to  limit  the minimum  energy  performance  requirements  to  the  renovated  parts  that  are  most  relevant  for the energy performance  of  the  building.  Member  States  should  be  able  to  define  a  'major  renovation'  either  in  terms  of a  percentage  of  the  surface  of  the  building  envelope  or  in  terms  of  the  value  of  the  building.  If  a  Member  State decides to define a major renovation in terms of the value of the building, values such as the actuarial value, or the current  value  based  on  the  cost  of  reconstruction,  excluding  the  value  of  the  land  upon  which  the  building  is situated,  could  be  used.
- (20) The  enhanced  climate  and  energy  ambition  of  the  Union  requires  a  new  vision  for  buildings:  the  zero-emission building,  with  very  low  energy  demand,  zero  on-site  carbon  emissions  from  fossil  fuels  and  zero  or  a  very  low amount of operational greenhouse gas emissions. All new buildings should be zero-emission buildings by 2030, and existing  buildings  should  be  transformed  into  zero-emission  buildings  by  2050.

( 13 ) Directive 2009/125/EC of the European Parliament and of the Council of 21 October 2009 establishing a framework for the setting of  ecodesign  requirements  for  energy-related  products  (OJ  L  285,  31.10.2009,  p.  10).

( 14 ) Regulation (EU) 2017/1369 of the European Parliament and of the Council of 4 July 2017 setting a framework for energy labelling and repealing  Directive  2010/30/EU  (OJ  L  198,  28.7.2017,  p.  1).

- (21) Where an existing building is  altered,  it  is  not  considered  to  be  a  new  building.
- (22) Different  options  are  available  to  cover  the  energy  needs  of  a  zero-emission  building:  energy  generated  on  site  or nearby from  renewable  sources  such  as  solar  thermal,  geothermal,  solar  photovoltaics,  heat  pumps,  hydroelectric power  and  biomass,  renewable  energy  provided  by  renewable  energy  communities,  efficient  district  heating  and cooling,  and  energy  from  other  carbon-free  sources.  Energy  derived  from  combustion  of  renewable  fuels  is considered to be energy from renewable sources generated on-site where the combustion of the renewable fuel takes place  on-site.
- (23) Zero-emission  buildings  can  contribute  to  demand-side  flexibility  for  instance  through  demand  management, electrical storage, thermal storage and distributed renewable generation to support a more reliable, sustainable and efficient  energy  system.
- (24) The necessary decarbonisation of the Union building stock requires energy renovation at a large scale: almost 75 % of that building stock is inefficient according to current building standards, and 85 to 95 % of the buildings that exist today  will  still  be  standing  in  2050.  However,  the  weighted  annual  energy  renovation  rate  is  persistently  low  at around 1 %. At the current pace, the decarbonisation of the building sector would require centuries. Triggering and supporting building  renovation,  including a  shift  towards  emission-free  heating  systems, is  therefore  a  key  goal  of this Directive. Supporting renovations at district-level, including through industrial or serial type renovations, offers benefits  by  stimulating  the  volume  and  depth  of  building  renovations  and  will  lead  to  a  quicker  and  cheaper decarbonisation of the building stock. Industrial solutions for construction and building renovation include versatile prefabricated  elements  providing  different  functions  such  as  insulation  and  energy  generation.
- (25) Minimum  energy  performance  standards  are  the  essential  regulatory  tool  by  means  of  which  to  trigger  the renovation of existing buildings on a large scale, as they tackle the key barriers to renovation such as split incentives and  co-ownership  structures,  which  cannot  be  overcome  by  economic  incentives.  The  introduction  of  minimum energy  performance  standards  should  lead  to  a  gradual  phasing  out  of  the  worst-performing  buildings  and a  continuous  improvement  of  the  national  building  stock,  contributing  to  the  long-term  goal  of  a  decarbonised building  stock  by  2050.
- (26) Minimum energy  performance  standards  for  non-residential  buildings  should  be  provided  for  at  Union  level  and should focus on the renovation of the worst-performing non-residential buildings, which have the highest potential in  terms  of  decarbonisation  and  extended  social  and  economic  benefits  and  therefore  need  to  be  renovated  as a priority. In addition, Member States should establish specific timelines for the further renovation of non-residential buildings  in  their  national  building  renovation  plans.  Some  specific  situations  justify  exemptions  for  individual non-residential  buildings  from  minimum  energy  performance  standards,  in  particular  the  planned  demolition  of a building or an unfavourable cost-benefit assessment; cases of serious hardship justify an exemption for as long as the  hardship  persists.  Member  States  should  establish  stringent  criteria  for  such  exemptions  in  order  to  avoid a  disproportionate  share  of  exempted  non-residential  buildings.  They  should  communicate  those  criteria  in  their national building renovation plans and should compensate for the exempted non-residential buildings via equivalent energy performance improvements in other  parts  of  the  non-residential  building  stock.
- (27) As regards  residential  buildings,  Member  States  should  have  the  flexibility  to  choose  the  tools  by  means  of  which they  achieve  the  required  improvement  of  the  residential  building  stock,  such  as  minimum  energy  performance standards, technical assistance and financial support measures. Member States should establish a national trajectory for  the  progressive  renovation of  the  national residential building stock in line with the national roadmap and the 2030,  2040  and  2050  targets  contained  in  the  Member  State's  national  building  renovation  plan  and  with  the transformation of the national building stock into a zero-emission building stock by 2050. The national trajectories should  comply  with  intermediate,  five-year  milestones  for  the  decrease  in  the  average  primary  energy  use  of  the residential  building  stock,  starting  in  2030,  which  ensure  similar  efforts  across  Member  States.
- (28) As regards the rest of the national building stock, Member States are free to decide whether they wish to introduce minimum  energy  performance  standards,  designed  at  national  level  and  adapted  to  national  conditions.  When reviewing this Directive, the Commission should assess whether the measures established pursuant to this Directive will  deliver  sufficient  progress  towards  achieving  a  fully  decarbonised,  zero-emission  building  stock  by  2050  or whether  further  measures,  such  as  binding  minimum  energy  performance  standards  need  to  be  introduced,  in particular  for  residential  buildings  in  order  to  achieve  the  five-year  milestones.

- (29) The  introduction  of  minimum  energy  performance  standards  should  be  accompanied  by  an  enabling  framework including  technical  assistance  and  financial  measures,  in  particular  for  vulnerable  households.  Minimum  energy performance  standards  set  at  national  level  do  not  amount  to  'Union  standards'  within  the  meaning  of  State  aid rules,  while  Union-wide  minimum  energy  performance  standards  might  be  considered  to  constitute  such  'Union standards'. In line with revised State aid rules, Member States may grant State aid to building renovation to comply with the Union-wide energy performance standards until those Union-wide standards become mandatory. Once the standards are mandatory, Member States may continue to grant State aid for the renovation of buildings and building units  falling  under  the  Union-wide  energy  performance  standards,  provided  that  the  building  renovation  aims  at a  higher  standard.
- (30) The  EU  Taxonomy,  established  by  Regulation  (EU)  2020/852  of  the  European  Parliament  and  of  the  Council ( 15 ), classifies  environmentally  sustainable  economic  activities  across  the  economy,  including  for  the  building  sector. Under Commission Delegated Regulation (EU) 2021/2139 ( 16 )  (the  'EU Taxonomy Climate Delegated Act'), building renovation  is  considered  to  be  a  sustainable  activity  where  it  achieves  at  least  30 %  energy  savings,  complies  with minimum  energy  performance  requirements  for  major  renovation  of  existing  buildings,  or  consists  of  individual measures related to the energy performance of buildings, such as the installation, maintenance or  repair of energy efficiency equipment  or  of instruments and devices for measuring, regulating and controlling the energy performance of buildings, where such individual measures comply with the established criteria. Building renovation to  comply  with  Union-wide  minimum  energy  performance  standards  is  typically  in  line  with  the  EU  Taxonomy criteria  related  to  building  renovation  activities.
- (31) Minimum energy performance requirements for existing buildings and building elements were already contained in the  predecessors  of  this  Directive  and  should  continue  to  apply.  While  the  newly  introduced  minimum  energy performance  standards  set  a  minimum  level  for  the  energy  performance  of  existing  buildings  and  ensure  that renovation  of  inefficient  buildings  takes  place,  minimum  energy  performance  requirements  for  existing  buildings and building elements  ensure  the  necessary  depth  of  renovation  when  a  renovation  takes  place.
- (32) There is an urgent need to reduce the dependence on fossil fuels in buildings and to accelerate efforts to decarbonise and  electrify  their  energy  consumption.  In  order  to  enable  the  cost-effective  installation  of  solar  technologies  at a later stage, all new buildings should be 'solar-ready', that is, designed to optimise the solar generation potential on the  basis  of  the  site's  solar  irradiance,  enabling  the  installation  of  solar  technologies  without  costly  structural interventions.  In  addition,  Member  States  should  ensure  the  deployment  of  suitable  solar  installations  on  new buildings, both residential and non-residential, and on existing non-residential buildings. The large-scale deployment of  solar  energy  on  buildings  would  make  a  major  contribution  to  shielding  more  effectively  consumers  from increasing and volatile prices of fossil fuels, reduce the exposure of vulnerable citizens to high energy costs and result in wider  environmental,  economic  and  social  benefits.  In  order  to  efficiently  exploit  the  potential  of  solar installations on  buildings, Member  States  should  establish  criteria  for the implementation  of,  and  possible exemptions  from,  the  deployment  of  solar  installations  on  buildings,  in  line  with  the  assessed  technical  and economic  potential  of  the  solar  energy  installations  and  the  characteristics  of  the  buildings  covered  by  this obligation, taking into account the principle of technology neutrality and the combination of solar installations with other  roof  uses,  such  as  green  roofs  or  other  building  services  installations.  In  their  criteria  for  the  practical implementation of  the obligations of deployment of suitable solar energy installation on buildings, Member States should be able to express the relevant threshold in terms of the building's ground floor area instead of the building's useful  floor  area,  provided  that  such  a  method  corresponds  to  an  equivalent  installed  capacity  of  suitable  solar energy installation on buildings. As the obligation to deploy solar  installations on individual buildings depends on the  criteria  established  by  Member  States,  the  provisions  on  solar  energy  on  buildings  do  not  qualify  as  a  'Union standard'  within  the  meaning  of  State  aid  rules.

( 15 ) Regulation (EU) 2020/852 of the European Parliament and of the Council of 18 June 2020 on the establishment of a framework to facilitate  sustainable  investment,  and  amending  Regulation  (EU)  2019/2088  (OJ  L  198,  22.6.2020,  p.  13).

( 16 ) Commission  Delegated  Regulation  (EU)  2021/2139  of  4  June  2021  supplementing  Regulation  (EU)  2020/852  of  the  European Parliament  and  of  the  Council  by  establishing  the  technical  screening  criteria  for  determining  the  conditions  under  which  an economic  activity  qualifies  as  contributing  substantially  to  climate  change  mitigation  or  climate  change  adaptation  and  for determining  whether  that  economic  activity  causes  no  significant  harm  to  any  of  the  other  environmental  objectives  (OJ  L  442, 9.12.2021, p.  1).

- (33) It should  be  possible  for  Member  States  to  encourage,  by  means  of  information,  appropriate  administrative procedures or other measures that are set out in their national building renovation plans, the deployment of suitable solar  energy  installations  in  combination  with  the  renovation  of  the  building  envelope,  with  the  replacement  of technical building systems or with the installation of recharging infrastructure for electric vehicles, of heat pumps or of  building  automation  and  control  systems.
- (34) With regard to mixed-used buildings that include both residential and non-residential building units, Member States may continue to choose whether  to treat  them  as  residential  or  non-residential  buildings.
- (35) Solar photovoltaics and solar thermal technologies, including in combination with energy storage, should be rolled out  rapidly  to  benefit  both  the  climate  and  the  finances  of  citizens  and  businesses.
- (36) The  electrification  of  buildings,  such  as  through  the  deployment  of  heat  pumps,  solar  installations,  batteries  and recharging infrastructure, changes the risks with regard to the fire safety of buildings, which Member States need to address. As regards fire safety in car parks, the Commission should publish non-binding guidance for Member States.
- (37) To  achieve  a  highly  energy-efficient  and  decarbonised  building  stock  and  the  transformation  of  existing  buildings into  zero-emission  buildings  by  2050,  Member  States  should  establish  national  building  renovation  plans  which replace  the  long-term  renovation  strategies  provided  for  in  Article  2a  of  Directive  2010/31/EU  and  which  are  to become an even stronger, fully operational planning tool for Member States, in line with the 'energy efficiency first' principle,  with  a  stronger  focus  on  financing  and  ensuring  that  appropriately  skilled  workers  are  available  for carrying  out  building  renovations  Member  States  may  take  into  account  the  Pact  for  Skills  set  out  in  the communication of the Commission of 1 July 2020 entitled 'European Skills Agenda for sustainable competitiveness, social  fairness  and  resilience'.  In  their  national  building  renovation  plans,  Member  States  should  set  their  own national building renovation targets. In accordance with Article 21, point (b)(7), of Regulation (EU) 2018/1999 and with  the  enabling  conditions  set  under  Regulation  (EU)  2021/1060  of  the  European  Parliament  and  of  the Council ( 17 ),  Member States should provide an outline of financing measures, as well as an outline of the investment needs and  the  administrative  resources  for  the  implementation  of  their  national  building  renovation  plans.
- (38) The 'energy efficiency first' principle is an overarching principle that should be taken into account across all sectors, going beyond the energy system, at all levels. It is defined in Article 2, point (18), of Regulation (EU) 2018/1999 as meaning  to  take  utmost  account  in  energy  planning,  and  in  policy  and  investment  decisions,  of  alternative cost-efficient energy efficiency measures to make energy demand and energy supply more efficient, in particular by means  of  cost-effective end-use energy savings, demand-response  initiatives and  more  efficient conversion, transmission  and  distribution  of  energy,  whilst  still  achieving  the  objectives  of  those  decisions.  The  principle  is therefore  equally  relevant  with  regard  to  improving  the  energy  performance  of  buildings  and  is  highlighted  in  the Renovation Wave strategy as one of the key principles for building renovation towards 2030 and 2050. As set out in Commission  Recommendation  (EU)  2021/1749 ( 18 ),  improved  health  and  well-being  are among  the  major co-benefits  of  applying  the  'energy  efficiency  first'  principle  to  improve  the  energy  performance  of  buildings.
- (39) In  order  to  ensure  that  the  Union's  workforce  is  fully  prepared  to  work  actively  towards  the  achievement  of  the Union  climate  objectives,  Member  States  should  encourage  under-represented  groups  to  train  and  work  in  the construction  and  building  sector.
- (40) The national building renovation plans should be based on a harmonised template in order to ensure comparability of  plans.  In  order  to  ensure  the  required  ambition,  the  Commission  should  assess  the  draft  national  building renovation plans  and  issue  recommendations  to Member  States.
- (41) The  national  building  renovation  plans  should  be  closely  linked  with  the  integrated  national  energy  and  climate plans under Regulation (EU) 2018/1999, and progress in achieving the national targets and the contribution of the national building renovation plans to national and Union targets should be reported as part of the biennial reporting

( 17 ) Regulation (EU) 2021/1060 of the European Parliament and of the Council of 24 June 2021 laying down common provisions on the  European  Regional  Development  Fund,  the  European  Social  Fund  Plus,  the  Cohesion  Fund,  the  Just  Transition  Fund  and  the European  Maritime,  Fisheries  and  Aquaculture  Fund  and  financial  rules  for  those  and  for  the  Asylum,  Migration  and  Integration Fund,  the  Internal  Security  Fund  and  the  Instrument  for  Financial  Support  for  Border  Management  and  Visa  Policy  (OJ  L  231, 30.6.2021, p.  159).

( 18 ) Commission Recommendation (EU) 2021/1749 of 28 September 2021 on Energy Efficiency First:  from principles to practice Guidelines and examples for  its implementation in decision-making in the energy sector and beyond (OJ L 350, 4.10.2021, p. 9).

- under  Regulation  (EU)  2018/1999.  Considering  the  urgency  to  scale  up  renovation  on  the  basis  of  solid  national building renovation plans, the date for the submission of the first national building renovation plan should be set as early  as  possible.  The  subsequent  national  building  renovation plans should  be  submitted  as  part of  the  integrated national energy and climate plans and their updates, which means that the second draft national building renovation plan  should  be  submitted  with  the  second  draft  integrated  national  energy  and  climate  plans  in  2028.
- (42) A staged  deep  renovation  can  be  a  solution  to  address  high  upfront  costs  and  hassle  for  the  inhabitants  that  may occur  when  renovating  'in  one  go'  and  can  allow  for  less  disruptive  and  more  financially  feasible  renovation measures. However, such staged deep renovation needs to be carefully planned in order to avoid that one renovation step precludes necessary subsequent steps. One-step deep renovation can be more cost-effective and result in fewer emissions linked to the renovation than staged renovation. Renovation passports provide a clear roadmap for staged deep  renovations,  helping  owners  and  investors  plan  the  best  timing  and  scope  for  interventions.  Therefore, renovation passports should  be  encouraged and  made  available,  as  a  voluntary  tool,  to  building  owners  across  all Member States. Member States should ensure that renovation passports do  not create a disproportionate burden.
- (43) There are some synergies between renovation passports and energy performance certificates, in particular as regards the assessment of the current performance of the building and the recommendations for its improvement. In order to make the most of those synergies and reduce costs for building owners, Member States should be able to allow the renovation passport and the energy performance certificate to  be drawn up jointly  by  the  same expert and issued together. In the case  of such  joint drawing  up  and  issuing,  the  renovation  passport  should  substitute  the recommendations  in  the  energy  performance  certificate.  It  should,  however,  remain  possible  to  obtain  an  energy performance certificate  without  a  renovation  passport.
- (44) Long-term  renovation  contracts  are  an  important  instrument  by  means  of  which  to  stimulate  staged  renovation. Member States may introduce mechanisms that allow the establishment of  long-term renovation contracts over the various stages of staged renovation. Where new and more effective incentives become available during the various stages of the renovation, access to those new incentives may be ensured by allowing beneficiaries to switch to new incentives.
- (45) The  concept of  'deep  renovation'  has  not  yet  been  defined  in  Union  law.  With  a  view  to  achieving  the  long-term vision for buildings, deep renovation should be defined as a renovation that transforms buildings into zero-emission buildings  but,  as  a  first  step,  as  a  renovation  that  transforms  buildings  into  nearly  zero-energy  buildings.  This definition  serves  the  purpose  of  increasing  the  energy  performance  of  buildings.  A  deep  renovation  for  energy performance  purposes  may  also  be  a  prime  opportunity  to  address  other  aspects  such  as  indoor  environmental quality,  living  conditions  of  vulnerable  households,  increasing  climate  resilience,  resilience  against  disaster  risks including seismic resilience, fire safety, the removal of hazardous substances including asbestos, and accessibility for persons with disabilities.
- (46) In order to foster deep renovation, which is one of the goals of the Renovation Wave strategy, Member States should give  enhanced  financial  and  administrative  support  to  deep  renovation.
- (47) Member States should support energy performance upgrades of existing  buildings  that  contribute  to achieving an adequate  level  of  indoor  environmental  quality,  removing  asbestos  and  other  harmful  substances,  preventing  the illegal  removal  of  harmful  substances,  and  facilitating  compliance  with  existing  legislative  acts  such  as  Directives 2009/148/EC ( 19 )  and  (EU)  2016/2284 ( 20 )  of  the  European  Parliament  and  of  the  Council.
- (48) Integrated district or  neighbourhood approaches help to increase the cost-effectiveness of the renovations required for  buildings  that  are  spatially  related  such  as  housing  blocks.  Such  approaches  to  renovations  offer  a  variety  of solutions  at  a  larger  scale.

( 19 ) Directive 2009/148/EC of the European Parliament and of the Council of 30 November 2009 on the protection of workers from the risks  related  to  exposure  to  asbestos  at  work  (OJ  L  330,  16.12.2009,  p.  28).

( 20 ) Directive  (EU)  2016/2284  of  the  European  Parliament  and  of  the  Council  of  14  December  2016  on  the  reduction  of  national emissions  of  certain  atmospheric  pollutants,  amending  Directive  2003/35/EC  and  repealing  Directive  2001/81/EC  (OJ  L  344, 17.12.2016, p.  1).

- (49) Electric  vehicles  are  expected  to  play  a  crucial  role  in  the  decarbonisation  and  efficiency  of  the  electricity  system, namely  through  the  provision  of  flexibility,  balancing  and  storage  services,  especially  through  aggregation.  This potential of electric vehicles to integrate with the electricity system and contribute to system efficiency and further absorption  of  renewable  electricity  should  be  fully  exploited.  Recharging  in  relation  to  buildings  is  particularly important,  since  this  is  where  electric  vehicles  park  regularly  and  for  long  periods  of  time.  Slow  recharging  is economical  and  the  installation  of  recharging  points  in  private  spaces  can  provide  energy  storage  to  the  related building and integration of smart recharging services and bi-directional recharging and system integration services in general.
- (50) Combined with an increased share of renewable electricity production, electric vehicles produce less greenhouse gas emissions. Electric vehicles constitute an important component of a clean energy transition on the basis of energy efficiency  measures,  alternative  fuels,  renewable  energy  and  innovative  solutions  for  the  management  of  energy flexibility.  Building  codes  can  be  effectively  used  to  introduce  targeted  requirements  to support  the  deployment of recharging  infrastructure  in  car  parks  of  residential  and  non-residential  buildings.  Member  States  should  aim  to remove barriers such as split incentives and administrative complications which individual owners encounter when trying  to  install  a  recharging  point  on  their  parking  space.
- (51) Pre-cabling and ducting facilitate the rapid  deployment of  recharging points if and  where they are needed. Readily available infrastructure will decrease the costs of installation of recharging points for individual owners and ensure that  electric  vehicle  users  have  access  to  recharging  points.  Establishing  requirements  for  electromobility  at  Union level concerning the pre-equipping of parking spaces and the installation of recharging points is an effective way to promote electric vehicles in the near future while enabling further development at a reduced cost in the medium to long term. Where technically feasible, Member States should ensure the accessibility of recharging points for persons with disabilities.
- (52) Smart recharging and bi-directional recharging enable the energy system integration of buildings. Recharging points where  electric  vehicles  typically  park  for  extended  periods  of  time,  such  as  where  people  park  for  reasons  of residence or employment, are highly relevant to energy system integration, therefore smart recharging functionalities need  to  be  ensured.  In  situations  where  bi-directional  recharging  would  assist  further  penetration  of  renewable electricity by electric vehicle fleets in transport and the electricity system in general, such functionality should also be made available.
- (53) Promoting  green  mobility  is  a  key  part  of  the  European  Green  Deal  and  buildings  can  play  an  important  role  in providing  the  necessary  infrastructure,  not  only  for  recharging  of  electric  vehicles  but  also  for  bicycles.  A  shift  to active mobility such as cycling can significantly reduce greenhouse gas emissions from transport. With the increase in  the  sale  of  electrically  power-assisted  cycles  and  other  L-category  vehicle  types,  referred  to  in  Article  4  of Regulation  (EU)  No  168/2013  of  the  European  Parliament  and  of  the  Council ( 21 ),  and  in  order  to  facilitate  the installation  of  recharging  points  at  a  later  stage,  pre-cabling  or  ducting  should  be  required  in  new  residential buildings and, where technically and economically feasible, in residential buildings undergoing major renovation. As set  out  in  the  communication  of  the  Commission  of  17  September  2020  on  'Stepping  up  Europe's  2030  climate ambition - Investing in a climate-neutral future for the benefit of our people' (the 'Climate Target Plan'), increasing the modal shares of clean and efficient private and public transport, such as cycling, will drastically lower pollution from transport and bring major benefits to individual citizens and communities. The lack of bicycle parking spaces is a  major barrier  to the uptake of cycling, both in residential and non-residential buildings. Union requirements and national  building  codes  can  effectively  support  the  transition  to  cleaner  mobility  by  establishing  requirements  for a minimum number of bicycle parking spaces, and building bicycle parking spaces and related infrastructure in areas where bicycles are less used can lead to an increase in their use. The requirement to provide bicycle parking spaces should not depend on, or necessarily be linked to, the availability and supply of car parking spaces, which may be unavailable  in  certain  circumstances.  Member  States  should  allow  an  increase  in  bicycle  parking  in  residential buildings  where  there  are  no  car  parking  spaces  by  providing  for  the  installation  of  at  least  two  bicycle  parking spaces  for  every  residential  building  unit.
- (54) The agendas of the Digital Single Market and the Energy Union should be aligned and should serve common goals. The digitalisation of the energy system is quickly changing the energy landscape, from the integration of renewables to  smart grids and smart-ready buildings. In order  to digitalise the building sector, the Union's connectivity targets
- ( 21 ) Regulation  (EU)  No  168/2013  of  the  European  Parliament  and  of  the  Council  of  15  January  2013  on  the  approval  and  market surveillance  of  two-  or  three-wheel  vehicles  and  quadricycles  (OJ  L  60,  2.3.2013,  p.  52).

- and ambitions for  the  deployment of  high-capacity communication  networks  are  important  for  smart  homes  and well-connected  communities.  Targeted  incentives  should  be  provided  to  promote  smart-ready  systems  and  digital solutions in the built environment. This would offer new opportunities for energy savings, by providing consumers with more accurate information about their consumption patterns, and by enabling the system operator to manage the grid more effectively. Member States should encourage the use of digital technologies for analysis, simulation and management of buildings,  including  with  regard  to deep  renovations.
- (55) In  order  to  facilitate  a  competitive  and  innovative  market  for  smart  building  services  that  contributes  to  efficient energy use and integration of renewable energy in buildings and support investments in renovation, Member States should ensure direct access to building systems' data by interested parties. To avoid excessive administrative costs for third  parties,  Member States shall facilitate the full  interoperability of services and  of  the  data exchange within  the Union.
- (56) The  smart  readiness  indicator  should  be  used  to  measure  the  capacity  of  buildings  to  use  information  and communication  technologies  and  electronic  systems  to  adapt  the  operation  of  buildings  to  the  needs  of  the occupants  and  the  grid  and  to  improve  the  energy  efficiency  and  overall  performance  of  buildings.  The  smart readiness  indicator  should  raise  awareness  among  building  owners  and  occupants  of  the  value  behind  building automation and electronic monitoring of technical building systems and should give confidence to occupants about the actual savings of those new enhanced-functionalities. The smart readiness indicator is particularly beneficial for large  buildings  with  a  high  energy  demand.  For  other  buildings,  the  scheme  for  rating  the  smart  readiness  of buildings  should  be  optional  for  Member  States.
- (57) A digital  building  twin  is  an  interactive  and  dynamic  simulation  that  reflects  the  real-time  status  and  behaviour of a physical building. By incorporating real-time data from sensors, smart meters and other sources, a digital building twin provides a holistic view of  the building's performance, including energy consumption, temperature, humidity, occupancy  levels,  and  more  and  can  be  used  to  monitor  and  manage  the  building's  energy  consumption.  Where a  digital  building  twin  is  available,  it  should  be  taken  into  account,  in  particular  for  the  smart  readiness  indicator.
- (58) Access  to  sufficient  funding  is  crucial  to  meet  the  2030  and  2050  energy  and  climate  targets.  Union  financial instruments  and  other  measures  have  been  put  into  place  or  adapted  with  the  aim  of  supporting  the  energy performance of buildings. The most recent initiatives to increase the availability of financing at Union level include, inter  alia,  the  'Renovate'  flagship  component  of  the  Recovery  and  Resilience  Facility,  in  particular  the  REPowerEU plan, and the Social Climate Fund established by Regulation (EU) 2023/955 of the European Parliament and of the Council ( 22 ).
- (59) Union  financial  instruments  should  be  used  to  give  practical  effect  to  the  objectives  of  this  Directive,  without replacing national measures. In particular, due to the scale of the renovation effort needed, they should be used for providing  appropriate  and  innovative  means  of  financing  to  catalyse  investment  in  the  energy  performance  of buildings.  They could  play  an  important  role  in  the  development  of  national,  regional  and  local  energy  efficiency funds, instruments and mechanisms which deliver such financing possibilities to private property owners, to small and medium-sized enterprises (SMEs) and to energy efficiency service  companies.
- (60) Financial  mechanisms,  incentives and  the  mobilisation  of financial  institutions  for  energy  renovations in  buildings should play a central role in national building renovation plans and be actively promoted by Member States. Such measures should include encouraging energy-efficient mortgages for certified energy-efficient building renovations, promoting  investments  for  public  bodies  in  an  energy-efficient  building  stock,  for  example  by  public-private partnerships or energy performance contracts or reducing the perceived risk of the investments. Information about available  funding and financial  tools should be made available to the public in an easily accessible and transparent manner. Member States should encourage financial institutions to promote targeted financial  products, grants and subsidies  to  improve  the  energy  performance  of  buildings  housing  vulnerable  households,  as  well  as  to  owners  in

( 22 ) Regulation (EU) 2023/955 of the European Parliament and of the Council of 10 May 2023 establishing a Social Climate Fund and amending Regulation (EU) 2021/1060 (OJ L 130, 16.5.2023, p. 1).

worst-performing buildings with multiple residential building units and buildings in rural areas, and other groups for whom  access  to  financing  is  difficult.  The  Commission  should  adopt  a  voluntary  framework  to  help  financial institutions  target  and  increase  lending  volumes  in  accordance  with  the  Union's  decarbonisation  ambition  and relevant energy  targets.

- (61) Green  mortgages  and  green  loans  can  significantly  contribute  to  transforming  the  economy  and  reducing  carbon emissions.
- (62) Financing  alone  will  not  deliver  on  the  renovation  needs.  Together  with  financing,  setting  up  accessible  and transparent  advisory  tools  and  assistance  instruments  such  as  one-stop  shops  that  provide  integrated  energy renovation services or facilitators, as well as implementing other measures and initiatives such as those referred to in the  Commission's  Smart  Finance  for  Smart  Buildings  Initiative,  is  indispensable  to  provide  the  right  enabling framework  and  break  barriers  to  renovation.  One-stop  shops  should  provide  technical  assistance  and  be  easily available  to  all  those  involved  in  building  renovations,  including  homeowners  and  administrative,  financial  and economic actors, such as SMEs, including  microenterprises.
- (63) Inefficient buildings are often linked to energy poverty and social problems. Vulnerable households are particularly exposed  to  increasing  energy  prices  as  they  spend  a  larger  proportion  of  their  budget  on  energy  products.  By reducing  excessive  energy  bills,  building  renovation  can  lift  people  out  of  energy  poverty  and  can  also  prevent energy poverty. At the same time, building renovation does not come for free, and it is essential to ensure that the social  impact  of  the  costs  for  building  renovation,  in  particular  on  vulnerable  households,  is  kept  in  check.  The Renovation Wave strategy should leave no one behind and be seized as an opportunity to improve the situation of vulnerable  households,  and  a  fair  transition  towards  climate  neutrality  should  be  ensured.  Therefore,  financial incentives  and  other  policy  measures  should  as  a  priority  target  vulnerable  households,  people  affected  by  energy poverty and people living in social housing, and Member States should take measures to prevent evictions because of renovation,  such  as  caps  on  rent  increases.  Council  Recommendation  of  16  June  2022 ( 23 )  provides  a  common framework  and  shared  understanding  of  comprehensive  policies  and  investments  needed  for  ensuring  that  the transition  is  fair.
- (64) Microenterprises  represent  94 %  of  companies  active  in  the  building  sector.  Together  with  small  enterprises,  they amount to 70 % of employment in the construction sector. They supply essential services and jobs locally. However, as  microenterprises  typically  rely  on  fewer  than  10  employees,  they  have  limited  resources  to  comply  with regulatory  requirements  and  rules  attached  to  financial  support  programmes  schemes.  Energy  communities, citizen-led  initiatives  and  local  authorities  and  energy  agencies,  while  indispensable  for  delivering  the  Renovation Wave, face the same issues of  lower administrative, financial and organisational capacities. This should not hamper the  essential  role  of  such  entities  and  should  be  taken  into  account  in  the  development  of  support  and  training programmes,  with  sufficient  visibility  and  ease  of  access.  Member  States  may  actively  support  organisations  with lower  means  with  dedicated  technical,  financial  and  legal  assistance.
- (65) Energy performance certificates for buildings have been in use since 2002. However, the use of different scales and formats hinders the comparability between different national schemes. Greater comparability of energy performance certificates across the Union facilitates the use of such certificates by financial institutions, thereby steering financing towards buildings with better energy performance and building renovation. The EU Taxonomy relies on the use of energy  performance  certificates  and  accentuates  the  need  to  improve  their  comparability.  Introducing  a  common scale of energy performance classes and a common template should ensure sufficient comparability between energy performance certificates  across  the  Union.

( 23 ) Council Recommendation of 16 June 2022 on ensuring a fair transition towards climate neutrality (OJ C 243, 27.6.2022, p. 35).

- (66) A  number  of  Member  States  have  recently  modified  their  energy  performance  certification  schemes.  In  order  to avoid disruption,  those  Member  States  should  have  additional  time  to  adapt  their  schemes.
- (67) In  order  to  ensure  that  the  energy  performance  of  buildings  can  be  taken  into  account  by  prospective  buyers  or tenants  early  in  the  process,  buildings  or  building  units  which  are  offered  for  sale  or  rent  should  have  an  energy performance certificate, and the energy performance class and indicator should be stated in all advertisements. The prospective  buyer  or  tenant  of  a  building  or  building  unit  should,  in  the  energy  performance  certificate,  be  given correct  information  about  the  energy  performance  of  the  building  and  practical  advice  on  improving  such performance. The energy performance certificate should also provide information on its primary and final  energy consumption,  energy  needs,  renewable  energy  production,  greenhouse  gas  emissions,  life-cycle  GWP  if  available, and, as an option, its indoor environmental quality sensors or controls. The energy performance certificate should contain  recommendations for  the  improvement of  the  energy  performance  of  the  building.
- (68) The  monitoring  of  the  building  stock  is  facilitated  by  the  availability  of  data  collected  by  digital  tools,  thereby reducing administrative costs. Therefore, national  databases for  the energy performance of buildings should be set up,  and  the  information  contained  therein  should  be  transferred  to  the  EU  Building  Stock  Observatory.
- (69) Buildings  owned  or  occupied  by  public  bodies  should  set  an  example  by  showing  that  environmental  and  energy factors are taken into account. Those buildings should therefore be subject to energy certification on a regular basis. The  dissemination  to  the  public  of  information  on  the  energy  performance  of  buildings  should  be  enhanced  by clearly  displaying  those  energy  performance  certificates,  in  particular  in  buildings  which  are  occupied  by  public bodies  and  which  are  frequently  visited  by  the  public  and  certain  non-residential  buildings,  such  as  town  halls, schools,  shops  and  shopping  centres,  supermarkets,  restaurants,  theatres,  banks  and  hotels.
- (70) Recent  years  have  seen  a  rise  in  the  number  of  air-conditioning  systems  in  European  countries.  That  creates considerable  problems  at  peak  load  times,  increasing  the  cost  of  electricity  and  disrupting  the  energy  balance. Priority  should  be  given  to  strategies  which  enhance  the  thermal  performance  of  buildings  during  the  summer period.  To  that  end,  there  should  be  a  focus  on  measures  which  avoid  overheating,  such  as  shading  and  sufficient thermal  capacity  in  the  building  construction,  and  further  development  and  application  of  passive  cooling techniques, primarily those that improve indoor environmental quality, the micro-climate around buildings and the urban heat island  effect.
- (71) Regular  maintenance  and  inspection  of  heating  systems,  ventilation  systems  and  air-conditioning  systems  by qualified personnel contributes to maintaining their correct adjustment in accordance with the product specification and  in  that  way  ensures  optimal  performance  from  an  environmental,  safety  and  energy  point  of  view.  An independent assessment of the entire heating system, ventilation system and air-conditioning system should occur at regular intervals during its lifecycle in particular before its replacement or upgrading. Inspections should address the parts  of  the  systems  that  are  accessible  either  directly  or  indirectly  through  available  non-destructive  methods.  In order  to minimise the administrative burden on building owners and tenants, Member States should endeavour  to combine inspections  and  certifications  as  far  as  possible.  Where  a  ventilation  system  is  installed,  its  sizing  and  its capabilities to optimise its performance under  typical or average operating conditions relevant for  the specific and current  use  of  the  building  should  also  be  assessed.
- (72) Where the system to be inspected is based on fossil fuels,  the  inspection  should  include  a  basic  assessment  of  the feasibility  to  reduce  the  on-site  use  of  fossil  fuels,  for  example  by  integrating  renewable  energy,  changing  energy source, or replacing or adjusting the existing systems. In order to reduce the burden on users, that assessment should not  be  repeated  if  such  recommendations  are  already  documented,  in  the  context  of  an  energy  performance certificate, renovation  passports,  energy  audit,  recommendations  from  the  manufacturer  or  other  means  of providing advice in  an  equivalent official  document or  if  the  replacement  of  the  system  is  already  planned.
- (73) Some heating systems involve a high risk of carbon monoxide intoxication, depending on the type of heat generator (boiler,  heat  pump),  the  type  of  fuel  (coal,  oil,  biomass,  gas)  or  the  location  of  the  heat  generator  (such  as  within living  spaces  or  in  spaces  not  properly  ventilated).  Inspections  of  such  systems  provide  a  good  opportunity  for managing those risks.
- (74) A common approach  to  the  energy  performance  certification  of  buildings,  renovation  passports,  smart  readiness indicators and to the inspection of heating systems and air-conditioning systems, carried out by qualified or certified accredited  experts,  whose  independence  is  to  be  guaranteed  on  the  basis  of  objective  criteria,  will  contribute  to a  level  playing  field  as  regards  efforts  made  in  Member  States  related  to energy  savings  in  the  buildings  sector  and will  introduce  transparency  for  prospective  owners  or  users  with  regard  to  energy  performance  in  the  Union

property  market.  Experts  should  benefit  from  using  test  equipment  certified  in  accordance  with  EN  and  ISO standards.  In  order  to  ensure  the  quality  of  energy  performance  certificates,  renovation  passports,  smart  readiness indicators  and  of  the  inspection  of  heating  systems  and  air-conditioning  systems  throughout  the  Union,  an independent control  system should  be  established  in  each Member  State.

- (75) A  sufficient  number  of  reliable  professionals  competent  in  the  field  of  energy  renovation  should  be  available  to ensure  sufficient  capacity  to  carry  out  quality  renovation  works  at  the  required  scale.  Member  States  should therefore, where appropriate and feasible, put in place certification schemes for integrated renovation works, which require expertise in various building elements or systems such as building insulation, electricity and heating systems and  the  installation  of  solar technologies;  professionals  involved  may  include  designers,  general  contractors, specialist  contractors  and  installers.
- (76) Since  local  and  regional  authorities  are  critical  for  the  successful  implementation  of  this  Directive,  they  should  be consulted and involved, as and when appropriate in accordance with applicable national law, on planning issues, the development of programmes to provide information, training and awareness-raising, and on the implementation of this Directive at national or regional level. Such consultations may also serve to promote the provision of adequate guidance  to  local  planners  and  building  inspectors  to  carry  out  the  necessary  tasks.  Furthermore,  Member  States should  enable  and  encourage  architects,  planners  and  engineers  to  properly  consider  the  optimal  combination  of improvements in  energy  efficiency,  use  of  energy  from  renewable  sources  and  use  of  district  heating  and  cooling when planning, designing, building and renovating industrial or residential areas, including building modelling and simulation  technologies.
- (77) Installers and builders are critical for the successful implementation of this Directive. Therefore, an adequate number of installers and builders should, through training and other measures, have the appropriate level of competence for the  installation  and  integration  of  the  energy-efficient  and  renewable  energy  technology  required.
- (78) In order to further the aim of improving the energy performance of buildings, the power to adopt acts in accordance with Article 290 TFEU should be delegated to the Commission in respect of the adaptation to technical progress of certain  parts  of  the  general  framework  set  out  in  Annex  I,  in  respect  of  the  establishment  of  a  comparative methodology  framework  for  calculating  cost-optimal  levels  of  minimum  energy  performance  requirements,  in respect  of  setting  out  a  Union  framework  for  the  national  calculation  of  life-cycle  GWP  with  a  view  to  achieving climate  neutrality,  in  respect  of  a  Union  scheme  for  rating  the  smart  readiness  of  buildings  and  to  effectively encourage  financial  institutions  to  increase  volumes  provided  for  energy  performance  renovations  by  means  of a comprehensive portfolio framework for voluntary use by financial institutions. It is of particular importance that the Commission carry out appropriate consultations during its preparatory work, including at expert level, and that those consultations be conducted in accordance with the principles laid down in the Interinstitutional Agreement of 13 April 2016 on Better Law-Making ( 24 ). In particular, to ensure equal participation in the preparation of delegated acts, the European Parliament and the Council receive all documents at the same time as Member States' experts, and their  experts  systematically  have  access  to meetings  of  Commission  expert  groups  dealing  with  the  preparation  of delegated  acts.
- (79) In  order  to  ensure  an  effective  implementation  of  the  provisions  laid  down  in  this  Directive,  the  Commission supports Member States through various tools, such as the Technical Support Instrument established by Regulation (EU)  2021/240  of  the  European  Parliament  and  of  the  Council ( 25 )  providing  tailor-made  technical  expertise  to design and implement reforms, including those aimed at increasing the annual energy renovation rate of residential and non-residential buildings  by  2030 and to foster deep energy renovations. The technical support relates to, for example, strengthening of administrative capacity, supporting policy development and implementation, and sharing of  relevant  best  practices.
- (80) Since  the  objectives  of  this  Directive,  namely  improving  the  energy  performance  of  buildings  and  reducing  the greenhouse  gas  emissions  from  buildings,  cannot  be  sufficiently  achieved  by  the  Member  States,  due  to  the complexity  of  the  buildings  sector  and  the  inability  of  the  national  housing  markets  to  adequately  address  the challenges of energy efficiency, but can rather, by reason of the scale and the effects of the action, be better achieved

( 24 ) OJ L  123,  12.5.2016,  p.  1.

( 25 ) Regulation (EU) 2021/240 of  the European Parliament and of  the Council of 10 February 2021 establishing a Technical Support Instrument  (OJ  L  57,  18.2.2021,  p.  1).

- at Union level, the Union may adopt measures, in accordance with the principle of subsidiarity as set out in Article 5 of the Treaty on European Union. In accordance with the principle of proportionality as set out in that Article, this Directive  does  not  go  beyond  what  is  necessary  in  order  to  achieve  those  objectives.
- (81) The legal basis of this initiative empowers the Union to establish the measures necessary to achieve the objectives of the Union with regard to policy on energy. The proposal contributes to the Union's energy policy objectives outlined in Article 194(1) TFEU, in particular improving the energy performance of buildings and reducing their greenhouse gas  emissions,  which contributes  to  preserving  and  improving  the  environment.
- (82) In accordance with point 44 of the Interinstitutional Agreement on Better Law-Making, Member States should draw up, for  themselves and in the interest of  the Union, their own tables, illustrating, as far as possible, the correlation between this Directive and the transposition measures, and make them public. In accordance with the Joint Political Declaration  of  28  September  2011  of  Member  States  and  the  Commission  on  explanatory  documents,  Member States have undertaken to accompany, in justified cases, the notification of their transposition measures with one or more documents explaining the relationship between the components of a directive and the corresponding parts of national  transposition  instruments.  With  regard to this  Directive,  the  legislator  considers  the  transmission  of  such documents to be justified, in particular following the judgment of the Court of Justice of the European Union in Case C-543/17 ( 26 ).
- (83) The obligation to transpose this Directive into national law should be confined to those provisions which represent a substantive amendment as compared to the earlier Directive. The obligation to transpose the provisions which are unchanged arises under  the  earlier  Directive.
- (84) This Directive should be without prejudice to the obligations of the Member States relating to the time-limits for the transposition  into  national  law  and  the  dates  of  application  of  the  Directives  set  out  in  Part  B  of  Annex  VIII,

HAVE ADOPTED THIS DIRECTIVE:

## Article  1

## Subject matter

- 1. This  Directive  promotes the improvement of  the energy performance of buildings and the reduction of greenhouse gas  emissions  from  buildings  within  the  Union,  with  a view  to  achieving a  zero-emission  building  stock  by  2050,  taking into account the outdoor climatic conditions, the local conditions, the requirements for indoor environmental quality, and cost-effectiveness.
- 2. This  Directive  lays  down  requirements  as  regards:
- (a) the common general framework for a methodology for calculating the integrated energy performance of buildings and building  units;
- (b) the  application  of  minimum  energy  performance  requirements  to new  buildings  and  new  building  units;
- (c) the  application  of  minimum  energy  performance  requirements  to:
- (i) existing  buildings  and  existing  building  units  that  are  undergoing  major  renovation;
- (ii) building  elements  that  form  part  of  the  building  envelope  and  that  have  a  significant  impact  on  the  energy performance of  the  building  envelope  when  they are  retrofitted  or  replaced;
- (iii) technical  building  systems  where  they  are  installed,  replaced  or  upgraded;
- (d) the  application  of  minimum  energy  performance  standards  to  existing  buildings  and  existing  building  units,  in accordance with Articles  3  and  9;
- (e) the  calculation  and  disclosure  of  the  life-cycle  global  warming  potential  of  buildings;
- (f) solar  energy  in  buildings;
- ( 26 ) Judgment of the Court (Grand Chamber) of 8 July 2019, European Commission v Kingdom of Belgium , C-543/17, ECLI:EU:C:2019:573.

- (g) renovation passports;
- (h) national  building  renovation plans;
- (i) sustainable  mobility  infrastructure  in  and  adjacent  to  buildings;
- (j) smart  buildings;
- (k) energy  performance certification  of  buildings  or  building  units;
- (l) regular  inspection  of  heating  systems,  ventilation  systems  and  air-conditioning  systems  in  buildings;
- (m) independent control systems for energy performance certificates, renovation passports, smart readiness indicators and inspection  reports;
- (n) the  indoor  environmental  quality  performance  of  buildings.
- 3. The  requirements  laid  down  in  this  Directive  are  minimum  requirements  and  shall  not  prevent  any  Member  State from maintaining  or  introducing  more  stringent  measures,  provided  that  such  measures  are  compatible  with  Union  law. Those measures shall  be  notified  to  the  Commission.

## Article  2

## Definitions

For  the  purposes  of  this  Directive,  the  following  definitions  apply:

- (1) 'building'  means  a  roofed  construction  having walls,  for  which energy is  used  to condition  the indoor environment;
- (2) 'zero-emission  building'  means  a  building  with  a  very  high  energy  performance,  as  determined  in  accordance  with Annex I, requiring zero or a very low amount of energy, producing zero on-site carbon emissions from fossil fuels and producing zero  or  a very  low  amount of operational  greenhouse  gas emissions,  in  accordance  with  Article  11;
- (3) 'nearly zero-energy building' means a building with a very high energy performance, as determined in accordance with Annex I, which is no worse than the 2023 cost-optimal level reported by Member States pursuant to Article 6(2) and where the nearly zero or  very low amount of energy required is covered to a very significant extent by energy from renewable  sources,  including  energy  from  renewable  sources  produced  on-site  or  energy  from  renewable  sources produced nearby;
- (4) 'minimum energy performance standards' means rules that require existing buildings to meet an energy performance requirement as part of a wide renovation plan for a building stock or at a trigger point on the market such as sale, rent, donation or change of purpose within the cadastre or land registry, in a period of time or by a specific date, thereby triggering  the  renovation  of  existing  buildings;
- (5) 'public  bodies'  means  public  bodies  as  defined  in  Article  2,  point  (12),  of  Directive  (EU)  2023/1791;
- (6) 'technical building system' means technical equipment of a building or building unit for space heating, space cooling, ventilation, domestic  hot  water, built-in lighting, building  automation  and  control,  on-site  renewable energy generation  and  energy  storage,  or  a  combination  thereof,  including  those  systems  using  energy  from  renewable sources;
- (7) 'building automation and control system' means a system comprising all products, software and engineering services that  can  support  energy-efficient,  economical  and  safe  operation  of  technical  building  systems  through  automatic controls  and  by  facilitating  the  manual  management of  those  technical  building  systems;
- (8) 'energy  performance  of  a  building'  means  the  calculated  or  metered  amount  of  energy  needed  to  meet  the  energy demand  associated  with  a  typical  use  of  the  building,  which  includes  energy  used  for  heating,  cooling,  ventilation, domestic hot water and lighting;
- (9) 'primary energy' means energy from renewable and non-renewable sources which has not undergone any conversion or  transformation process;

- (10) 'metered'  means  measured  by  a  relevant  device,  such  as  an  energy  meter,  a  power  meter,  a  power  metering  and monitoring device,  or  an  electricity  meter;
- (11) 'non-renewable  primary  energy  factor'  means  an  indicator  that  is  calculated  by  dividing  the  primary  energy  from non-renewable sources for a given energy carrier, including the delivered energy and the calculated energy overheads of  delivery  to  the  points  of  use,  by  the  delivered  energy;
- (12) 'renewable primary energy factor' means an indicator that is calculated by dividing the primary energy from renewable sources  from  an  on-site,  nearby  or  distant  energy  source  that  is  delivered  via  a  given  energy  carrier,  including  the delivered  energy  and  the  calculated  energy overheads  of  delivery  to  the  points  of  use,  by  the  delivered  energy;
- (13) 'total  primary  energy  factor'  means  the  sum  of  renewable  and  non-renewable  primary  energy  factors  for  a  given energy carrier;
- (14) 'energy from renewable sources' means energy from renewable non-fossil sources, namely wind, solar (solar  thermal and solar  photovoltaic)  and  geothermal  energy, osmotic  energy, ambient energy, tide,  wave and  other ocean  energy, hydropower, biomass, landfill gas, sewage  treatment  plant  gas,  and  biogas;
- (15) 'building  envelope'  means  the  integrated  elements  of  a  building  which  separate  its  interior  from  the  outdoor environment;
- (16) 'building unit' means a section, floor or apartment within a building which is designed or altered to be used separately;
- (17) 'building  element'  means  a  technical  building  system  or  an  element  of  the  building  envelope;
- (18) 'residential  building  or  building  unit'  means  a  room  or  suite  of  rooms  in  a  permanent  building  or  a  structurally separated  part  of  a  building  which  is  designed  for  all-year  habitation  by one  private  household;
- (19) 'renovation passport' means a tailored roadmap for the deep renovation of a specific building in a maximum number of  steps  that  will  significantly  improve  its  energy  performance;
- (20) 'deep  renovation'  means  a  renovation  which  is  in  line  with  the  'energy  efficiency  first'  principle,  which  focuses  on essential  building  elements  and  which  transforms  a  building  or  building  unit:
- (a) before  1  January  2030,  into  a  nearly  zero-energy  building;
- (b) from 1 January 2030, into a zero-emission building;
- (21) 'staged  deep  renovation'  means  a  deep  renovation  carried  out  in  a  maximum  number  of  steps,  asset  out  in a  renovation passport;
- (22) 'major  renovation'  means  the  renovation  of  a  building  where:
- (a) the total cost of  the renovation relating to the building envelope or  the technical building systems is higher  than 25 % of  the  value  of  the  building,  excluding  the  value  of  the  land  upon  which  the  building  is  situated;  or
- (b) more than 25 % of  the surface  of  the  building  envelope  undergoes  renovation.
- Member States may choose to apply point (a) or (b);
- (23) 'operational  greenhouse  gas  emissions'  means  greenhouse  gas  emissions  associated  with  the  energy consumption  of the  technical  building  systems  during  the  use  and  operation  of  the  building;
- (24) 'whole-life-cycle  greenhouse  gas  emissions'  means  greenhouse  gas  emissions  that  occur  over  the  whole  life  cycle  of a  building,  including  the  production  and  transport  of  construction  products,  construction-site  activities,  the  use  of energy in the building and replacement of construction products, as well as demolition, transport and management of waste  materials  and  their  reuse,  recycling  and  final  disposal;

- (25) 'life-cycle  global  warming  potential'  or  'life-cycle  GWP'  means  an  indicator  which  quantifies  the  global  warming potential  contributions  of  a  building  along  its  full  life  cycle;
- (26) 'split  incentives'  means  split  incentives  as  defined  in  Article  2,  point  (54),  of  Directive  (EU)  2023/1791;
- (27) 'energy  poverty'  means  energy  poverty  as  defined  in  Article  2,  point  (52),  of  Directive  (EU)  2023/1791;
- (28) 'vulnerable households' means  households  in  energy  poverty  or  households, including lower middle-income households, that are particularly exposed to high energy costs and that lack the means to renovate the building that they occupy;
- (29) 'European  standard'  means  a  standard  adopted  by  the  European  Committee  for  Standardization,  the  European Committee  for  Electrotechnical  Standardization  or  the  European Telecommunications  Standards  Institute  and  made available  for  public  use;
- (30) 'energy performance certificate' means a certificate, recognised by a Member State or by a legal person designated by it, which indicates the energy performance of a building or building unit, calculated in accordance with a methodology adopted pursuant to Article 4;
- (31) 'cogeneration'  means  the  simultaneous  generation  in  one  process  of  thermal  energy  and  electrical  or  mechanical energy;
- (32) 'cost-optimal level' means the energy performance level which leads to the lowest cost during the estimated economic life  cycle,  where:
- (a) the  lowest  cost  is  determined  taking  into  account:
- (i) the  category  and  use  of  the  building  concerned;
- (ii) energy-related  investment  costs  on  the  basis  of official  forecasts;
- (iii) maintenance  and  operating  costs,  including  energy  costs  taking  into  account  the  cost  of  greenhouse  gas allowances;
- (iv) environmental and health externalities  of energy  use;
- (v) earnings  from  energy  produced  on-site,  where  applicable;
- (vi) waste  management costs, where applicable; and
- (b) the  estimated  economic  life  cycle  is  determined  by  each  Member  State  and  refers  to  the  remaining  estimated economic life cycle of a building where energy performance requirements are set for the building as a whole, or to the  estimated  economic  life  cycle  of  a  building  element  where  energy  performance  requirements  are  set  for building elements.

The cost-optimal level shall lie within the range of performance levels where the cost-benefit analysis calculated over the  estimated  economic  life  cycle  is  positive;

- (33) 'recharging point' means a recharging point as defined in Article 2, point (48), of Regulation (EU) 2023/1804 of the European Parliament and of  the Council ( 27 );
- (34) 'pre-cabling'  means  all  measures  that  are  necessary  to  enable  the  installation  of  recharging  points,  including  data transmission,  cables,  cable  routes  and,  where  necessary,  electricity  meters;
- (35) 'roofed  car  park'  means  a  roofed  construction,  with  at  least  three  car  parking  spaces,  that  does  not  use  energy  to condition  the  indoor  environment;
- (36) 'micro-isolated system' means any system with consumption less than 500 GWh in the year 2022, where there is no connection with other systems;
- ( 27 ) Regulation (EU) 2023/1804 of the European Parliament and of the Council of 13 September 2023 on the deployment of alternative fuels  infrastructure,  and  repealing  Directive  2014/94/EU  (OJ  L  234,  22.9.2023,  p.  1).

- (37) 'smart recharging' means smart recharging as defined in Article 2, second paragraph, point (14m), of Directive (EU) 2018/2001 of  the European Parliament and of  the  Council ( 28 );
- (38) 'bi-directional  recharging'  means  bi-directional  recharging  as  defined  in  Article  2,  point  (11),  of  Regulation  (EU) 2023/1804;
- (39) 'mortgage portfolio standards' means  mechanisms incentivising  mortgage lenders to establish a path to increase the median energy performance of the portfolio of buildings covered by their mortgages towards 2030 and 2050, and to encourage  potential clients to improve  the  energy performance  of their property  in line with the Union's decarbonisation ambition and relevant energy targets in the area of energy consumption in buildings, relying on the criteria  for  determining  environmentally  sustainable  economic  activities  set  out  in  Article  3  of  Regulation  (EU) 2020/852;
- (40) 'pay-as-you-save financial  scheme' means a loan  scheme dedicated exclusively to energy  performance improvements where a correlation is established in the designing of the scheme between the repayments on the loan and the achieved energy  savings,  also  taking  into  account  other  economic  factors  such  as  the  indexation  of  the  energy  cost,  interest rates,  increased  asset  value  and  loan  re-financing;
- (41) 'digital  building logbook' means a common repository for all relevant building data, including data related to energy performance such as energy performance certificates, renovation passports and smart readiness indicators, as well as data  related  to  the  life-cycle  GWP,  which  facilitates  informed  decision  making  and  information  sharing  within  the construction  sector,  and  among  building  owners  and  occupants,  financial  institutions  and  public  bodies;
- (42) 'air-conditioning system' means a combination of the components required to provide a form of indoor air treatment, by  which temperature is  controlled  or  can  be  lowered;
- (43) 'heating system' means a combination of the components required to provide a form of indoor air treatment, by which the  temperature  is  increased;
- (44) 'ventilation  system'  means  the  technical  building  system  which  provides  outdoor  air  to  a  space  by  natural  or mechanical means;
- (45) 'heat generator' means the part of a heating system that generates useful heat for uses identified in Annex I, using one or  more  of  the  following  processes:
- (a) the  combustion  of  fuels  in,  for  example,  a  boiler;
- (b) the  Joule  effect,  taking  place  in  the  heating  elements  of  an  electric  resistance  heating  system;
- (c) capturing  heat  from  ambient  air,  ventilation  exhaust  air,  or  a  water  or  ground  heat  source  using  a  heat  pump;
- (46) 'cooling  generator'  means  the  part  of  an  air-conditioning  system  that  generates  useful  cooling  for  uses  identified  in Annex I;
- (47) 'energy  performance  contracting'  means  energy  performance  contracting  as  defined  in  Article  2,  point  (33),  of Directive  (EU)  2023/1791;
- (48) 'boiler'  means  the  combined  boiler  body-burner  unit,  designed  to transmit  to fluids  the  heat  released  from  burning;
- (49) 'effective  rated  output'  means  the  maximum  calorific  output,  expressed  in  kW,  specified  and  guaranteed  by  the manufacturer as being deliverable during continuous operation while complying with the useful efficiency indicated by  the  manufacturer;
- (50) 'district heating' or 'district cooling' means the distribution of thermal energy in the form of steam, hot water or chilled liquids, from a central or decentralised source of production through a network to multiple buildings or sites, for the use  of  space  or  process  heating  or  cooling;
- (51) 'useful floor area' means the area of the floor of a building needed as parameter to quantify specific conditions of use that are expressed per unit of floor area and for the application of the simplifications and the zoning and allocation or re-allocation  rules;
- ( 28 ) Directive (EU) 2018/2001 of  the European Parliament and of  the Council of 11 December 2018 on the promotion of  the use of energy from renewable sources (OJ L  328, 21.12.2018, p. 82).

- (52) 'reference  floor  area'  means  the  floor  area  used  as  reference  size  for  the  assessment  of  the  energy  performance  of a building, calculated as the sum of the useful floor areas of the spaces within the building envelope specified for the energy performance assessment;
- (53) 'assessment  boundary'  means  the  boundary  where  the  delivered  energy  and  exported  energy  are  measured  or calculated;
- (54) 'on-site'  means  in  or  on  a  particular  building  or  on  the  land  on  which  that  building  is  located;
- (55) 'energy from renewable sources produced nearby' means energy from renewable sources, produced within a local or district-level  perimeter  of  a  particular  building,  which  fulfils  all  of  the  following  conditions:
- (a) it  can  be  distributed  and  used  only within that local and district-level perimeter  through a dedicated distribution network;
- (b) it  allows  for  the  calculation of a specific  primary energy factor  valid only for  the energy from renewable sources produced within that local  or  district-level  perimeter;  and
- (c) it  can  be  used  on-site  through  a  dedicated  connection  to  the  energy  production  source,  where  that  dedicated connection requires  specific  equipment  for  the  safe  supply  and  metering  of  energy  for  self-use  of  the  building;
- (56) 'services related to the energy performance of buildings' or 'EPB services' means the services, such as heating, cooling, ventilation,  domestic  hot  water  and  lighting  and  others  for  which  the  energy  use  is  taken  into  account  in  the calculation  of  the  energy  performance  of  buildings;
- (57) 'energy needs' means the energy to be delivered to, or extracted from, a conditioned space to maintain the intended space  conditions  during  a  given  period  of  time,  disregarding  any  technical  building  system  inefficiencies;
- (58) 'energy  use'  or  'energy  consumption'  means  energy  input  to  a  technical  building  system  providing  an  EPB  service intended  to  satisfy  an  energy  need;
- (59) 'self-use'  means  the  use  of  energy  from  renewable  sources  produced  on-site  or  energy  from  renewable  sources produced nearby by on-site technical systems for EPB services;
- (60) 'other on-site uses' means on-site uses other than EPB services, including appliances, miscellaneous and ancillary loads, or  electro-mobility  recharging  points;
- (61) 'calculation  interval'  means  the  discrete  time  interval  used  for  the  calculation  of  the  energy  performance;
- (62) 'delivered energy' means energy, expressed per energy carrier, supplied to the technical building systems through the assessment boundary, to satisfy  the  uses  taken  into  account  or  to  produce  the  exported  energy;
- (63) 'exported energy' means the proportion of the renewable energy, expressed per energy carrier and per primary energy factor,  that  is  exported  to  the  energy  grid  instead  of  being  used  on-site  for  self-use  or  for  other  on-site  uses;
- (64) 'bicycle  parking  space'  means  a  designated  space  for  parking  at  least  one  bicycle;
- (65) 'car  park  physically  adjacent  to  a  building'  means  a  car  park  which  is  intended  for  the  use  of  residents,  visitors  or workers of a building and which is located within the property area of the building or is in the direct vicinity of  the building;
- (66) 'indoor environmental quality' means the result of an assessment of the conditions inside a building that influence the health  and  wellbeing  of  its  occupants,  based  upon  parameters  such  as  those  relating  to  the  temperature,  humidity, ventilation  rate  and  presence  of  contaminants.

## Article  3

## National building  renovation plan

- 1. Each Member State shall establish a national building renovation plan to ensure the renovation of the national stock of  residential  and  non-residential  buildings,  both  public  and  private,  into  a  highly  energy-efficient  and  decarbonised building  stock  by  2050,  with  the  objective  to  transform  existing  buildings  into  zero-emission  buildings.
- 2. Each national  building  renovation plan  shall  include:
- (a) an  overview  of  the  national  building  stock  for  different  building  types,  including  their  share  in  the  national  building stock, construction periods and climatic zones, based, as appropriate, on statistical sampling and the national database for energy performance certificates pursuant to Article 22, an overview of market barriers and market failures and an overview  of  the  capacities  in  the  construction,  energy  efficiency  and  renewable  energy  sectors,  and  of  the  share  of vulnerable  households  based,  as  appropriate,  on  statistical  sampling;
- (b) a  roadmap  with  nationally  established  targets  and  measurable  progress  indicators,  including  the  reduction  of  the number of people affected  by energy  poverty,  with  a  view  to  achieving  the  2050  climate  neutrality  goal,  in  order  to ensure a highly energy-efficient and decarbonised national building stock and the transformation of existing buildings into  zero-emission  buildings  by  2050;
- (c) an  overview  of  implemented  and  planned  policies  and  measures,  supporting  the  implementation  of  the  roadmap pursuant to point (b);
- (d) an  outline  of  the  investment  needs  for  the  implementation  of  the  national  building  renovation  plan,  the  financing sources  and  measures,  and  the  administrative  resources  for  building  renovation;
- (e) the thresholds for the operational greenhouse gas emissions and annual primary energy demand of a new or renovated zero-emission building  pursuant  to Article  11;
- (f) minimum energy performance standards for  non-residential buildings  on the basis  of maximum energy  performance thresholds  pursuant  to Article  9(1);
- (g) national  trajectory  for  the  renovation  of  the  residential  building  stock,  including  the  2030  and  2035  milestones  for average primary energy  use in  kWh/(m .y)  pursuant  to Article  9(2);  and 2
- (h) an evidence-based  estimate of expected  energy  savings and  wider  benefits, including those related to indoor environmental quality.

The roadmap referred to in point (b) of this paragraph shall include national targets for 2030, 2040 and 2050 as regards the  annual  energy  renovation  rate,  the  primary  and  final  energy  consumption  of  the  national  building  stock  and  its operational  greenhouse  gas  emission  reductions;  specific  timelines  for  non-residential  buildings  to  comply  with  lower maximum  energy  performance  thresholds  pursuant  to  Article  9(1),  by  2040  and  2050,  in  line  with  the  pathway  for transforming the national building stock into zero-emission buildings; and an evidence-based estimate of expected energy savings  and  wider  benefits,  including  those  related  to  indoor  environmental  quality.

Where an overview of specific policies and measures as referred to in point (c) or an outline of specific investment needs as referred to in point (d) is already included in the national energy and climate plans, a clear reference to the relevant parts of the  national  energy  and  climate  plans  may  be  included  in  the  building  renovation  plan  in  place  of  a  fully  developed overview.

- 3. Every five years, each Member State shall prepare and submit to the Commission its draft national building renovation plan,  using  the  template  set  out  in  Annex  II  to  this  Directive.  Each  Member  State  shall  submit  its  draft  national  building renovation plan as part of its draft integrated national energy and climate plan referred to in Article 9 of Regulation (EU) 2018/1999 and, where the Member States submits a draft update, as part of  the draft update referred to in Article 14 of that  Regulation.

Notwithstanding  the  first  subparagraph,  Member  States  shall  submit  the  first  draft  building  renovation  plan  to  the Commission by 31 December 2025.

- 4. To  support  the  development  of  its  national  building  renovation  plan,  each  Member  State  shall  carry  out  a  public consultation  on  its  draft  national  building  renovation  plan  prior  to  submitting  it  to  the  Commission.  The  public consultation  shall  involve  in  particular  local  and  regional  authorities  and  other  socioeconomic  partners,  including  civil society  and  bodies  working  with  vulnerable  households.  Each  Member  State  shall  annex  a  summary  of  the  results  of  its public consultation to its draft national building renovation plan. The public consultation may be integrated as part of the public  consultation  undertaken  pursuant  to  Article  10  of  Regulation  (EU)  2018/1999.
- 5. The  Commission  shall  assess  the  draft  national  building  renovation  plans  submitted  pursuant  to  paragraph  3,  in particular  with  regard  to whether:
- (a) the  level  of  ambition  of  the  nationally  established  targets  is  sufficient  and  in  line  with  the  national  commitments  on climate and  energy  laid  down in  the  national  integrated  energy  and  climate  plans;
- (b) the  policies  and  measures  are  sufficient  to  achieve  the  nationally  established  targets;
- (c) the  allocation  of  budgetary  and  administrative  resources  is  sufficient  for  the  implementation  of  the  plan;
- (d) the financing sources and measures referred to in paragraph 2, first subparagraph, point (d), of  this Article are in line with the planned reduction of energy poverty referred to in paragraph 2, first subparagraph, point (b), of  this Article;
- (e) the  plans  prioritise  the  renovation  of  worst-performing  buildings  in  accordance  with  Article  9;
- (f) the  public  consultation  pursuant  to  paragraph  4  has  been  sufficiently  inclusive;  and
- (g) the  plans  comply  with  the  requirements  of  paragraph  1  and  the  template  in  Annex  II.

After  consulting  the  Committee  established  by  Article  33  of  this  Directive,  the  Commission  may  issue  country-specific recommendations to Member States in accordance with Article 9(2) and Article 34 of Regulation (EU) 2018/1999.

With regard to the first draft national building renovation plan, the Commission may issue country-specific recommendations to Member States no later  than six months after  the Member State has submitted that  plan.

- 6. In its national building renovation plan, each Member State shall take due account of any recommendations issued by the  Commission  on  the  draft  national  building  renovation  plan.  If  the  Member  State  concerned  does  not  address a recommendation or a substantial part thereof, it shall provide reasons to the Commission and shall make those reasons public.
- 7. Every five years, each Member State shall submit its national building renovation plan to the Commission, using the template set out in Annex II to this Directive. Each Member State shall submit its national building renovation plan as part of  its  integrated  national  energy  and  climate  plan  referred  to  in  Article  3  of  Regulation  (EU)  2018/1999  and,  where a  Member State submits  an  update,  as  part  of  the  update  referred  to  in  Article  14  of  that  Regulation.

Notwithstanding  the  first  subparagraph,  Member  States  shall  submit  the  first  national  building  renovation  plan  to  the Commission by 31 December 2026.

- 8. Each Member State shall annex the details of the implementation of its most recent long-term renovation strategy or national building renovation plan to its next national building renovation plan, indicating whether its national targets have been  achieved.
- 9. Each  Member  State  shall  include  in  its  integrated  national  energy  and  climate  progress  reports,  in  accordance  with Articles 17 and 21 of Regulation (EU) 2018/1999, information on the implementation of the national targets referred to in paragraph 2, point (b), of this Article. Every two years, the Commission shall include in its annual State of the Energy Union report submitted pursuant to Article 35 of Regulation (EU) 2018/1999, an overall progress report on the renovation of the national stock of residential and non-residential buildings, both public and private, in line with the roadmaps set out in the building renovation plans, based upon the information submitted by the Member States in their integrated national energy and  climate  progress  reports.  The  Commission  shall  monitor  annually  the  evolution  of  the  energy  performance  of  the Union  building  stock,  on  the  basis  of  best  available  information  from  Eurostat  and  other  sources,  and  publish  the information through the EU Building Stock Observatory.

## Article  4

## Adoption of a methodology for calculating the energy performance of buildings

Member  States  shall  apply  a  methodology  for  calculating  the  energy  performance  of  buildings  in  accordance  with  the common general framework set out in Annex I. That methodology shall be adopted at national or  regional level.

The Commission shall issue guidance for  the calculation of the energy performance of transparent building elements that form part of  the  building envelope and  the  consideration  of ambient energy.

## Article  5

## Setting  of  minimum energy performance requirements

- 1. Member  States  shall  take  the  necessary  measures  to  ensure  that  minimum  energy  performance  requirements  for buildings or building units are set with a view to at least achieving cost-optimal levels and, where relevant, more stringent reference  values  such  as  nearly  zero-energy  building  requirements  and  zero-emission  buildings  requirements.  The  energy performance shall be calculated in accordance with the methodology referred to in Article 4. Cost-optimal levels shall be calculated  in  accordance  with  the  comparative  methodology  framework  referred  to  in  Article  6.

Member  States  shall  take  the  necessary  measures  to  ensure  that  minimum  energy  performance  requirements  are  set  for building elements that form part of the building envelope and that have a significant impact on the energy performance of the building envelope when they are replaced or retrofitted, with a view to achieving at least cost-optimal levels. Member States  may  set  the  requirements  for  building  elements  at  a  level  that  would  facilitate  the  effective  installation  of  low temperature heating  systems  in  renovated  buildings.

When  setting  requirements,  Member  States  may  differentiate  between  new  and  existing  buildings  and  between  different categories  of  building.

Those requirements shall take account of optimal indoor environmental quality, in order to avoid possible negative effects such  as  inadequate  ventilation,  as  well  as  local  conditions  and  the  designated  function  and  the  age  of  the  building.

Member States shall review their minimum energy performance requirements at regular intervals which shall not be longer than five years and shall, if necessary, update them in order to reflect technical progress in the building sector, the results of the  cost-optimal  calculation  set  out  in  Article  6,  and  updated  national  energy  and  climate  targets  and  policies.

- 2. Member States  may  adapt  the  requirements  referred  to  in  paragraph  1  to  buildings  officially  protected  at  national, regional or local level, as part of a designated environment or because of their special architectural or historical merit, in so far  as  compliance  with  certain  requirements  would  unacceptably  alter  their  character  or  appearance.
- 3. Member States may decide not to set or apply the requirements referred to in paragraph 1 to the following categories of  building:
- (a) buildings owned by the armed forces or central government and serving national defence purposes, apart from single living  quarters  or  office  buildings  for  the  armed  forces  and  other  staff  employed  by  national  defence  authorities;
- (b) buildings  used  as  places  of  worship  and  for  religious  activities;
- (c) temporary buildings with a time of use of two years or less, industrial sites, workshops and non-residential agricultural buildings  with  low  energy  demand  and  non-residential  agricultural  buildings  which  are  used  by  a  sector  covered  by a  national  sectoral  agreement  on  energy  performance;
- (d) residential buildings which are used or intended to be used for either less than four months of the year or, alternatively, for a limited annual time of use and with an expected energy consumption of less than 25 % of what would be the result of  all-year  use;

- (e) stand-alone  buildings  with  a  total  useful  floor  area  of  less  than  50  m . 2

## Article  6

## Calculation of cost-optimal  levels  of minimum energy performance requirements

- 1. The Commission is empowered to adopt delegated acts in accordance with Article 32 to supplement this Directive concerning the establishment and revision of a comparative methodology framework for calculating cost-optimal levels of minimum energy performance requirements for buildings and building elements.

By 30 June 2025, the Commission shall revise the comparative methodology framework for calculating cost-optimal levels of minimum energy performance requirements in new buildings and existing buildings undergoing major renovation and for individual building elements. Those levels shall be in line with the national pathways set out in the national energy and climate plans  submitted  to  the  Commission pursuant  to Article  14  of  Regulation  (EU)  2018/1999.

The comparative methodology framework shall be laid down in accordance with Annex VII and shall differentiate between new and existing  buildings  and  between  different  categories  of  building.

- 2. Member  States shall calculate cost-optimal levels of minimum  energy  performance  requirements  using  the comparative methodology framework established in accordance with paragraph 1 and relevant parameters, such as climatic conditions  and  the  practical  accessibility  of  energy  infrastructure,  and  compare  the  results  of  that  calculation  with  the minimum  energy  performance  requirements  in  force.  When  calculating  the  cost-optimal  levels  of  minimum  energy performance requirements, Member States may take into account the life-cycle  GWP.

Member States  shall  report  to  the  Commission  all  input  data  and  assumptions  used  for  the  calculations  of  cost-optimal levels of minimum energy performance requirements and the results of those calculations. To that end Member States shall use the template provided in Annex III to the Commission Delegated Regulation (EU) No 244/2012 ( 29 ). Member States shall update and submit those reports to the Commission at regular intervals, which shall not be longer than five years. The first report on the calculations on the basis of the revised methodology framework pursuant to paragraph 1 of this Article shall be  submitted  by  30  June  2028.

- 3. If the  result  of  the  comparison  performed  in  accordance  with  paragraph  2  shows  that  the  minimum  energy performance requirements in force in a Member State are less energy-efficient than cost-optimal levels of minimum energy performance requirements by more than 15 %, the Member State concerned shall adjust the minimum energy performance requirements  in place  within  24  months  of  the  availability of  the  results  of  that  comparison.
- 4. The  Commission  shall  publish  a  report  on  the  progress  of  the  Member  States  in  reaching  cost-optimal  levels  of minimum energy performance requirements.

## Article  7

## New buildings

- 1. Member States shall ensure  that  new  buildings  are  zero-emission  buildings  in  accordance  with  Article  11:
- (a) from 1 January 2028, new buildings owned by public bodies; and
- (b) from 1 January 2030, all  new buildings;

Until the application of  the requirements under  the first  subparagraph, Member States shall ensure that all new buildings are at least nearly zero-energy buildings and meet the minimum energy performance requirements laid down in accordance with Article 5. Where public bodies intend to occupy a new building that they do not own, they shall aim for that building to  be  a  zero-emission  building.

( 29 ) Commission Delegated Regulation (EU) No 244/2012 of 16 January 2012 supplementing Directive 2010/31/EU of the European Parliament and of the Council on the energy performance of buildings by establishing a comparative methodology framework for calculating  cost-optimal  levels  of  minimum  energy  performance  requirements  for  buildings  and  building  elements  (OJ  L  81, 21.3.2012, p.  18).

- 2. Member States shall  ensure  that  the  life-cycle  GWP  is  calculated  in  accordance  with  Annex  III  and  disclosed  in  the energy  performance certificate  of  the  building:
- (a) from 1 January 2028, for all  new  buildings  with  a  useful  floor  area  larger  than  1 000  m ; 2
- (b) from 1 January 2030, for all  new  buildings.
- 3. The Commission is empowered to adopt delegated acts in accordance with Article 32 to amend Annex III to set out a Union framework for the national calculation of life-cycle GWP with a view to achieving climate neutrality. The first such delegated  act  shall  be  adopted  by  31  December  2025.
- 4. Member States may decide not to apply paragraphs 1 and 2 to buildings for  which building permit applications or equivalent applications, including for change of use, have already been submitted by the dates pursuant to paragraphs 1 and 2.
- 5. By 1 January 2027, Member States shall publish and notify to the Commission a roadmap detailing the introduction of  limit  values  on  the  total  cumulative  life-cycle  GWP of  all  new  buildings  and  set  targets  for  new  buildings  from  2030, considering  a  progressive  downward  trend,  as  well  as  maximum  limit  values,  detailed  for  different  climatic  zones  and building  typologies.

Those maximum limit values shall be in line with the Union's objective  of achieving  climate neutrality.

The Commission shall issue guidance, share evidence on existing national policies and offer  technical support to Member States,  at  their  request.

- 6. Member  States  shall  address,  in  relation  to  new  buildings,  the  issues  of  optimal  indoor  environmental  quality, adaptation  to  climate  change,  fire  safety,  risks  related  to  intense  seismic  activity  and  accessibility  for  persons  with disabilities.  Member  States  shall  also  address  carbon  removals  associated  to  carbon  storage  in  or  on  buildings.

## Article  8

## Existing  buildings

- 1. Member States shall take the necessary measures to ensure that, when buildings undergo major renovation, the energy performance  of  the  building  or  the  renovated  part  thereof  is  upgraded  in  order  to  meet  minimum  energy  performance requirements  set  in  accordance  with  Article  5  in  so  far  as  technically,  functionally  and  economically  feasible.

Those  requirements  shall  be  applied  to  the  renovated  building  or  building  unit  as  a  whole.  Additionally  or  alternatively, requirements  may be applied to the  renovated building elements.

- 2. Member States shall in addition take the necessary measures to ensure that, when a building element that forms part of  the building envelope and has a significant impact on the energy performance of the building envelope is retrofitted or replaced, the  energy  performance of  the building element meets minimum energy performance requirements in so far as technically,  functionally  and  economically  feasible.
- 3. Member  States  shall,  in  relation  to  buildings  undergoing  major  renovation,  encourage  high-efficiency  alternative systems, in so far as technically, functionally and economically feasible. Member States shall address, in relation to buildings undergoing  major  renovation,  the  issues  of  indoor  environmental  quality,  adaptation  to  climate  change,  fire  safety,  risks related to intense seismic activity, the removal of hazardous substances including asbestos and accessibility for persons with disabilities.

## Article  9

## Minimum energy performance standards for non-residential buildings and trajectories for progressive renovation of  the  residential  building  stock

- 1. Member  States  shall  establish  minimum  energy  performance  standards  for  non-residential  buildings  which  ensure that  those  buildings  do  not  exceed  the  specified  maximum  energy  performance  threshold,  as  referred  to  in  the  third subparagraph, expressed by a numeric indicator of primary or final energy use in kWh/(m .y), by the dates specified in the 2 fifth  subparagraph.

The  maximum  energy  performance  thresholds  shall  be  established  on  the  basis  of  the  non-residential  building  stock  on 1  January  2020,  based  on  available  information  and,  where  appropriate,  on  statistical  sampling.  Member  States  shall exclude  from  the  baseline  non-residential  buildings  that  they exempt  pursuant  to  paragraph  6.

Each Member State shall set a maximum energy performance threshold to the effect that 16 % of its national non-residential building  stock  is  above  that  threshold  (the  '16 %  threshold').  Each  Member  State  shall  also  set  a  maximum  energy performance  threshold  to  the  effect  that  26 %  of  its  national  non-residential  building  stock  is  above  that  threshold  (the '26 %  threshold').  Member  States  may  set  the  maximum  energy  performance  thresholds  with  reference  to  the  national non-residential  building  stock  as  a  whole  or  per  building  type  or  category of  building.

Member States may set the thresholds at a level corresponding to a specific energy performance class, provided that they comply with the third subparagraph.

The minimum energy performance standards shall ensure, at least, that  all non-residential  buildings  are  below:

- (a) the  16 %  threshold  from  2030;  and
- (b) the  26 %  threshold  from  2033.

Compliance of individual non-residential buildings with the thresholds shall be checked on the basis of energy performance certificates  or,  where  appropriate,  other  available  means.

In their roadmaps as referred to in Article 3(1), point (b), Member States shall establish specific timelines for non-residential buildings to comply with lower maximum energy performance thresholds by 2040 and 2050, in line with the pathway for transforming  the  national  building  stock  into  zero-emission  buildings.

Member States may establish  and  publish  criteria  to  exempt  individual  non-residential  buildings,  in  light  of  the  expected future use of  those buildings, in light of serious hardship or  in the case of an unfavourable cost-benefit assessment, from requirements  in  this  paragraph.  Any  such  criteria  shall  be  clear,  precise  and  stringent  and  shall  ensure  equal  treatment between non-residential buildings. When establishing those criteria Member States shall enable the ex ante assessment of the potential share of non-residential buildings covered and shall avoid a disproportionate number of non-residential buildings from  being  exempted.  Member  States  shall  also  report  on  the  criteria  as  part  of  their  national  building  renovation  plans submitted to  the  Commission pursuant to Article  3.

Where Member States establish criteria for exemptions pursuant to the eighth subparagraph, they shall achieve equivalent energy  performance improvements in other  parts of  the non-residential  building  stock.

Where the overall  renovation  necessary  to  achieve  the  energy  performance  thresholds  specified  in  this  paragraph  has  an unfavourable cost-benefit assessment for a given non-residential building, Member States shall require that, for  that given non-residential  building,  at  least  those  individual  renovation  measures  with  a  favourable  cost-benefit  assessment  are implemented.

To  the  extent  that  the  national  non-residential  building  stock,  or  part  of  it,  is  seriously  damaged  by  a  natural  disaster, a  Member  State  may  temporarily  adjust  the  maximum  energy  performance  threshold  so  that  the  energy  renovation  of damaged  non-residential  buildings  replaces  the  energy  renovation  of  other  worst-performing  non-residential  buildings, whilst ensuring that a similar percentage of the non-residential building stock undergoes energy renovation. In that case, the Member State shall report  the  adjustment  and  its  projected  length  in  its  national  building  renovation  plan.

- 2. By  29  May  2026,  each  Member  State  shall  establish  a  national  trajectory  for  the  progressive  renovation  of  the residential building stock in line with the national roadmap and the 2030, 2040 and 2050 targets contained in the Member State's national building renovation plan and with the aim of transforming the national building stock into a zero-emission building  stock  by  2050.  The  national  trajectory  for  the  progressive  renovation  of  the  residential  building  stock  shall  be expressed  as  a  decrease  in  the  average  primary  energy  use  in  kWh/(m .y)  of  the  entire  residential  building  stock over  the 2 period from 2020 to 2050, and shall identify the number of residential buildings and residential building units or floor area to  be  renovated  annually,  including  the  number  or  floor  area  of  the  43 %  worst-performing  residential  buildings  and residential  building  units.

Member States shall  ensure  that  the  average  primary  energy  use  in  kWh/(m .y)  of  the  entire  residential  building  stock: 2

- (a) decreases  by  at  least  16 %  compared  to  2020  by  2030;
- (b) decreases  by  at  least  20-22 %  compared  to  2020  by  2035;
- (c) by  2040,  and  every  5  years  thereafter,  is  equivalent  to,  or  lower  than  the  nationally  determined  value  derived  from a  progressive  decrease  in  the  average  primary  energy  use  from  2030  to  2050,  in  line  with  the  transformation  of  the residential  building  stock  into  a  zero-emission  building  stock.

Member States  shall  ensure  that  at  least  55 %  of  the  decrease  in  the  average  primary  energy  use  referred  to  in  the  third subparagraph is achieved through the renovation of the 43 % worst-performing residential buildings. Member States may count the decrease in the average primary energy use achieved by the renovation of residential buildings affected by natural disasters such  as earthquakes  and  floods towards  the share achieved by means  of the renovation of the 43 % worst-performing residential  buildings.

In  their  renovation  efforts  to  achieve  the  required  decrease  in  the  average  primary  energy  use  of  the  entire  residential building  stock,  Member  States  shall  put  in  place  measures  such  as  minimum  energy  performance  standards,  technical assistance  and  financial  support  measures.

In their renovation efforts, Member States shall not disproportionately exempt rental residential buildings or building units.

Member  States  shall  report  in  the  national  building  renovation  plans  the  methodology  used  and  data  gathered  for estimating  the  values  referred  to  in  the  second  and  third  subparagraphs.  As  part  of  the  assessment  of  national  building renovation  plans,  the  Commission  shall  monitor  the  achievement  of  the  values  referred  to  in  the  second  and  third subparagraphs, including the number of buildings and building units or floor area of the 43 % worst-performing residential buildings,  and  make  recommendations  where  necessary.  Those  recommendations  may  include  a  more  extensive  use  of minimum energy performance standards.

The national trajectory  for  the  progressive  renovation  of  the  residential  building  stock  shall  refer  to  data  on  the  national residential  building  stock,  based,  as  appropriate,  on  statistical  sampling  and  energy  performance  certificates.

If  the average fossil share of energy use in residential buildings is lower than 15 %, Member States may adjust the levels laid down in the points (a) and (b) of the third subparagraph, to ensure that the average primary energy use in kWh/(m .y) of the 2 entire  residential  building  stock  by  2030,  and  every  five  years  thereafter,  is  equivalent  to,  or  lower  than  a  nationally determined  value  derived  from  a  linear  decrease  in  the  average  primary  energy  use  from  2020  to  2050,  in  line  with  the transformation  of  the  residential  building  stock  into  a  zero-emission  building  stock.

- 3. In  addition  to  primary  energy  use  referred  to  in  paragraphs  1  and  2  of  this  Article,  Member  States  may  establish additional  indicators  of  non-renewable  and  renewable  primary  energy  use,  and  of  operational  greenhouse  gas  emissions produced  in  kgCO eq/(m 2 2 .y).  In  order  to  ensure  reduction  of  operational  greenhouse  gas  emissions,  minimum  energy performance standards shall take into account Article  15a(1)  of  Directive  (EU)  2018/2001.
- 4. In accordance  with  Article  17,  Member  States  shall  support  compliance  with  minimum  energy  performance standards  by  all  of  the  following  measures:
- (a) providing appropriate financial measures, in particular those targeting vulnerable households, people affected by energy poverty or,  where  applicable,  living  in  social  housing,  in  accordance  with  Article  24  of  Directive  (EU)  2023/1791;
- (b) providing technical assistance, including through one-stop shops with a particular focus on vulnerable households and, where applicable,  people  living  in  social  housing,  in  accordance  with  Article  24  of  Directive  (EU)  2023/1791;
- (c) designing  integrated  financing  schemes  which  provide  incentives  for  deep  renovations  and  staged  deep  renovations, pursuant to Article  17;

- (d) removing non-economic barriers, including split  incentives;  and
- (e) monitoring  social  impacts,  in  particular  on  the  most  vulnerable  households.
- 5. Where a building is renovated in order to comply with a minimum energy performance standard, Member States shall ensure compliance with the minimum energy performance requirements for building elements pursuant to Article 5 and, in the  case  of  major  renovation,  with  the  minimum  energy  performance  requirements  for  existing  buildings  pursuant  to Article  8.
- 6. Member States may decide not to apply the minimum energy performance standards referred to in paragraphs 1 and 2  to  the  following  categories  of  building:
- (a) buildings officially protected as part of a designated environment or because of their special architectural or historical merit, or other heritage buildings, in so far as compliance with the standards would unacceptably alter their character or appearance,  or  if  their  renovation  is  not  technically or  economically  feasible;
- (b) buildings  used  as  places  of  worship  and  for  religious  activities;
- (c) temporary buildings with a time of use of two years or less, industrial sites, workshops and non-residential agricultural buildings  with  low  energy  demand  and  non-residential  agricultural  buildings  which  are  used  by  a  sector  covered  by a  national  sectoral  agreement  on  energy  performance;
- (d) residential buildings which are used or intended to be used for either less than four months of the year or, alternatively, for a limited annual time of use and with an expected energy consumption of less than 25 % of what would be the result of  all-year  use;
- (e) stand-alone  buildings  with  a  total  useful  floor  area  of  less  than  50  m ; 2
- (f) buildings owned by the armed forces or central government and serving national defence purposes, apart from single living  quarters  or  office  buildings  for  the  armed  forces  and  other  staff  employed  by  national  defence  authorities.
- 7. Member  States  shall  take  the  measures  necessary  to  ensure  the  implementation  of  minimum  energy  performance standards referred to in paragraphs 1 and 2 of this Article, including appropriate monitoring mechanisms and penalties in accordance with Article 34.

When  laying  down  the  rules  on  penalties,  Member  States  shall  take  into  account  the  financial  situation  and  access  to adequate financial  support  of  homeowners, in particular  for  vulnerable  households.

- 8. By 31 March 2025, the Commission shall, in support of the implementation of this Directive and taking due account of  the  principle  of  subsidiarity,  present  an  analysis  with  particular  regard  to:
- (a) the effectiveness of, the appropriateness of the level of, the actual amount used from, and the types of instrument used with regard to structural funds and Union framework programmes, including funding from the European Investment Bank,  for  improving  the  energy  performance  of  buildings,  especially  in  housing;
- (b) the  effectiveness  of,  the  appropriateness  of  the  level  of,  and  the  types  of  instrument  and  types  of  measure  used  with regard  to  funds  from  public  finance  institutions;
- (c) the  coordination  of  Union  and  national  funding  and  other  types  of  measure  that  can  act  as  leverage  for  stimulating investments in the energy performance of buildings, and the adequacy of such funding for achieving Union objectives.

On the basis of that analysis, the Commission shall submit a report to the European Parliament and to the Council on the effectiveness  and  appropriateness  of  financing  instruments  towards  the  improvement  of  the  energy  performance  of buildings,  in  particular  the  worst-performing  ones.

## Article  10

## Solar  energy in buildings

- 1. Member States shall ensure that all new buildings are designed to optimise their solar energy generation potential on the  basis  of  the  solar  irradiance  of  the  site,  enabling  the  subsequent  cost-effective  installation  of  solar  technologies.
- 2. The permit-granting procedure for the installation of solar energy equipment set out in Article 16d of Directive (EU) 2018/2001, and simple-notification procedure for grid connections set out in Article 17 of that Directive shall apply to the installation  of  solar  energy  equipment  on  buildings.
- 3. Member  States  shall  ensure  the  deployment  of  suitable  solar  energy  installations,  if technically  suitable and economically and functionally  feasible,  as  follows:
- (a) by 31 December 2026, on all new public and non-residential buildings with useful floor area larger  than 250  m ; 2
- (b) on all  existing  public  buildings  with  useful  floor  area  larger  than:
- (i) 2 000 m 2 ,  by  31  December  2027;
- (ii) 750 m 2 ,  by  31  December  2028;
- (iii) 250 m 2 ,  by  31  December  2030;
- (c) by  31  December  2027,  on  existing  non-residential  buildings  with  useful  floor  area  larger  than  500  m ,  where  the 2 building  undergoes  a  major  renovation  or  an  action  that  requires  an  administrative  permit  for  building  renovations, works on the roof or  the  installation  of  a  technical  building  system;
- (d) by 31 December 2029, on all new residential buildings;  and
- (e) by 31 December 2029, on all new roofed car  parks  physically  adjacent to buildings.

In their national building renovation plans referred to in Article 3, Member States shall include policies and measures with regard  to  the  deployment  of  suitable  solar  energy  installations  on  all  buildings.

- 4. Member States shall establish, and make publicly available, criteria at national level for  the practical implementation of the obligations set out in this Article, and for possible exemptions from those obligations for specific types of building, taking  into  account  the  principle  of  technological  neutrality  with  regard  to  technologies  not  producing  any  on-site emissions and in accordance with the assessed technical and economic potential of  the solar energy installations and the characteristics  of  the  buildings  covered by  this  obligation.  Member  States  shall  also  take  into  account  structural  integrity, green  roofs,  and  attic  and  roof  insulation,  where  appropriate.

In order to achieve the objectives of this Article and to take into account the issues linked to the stability of the electricity network,  Member  States  shall  include  relevant  stakeholders  in  the  establishment  of  the  criteria  referred  to  in  the  first subparagraph of  this  paragraph.

In  the  transposition  of  the  obligations  set  out  in  the  first  subparagraph  of  paragraph  3,  a  Member  State  may  use  the measurement of buildings' ground floor area instead of buildings' useful floor area, provided that the Member State shows that  this  results  in  an  equivalent  amount  of  installed  capacity of  suitable  solar  energy  installations  on  buildings.

- 5. Member  States  shall  put  in  place  a  framework  providing  the  necessary  administrative,  technical  and  financial measures to support the deployment of solar energy in buildings, including in combination with technical building systems or  efficient  district  heating  systems.

## Article  11

## Zero-emission buildings

- 1. A  zero-emission  building  shall  not  cause  any  on-site  carbon  emissions  from  fossil  fuels.  A  zero-emission  building shall,  where  economically  and technically feasible,  offer  the  capacity  to react  to  external  signals  and  adapt  its  energy  use, generation  or  storage.

- 2. Member  States  shall  take  the  necessary  measures  to  ensure  that  the  energy  demand  of  a  zero-emission  building complies with a maximum threshold.

Member  States  shall  set  that  maximum  threshold  for  the  energy  demand  of  a  zero-emission  building  with  a  view  to achieving at least the cost-optimal levels established in the most recent national cost-optimal report pursuant to Article 6. Member States shall  revise  the  maximum  threshold  every  time  that  the  cost-optimal  levels  are  revised.

- 3. The  maximum  threshold  for  the  energy  demand  of  a  zero-emission  building  shall  be  at  least  10 %  lower  than  the threshold for total primary energy use established at Member State level for nearly zero-energy buildings on 28 May 2024.
- 4. Member States may adjust the maximum threshold for the energy demand of a zero-emission building for renovated buildings,  while  complying with  the  respective  provisions on  cost optimality,  and,  where  thresholds  for  renovated  nearly zero-energy  buildings  have  been  established,  the  requirements  of  paragraph  3.
- 5. Member  States  shall  take  the  necessary  measures  to  ensure  that  the  operational  greenhouse  gas  emissions  of a zero-emission building comply with a maximum threshold established at the Member State level in their national building renovation plans.  That  maximum threshold may be set at different levels for  new  and  renovated  buildings.
- 6. Member  States  shall  notify  the  Commission  about  their  maximum  thresholds,  including  a  description  of  the calculation  methodology  per  building  type  and  relevant  outdoor  climate  designation,  in  accordance  with  Annex  I.  The Commission shall review the maximum thresholds and recommend their adaptation where appropriate.
- 7. Member States shall ensure that the total annual primary energy use of a new or renovated zero-emission building is covered by:
- (a) energy from renewable sources generated on-site or nearby, fulfilling the criteria laid down in Article 7 of Directive (EU) 2018/2001;
- (b) energy  from  renewable  sources  provided  from  a  renewable  energy  community  within  the  meaning  of  Article  22  of Directive  (EU)  2018/2001;
- (c) energy  from  an  efficient  district  heating  and  cooling  system  in  accordance  with  Article  26(1)  of  Directive  (EU) 2023/1791; or
- (d) energy  from  carbon-free  sources.

Where it is not technically or economically feasible to fulfil the requirements laid down in this paragraph, the total annual primary energy use may also be covered by other energy from the grid complying with criteria established at national level.

## Article  12

## Renovation passport

- 1. By 29 May 2026, Member States shall introduce a scheme for renovation passports based on the common framework set  out  in  Annex  VIII.
- 2. The scheme referred to in paragraph 1 shall be of voluntary use by owners of buildings and building units, unless the Member State decides to make it mandatory.

Member States shall take measures to ensure that renovation passports are affordable and shall consider whether to provide financial  support  to vulnerable  households  wishing  to  renovate  their  buildings.

- 3. Member States may allow for the renovation passport to be drawn up and issued jointly with the energy performance certificate.
- 4. The  renovation  passport  shall  be  issued  in  a  digital  format  suitable  for  printing,  by  a  qualified  or  certified  expert, following an on-site visit.
- 5. When the renovation passport is issued, a discussion with the expert referred to in paragraph 4 shall be suggested to the  building  owner  to allow the expert to explain the best steps by which to transform the building into a zero-emission building  well  before  2050.

- 6. Member States shall strive to provide a dedicated digital tool by means of which to prepare and, where appropriate, update the renovation passport. Member States may develop a complementary tool allowing building owners and building managers  to  simulate  a  draft  simplified  renovation  passport  and  for  them  to  update  it  once  a  renovation  takes  place  or a  building  element  is  replaced.
- 7. Member  States  shall  ensure  that  the  renovation  passport  can  be  uploaded  to  the  national  database  for  the  energy performance of buildings  set  up  pursuant  to  Article  22.
- 8. Member  States  shall  ensure  that  the  renovation  passport  is  stored  in,  or  can  be  accessed  via,  where  available,  the digital  building  logbook.

## Article  13

## Technical building systems

- 1. Member  States  shall,  for  the  purpose  of  optimising  the  energy  use  of  technical  building  systems,  set  system requirements,  using energy-saving technologies, in respect of  the  overall  energy  performance,  the  proper  installation,  the appropriate dimensioning, adjustment and control and, where appropriate, the hydronic balancing of the technical building systems  which  are  installed  in  new  or  existing  buildings.  When  setting  up  the  requirements,  Member  States  shall  take account of  design  conditions  and  typical  or  average  operating  conditions.

System requirements shall be set for new and for the replacement and upgrading of existing technical building systems and shall  be  applied  in  so  far  as  technically,  economically  and  functionally  feasible.

Member  States  may  set  requirements  related  to  the  greenhouse  gas  emissions  of,  or  to  the  type  of  fuel  used  by  heat generators or to the minimum part of renewable energy used for heating at building's level, provided that such requirements do not  constitute  an  unjustified  market  barrier.

Member  States  shall  ensure  that  the  requirements  they  set  for  technical  building  systems  reach  at  least  the  latest cost-optimal  levels.

- 2. Member States may set specific system requirements for technical building systems in order to facilitate the effective installation  and  operation  of  low  temperature  heating  systems  in  new  or  renovated  buildings.
- 3. Member  States  shall  require  new  buildings,  where  technically  and  economically  feasible,  to  be  equipped  with self-regulating devices for the separate regulation of the temperature in each room or, where justified, in a designated heated or cooled zone of the building unit and, where appropriate, with hydronic balancing. The installation of such self-regulating devices and, where appropriate, hydronic balancing in existing buildings shall be required when heat generators or cooling generators are  replaced,  where  technically  and  economically  feasible.
- 4. Member States shall set requirements for  the implementation of adequate indoor environmental quality standards in buildings  in  order  to  maintain  a  healthy  indoor  climate.
- 5. Member  States  shall  require  non-residential  zero-emission  buildings  to  be  equipped  with  measuring  and  control devices for the monitoring and regulation of indoor air quality. In existing non-residential buildings, the installation of such devices  shall  be  required,  where  technically  and  economically  feasible,  when  a  building  undergoes  a  major  renovation. Member States may require the installation  of  such  devices  in  residential  buildings.
- 6. Member States shall ensure that, when a technical building system is installed, the overall energy performance of the altered part and, where relevant, of the complete altered system is assessed. The results shall be documented and passed on to the building owner, so that they remain available and can be used for the verification of compliance with the minimum requirements  laid  down pursuant  to  paragraph  1  and  the  issue  of  energy  performance  certificates.

Member States  shall  take  the  necessary  measures  to  ensure  that  the  energy  performance  of  technical  building  systems  is optimised  where  they  are  retrofitted  or  replaced.

Member States shall  promote  energy  storage for  renewable  energy  in  buildings.

Member  States  may  provide  for  new  incentives  and  funding  to  encourage  the  switch  from  fossil-fuel-based  heating  and cooling  systems  to  non-fossil-fuel-based  heating  and  cooling  systems.

- 7. Member States shall strive to replace stand-alone boilers powered by fossil fuels in existing buildings, in line with the national  phase-out  plans  for  fossil  fuel  boilers.
- 8. The Commission shall issue guidance  on what qualifies as  a fossil  fuel  boiler.
- 9. Member  States shall lay down  requirements to ensure that, where technically and economically feasible, non-residential  buildings  are  equipped  with  building  automation  and  control  systems,  as  follows:
- (a) by  31  December  2024,  non-residential  buildings  with  an  effective  rated  output  for  heating  systems,  air-conditioning systems, systems for combined space heating and ventilation, or systems for combined air conditioning and ventilation of over 290 kW;
- (b) by  31  December  2029,  non-residential  buildings  with  an  effective  rated  output  for  heating  systems,  air-conditioning systems, systems for combined space heating and ventilation, or systems for combined air conditioning and ventilation of over 70  kW.
- 10. The building automation and control systems shall be capable of:
- (a) continuously monitoring, logging,  analysing and  allowing  for  adjusting  energy  use;
- (b) benchmarking the building's energy efficiency, detecting losses in efficiency of technical building systems, and informing the  person  responsible  for  the  facilities  or  technical  building  management  about  opportunities  for  energy  efficiency improvement;
- (c) allowing communication with connected technical building systems and other appliances inside the building, and being interoperable with technical building systems across different types of proprietary technologies, devices and manufacturers;
- (d) by 29 May 2026 monitoring of indoor environmental quality.
- 11. Member States shall lay down requirements to ensure that, where technically, economically and functionally feasible, from 29 May 2026, new residential buildings and residential buildings undergoing major renovations are equipped with the following:
- (a) the functionality of continuous electronic monitoring that measures systems' efficiency and informs building owners or managers in the case  of a  significant  variation  and  when  system  servicing  is  necessary;
- (b) effective control  functionalities  to  ensure  optimum  generation,  distribution,  storage,  use  of  energy  and,  where applicable,  hydronic  balance;
- (c) a  capacity  to  react  to  external  signals  and  adjust  the  energy  consumption.

Member States may exclude single-family houses undergoing major  renovations  from the requirements laid down in this paragraph where the costs  of  installation  exceed  the  benefits.

- 12. Member  States shall lay down  requirements to ensure that, where technically and economically feasible, non-residential buildings with an effective rated output for heating systems, air-conditioning systems, systems for combined space  heating  and  ventilation,  or  systems  for  combined  air  conditioning  and  ventilation  of:
- (a) over  290  kW are  equipped  with  automatic  lighting  controls  by  31  December  2027;
- (b) over  70  kW are  equipped  with  automatic  lighting  controls  by  31  December  2029.

The automatic lighting  controls  shall  be  suitably  zoned  and  capable  of occupancy  detection.

## Article  14

## Infrastructure for  sustainable  mobility

- 1. With regard to new non-residential  buildings  with  more  than  five  car  parking  spaces  and  non-residential  buildings undergoing major  renovation, with more than five  car  parking  spaces,  Member  States shall  ensure:
- (a) the  installation  of  at  least  one  recharging  point  for  every  five  car  parking  spaces;
- (b) the installation of pre-cabling for at least 50 % of car parking spaces and ducting, namely conduits for electric cables, for the  remaining  car  parking  spaces,  to  enable  the  installation  at  a  later  stage  of  recharging  points  for  electric  vehicles, electrically  power-assisted  cycles  and  other  L-category  vehicle  types;  and
- (c) the  provision  of  bicycle  parking  spaces  representing  at  least  15 %  of  average  or  10 %  of  total  user  capacity  of non-residential buildings, taking into account the space required also for bicycles with larger dimensions than standard bicycles.

The first  subparagraph  shall  apply  where:

- (a) the car park is located inside the building, and, for major renovations, renovation measures include the car park or the electrical  infrastructure  of  the  building;  or
- (b) the car park is physically adjacent to the building, and, for major renovations, renovation measures include the car park or  the  electrical  infrastructure  of  the  car  park.

Member  States  shall  ensure  that  the  pre-cabling  and  ducting  referred  to  in  point  (b)  of  the  first  subparagraph  are dimensioned so as to enable the simultaneous and efficient use of the required number of recharging points and support, where appropriate, the  installation  of  a  load  or  recharging  management  system,  to  the  extent  that  this  is  technically  and economically feasible  and  justifiable.

By  way  of  derogation  from  point  (a)  of  the  first  subparagraph,  for  new  office  buildings  and  office  buildings  undergoing major renovation, with more than five parking spaces, Member States shall ensure the installation of at least one recharging point  for  every  two  parking  spaces.

- 2. With regard to all non-residential buildings with more than 20 car parking spaces, Member States shall, by 1 January 2027, ensure:
- (a) the  installation  of  at  least  one  recharging  point  for  every  10  car  parking  spaces,  or  of  ducting,  namely  conduits  for electric cables, for at least 50 % of the car parking spaces to enable the installation at a later stage of recharging points for  electric  vehicles;  and
- (b) the  provision  of  bicycle  parking  spaces  representing  at  least  15 %  of  average  or  10 %  of  total  user  capacity  of  the building  and  with  space  required  also  for  bicycles  with  larger  dimensions  than  standard  bicycles.

For  buildings  owned  or  occupied  by  public  bodies,  Member  States  shall  ensure  the  installation  of  pre-cabling  for  at  least 50 % of car  parking  spaces  by  1  January  2033.

Member States may postpone the implementation of this requirement until 1 January 2029 for all non-residential buildings that  have  been  renovated  in  the  two  years  prior  to  28  May  2024  in  order  to  comply  with  the  national  requirements established  in  accordance  with  Article  8(3)  of  Directive  2010/31/EU.

- 3. Member States may adjust requirements for  the number of bicycle parking spaces in accordance with paragraphs 1 and 2 for  specific  categories  of  non-residential  buildings  that  are  not  typically  accessed  by  bicycles.
- 4. With regard to new residential buildings with more than three car parking spaces and residential buildings undergoing major  renovation,  with  more  than  three  car  parking  spaces,  Member  States  shall  ensure:
- (a) the installation of pre-cabling for at least 50 % of car parking spaces and ducting, namely conduits for electric cables, for the  remaining  car  parking  spaces  to  enable  the  installation,  at  a  later  stage,  of  recharging  points  for  electric  vehicles, electrically  power-assisted  cycles  and  other  L-category  vehicle  types;  and
- (b) the  provision  of  at  least  two  bicycle  parking  spaces  for  every  residential  building  unit.

With  regard  to  new  residential  buildings  with  more  than  three  car  parking  spaces,  Member  States  shall  also  ensure  the installation  of  at  least  one  recharging  point.

The first  and  second  subparagraphs  shall  apply  where:

- (a) the car park is located inside the building, and, for major renovations, renovation measures include the car park or the electric  infrastructure  of  the  building;  or
- (b) the car park is physically adjacent to the building, and, for major renovations, renovation measures include the car park or  the  electrical  infrastructure  of  the  car  park.

By way of derogation from the first  subparagraph, Member States may, subject to an assessment by local authorities and taking into account local characteristics, including demographical, geographical and climate conditions, adjust requirements for  the  number  of  bicycle  parking  spaces.

Member States shall ensure that the pre-cabling referred to in point (a) of the first subparagraph is dimensioned to enable the  simultaneous  use  of  recharging  points  on  all  parking  spaces.  Where,  in  the  case  of  major  renovation,  ensuring  two bicycle parking spaces for every residential building unit is not feasible, Member States shall ensure as many bicycle parking spaces  as  appropriate.

- 5. Member States may decide not to apply paragraphs 1, 2 and 4 of this Article to specific categories of building where:
- (a) the  recharging  infrastructure  required  would  rely  on  micro-isolated  systems  or  the  buildings  are  situated  in  the outermost  regions  within  the  meaning  of  Article  349  TFEU  where  this  would  lead  to  substantial  problems  for  the operation  of  the  local  energy  system  and  would  endanger  the  stability of  the  local  grid;  or
- (b) the cost of the recharging and ducting installations exceeds at least 10 % of the total cost of the major renovation of the building.
- 6. Member States shall ensure that the recharging points referred to in paragraphs 1, 2 and 4 of this Article are capable of smart  recharging  and,  where  appropriate,  bi-directional  recharging  and  that  they  are  operated  on  the  basis  of non-proprietary  and  non-discriminatory  communication  protocols  and  standards,  in  an  interoperable  manner,  and  in compliance with any European standards and delegated acts adopted pursuant to Article 21(2) and (3) of Regulation (EU) 2023/1804.
- 7. Member  States  shall  encourage  that  operators  of  non-publicly  accessible  recharging  points  operate  them  in accordance with Article 5(4)  of  Regulation  (EU)  2023/1804,  where  applicable.
- 8. Member  States  shall  provide  for  measures  in  order  to  simplify,  streamline  and  accelerate  the  procedure  for  the installation  of  recharging  points  in  new  and  existing,  residential  and  non-residential  buildings,  especially  of  co-owners' associations, and remove regulatory barriers, including permitting and approval procedures from public authorities without prejudice to the property and tenancy law of the Member States. Member States shall remove barriers to the installation of recharging points in residential buildings with parking spaces, in particular the need to obtain consent from the landlord or co-owners for a private recharging point for own use. A request by tenants or co-owners to be allowed to install recharging infrastructure  in  a  parking  space  may  be  refused  only  if  there  are  serious  and  legitimate  grounds  for  doing  so.

Without  prejudice  to  their  property  and  tenancy  law,  Member  States  shall  assess  administrative  barriers  regarding  the application for  the  installation  of a  recharging  point  in  a  building  with  multiple  residential  building  units  at  a  tenants'  or a  co-owners'  association.

Member  States  shall  ensure  the  availability  of  technical  assistance  for  building  owners  and  tenants  wishing  to  install recharging  points  and  bicycle  parking  spaces.

With  regard  to  residential  buildings,  Member  States  shall  consider  whether  to  introduce  support  schemes  for  the installation  of  recharging  points,  pre-cabling  or  ducting  of  parking  spaces  in  line  with  the  number  of  battery  electric light-duty  vehicles  registered  in  their  territory.

- 9. Member  States  shall  ensure  the  coherence  of  policies  for  buildings,  active  and  green  mobility,  climate,  energy, biodiversity  and  urban planning.
- 10. By  31  December 2025, the Commission shall publish guidance for  fire safety in  car  parks.

## Article  15

## Smart readiness of buildings

- 1. The Commission shall adopt delegated acts in accordance with Article 32 to supplement this Directive concerning an optional common Union scheme for rating the smart readiness of buildings. The rating shall be based on an assessment of the capabilities of a building or building unit to adapt its operation to the needs of the occupant, in particular concerning indoor  environmental  quality  and  the  grid  and  to  improve  its  energy  efficiency  and  overall  performance.

In  accordance  with  Annex  IV,  the  optional  common  Union  scheme  for  rating  the  smart  readiness  of  buildings  shall  lay down:

- (a) the  definition  of  the  smart  readiness  indicator;
- (b) a  methodology by which it is  to be  calculated.
- 2. By 30 June 2026, the Commission shall submit a report to the European Parliament and the Council on the testing and  implementation of  the  smart  readiness  indicator  on  the  basis  of  the  available  results  of  the  national  test  phases  and other  relevant  projects.

Taking  into  account  the  outcome  of  that  report,  the  Commission  shall,  by  30  June  2027,  adopt  a  delegated  act  in accordance with Article 32, supplementing this Directive by requiring the application of  the common Union scheme for rating  the  smart  readiness  of  buildings,  in  accordance  with  Annex  IV,  to  non-residential  buildings  with  an  effective  rated output for heating  systems,  air-conditioning  systems,  systems for  combined  space  heating and  ventilation,  or  systems for combined air-conditioning and ventilation  of over 290  kW.

- 3. The  Commission  shall,  after  having  consulted  the  relevant  stakeholders,  adopt  an  implementing  act  detailing  the technical arrangements for the effective implementation of the scheme referred to in paragraph 1 of this Article, including a timeline for a non-committal test phase at national level, and clarifying the complementary relation of the scheme to the energy  performance certificates  referred  to  in  Article  19.

That  implementing act  shall  be  adopted  in  accordance  with  the  examination  procedure  referred  to  in  Article  33(3).

- 4. Provided that  the  Commission  has  adopted  the  delegated  act  referred  to  in  paragraph  2,  it  shall,  by  30  June  2027, adopt an implementing act detailing the technical arrangements for the effective implementation of the application of the scheme  referred  to  in  paragraph  2  to  non-residential  buildings  with  an  effective  rated  output  for  heating  systems, air-conditioning  systems,  systems  for  combined  space  heating  and  ventilation,  or  systems  for  combined  air-conditioning and ventilation  of over  290  kW.

That  implementing act  shall  be  adopted  in  accordance  with  the  examination  procedure  referred  to  in  Article  33(3).

## Article  16

## Data exchange

- 1. Member States shall ensure that the building owners, tenants and managers can have direct access to their building systems'  data.  Upon  their  consent,  the  access  or  data  shall  be  made  available  to  a  third  party,  subject  to  the  existing applicable  rules  and  agreements.  Member  States  shall  facilitate  the  full  interoperability  of  services  and  of  data  exchange within  the  Union  in  accordance  with  paragraph  5.

For the purposes of this Directive, building systems' data shall include at least all readily available data related to the energy performance  of  building  elements,  the  energy  performance  of  building  services,  the  projected  lifespan  of  the  heating systems, where available, building automation and control systems, meters, measuring and control devices and recharging points  for  e-mobility  and  be  linked,  where  available,  to  the  digital  building  logbook.

- 2. When laying down the rules regarding the management and exchange of data, taking into account the international standards  and  management  format  to  data  exchange,  Member  States  or,  where  a  Member  State  has  so  provided,  the designated competent authorities, shall comply with the applicable Union law. The rules on the access and any charges shall not  constitute  a  barrier  or  create  discrimination  for  third  parties  to  access  building  systems'  data.
- 3. No additional costs shall be charged to the building owner, tenant or manager for access to their data or for a request to make their data available to a third party subject to the existing applicable rules and agreements. Member States shall be responsible  for  setting  the  relevant  charges  for  access  to  data  by  other  eligible  parties  such  as  financial  institutions, aggregators,  energy  suppliers,  energy  services  providers  and  national  statistical  institutes  or  other  national  authorities responsible for the development, production and dissemination of European statistics. Member States or, where applicable, the designated competent authorities, shall ensure that any charges imposed by regulated entities that provide data services are  reasonable  and  duly  justified.  Member  States  shall  incentivise  the  sharing  of  the  relevant  building  systems'  data.
- 4. The rules on access to data and data storage for the purposes of this Directive shall comply with the relevant Union law.  The  processing  of  personal  data  within  the  framework  of  this  Directive  shall  be  carried  out  in  accordance  with Regulation  (EU)  2016/679  of  the  European  Parliament  and  of  the  Council ( 30 ).
- 5. By  31  December  2025,  the  Commission  shall  adopt  implementing  acts  detailing  interoperability  requirements  and non-discriminatory  and  transparent  procedures  for  access  to  the  data.

Those implementing acts shall  be  adopted  in  accordance  with  the  advisory  procedure  referred  to  in  Article  33(2).

The  Commission  shall  issue  a  consultation  strategy,  setting  out  consultation  objectives,  targeted  stakeholders  and  the consultation  activities  for  the  development  of  the  implementing  acts.

## Article  17

## Financial incentives, skills  and  market  barriers

- 1. Member States shall provide appropriate financing, support measures and other instruments able to address market barriers in order to deliver the necessary investments identified in their national building renovation plan to transform their building  stock  into  zero-emission  buildings  by  2050.
- 2. Member States shall ensure that applications and procedures for public financing are simple and streamlined in order to  facilitate  access  to  financing,  especially  for  households.
- 3. Member States shall assess  and,  where  appropriate, address  barriers  related  to  up-front  costs  of  renovations.
- 4. When  designing  financial  support  schemes  for  building  renovation,  Member  States  shall  consider  whether  to  use revenue-based  parameters.
- ( 30 ) Regulation (EU) 2016/679 of the European Parliament and of the Council of 27 April 2016 on the protection of natural persons with regard to the processing of personal data and on the free movement of such data, and repealing Directive 95/46/EC (General Data Protection Regulation)  (OJ  L  119,  4.5.2016,  p.  1).

Member States may use the national energy efficiency funds, where such funds are set up pursuant to Article 30 of Directive (EU)  2023/1791, to finance  dedicated  schemes and  programmes for energy  performance renovations.

- 5. Member States shall take appropriate regulatory measures to remove non-economic barriers to building renovation. With regard to buildings with more than one building unit, such measures may include removing unanimity requirements in  co-ownership  structures,  or  allowing  co-ownership  structures  to  be  direct  recipients  of  financial  support.
- 6. Member States  shall  make  best  cost-effective  use  of  national  financing  and  financing  available  established  at  Union level,  in  particular  the  Recovery  and  Resilience  Facility,  the  Social  Climate Fund,  the  Cohesion  fund,  InvestEU,  auctioning revenues from emission trading pursuant to Directive 2003/87/EC of the European Parliament and of the Council ( 31 )  and other public funding sources. Those funding sources shall be deployed consistently with a path to achieving a zero-emission building  stock  by  2050.
- 7. To  support  the  mobilisation  of  investments,  Member  States  shall  promote  the  effective  development  and  use  of enabling  funding  and  financial  tools,  such  as  energy  efficiency  loans  and  mortgages  for  building  renovation,  energy performance contracting, pay-as-you-save financial schemes, fiscal incentives, for example reduced tax rates on renovation works and materials,  on-tax schemes, on-bill schemes, guarantee funds, funds targeting deep renovations, funds targeting renovations with a significant minimum threshold of targeted energy savings and mortgage portfolio standards. They shall guide investments into an energy-efficient public building stock, in line with Eurostat guidance on the recording of energy performance contracts in government accounts.

Member States may also promote and simplify the use of public-private partnerships.

- 8. Member States shall ensure that information about available funding and financial tools is made available to the public in  an  easily  accessible  and  transparent  manner,  including  by  digital  means.
- 9. The  enabling  funding  and  financial  tools  may  include  renovation  loans  or  guarantee  funds  for  energy  performance renovations,  including  in  combination with  relevant  Union programmes,  where  applicable.
- 10. By  29  May  2025,  the  Commission  shall  adopt  a  delegated  act  in  accordance  with  Article  32  supplementing  this Directive  by  establishing  a  comprehensive  portfolio  framework  for  voluntary  use  by  financial  institutions  that  supports lenders in targeting and increasing lending volumes provided in accordance with the Union's decarbonisation ambition and relevant  energy  targets,  in  order  to  effectively  encourage  financial  institutions  to  increase  lending  volumes  provided  for energy  performance  renovations.  The  actions  set  out  in  the  comprehensive  portfolio  framework  shall  cover  increasing lending volumes for energy renovations and shall include suggested safeguards to protect vulnerable households through blended funding solutions. The framework shall describe best practices to encourage lenders to identify and act upon the worst-performing buildings  within  their  portfolios.
- 11. Member States shall facilitate the aggregation of projects to enable investor access as well as packaged solutions for potential  clients.

Member  States  shall  adopt  measures  that  promote  energy  efficiency  lending  products  for  building  renovations,  such  as green mortgages and green loans, secured and unsecured, and ensure that they are offered widely and in a  non-discriminatory  manner  by  financial  institutions  and,  are  visible  and  accessible  to  consumers.  Member  States  shall ensure that banks and other financial institutions and investors receive information on opportunities to participate in the financing  of  the  improvement of  the  energy  performance  of  buildings.

- 12. Member States shall put in place measures and financing to promote education and training with a view to ensuring that  there  is  a  sufficient  workforce  with  the  appropriate  level  of  skills  corresponding  to  the  needs  in  the  building  sector, especially  targeting  SMEs,  including  microenterprises,  as  appropriate.  One-stop  shops  established  pursuant  to  Article  18 may facilitate  access  to  such  measures  and  financing.
- ( 31 ) Directive 2003/87/EC of the European Parliament and of the Council of 13 October 2003 establishing a system for greenhouse gas emission allowance trading within the  Union and amending Council Directive 96/61/EC (OJ L 275, 25.10.2003, p. 32).

- 13. The Commission shall, where appropriate and upon request, assist Member States in setting up national or regional financial  support  programmes  with  the  aim  of  increasing  the  energy  performance  of  buildings,  especially  of  existing buildings, including by supporting the exchange of best practice between the responsible national or regional authorities or bodies. Member States shall ensure that such programmes are developed in a way that they are accessible to organisations with  lower  administrative,  financial,  and  organisational  capacities.
- 14. With due regard to vulnerable households, Member States shall link their financial measures for energy performance improvements  and  reduced  greenhouse  gas  emissions  in  the  renovation  of  buildings  to  the  targeted  or  achieved  energy savings  and  improvements, as  determined  by one  or  more  of  the  following  criteria:
- (a) the energy performance of the equipment or material used for the renovation and the related greenhouse gas emission reduction; in which case, the equipment or  material  used for  the renovation is to be installed by an installer  with the relevant level of certification or qualification and shall comply with at least minimum energy performance requirements for  building  elements  or  higher  reference  values  for  an  improved  energy  performance  of  buildings;
- (b) standard  values  for  the  calculation  of  energy  savings  and  greenhouse  gas  emission  reduction  in  buildings;
- (c) the improvement achieved due to such renovation by comparing energy performance certificates issued before and after renovation;
- (d) the  results  of  an  energy  audit;
- (e) the  results of  another  relevant,  transparent  and  proportionate  method  that  shows  the  improvement  in  energy performance, for example by comparing the energy consumption before and after renovation with metering systems, provided it  complies with  the  requirements  set  out  in  Annex  I.
- 15. From 1 January 2025, Member States shall not provide any financial incentives for  the installation of stand-alone boilers  powered  by  fossil  fuels,  with  the  exception  of  those  selected  for  investment,  before  2025,  in  accordance  with Regulation  (EU)  2021/241,  Article  7(1),  point  (h)(i),  third  indent,  of  Regulation  (EU)  2021/1058  and  with  Article  73  of Regulation  (EU)  2021/2115 of  the  European  Parliament  and  of  the  Council ( 32 ).
- 16. Member  States  shall incentivise deep renovation and staged deep renovation  with higher financial, fiscal, administrative  and  technical  support.  Where  it  is  not  technically  or  economically  feasible  to  transform  a  building  into a zero-emission building, a renovation resulting in at least a 60 % reduction of primary energy use shall be considered to be a  deep  renovation  for  the  purposes  of  this  paragraph.  Member  States  shall  incentivise  sizeable  programmes  that  address a  high  number  of  buildings,  in  particular  the  worst-performing  buildings,  such  as  through  integrated  district  renovation programmes, and that  result  in  an  overall  reduction  of  at  least  30 %  of  primary  energy  use,  with  higher  financial,  fiscal, administrative  and  technical  support,  according  to  the  level  of  performance  achieved.
- 17. Without  prejudice  to  their  national  economic  and  social  policies  and  to  their  systems  of  property  law,  Member States  shall  address  the  eviction  of  vulnerable  households  caused  by  disproportionate  rent  increases  following  energy renovation  of  their  residential  building  or  building  unit.
- 18. Financial incentives shall target, as a priority, vulnerable households, people affected by energy poverty and people living  in  social  housing,  in  accordance  with  Article  24  of  Directive  (EU)  2023/1791.
- ( 32 ) Regulation (EU) 2021/2115 of the European Parliament and of the Council of 2 December 2021 establishing rules on support for strategic plans to be drawn up by Member States under  the common agricultural policy (CAP Strategic Plans) and financed by the European  Agricultural  Guarantee  Fund  (EAGF)  and  by  the  European  Agricultural  Fund  for  Rural  Development  (EAFRD)  and repealing  Regulations  (EU)  No  1305/2013  and  (EU)  No  1307/2013  (OJ  L  435,  6.12.2021,  p.  1).

- 19. When providing financial incentives to owners of buildings or building units for the renovation of rented buildings or building units, Member States shall aim at financial incentives benefiting both the owners and the tenants. Member States shall introduce effective safeguards, to protect in particular  vulnerable households, including by providing rent support or by imposing caps on rent increases, and may incentivise financial schemes that tackle the upfront costs of renovations, such as on-bill schemes, pay-as-you-save schemes or energy performance contracting, as referred to in point (33) of Article 2 and Article  29  of  Directive  (EU)  2023/1791.

## Article  18

## One-stop shops for  the energy performance of buildings

- 1. Member States shall, in cooperation with competent authorities, and, where appropriate, private stakeholders, ensure the  establishment  and  the  operation  of  technical  assistance  facilities,  including  through  inclusive  one-stop  shops  for  the energy  performance  of  buildings,  targeting  all  actors  involved  in  building  renovations,  inter  alia,  home  owners  and administrative,  financial  and  economic  actors,  such  as  SMEs,  including  microenterprises.

Member States shall ensure that technical assistance facilities are available across their territory by establishing at least one one-stop  shop:

- (a) per  80 000  inhabitants;
- (b) per  region;
- (c) in  areas  where  the  average  age  of  the  building  stock  is  above  the  national  average;
- (d) in  areas  where  Member  States  intend  to  implement  integrated  district  renovation  programmes;  or
- (e) in  a  location  that  can  be  reached  within  less  than  90  minutes  of  average  travel  time,  on  the  basis  of  the  means  of transport  that  is  locally  available.

Member  States  may  designate  the  one-stop  shops  established  pursuant  to  Article  22(3),  point  (a),  of  Directive  (EU) 2023/1791 as one-stop shops for  the purposes of  this  Article.

The Commission shall provide guidelines to establish those one-stop shops in accordance with Article 22(6) of Directive (EU)  2023/1791.

- 2. The technical  assistance  facilities  established  pursuant  to  paragraph  1,  shall:
- (a) provide  streamlined  information  on  technical  and  financial  possibilities  and  solutions  to  households,  SMEs  including microenterprises,  and  public  bodies;
- (b) provide  holistic  support  to  all  households,  with  a  particular  focus  on  households  affected  by  energy  poverty  and  on worst-performing  buildings,  as  well  as  to  accredited  companies  and  installers  providing  retrofit  services,  adapted  to different  housing  typologies  and  geographical  scope,  and  provide  support  covering  the  different  stages  of  the  retrofit project.
- 3. One-stop shops established  pursuant  to paragraph 1  shall:
- (a) provide independent advice on the energy performance of buildings and may accompany integrated district renovation programmes;
- (b) offer  dedicated  services  for  vulnerable  households,  people  affected  by  energy  poverty  and  people  in  low-income households.

## Article  19

## Energy performance certificates

- 1. Member States shall lay down the necessary measures to establish a system of certification of the energy performance of  buildings.

The energy performance certificate shall include the energy performance of a building expressed by a numeric indicator of primary  energy  use  in  kWh/(m .y),  and  reference  values  such  as  minimum  energy  performance  requirements,  minimum 2 energy performance standards, nearly zero-energy building requirements and zero-emission building requirements, in order to make it possible for owners or  tenants of  the building or building unit to compare and assess its energy performance.

- 2. By 29 May 2026, the energy performance certificate shall comply with the template in Annex V. It shall specify the energy performance class of the building, on a closed scale using only letters from A to G. The letter A shall correspond to zero-emission buildings, and the letter G shall correspond to the very worst-performing buildings in the national building stock at  the  time  of  the  introduction  of  the  scale.  Member  States  that,  on  29  May  2026,  already  designate  zero-emission buildings  as  'A0'  may continue  to  use  that  designation  instead  of  class  A.  Member  States  shall  ensure  that  the  remaining classes (B to F or, where A0 is used, A to F) have an appropriate distribution of energy performance indicators among the energy  performance classes.

Member  States  may  define  an  A+  energy  performance  class  corresponding  to  buildings  with  a  maximum  threshold  for energy demand which is at least 20 % lower than the maximum threshold for zero-emission buildings, and which generates more renewable energy on-site annually than its total annual primary energy demand. For existing buildings renovated to A + class, Member States shall ensure that the life-cycle GWP is estimated and disclosed in the energy performance certificate of  the  building.

Member States which have rescaled their energy performance classes on or after 1 January 2019 and before 28 May 2024, may postpone the rescaling of  their  energy  performance  classes  until  31  December  2029.

- 3. Member States shall ensure  a  common visual identity  for  energy  performance  certificates  on  their  territory.
- 4. Member States shall ensure  the  quality,  reliability  and  affordability of  energy  performance  certificates.

Member States shall take measures to ensure that energy performance certificates are affordable and shall consider whether to  provide  financial  support  for  vulnerable  households.

Member  States  shall  ensure  that  energy  performance  certificates  are  issued  in  accordance  with  Article  20(1)  and  by independent experts on the basis of an on-site visit, which may be carried out, where appropriate, by virtual means with visual checks.  The energy performance certificates shall be clear and easily legible, available in a machine-readable format and in  accordance  with  the  template  in  Annex  V.

- 5. The energy performance certificate shall include recommendations for  the cost-effective improvement of the energy performance and the reduction of operational greenhouse gases emissions and the improvement of indoor environmental quality  of  a  building  or  building  unit,  unless  the  building  or  building  unit  already  achieves  at  least  energy  performance class  A.

The recommendations included in the energy performance certificate shall cover:

- (a) measures carried out in connection with a major renovation of the building envelope or  technical building system or systems;  and
- (b) measures  for  individual  building  elements  independent  of  a  major  renovation  of  the  building  envelope  or  technical building  system  or  systems.
- 6. Where  Member  States  provide  for  a  renovation  passport  to  be  drawn  up  and  issued  jointly  with  the  energy performance certificate pursuant to Article 12(3), the renovation passport shall substitute the recommendations pursuant to  paragraph  5  of  this  Article.
- 7. The  recommendations  included  in  the  energy  performance  certificate  shall  be  technically  feasible  for  the  specific building and shall provide an estimate for  the energy savings and the reduction of operational greenhouse gas emissions. They  may  provide  an  estimate  for  the  range  of  payback  periods  or  costs  and  benefits  over  its  economic  life  cycle  and information on available financial incentives, administrative and technical assistance, as well as financial benefits which are broadly  associated  with  the  achievement  of  the  reference  values.

- 8. The recommendations shall include an assessment of whether the heating systems, ventilation systems, air-conditioning systems and domestic hot-water systems can be adapted to operate at more efficient temperature settings, such as low temperature emitters for water based heating systems, including the required design of thermal power output and temperature and flow requirements.
- 9. The recommendations shall include an assessment of the remaining lifespan of the heating system or air-conditioning system. Where relevant, the recommendations shall indicate possible alternatives for the replacement of the heating system or  air-conditioning  system,  in  line  with  the  2030  and  2050  climate  targets,  taking  into  account  local  and  system-related circumstances.
- 10. The energy performance certificate shall provide an indication as to where the owner or  tenant of  the building or building  unit  can  receive  more  detailed  information,  including  as  regards  the  cost-effectiveness  of  the  recommendations made  in  the  energy  performance  certificate.  The  evaluation  of  cost-effectiveness  shall  be  based  on  a  set  of  standard conditions,  such  as  the  assessment  of  energy  savings  and  underlying  energy  prices  and  a  preliminary  cost  forecast.  In addition, it shall contain information on the steps to be taken to implement the recommendations, the contact information of relevant one-stop shops and, where relevant, on financial support options. Other information on related topics, such as energy  audits  or  incentives  of  a  financial  or  other  nature  and  financing  possibilities,  or  advice  on  how  to  increase  the climate resilience  of  the  building,  may  also  be  provided  to  the  owner  or  tenant  of  the  building  or  building  unit.
- 11. Certification  for  building  units  may  be  based:
- (a) on a  common certification  of  the  whole  building;  or
- (b) on  the  assessment  of  another  representative  building  unit  with  the  same  energy-relevant  characteristics  in  the  same building.
- 12. Certification for single-family houses may be based on the assessment of another representative building of similar design and size with a similar actual energy performance quality if such correspondence can be guaranteed by the expert issuing  the  energy  performance  certificate.
- 13. The validity of the energy performance certificate shall not exceed 10 years. Member States shall ensure that, where a  building  was  issued  a  energy  performance  certificate  below  level  C,  building  owners  are  invited  to  a  one-stop  shop  to receive  renovation  advice  on  whichever  of  the  following  is  the  earlier:
- (a) immediately after  the  energy  performance  certificate  of  the  building  expires;  or
- (b) five  years  after  the  issuance  of  the  energy  performance  certificate.
- 14. Member States shall make simplified procedures for updating an energy performance certificate available where only individual  elements  are  upgraded,  by  means  of  single  or  standalone  measures.

Member States shall make simplified procedures for updating an energy performance certificate available where measures identified in a renovation passport are put in place or where a building digital twin, other certified methods, or data from certified  tools  determining  the  energy  performance  of  a  building  are  used.

## Article  20

## Issue  of  energy  performance certificates

- 1. Member States shall ensure  that  a  digital  energy  performance  certificate  is  issued  for:
- (a) buildings or building units when they are constructed, when they have undergone a major renovation, when they are sold,  when  they  are  rented  out  to  a  new  tenant,  or  for  which  a  rental  contract  is  renewed;
- (b) existing  buildings  owned  or  occupied  by  public  bodies.

The requirement to issue an energy performance certificate shall not apply where a certificate, issued in accordance with either  Directive  2010/31/EU  or  this  Directive,  for  the  building  or  building  unit  concerned  is  available  and  valid.

Member States shall  ensure  that  a  paper  version  of  the  energy  performance  certificate  is  issued  on  request.

- 2. Member  States  shall  require  that,  when  buildings  or  building  units  are  constructed,  have  undergone  a  major renovation,  or  are  sold  or  rented  out,  or  when  rental  contracts  for  buildings  or  building  units  are  renewed,  the  energy performance certificate is  shown to the  prospective  tenant  or  buyer  and  handed  over  to  the  buyer  or  tenant.
- 3. Where a building is sold or  rented out in advance of construction or  major renovation, Member States may require the seller to provide an assessment of its future energy performance, as a derogation from paragraphs 1 and 2; in that case, the energy performance certificate shall be issued at the latest once the building has been constructed or renovated and shall reflect  the  as-built  state.
- 4. Member States  shall  require  that  buildings  or  buildings  units  which  are  offered  for  sale  or  for  rent  have  an  energy performance certificate, and that the energy performance indicator and class of  the energy performance certificate of  the building  or  the  building  unit,  as  applicable,  is  stated  in  online  and  offline  advertisements,  including  in  property  search portal  websites.

Member States shall  carry out  sample  checks  or  other  controls  to  ensure  compliance  with  these  requirements.

- 5. The provisions of this Article shall be implemented in accordance with applicable national rules on joint ownership or  common property.
- 6. Member  States  may  exclude  the  categories  of  building  referred  to  in  Article  5(3),  points  (b),  (c)  and  (e),  from  the application of paragraphs 1, 2, 4 and 5 of this Article. Member States which chose to exclude from the obligations of this Article by 28 May 2024, residential buildings which are used or intended to be used for either less than four months of the year or, alternatively, for a limited annual time of use and with an expected energy consumption of  less than 25 % of what would be the result of all-year  use,  may continue  to  do  so.
- 7. The  possible  effects  of  energy  performance  certificates  in  terms  of  legal  proceedings,  if  any,  shall  be  decided  in accordance with national rules.
- 8. Member States shall ensure that all energy performance certificates issued are uploaded to the database for the energy performance  of  buildings  referred  to  in  Article  22.  The  upload  shall  contain  the  full  energy  performance  certificate, including all  necessary  data  required  for  the  calculation  of  the  energy  performance  of  the  building.

## Article  21

## Display of energy performance certificates

- 1. Member States shall take measures to ensure that, where a building for  which an energy performance certificate has been issued in accordance with Article 20(1) is occupied by public bodies and frequently visited by the public, the energy performance certificate is  displayed  in  a  prominent  place  clearly  visible  to  the  public.
- 2. Member States shall require that in a non-residential building for  which an energy performance certificate has been issued in accordance with Article 20(1), the energy performance certificate is displayed in a prominent and clearly visible place.
- 3. The provisions of paragraphs 1 and 2 do not include an obligation to display the recommendations included in the energy  performance certificate.

## Article  22

## Databases for  the energy performance of buildings

- 1. Each Member State shall set up a national database for the energy performance of buildings which allows data to be gathered on the energy performance of individual buildings and on the overall energy performance of the national building stock.  Such  databases  may consist  of  a  set  of  interconnected  databases.

The  database  shall  allow  data  to  be  gathered  from  all  relevant  sources  related  to  energy  performance  certificates, inspections,  the  renovation passport,  the  smart  readiness  indicator and  the  calculated or  metered energy consumption of the  buildings  covered.  In  order  to  populate  the  database,  building  typologies  may  also  be  gathered.  Data  may  also  be gathered  and  stored  on  both  operational  and  embodied  emissions  and  life-cycle  GWP.

- 2. The  aggregated  and  anonymised data  of  building  stock  shall  be  made  publicly  available,  in  compliance  with  Union and  national  data  protection  rules.  The  data  stored  shall  be  machine-readable  and  accessible  via  an  appropriate  digital interface. Member States shall ensure easy and free-of-charge access to the full energy performance certificate for building owners,  tenants  and  managers  and  to  financial  institutions  as  regards  the  buildings  in  their  investment  and  lending portfolios,  and,  upon  permission  from  the  owner,  also  to  independent  experts.  For  buildings  offered  for  rent  or  sale, Member States shall ensure access to the full energy performance certificate for prospective tenants or buyers that have been authorised  by  the  owner  of  the  building.
- 3. Member States shall ensure that local authorities have access to relevant data on the energy performance of buildings on  their  territory  as  required  to  facilitate  drafting  of  heating  and  cooling  plans  and  include  operational  geographic information systems and the related databases, in accordance with Regulation (EU) 2016/679. Member States shall support the  local  authorities  in  obtaining  necessary  resources  for  data  and  information  management.
- 4. Member  States  shall  make  publicly  available  information  on  the  share  of  buildings  in  the  national  building  stock covered by energy performance certificates and aggregated or anonymised data on the energy performance, including the energy  consumption,  and,  where  available,  the  life-cycle  GWP  of  the  buildings  covered.  The  public  information  shall  be updated at least  twice  per  year.  Member  States  shall  make  anonymised or  aggregated  information  available  to public  and research institutions  such  as  national  statistical  institutes,  upon  request.
- 5. At least once per year, Member States shall ensure the transfer of the information in the national database to the EU Building  Stock  Observatory.  Member  States  may  transfer  the  information  more  frequently.
- 6. The Commission shall adopt implementing acts to establish common templates for the transfer of the information to the  EU  Building  Stock  Observatory.  The  first  such  implementing act  shall  be  adopted  by  30  June  2025.

Those implementing acts shall  be  adopted  in  accordance  with  the  examination procedure  referred  to in  Article  33(3).

- 7. For the purpose of ensuring coherence and consistency of information, Member States shall ensure that the national database  for  the  energy  performance  of  buildings  is  interoperable  and  integrated  with  other  administrative  databases containing information on buildings, such as the national building cadastre or land registry and digital building logbooks.

## Article  23

## Inspections

- 1. Member States shall lay down the necessary measures to establish regular inspections of the accessible parts of heating systems,  ventilation  systems  and  air-conditioning  systems,  including  any  combination  thereof,  with  an  effective  rated output  of  over  70  kW.  The  effective  rating  of  the  system  shall  be  based  on  the  sum  of  the  rated  output  of  the  heat generators and  cooling  generators.
- 2. Member  States  may  establish  separate  inspection  schemes  for  the  inspections  of  residential  and  non-residential systems.
- 3. Member States may set different inspection frequencies depending on the type and effective rated output of the system whilst taking into account the costs of the inspection of the system and the estimated energy cost savings that may result from the inspection. Systems shall be inspected at least every five years. Systems with generators of an effective rated output of  more  than  290  kW  shall  be  inspected  at  least  every  three  years.
- 4. The inspection shall include the assessment of the generator or generators, circulation pumps and, where appropriate, components of  ventilation  systems,  air  and  water  distribution  systems,  hydronic  balancing  systems  and  control  systems. Member States may include in the inspection schemes any additional building systems identified  under  Annex I.

The inspection shall include an assessment of the efficiency and sizing of the heat and cooling generator or generators and of the main components thereof compared with the requirements of the building and shall consider the capabilities of the system to optimise its performance  under typical or average operating conditions, using available energy-saving technologies, and under changing conditions due to use variation. Where relevant, the inspection shall assess the feasibility of the system to operate under different and more efficient temperature settings, such as at low temperature for water-based heating systems, including via the design of thermal power output and temperature and flow requirements, while ensuring the safe operation of the system. The inspection shall, where relevant, include a basic assessment of the feasibility to reduce on-site  use  of  fossil  fuels,  for  example  by  integrating  renewable  energy,  changing  energy  source  or  replace  or  adjust  the existing  systems.

Where a ventilation system is installed, its sizing and its capabilities to optimise its performance under  typical or average operating  conditions  relevant  for  the  specific  and  current  use  of  the  building  shall  also  be  assessed.

Where no changes have been made to the system or to the requirements of the building following an inspection carried out pursuant  to  this  Article,  Member  States  may  choose  not  to  require  the  assessment  of  the  main  component  sizing  or  the assessment of operation  under  different  temperatures  to  be  repeated.

- 5. Technical  building  systems  that  are  explicitly  covered  by  an  agreed  energy  performance  criterion  or  a  contractual arrangement specifying an agreed level of energy efficiency improvement, such as energy performance contracting, or that are operated by a utility or network operator and therefore subject to performance monitoring measures on the system side, shall be exempt from the requirements laid down in paragraph 1, provided that the overall impact of such an approach is equivalent  to  that  resulting  from  paragraph  1.
- 6. Where the overall impact is equivalent to that resulting from paragraph 1, Member States may opt to take alternative measures  such  as  financial  support  or  the  provision  of  advice  to  users  concerning  the  replacement  of  generators,  other modifications  to  the  system  and  alternative  solutions  to  assess  the  performance,  efficiency  and  appropriate  size  of  those systems.

Before applying the alternative measures referred to in the first subparagraph of this paragraph, each Member State shall, by means of submitting a report to the Commission, document the equivalence of the impact of those measures to the impact of  the  measures  referred  to  in  paragraph  1,  including  in  terms  of  energy  savings  and  greenhouse  gas  emissions.

- 7. Buildings that comply with Article 13(10) or (11) shall be exempt from the requirements laid down in paragraph 1 of this  Article.
- 8. Member States  shall  put  in  place  inspection  schemes  or  alternative  measures  such  as  digital  tools  and  checklists  to certify that the delivered construction and renovation works meet the designed energy performance and are compliant with the  minimum energy performance requirements laid down in the building codes or equivalent regulations.
- 9. Member States  shall  include  a  summarised  analysis  of  the  inspection  schemes  and  their  results  as  an  annex  to  the national  building  renovation  plan  referred  to  in  Article  3.  Member  States  that  have  chosen  the  alternative  measures indicated  in  paragraph  6  of  this  Article  shall  include  a  summarised  analysis  and  the  results  of  the  alternative  measures.

## Article  24

## Reports on the inspection of heating systems, ventilation systems and air-conditioning systems

- 1. An inspection report shall be issued after each inspection of a heating system, ventilation system or air-conditioning system.  The  inspection  report  shall  contain  the  result  of  the  inspection  performed  in  accordance  with  Article  23  and include  recommendations for  the  cost-effective  improvement of  the  energy  performance  of  the  inspected  system.

Those recommendations may be based on a comparison of the energy performance of the system inspected with that of the best  available  feasible  system,  using  energy-saving  technologies,  and  a  system  of  similar  type  for  which  all  relevant components  achieve  the  level  of  energy  performance  required  by  the  applicable  law.  The  recommendations  shall,  where relevant,  include  the  results  from  the  basic  assessment  of  the  feasibility  to  reduce  on-site  use  of  fossil  fuels.

The inspection report shall indicate any safety issue that was detected during inspection. However, the author of the report shall  not  be  considered  to  be  liable  in  relation  to  the  detection  or  indication  of  any  such  safety  issues.

- 2. The inspection  report  shall  be  handed  over  to  the  owner  or  tenant  of  the  building  or  building  unit.
- 3. The inspection report shall be uploaded into the national database for the energy performance of buildings pursuant to  Article  22.

## Article  25

## Independent experts

- 1. Member States  shall  ensure  that  the  energy  performance  certification  of  buildings,  the  establishment  of  renovation passports, the smart readiness assessment and the inspection of heating systems, ventilation systems and air-conditioning systems are carried out in an independent manner by qualified or certified experts, whether operating in a self-employed capacity or  employed  by public  bodies  or  private enterprises.

Experts shall be certified in accordance with Article 28 of Directive (EU) 2023/1791 taking into account their competence.

- 2. Member  States  shall  make  available  to  the  public  information  on  training  and  certifications.  Member  States  shall ensure  that  either  regularly  updated  lists  of  qualified  or  certified  experts  or  regularly  updated  lists  of  certified  companies which offer  the  services  of  such  experts  are  made  available  to  the  public.

## Article  26

## Certification of  building  professionals

- 1. Member  States  shall  ensure  the  appropriate  level  of  competence  for  building  professionals  carrying  out  integrated renovation  works  in  accordance  with  Article  3  of,  and  Annex  II  to,  this  Directive  and  with  Article  28  of  Directive  (EU) 2023/1791.
- 2. Where appropriate and feasible, Member States shall ensure that certification or equivalent qualification schemes are available  for  providers  of  integrated  renovation  works  where  this  is  not  covered  by  Article  18(3)  of  Directive  (EU) 2018/2001 or Article 28 of Directive (EU)  2023/1791.

## Article  27

## Independent control system

- 1. Member States  shall  ensure  that  independent  control  systems  for  energy  performance  certificates  are  established  in accordance with Annex VI, and that independent control systems for renovation passports, smart readiness indicators and reports  on  the  inspection  of  heating  systems,  ventilation  systems  and  air-conditioning  systems  are  established.  Member States  may  establish  separate  systems  for  the  control  of  energy  performance  certificates,  renovation  passports,  smart readiness  indicators  and  reports  on  the  inspection  of  heating  systems,  ventilation  systems  and  air-conditioning  systems.
- 2. The Member States may delegate the responsibilities  for  implementing the  independent control  systems.

Where  the  Member  States  decide  to  do  so,  they  shall  ensure  that  the  independent  control  systems  are  implemented  in compliance with Annex VI.

- 3. Member  States  shall  require  the  energy  performance  certificates,  the  renovation  passports,  the  smart  readiness indicators and the inspection reports referred to in paragraph 1 to be made available to the competent authorities or bodies on request.

## Article  28

## Review

The Commission, assisted by the Committee referred to in Article 33, shall review this Directive by 31 December 2028, in light  of  the  experience  gained  and  progress  made  during  its  application,  and,  if  necessary,  make  proposals.

As  part  of  that  review,  the  Commission  shall  assess  whether  the  application  of  this  Directive  in  combination  with  other legislative instruments addressing energy performance and greenhouse gas emissions from buildings, in particular through carbon pricing, deliver sufficient progress towards achieving a fully decarbonised, zero-emission building stock by 2050, or whether further binding measures at Union level, in particular mandatory minimum energy performance standards across the whole building stock, need to be introduced, including in order to ensure that the values for 2030 and 2035 set out in Article 9(2) can be achieved. The Commission shall also assess the national roadmaps and in particular  the planned limit values  for  the  life-cycle  GWP  of  new  buildings  pursuant  to  Article  7(4)  and  shall  consider  whether  additional  measures promoting a sustainable built environment are needed. The Commission shall also examine in what manner Member States could apply integrated district or neighbourhood approaches in Union building and energy efficiency policy, while ensuring that each building meets the minimum energy performance requirements, for example by means of integrated renovation programmes  and  overall  renovation  schemes  applying  to  a  number  of  buildings  in  a  spatial  context  instead  of  a  single building. The Commission shall also assess whether alternative indicators, such as final energy use and energy needs would be  better  suited  for  the  purposes  of  Annex  I.

## Article  29

## Information

- 1. Member  States  shall  prepare  and  carry  out  information  and  awareness-raising  campaigns.  They  shall  take  the necessary measures to inform the owners and tenants of buildings or building units and all relevant market actors, such as local and regional authorities and energy communities, of the different methods and practices that serve to enhance energy performance.  In  particular,  Member  States  shall  take  the  necessary  measures  to  provide  tailor-made  information  to vulnerable  households.  That  information  shall  also  be  made  available  to  local  authorities  and  civil  society organisations.
- 2. Member States shall in particular provide information to the owners or tenants of buildings on energy performance certificates, including their purpose and objectives, on cost-effective measures and, where appropriate, financial instruments, to improve the energy performance of the building, and on replacing fossil fuel boilers with more sustainable alternatives.  Member  States  shall  provide  the  information  through  accessible  and  transparent  advisory  tools  such  as renovation  advice  and  the  one-stop  shops  established  pursuant  to  Article  18,  paying  particular  attention  to  vulnerable households.

At the request of the Member States, the Commission shall assist Member States in staging information campaigns for the purposes of paragraph 1 and the first subparagraph of  this  paragraph,  which may  be  dealt  with  in  Union  programmes.

- 3. Member States shall ensure that guidance and training, including for under-represented groups, are made available, for those responsible for  implementing this Directive. Such guidance and training shall address the importance of improving energy  performance,  and  shall  enable  consideration  of  the  optimal  combination  of  improvements  in  energy  efficiency, reduction of greenhouse gas emissions, use of energy from renewable sources and use of district heating and cooling when planning,  designing,  building  and  renovating  industrial  or  residential  areas.  Such  guidance  and  training  may  also  address structural  improvements, adaptation to climate change, fire  safety, risks  related to intense seismic  activity, the  removal of hazardous substances including asbestos, air pollutant emissions (including fine particulate matter), indoor environmental quality  and  accessibility  for  persons  with  disabilities.  Member  States  shall  endeavour  to  put  in  place  measures  to  support training  for  local  and  regional  authorities,  renewable  energy  communities  and  other  relevant  actors,  such  as  citizen-led renovation  initiatives,  to  promote  the  objectives  of  this  Directive.
- 4. The Commission shall continuously improve its information services, in particular the website that has been set up as a  European  portal  for  energy  efficiency  in  buildings  directed  towards  citizens,  professionals  and  authorities,  in  order  to assist  Member  States  in  their  information  and  awareness-raising  efforts.  Information  displayed  on  that  website  might include links to relevant Union law and national, regional and local rules, links to Europa websites that display the National Energy  Efficiency  Action  Plans,  links  to  available  financial  instruments,  as  well  as  best  practice  examples  at  national, regional and local level, including with regard to the one-stop shops established pursuant to Article 18 of this Directive. In

the context of  the European Regional Development Fund, the Cohesion Fund and the Just Transition Fund established by Regulation (EU) 2021/1056 of the European Parliament and of the Council ( 33 ),  the Social Climate Fund, and the Recovery and  Resilience  Facility,  the  Commission  shall  continue  and  further  intensify  its  information  services  with  the  aim  of facilitating the use of available funds by providing assistance and information, including, in cooperation with the European Investment  Bank,  through  the  European  Local  Energy  Assistance  facility,  to  interested  stakeholders,  including  national, regional and local authorities, on funding possibilities, taking into account the latest changes in the regulatory framework.

## Article  30

## Consultation

In order  to facilitate the effective implementation of this Directive, Member States shall consult the stakeholders involved, including local and regional authorities, in accordance with the national law applicable and as relevant. Such consultation is of  particular  importance  for  the  application  of  Article  29.

## Article  31

## Adaptation of Annex I to technical progress

The  Commission  shall  adopt  delegated  acts  in  accordance  with  Article  32  to  amend  this  Directive  concerning  the adaptation  of  points  4  and  5  of  Annex  I  to  technical  progress.

## Article  32

## Exercise  of  the  delegation

- 1. The power to adopt delegated acts is conferred on the Commission subject to the conditions laid down in this Article.
- 2. The power to adopt delegated acts referred to in Articles 6, 7, 15, 17 and 31 shall be conferred on the Commission for  an  indeterminate  period  of  time  from  28  May  2024.
- 3. The  delegation  of  power  referred  to  in  Articles  6,  7,  15,  17  and  31  may  be  revoked  at  any  time  by  the  European Parliament or by the Council. A decision to revoke shall put an end to the delegation of the power specified in that decision. It  shall take effect the day following the publication of the decision in the Official Journal of the European Union or at a later date  specified  therein.  It  shall  not  affect  the  validity  of  any  delegated  acts  already  in  force.
- 4. Before adopting a delegated act, the Commission shall consult experts designated by each Member State in accordance with  the  principles  laid  down  in  the  Interinstitutional  Agreement  of  13  April  2016  on  Better  Law-Making.
- 5. As soon as it adopts a delegated act, the Commission shall notify it simultaneously to the European Parliament and to the  Council.
- 6. A delegated  act  adopted  pursuant  to  Article  6,  7,  15,  17  or  31  shall  enter  into  force  only  if  no  objection  has  been expressed either by the European Parliament or the Council within a period of two months of notification of that act to the European Parliament and the Council or if, before the expiry of that period, the European Parliament and the Council have both informed the Commission that they will not object. That period shall be extended by two months at the initiative of the  European  Parliament or  of  the  Council.

## Article  33

## Committee procedure

- 1. The  Commission  shall  be  assisted  by  a  committee.  That  committee  shall  be  a  committee  within  the  meaning  of Regulation  (EU)  No  182/2011  of  the  European  Parliament  and  of  the  Council ( 34 ).
- ( 33 ) Regulation (EU) 2021/1056 of the European Parliament and of the Council of 24 June 2021 establishing the Just Transition Fund (OJ  L  231,  30.6.2021,  p.  1).
- ( 34 ) Regulation  (EU)  No  182/2011  of  the  European  Parliament  and  of  the  Council  of  16  February  2011  laying  down  the  rules  and general principles concerning mechanisms for control by Member States of the Commission's exercise of implementing powers (OJ L  55,  28.2.2011,  p.  13).

- 2. Where reference  is  made  to  this  paragraph,  Article  4  of  Regulation  (EU)  No  182/2011  shall  apply.
- 3. Where reference  is  made  to  this  paragraph,  Article  5  of  Regulation  (EU)  No  182/2011  shall  apply.

## Article  34

## Penalties

Member States shall lay down the rules on penalties applicable to infringements of national provisions adopted pursuant to this Directive and shall take all measures necessary to ensure that they are implemented. The penalties provided for must be effective,  proportionate  and  dissuasive.  Member  States  shall,  without  delay,  notify  the  Commission  of  those  rules  and  of those  measures  and  shall  notify  it,  without  delay,  of  any  subsequent  amendment  affecting  them.

## Article  35

## Transposition

- 1. Member States  shall  bring  into  force  the  laws,  regulations  and  administrative  provisions  necessary  to  comply  with Articles  1,  2  and  3,  5  to  29  and  32  and  Annexes  I,  II  and  III  and  V  to  X  by  29  May  2026.  They  shall  immediately communicate the text of  those  measures  and  a  correlation  table  to the  Commission.

Member  States  shall  bring  into  force  the  laws,  regulations  and  administrative  provisions  necessary  to  comply  with Article  17(15)  by  1  January  2025.

When Member States  adopt  those  measures,  they  shall  contain  a  reference  to  this  Directive  or  be  accompanied  by  such a reference on the occasion of their official publication. They shall also include a statement that references in existing laws, regulations and administrative provisions to the Directive repealed by this Directive shall be construed as references to this Directive.  Member  States  shall  determine  how  such  reference  is  to  be  made  and  how  that  statement  is  to  be  formulated.

- 2. Member  States  shall  communicate  to  the  Commission  the  text  of  the  main  provisions  of  national  law  which  they adopt  in  the  field  covered  by  this  Directive.

## Article  36

## Repeal

Directive  2010/31/EU,  as  amended  by  the  acts  listed  in  Part  A  of  Annex  IX,  is  repealed  with  effect  from  30  May  2026, without prejudice to the obligations of the Member States relating to the time-limits for the transposition into national law and the  dates  of  application  of  the  Directives  set  out  in  Part  B  of  Annex  IX.

References to the repealed Directive shall be construed as references to this Directive and shall be read in accordance with the  correlation  table  in  Annex  X.

## Article  37

## Entry into force and application

This  Directive  shall  enter  into  force  on  the  twentieth  day  following  that  of  its  publication  in  the Official  Journal  of  the European  Union .

Articles  30,  31,  33  and  34  shall  apply  from  30  May  2026.

## Article  38

## Addressees

This  Directive  is  addressed  to  the  Member  States.

Done at Strasbourg, 24 April 2024.

For  the  European  Parliament

The  President

R.  METSOLA

For  the  Council

The  President

M.  MICHEL

## Common general framework for  the calculation of  the energy performance of buildings

## (referred  to  in  Article  4)

- 1. The energy  performance  of a  building  shall  be  determined  on  the  basis  of  calculated  or  metered  energy  use  and  shall reflect  typical  energy  use  for  space  heating,  space  cooling,  domestic  hot  water,  ventilation,  built-in  lighting  and  other technical building systems. Member States shall ensure that the typical energy use is representative of actual operating conditions  for  each  relevant  typology  and  reflects  the  typical  user  behaviour.  Where  possible,  typical  energy  use  and typical  user  behaviour  shall  be  based  on  available  national  statistics,  building  codes  and  metered  data.

Where metered energy use is the basis for calculating the energy performance of buildings, the calculation methodology shall  be  capable  of  identifying  the  influence  of  the  behaviour  of  occupants  and  the  local  climate,  which  shall  not  be reflected in  the  result  of  the  calculation.  Metered  energy  use  for  the  purpose  of  calculating  the  energy  performance  of buildings  shall  require  readings  of  at  least  monthly  intervals  and  must  differentiate  between  energy carriers.

Member States may use metered energy consumption under typical operating conditions to verify the correctness of the calculated energy use and enable comparison between calculated and actual performance. Metered energy consumption for  the  purposes  of  verification  and  comparison  may  be  based  on  monthly  readings.

The  energy  performance  of  a  building  shall  be  expressed  by  a  numeric  indicator  of  primary  energy  use  per  unit  of reference floor area per year, in kWh/(m .y) for the purposes of both energy performance certification and compliance 2 with  minimum  energy  performance  requirements.  The  methodology  applied  for  the  determination  of  the  energy performance of a building  shall  be  transparent  and  open  to  innovation.

Member  States  shall  describe  their  national  calculation  methodology  on  the  basis  of  Annex  A  to  the  key  European standards  on  the  energy  performance  of  buildings,  namely  (EN)  ISO  52000-1,  (EN)  ISO  52003-1,  (EN)  ISO  52010-1, (EN) ISO 52016-1, (EN) ISO 52018-1, (EN) ISO 52120-1, EN 16798-1 and EN 17423 or superseding documents. This provision shall  not  constitute  a  legal  codification  of  those  standards.

Member  States  shall  take  the  necessary  measures  to  ensure  that,  where  buildings  are  supplied  by  district  heating  or cooling  systems,  the  benefits  of  such  supply  are  recognised  and  accounted  for  in  the  calculation  methodology,  in particular  the  renewable  energy  share,  through  individually certified  or  recognised  primary  energy  factors.

- 2. The energy needs and energy use for  space heating,  space  cooling,  domestic hot  water,  ventilation,  lighting  and  other technical building systems shall be calculated using monthly, hourly or sub-hourly time calculation intervals in order to account  for  varying  conditions  that  significantly  affect  the  operation  and  performance  of  the  system  and  the  indoor conditions, and to optimise health, indoor air quality, including comfort levels, defined by Member States at national or regional  level.

Where product-specific regulations for  energy-related  products  adopted  under  Directive  2009/125/EC  include  specific product  information  requirements  for  the  purpose  of  calculating  energy  performance  and  life-cycle  GWP  under  this Directive,  national  calculation  methods  shall  not  require  additional  information.

The  calculation  of  primary  energy  shall  be  based  on  regularly  updated  and  forward-looking  primary  energy  factors (distinguishing non-renewable, renewable and total) or weighting factors per energy carrier, which have to be recognised by  the  national  authorities  and  taking  into  account  the  expected  energy  mix  on  the  basis  of  its  national  energy  and climate plan. Those primary energy factors or weighting factors may be based on national, regional or local information. Primary energy factors or weighting factors may be set on an annual, seasonal, monthly, daily or hourly basis or on more specific  information  made  available  for  individual  district  systems.

Primary energy factors or weighting factors shall be defined by Member States. The choices made and data sources shall be  reported  according  to  EN  17423  or  any  superseding  document.  Member  States  may  opt  for  an  average  Union primary energy factor for electricity established pursuant to Directive (EU) 2023/1791 instead of a primary energy factor reflecting  the  electricity  mix  in  the  country.

- 3. For  the  purpose  of  expressing  the  energy  performance  of  a  building,  Member  States  shall  define  additional  numeric indicators  of  total,  non-renewable  and  renewable  primary  energy  use,  and  of  operational  greenhouse  gas  emissions produced in kgCO eq/(m 2 .y). 2
- 4. The methodology shall be laid down taking  into consideration  at  least  the  following  aspects:
- (a) the  following actual  thermal  characteristics  of  the  building  including  its  internal  partitions:
- (i) thermal capacity;
- (ii) insulation;
- (iii) passive  heating;
- (iv) cooling elements;
- (v) thermal bridges;
- (b) heating  installation  and  domestic  hot-water  supply,  including  their  insulation  characteristics;
- (c) capacity of  installed  on-site  renewable  energy  generation  and  energy  storage;
- (d) air-conditioning  installations;
- (e) natural  and  mechanical  ventilation  which  may  include  air-tightness  and  heat  recovery;
- (f) built-in  lighting  installation  (mainly  in  the  non-residential  sector);
- (g) the  design,  positioning  and  orientation  of  the  building,  including  outdoor  climate;
- (h) passive  solar  systems  and  solar  protection;
- (i) indoor  climatic  conditions,  including  the  designed  indoor  climate;
- (j) internal  loads;
- (k) building automation and control systems and their capabilities to monitor, control and optimise energy performance.
- 5. The positive  influence  of  the  following  aspects  shall  be  taken  into  account:
- (a) local solar exposure conditions, active solar systems and other heating and electricity systems on the basis of energy from renewable sources;
- (b) electricity  produced  by cogeneration;
- (c) district  or  block  heating  and  cooling  systems;
- (d) natural  lighting;
- (e) electrical  storage  systems;
- (f) thermal storage systems.
- 6. For the purposes of the calculation of the energy performance of buildings, buildings should be adequately classified into the  following  categories:
- (a) single-family  houses  of  different  types;
- (b) apartment blocks;

- (c) offices;
- (d) educational  buildings;
- (e) hospitals;
- (f) hotels  and  restaurants;
- (g) sports  facilities;
- (h) wholesale  and  retail  trade  services  buildings;
- (i) other  types  of  energy-consuming  buildings.

## Template for  the national building  renovation plans

## (referred  to  in  Article  3)

| This Directive Article 3                      | Mandatory indicators                                                                                                                                                                                                                                                                                                                                                             | Optional indicators                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|-----------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| (a) Overview of the na- tional building stock | Number of buildings and total floor area (m 2 ): - per building type (including public buildings and social housing) - per energy performance class - nearly zero-energy buildings - worst-performing buildings (including a defini- tion) - the 43 % worst-performing residential buildings - estimation of the share of buildings exempted pursuant to Article 9(6), point (b) | Number of buildings and total floor area (m 2 ): - per building age - per building size - per climatic zone - demolition (number and total floor area (m 2 ))                                                                                                                                                                                                                                                                                                                     |
|                                               | Number of energy performance certificates: - per building type (including public buildings) - per energy performance class                                                                                                                                                                                                                                                       | Number of energy performance certificates: - per construction period                                                                                                                                                                                                                                                                                                                                                                                                              |
|                                               | Annual renovation rates: number and total floor area (m 2 ) - per building type - to nearly zero-energy and/or to zero-emission building levels - per renovation depth (weighted average renova- tion) - public buildings                                                                                                                                                        |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
|                                               | Primary and final annual energy consumption (ktoe): - per building type - per end use Energy savings (ktoe): - residential buildings - non-residential buildings - public buildings Average primary energy use in kWh/(m 2 .y) for residential buildings Share of renewable energy in the building sector (MW installed or GWh generated): - for different uses                  | Reduction in energy costs (EUR) per household (average) Primary energy use of a building corresponding to the top 15 % (substantial contribution threshold) and the top 30 % (do no significant harm threshold) of the national building stock, as per Delegated Regula- tion (EU) 2021/2139 Share of heating system in the building sector per boiler/heating system type Share of renewable energy in the building sector (MW installed or GWh generated): - on-site - off-site |

| This Directive Article 3   | Mandatory indicators                                                                                                                                                                                                                                        | Optional indicators                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|----------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                            | Annual operational greenhouse gas emissions (kgCO 2 eq/(m 2 .y): - per building type Annual operational greenhouse gas emission reduc- tion (kgCO 2 eq/(m 2 .y): - per building type                                                                        | Life-cycle GWP (kgCO 2 eq/m 2 ) in new buildings: - per building type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|                            | Market barriers and failures (description): - split incentives - capacity of construction and energy sector Evaluation of the capacities in the construction, energy efficiency and renewable energy sectors                                                | Market barriers and failures (description): - administrative - financial - technical - awareness - other Number of: - energy service companies - construction companies - architects and engineers - skilled workers - one-stop shops - SMEs in the construction/renovation sector - renewable energy communities and citizen-led renovation initiatives Projections of the construction workforce: - retiring architects/engineers/skilled workers - architects/engineers/skilled workers entering the market - young people in the sector - women in the sector Overview and forecast of the evolution of prices of construction materials and national market develop- |
|                            | Energy poverty (definition): - % of people affected by energy poverty - proportion of disposable household income spent on energy - population living in inadequate dwelling condi- tions (e.g. leaking roof) or with inadequate thermal comfort conditions |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |

| This Directive Article 3         | Mandatory indicators                                                                                                                                                                                                                                                                                                                                                                                                                     | Optional indicators                                                                               |
|----------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
|                                  | Primary energy factors: - per energy carrier - non-renewable primary energy factor - renewable primary energy factor - total primary energy factor                                                                                                                                                                                                                                                                                       |                                                                                                   |
|                                  | Definition of nearly-zero energy building for new and existing buildings                                                                                                                                                                                                                                                                                                                                                                 | Overview of the legal and administrative framework                                                |
|                                  | Cost-optimal minimum energy performance require- ments for new and existing buildings                                                                                                                                                                                                                                                                                                                                                    |                                                                                                   |
| (b) Roadmap for 2030, 2040, 2050 | Targets for annual renovation rates: number and total floor area (m 2 ): - per building type - worst-performing buildings - the 43 % worst-performing residential buildings Information pursuant to Article 9(1): - criteria to exempt individual non-residential buildings - estimated share of exempted non-residential buildings - estimation of equivalent energy performance improvements due to exempted non-residential buildings | Targets for expected share (%) of renovated buildings: - per building type - per renovation depth |
|                                  | Targets for expected primary and final annual energy consumption (ktoe): - per building type - per end use Expected energy savings: - per building type Targets for the increase in the share of renewable energy in accordance with Article 15a of Directive (EU) 2018/2001 Numerical targets for the deployment of solar energy                                                                                                        | Share of energy from renewable sources in the building sector (MW installed or GWh generated)     |

| This Directive Article 3                                        | Mandatory indicators                                                                                                                                                                                                                                                                        | Optional indicators                                                                                                                                                                                                                                                                                                                      |
|-----------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                                 | Targets for expected operational greenhouse gas emissions (kgCO 2 eq/(m 2 .y): - per building type Targets for expected operational greenhouse gas emission reduction (%): - per building type                                                                                              | Split between emissions covered by Chapter III [stationary installations], Chapter IVa [emissions trading system for buildings, road transport and additional sectors] of Directive 2003/87/EC, and other stock; Targets for expected whole-life-cycle greenhouse gas emission (kgCO 2 eq/(m 2 .y) in new buildings: - per building type |
|                                                                 | Expected wider benefits: - % reduction of people affected by energy poverty                                                                                                                                                                                                                 | - Creation of new jobs - Increase in GDP (share and billion euros)                                                                                                                                                                                                                                                                       |
|                                                                 | The Member State's contribution to the Union's energy efficiency targets in accordance with Article 4 of Directive (EU) 2023/1791 attributable to its building stock's renovation (share and figure in ktoe)                                                                                |                                                                                                                                                                                                                                                                                                                                          |
| (c) Overview of imple- mented and planned policies and measures | Policies and measures with regard to the following elements:                                                                                                                                                                                                                                | Policies and measures with regard to the following elements:                                                                                                                                                                                                                                                                             |
| (c) Overview of imple- mented and planned policies and measures | trigger points in the life cycle of the building; (b) national minimum energy performance stan- dards pursuant to Article 9 and other policies and actions to target the worst-performing segments of the national building stock, includ- ing safeguards as referred to in Article 17(19); | (b) the promotion of the energy services market; (c) the increase in fire safety; (d) the increase in resilience against disaster risks, including risks related to intense seismic activity; (e) the removal of hazardous substances                                                                                                    |
| (c) Overview of imple- mented and planned policies and measures | (c) the promotion of deep renovation of buildings, including staged deep renovation;                                                                                                                                                                                                        | including asbestos;                                                                                                                                                                                                                                                                                                                      |
| (c) Overview of imple- mented and planned policies and measures | (d) empowering and protecting vulnerable custo- mers and the alleviation of energy poverty, including policies and measures pursuant to Article 24 of Directive (EU) 2023/1791, and housing affordability;                                                                                  | (f) accessibility for persons with disabilities;                                                                                                                                                                                                                                                                                         |
| (c) Overview of imple- mented and planned policies and measures |                                                                                                                                                                                                                                                                                             | (g) the role of renewable energy communities and citizen energy communities in district and neighbourhood approaches;                                                                                                                                                                                                                    |
| (c) Overview of imple- mented and planned policies and measures | (e) the creation of one-stop shops or similar mechanisms pursuant to Article 18 for the provision of technical, administrative and financial advice and assistance;                                                                                                                         | (h) addressing mismatches in human capacities; and (i) addressing the improvement of indoor                                                                                                                                                                                                                                              |
| (c) Overview of imple- mented and planned policies and measures |                                                                                                                                                                                                                                                                                             | environ- mental quality.                                                                                                                                                                                                                                                                                                                 |

| This Directive Article 3   | Mandatory indicators           | Optional                                                                                                                                                                                                                                                                                                                                                                                 | indicators                                                                                 |
|----------------------------|--------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|
|                            | (f)                            | the decarbonisation of heating and cooling, including through district heating and cooling networks, and the phasing out of fossil fuels in heating and cooling with a view to a complete phasing out of fossil fuel boilers by 2040;                                                                                                                                                    | For all policies and measures: - administrative resources and capacities                   |
|                            | (g)                            | prevention and high-quality treatment of con- struction and demolition waste in accordance with Directive 2008/98/EC, in particular as regards the waste hierarchy, and the objectives of the circular economy;                                                                                                                                                                          | - area(s) covered - worst-performing                                                       |
|                            | (h)                            | the promotion of renewable energy sources in buildings in line with the indicative target for the share of energy from renewable sources in the building sector laid down in Article 15a(1) of Directive (EU) 2018/2001;                                                                                                                                                                 | - minimum energy performance standards - energy poverty, social housing                    |
|                            | (i)                            | the deployment of solar energy installations on buildings;                                                                                                                                                                                                                                                                                                                               | - public buildings                                                                         |
|                            | (j)                            | the reduction of whole-life-cycle greenhouse gas emissions for the construction, renovation, operation and end of life of buildings, and the uptake of carbon removals;                                                                                                                                                                                                                  | - non-residential                                                                          |
|                            | (k)                            | the promotion of district and neighbourhood approaches and integrated renovation pro- grammes at district level, which may address issues such as energy, mobility, green infra- structure, waste and water treatment and other aspects of urban planning and may take into account local and regional resources, circularity and sufficiency;                                           | - industry - renewable energy sources - phasing out of fossil fuels in heating and cooling |
|                            | (l)                            | the improvement of buildings owned by public bodies, including policies and measures pur- suant to Articles 5, 6 and 7 of Directive (EU) 2023/1791;                                                                                                                                                                                                                                      | - whole-lifecycle greenhouse gas emissions - circular economy and waste                    |
|                            |                                | (m) the promotion of smart technologies and infrastructure for sustainable mobility in build- ings; - one-stop                                                                                                                                                                                                                                                                           | shops - renovation passports                                                               |
|                            | (n) addressing market barriers | and market failures;                                                                                                                                                                                                                                                                                                                                                                     |                                                                                            |
|                            | (o)                            | addressing skills gaps and promoting education, targeted training, upskilling and reskilling in the construction sector and energy efficiency and renewable energy sectors (whether public or private), with a view to ensuring that there is a sufficient workforce with the appropriate level of skills corresponding to the needs in the building sector, with a special focus on the | - sustainable mobility in buildings - district and neighbourhood approaches                |
|                            | (p)                            | underrepresented groups; - skills,                                                                                                                                                                                                                                                                                                                                                       | training awareness campaigns and advisory tools                                            |
|                            |                                | awareness-raising campaigns and other advisory tools; and                                                                                                                                                                                                                                                                                                                                | -                                                                                          |

| This Directive Article 3                                                                          | Mandatory indicators                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | Optional indicators   |
|---------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------|
|                                                                                                   | (q) promotion of modular and industrialised solu- tions for construction and building renovation. For all policies and measures: - name of policy or measure - short description (precise scope, objective and conditions of operation) - quantified objective - type of policy or measure (such as legislative; economic; fiscal; training, awareness) - planned budget and funding sources - entities responsible for implementing the policy - expected impact - status of implementation - date of entry into force - implementation period |                       |
| (d) Outline of the invest- ment needs, the bud- getary sources and the administrative re- sources | - total investment needs for 2030, 2040, 2050 (million EUR) - public investments (million EUR) - private investments (million EUR)                                                                                                                                                                                                                                                                                                                                                                                                              |                       |
| (e) Thresholds of new and renovated zero-emis- sion buildings, referred to in Article 11          | - operational greenhouse gas emissions thresholds of new zero-emission buildings; - operational greenhouse gas emissions thresholds of renovated zero-emission buildings; - annual primary energy use thresholds of new zero-emission buildings; - annual primary energy use thresholds of reno- vated zero-emission buildings                                                                                                                                                                                                                  |                       |
| (f) Minimum energy per- formance standards for non-residential build- ings                        | - maximum energy performance thresholds, pur- suant to Article 9(1)                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |                       |
| (g) National trajectory for the progressive renova- tion of the residential building stock        | - the national trajectory for the progressive renovation of the residential building stock, including the 2030 and 2035 milestones for average primary energy use in kWh/(m 2 .y), pursuant to Article 9(2)                                                                                                                                                                                                                                                                                                                                     |                       |

## Calculation of  life-cycle  GWP of  new buildings pursuant to Article 7(2)

For the calculation  of the life-cycle GWP  of  new  buildings  pursuant  to  Article  7(2),  the  total  life-cycle  GWP  is communicated as a numeric indicator for each life-cycle stage expressed as kgCO eq/(m ) (of useful floor area) calculated 2 2 over  a  reference  study  period  of  50  years.  The  data  selection,  scenario  definition  and  calculations  shall  be  carried  out  in accordance  with  EN  15978  (EN  15978:2011  Sustainability  of  construction  works.  Assessment  of  environmental performance  of  buildings. Calculation method)  and  taking  into  account  any  subsequent  standard  relating  to  the sustainability  of  construction  works  and  the  calculation  method  for  the  assessment  of  environmental  performance  of buildings. The scope of building elements and technical equipment is as defined in the Level(s) common EU framework for indicator  1.2.  Where  a  national  calculation  tool  or  method  exists,  or  is  required  for  making  disclosures  or  for  obtaining building permits, that tool or method may be used to provide the required disclosure. Other calculation tools or methods may be used if they fulfil the minimum criteria established by the Level(s) common EU framework. Data regarding specific construction products calculated in accordance with Regulation (EU) No 305/2011 of the European Parliament and of the Council ( )  shall  be  used  when  available. 1

( 1 ) Regulation (EU) No 305/2011 of the European Parliament and of the Council of 9 March 2011 laying down harmonised conditions for  the  marketing  of  construction  products  and  repealing  Council  Directive  89/106/EEC  (OJ  L  88,  4.4.2011,  p.  5).

## Common general framework for rating the smart readiness of buildings

- 1. The Commission shall establish the definition of the smart readiness indicator and a methodology by which it is to be calculated,  in  order  to  assess  the  capabilities  of  a  building  or  building  unit  to  adapt  its  operation  to  the  needs  of  the occupant and of  the  grid  and  to  improve  its  energy  efficiency  and  overall  performance.

The smart readiness indicator shall cover features for enhanced energy savings, benchmarking and flexibility, enhanced functionalities  and  capabilities  resulting  from  more  interconnected  and  intelligent  devices.

The methodology shall take into account features  such  as  the  possible  existence  of a  digital  twin  of  the  building.

- The  methodology  shall  take  into  account  features  such  as  smart  meters,  building  automation  and  control  systems, self-regulating  devices  for  the  regulation  of  indoor  air  temperature,  built-in  home  appliances,  recharging  points  for electric vehicles, energy storage and detailed functionalities and the interoperability of those features, as well as benefits for  the  indoor  climate  conditions,  energy  efficiency,  performance  levels  and  enabled  flexibility.
- 2. The  methodology  shall  rely  on  the  following  key  functionalities  relating  to  the  building  and  its  technical  building systems:
- (a) the  ability  to  maintain  energy  performance  and  operation  of  the  building  through  the  adaptation  of  energy consumption for example through use of energy from renewable sources;
- (b) the ability to adapt its operation mode in response to the needs of  the occupant while paying due attention to the availability  of  user-friendliness,  maintaining  healthy  indoor  climate  conditions  and  the  ability  to  report  on  energy use;
- (c) the flexibility of a building's overall energy demand, including its ability to enable participation in active and passive as well as implicit and explicit demand response, through its energy storage and release of energy back to the grid, for  example  through  flexibility  and  load  shifting  capacities;  and
- (d) the ability to improve its energy efficiency and overall performance through the use of energy-saving technologies.
- 3. The methodology may further  take into account:
- (a) the  interoperability  between  systems  (smart  meters,  building  automation  and  control  systems,  built-in  home appliances,  self-regulating  devices  for  the  regulation  of  indoor  air  temperature  within  the  building  and  indoor  air quality  sensors  and  ventilations);  and
- (b) the positive influence  of  existing communication  networks,  in  particular the existence of high-speed-ready in-building physical infrastructure, such as the voluntary 'broadband ready' label, and the existence of an access point for  buildings  with  multiple  residential  building  units,  in  accordance  with  Article  8  of  Directive  2014/61/EU  of  the European Parliament and of  the  Council ( ). 1
- 4. The methodology shall not negatively affect existing national energy performance certification schemes and shall build on related initiatives  at  national  level,  while  taking  into  account  the  principle  of occupant  ownership,  data  protection, privacy  and  security,  in  compliance  with  relevant  Union  data  protection  and  privacy  law  as  well  as  best  available techniques for  cyber  security.
- 5. The  methodology  shall  set  out  the  most  appropriate  format  of  the  smart  readiness  indicator  parameter  and  shall  be simple, transparent, and easily understandable for consumers, owners, investors and demand-response  market participants.

( 1 ) Directive 2014/61/EU of the European Parliament and of the Council of 15 May 2014 on measures to reduce the cost of deploying high-speed electronic  communications  networks  (OJ L  155,  23.5.2014, p.  1).

## Template for energy performance certificates

## (referred  to in  Article  19)

- 1. On its  front  page,  the  energy  performance  certificate  shall  display  at  least  the  following  elements:
- (a) the  energy  performance  class;
- (b) the  calculated  annual  primary  energy  use  in  kWh/(m .y); 2
- (c) the  calculated  annual  final  energy  use  in  kWh/(m .y); 2
- (d) renewable  energy  produced  on-site in  %  of energy  use;
- (e) operational  greenhouse  gas emissions  (kgCO /(m .y)),  and  the  value  of  the  life-cycle  GWP,  if  available. 2 2

The energy performance certificate  shall  also  display  the  following  elements:

- (a) the  calculated  annual  primary  and  final  energy consumption  in  kWh  or  MWh;
- (b) renewable  energy  production  in  kWh  or  MWh;  main  energy carrier  and  type  of  renewable  energy  source;
- (c) the  calculated  energy  needs  in  kWh/(m .y); 2
- (d) a yes/no  indication  whether  the  building  has  a  capacity  to  react  to  external  signals  and  adjust  the  energy consumption;
- (e) a  yes/no  indication  whether  the  heat  distribution  system  inside  the  building  is  capable  to  work  at  low  or  more efficient  temperature  levels,  where  applicable;
- (f) the  contact  information  of  the  relevant  one-stop  shop  for  renovation  advice.
- 2. In  addition,  the  energy  performance  certificate  may  include  the  following  indicators:
- (a) energy use,  peak  load,  size  of  generator  or  system,  main  energy carrier  and  main  type  of  element  for  each  of  the uses:  heating,  cooling,  domestic  hot  water,  ventilation  and  in-built  lighting;
- (b) the  greenhouse  gas  emission  class  (if  applicable);
- (c) information on carbon removals associated to the temporary storage of carbon in  or on buildings;
- (d) a  yes/no  indication  whether  a  renovation  passport  is  available  for  the  building;
- (e) the  average  U-value  for  the  opaque  elements  of  the  building  envelope;
- (f) the  average  U-value  for  the  transparent  elements  of  the  building  envelope;
- (g) type  of  most  common  transparent element  (e.g.  double-glazed  window);
- (h) results  of  the  analysis  on  overheating  risk  (if  available);
- (i) the  presence  of  fixed  sensors  that  monitor  the  indoor  environmental  quality;
- (j) the  presence  of  fixed  controls  that  respond  to  the  levels  of  indoor  environmental  quality;
- (k) number and type of recharging points for electric vehicles;
- (l) presence,  type  and  size  of  energy  storage  systems;
- (m) expected  remaining lifespan  of  the  heating  or  air-conditioning  systems  and  appliances,  where  applicable;
- (n) feasibility  of  adapting  the  heating  system  to  operate  at  more  efficient  temperature  settings;

- (o) feasibility  of  adapting  the  domestic  hot-water  system  to  operate  at  more  efficient  temperature  settings;
- (p) feasibility  of  adapting  the  air-conditioning  system  to  operate  at  more  efficient  temperature  settings;
- (q) metered energy consumption;
- (r) whether  there  is  a  connection  to  a  district  heating  and  cooling  network,  and,  if  available,  information  about a  potential  connection  to  an  efficient  district  heating  and  cooling  system;
- (s) local primary energy factors and related carbon emission factors of the connected local district heating and cooling network;
- (t) operational  fine  particulate  matter  (PM 2,5 )  emissions.

The energy performance certificate may include the following links with other  initiatives if  these apply in the relevant Member State:

- (a) a  yes/no  indication  whether  a  smart  readiness  assessment  has  been  carried  out  for  the  building;
- (b) where available, the  value  of  the  smart  readiness  assessment;
- (c) a  yes/no  indication  whether  a  Digital  Building  Logbook  is  available  for  the  building.

Persons  with  disabilities  shall  have  equal  access  to  the  information  in  energy  performance  certificates.

## Independent control systems for energy performance certificates

- 1. Definition  of  a  valid  energy  performance  certificate

Member States shall  provide  a  clear  definition  of  what  is  considered  to  be  a  valid  energy  performance  certificate.

The definition  of  a  valid  energy  performance  certificate  shall  ensure:

- (a) a  validity  check  of  the  input  data  (including  on-site  checks)  of  the  building  used  to  issue  the  energy  performance certificate  and  the  results  stated  in  the  certificate;
- (b) the  validity of  the  calculations;
- (c) a  maximum deviation for  the  energy  performance  of a  building,  preferably  expressed  by  the  numeric  indicator  of primary energy use (kWh/(m 2 .y));
- (d) a  minimum number of elements differing from default or standard  values.

Member  States  may  include  additional  elements  in  the  definition  of  a  valid  energy  performance  certificate,  such  as maximum deviation for specific input data values.

- 2. Quality of  the  independent  control  system  for  energy  performance  certificates

Member States  shall  provide  a  clear  definition  of  the  quality  objectives  and  the  level  of  statistical  confidence  that  the energy performance certificate framework should achieve. The independent control system shall ensure at least 90 % of valid  issued  energy  performance  certificates  with  a  statistical  confidence  of  95 %  for  the  evaluated  period,  which  shall not exceed one year.

The level  of  quality  and  the  level  of  confidence  of  the  independent  control  system for  energy  performance  certificates shall be measured using random sampling and shall account for all elements provided in the definition of a valid energy performance  certificate.  Member  States  shall  require  third-party  verification  for  the  evaluation  of  at  least  25 %  of  the random sample when the independent control systems have been delegated to non-governmental bodies.

The validity of the input data shall be verified with information provided by the independent expert. Such information may include product certificates, specifications or building plans that include details on the performance of the different elements  included  in  the  energy  performance  certificate.

The  validity  of  the  input  data  shall  be  verified  by  on-site  visits,  which  may  be  carried  out  by  virtual  means,  where appropriate in at least 10 % of the energy performance certificates that are part of the random sampling used to assess the  overall  quality  of  the  scheme.

In addition to the minimum random sampling to determine the overall level of quality, Member States may use different strategies to specifically detect and target poor quality in energy performance certificates with the objective to improve the overall quality of the scheme. Such targeted analysis cannot be used as the basis to measure the overall quality of the scheme.

Member States shall deploy pre-emptive and reactive measures to ensure the quality of the overall energy performance certificate  framework.  Those  measures  may  include  additional  training  for  independent  experts,  targeted  sampling, obligation  to  re-submit  energy  performance  certificates,  proportional  fines  and  temporary  or  permanent  bans  for experts.

Where information is added to a database it  shall be  possible  for  national  authorities  to  identify  the  originator  of  the addition,  for  monitoring  and  verification  purposes.

## 3. Availability of  energy  performance  certificates

The independent control system shall verify the availability of energy performance certificates to prospective buyers and tenants in order to ensure that it is possible to consider the energy performance of the building in their decision to buy or  rent.

The independent control system shall verify the visibility of  the  energy  performance indicator and class  in advertising media.

- 4. Treatment of building  typologies

The independent control system shall account for different building typologies, particularly for building typologies that are  most  prevalent  in  the  real  estate  market,  such  as  single  residential,  multi-residential,  offices  or  retail.

- 5. Public  disclosure

Member States shall regularly publish, on the national database on energy performance certificates, at least the following information on the quality system:

- (a) the  definition  of  a  valid  energy  performance  certificate;
- (b) quality objectives  for  the  energy  performance  certificate  scheme;
- (c) results of  the quality assessment, including number of certificates evaluated and relative size to the total number of issued  certificates  in  the  given  period  (per  typology);
- (d) contingency measures to improve the overall  quality of energy performance certificates.

## Comparative methodology framework to identify cost-optimal levels of energy performance requirements for buildings and building elements

The comparative methodology framework shall enable Member States to determine the energy and emission performance of buildings and building elements and the economic aspects of measures relating to the energy and emission performance, and  to  link  them  with  a  view  to  identifying  the  cost-optimal  level  to  achieve  the  2030  emission  reduction  and  climate neutrality  goals,  as  well  as  a  zero-emission  building  stock  by  2050  at  the  latest.

The comparative methodology framework shall be accompanied by guidelines outlining how to apply that framework in the  calculation  of  cost-optimal  performance  levels.

The comparative methodology framework shall allow for taking into account use patterns, outdoor climate conditions and their  future  changes  according  to  best  available  climate  projections,  including  heat  and  cold  waves,  investment  costs, building category, maintenance and operating costs (including energy costs and savings), earnings from energy produced, where  applicable,  environmental  and  health  externalities  of  energy  use,  waste  management  costs,  where  applicable,  and technological developments. It  should  be  based  on  relevant  European  standards  relating  to  this  Directive.

The Commission shall also provide:

- - guidelines to accompany the comparative methodology framework; those guidelines will serve to enable the Member States  to  undertake  the  steps  listed  below,
- - information on estimated long-term  energy price developments.

For  the  application  of  the  comparative  methodology  framework  by  Member  States,  general  conditions,  expressed  by parameters,  shall  be  laid  down  at  Member  State  level.  The  Commission  shall  issue  recommendations  to  Member  States regarding  their  cost  optimality  levels,  where  relevant.

The comparative methodology framework shall require Member States to:

- - define  reference  buildings  that  are  characterised  by  and  representative  of  their  functionality  and  geographic  location, including  indoor  and  outdoor  climate  conditions.  The  reference  buildings  shall  cover  residential  and  non-residential buildings,  both  new  and  existing  ones,
- - define  energy  efficiency  measures  to  be  assessed  for  the  reference  buildings.  Those  may  be  measures  for  individual buildings  as  a  whole,  for  individual  building  elements,  or  for  a  combination  of  building  elements,
- - assess  the  final  and  primary  energy  need  and  resulting  emissions  of  the  reference  buildings  with  the  defined  energy efficiency  measures  applied,
- - calculate  the  costs  (i.e.  the  net  present  value)  of  the  energy  efficiency  measures  (as  referred  to  in  the  second  indent) during the expected economic life cycle applied to the reference buildings (as referred to in the first indent) by applying the  comparative methodology framework principles.

By calculating the costs of the energy efficiency measures during the expected economic life cycle, the cost-effectiveness of different  levels  of  minimum  energy  performance  requirements  is  assessed  by  the  Member  States.  That  will  allow  the determination of  cost-optimal  levels  of  energy  performance  requirements.

## Requirements for  renovation passports

- 1. The renovation passport shall  include:
- (a) information on the current energy  performance of  the  building;
- (b) a  graphical  representation  or  graphical  representations  of  the  roadmap  and  its  steps  for  a  staged  deep  renovation;
- (c) information  on  relevant  national  requirements  such  as  minimum  energy  performance  requirements  for  buildings, minimum energy  performance  standards  and  rules  in  the  Member  State  on  the  phasing  out  of  fossil-fuel  used  in buildings  for  heating  and  cooling,  including  application  dates;
- (d) a  succinct  explanation  on  the  optimal  sequencing  of  steps;
- (e) information about each step, including:
- (i) the name  and  description  of  the  renovation  measures  for the step, including  relevant  options  for the technologies,  techniques  and  materials  to  be  used;
- (ii) the estimated energy savings in primary and final energy consumption, in kWh and in percentage improvement compared to the energy consumption prior  to the step;
- (iii) the  estimated  reduction  of operational  greenhouse  gas  emissions;
- (iv) the  estimated  savings  on  the  energy  bill,  clearly  indicating  the  assumptions  on  energy  costs  used  for  the calculation;
- (v) the  estimated  energy  performance  class  of  the  energy  performance  certificate  to  be  achieved  following completion of  the  step;
- (f) information about a potential  connection to an  efficient  district  heating  and  cooling  system;
- (g) the share of individual or collective generation and self-consumption of renewable energy estimated to be achieved after  the  renovation;
- (h) general  information  on  available  options  for  improving  construction  products'  circularity  and  for  reducing  their whole-life-cycle greenhouse  gas  emissions,  as  well  as  wider  benefits  related  to  health  and  comfort,  indoor environmental quality  and  the  improved  adaptive  capacity of  the  building  to  climate  change;
- (i) information on available  funding and  links  to  the  relevant  web  pages  indicating  the  sources  of  such  funding;
- (j) information  on  technical  advice  and  advisory  services,  including  contact  details  and  links  to  the  web  pages  of one-stop  shops.
- 2. The renovation passport may include:
- (a) an  indicative  timing  of  the  steps;
- (b) for  each  step:
- (i) a detailed description of the technologies, techniques and materials to be used, their advantages, disadvantages and costs;
- (ii) how the energy performance of the building would compare to minimum energy performance requirements for buildings undergoing major  renovation, nearly zero-energy building and zero-emission building requirements after completion of the step and how the energy performance of the building elements replaced would compare to  minimum energy performance requirements for single building elements, where  these exist;

- (iii) the  estimated  costs  for  carrying  out  the  step;
- (iv) the  estimated  payback  period  for  the  step,  with  and  without  any  available  financial  support;
- (v) the  estimated  time  needed  to  carry out  the  step;
- (vi) where available, the reference values on the life-cycle greenhouse gas emissions for the materials and equipment and links  to  the  relevant  web  pages  where  they can  be  found;
- (vii) the  estimated  lifetime  of  measures  and  the  estimated  maintenance  costs;
- (c) independent modules on:
- (i) the typical trades necessary  or recommended  for  carrying  out  energy  renovations  (architects,  advisors, contractors,  suppliers  and  installer,  etc.)  or  links  to  the  relevant  web  pages;
- (ii) a list of relevant architects, advisors, contractors, suppliers or installers in the area, that may include only those fulfilling certain conditions such as matching higher qualification or certification labels or conditions, or links to the  relevant  web  pages;
- (iii) the  technical  conditions  needed  for  an  optimal  roll-out  of  low  temperature  heating;
- (iv) how the renovation steps and additional  measures  could improve  the smart  readiness  of a  building;
- (v) technical  and  safety  requirements  for  materials  and  works;
- (vi) the underlying assumptions behind the calculations provided or links to the relevant web page where they can be  found;
- (d) information on how to access a digital version  of  the  renovation passport;
- (e) any major renovations made to the building or building unit, as referred to in Article 8(1), and any retrofitting or replacement of a building element that forms part of the building envelope and which has a significant impact on the energy performance of the building envelope, as referred to in Article 8(2), where such information is made available to  the  expert  carrying  out  the  renovation  passport;
- (f) information related to seismic safety, where such information relevant to the building is made available to the expert;
- (g) upon  request  of  and  on  the  basis  of  information  made  available  by  the  current  building  owner,  an  attachment containing additional information, such as the adaptability of spaces to evolving needs and any planned renovations.
- 3. Regarding the status of the building prior  to the renovation steps, the renovation passport shall consider, to the extent possible,  information  contained  in  the  energy  performance  certificate.
- 4. Each metric used for estimating  the  impact of  steps  shall  be  based  on  a  set  of  standard  conditions.

## PART A

## Repealed Directive with list of  the successive amendments thereto (referred  to in  Article  36)

PART B

| Directive 2010/31/EU of the European Parliament and of the Council (OJ L 153, 18.6.2010, p. 13).      |                 |
|-------------------------------------------------------------------------------------------------------|-----------------|
| Directive (EU) 2018/844 of the European Parliament and of the Council (OJ L 156, 19.6.2018, p. 75).   | only Article 1  |
| Regulation (EU) 2018/1999 of the European Parliament and of the Council (OJ L 328, 21.12.2018, p. 1). | only Article 53 |

## Time-limits for  transposition  into national law and dates of application (referred  to in  Article  36)

| Directive     | Time-limit for transposition   | Dates of application                                                                                                                                                                                                                                                       |
|---------------|--------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2010/31/EU    | 9 July 2012                    | as far as Articles 2, 3, 9, 11, 12, 13, 17, 18, 20 and 27 are concerned, 9 January 2013; as far as Articles 4 to 8, 14, 15 and 16 are concerned, 9 January 2013 with regard to buildings occupied by the public authorities and 9 July 2013 with regard to other buildings |
| (EU) 2018/844 | 10 March 2020                  |                                                                                                                                                                                                                                                                            |

## Correlation table

| Directive 2010/31/EU                                       | This Directive                                |
|------------------------------------------------------------|-----------------------------------------------|
| Article 1                                                  | Article 1                                     |
| Article 2, point (1)                                       | Article 2, point 1                            |
| -                                                          | Article 2, point (2)                          |
| Article 2, point (2)                                       | Article 2, point (3)                          |
| -                                                          | Article 2, points (5) and (6)                 |
| Article 2, points (3), (3a), (4) and (5)                   | Article 2, points (7) to (10)                 |
| -                                                          | Article 2, points (12), (13) and (14)         |
| Article 2, points (6), (7), (8) and (9)                    | Article 2, points (15) to (18)                |
| -                                                          | Article 2, points (19) to (22)                |
| Article 2, point (10)                                      | Article 2, point (23)                         |
| -                                                          | Article 2, points (24) to (29)                |
| Article 2, points (11), (12), (13) and (14)                | Article 2, points (30) to (33)                |
| -                                                          | Article 2, points (34), (37) to (40) and (42) |
| Article 2, point (15)                                      | Article 2, point (42)                         |
| Article 2, points (15), (15a), (15b), (15c), (16) and (17) | Article 2, points (43), (44), (47) to (50)    |
| Article 2, point (18)                                      | -                                             |
| Article 2, point (19)                                      | Article 2, point (51)                         |
| -                                                          | Article 2, points (52) to (64)                |
| Article 2, point (20)                                      | -                                             |
| Article 2a                                                 | Article 3                                     |
| Article 3                                                  | Article 4                                     |
| Article 4                                                  | Article 5                                     |
| Article 5                                                  | Article 6                                     |
| Articles 6 and 9                                           | Article 7                                     |
| Article 7                                                  | Article 8                                     |
| -                                                          | Article 9                                     |
| -                                                          | Article 12                                    |
| Article 8(1), (9)                                          | Article 13                                    |
| Article 8(2) to (8)                                        | Article 14                                    |
| Article 8(10), (11)                                        | Article 15                                    |
| -                                                          | Article 16                                    |
| Article 10                                                 | Article 17                                    |
| Article 11                                                 | Article 19                                    |
| Article 12                                                 | Article 20                                    |
| Article 13                                                 | Article 21                                    |
| -                                                          | Article 22                                    |
| Articles 14 and 15                                         | Article 23                                    |

| Directive 2010/31/EU   | This Directive   |
|------------------------|------------------|
| Article 16             | Article 24       |
| Article 17             | Article 25       |
| -                      | Article 26       |
| Article 18             | Article 27       |
| Article 19             | Article 28       |
| Article 19a            | -                |
| Article 20             | Article 29       |
| Article 21             | Article 30       |
| Article 22             | Article 31       |
| Article 23             | Article 32       |
| Article 26             | Article 33       |
| Article 27             | Article 34       |
| Article 28             | Article 35       |
| Article 29             | Article 36       |
| Article 30             | Article 37       |
| Article 31             | Article 38       |
| Annex I                | Annex I          |
| -                      | Annex II         |
| -                      | Annex III        |
| Annex IA               | Annex IV         |
| -                      | Annex V          |
| Annex II               | Annex VI         |
| Annex III              | Annex VII        |
| Annex IV               | Annex IX         |
| Annex V                | Annex X          |