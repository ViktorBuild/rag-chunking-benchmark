---
document_id: ghg_scope3_ch01_purchased_goods
title: "Scope 3 Guidance - Category 1: Purchased Goods and Services"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat01_purchased_goods.pdf"
tables_detected: 25
converted_with: "Docling v2.32 (TableFormer)"
---

1 1

## Category 1: Purchased Goods and Services

<!-- image -->

## Category description

<!-- image -->

T of products purchased or acquired by the reporting company in the reporting year. his category includes all upstream (i.e., cradle-to-gate) emissions from the production Products include both goods (tangible products) and services (intangible products).

Category 1 includes emissions from all purchased goods and services not otherwise included in the other categories of upstream scope 3 emissions (i.e., category 2 through category 8). Specific categories of upstream emissions are separately reported in category 2 through category 8 to enhance the transparency and consistency of scope 3 reports.

Emissions from the transportation of purchased products from a tier one (direct) supplier to the reporting company (in vehicles not owned or controlled by the reporting company) are accounted for in category 4 (Upstream transportation and distribution).

Companies may find it useful to differentiate between purchases of production-related products (e.g., materials, components, and parts) and non-production-related products (e.g., office furniture, office supplies, and IT support). This distinction may be aligned with procurement practices and therefore may be a useful way to more efficiently organize and collect data (see box 5.2 of the Scope 3 Standard ).

## Summary of methods for calculating emissions from purchased goods and services

Companies may use the methods listed below to calculate scope 3 emissions from purchased goods and services. The first two methods - supplier-specific and hybrid - require the reporting company to collect data from the suppliers, whereas the second two methods - average-data and spend-based - use secondary data (i.e. industry average data). These methods are listed in order of how specific  the calculation is to the individual supplier of a good or service. However, companies need 2 not always use the most specific method as a first preference (see figure 1.1 and box 1.1).

2 See Box 1.1 for further explanation of the data specificity and data accuracy

- · Supplier-specific method collects product-level cradle-to-gate GHG inventory data from goods or services suppliers.
- · Hybrid method uses a combination of supplier-specific activity data (where available) and secondary data to fill the gaps. This method involves:
- · collecting allocated scope 1 and scope 2 emission data directly from suppliers;
- · calculating upstream emissions of goods and services from suppliers' activity data on the amount of materials, fuel, electricity, used, distance transported, and waste generated from the production of goods and services and applying appropriate emission factors; and
- · using secondary data to calculate upstream emissions wherever supplier-specific data is not available.
- · Average-data method estimates emissions for goods and services by collecting data on the mass (e.g., kilograms or pounds), or other relevant units of goods or services purchased and multiplying by the relevant secondary (e.g., industry average) emission factors (e.g., average emissions per unit of good or service).

1. wheat

10. recycling bin

- · Spend-based method estimates emissions for goods and services by collecting data on the economic value of goods and services purchased and multiplying it by relevant secondary (e.g., industry average) emission factors (e.g., average emissions per monetary value of goods). 1 2 3 1. wheat 2. tree 3. mountains 4. glass bottle 5. plastic bottle 6. aluminium can 1 2 3 2. tree 3. mountains 4. glass bottle 5. plastic bottle 6. aluminium can 7. factory 8. lorry 9. cloud

11. recycling bin (colours

7. factory

4

5

6

reversed)

12. wind turbines

13. chicken

14. cow 1

15. cow 2

## Figure [1.1] Different data types used for different calculation methods 1 4 5 6 16. shop 17. factory showing carbon

emissions (carbon emissions are shown in

orange)

9

## Product life cycle stages

8. lorry

9. cloud

10. recycling bin

11. recycling bin (colours reversed)

1

2

12. wind turbines

13. chicken

14. cow 1

15. cow 2

16. shop

17. factory showing carbon emissions (carbon

emissions are shown in

4

<!-- image -->

1

2

3

8

11

<!-- image -->

<!-- image -->

<!-- image -->

All other upstream emissions from production of product 4 5 6 13 14 15

10

11

Supplier-specific data

8

7

9

17

Supplier-specific data or average data, or a combination of both 13 14

10

11

12

16

13

16

Average data 14 17

Average data 17

15

9

12

15

5

4

orange)

5. plastic bottle

6. aluminium can

7. factory

8. lorry

9. cloud

10. recycling bin

11. recycling bin (colours reversed)

12. wind turbines

5

<!-- image -->

13. chicken

14. cow 1

15. cow 2

16. shop

17. factory showing carbon emissions (carbon

Supplier-specific data 10 11 10 emissions are shown in orange)

13

14

13

Supplier-specific data

16

17

16

Average data

Average data

8

11

14

17

2

Calculation Method

Supplier-specific method

Hybrid method

Average-data method

Spend-based method

7

16

8

3

6

9

1. wheat

2. tree

1. wheat

2. tree

3. mountains

3. mountains

4. glass bottle 4. glass bottle

5. plastic bottle 5. plastic bottle

6

6. aluminium can . aluminium can

7. factory

7. factory

8. lorry

8. lorry

9. cloud

9. cloud

1

10. recycling bin0. recycling bin

11. recyclin

11. recycling bin (colours   g bin (colours reversed)

reversed)

12

12. wind turbines. wind turbines

13. chicken

13. chicken

14. cow 1

15. cow 2

14. cow 1

15. cow 2

16. shop

16. shop

17. factory s

17. factory showing carbon howing carbon emis

emissions (carbon     sions (carbon emission

emissions are shown in s are shown in orange)

orange)

9

Notes on data used

All data is specific to the supplier's product 12 12

Scope 1 &amp; 2 data specific to supplier's product, all other upstream emissions either supplier specific or average 15 15

All emissions are based on secondary process data

All emissions are based on secondary EEIO data

3

6

Collecting data directly from suppliers adds considerable time and cost burden to conducting a scope 3 inventory, so companies should first carry out a screening (see Introduction, 'Screening to prioritize data collection') to prioritize data collection and decide which calculation method is most appropriate to achieve their business goals.

## Box [1.1] The difference between data specificity and data accuracy

Even though the supplier-specific and hybrid methods are more specific to the individual supplier than the average-data and spend-based methods, they may not produce results that are a more accurate reflection of the product's contribution to the reporting company's scope 3 emissions.  In fact, data collected from a supplier may actually be less accurate than industry-average data for a particular product. Accuracy derives from the granularity of the emissions data, the reliability of the supplier's data sources, and which, if any, allocation techniques were used. The need to allocate the supplier's emissions to the specific products it sells to the company can add a considerable degree of uncertainty, depending on the allocation methods used (for more information on allocation, see chapter 8 of the Scope 3 Standard ).

Figure 1.2 provides a decision tree to help companies determine the most appropriate calculation method for estimating their category 1 emissions. Companies may use different calculation methods for different types of purchased goods and services within category 1. For example, they can use more specific methods for categories of goods and services that contribute the most to total emissions. The choice of calculation method depends on several factors outlined in the Introduction, including the company's business goals, the significance (relative to total emissions) of goods and services within category 1, the availability of data, and the quality of available data. See sections 7.3 and 7.4 of the Scope 3 Standard for guidance on assessing data quality.

## Figure [1.2] Decision tree for selecting a calculation method for emissions from purchased goods and services

<!-- image -->

Note * Companies should collect data of sufficient quality to ensure that the inventory:

- • most appropriately reflects the GHG emissions of the company
- • supports the company's business goals for conducting a GHG inventory
- • serves the decision-making needs of users, both internal and external to the company.

For more information on how to determine whether data is of sufficient quality, see section 7.3 of the Scope 3 Standard Source: World Resources Institute

## Supplier-specific method

Supplier-specific product-level data is the most accurate because it relates to the specific good or service purchased by the reporting company and avoids the need for allocation (see chapter 8 of the Scope 3 Standard ).

## Activity data needed

- · Quantities or units of goods or services purchased

## Emission factors needed

- · Supplier-specific cradle-to-gate emission factors for the purchased goods or services (e.g., if the supplier has conducted a reliable cradle-to-gate GHG inventory, for example, using the GHG Protocol Product Standard ).

## Data collection guidance

Companies may send questionnaires to each relevant supplier or other value chain partner requesting the following:

- · Product life cycle GHG emissions data following the GHG Protocol Product Standard
- · A description of the methodologies used to quantify emissions and a description of the data sources used (including emission factors and GWP values)
- · Whether the data has been assured/verified, and if so, the type of assurance achieved
- · Any other relevant information (e.g., percentage of the product inventory calculated using primary data).

Note that to the extent possible, the data provided by the supplier should be for the same time interval as the reporting company's scope 3 inventory and preference should be given to verified data.

When collecting emission factors from suppliers it is recommended that companies also request information relating to the ratio of primary and secondary data used to calculate the emission factor. This information will provide transparency around how much primary data the supplier used to calculate the emission factor for its product. As suppliers become more sophisticated in GHG assessments, the percentage of primary data used to calculate emissions factors for their products is likely to increase. Collecting information on the ratio of primary and secondary data will enable this ratio to be measured and tracked over time.

## Calculation formula [1.1] Supplier-specific method

## CO 2 e emissions for purchased goods or services =

## sum across purchased goods or services:

∑ (quantities of good purchased (e.g., kg)

× supplier-specific product emission factor of purchased good or service (e.g., kg CO e/kg)) 2

## Example [1.1] Calculating emissions from purchased goods and services using the supplier-specific method

Company A is a construction company that purchases materials for its operations. Using its internal IT system, Company A is able to determine the total weight (kg) purchased for each material.

Company A collects product-specific emission factors from the supplier for the purchased goods, which were produced as part of the suppliers' internal GHG inventory reports.

| Purchased good   | Supplier   | Quantities purchased (kg)   |   Supplier-specific emission factor (kg CO 2 e/kg) |
|------------------|------------|-----------------------------|----------------------------------------------------|
| Cement           | Supplier C | 200,000                     |                                               0.15 |
| Plaster          | Supplier D | 600,000                     |                                               0.1  |
| Paint            | Supplier E | 200,000                     |                                               0.1  |
| Timber           | Supplier F | 100,000                     |                                               0.25 |
| Concrete         | Supplier G | 50,000                      |                                               0.2  |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

## Total emissions of purchased goods by Company A is calculated as follows:

∑ (quantities of good purchased (e.g., kg)

× supplier-specific emission factor of purchased good or service (e.g., kg CO e/kg)) 2

- = (200,000 × 0.15) + (600,000 × 0.1) + (200,000 × 0.1) + (100,000 × 0.25) + (50,000 × 0.2)
- = 145,000 kg CO e

2

## Hybrid method

## Activity data needed

For each supplier, reporting companies should collect as much of the following activity data relating to the good or service purchased as is available (if data is unavailable for certain activities, secondary data can be used to fill the gaps):

- · Allocated scope 1 and scope 2 data (including emissions from electricity use and fuel use and any process and fugitive emissions). For guidance on allocating emissions, refer to chapter 8 of the Scope 3 Standard
- · Mass or volume of material inputs (e.g., bill of materials), mass or volume of fuel inputs used, and distance from the origin of the raw material inputs to the supplier (the transport emissions from the supplier to the reporting company is calculated in category 4 so it should not be included here)
- · Quantities of waste output other emissions.

Note that, to the extent possible, the data provided by the supplier should be for the same time interval as the reporting company's scope 3 inventory and preference should be given to assured data.

If it is not feasible for the company to collect data from all its suppliers for all purchased goods, the company may use extrapolation and sampling techniques (see Appendix A).

If a supplier cannot provide data on some or all of the items in the list above, the reporting company may combine the available supplier-specific data with secondary data for the other activities.

Companies should also collect either:

- · Mass or number of units of purchased goods or services (e.g., kg, m 3 , hours spent, etc.)
- · Amount spent on purchased goods or services, by product type, using market values (e.g., dollars).

## Emission factors needed

Depending what activity data has been collected from the supplier, companies may need to collect:

- · Cradle-to-gate emission factors for materials used by tier 1 supplier to produce purchased goods (Note: these emission factors can either be supplier-specific emission factors provided by the supplier, or industry-average emission factors sourced from a secondary database. In general, preference should be given to more specific and verified emission factors)
- · Life cycle emission factors for fuel used by incoming transport of input materials to tier 1 supplier
- · Emission factors for waste outputs by tier 1 suppliers to produce purchased goods
- · Other emission factors as applicable (e.g., process emissions).

The secondary emission factors required will also depend on what data is available for the purchased good. Companies will need to collect either:

- · Cradle-to-gate emission factors of the purchased goods or services per unit of mass or unit of product (e.g., kg CO e/kg or kg CO e/hour spent) 2 2
- · Cradle-to-gate emission factors of the purchased goods or services per unit of economic value (e.g., kg CO e/$). 2

## Data collection guidance

To combine the primary data collected from the supplier with secondary data (to fill the gaps), the secondary emission factors must be disaggregated so the necessary elements can be overwritten with the supplier-specific data. For example, if a company collects only scope 1, scope 2, and waste data from the supplier, all other upstream emissions need to be estimated using secondary data (see example 1.3 below).

The reporting company may request the following information from suppliers to assist calculation:

- · Internal data systems (e.g., bill of materials, freight distance of incoming raw materials)
- · Public GHG inventory reports accessible through GHG reporting programs.

Data sources for emission factors include:

- · The data sources on the GHG Protocol website (http://www.ghgprotocol.org/Third-Party-Databases). Additional databases may be added periodically, so continue to check the website
- · Company- or supplier-developed emission factors (e.g., if the supplier has conducted a reliable cradle-to-gate product GHG inventory or internal LCA report)
- · Life cycle databases
- · Industry associations
- · Government agencies (e.g., Defra provides emission factors for the United Kingdom)
- · For activity data, emission factors, and formulas for process and fugitive emissions, see the GHG Protocol website (http://www.ghgprotocol.org/calculation-tools/all-tools) and the IPCC 2006 Guidelines (http://www.ipcc-nggip.iges. or.jp/public/2006gl/index.html).

Calculation formula [1.2]   Hybrid method (where supplier-specific activity data is available for all activities associated with producing the purchased goods)

## CO 2 e emissions for purchased goods and services =

## sum across purchased goods and services:

∑ scope 1 and scope 2 emissions of tier 1 supplier relating to purchased good or service (kg CO e) 2

+

## sum across material inputs of the purchased goods and services:

∑ (mass or quantity of material inputs used by tier 1 supplier relating to purchased good or service (kg or unit) × cradle-to-gate emission factor for the material (kg CO e/kg or kg CO e/unit)) 2 2

+

## sum across transport of material inputs to tier 1 supplier:

∑ (distance of transport of material inputs to tier 1 supplier (km)

× mass or volume of material input (tonnes or TEUs)

× cradle-to-gate emission factor for the vehicle type (kg CO e/tonne or TEU/km)) 2

+

## sum across waste outputs by tier 1 supplier relating to purchased goods and services:

∑ (mass of waste from tier 1 supplier relating to the purchased good or service (kg)

× emission factor for waste activity (kg CO e/kg)) 2

+

other emissions emitted in provision of the good or service as applicable

If the supplier is not able to provide specific information about its goods or services sold to the company, it may be necessary to allocate the emissions. For example, to calculate the sum of the waste outputs by the tier 1 supplier that relate to the purchased goods, a company can allocate a proportion of the total waste from the supplier's operations to the purchased product. Guidance on allocation can be found in chapter 8 of the Scope 3 Standard .

## Example [1.2] Calculating emissions from purchased goods using the hybrid method

Company A prints designs on t-shirts; it purchases the t-shirts from supplier B. Company A obtains the following information about supplier B's scope 1 and scope 2 emissions and waste generated, relating to the t-shirts sold to Company A. Company A also obtains information regarding supplier B's material inputs relating to the t-shirts sold to Company A and transport of these material inputs to supplier B. Company A also collects representative emission factors by reference to life cycle databases.

Scope 1 and scope 2 data from supplier B relating to production of purchased goods

|             | Amount (kWh)   |   Emission factor (kg CO 2 e/kWh) |
|-------------|----------------|-----------------------------------|
| Electricity | 5,000          |                               0.5 |
| Natural gas | 2,500          |                               0.2 |

## Example [1.2] Calculating emissions from purchased goods using the hybrid method (continued)

Material inputs of purchased goods

|            | Mass purchased (kg)   |   Emission factor (kg CO 2 e/kg) |
|------------|-----------------------|----------------------------------|
| Cotton     | 5,000                 |                              7   |
| Polymer    | 2,500                 |                              5   |
| Chemical A | 500                   |                              2   |
| Chemical B | 500                   |                              1.5 |

Transport of material inputs to supplier B

|            | Distance of transport (km)   |   Vehicle type emission factor (kg CO 2 e/kg/km) |
|------------|------------------------------|--------------------------------------------------|
| Cotton     | 1,000                        |                                             0.01 |
| Polymer    | 2,500                        |                                             0.02 |
| Chemical A | 800                          |                                             0.05 |
| Chemical B | 200                          |                                             0.1  |

Waste outputs by supplier B relating to production of purchased goods

Amount (kg)

Emission factor (kg CO e/kg of waste sent to landfill)

2

Waste sent to landfill

100

0.5

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

## Example [1.2] Calculating emissions from purchased goods using the hybrid method (continued)

Emissions at each stage are calculated by multiplying activity data by respective emission factors, as follows:

## scope 1 and scope 2 emissions by supplier B:

∑ scope 1 and scope 2 emissions of supplier B relating to purchased good (kg CO e) 2 = (5,000 × 0.5) + (2,500 × 0.2) = 3,000 kg CO e

2

## material input emissions:

∑ (mass or value of material inputs used by supplier B relating to purchased good (kg or $) × emission factor for the material (kg CO e/kg or kg CO e/$)) 2 2 = (5,000 × 7) + (2,500 × 5) + (500 × 2) + (500 × 1.5) = 49,250 kg CO e

2

## transport of material inputs emissions:

∑ (distance of transport of material inputs to supplier B (km) × mass of material input (kg) × emission factor for the vehicle type (kg CO e/kg/km)) 2 = (5,000 × 1,000 × 0.01) + (2,500 × 2,500 × 0.02) + (500 × 800 × 0.05) + (500 × 200 × 0.1) = 20,500 kg CO e

2

## waste output by supplier B:

∑ (mass of waste from supplier B relating to the purchased good (sent to landfill) (kg) × emission factor for waste to landfill (kg CO e/kg)) 2 = 100 × 0.5 = 50 kg CO e

2

total emissions of purchased t-shirts from supplier B is calculated by summing the above results, as follows:

3,000 + 49,250 + 20,500 + 50 = 72,800 kg CO e 2

If the reporting company decides that it is not within the company's business goals to collect all the data needed to calculate emissions based entirely on supplier-specific activity data, the reporting company may choose to use a combination of supplier-specific and average data. This option may be desirable in cases where supplier engagement is part of a company's business goals for carrying out a scope 3 inventory, but where collecting all the data necessary to calculate a cradle-to-gate emission factor from supplier-specific activity data is not practical. It is likely that many suppliers will not be able to provide all the activity data listed, so this technique of combining some supplier-specific data with secondary data is a possible alternative.

Calculation formula 1.3 follows the same structure as calculation formula 1.2. The difference is that where data is unavailable for certain activities, secondary data (either process data or EEIO data) is used to fill the gaps. (See also figure 1.1.).

Calculation formula 1.3 shows an example in which only scope 1 and scope 2 data and waste data were collected from the supplier, however, any combination of data could be collected from suppliers and the remaining data estimated using secondary data in the same way.

## Calculation formula [1.3]   Hybrid method (where only allocated scope 1 and scope 2 emissions and waste data are available from supplier)

## CO 2 e emissions for a purchased good where the supplier can only provide scope 1 and scope 2 emissions data and waste generated in operations data =

## sum across purchased goods and services:

∑ scope 1 and scope 2 emissions of tier 1 supplier relating to purchased good or service (kg CO e) 2

+

∑ (mass of waste from tier 1 supplier relating to the purchased good (kg) × emission factor for waste activity (kg CO e/kg))

2

+

∑ (mass or quantity of units of purchased good or service (kg)

× emission factor of purchased good excluding scope 1, scope 2, and emissions from waste generated by producer (kg CO e/kg or unit or $)) 2

## Example [1.3]   Calculating emissions from a purchased good by using the hybrid method (where only allocated scope 1 and scope 2 emissions and waste data are available from supplier)

Using the same example, company A prints designs on t-shirts; it purchases the t-shirts from supplier B. However, in this case, supplier B only has data available on allocated scope 1 and scope 2 emissions and waste generated in supplier B's operations (emissions and waste were allocated using physical allocation based on the total output of t-shirts in the reporting year and the quantity of t-shirts sold to Company A). Company A has to estimate the upstream emissions of supplier B using secondary data. Company A collects data on the quantity of t-shirts purchased from supplier B, as well as a cradle-to-gate emission factor for the production of a t-shirt (by reference to life cycle databases).

Scope 1 and scope 2 data from supplier B relating to production of purchased goods

|             | Amount (kWh)   |   Emission factor (kg CO 2 e/kWh) |
|-------------|----------------|-----------------------------------|
| Electricity | 5,000          |                               0.5 |
| Natural gas | 2,500          |                               0.2 |

Waste outputs by supplier B relating to production of purchased goods

|                        |   Amount (kg) |   Emission factor (kg CO2e/kg of waste sent to landfill) |
|------------------------|---------------|----------------------------------------------------------|
| Waste sent to landfill |           100 |                                                      0.5 |

## Example [1.3]   Calculating emissions from a purchased good by using the hybrid method (where only allocated scope 1 and scope 2 emissions and waste data are available from supplier) (continued)

Quantity of t-shirts purchased from supplier B and cradle-to-gate emission factor from life cycle database. The cradleto-gate process emission factor is from a database where it is possible to disaggregate the stages of the life cycle of the t-shirt. Emissions associated with the manufacture stage were excluded as these represent the emissions of supplier B itself (as opposed to cotton farming, processing, etc., which occur further upstream).

Number of t-shirts purchased from supplier B

Cradle-to-gate process emission factor (kg CO2e/per t-shirt)

Cradle-to-gate process emission factor (kg CO2e/per t-shirt) (excluding scope 1 and 2 emissions and emissions from waste associated with final producer)

T-shirts

12,000

6

5.6

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

## Emissions at each stage are calculated by multiplying activity data by respective emission factors, as follows: scope 1 and scope 2 emissions from supplier B:

∑ scope 1 and scope 2 emissions of supplier B relating to purchased good (kg CO e)

2

2 = (5,000 × 0.5) + (2,500 × 0.2) = 3,000 kg CO e

## waste output from supplier B:

∑ (mass of waste from supplier B relating to the purchased good (sent to landfill) (kg)

× emission factor for waste to landfill (kg CO2e/kg)) = 100 × 0.5 = 50 kg CO e 2

## all other upstream emissions from supplier B:

∑ (mass or quantity of units of purchased good or service (kg)

× emission factor of purchased good excluding scope 1 and scope 2 emissions of producer (kg CO2e/kg or unit or $))

= (50,000 × 5.6)

= 67,200 kg CO e 2

total emissions of purchased t-shirts from supplier B is calculated by summing the above results, as follows:

= 3,000 + 50 + 67,200

= 70,250 kg CO e 2

## Average-data method

In this method, the company collects data on the mass or other relevant units of purchased goods or services and multiplies them by relevant secondary (e.g., industry average) cradle-to-gate emission factors. Secondary emission factors may be found in process-based life cycle inventory databases. Refer to 'Secondary data sources' in the Introduction for further guidance on these databases.

## Activity data needed

- · Mass or number of units of purchased goods or services for a given year (e.g., kg, hours spent).

Companies may organize the above data more efficiently by differentiating purchased goods or services into mass and other categories of units (e.g., volume), where appropriate.

## Emission factors needed

- · Cradle-to-gate emission factors of the purchased goods or services per unit of mass or unit of product (e.g., kg CO e/kg or kg CO e/hour spent). 2 2

## Data collection guidance

Data sources for activity data include:

- · Internal data systems (e.g., bill of materials)
- · Purchasing records.

Data sources for emission factors include:

- · Process life cycle databases
- · Industry associations.

Companies should assess both the age of the database (i.e., temporal representativeness) and the geographic relevance to the supplier's location (e.g., geographical representativeness), as well as the technological representatives, completeness, and reliability of the data. For additional guidance, see sections 7.3 and 7.5 of the Scope 3 Standard .

## Calculation formula [1.4] Average-data method

## CO 2 e emissions for purchased goods or services =

## sum across purchased goods or services:

∑ (mass of purchased good or service (kg)

× emission factor of purchased good or service per unit of mass (kg CO e/kg)) 2

or

∑ (unit of purchased good or service (e.g., piece)

× emission factor of purchased good or service per reference unit (e.g., kg CO e/piece)) 2

## Spend-based method

If the supplier-specific method, hybrid method, and average-data method are not feasible (e.g., due to data limitations), companies should apply the average spend-based method by collecting data on the economic value of purchased goods and services and multiplying them by the relevant EEIO emission factors. Refer to the 'Secondary data sources' in the Introduction for further guidance on EEIO data.

Companies may use a combination of the material-based method and spend-based method by using both processbased and EEIO data for various purchased goods and services.

## Activity data needed

- · Amount spent on purchased goods or services, by product type, using market values (e.g., dollars)
- · Where applicable, inflation data to convert market values between the year of the EEIO emissions factors and the year of the activity data.

## Emission factors needed

- · Cradle-to-gate emission factors of the purchased goods or services per unit of economic value (e.g., kg CO e/$). 2

## Data collection guidance

Data sources for activity data include:

- · Internal data systems (e.g., enterprise resource planning (ERP) systems)
- · Bill of materials
- · Purchasing records.

Data sources for emission factors include:

- · Environmentally-extended input-output (EEIO) databases
- · Industry associations.

## Calculation formula [1.5] Spend-based method

## CO 2 e emissions for purchased goods or services =

## sum across purchased goods or services:

∑ (value of purchased good or service ($)

× emission factor of purchased good or service per unit of economic value (kg CO e/$)) 2

## Example [1.4]   Calculating emissions from purchased goods and services by using a combination of the average-data method and the spend-based method

Company E purchases over 1,000 components and raw materials to manufacture a broad range of electronic goods. Instead of obtaining data from all suppliers and allocating emissions between 1,000 separate goods, the company groups purchased goods based on:

- · Semi-processed components (e.g., average semiconductor)
- · Raw materials (e.g., average steel).

Physical data (mass) is available only for the semi-processed components. For raw materials, only spend data is available.

Company E calculates the mass of semi-processed components by combining primary data available through its IT systems with extrapolation techniques. For raw materials, the company determines the amount spent through its enterprise resource planning (ERP) system. Company E obtains process-based cradle-to-gate emission factors for the semi-processed components and EEIO cradle-to-gate emission factors for the raw materials.

The results of the data collection are summarized below:

| Purchased semi-processed components   | Mass (kg)   |   Emission factor (kg CO2e/kg) |
|---------------------------------------|-------------|--------------------------------|
| Hard drive                            | 400         |                             20 |
| Integrated circuits                   | 200         |                             10 |
| Liquid Crystal Display (LCD)          | 500         |                             40 |
| Semiconductors                        | 100         |                             70 |
| Battery                               | 1,500       |                              3 |
| Keyboard                              | 300         |                              3 |

Example [1.4]   Calculating emissions from purchased goods and services by using a combination of the average-data method and the spend-based method (continued)

| Purchased raw materials   | Value ($)   |   Emission factor (kg CO2e/$) |
|---------------------------|-------------|-------------------------------|
| Plastic (PS)              | 5,000       |                           0.3 |
| Plastic (ABS)             | 3,000       |                           0.3 |
| PET (film)                | 4,000       |                           0.3 |
| Aluminum                  | 6,000       |                           0.5 |
| Steel                     | 1,500       |                           0.2 |
| Cyclohexane               | 5,000       |                           0.2 |
| Epoxy resin               | 5,000       |                           0.3 |
| Copper                    | 1,000       |                           0.3 |
| Glass                     | 5,000       |                           0.4 |

Note: the activity data and emissions factors are illustrative only, and do not refer to actual data.

Total emissions of purchased goods by Company E can be calculated by multiplying the mass/value purchased by the respective emission factors and summing the results, as follows:

```
= (400 × 20) + (200 × 10) + (500 × 40) + (100 × 70) + (1,500 × 3) + (300 × 3) + (5,000 × 0.3) + (3,000 × 0.3) + (4,000 × 0.3) + (6,000 × 0.5) + (1,500 × 0.2) + (5,000 × 0.2) + (5,000 × 0.3) + (1,000 × 0.3) + (5,000 × 0.4) = 54,100 kg CO e 2
```