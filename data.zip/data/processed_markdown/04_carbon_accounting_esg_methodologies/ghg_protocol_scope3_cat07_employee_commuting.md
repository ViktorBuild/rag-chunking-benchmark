---
document_id: ghg_scope3_ch07_employee_commuting
title: "Scope 3 Guidance - Category 7: Employee Commuting"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat07_employee_commuting.pdf"
tables_detected: 11
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

- · Automobile travel
- · Bus travel
- · Rail travel
- · Air travel
- · Other modes of transportation (e.g., subway, bicycling, walking).

Companies may include emissions from teleworking (i.e., employees working remotely) in this category.

A reporting company's scope 3 emissions from employee commuting include the scope 1 and scope 2 emissions of employees and third-party transportation providers.

## Calculating emissions from employee commuting

Figure 7.1 offers a decision tree for selecting a calculation method for scope 3 emissions from employee commuting. Companies may use one of the following methods:

- · Fuel-based method , which involves determining the amount of fuel consumed during commuting and applying the appropriate emission factor for that fuel
- · Distance-based method, which involves collecting data from employees on commuting patterns (e.g., distance travelled and mode used for commuting) and applying appropriate emission factors for the modes used
- · Average-data method , which involves estimating emissions from employee commuting based on average (e.g., national) data on commuting patterns.
- 4 'Employees' refers to employees of entities and facilities owned, operated, or leased by the reporting company. Companies may include employees of other relevant entities (e.g., franchises or outsourced operations) in this category, as well as consultants, contractors, and other individuals who are not employees of the company, but commute to facilities owned and operated by the company.

7

## Figure [7.1] Decision tree for selecting a calculation method for emissions from employee commuting

<!-- image -->

## Fuel-based method

If data is available on the quantity or amount spent on fuel by employees for commuting, companies may apply the fuel-based method. The calculation methodology for the fuel-based method is the same as the fuel-based method in category 4 (Upstream transport and distribution). For guidance on calculating emissions using this method, refer to the guidance for category 4 (Upstream transport and distribution). If the fuel-based method is used to calculate emissions from commuting on public transport, then emissions need to be allocated to the employee(s). For more information on allocation, see chapter 8 of the Scope 3 Standard .

## Distance-based method

## Activity data needed

Companies should collect data on the following:

- · Total distance travelled by employees over the reporting period (e.g., passenger-kilometers travelled)
- · Mode of transport used for commuting (e.g., train, subway, bus, car, bicycle).

## Emission factors needed

Companies should collect:

- · Emission factors for each mode of transport (usually expressed in units of greenhouse gas (CO , CH , N O, or CO e) 2 4 2 2 emitted per passenger-kilometers travelled).

Note: For air travel emission factors, multipliers or other corrections to account for radiative forcing may be applied to the GWP of emissions arising from aircraft transport. Where used, companies should disclose the specific factor used.

## Data collection guidance

Companies should collect data on employee commuting habits, for example through a survey. Companies should survey their employees annually to obtain information on average commuting habits. Types of data to collect include:

- · Distance travelled by employees per day, or location of residence and office
- · The number of days per week that employees use different vehicle types (all categories of subway, car, bus, train, bicycle, etc.)
- · Number of commuting days per week and number of weeks worked per year
- · If the company is multinational: employees' region of residence/work (since transportation emission factors vary by region)
- · Whether there is a significant car-pooling scheme in operation, the proportion of employees using the scheme and the average occupancy per vehicle
- · If applicable, the amount of energy used from teleworking (e.g., kWh of gas, electricity consumed).

Collecting commuting data from all employees through a survey may not be feasible. Companies may extrapolate from a representative sample of employees to represent the total commuting patterns of all employees. For example, a company with 4,000 employees, who each have different commuting profiles, may extrapolate from a representative sample of, for example, 1,000 employees to approximate the total commuting of all employees. See Appendix A for more information on sampling.

## Calculation formula [7.1] Distance-based method

## CO 2 e emissions from employee travel =

## first, sum across all employees to determine total distance travelled using each vehicle type:

total distance travelled by vehicle type (vehicle-km or passenger-km) = ∑ (daily one-way distance between home and work (km) × 2 × number of commuting days per year)

## then, sum across vehicle types to determine total emissions:

kg CO e from employee commuting 2 = ∑ (total distance travelled by vehicle type (vehicle-km or passenger-km) × vehicle specific emission factor (kg CO e/vehicle-km or kg CO e/passenger-km)) 2 2

+

## (optionally) for each energy source used in teleworking:

∑ (quantities of energy consumed (kWh) × emission factor for energy source (kg CO e/kWh)) 2

7

7

Companies should convert daily commuting distance into annual commuting distance by multiplying the daily distance by the number of times the trip occurs during the reporting period. For example, if a company collects distance data on one-way journeys, the company should multiply the distance by the number of working days in the reporting year, and then multiply by two to account for daily return journeys.

Distance-travelled data by transport mode should be summed across all employees to obtain total annual kilometers or passenger-kilometers travelled by each mode of transport.

Companies may optionally calculate the emissions of teleworking from home. To calculate these emissions, a baseline emissions scenario should first be established. Baseline emissions occur regardless of whether or not the employee was at home (e.g., energy consumed by the refrigerator). The reporting company should only account for the additional emissions resulting from working from home, for example the electricity usage as a result of running the air conditioner to stay cool.

## Example [7.1] Calculating emissions from employee travel using the distance-based method

ompletes a questionnaire the results of which are summarized in the following table: Company A is a small advertising services company, with three employees working 48 weeks per year. To calculate emissions from employee commuting, it creates an 'employee commuting profile' for each employee. Each employee c

| Employee   |   Rail commute (times per week) | One way distance by rail (km)   |   Rail emission factor (kg CO 2 e/ passenger- kilometer) |   Car commute (times per week |   Car emission factor (kg CO 2 e/ vehicle- kilometer) | One way distance by car (km)   |
|------------|---------------------------------|---------------------------------|----------------------------------------------------------|-------------------------------|-------------------------------------------------------|--------------------------------|
| A          |                               5 | 10                              |                                                      0.1 |                             0 |                                                   0.2 | N/A                            |
| B          |                               4 | 10                              |                                                      0.1 |                             1 |                                                   0.2 | 15                             |
| C          |                               0 | N/A                             |                                                      0.1 |                             5 |                                                   0.2 | 20                             |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

## the total distance travelled by rail (km) is calculated as:

- ∑ (daily one way distance between home and work (km) × 2 × 5 × number of commuting weeks per year) = (10 × 2 × 5 × 48) + (10 × 2 × 4 × 48) = 8,640 km

## the total distance travelled by car (km) is calculated as:

- ∑ (daily one way distance between home and work (km) × 2 × 5 × number of commuting weeks per year) = (15 × 2 × 1 × 48) + (20 × 2 × 5 × 48) = 11,040 km

## total emissions from employee commuting for the reporting year is calculated as:

∑ (total distance travelled by vehicle type (vehicle-km or passenger-km) × vehicle specific emission factor (kg CO e/vehicle-km or kg CO e/passenger-km)) 2 2 = (8,640 × 0.1) + (11,040 × 0.2) = 3,072 kg CO e 2

7

## Average-data method

If company specific data is unavailable, companies may use average secondary activity data to estimate distance travelled and mode of transport. This may include using:

- · Average daily commuting distances of typical employees
- · Average modes of transport of typical employees
- · Average number of commuting days per week and average number of weeks worked per year.

Such estimation requires making several simplifying assumptions, which add uncertainty to the emissions estimates.

## Activity data needed

Companies should collect data on:

- · Number of employees
- · Average distance travelled by an average employee per day
- · Average breakdown of transport modes used by employees
- · Average number working days per year.

## Emission factors needed

- · Companies should collect:
- · Emission factors for each mode of transport (usually expressed as kilograms of GHG emitted per passenger per kilometer travelled).

## Data collection guidance

Company may collect average secondary data from sources such as national transportation departments, ministries or agencies, national statistics publications, and/or industry associations.

For example, the UK Office for National Statistics publishes average commuting patterns and distances (http://www. neighbourhood.statistics.gov.uk/dissemination/Info.do?page=analysisandguidance/commutingstatistics/commutingstatistics.htm).

Calculation resources include:

- · GHG Protocol Calculation Tool, 'Mobile Combustion GHG Emissions Calculation Tool. Version 2.0. June 2009,' developed by World Resources Institute, available at http://www.ghgprotocol.org/calculation-tools/all-tools
- · U.S. EPA Climate Leaders GHG Inventory Protocol, 'Optional Emissions from Commuting, Business Travel and Product Transport,' available at: http://www.epa.gov/stateply/documents/resources/commute\_travel\_product.pdf
- · For UK organizations, the Department for Transport provides guidance and a calculation tool for work-related travel at: http://www2.dft.gov.uk/pgr/sustainable/greenhousegasemissions/.

## Calculation formula [7.2] Average-data method

## CO 2 e emissions from employee commuting =

## sum across each transport mode:

∑ (total number of employees × % of employees using mode of transport × one way commuting distance (vehicle-km or passenger-km) × 2 × working days per year × emission factor of transport mode (kg CO e/vehicle-km or kg CO e/passenger-km)) 2 2

Companies should convert average daily commuting distance into annual average commuting distance by multiplying the one-way distance by two for the daily return trip and by the average number of days worked per year (i.e., excluding weekends and days spent on business travel, vacation, or working from home).

## Example [7.2] Calculating emissions from employee travel using the average data method

hoices and distances of commuters. National statistics show that UK workers work on average 235 days a year. The Company A is a manufacturer in the United Kingdom with over 10,000 employees. To determine the distance and mode of transport of employee travel, it refers to the UK Department of Transport's information regarding average commute c example assumes that employees do not share rides. The results of the study are shown below:

| Commute group   |   Percent of total commutes |   Average one-way distance (km) |   Emission factor (kg CO 2 e/ vehicle or passenger km |
|-----------------|-----------------------------|---------------------------------|-------------------------------------------------------|
| Rail            |                          50 |                              10 |                                                   0.1 |
| Car             |                          30 |                              15 |                                                   0.2 |
| Foot            |                          15 |                               1 |                                                   0   |
| Bus             |                           5 |                               5 |                                                   0.1 |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

7

7

## Example [7.2] Calculating emissions from employee travel using the average data method (continued)

## CO 2 e emissions by mode of transport can be calculated as follows:

emissions from employee commuting = ∑ (total number of employees

× % of employees using mode of transport × one way commuting distance (vehicle-km or passenger-km) × 2 × working days per year × emission factor of transport mode (kg CO e/vehicle-km or kg CO e/passenger-km))

2 2

## rail commuters:

(10,000 × 50% × 10 × 2 × 235 × 0.1) = 2,350,000 kg CO e 2

## car commuters:

(10,000 × 30% × 15 × 2 × 235 × 0.2) = 4,230,000 kg CO e 2

## foot commuters:

(10,000 × 15% × 1 × 2 × 235 × 0) = 0 kg CO e 2

## bus commuters:

(10,000 × 5% × 5 × 2 × 235 × 0.1) = 117,500 kg CO e 2

## total CO e of employee travel can be calculated as follows: 2

= 2,350,000 + 4,230,000 + 0 + 117,500 = 6,697,500kg CO e 2