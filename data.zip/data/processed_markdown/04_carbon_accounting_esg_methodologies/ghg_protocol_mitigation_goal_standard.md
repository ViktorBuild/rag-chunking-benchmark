---
document_id: ghg_mitigation_goal_standard
title: "Mitigation Goal Standard: An Accounting and Reporting Standard for National and Subnational Targets"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol / WRI"
year: 2014
original_file: "ghg_protocol_mitigation_goal_standard.pdf"
tables_detected: 158
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Mitigation Goal Standard

An accounting and reporting standard for national and subnational greenhouse gas reduction goals

<!-- image -->

<!-- image -->

## World Resources Institute team

Kelly Levin

Jared Finnegan

David Rich

Pankaj Bhatia

## Advisory Committee members

Samuel Tumiwa

Asian Development Bank

Ajay Mathur

Bureau of Energy Efficiency, India

Mary Nichols

California Air Resources Board

Ned Helme

Center for Clean Air Policy

Andrei Bourrouet

Costa Rican Institute of Electricity

Robert Owen-  Jones

Department of Climate Change and Energy Efficiency, Australia

Brian Mantlana

Department of Environmental Affairs, South Africa

Niklas Höhne

Ecofys

Dessalegne Fanta

Ethiopia Environmental Protection Authority

Jürgen Lefevere

European Commission

Jamshyd N. Godrej

Godrej &amp; Boyce Mfg Co. Ltd., India

Jennifer Layke

Johnson Controls

John Kornerup Bang

Maersk Group

Karen Suassuna

Ministry of Environment, Brazil

Alexa Kleysteuber

Ministry of Environment, Chile

Yuji Mizuno

Ministry of Environment, Japan

Andrea García-  Guerrero

Ministry of Environment and Sustainable Development, Colombia

Zou Ji

National Development and Reform Commission, China

Jonathan Dickinson

New York City Mayor's Office of Long-  Term Planning and Sustainability

Jane Ellis

Organisation for Economic Co-  operation and Development (OECD)

Kersten-  Karl Barth

Siemens

Suzana Kahn Ribeiro

State of Rio de Janeiro

Michael Lazarus

Stockholm Environment Institute-  U.S.

Chaiwat Munchareon

Thailand Greenhouse Gas Management Organization

Teng Fei

Tsinghua University

Neta Meidáv

United Kingdom Department of Energy and Climate Change

Katia Simeonova

United Nations Climate Change Secretariat

Yamil Bonduki

United Nations Development Programme (UNDP)

Maurice LeFranc

United States Environmental Protection Agency

Xueman Wang

World Bank

Thierry Berthoud

World Business Council for Sustainable Development (WBCSD)

<!-- image -->

<!-- image -->

## Detailed Table of Contents

| 1    | i ntroduction                                              | 4   | 5   | estimating Base year or                  |    |
|------|------------------------------------------------------------|-----|-----|------------------------------------------|----|
| 1.1  | Purpose of this standard                                   | 5   |     | Baseline scenario emissions              | 54 |
| 1.2  | Intended users                                             | 6   | 5.1 | Estimating base year emissions           |    |
| 1.3  | How the standard was developed                             | 6   |     | (for users with base year emissions      |    |
| 1.4  | Applicability of the standard                              | 6   |     | goals or base year intensity goals)      | 56 |
| 1.5  | Scope of the standard                                      | 7   | 5.2 | Estimating baseline scenario emissions   |    |
| 1.6  | When to use the standard                                   | 7   |     | (for users with baseline scenario goals) | 58 |
| 1.7  | Data and capacity needs                                    | 7   |     |                                          |    |
|      | for implementing the standard                              |     |     |                                          |    |
| 1.8  | Relationship to GHGinventories                             | 8   | 6   | accounting for the land sector           | 74 |
|      |                                                            |     | 6.1 | Overview and key concepts                | 75 |
| 1.9  | Relationship to the GHGProtocol Policy and Action Standard | 8   | 6.2 | Choose land-based or activity-based      |    |
| 1.10 | Terminology: shall, should, and may                        | 8   |     | accounting approach                      | 78 |
|      |                                                            |     | 6.3 | Choose land use categories or activities | 79 |
| 1.11 | Limitations                                                | 9   | 6.4 | Choose specific carbon pools, GHGfluxes, |    |
|      |                                                            |     |     | and categories/activities                | 79 |
| 2    | overview of steps, key concepts,                           |     | 6.5 | Choose the accounting method             | 80 |
|      | and requirements                                           | 10  | 6.6 | Minimize potential risks associated      |    |
| 2.1  | Overview of steps                                          | 11  |     | with the chosen accounting method        | 83 |
| 2.2  | Key concepts                                               | 11  | 6.7 | Decide on treatment                      |    |
| 2.3  | Example of following                                       |     |     | of natural disturbances                  | 86 |
| 2.4  | Requirements in the standard                               | 18  |     |                                          |    |

## 3 accounting and reporting principles

88

90

91

92

92

## Calculate allowable emissions

22

26

28

30

35

41

46

51

## 7 calculating allowaBle emissions in the target year(s)

7.1

Calculate allowable emissions in the target year(s)

Calculate allowable emissions intensity in the target year(s)

(for users with base year intensity goals)

Calculate emission reductions associated with achieving the goal (optional)

Set milestones (optional)

Define goal/methods

4

4.1

4.2

4.3

4.4

4.5

4.6

designing a mitigation goal

Prepare for goal design

Define	goal	boundary

Choose goal type

Define	goal	time	frame

Decide on use of transferable emissions units

Define	goal	level

7.2

7.3

7.4

<!-- image -->

## Assess progress/ achievement

| 8   | assessing progress                                                                      |     |
|-----|-----------------------------------------------------------------------------------------|-----|
|     | during the goal period                                                                  |  94 |
| 8.1 | Choose frequency of assessment                                                          |  96 |
| 8.2 | Develop a GHGinventory and calculate reporting year emissions                           |  97 |
| 8.3 | Calculate reporting year emissions intensity (for users with base year intensity goals) |  97 |
| 8.4 | Recalculate emissions during the goal period (if relevant)                              |  98 |
| 8.5 | Calculate change in emissions since the start of the goal period                        |  99 |
| 8.6 | Calculate additional emission reductions needed to achieve the goal                     | 102 |
| 8.7 | Assess why emissions have changed since the start of the goal period                    | 104 |
| 8.8 | Assess whether the jurisdiction is on track to achieve the goal                         | 106 |

## Detailed Table of Contents

|   9 | assessing goal achievement                                                      |   110 |
|-----|---------------------------------------------------------------------------------|-------|
| 9.1 | Develop a GHGinventory and calculate target year or period emissions            |   112 |
| 9.2 | Determine quantity of transferable emissions units retired and sold             |   113 |
| 9.3 | Calculate accountable emissions                                                 |   113 |
| 9.4 | Calculate accountable emissions intensity (if relevant)                         |   116 |
| 9.5 | Recalculate base year emissions or baseline scenario emissions (if relevant)    |   116 |
| 9.6 | Assess goal achievement                                                         |   117 |
| 9.7 | Calculate emission reductions and cumulative emissions (optional)               |   119 |
| 9.8 | Assess why emissions have changed since the start of the goal period (optional) |   120 |

## Verify

| 10   | verification                    | 122   |
|------|---------------------------------|-------|
| 10.1 | Introduction                    | 123   |
| 10.2 | Benefits of verification        | 124   |
| 10.3 | Key concepts                    | 124   |
| 10.4 | Subject matter relevant         |       |
|      | to the Mitigation Goal Standard | 126   |
| 10.5 | Types of verification           | 126   |
| 10.6 | Levels of assurance             | 128   |
| 10.7 | Competencies of verifiers       | 128   |
| 10.8 | Verification process            | 129   |

## Report

| 11   | reporting                      |   132 |
|------|--------------------------------|-------|
| 11.1 | Required information           |   133 |
| 11.2 | Optional reporting information |   139 |
|      | appendix                       |   140 |
|      | Sample GHGBalance Sheet        |   141 |
|      | Abbreviations and Acronyms     |   142 |
|      | Glossary                       |   144 |
|      | References                     |   150 |
|      | Contributors                   |   153 |

1

Introduction

<!-- image -->

<!-- image -->

G reenhouse gas (GHG) emissions are driving climate change and its impacts around the world. According to climate scientists, global greenhouse gas emissions must be cut by as much as 72 percent below 2010 levels by 2050 to  have  a  likely  chance  of  limiting  the  increase  in  global  mean  temperature  to 2 degrees Celsius above preindustrial levels (IPCC 2014). Every degree increase in temperature will produce increasingly unpredictable and dangerous impacts for people and ecosystems. As a result, there is an urgent need to accelerate efforts to reduce GHG emissions.

To reduce GHG emissions, national and subnational governments are adopting a variety of climate change mitigation goals. As they do so, they need to assess and report progress toward these goals in a relevant, complete, consistent, transparent, and accurate manner in order to meet domestic and international objectives and ensure that efforts implemented to achieve goals are having the intended results.

## 1.1 Purpose of this standard

Mitigation goals are commitments to limit GHG emissions to a specified quantity by a specified date. The GHG Protocol Mitigation Goal Standard provides guidance for designing national and subnational mitigation goals and a standardized approach for assessing and reporting progress toward goal achievement.

This standard is intended to help users accomplish the following:

- · Design a mitigation goal, which entails
- · understanding the advantages and disadvantages of various types of mitigation goals and
- · informing the choice of mitigation strategies used for achieving the goal.
- · Define accounting methods for tracking progress while maintaining consistency with applicable inventory methods.
- · Calculate allowable emissions in the target year(s) in order to understand future emissions levels associated with meeting the goal.
- · Assess and report progress toward meeting a goal, which entails
- · evaluating what additional actions are needed to achieve the goal,

- · publicly reporting goal progress and assessment methods, and
- · meeting stakeholder demands for transparency.
- · Assess and report whether a goal has been achieved.

This standard was developed with the following objectives in mind:

- · To help users assess and report progress toward mitigation goals in an accurate, consistent, transparent, complete, and relevant manner
- · To help policymakers and other decision makers develop effective strategies for managing and reducing GHG emissions guided by their climate and/or sustainable development objectives
- · To support consistent and transparent public reporting of mitigation goal design choices and progress toward goal achievement guided by users' national or subnational circumstances and needs
- · To support national governments in meeting international reporting obligations (for example, National Communications and biennial reports/biennial update reports) under the United Nations Framework Convention on Climate Change (UNFCCC), if relevant
- · To create more international consistency and transparency in the way jurisdictions design and assess progress toward mitigation goals
- · To help national and subnational governments design and implement mitigation goals that make a transparent and meaningful contribution to effective global GHG mitigation

## 1.2 Intended users

This standard is intended primarily for national and subnational government agencies involved in setting and tracking mitigation goals. Companies and organizations may also find this guidance useful. They may also refer to Chapter 1 1 of the GHG Protocol Corporate Accounting and Reporting Standard for specific guidance on corporate mitigation goals . The standard may also be useful for research institutions and nongovernmental organizations (NGOs) that are assessing the emissions impacts of mitigation goals and tracking progress toward their achievement.

Throughout the standard, the term 'user' refers to the entity implementing the standard.

## 1.3 How the standard was developed

This standard was developed by the Greenhouse Gas Protocol (GHG Protocol). The GHG Protocol is a multistakeholder partnership of businesses, NGOs, governments, academic institutions, and others convened by the World Resources Institute (WRI) and the World Business Council for Sustainable Development (WBCSD). Launched in 1998, the mission of the GHG Protocol is to develop internationally accepted GHG accounting and reporting standards and tools, and to promote their adoption in order to achieve a low emissions economy worldwide. All GHG Protocol standards and guidance are available at www.ghgprotocol.org.

In June 2012, WRI launched a 2-  year process to develop the Mitigation Goal Standard. A 30-  member advisory committee provided strategic direction throughout the process. The first draft of the Mitigation Goal Standard was developed in 2012 by a technical working group consisting of 22 members, then reviewed by members of a review group, including during three stakeholder workshops. In 2013, the second draft was pilot tested on six goals in a variety of countries and cities across a range of sectors to test how the standard worked in practice. Pilot countries included Chile, India, Israel, South Africa, the United Kingdom, and the United States. The standard was revised based on pilot testing feedback and circulated for public comment in July and August 2014.

## 1.4 Applicability of the standard

This standard is applicable to

- · All countries and regions
- · National and subnational governments
- · Economy-  wide mitigation goals and sectoral goals

In the absence of UNFCCC or domestic rules or to supplement them, this standard may be useful in designing and assessing corresponding goals, including intended nationally determined mitigation contributions, quantified emission limitation or reduction commitments (QELRCs), and nationally appropriate mitigation actions (NAMAs) framed as mitigation goals,  as well as goals in the context of low 1 emissions development strategies (LEDS), or other national, subnational, or international mitigation commitments. 2

Although the standard is designed for GHG mitigation goals, users may find it useful for other types of goals, such as energy efficiency, renewable energy, or other goals not expressed in terms of GHG emissions or emission reductions.

## 1.5 Scope of the standard

This standard includes steps related to designing and assessing mitigation goals, including accounting, reporting, and verification. It includes both requirements-  that is, accounting and reporting steps that users must follow in order to be in conformance with this standard-  and guidance to help users implement the standard. While the guidance provides recommendations, users need not follow them to be in conformance with the standard.

Use of the standard is voluntary. Users may initially choose to implement the standard in part with a view toward full implementation if other stages of mitigation goals accounting are relevant. However, users must follow all applicable accounting and reporting requirements in order for the assessment to be in conformance with the standard.

Setting GHG reduction goals is a political process, and the way a goal is designed will depend on national or subnational objectives, circumstances, capacities, available support, as well as other considerations about feasibility. This standard is policy-  neutral in that it provides guidance on the technical aspects of goal design and assessment, independent of policy choices. The standard allows users to choose any goal type and make other goal design choices guided by national or subnational circumstances and/or relevant international processes. For example, this standard requires users to choose and report a target year but does not prescribe which target year be chosen when designing a goal.

While the standard focuses on the particular goal under assessment, mitigation goal design and accounting should be seen as an iterative process that establishes and tracks progress toward a series of goals that phase out emissions over time.

## 1.6 When to use the standard

The standard may be used at multiple points in time throughout a goal setting and implementation process:

- · Before implementation of the goal: To design a mitigation goal (Chapter 4), define accounting methods for tracking progress (Chapters 5 and 6), and calculate allowable emissions in the goal's target year(s) (Chapter 7)
- · during the goal period: To assess and report progress toward achieving the goal by tracking changes in emissions and removals over time and calculate additional emission reductions needed to achieve the goal (Chapter 8)
- · at the end of the goal period: To assess goal achievement (Chapter 9)

The frequency and timing of the application of the standard depends on users' objectives and available resources. The most comprehensive approach is to apply the standard once before implementation, annually (or regularly) during the goal period, and once at the end of the goal period.

## 1.7 Data and capacity needs for implementing the standard

A mitigation goal assessment will be easier to carry out if systems to collect data and apply the relevant methods are already in place. For example, the assessment will require numerous data inputs, including a complete GHG inventory, at a minimum. Some goal types, such as base year intensity goals and baseline scenario goals, require additional data as well, such as gross domestic product (GDP). Users should consider making necessary improvements in institutional, human, or technical capacities for data collection and management before applying the standard. It will be critical to develop robust and credible data sets to make accurate goal assessments and enable key decisions. Lastly, participatory processes for goal design, as well as clear communication of the outcomes of goal assessment, are important for improving accuracy, accountability, and trust.

## 1.8 Relationship to GHG inventories

GHG inventories are critical for tracking changes in overall GHG emissions and removals at the national, subnational (for example, cities), and company/organizational levels. The development of an inventory is an important first step toward designing a mitigation goal (Section 4.1 provides information on developing a GHG inventory). This standard uses the inventory and underlying inventory methodologies-  such as the Intergovernmental Panel on Climate Change (IPCC) Guidelines for National Greenhouse Gas Inventories 3 -  as a starting point for generating the emissions data necessary for assessing progress toward mitigation goals so that consistency with the inventory methodology is maintained.

Mitigation goals accounting differs from inventory accounting in a few ways. Most existing GHG inventory guidelines 4  do not provide guidance on how to design mitigation goals or how to assess and report progress toward achieving them. While a GHG inventory covers the full range of a jurisdiction's emissions and removals across all sectors and gases, accounting for mitigation goals focuses on those sectors and gases included in the goal boundary, which may be the same or a subset of total emissions. Goals accounting also includes purchases and sales of transferable emissions units (such as offset credits and allowances), if applicable, and emissions and removals from the land sector, which may be accounted for differently than under an inventory approach, given the treatment of natural disturbances or legacy effects. Assessing and reporting progress toward mitigation goals should be carried out in conjunction with regularly developing and updating a GHG inventory.

## 1.9 Relationship to the GHG Protocol Policy and Action Standard

The GHG Protocol Mitigation Goal Standard and GHG Protocol Policy and Action Standard are both intended to support users in assessing and reporting progress toward GHG mitigation objectives (see Table 1.1). The two standards were developed simultaneously as part of the same standard development process in order to ensure harmonization of overlapping topics, where they exist (for example, the development of baseline scenarios, uncertainty analysis, verification procedures, and accounting and reporting principles).

While each standard can be implemented independently, the standards can also be used together. For example, users may apply the Mitigation Goal Standard to understand the level of GHG reductions needed to meet a GHG mitigation goal and then use the Policy and Action Standard to estimate the GHG effects of selected policies and actions to determine if they are collectively sufficient to achieve the goal. Conversely, users may first apply the Policy and Action Standard to estimate expected GHG reductions from various mitigation policies to understand the range of achievable GHG reductions and then use the Mitigation Goal Standard to design a mitigation goal and assess and report progress.

Some goals may be framed in terms of a target quantity of emission reductions to be achieved by implementing a group of policies, actions, or projects, rather than in terms of an overarching economy-  wide or sectoral mitigation goal. For these types of goals, users should assess progress by estimating the GHG impact of the group of policies, actions, or projects using the Policy and Action Standard (for policies and actions) or the GHG Protocol for Project Accounting (for individual projects).

## 1.10 Terminology: shall, should, and may

This standard uses precise language to indicate which provisions of the standard are requirements, which are recommendations, and which are permissible or allowable options that users may choose to follow. The term ' shall ' is used throughout this standard to indicate what is required in order to be in conformance with the standard. The term ' should ' is used to indicate a recommendation but not a requirement. The term ' may ' is used to indicate an option that is permissible or allowable. The term 'required' is used in the guidance to refer to requirements in the standard. 'Needs,' 'can,' and 'cannot' are used to provide guidance on implementing a requirement or to indicate when an action is or is not possible.

## table 1.1 comparison of ghg protocol Mitigation Goal Standard and the ghg protocol Policy and Action Standard

| standard                   | description                                                                                                                                                                                                                                                                                                                                   |
|----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Mitigation Goal Standard   | How to assess and report overall progress toward national, subnational, or sectoral GHG reduction goals. Types of mitigation goals include GHG reductions from a base year, reductions to a fixed-level of emissions (zero in the case of carbon neutrality), reductions in emissions intensity, and GHG reductions from a baseline scenario. |
| Policy and Action Standard | How to estimate the greenhouse gas effects of policies and actions. Types of policies and actions include regulations and standards; taxes and charges; subsidies and incentives; information instruments; voluntary agreements; implementation of new technologies, processes, or practices.                                                 |

<!-- image -->

## 1.11 Limitations

Users should exercise caution in comparing the results of assessments of different jurisdictions' goals based on this standard even if they are the same type of goal. Differences in reported emissions levels or emission reductions may be a result of differences in data sources or methods (for example, when accounting options exist) rather than realworld differences. Efforts to ensure additional consistency may be necessary to enable valid comparisons. In general, comparable results can best be achieved if goal assessments are undertaken using comparable data, assumptions, and methodologies (such as inventory methodology and global warming potential values), which can enhance consistency between assessments. To understand whether comparisons are valid, all methodologies, assumptions, and data sources used must be transparently reported. Results that are not comparable should not be aggregated, either within jurisdictions or across jurisdictions.

## endnotes

- 1.  To quantify GHG reductions from NAMAs framed as individual projects, see the GHG Protocol for Project Accounting (2005). For assessing NAMAs framed as policies and actions, see the GHG Protocol Policy and Action Standard (2014).
- 2.  This standard would be superseded by any international or domestic program requirements.
- 3.  The most recent full version of the IPCC Guidelines was published in 2006 and can, with earlier guidance and more recent supplementary material, be accessed at http://www.ipcc-  nggip.iges.or.jp/.
- 4.  Global Protocol for Communities (GPC), an inventory guideline for cities, has incorporated the Mitigation Goal Standard as part of its inventory guideline. See GPC 2014: Chap. 11.

2

<!-- image -->

## Overview of Steps, Key Concepts, and Requirements

<!-- image -->

T his  chapter  provides  an  overview  of  the  steps  involved  in  assessing  and reporting progress toward mitigation goals, an introduction to key concepts used in the standard, and a checklist of the accounting requirements that must be followed for a goal assessment to be in conformance with this standard.

## 2.1 Overview of steps

## 2.2 Key concepts

This standard is organized according to the steps a user follows in assessing and reporting goal progress. See Figure 2.1 for an overview of steps in this standard.

Depending on individual objectives and the stage at which this standard is applied, users may not need to follow all of the steps in Figure 2.1. If users have already designed a goal and calculated base year emissions or baseline scenario emissions, the guidance in Chapters 4 and 5 may be skipped, but accounting and reporting requirements apply to all users  Chapters 6 and 7 include . guidance and accounting and reporting requirements that are relevant to all users. Chapter 8 should be applied during the goal period, while users should apply Chapter 9 only at the end of the goal period. All users are required to fulfill the reporting requirements in Chapter 11.

This section describes key concepts used in this standard.

## 2.2.1 Jurisdiction

A jurisdiction is the geographic territory over which authority to make legal decisions and judgments is exercised. This standard can be applied toward mitigation goals covering all levels of jurisdictions, including cities, municipalities, districts, states, provinces, and countries, among others. Goals may include both in-  jurisdiction emissions, emissions from sources located within the jurisdiction, and out-  ofjurisdiction emissions, emissions from sources located outside of jurisdiction that occur as a consequence of activities within that boundary.

## 2.2.2 mitigation goal types

A mitigation goal is a commitment to reduce, or limit the increase of, GHG emissions 1  or emissions intensity by a specified quantity, to be achieved by a future date. This standard is primarily designed to support the four goal types listed in Table 2.1. It may be applied at the national or

figure 2.1 overview of steps for mitigation goal accounting

<!-- image -->

| overarching steps             | detailed steps                                        |   chapter |
|-------------------------------|-------------------------------------------------------|-----------|
| define goal/methods           | Design a mitigation goal                              |         4 |
| define goal/methods           | Estimate base year or baseline scenario emissions     |         5 |
| define goal/methods           | Account for the land sector                           |         6 |
| calculate allowable emissions | Calculate allowable emissions in the target year(s)   |         7 |
| assess progress/ achievement  | Assess progress during the goal period                |         8 |
| assess progress/ achievement  | Assess goal achievement at the end of the goal period |         9 |
| verify                        | Verify results (optional)                             |        10 |
| report                        | Report results and methodology used                   |        11 |

subnational level to and to either economy-  wide or sectoral goals. Chapter 4 provides further information on goal types.

## 2.2.3 goal boundary

The goal boundary refers to the geographic area, sectors, and greenhouse gases covered by the goal. It may include out-  of-  jurisdiction emissions and removals. How the boundary is defined can have a significant impact on the ambition of the mitigation goal, as well as the opportunities available for achieving the goal. The goal boundary may differ from the GHG inventory boundary. The GHG inventory boundary may cover more greenhouse gases, sectors, and geographic area than the goal boundary. Chapter 4 provides guidance on defining the goal boundary.

## 2.2.4 single-  year and multi-  year goals

Some goals are designed to achieve emission reductions (or reductions in intensity) by a single future year. This standard refers to such goals as single-  year goals. Other goals are designed to achieve emission reductions (or reductions in intensity) over several years. This standard refers to these goals as multi-  year goals. Single-  year goals limit emissions in one future year-  the target year-  while multi-  year goals aim to limit cumulative emissions over multiple yearsthe target period. A user may choose to adopt a series of single-  year or multi-  year goals along an emissions trajectory.

## 2.2.5 Base year emissions or emissions intensity

Base year emissions or emissions intensity levels are used as a reference point to set base year emissions goals and base year intensity goals. A base year is a specific year of historical emissions data. It is also the first year of the goal period. Users may also choose a base period-  an average of multiple years of historical emissions datainstead of a base year, especially when there are significant fluctuations in emissions levels over time. Base year and base period emissions are the emissions and removals

table 2.1 overview of mitigation goal types

| goal type                | description                                                                                                                                                                                                                                                                                                                                   | reductions in what?   | reductions relative to what?          |
|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------|---------------------------------------|
| Base year emissions goal | Reduce, or control the increase of, emissions by a specified quantity relative to a base year. For example, a 25% reduction from 1990 levels by 2020.                                                                                                                                                                                         | Emissions             | Historical base year emissions        |
| fixed-level goal         | Reduce, or control the increase of, emissions to an absolute emissions level in a target year. One type of fixed-level goal is a carbon neutrality goal, which is designed to reach zero net emissions by a certain date.                                                                                                                     | Emissions             | No reference level                    |
| Base year intensity goal | Reduce emissions intensity (emissions per unit of another variable, typically GDP) by a specified quantity relative to a base year. For example, a 40% reduction from 1990 base year intensity by 2020.                                                                                                                                       | Emissions intensity   | Historical base year emissions        |
| Baseline scenario goal   | Reduce emissions by a specified quantity relative to a projected emissions baseline scenario. A baseline scenario is a reference case that represents future events or conditions most likely to occur in the absence of activities taken to meet the mitigation goal. For example, a 30% reduction from baseline scenario emissions in 2020. | Emissions             | Projected baseline scenario emissions |

within the goal boundary in the specified reference year or years, derived from the jurisdiction's GHG inventory.

figure 2.2 Baseline scenario emissions

A base year or base period also is relevant to users with base year intensity goals because these goals are also tracked against historical data. However, in the case of base year intensity goals, progress is tracked in terms of emissions per unit of another variable (typically output, such as GDP). Users with base year intensity goals will need to calculate output in the base year or base period in addition to GHG emissions. This will be an input into calculating base year emissions intensity.

Chapter 4 provides guidance on selecting a base year or base period. Chapter 5 provides guidance on calculating base year emissions or emissions intensity.

## 2.2.6 Baseline scenario emissions

Baseline scenario emissions are used as a reference point to set baseline scenario goals (Figure 2.2). A baseline

<!-- image -->

scenario is a hypothetical or projected reference case that represents future events or conditions most likely to occur in the absence of activities taken to meet a mitigation goal. Baseline scenarios are sometimes referred to as business-  as-  usual (BAU) scenarios. In this standard, 'baseline scenario' is used as a general term to refer to any type of emissions projection. The term 'BAU scenario' is often used to refer to a type of baseline scenario that includes already implemented and adopted policies. Developing a baseline scenario may depend on a wide variety of inputs, such as data on factors that drive emissions (economic activity, energy prices, population growth, etc.), assumptions about how emissions drivers are expected to change over the goal period, and data on the effects of implemented or adopted policies and actions. Baseline scenario emissions are an estimate of the GHG emissions associated with the baseline scenario. Chapter 5 provides guidance on developing a baseline scenario.

## 2.2.7 land sector accounting

In the land sector, emissions and removals included in a GHG inventory can include fluxes of both anthropogenic origin (such as deforestation) and non-  anthropogenic origin (such as disease outbreaks). In order to target land-  use categories or activities that can be most directly influenced by humans, users may choose to include a particular set of land-  use categories and activities within the goal boundary and account for them using land-  use-  specific mitigation accounting methods.

The land sector may be treated in four ways: included in the goal boundary, treated as a separate sectoral goal, treated as an offset, or not accounted for. How land sector emissions and removals are incorporated into the mitigation goal can have a significant impact on the overall reductions achieved as a result of the goal. Users should consider their objectives, circumstances, and capacities when making policy and methodological choices about the treatment of the land sector and be transparent about this from the outset when describing their choices. Chapter 4 provides guidance on how to treat the land sector when designing a mitigation goal. Chapter 6 provides guidance on accounting for land sector emissions and removals.

## 2.2.8 allowable emissions

Allowable emissions are the maximum quantity of emissions that may be emitted in the target year or target period-  the last year(s) of the goal period-  consistent with achieving the mitigation goal (see Figure 2.3). Calculating allowable emissions enables users to understand the emissions level that must be met in the target year(s) to achieve the goal. It also allows helps in assessing progress and determining goal achievement.

## 2.2.9 transferable emissions units

Transferable emissions units include offset credits generated from emission reduction projects or programs-  such as Clean Development Mechanism (CDM) projects-  and emissions allowances issued to participants of emissions trading programs. They can be generated beyond the jurisdictional boundary-  for example, in the case of a national jurisdiction, in another country-  or within the jurisdictional boundary but in sectors or gases not included in the goal boundary.

Some mitigation goals may be achieved by a combination of emission reductions within the goal boundary and transferable emissions units from outside the goal boundary applied toward the goal. See Figure 2.4 for an illustration of using transferable emissions units toward meeting a goal. In the figure, emissions within the goal boundary in the target year exceed allowable emissions, so transferable emissions units are used to make up the difference. In all cases, users should take steps to ensure the environmental integrity of any units used toward the goal and account for both retirement and sales of units. Chapter 4 provides guidance on ensuring the environmental integrity of units, and Chapter 9 provides equations for accounting for units.

## 2.2.10  goal achievement

At the end of the goal period, goal achievement is assessed by comparing allowable emissions to accountable emissions , or the quantity of emissions and removals that users apply toward achieving the goal. Accountable emissions include emissions and removals within the goal boundary in the target year as well as sales and retirement of transferable emissions units, if applicable, and change in net land sector emissions, depending on how the land sector is treated in the goal design. Transferable emissions units sold in

figure 2.3 allowable emissions in the target year

<!-- image -->

figure 2.4 use of transferable emissions units toward meeting a goal

<!-- image -->

the target year(s) are added to target year emissions in the goal boundary, and transferable emissions units retired and applied toward the goal are subtracted to prevent double counting of units. See Figure 2.5.

If accountable emissions are equal to or less than allowable emissions in the target year(s), then the goal has been achieved (see Table 2.2). Chapter 9 provides guidance on assessing goal achievement. Appendix A provides a sample GHG balance sheet to help users track annual sales and retirement of transferable emissions units.

<!-- image -->

## 2.3 Example of following the steps in the standard

Table 2.3 provides a simplified example of the application of the steps in the standard. Table 2.3 is only intended to illustrate the various steps. A goal assessment following this standard should be more detailed and comprehensive.

figure 2.5 calculating accountable emissions*

<!-- image -->

- * For users that do not treat the land sector as an offset.

table 2.2 assessing goal achievement

| if . . .                                      | then . . .           |
|-----------------------------------------------|----------------------|
| accountable emissions - < allowable emissions | Goal is achieved     |
| accountable emissions > allowable emissions   | Goal is not achieved |

table 2.3 example of applying the steps in the standard for an illustrative goal

| chapter                                                          | simplified example for an illustrative goal                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| chapter 4: designing a mitigation goal                           | The mitigation goal is a single-year base year emissions goal for a national jurisdiction to reduce GHG emissions by 20 percent relative to 1990 levels by 2020. The goal covers all seven greenhouse gases under the Kyoto Protocol, all IPCC sectors, the entire land sector, all in-jurisdiction emissions, and the mainland territory of the national jurisdiction. The goal will be achieved in part by the use of transferable emissions units. However, these units will account for no more than 3 percent of overall reductions, and they will be generated through the Clean Development Mechanism. A transaction log will be used to prevent double counting between the selling and purchasing jurisdictions. |
| chapter 5: estimating Base year or Baseline scenario emissions   | The base year emissions are 900 Mt CO 2 e.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| chapter 6: accounting for the land sector                        | A land-based accounting approach is used, with comprehensive coverage of all carbon pools and fluxes. No natural disturbance mechanism is adopted.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| chapter 7: calculating allowable emissions in the target year(s) | For base year emissions goals: • Allowable emissions in the target year (Mt CO 2 e) = base year emissions (Mt CO 2 e) - (base year emissions (Mt CO 2 e) × percent reduction) • 900 Mt CO 2 e - (900 Mt CO 2 e × 0.20) = 720 Mt CO 2 e Allowable emissions in the target year are 720 Mt CO 2 e.                                                                                                                                                                                                                                                                                                                                                                                                                          |
| chapter 8: assessing progress during the goal period             | The reporting year is 2013. Emissions in the goal boundary in 2013 are 800 Mt CO 2 e. Additional emission reductions needed to achieve the goal are 80 Mt CO 2 e in 2020.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| chapter 9: assessing goal achievement                            | To assess goal achievement, accountable emissions in the target year are compared to allowable emissions in the target year (2020). Target year emissions are 730 Mt CO 2 e; 10 Mt CO 2 e are sold in the target year; and 20 Mt CO 2 e are retired in the target year. • Accountable emissions (Mt CO 2 e) = emissions within the goal boundary in the target year (Mt CO 2 e) + transferable emissions units sold in the target year (Mt CO 2 e) - transferable emissions units retired in the target year (Mt CO 2 e) • 730 Mt CO 2 e + 10 Mt CO 2 e - 20 Mt CO 2 e = 720 Mt CO 2 e Accountable emissions in (2020) are 720 Mt CO 2 e. Allowable emissions are 720 Mt CO 2 e. The goal is achieved.                    |
| chapter 10: verification                                         | Verification is conducted by a third-party verifier. Reasonable assurance is provided.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| chapter 11: reporting                                            | All reporting requirements are met. The goal assessment report is made publicly available online.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |

## 2.4 Requirements in the standard

This standard includes accounting and reporting requirements to help users design a goal and develop a GHG assessment that represents a true and fair account of progress toward goal achievement. Table 2.4 provides a checklist of the accounting requirements included in this standard. Subsequent chapters provide guidance and explanations of terms and concepts in the table. Accounting requirements are also summarized in a box at the beginning of each chapter. Reporting requirements are listed in Chapter 1 1.

As described in Chapter 1, the term 'shall' is used throughout the standard to indicate requirements. 'Should' is used to indicate a recommendation, but not a requirement, while 'may' is used to indicate an option that is permissible or allowable. Table 2.4 compiles all the 'shall' statements that are related to accounting, while 'shall' statements related to reporting are compiled in Chapter 1 1.

table 2.4 requirements in this standard

| chapter                                                        | accounting requirement                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
|----------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| chapter 3: accounting and reporting principles                 | • GHG accounting and reporting shall be based on the principles of relevance, completeness, consistency, transparency, and accuracy.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| chapter 4: designing a mitigation goal                         | • For national jurisdictions: use the Intergovernmental Panel on Climate Change (IPCC) Guidelines for National Greenhouse Gas Inventories to develop a national GHG inventory. • Apply global warming potential (GWP) values provided by the IPCC based on a 100-year time horizon. • For national jurisdictions that choose to set a goal for out-of-jurisdiction emissions: define separate goals for in-jurisdiction and out-of-jurisdiction emissions. • For users with dynamic baseline scenario goals: develop and report a baseline scenario recalculation policy at the start of the goal period, including which exogenous drivers will trigger a recalculation. • For users with both short-term and long-term goals: account for each separately. • For users that apply offset credits toward the goal: use offsets credits that are real, additional, permanent, transparent, verified, owned unambiguously, and address leakage. • For users that apply emissions allowances toward the goal: use allowances that come from emissions trading systems with rigorous monitoring and verification protocols, transparent tracking and reporting |
| chapter 5: estimating Base year or Baseline scenario emissions | For users with base year or base year intensity goals: • Calculate base year or base period emissions by aggregating emissions from the GHG inventory for all gases and sectors included in the goal boundary, including out-of-jurisdiction emissions, if relevant. • For users that treat the land sector as an offset: calculate net base year emissions in the land sector separately from other sectors. For users with base year intensity goals: • Calculate base year emissions intensity. For users with baseline scenario goals: • Develop a goal baseline scenario that covers the same sectors, gases, and in-jurisdiction and out-of- jurisdiction emissions as the goal boundary. • Use a time frame for the baseline scenario that is at least as long as the goal period. • Estimate goal baseline scenario emissions in the target year(s). For users that treat the land sector as an offset and apply the forward-looking baseline accounting method: • Calculate baseline scenario emissions in the land sector separately from other sectors.                                                                                          |

table 2.4 requirements in this standard (continued)

| chapter                                                          | accounting requirement                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
|------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| chapter 6: accounting for the land sector                        | If the land sector is included in the goal boundary, treated as a separate sectoral goal, or used as an offset: • Account for emissions and removals arising from land use and land-use change within elected land- use categories or activities. • Account for changes in all significant land-based carbon pools, GHG fluxes, and subcategories/ activities within elected land-use categories or suites of activities. • Account for harvested wood products using one of the relevant IPCC methodologies and/or good practice guidance and taking account any UNFCCC or other decisions that are relevant. • If factoring out natural disturbances: • Exclude any removals on lands affected by a natural disturbance from accounting until they have balanced the quantity of emissions removed from accounting. • If relevant, ensure consistency with the treatment of natural disturbances in the base year, base period, or baseline scenario, including by excluding removals associated with the previously disturbed land in the base year or period or baseline. • Do not exclude emissions associated with salvage logging. • Do not exclude emissions from natural disturbances on lands that are subject to land-use change following the disturbance. • Undertake all relevant land-sector accounting and reporting steps again if: • Users change the land sector accounting approach during the goal period. • Users add a land category, subcategory, or activity to accounting, or change the treatment of an existing land category, subcategory, or activity. • Users revise the goal level to compensate for non-additional emissions or emission reductions. |
| chapter 7: calculating allowable emissions in the target year(s) | • Calculate allowable emissions in the target year(s). • For users with base year intensity goals: calculate allowable emissions intensity in the target year(s).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| chapter 8: assessing progress during the goal period             | For users that assess progress during the goal period: • Calculate reporting year emissions by aggregating emissions from the GHG inventory for all gases and sectors included in the goal boundary and out-of-jurisdiction emissions, if relevant. • For users with base year intensity goals: calculate reporting year emissions intensity. • For users that treat the land sector as an offset: calculate the change in net land sector emissions in the reporting year from selected land-use categories, activities, and pools and fluxes based on the chosen land-use accounting method. • Recalculate (1) base year emissions, base year emissions intensity, or baseline scenario emissions; (2) allowable emissions or emissions intensity; and/or (3) reporting year emissions if significant changes are made to methods used and/or significant errors in original calculations are discovered. • For users with dynamic baseline scenario goals: recalculate baseline scenario emissions by replacing forecasted values with observed values for all significant exogenous emissions drivers.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |

## table 2.4 requirements in this standard (continued)

| chapter                                                          | accounting requirement                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| chapter 8: assessing progress during the goal period (continued) | For users that assess progress during the goal period (continued): • If baseline scenario emissions are recalculated, recalculate allowable emissions (by reapplying Chapter 7) to ensure consistency. • Recalculate (1) base year emissions, base year emissions intensity, or baseline scenario emissions; (2) allowable emissions or emissions intensity; and (3) reporting year emissions if significant revisions are made to the goal boundary (for example, changes in sectors, gases, or geographic area). • Recalculate (1) allowable emissions or emissions intensity and (2) reporting year emissions if the goal type or goal level is changed or the goal is changed from a single-year goal to a multi-year goal. • For users that change the goal type, goal level, or change from a single-year goal to a multi-year goal: follow all accounting and reporting requirements for the new goal by reapplying all relevant chapters.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| chapter 9: assessing goal achievement                            | For users that assess goal achievement at the end of the goal period: • Calculate target year or period emissions by aggregating emissions from the GHG inventory for all gases and sectors included in the goal boundary, including out-of-jurisdiction emissions, if relevant. • Do not double count, double sell, or double claim transferable emissions units. • Correct relevant registries, accounts, and reported emissions in the event that double counting is observed. • Calculate accountable emissions. • For users that treat the land sector as an offset: calculate the change in net land sector emissions in the target year from selected land-use categories, activities, and pools and fluxes based on the chosen land-use accounting method. • For users that have chosen to cap the quantity of land sector emissions and removals that can be applied toward the goal: apply the cap when calculating accountable emissions. • For users with base year intensity goals: calculate accountable emissions intensity. • Recalculate (1) base year emissions, base year emissions intensity, or baseline scenario emissions; (2) allowable emissions or emissions intensity; (3) reporting year emissions; and (4) target year(s) emissions if significant changes are made to methods used and/or significant errors in original calculations are discovered. • For users with dynamic baseline scenario goals: recalculate baseline scenario emissions by replacing forecasted values with observed values for all exogenous emissions drivers. • If base year or baseline scenario emissions are recalculated, recalculate allowable emissions (by reapplying Chapter 7) to ensure consistency. • Compare accountable emissions to allowable emissions in the target year(s) to assess goal achievement at the end of the goal period. • For users with base year intensity goals: compare accountable emissions intensity to allowable emissions intensity in the target year(s). |
| chapter 11: reporting                                            | • See Chapter 11 for a list of reporting requirements.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |

## endnotes

- 1.  Or enhance removals. Enhanced removals should come from longterm carbon sequestration.

<!-- image -->

3

Accounting and Reporting Principles

<!-- image -->

A ccounting principles are intended to underpin and guide GHG accounting and reporting to ensure that goal assessments represent a true and fair account of progress achieved. The five principles described below are intended to guide the implementation of the standard and the assurance of goal assessments, particularly when application of the standard in specific situations is ambiguous.

table 3.1 checklist of accounting requirements in this chapter

| section                                        | accounting requirements                                                                                                              |
|------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|
| chapter 3: accounting and reporting principles | • GHG accounting and reporting shall be based on the principles of relevance, completeness, consistency, transparency, and accuracy. |

GHG accounting and reporting shall be based on the following five principles:

relevance: Ensure that the GHG information provided in the goal assessment appropriately reflects the decisionmaking needs of users-  both internal and external to the reporting entity. Users should use the principle of relevance when carrying out steps where a range of options is provided, including designing the goal (Chapter 4), and when making methodological decisions during goal assessment. Applying the principle of relevance depends on the objectives of the assessment.

completeness: Account and report all GHG emissions and removals included in the goal boundary. Users should not exclude any emissions or removals from the assessment that would compromise the relevance of the assessment. In the case of any exclusions (for example, if the user lacks data), it is important that all exclusions be disclosed and justified.

consistency: Use consistent methods, data, assumptions, and calculations throughout the goal period to estimate GHG emissions and removals to ensure the generation of comparable GHG emissions data over time and the accurate assessment of progress toward the goal. Disclose and justify any changes to data, boundary,

<!-- image -->

methods, or any other relevant factors in the time series, as well as any recalculations of past emissions data.

transparency: Provide clear and sufficient information for reviewers to assess the credibility and reliability of reported progress toward a mitigation goal. Information on the processes, procedures, assumptions, and limitations of the goal assessment should be recorded, compiled, and analyzed in a way that enables internal reviewers and verifiers to attest to its credibility. Specific exclusions need to be clearly identified and justified, assumptions disclosed, and appropriate references provided for the methods applied and the data sources used. The information should be sufficient to enable a party external to the goal assessment process to derive the same results if provided with the same source data.

accuracy: Ensure that GHG measurements, estimates, or calculations and non-  GHG data, especially socioeconomic data used to develop baselines scenarios, is systemically neither over nor under the actual value, as far as can be judged. Data should be sufficiently accurate to enable intended users and stakeholders to make decisions with reasonable confidence that reported information is credible. Users should reduce uncertainties as far as practicable and ensure the data are sufficiently accurate to serve decision-  making needs. Users should apply conservative assumptions, values, and procedures when uncertainty is high and the cost of measures to reduce uncertainty is not worth the increase in accuracy. Conservative values and assumptions are those that are more likely to overstate GHG emissions or underestimate GHG reductions. Reporting on measures taken to ensure accuracy and improve accuracy over time can help promote credibility and enhance transparency.

## g u i d a n c e

In practice, users may encounter tradeoffs between principles when developing a goal assessment. For example, a user may find that achieving the most complete assessment requires using less accurate data, compromising overall accuracy. Conversely, achieving the most accurate assessment may require that certain sectors or gases with low accuracy are excluded from the goal boundary, compromising overall completeness. Users should balance tradeoffs between principles depending on their objectives. Over time, as the accuracy and completeness of data increase, the tradeoff between these accounting principles will likely diminish.

Uncertainties in data (for example, inventory data) can influence mitigation goal accounting and the ability of users to fully achieve completeness or accuracy during goal design. Users should continue to improve data over time as they assess progress toward goal achievement.

<!-- image -->

4

Designing a Mitigation Goal

<!-- image -->

<!-- image -->

T his chapter provides guidance on designing a mitigation goal. Users that have already designed a mitigation goal may skip the guidance provided in  this  chapter.  However,  the  accounting  and  reporting  requirements  in this  chapter  apply  to  all  users.  The  sequence  of  steps  (Figure  4.1)  presented  is illustrative. Users may design their goal by following any sequence of steps.

figure 4.1 overview of steps in this chapter

prepare for goal design (section 4.1)

define goal boundary (section 4.2)

<!-- image -->

decide on use of transferable emissions units (section 4.5)

<!-- image -->

define goal level (section 4.6)

<!-- image -->

choose goal type (section 4.3)

<!-- image -->

define goal time frame (section 4.4)

<!-- image -->

table 4.1 checklist of accounting requirements in this chapter

| section                                                     | accounting requirement                                                                                                                                                                                                                                                                                                                                                                                                       |
|-------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| prepare for goal design (section 4.1)                       | • Use the Intergovernmental Panel on Climate Change (IPCC) Guidelines for National Greenhouse Gas Inventories to develop a national GHG inventory (for national jurisdictions). • Apply global warming potential (GWP) values provided by the IPCC based on a 100-year time horizon.                                                                                                                                         |
| define goal boundary (section 4.2)                          | • For national jurisdictions that choose to set a goal for out-of-jurisdiction emissions: define separate goals for in-jurisdiction and out-of-jurisdiction emissions.                                                                                                                                                                                                                                                       |
| choose goal type (section 4.3)                              | • For users with dynamic baseline scenario goals: develop and report a baseline scenario recalculation policy at the start of the goal period, including which exogenous drivers will trigger a recalculation.                                                                                                                                                                                                               |
| define goal time frame (section 4.4)                        | • For users with both short-term and long-term goals: account for each separately.                                                                                                                                                                                                                                                                                                                                           |
| decide on use of transferable emissions units (section 4.5) | • For users that apply offset credits toward the goal: use offsets credits that are real, additional, permanent, transparent, verified, owned unambiguously, and address leakage. • For users that apply emissions allowances toward the goal: use allowances that come from emissions trading systems with rigorous monitoring and verification protocols, transparent tracking and reporting of units, and stringent caps. |

Note: Reporting requirements are listed in Chapter 11. Some goal types have no requirements and therefore are not referenced in the table; however, there is guidance throughout the chapter for all goal types.

Box 4.1 summarizes the key considerations included in this chapter for goal design that can maximize emission reductions, measurability, and completeness.

track changes in GHG emissions and removals and at the end of the goal period to assess whether a mitigation goal has been achieved.

## 4.1 Prepare for goal design

Preparing for goal design involves:

- · Developing a GHG inventory
- · Understanding mitigation needs and opportunities

Each activity is described further below.

## 4.1.1 develop a ghg inventory

Developing a GHG inventory is a critical first step in designing and setting a GHG mitigation goal. While the full inventory may be more complete than the chosen goal boundary, GHG inventories are needed to identify high emitting sectors and prioritize mitigation opportunities. A GHG inventory is also required during the goal period to

To develop a GHG inventory, users in national jurisdictions shall use the IPCC Guidelines for National Greenhouse Gas Inventories . Users in national jurisdictions should use the most up-  to-  date IPCC guidance and guidelines agreed under the UNFCCC. Users in subnational jurisdictions should use internationally accepted methods and guidelines such as the Global Protocol for Community-  Scale Greenhouse Gas Emission Inventories (GPC), in addition to relevant IPCC methods. If uncertainties in the inventory are high, users should consider the principle of conservativeness to increase the likelihood of achieving the goal.

To quantify emissions, users shall apply global warming potential (GWP) values provided by the IPCC based on a 100-  year time horizon. GWP values describe the radiative

## Box 4.1   key considerations for designing a goal that can maximize emission reductions, measurability, and completeness

If the objective of the goal design is to maximize emission reductions, measurability, and completeness, users should consider the following:

- · minimizing leakage: Emission increases outside of the goal boundary can be minimized by including significant out-  of-  jurisdiction emissions in the goal boundary, which may be especially relevant for subnational jurisdictions, such as cities. (Section 4.2.4)
- · choice of goal time frame: Multi-  year goals have a better chance of limiting cumulative emissions over the goal period than single-  year goals, and they facilitate understanding of anticipated emissions levels over multiple years, rather than only a single year. This can better reveal whether cumulative emission reductions are aligned with meeting global temperature targets. (Section 4.4.2)
- · choice of goal type: Base year emissions goals and fixed-level goals are simpler to account for, more certain, and more transparent than base year intensity goals and baseline scenario goals, because allowable emissions in the target year(s) can be easily calculated at the beginning of the goal period, and progress can be tracked using the GHG inventory alone without the need for additional models, socioeconomic data, or assumptions. (Section 4.3)
- · Users seeking to accommodate short-  term emission increases should consider adopting base year emissions goals or fixed-level goals that are framed as a controlled increase in emissions from a base year. (Section 4.4)
- · Static baseline scenario goals provide more certainty and transparency regarding intended future emissions levels than dynamic baseline scenario goals, since they represent a fixed point against which to calculate allowable emissions and assess progress. Static baseline scenario goals also introduce fewer practical challenges than dynamic baseline scenario goals. (Section 4.3)

forcing impact (or degree of harm to the atmosphere) of 1 unit of a given GHG relative to 1 unit of carbon dioxide, and they convert GHG emissions data for non-  CO  gases 2 into units of carbon dioxide equivalent (CO e). Users may 2 use either (1) the IPCC GWP values agreed to by the UNFCCC or (2) the most recent GWP values published by the IPCC. Users shall report the GWP values used.

- · Adopting a combination of short-  term and long-  term goals provides more clarity for long-  term planning and better ensures a decreasing emissions pathway. (Section 4.4.3)
- · use of transferable emissions units. For the greatest environmental integrity and most consistent accounting, ensure that any transferable emissions units applied toward a goal meet the highest quality principles and are generated in the target year or period. (Section 4.5)
- · Mechanisms for tracking units between buyers and sellers can strengthen the environmental integrity of mitigation goals and prevent double counting. (Section 4.5.4)
- · choice of goal level: The goal level should significantly reduce emissions below the jurisdiction's business-  asusual emissions trajectory (taking into account currently implemented and adopted mitigation policies) and correspond to an emissions trajectory that is in line with the level of emission reductions necessary to avoid dangerous climate change impacts, as determined by the most recent climate science. (Section 4.6)

## 4.1.2 understand mitigation needs and opportunities

To inform the design of the goal, users should consider both global mitigation needs and jurisdiction-  specific mitigation opportunities and development and policy objectives. Recent findings from climate science, such as IPCC reports, can help users understand the magnitude of emission reductions needed to limit warming and avoid the most dangerous climate change impacts, and these findings

should be a primary input into the design of a mitigation goal, especially regarding the goal level and goal boundary.

Based on the jurisdiction's GHG inventory, users may also choose to assess how each sector and greenhouse gas contributes to the overall emissions profile of the jurisdiction. Based on this information, users could identify mitigation opportunities using mitigation assessment methods, which indicate the magnitude of available reduction opportunities and the potential costs and benefits associated with each. The basic analytical framework for mitigation assessments includes the following activities (based on Tirpak et al. 1995):

- · Developing an informational baseline scenario that represents the growth in emissions most likely to occur in the absence of a mitigation goal or future mitigation activities (Chapter 5 provides guidance on developing baseline scenarios) 1
- · Identifying and characterizing mitigation options, including policies, actions, and technologies, based on factors such as mitigation potential, cost, ease of implementation, and co-  benefits
- · Developing alternative scenarios that represent likely emissions trajectories that would occur if mitigation strategies were implemented
- · Estimating incremental costs and benefits, including cobenefits, of mitigation strategies

If a mitigation assessment is conducted, it should be undertaken in an open and transparent manner that engages relevant stakeholders and includes public review and comment periods. Detailed technical guidance on mitigation assessments can be obtained from the IPCC and the UNFCCC, among other sources (see Tirpak et al. 1995; UNFCCC 2013a; Sathaye and Meyers 1995).

## 4.2 Define goal boundary

The goal boundary refers to the geographic area, sectors (including the land sector), in-  jurisdiction and out-  ofjurisdiction emissions and removals, and greenhouse gases covered by a mitigation goal. How the goal boundary is defined has a significant impact on the emission reductions that can be generated under the mitigation goal, as well as the mitigation opportunities available for achieving the goal. The goal boundary may differ from the GHG inventory boundary, which typically covers all greenhouse gases, sectors, geographic area, and in-  jurisdiction emissions. Each step for defining the goal boundary is described below.

Users shall report the percentage of total inventory emissions that is included in the goal boundary in the base year or start year of the baseline scenario, including the land sector, if relevant. The percentage is calculated by dividing emissions included in the goal boundary in the base year or start year by total GHG inventory emissions in the base year or start year.

## 4.2.1 define geographic coverage

The first step in designing the goal boundary is to define the geographical territory covered by the goal. In most instances, the geographic coverage will be the same as the jurisdiction's geopolitical boundary. In some cases users may choose to exclude certain parts of the jurisdiction's territory from the goal boundary. (Out-  of-  jurisdiction emissions are separately addressed in Section 4.2.4.)

Users shall report the geographic coverage of the goal, and disclose any protectorates, departments, overseas territories, dependencies, or other territories excluded from the goal boundary. Users seeking to set a comprehensive goal should not exclude territory with significant emissions sources from the goal boundary. Users should provide a rationale for any excluded territories and an indication of the magnitude of emissions (in Mt CO e) associated with 2 the excluded territories.

## 4.2.2 choose sectors

The next step is to choose which sectors to include in the goal boundary. The IPCC 2006 Guidelines for National Greenhouse Gas Inventories (IPCC 2006) groups GHG emissions and removals into five main sectors: (1) energy; (2) industrial processes and product use (IPPU); (3) agriculture, forestry, and other land use (AFOLU); (4) waste; and (5) other. Users including AFOLU in the goal boundary should separately report agriculture and land use because of the special accounting rules that may apply to the latter (see the guidance in Chapter 6).

Users shall report the sectors and subsectors included in the goal boundary and disclose any exclusions. Users shall report the definitions of the sectors and subsectors

included in the goal. Users with sectoral goals shall report any out-  of-  sector emissions included in the goal boundary. If sector definitions are used that deviate from the most recent IPCC Guidelines for National Greenhouse Gas Inventories , users should provide an explanation for why IPCC-  defined sectors were not used and information on the alternative sector definitions, including an explanation of how nonIPCC sector definitions correspond to IPCC definitions. 2

## 4 . 2 . 2   g u i d a n c e

Incomplete sectoral coverage may compromise the emission reductions generated under the goal by excluding significant emissions sources and causing leakage, whereby activities (such as policies, actions, and projects) implemented to meet the goal cause an increase in emissions from sectors not included in the goal boundary. Users seeking to set a comprehensive goal and minimize the possibility for leakage should include all IPCC sectors within the goal boundary. For those users that do not include all sectors within the goal boundary, users should not exclude high emitting sectors in order to increase opportunities for GHG reductions.

Users should consider including international aviation and shipping emissions (a subcategory of 'other' under the IPCC sectors) in the goal boundary. To do so, users may account for emissions from both departing and arriving airplanes and ships, emissions from only departing or arriving airplanes and ships, or some other portion of these emissions.

## Sectoral goals

Instead of including all IPCC sectors within the goal boundary, users may choose to set a sectoral goal. Sectoral goals are mitigation goals that cover one sector and may be adopted as a way to focus mitigation efforts and resources on a high emitting sector.

Sectoral goals may cover in-  sector emissions as well as out-  of-  sector emissions-  emissions from sources outside the sectoral boundary that occur as a consequence of activities within the sectoral boundary. For example, a goal to reduce emissions in the cement sector might include emissions resulting from cement processes (in-  sector emissions) as well as emissions associated with purchased electricity that cement companies consume (out-  of-  sector emissions).

## Sector definitions

Users should use sector definitions that are consistent with the jurisdiction's GHG inventory. This approach ensures consistency between the GHG inventory and the mitigation goal.

In some instances, users may choose to deviate from IPCC sector definitions in order to target specific activities or use particular policy tools. While the IPCC is the most widely recognized reference for sectoral definitions for GHG inventories, other established bodies provide alternative sector definitions, including the International Standard Industrial Classification (ISIC) and the North American Industrial Classification Standard (NAICS). In all cases, users should define sectors in a way that avoids double counting of sources among different sectors.

## 4.2.3 decide on treatment of emissions and removals from the land sector

The land sector refers to the following land-  use categories: forestland, cropland, grassland, wetland, settlement, and other land, and includes emissions and removals from land in agricultural production and grazing lands/grasslands (IPCC 2006). These categories are collectively referred to as LULUCF in the 2003 IPCC Good Practice Guidance for Land Use and in the common reporting format used for reporting emissions to the UNFCCC, or simply as the land sector.

The land sector is treated separately from other sectors principally because of (1) the potential significance of natural-  disturbance-  related emissions and (2) the potential size and arbitrariness of legacy effects, in which earlier land management continues to influence emissions and removals during the goal period (see Section 6.1). 3 As a result, users may choose to adopt an accounting framework for the land sector that differs from national and subnational GHG inventory-  based accounting methods. The way the land sector is treated may have significant implications for the goal coverage, the emission reductions achieved by implementing the goal, and the user's ability to meet the goal. Users may treat emissions and removals from the land sector in one of four ways:

- · include in the goal boundary: The land sector is included in the goal boundary, like other sectors. Emissions and removals in the sector are accounted for in a manner consistent with the goal type. 4

- · sectoral goal: A sectoral goal for the land sector is separately designed and assessed, apart from any other mitigation goals a jurisdiction may have. Only emissions and removals in the land sector are included within the sectoral goal boundary.
- · offset: The land sector is not included in the goal boundary. Instead, net land sector emissions are added to emissions from sectors included in the goal boundary. 5 (The use of the term 'offset' here does not refer to using project-  level accounting methods to generate offset credits; instead it refers to applying the total change in net land sector emissions over the goal period to emissions in other sectors.)
- · do not account for the land sector: The land sector is not included in the goal boundary and no separate accounting occurs.

## 4 . 2 . 3   g u i d a n c e

The way land sector emissions and removals are incorporated into the goal may have a significant impact on the emission reductions generated under the goal. When choosing how to treat the land sector, users should consider:

- · The magnitude of emissions/removals from the land sector
- · Co-  benefits of land-  use management such as water regulation, flood and erosion control, timber and nonwood products, biodiversity protection, and food security
- · Policy objectives, circumstances, and capacities
- · Whether and how the goal creates incentives to mitigate emissions and enhance removals in the land sector
- · Consistency with the overall goal type

Subsequent chapters provide guidance on each approach but address the offset approach separately throughout using boxes, since the offset approach requires different accounting procedures than the other methods. Users shall report how emissions and removals from the land sector are treated in the goal.

- · Practical considerations of land-  use accounting, including data collection and data availability
- · Consistency with existing land sector accounting mechanisms in which the jurisdiction is participating

Table 4.2 outlines advantages and disadvantages of each approach.

<!-- image -->

table 4.2 advantages and disadvantages of ways to treat the land sector in a mitigation goal

| treatment of land sector      | advantages                                                                                                                                                                              | disadvantages                                                                                                                                                                                                                                                                                                                 |
|-------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| included in the goal boundary | • Consistent with other sectors covered by the goal • Provides a signal to reduce land sector emissions • May lead to a more efficient distribution of mitigation effort across sectors | • May require additional land sector data • Provides less flexibility to design a specialized goal for the land sector, unless special rules are applied                                                                                                                                                                      |
| sectoral goal                 | • Provides a signal to reduce land sector emissions • Enables users to design a specialized goal for the land sector • Special circumstances of the sector may be easier to explain.    | • May require additional land sector data • Having multiple goals (one for the land sector and one for other sectors) may be difficult to communicate to stakeholders • May reduce efficiency of mitigation across sectors                                                                                                    |
| offset                        | • Provides flexibility to treat the land sector differently from other sectors covered by the goal • Allows users to choose land sector accounting method                               | • May not provide a signal to reduce land sector emissions • Depending on accounting approach chosen, may account for emission reductions or enhanced removals that would have occurred in the absence of the goal, which would enable the goal to be met without additional effort • May require additional land sector data |
| not accounted for             | • Appropriate for users with insignificant land sector emissions or lack of capacity to account for the land sector                                                                     | • Does not provide a signal to reduce land sector emissions                                                                                                                                                                                                                                                                   |

Users should include the land sector in the goal boundary to maximize mitigation opportunities by ensuring that land sector emissions and removals are included in economywide mitigation strategies and to minimize the potential for leakage of emissions from covered sectors to the land sector (such as the use of biomass for energy production).

have occurred in the absence of the goal. While accounting techniques exist that can minimize such impacts, these users may instead choose to adopt a separate sectoral goal for the land sector. Chapter 6 provides detailed guidance on land sector accounting.

In some cases, however, including the land sector in the goal boundary may not be appropriate. For example, users with base year intensity goals based on a unit of economic output should consider removing the land sector from the goal boundary, accounting and reporting progress separately using a more appropriate metric, such as emissions per hectare of land. Furthermore, users should not include the land sector in the goal boundary if doing so would result in large quantities of non-  additional 6 emission reductions or enhanced removals that would

## 4.2.4 choose in-  jurisdiction and outof-  jurisdiction emissions

Activities within a jurisdiction's boundary can result in emissions from sources located inside and outside the jurisdiction itself. For example, emissions from purchased electricity generated outside a jurisdiction's boundary are the result of that jurisdiction's activities (for example, electricity use) but occur at sources located outside it. Categorizing emissions as in-  jurisdiction or out-  of-  jurisdiction helps users manage all emissions that result as a consequence of activities that occur within the jurisdiction's boundaries.

- · in-  jurisdiction emissions are emissions from sources located within a jurisdiction's boundary.
- · out-  of-  jurisdiction emissions are emissions from sources located outside of a jurisdiction's boundary that occur as a consequence of activities within that boundary.

Users should categorize emissions either as in-  jurisdiction and out-  of-  jurisdiction emissions or in a manner consistent with the jurisdiction's GHG inventory (for example, a scopes framework in the case of the GPC). 7

The IPCC Guidelines for National Greenhouse Gas Inventories provide guidance for estimating and reporting in-  jurisdiction emissions only, while subnational inventory methods such as the GPC provide guidance on both in-  jurisdiction and out-  of-  jurisdiction emissions.

Users in national jurisdictions that choose to set a goal for out-  of-  jurisdiction emissions shall define separate goals for in-  jurisdiction and out-  of-  jurisdiction emissions.

Users in subnational jurisdictions shall report whether the goal covers out-  of-  jurisdiction emissions and, if so, which out-  of-  jurisdiction emissions are included and excluded.

## 4 . 2 . 4   g u i d a n c e

Users in national jurisdictions seeking to maximize comprehensiveness and minimize leakage should include all in-  jurisdiction emissions in the goal boundary. They may also target out-  of-  jurisdiction emissions by setting a separate goal that covers relevant out-  of-  jurisdiction emission sources.

Users in subnational jurisdictions seeking to maximize comprehensiveness and minimize leakage should include all in-  jurisdiction emissions and also include all significant out-  of-  jurisdiction emissions in the goal boundary, especially if a large proportion of emissions occur outside of the jurisdiction's boundaries, if the subnational GHG inventory includes out-  of-  jurisdiction emissions, or if out-  ofjurisdiction emissions are relevant for subnational decision making. Subnational jurisdictions that choose to include out-  of-  jurisdiction emissions in the goal boundary may:

- · Define a single goal that includes both in-  jurisdiction and out-  of-  jurisdiction emissions (for example, reduce combined in-  jurisdiction and out-  of-  jurisdiction emissions by 40 percent relative to 2000 levels by 2020); or
- · Define separate goals for in-  jurisdiction and out-  ofjurisdiction emissions (for example, reduce in-  jurisdiction emissions by 30 percent and reduce out-  of-  jurisdiction emissions by 15 percent relative to 2000 levels by 2020).

Even if out-  of-  jurisdiction emissions are included in the goal, they may not lead to emission reductions across a larger boundary (for example, if the emissions covered are smaller than the electricity grid).

## Leakage

Leakage occurs if mitigation actions to reduce emissions within the goal boundary cause increases in emissions from uncovered sources, sectors, or gases outside the goal boundary. Leakage can be reduced by including all significant in-  jurisdiction and out-  of-  jurisdiction emissions (that occur as a consequence of the jurisdiction's activities) within the goal boundary. To identify and estimate sources of leakage associated with specific mitigation policies and actions, users should refer to the GHG Protocol Policy and Action Standard .

## Goal overlap resulting from inclusion of out-  of-  jurisdiction emissions

Since one jurisdiction's out-  of-  jurisdiction emissions are another jurisdiction's in-  jurisdiction emissions, it is possible that the goals of two jurisdictions will overlap and that the same emissions and emission reductions will be included in two different goal boundaries. For example, if Jurisdiction A's goal includes emissions from electricity purchased from Jurisdiction B, and Jurisdiction B's goal covers emissions from electricity generation, any emission reductions associated with that electricity will contribute to the goals of both jurisdictions. This is problematic because the atmosphere sees those emissions or emission reductions only once. Goal overlap may be most relevant for subnational jurisdictions. Transparent reporting can help highlight goal overlap.

Some users may seek to aggregate results of goals assessment across jurisdictions, for example, to show collective emission reductions achieved. Given the risk of goal overlap, only in-  jurisdiction emissions and emission reductions should be aggregated across jurisdictions. Double counting may result if out-  of-  jurisdiction emission reductions are aggregated across jurisdictions.

## 4.2.5 choose greenhouse gases

The last step in defining the goal boundary is to choose which greenhouse gases are included in the goal boundary. Users seeking to set a comprehensive goal should include the seven greenhouse gases covered under UNFCCC and Kyoto Protocol within the goal boundary: carbon dioxide (CO ), methane (CH ), nitrous oxide (N O), 2 4 2 hydrofluorocarbons (HFCs), perfluorocarbons (PFCs), sulfur hexafluoride (SF ), and nitrogen trifluoride (NF ). Users may 6 3 include fewer greenhouse gases depending on objectives, data quality, mitigation opportunities, and capacity to accurately measure and monitor each greenhouse gas. Users may also include other greenhouse gases, such as Montreal Protocol gases, within the goal boundary. 8

Users shall report which greenhouse gases are included in the goal boundary. If all seven Kyoto Protocol gases are not included in the goal boundary, users shall justify why certain gases are excluded. For example, some jurisdictions' inventories may not include all Kyoto Protocol gases.

## 4.3 Choose goal type

After defining the goal boundary the next step is to choose the goal type. Users may choose one of four goals:

- 1.  Base year emissions goal
- 2.  Fixed-level goal
- 3.  Base year intensity goal
- 4.  Baseline scenario goal

Table 4.3 illustrates the relationship between the goal types.

table 4.3 overview of mitigation goal types

|                              | reductions in what?         | reductions in what?      | reductions in what?      |
|------------------------------|-----------------------------|--------------------------|--------------------------|
|                              |                             | emissions                | emissions intensity      |
| reductions relative to what? | historical base year        | Base year emissions goal | Base year intensity goal |
| reductions relative to what? | projected baseline scenario | Baseline scenario goal   | Not fully addressed in   |
| reductions relative to what? | no reference level          | Fixed-level goal         | this standard. 9         |

A base year emissions goal is a goal that reduces, or limits the increase of, emissions by a specified quantity relative to emissions in a historical base year (see Figure 4.2). Base year emissions goals are sometimes referred to as 'absolute goals,' since they limit absolute emissions, rather than emissions intensity.

figure 4.2 example of a base year emissions goal

<!-- image -->

<!-- image -->

A fixed-level goal is a goal that reduces, or limits the increase of, emissions to an absolute emissions level in a target year (see Figure 4.3). Fixed-level goals include carbon neutrality goals, which are designed to reach zero net emissions by a certain date. Fixed-level goals are not expressed relative to either a historical base year or a projected baseline scenario.

figure 4.3 example of a fixed-level goal

<!-- image -->

A base year intensity goal is a goal that reduces emissions intensity (emissions per unit of another variable, typically GDP) by a specified quantity relative to a historical base year (see Figure 4.4). Emissions intensity refers to emissions per unit of another variable, which is typically economic output, such as GDP, but may also be population, energy use, or a different variable. The emissions level will be the nominator, and the unit of variable will be the denominator, in equations related to accounting for base year intensity goals. For example, users that wish to reduce emissions intensity of the economy would choose GDP as the unit of variable.

figure 4.4 example of a base year intensity goal

<!-- image -->

A baseline scenario goal is a goal that reduces emissions by a specified quantity relative to a projected emissions baseline scenario (see Figure 4.5). A baseline scenario is a reference case that represents the events or conditions most likely to occur in the absence of activities taken to meet a mitigation goal. These goals are sometimes referred to as business-  as-  usual (BAU) goals. 10

Baseline scenarios may be static or dynamic . A static baseline scenario is developed and fixed at the start of the goal period and not recalculated over time. A dynamic baseline scenario is developed at the start of the goal period and recalculated during the goal period based on changes in emissions drivers such as GDP or energy prices. Users with baseline scenario goals shall report whether the baseline scenario is static or dynamic. Users with dynamic baseline scenario goals shall develop and report a baseline scenario recalculation policy at the start of the goal period, including which exogenous drivers-  emissions drivers that are unaffected by mitigation policies or actions implemented to meet the goal-  will trigger a recalculation. Users should apply the recalculation policy in a consistent manner. (Section 8.4 provides guidance on recalculating dynamic baseline scenarios.)

figure 4.5 example of a baseline scenario goal

goal period

<!-- image -->

Users shall report the mitigation goal type. If a base year intensity goal is chosen, users shall report the unit of the variable in the denominator used to calculate the intensity.

## 4 . 3   g u i d a n c e

From a GHG accounting perspective, base year emissions goals and fixed-level goals are the simplest to account for, most certain, and most transparent, because allowable emissions in the target year(s) can be easily calculated at the beginning of the goal period, and progress can be tracked using the GHG inventory alone without the need for additional models, socioeconomic data, or assumptions.

To understand future emission levels associated with base year intensity goals, projections and assumptions are needed regarding the level of output in the target year, which may introduce uncertainty. From a transparency perspective, it may be difficult to determine whether a reduction in emissions intensity translates to an increase or decrease in absolute GHG emissions, and by how much, given that the level of output is not fixed and will vary.

Baseline scenario goals are the most challenging to assess. The development of baseline scenarios typically requires a large amount of data, advanced modeling techniques, specialized technical capacity, and assumptions about the likely development of various emissions drivers. In addition, projections of the future are inherently uncertain and can vary widely based on underlying methods, models, and assumptions. From a transparency perspective, it may be difficult to determine whether a reduction relative to a baseline scenario translates to an increase or a decrease in absolute emissions. It may also be difficult to determine whether baseline scenario emissions are overestimated, which would compromise the environmental integrity of the goal.

For these reasons, users seeking to accommodate shortterm emission increases should consider adopting base year emissions goals or fixed-level goals that are framed as a controlled increase in emissions from a base year (for example, limiting emissions in 2025 to 5% above 2010 emissions). Users that wish to adopt a goal that is independent of changes in output, such as GDP, should consider adopting a base year intensity goal rather than a baseline scenario goal, given the practical challenges involved in accounting for baseline scenario goals.

Users with more than one goal may choose multiple goal types, framing short-  term goals differently than long-  term goals. For example, the United Kingdom has adopted a

series of short-  term fixed-level goals to reach a longerterm base year emissions goal (described in Box 4.3). (If more than one goal type is adopted, users should assess and report progress toward each goal separately.)

## static versus dynamic baseline scenario goals

Most goal types can be translated and framed as a different type of goal. For example, one could convert a base year emissions goal to a fixed-level goal by framing the goal in terms of allowable emissions in the target year(s) as opposed to in reference to historical emissions. Similarly, static baseline scenario goals fix allowable emissions in the target year. Therefore, the goal could be reframed as either a base year emissions goal, a fixed-level goal, or a base year intensity goal. 11 Given the disadvantages of baseline scenario goals, as described above, users should consider reframing baseline scenario goals as another goal type, such as a base year emissions goal or fixed-level goal, even if the goal level limits the increase in emissions.

Figure 4.6 illustrates the difference between static and dynamic baseline scenario goals. In the figure, allowable emissions associated with the goal change depending on whether a static or dynamic baseline scenario is chosen. In this example, the dynamic baseline scenario is recalculated downward over the goal period, which lowers allowable emissions in the target year. Dynamic baseline scenarios can also be recalculated upward, which would have the opposite effect.

Both static and dynamic baseline scenario goals have advantages and disadvantages (see Table 4.4). Users that seek greater certainty and transparency regarding intended future emissions levels should choose static baseline scenario goals, since they represent a fixed point against which to calculate allowable emissions and assess progress. Static baseline scenario goals also introduce fewer practical challenges than do dynamic baseline scenario goals.

figure 4.6 example of static versus dynamic baseline scenarios

<!-- image -->

## table 4.4 advantages and disadvantages of static and dynamic baseline scenario goals

|                                | advantages                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | disadvantages                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|--------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| static baseline scenario goal  | • The emission level to be achieved by the target year is fixed, which offers decision makers more certainty and offers stakeholders more transparency about the target level of emissions to be achieved. • Allows users to calculate the allowable emissions in the target year (in Chapter 8). • Easier to implement, since recalculation is not necessary.                                                                                                                                                     | • Cannot easily isolate the level of effort associated with meeting the goal. For example, it combined changes in emissions caused by mitigation efforts with those resulting from changes in emissions drivers such as GDP or energy prices (assuming these drivers are not directly affected by mitigation policies). • May lead to less realistic baseline assumptions to increase the likelihood that the goal is met.                                                                                                                                                                                                                                                        |
| dynamic baseline scenario goal | • Can more easily isolate the level of effort associated with meeting a goal, since it is recalculated to account for changes in exogenous drivers. • Can accommodate unforeseen changes in exogenous factors through recalculation. • Higher certainty that the goal will be met if mitigation activities are implemented, since the goal baseline scenario is recalculated for changes in exogenous drivers More realistic and up-to-date estimate of baseline scenario emissions since it is updated over time. | • The intended emissions level in the target year is more uncertain, as it is subject to change, which creates more uncertainty for decision makers and less transparency for stakeholders. • Allowable emissions in the target year may change during the goal period because of recalculations of the baseline scenario. • More challenging to implement, given the need to recalculate emissions for changes in drivers, which can be resource intensive and very complex, and potentially require the recalculation of other goals based upon the baseline (for example, a sectoral goal based on an economy-wide goal) and reassessments of necessary mitigation strategies. |

<!-- image -->

## other goal types

While this standard is primarily intended for users with the four goal types in Table 4.3, users may adopt goals that are framed in other ways (see Box 4.2).

## Box 4.2 additional goal types

As noted in Table 4.3, this standard does not address base year intensity goals relative to a baseline scenario or fixed level emissions base year intensity goals because these goal types have not been widely adopted. However, users with these goal types may still use the standard. In addition, goals could be framed in several other ways, including:

## emission reductions to be achieved by policies, actions, or projects

As opposed to tracking progress based on the jurisdictional GHG inventory, a goal could be framed as a sum of the emission reductions to be achieved by a group of policies, actions, or projects. For example, a goal framed in this way might aim to reduce emissions by 10 Mt CO e by 2020 2 through the implementation of five policies. This standard is not intended to guide users in assessing and reporting progress toward this type of goal, although users may find parts of it useful for this purpose. Instead, users should assess progress by estimating the GHG reductions from the group of policies, actions, or projects using the GHG Protocol Policy and Action Standard (for policies and actions) or the GHG Protocol for Project Accounting (for individual projects).

Users with this goal type should exercise caution before aggregating emission reductions of policies, actions, or projects. Overlaps and interactions between them can lead to overestimating or underestimating total GHG reductions. See the Policy and Action Standard for more information.

## Baseline scenario goals framed in terms of emission reductions to be achieved by policies, actions, or projects

Some jurisdictions are establishing baseline scenario goals framed in terms of a quantity of emission reductions to be achieved by a group of policies, actions, or projects relative to total national or subnational baseline scenario emissions. For example, a goal framed in this way may aim to achieve a 20 percent reduction in emissions relative to baseline scenario emissions by 2020 through the implementation of five policies. This standard is not intended to guide users in assessing and reporting progress toward this type of goal, although users may find parts of it useful for this purpose. Instead, users should assess progress by estimating the GHG reductions from the group of policies, actions, or projects using the Policy and Action Standard (for policies and actions) or the GHG Protocol for Project Accounting (for individual projects) and then subtracting the sum of these reductions from baseline scenario emissions.

Users should exercise caution when designing and assessing this goal type, given the challenges of accurately aggregating emission reductions (detailed in the Policy and Action Standard ). At a minimum, consistency is needed between the jurisdictional baseline scenario and the individual baseline scenarios for each policy, action, or project being aggregated, especially regarding baseline assumptions and the coverage of emissions across the baseline scenarios.

## non-  ghg goals (including energy efficiency and renewable energy goals)

This standard is not directly applicable to goals framed in terms of energy efficiency, renewable energy, or other targets not expressed in terms of GHG emissions or emission reductions. However, much of the guidance in later chapters may still be relevant. Users may assess progress and achievement of non-  GHG goals by tracking the variable that the goal is framed around (such as energy efficiency or renewable energy generation) rather than GHG emissions.

To understand emission reductions associated with a nonGHG goal, users should use the Policy and Action Standard to estimate the GHG impact of the underlying policies or actions implemented to meet the goal.

<!-- image -->

## 4.4 Define goal time frame

Defining the goal time frame includes three steps:

For example, a city may choose to have the same base year as that of the state in which it is located.

- 1.  Choose the base year (for users with base year emissions goals and base year intensity goals)
- 2.  Choose whether to adopt a single-  year or multi-  year goal
- 3.  Choose the target year or target period

## 4.4.1 choose the base year (for users with base year emissions goals and base year intensity goals)

A base year is a specific year of historical emissions (or emissions intensity) data against which current emissions (or emissions intensity) are compared. Base years enable consistent tracking of emissions over time.

Users with base year emissions goals and base year intensity goals shall report the base year or base period.

## 4 . 4 .1   g u i d a n c e

Users may either choose a single year of historical data (base year) or an average of historical data over multiple years (base period). When deciding between a base year and a base period, users should consider:

- · Emissions data quality and availability
- · Year-  to-  year fluctuations of emissions
- · The objectives of the user: A base year or base period could be chosen in order to align with related goals.

Users should choose a base year or base period for which representative, reliable, and verifiable emissions data are available to enable comprehensive and consistent tracking of emissions over time. Users in jurisdictions where emissions fluctuate significantly from year to year should choose a base period in order to smooth out fluctuations and track progress against a more representative emissions level. Users should avoid picking a year or years with uncharacteristically high or low emissions. Users in subnational jurisdictions may choose to align the choice of base year with that of a national goal.

Users should choose a single base year or single base period for all sectors and gases included in the goal boundary. Users with separate goals for in-  jurisdiction and out-  of-  jurisdiction emissions should use the same base year or base period for both goals.

## 4.4.2 choose whether to adopt a single-  year or multi-  year goal

Single-  year goals aim to reduce emissions by a single target year, while multi-  year goals aim to reduce emissions over a defined target period. For example, a single-  year goal might aim to reduce emissions by 2025, whereas a multi-  year goal would aim to reduce emissions over the 5-  year period from 2021 to 2025. Multi-  year goals include emissions limits for a series of consecutive years. See Figures 4.7 and 4.8.

figure 4.7 example of a single-  year goal

<!-- image -->

Users shall report whether the goal is a single-  year goal or a multi-  year goal. Users with a multi-  year goal shall report whether the goal is an average, annual, or cumulative multi-  year goal.

## 4 . 4 . 2   g u i d a n c e

A growing number of scientific papers have shown that warming is closely related to the total cumulative amount of CO 2 emissions released over a time period, rather than the timing of those emissions (Allen et al. 2009; Matthews et al. 2009; Meinshausen et al. 2009; and Zickfeld et al. 2009). The IPCC Fifth Assessment Report (AR5) summarizes the scientific literature and estimates that cumulative carbon dioxide emissions related to human activities need to be limited to 1 trillion tonnes C (1,000 PgC) since the beginning of the industrial revolution in order to have a likely chance of limiting warming to 2°C (IPCC 2013).

Because single-  year targets are more vulnerable to interannual fluctuations, a significant risk associated with single-  year goals is that emissions can increase during the goal period and then be reduced only shortly before the target year, which would result in a larger amount of cumulative emissions than if emissions were capped year-  over-  year by a multi-  year goal (see Figure 4.9).

figure 4.8 example of a multi-  year goal

<!-- image -->

Therefore, adopting multi-  year goals will have a better chance of limiting cumulative emissions over the goal period. Multi-  year goals also facilitate understanding of anticipated emissions levels over multiple years, rather than only a single target year, which provides more clarity about the expected emissions pathway and reveals whether cumulative emissions are limited sufficiently to meet temperature targets. It is also likely that multiyear goals will lead to transformed emissions pathways in which emissions continue to be reduced after the goal period, as opposed to with single-  year goals, which may be met more easily without requiring necessary transformations in emissions-  intensive sectors.

In addition, considerable fluctuations in emissions can result from weather effects, economic effects, or other factors that can pose challenges to meeting a single-  year goal.

figure 4.9 example of high cumulative emissions associated with a single-  year goal

<!-- image -->

## Guidance for users with a multi-  year goal

If a multi-  year goal is selected, it may be defined as an average, annual, or cumulative multi-  year goal. An average multi-  year goal is a commitment to reduce, or control the increase of, annual emissions (or emissions intensity) by an average amount over a target period (see Figure 4.10).

An annual multi-  year goal is a commitment to reduce, or control the increase of, annual emissions (or emissions intensity) by a specific amount each year over a target period (see Figure 4.1 1). For example, an annual multi-  year goal might specify a reduction of 20 percent below base year emissions in 2020, 22 percent by 2021, 24 percent by 2022, and so on.

figure 4.10 example of an average multi-  year goal

<!-- image -->

figure 4.11 example of an annual multi-  year goal

<!-- image -->

A cumulative multi-  year goal is a commitment to reduce, or control the increase of, cumulative emissions over a target period to a fixed absolute quantity (see Figure 4.12).

figure 4.12 example of a cumulative multi-  year goal

<!-- image -->

target period

Cumulative multi-  year goals are often referred to as 'carbon budgets.' This type of multi-  year goal is framed as a fixedlevel goal because it is not defined in reference to a base year or baseline scenario. Annual or average multi-  year goals can also be converted to cumulative multi-  year goals once the emissions levels are calculated for each year in the target period by summing the emissions levels over the target period. Box 4.3 provides an example of a cumulative multi-  year goal in the United Kingdom.

Since average and cumulative multi-  year goals do not specify individual targets for each year in the target period, they offer users more flexibility in meeting mitigation goals and can better accommodate variability in emissions. Annual multi-  year goals are less flexible, but they allow users to know the expected annual emissions level for each year of the target period. This information can be a useful input into decision-  making and planning processes.

## 4.4.3 choose the target year or target period

A target year is for users with single-  year goals and represents the year by which the jurisdiction commits to achieving the goal. A target period is for users with multi- year goals and represents the period of consecutive years over which the jurisdiction commits to achieving the goal.

Users with single-  year goals shall report the target year. Users with multi-  year goals shall report the target period.

The goal period is typically the time between the base year and the target year or period. However, not all goal types have a base year, and, therefore, the definition of the goal period depends on which goal type is chosen.

- · Base year emissions goal: The goal period is the time between the base year (or first year of the base period) and the target year or last year of the target period.
- · fixed-level goal: The goal period is the time between the year in which the goal is adopted and the target year or last year of the target period.

<!-- image -->

## Box 4.3 the united kingdom's fixed level, cumulative multi-  year goals

The United Kingdom has adopted a series of fixed level, cumulative multi-  year goals. These goals, referred to as carbon budgets, are required under the U.K. Climate Change Act 2008 and have been developed in an effort to meet a long-  term goal of reducing emissions by at least 80 percent below 1990 levels by 2050. This long-  term goal was chosen based on the most recent climate science and was determined to constitute a fair contribution toward global emission reductions necessary to limit warming to 2°C above preindustrial levels (CCC 2008).

to average annual emissions of 556.4 Mt CO e). The third has 2 a target period of 2018-22, with allowable emissions in the target period of 2,544 Mt CO e (equivalent to average annual 2 emissions of 508.8 Mt CO e). The fourth and final goal period 2 runs from 2023 to 2027, with allowable emissions in the target period of 1,950 Mt CO e (equivalent to average annual 2 emissions of 390 Mt CO e). Figure 4.13 shows the allowable 2 cumulative emissions for each target period.

The first multi-  year goal has a target period of 2008-12, with allowable emissions in the target period of 3,018 Mt CO e 2 (equivalent to average annual emissions of 603.6 Mt CO e). 2 The second has a target period of 2013-17, with allowable emissions in the target period of 2,782 Mt CO e (equivalent 2

The United Kingdom has designed the series of goals so that it can gradually reduce emissions to meet its long-  term goal in 2050.   Coupled short-  term and long-  term goals can help ensure that a long-  term emission reduction pathway is realized. The use of multi-  year goals was preferred over singleyear goals since the former are designed to limit cumulative emissions over time and allow some year-  to-  year flexibility.

figure 4.13 allowable cumulative emissions for u.k. goals

<!-- image -->

- · Base year intensity goal: The goal period is the time between the base year (or first year of the base period) and the target year or last year of the target period.
- · Baseline scenario goal: The goal period is the time between the start year (or first year of the start period) of the baseline scenario and the target year or last year of the target period.

All users shall report the length of the goal period. Users with short-  term and long-  term goals shall separately report the length of the goal period for each goal and account for them separately.

## 4 . 4 . 3   g u i d a n c e

When choosing a target year or period, users may choose to set short-  term goals, long-  term goals, or a combination of both. Short-  term goals are achieved in the near term (typically a matter of years rather than decades), whereas long-  term goals typically have a goal period greater than 5 or 10 years.

The most robust approach is to set a combination of short- and long-  term goals consistent with an emissions trajectory that phases out greenhouse gas emissions in the long term, consistent with the most recent climate science (further described in Section 4.6). For example, a user may adopt a short-  term goal for the next 5 years   coupled with a long-  term goal for the next 40 years.   Coupled short- and long-  term goals provide clarity for long-  term planning and ensure a decreasing emissions pathway. They can also reveal cost-  effective and realistic emission reduction pathways that are aligned with phasing out net greenhouse gas emissions in the long term. See Box 4.3 for an example of   coupled goals adopted by the United Kingdom.

If   oupled short- and long-  term goals are not feasible, c then the choice of the goal period should be guided by considering which goal length will best facilitate longterm mitigation planning and investment. For example, a longer-  term goal may provide signals for capital investments spanning many decades and provide greater certainty for businesses and other stakeholders about the longer-  term policy and investment context if supporting policies are put in place.

Users that choose a single-  year goal should consider adopting a series of single-  year goals for different time frames. A series of single-  year goals is preferable to one single-  year goal, as it incorporates more interim goals and enhances understanding of the emissions pathway over time. For example, users should choose to adopt   coupled short- and long-  term single-  year goals that continuously reduce emissions over time, such as a 20 percent reduction from 1990 base year emissions by 2020, followed by a 30 percent reduction from 1990 base year emissions by 2025, followed by a 40 percent reduction from 1990 base year emissions by 2030. The design of oupled short- and long-  term goals should be informed c by a plausible pathway to phase out emissions in the long term (see Box 4.6). Each goal in the series of single-  year goals should be assessed separately.

Users that need to accommodate short-  term increases in emissions should consider adopting a 'peak-  anddecline' goal, which specifies a target year in which emissions peak and a subsequent target year in which emission decline relative to the target year. To facilitate accounting, users with a series of single-  year goals should specify the target year for each singleyear goal as well as the emissions levels in the peak year and long-  term target year. A 'peak-  plateau-  anddecline' goal can also be designed in which peak-  year emissions are held for several years before declining.

## 4.5 Decide on use of transferable emissions units

A goal may be achieved using any combination of emission reductions from within the goal boundary (domestic reductions) and transferable emissions units generated outside of the goal boundary. 12 Transferable emissions units are units (for example, from market mechanisms) that are used toward meeting a mitigation goal or are sold to other jurisdictions. Transferable emissions units can be generated outside of the jurisdiction implementing the goal or within the implementing jurisdiction.

There are two main types of transferable emissions units:

- · Emissions allowances from emissions trading programs
- · Offset credits generated from emission reduction (or removal enhancing) projects or programs outside of the goal boundary

See Figure 4.14 for an illustration of applying transferable emissions units toward meeting a goal. In the figure, emissions in the target year exceed allowable emissions. To achieve the goal, units are used to offset the difference between target year emissions and allowable emissions.

figure 4.14 use of transferable emissions units toward a goal

<!-- image -->

Deciding on the use of transferable emissions units involves:

- 1.  Deciding on the quantity of units
- 2.  Deciding on the types of units
- 3.  Deciding on the vintages of units
- 4.  Implementing mechanisms for tracking units and avoiding double counting
- · permanent : Emission reductions or removals are irreversible or, if sourced from projects subject to potential reversal (for example, carbon sequestration), have guarantees to ensure that any losses are compensated for, which may include replacement mechanisms such as legal guarantees, insurance, or buffer pools.

## 4.5.1 decide on types of units

To safeguard the environmental integrity of the mitigation goal, it is critical that transferable emissions units applied toward the goal be equivalent to emission reductions that would have been undertaken within the goal boundary. To demonstrate this equivalency, offset credits applied toward the goal shall meet the quality principles for offset credits and emissions allowances described below. It will also be critically important to consider any established eligibility criteria for participating in trading programs.

Offset credits applied toward goal achievement shall be: 13

- · real : Emission reductions or removals represent actual emission reductions and are not artifacts of inaccurate or incomplete accounting. 14
- · additional : Emission reductions or removals are beyond what would have happened in the absence of the incentive provided by the offset credit program or project.
- · transparent: Offset credits are publicly and transparently registered with unique serial numbers to clearly document offset credit generation, transfer, retirement, cancellation, and ownership. Crediting programs are transparent regarding rules and procedures for monitoring, reporting, and verification, quantifying GHG reductions, and enforcement.
- · verified : Offset credits are issued from emission reductions or removals that result from projects whose performance has been appropriately validated and verified to a standard that ensures reproducible results by an independent third party that is subject to a viable and trustworthy accreditation system.
- · owned unambiguously: Ownership of GHG reductions or removals is clear by contractual assignment and/or government recognition of ownership rights. Transfer of ownership of offset credits must be unambiguous and documented. Once the reductions or removals are sold, the seller and host government

must cede all rights to claim future credit for the same reduction in order to avoid double counting.

- · addresses leakage : Emission reductions or removals are generated in a manner that addresses leakage. The market (or other) mechanism that generates the transferable emissions units is designed and operated in a way that minimizes the risk of leakage and accounts for any unavoidable leakage.

Allowances applied toward goal achievement shall come from emissions trading systems with the following quality features:

- · rigorous monitoring and verification protocols : Allowances are generated based on robust methods for measuring emissions that ensure the quality and comparability of underlying emissions data.
- · transparent tracking and reporting of units : Allowances are publicly and transparently registered
- to clearly document their generation, transfer, and ownership. Emissions trading programs are transparent regarding rules and procedures for monitoring, reporting, and verification, as well as compliance and enforcement.
- · stringent caps : Emissions trading programs have stringent caps that limit the amount of emissions in a given time period to a level lower than would be expected in a business-  as-  usual scenario. Using allowances from emissions trading programs with overly high caps compromises the environmental integrity of the goal, since these allowances do not represent real reductions.

Users shall report the types of units that are eligible to be applied toward the goal.

Many types of units may be applied toward the goal. Table 4.5 provides selected examples.

## table 4.5 examples of unit types

| program                                         | unit                                               |
|-------------------------------------------------|----------------------------------------------------|
| emissions allowances                            |                                                    |
| california cap-and-trade program                | California Cap-and-Trade Program allowance         |
| european union emission trading system (eu ets) | European Union allowance (EUA)                     |
| kyoto protocol international emissions trading  | AAU (Assigned Amount unit)                         |
| new Zealand ets                                 | NZU (New Zealand units)                            |
| quebec cap and trade system                     | Quebec Cap and Trade System allowance              |
| regional greenhouse gas initiative (rggi)       | RGGI CO 2 allowance                                |
| offset credits                                  |                                                    |
| clean development mechanism (cdm)               | certified emission reduction (CER)                 |
| gold standard                                   | Gold Standard voluntary emission reductions (VERs) |
| Joint implementation (Ji)                       | emission reduction units (ERU)                     |
| verified carbon standard                        | verified emission reduction (VER)                  |

<!-- image -->

## 4.5.2 decide on quantity of units

Jurisdictions should rely primarily on action within the goal boundary, but they may also sell or purchase varying amounts of units from beyond the goal boundary. Users shall report:

- · Any limit on the quantity of transferable emissions units that may be applied toward the goal, if defined, and the anticipated amount of units to be used to meet the goal
- · The maximum and anticipated amount of units to be used from time periods before the goal ('banked' units)
- · Anticipated issuance of units that will be sold to another jurisdiction, if known
- · Anticipated net transfers of allowance units between emissions trading systems, if known

## 4 . 5 . 2   g u i d a n c e

Using transferable emissions units to achieve a mitigation goal has both advantages and disadvantages.

Using units enables access to a wider pool of emission reduction opportunities that may lead to an increased goal level and more cost-  effective mitigation efforts. It may also involve the private sector in mitigation, create flexibility, increase technology transfer, provide benefits for sustainable development, and build technical capacity in jurisdictions where emission reductions for offset credits are generated. At the same time, relying on transferable emissions units, especially from outside of the jurisdiction, to achieve mitigation goals may lead to fewer domestic mitigation policies and actions, given reduced action in the goal boundary necessary to meet the mitigation goal, which may limit co-  benefits of GHG mitigation that would otherwise accrue. To meet long-  term goals, it may be more cost-  effective to take early domestic mitigation action rather than rely on purchased units in later years, since prices can be volatile and lead to overall higher costs. In addition, if the units used toward the goal are low quality and do not represent additional emission reductions, their use would compromise the environmental integrity of the goal and may lead to net global emission increases.

For jurisdictions seeking to drive domestic action on climate change or ones uncertain of the quality of units, mitigation goals should be achieved primarily through emission reductions from within the goal boundary. Users that use units to achieve the goal should define a limit on the maximum quantity of transferable emissions units that may be applied toward the goal. See Box 4.4 for an example of limited use of transferable emissions units.

## Box 4.4   the united kingdom's limited use of transferable emissions units

The United Kingdom has adopted a series of fixed level, cumulative multi-  year goals under its Climate Change Act 2008. Under the act, the government must set a limit on the use of transferable emissions units. During the first goal period, no units may be used toward meeting the goal. This limit was set based on projections that U.K. emissions would fall below allowable emissions levels during the entire goal period. During the second goal period, the limit has been set to 55 Mt CO e (2 percent of carbon budget 2 emissions over the period). While government projections suggest that the goal can be achieved through domestic activities alone, and therefore that no purchase of units will be necessary, this limit is in line with the EU effort-  sharing agreement, in which the United Kingdom participates. The government must set the limits for use of transferable emissions units for the third and fourth goal periods 18 months before those periods begin. The government has said that with regard to the fourth goal period, it 'will make every possible effort to meet this [the budget] by domestic action, as far as practical and affordable' (United Kingdom 2011).

## 4.5.3 decide on vintages of units

The vintage of a unit refers to the year in which the unit is generated. For example, a unit that is generated in 2014 has a 2014 vintage. It is possible that purchasers of units collect vintages of offset credits from multiple years during the goal period and retire them only in the target year(s) in an effort to meet the target. While from an accounting perspective this is not problematic, as it is easy to account for such units in the evaluation of achievement of the goal, the user could engage in very minimal mitigation within its boundary by choosing instead to retire a large volume of units in the target year.

This is a particular risk with single-  year goals, as fewer units need to be retired in order to meet the goal (as emissions limits are only for one year). With multi-  year goals, the volume of units that would have to be retired would be so large that this risk may not be as large. For further explanation, see Lazarus, Kollmuss, and Schneider 2014; and Prag, Hood, and Martins Barata 2013.

Users should therefore apply only target year or target period vintage toward the goal to maximize mitigation in the target year(s) and maintain consistent accounting. Under this approach, users purchase units at the end of the goal period only if there is a shortfall between target year emissions and net land sector emissions and allowable emissions, which maximizes domestic mitigation during the goal period. If users apply non-target year or period vintages, they should use units with vintages that fall within a short period prior to the target year(s) during the goal period. Users shall report the vintages of units that are eligible to be applied toward the goal.

Users may use 'banked' units that were generated before the goal period. For example, if there is a series of goals and the first goal was not only achieved but exceeded, users may seek to apply those additional emissions units to the next goal. However, for ease of accounting and to maximize emission reductions in the goal period, users should avoid banking units.

## 4.5.4 implement mechanisms for tracking units and preventing double counting

Double counting of transferable emissions units occurs when the same transferable emissions unit is counted toward the mitigation goal of more than one jurisdiction. Double counting of units undermines the environmental integrity of mitigation goals by reducing the actual quantity of global emission reductions.

Double counting can occur in a variety of ways: 15

- · double claiming occurs when a single transferable emissions unit is claimed by two different jurisdictions and applied toward the mitigation goal of both.
- · In the case of purchased units : Buyer claims unit and applies it toward the buyer's goal. Double counting occurs if seller applies the same unit toward the seller's goal.
- · In the case of sold units: Seller sells unit and the buyer applies it toward the buyer's goal. Double counting occurs if the seller applies it toward the seller's goal.
- · In the case of shared units: Both buyer and seller claim a proportion of the unit and apply that proportion toward both goals. Double counting occurs if there is overlap in the proportion of the unit that the buyer and seller claim. For example, double counting will result if the buyer and seller claim 60 percent each.
- · double selling occurs when a single unit is sold twice.
- · double issuance occurs when more than one transferable emissions unit is generated for 1 unit of emission reduction.

To prevent double counting, users should implement one or more of the following mechanisms for tracking units between buyers and sellers: 16

- · A registry that lists the quantity, status (canceled, retired, or banked), ownership, location, and origin of transferable emissions units held by a jurisdiction
- · A transaction log that records the details of each transaction between registry accounts, including the issuance, holding, transfer, and acquisition of transferable emissions units
- · agreements between buyers and sellers that specify which party has the exclusive right to claim each unit and specifies what percentage, if any, is shared
- · legal mandates that disallow double counting and employ penalty and enforcement systems
- · information sharing to identify units that are already registered in other programs

Users shall report the mechanisms in place to prevent double counting.

## 4 . 5 . 4   g u i d a n c e

Mechanisms to prevent double counting may be implemented at the subnational, national, or international level, or through a combination of levels. Under any mechanism, units should be uniquely identified at two different points in time: at the point of issuance/generation and at the point of retirement, when the unit is applied toward the achievement of a mitigation goal. Robust mechanisms entail the creation of standardized protocols for issuing and serializing units and employ registries and a centralized transaction log, which checks, records, and verifies transactions.

Table 4.6 provides examples of existing mechanisms currently being used in different jurisdictions to track units and prevent double counting.

should be transparent about whether any unit being claimed is potentially or actually subject to dispute for breach of contract or disagreement between parties.

## 4.6 Define goal level

Defining the goal level is the final step in the goal design process. The goal level represents the quantity of emission reductions or emissions and removals within the goal boundary in the target year or period that the jurisdiction commits to achieving. While the level of emission reductions will be dictated in part by other decisions, such as the extent of the goal boundary, the goal level is the primary decision that determines the scale of emission reductions generated under the goal.

Depending on goal type, the goal level should represent:

Under some mechanisms, situations may arise where different parties to a contract believe they have legitimate claim to the same unit-  for example, if one jurisdiction claims a unit despite agreeing not to claim it or if a national government claims a unit even though a subnational government has not sold the rights. Users should avoid such disputes through a transaction log, a registry system that covers all admissible units from both jurisdictions, as well as arbitration, agreements, or other means. The system

- · Base year emissions goal: the percentage reduction or controlled increase in emissions to be achieved relative to base year emissions
- · fixed-level goal: the absolute quantity of emissions and removals to be achieved in the target year or period
- · Base year intensity goal: the percentage reduction or controlled increase in emissions intensity to be achieved relative to base year emissions intensity
- · Baseline scenario goal: the percentage reduction or controlled increase in emissions to be achieved relative to baseline scenario emissions

table 4.6 examples of mechanisms for tracking transferable emissions units

| regime                                          | name of mechanism                                                              |
|-------------------------------------------------|--------------------------------------------------------------------------------|
| california cap-and-trade program                | Compliance Instrument Tracking System Service (CITSS) American Carbon Registry |
| european union emission trading system (eu ets) | Community Independent Transaction Log (CITL)                                   |
| kyoto protocol                                  | International Transaction Log (ITL) CDM Registry                               |

Users shall report the chosen goal level. Users with separate goals for in-  jurisdiction and out-  of-  jurisdiction emissions (or for different scopes) shall separately report a goal level for in-  jurisdiction emissions and for out-  of-  jurisdiction emissions (or for different scopes). Users may also report separate goal levels for individual greenhouse gases or sectors. Users should report the goal level for the non-  land sectors, in addition to the goal level with the land sector included.

## 4 . 6   g u i d a n c e

Users should define an ambitious goal level that:

- · Substantially reduces emissions below the jurisdiction's business-  as-  usual emissions trajectory (taking into account currently implemented and adopted mitigation policies) 17

dangerous climate change impacts, as determined by the most recent climate science (see Box 4.5)

Users may also consider the feasibility of emission reductions based on an assessment of factors such as the mitigation potential in key sectors, co-  benefits to be achieved through mitigation, renewable energy potential, cost, national/ subnational circumstances, and policy objectives.

While users may choose a range of values for the goal level and indicate certain conditions that need to be met if the higher goal level is to be achieved, users should instead choose a single value for the goal level, rather than a range of values, since using a single value increases transparency regarding the level of emissions in the target year or period if the goal is achieved.

- · Corresponds to an emissions trajectory that is in line with the level of emission reductions necessary to avoid

See Box 4.5 for more information on the level of emission reductions needed to avoid dangerous climate change. Box 4.4 provides a case study of the United Kingdom's adopting a goal based on climate science.

## Box 4.5   level of emission reductions consistent with a likely chance of limiting warming to 2°c and avoiding dangerous climate change

The international community has adopted a goal for global warming not to rise above 2°C compared to preindustrial temperatures. According to the U.N. Environment Programme's Emissions Gap Report , for there to be a likely chance of meeting the 2°C target, global emissions in 2020 should be no more than 44 Gt CO e. Global emissions should 2 also peak by 2020 in order to stay on a least-  cost pathway that has a likely chance of limiting warming to 2°C. In 2025, global emissions should be no more than 40 Gt CO e on 2 average and drop to 35 Gt CO e by 2030. By 2050, global 2 emissions levels should fall to 22 Gt CO e in order to stay 2 within 2°C of warming. For context, global emissions in 2010 were roughly 50 Gt CO e.* 2

In the long term, the IPCC Fifth Assessment Report finds that, if we are to have a likely chance of limiting warming to 2°C, GHG emissions should be zero or below zero** by 2100, requiring a phase-  out of greenhouse gas emissions.

While there are numerous combinations for dividing the global goal level into national and subnational goal levels, jurisdictions can better align their goal with climate science by considering

- (a) the need for global emissions to peak by 2020 and

(b) the need to phase out GHG emissions in the long term.*** If a jurisdiction's emissions do not peak by 2020, any delay will necessitate steeper rates of emissions decline in later decades, which would be more costly, could require use of unproven technologies, and may not be feasible given the required rate for technological, behavioral, and political change. According to the IPCC Fifth Assessment Report, all regions peak by 2020 for a likely chance of limiting warming to 2°C.

- * On average among modeling runs.
- ** Negative emissions could be realized through carbon dioxide removal (CDR) technologies. The report notes significant risks associated with CDR, such as the availability of land for bioenergy with carbon capture and storage (BECCS), the difficulty of storing such significant amounts of carbon, and the lack of BECCS plants that have been built and tested at scale.
- *** his is for a likely chance of limiting warming to 2°C under T a least cost scenario. Following these broad principles will not provide a guarantee that necessary global emission reductions would be achieved. A global assessment should be conducted regularly to ensure that national emissions trajectories are consistent with the necessary global emission reductions.

Sources: IPCC 2014; UNFCCC 2010; and UNEP 2013.

<!-- image -->

## endnotes

- 1.  Given the uncertainties in the development of baseline scenarios, discussed in Chapter 5, significant reliance on baseline scenarios can lead to greater uncertainties regarding the ease of goal achievement.
- 2.  For example, see U.S. EPA 2013. It should also be noted that the IPCC sectoral definitions differ slightly between the 2006 Guidelines for National Greenhouse Gas Inventories and the 1996 Guidelines for National Greenhouse Gas Inventories .
- 3.  For further discussion of the special features associated with the land sector, see Estrada et al. 2014.
- 4.  Possibly with a provision for the treatment of natural disturbances and legacy effects.
- 5.  If the change in net land emissions is positive, this would lead to an increase in emissions.
- 6.  While non-  additionality is a problem for all sectors, it has the potential to affect land sector accounting significantly because of natural disturbances and legacy effects.
- 7.  If a scopes framework is being used, the user should ensure that no double counting of emissions occurs between scopes 1 and 2; that is, scope 2 emissions should only include out of jurisdiction emissions. See the GPC for more information on how to calculate net scope 2 emissions.
- 8.  Users may also separately design a goal that covers black carbon, as long as the results of the goal assessment are not aggregated with other GHGs included in the assessment.
- 9.  These goal types are not addressed fully in this standard because these goal types have not been widely adopted. However, users with these goal types may still use relevant parts of the standard.
- 0. In this standard, baseline scenario is used as a general term to 1 refer to any type of emissions projection. The term 'business-  asusual (BAU) scenario' is often used to refer to a type of baseline scenario that includes already implemented and adopted policies. Section 5.2.6 provides more information on including policies in the baseline scenario.
- 1.  Using projections for the unit of output from the baseline 1 scenario goal.
- 2. The term 'transferable emissions units' was first introduced in 1 Prag, Hood, and Martins Barata 2013.
- 3. Based on Offset Quality Initiative 2008; World Wildlife Fund 2008; 1 and The Climate Registry 2013, as well as the California Cap on Greenhouse Gas Emissions and Market-  Based Compliance Mechanism Final Regulation Order.
- 4. As Michael Gillenwater (2012) notes, the concept of 'real' 1 suggests that fraudulent behavior did not occur and embraces several principles, including accuracy and comprehensiveness.
- 5. Based on Prag 2012. 1
- 6. These are not mutually exclusive, and a user could employ a 1 combination or all of them.
- 7.  Insofar as the jurisdiction's business-  as-  usual emissions trajectory 1 is not in line with an emissions pathway that has a likely chance of limiting warming to 2°C.

5

<!-- image -->

Estimating Base Year or Baseline Scenario Emissions

T his chapter guides users in either calculating base year emissions (for users with base year emissions goals or base year intensity goals) in Section 5.1 or estimating baseline scenario emissions (for users with baseline scenario goals) in Section 5.2. Users with any goal type may also use Section 5.2 to develop an informational baseline scenario. The chapter is intended for users that have not  already  calculated  base  year  emissions  or  baseline  scenario  emissions.  The accounting and reporting requirements apply to all users except for users with fixed-level goals, which may skip this chapter since neither base year nor baseline scenario emissions are necessary for assessing progress.

## 5.1 Estimating base year emissions (for users with base year emissions goals or base year intensity goals)

figure 5.1 overview of steps for estimating base year emissions and emissions intensity calculate base year emissions (for users with base year emissions goals or intensity goals) (section 5.1.1)

calculate base year emissions intensity (for users with intensity goals) (section 5.1.2)

<!-- image -->

table 5.1   checklist of accounting requirements (for users with base year emissions goals or base year intensity goals)

| section                                                                                                          | accounting requirements                                                                                                                                                                                                                                                                                                                                                                                  |
|------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| calculate base year emissions (for users with base year emissions and base year intensity goals) (section 5.1.1) | • Calculate base year emissions by aggregating emissions from the GHG inventory for all gases and sectors that are included in the goal boundary, including out-of- jurisdiction emissions, if relevant. • For users that treat the land sector as an offset and accounting relative to base year/ period emissions: calculate net base year emissions in the land sector separately from other sectors. |
| calculate base year emissions intensity (for users with base year intensity goals) (section 5.1.2)               | • For users with base year intensity goals: calculate base year emissions intensity.                                                                                                                                                                                                                                                                                                                     |

Note: Reporting requirements are listed in Chapter 11.

## 5.1.1 calculate base year emissions

After choosing the base year or base period in Section 4.4.1, users shall report a complete inventory for the base year or base period, including out-  of-  jurisdiction emissions, if relevant. For information on developing a GHG inventory, see Section 4.1.

Users shall calculate base year emissions by aggregating emissions from the GHG inventory for all gases and sectors included in the goal boundary, including out-  ofjurisdiction emissions, if relevant. To calculate base period emissions, users should calculate the average annual emissions level over the base period. (Throughout the standard, the term 'base year emissions' refers to base year or base period emissions.)

For users that include the land sector in the goal boundary or treat it as a sectoral goal, base year emissions include land sector emissions and removals for all selected landuse categories, activities, and pools and fluxes. For users that treat the land sector as an offset, base year emissions do not include land sector emissions and removals. This quantity is calculated separately (see Box 5.1).

## Box 5.1 for users that treat the land sector as an offset: calculating base year emissions

In Section 4.2.3, users choose how to treat the land sector. For users that treat the land sector as an offset, whether to calculate net base year emissions for the land sector separately from other sectors depends on the choice of the land sector accounting method. Users will make this choice in Chapter 6. Users that account for the sector relative to a base year/period shall calculate net base year emissions for the land sector separately from other sectors. Base year or period emissions for the land sector are used as an input into calculating the change in net land sector emissions in Chapters 8 and 9. Based on the availability of historical data, users that treat the land sector as an offset also report net emissions shall report net base year emissions for the land sector, all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances. Users shall from each elected land-  use category or activity. Chapter 6 provides further guidance on land sector accounting.

Users shall report base year emissions separately by gas (in tonnes) and in tonnes of carbon dioxide equivalent (CO e), 2 as well as the sources of data and calculation methods used. Users that include land sector emissions and removals in base year emissions shall report land sector emissions and removals separately for each selected land-  use category, activity, pool, and flux, as well as calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances. Users with separate goals for in-  jurisdiction and out-  of-  jurisdiction emissions shall separately report base year emissions for in-  jurisdiction and out-  of-  jurisdiction emissions.

## 5 .1 .1   g u i d a n c e

Emissions and removals in the land sector can be highly variable.  Adopting a 5- to 10-  year base period for the land 1 sector helps minimize the effects of interannual variability on GHG accounting in the land sector. If a base period is chosen for the land sector and a base year is chosen for the other sectors covered under the goal, the base period should be formulated to span an equal number of years on either side of the base year.

## 5.1.2 calculate base year emissions intensity (for users with base year intensity goals)

In addition to base year emissions, users with base year intensity goals calculate base year emissions intensity. To do this, users should divide base year emissions by the level of output in the base year (see Equation 5.1). Data for the level of output should be reliable, verifiable, and gathered from official sources. Quality assurance and quality control (QA/QC) for output data should be carried out in a manner consistent with the GHG inventory. Users should report QA/QC procedures for output data, if undertaken.

Users with base year intensity goals shall calculate base year emissions intensity and shall report the level of output in the base year and data sources used. Users with separate base year intensity goals for in-  jurisdiction and out-  of-  jurisdiction emissions shall separately report base year emissions intensity for in-  jurisdiction and out-  ofjurisdiction emissions.

## equation 5.1 calculating base year emissions intensity

Base year emissions intensity =

Base year emissions (Mt CO e) 2

Level of output (or relevant variable) in the base year

## 5.2 Estimating baseline scenario emissions (for users with baseline scenario goals)

## figure 5.2 overview of steps for estimating baseline scenario emissions

<!-- image -->

Note: This sequence of steps is illustrative. Users may follow a different sequence.

## table 5.2 checklist of accounting requirements (for users with baseline scenario goals)

| section                                              | accounting requirements                                                                                                                                                                                                                                                    |
|------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| overview and key concepts (section 5.2.1)            | • Develop a goal baseline scenario that covers the same sectors, gases, and in-jurisdiction and out-of-jurisdiction emissions as the goal boundary.                                                                                                                        |
| choose time frame (section 5.2.4)                    | • Use a time frame for the baseline scenario that is at least as long as the goal period.                                                                                                                                                                                  |
| estimate baseline scenario emissions (section 5.2.7) | • Estimate goal baseline scenario emissions in the target year(s). • For users that treat the land sector as an offset and choose the forward-looking baseline accounting method: calculate baseline scenario emissions for the land sector separately from other sectors. |

Note: Reporting requirements are listed in Chapter 11.

## 5.2.1 overview and key concepts

A baseline scenario is a reference case that represents the future events or conditions most likely to occur in the absence of activities taken to meet the mitigation goal. They are sometimes referred to as business-  as-  usual scenarios. Baseline scenarios are plausible descriptions of a possible future state of the world given pre-  established assumptions and methodological choices. They are not statements or predictions about what will actually happen in the future. Given inherent and potentially high uncertainties, projections of baseline scenario emissions may change dramatically over time. See Box 5.2 for an example.

energy-  related CO  emissions as part of the 2 Annual Energy Outlook (AEO). Figure 5.3 shows AEO projections for each year between 2005 and 2014 against actual data through 2012 (see black line). The projected emissions levels change dramatically from one year's scenario to the next as a result of updated information about key drivers and updates to included policies.

Users with baseline scenario goals develop a goal baseline scenario to set the goal and assess progress. Goal baseline scenarios may be static or dynamic. Static goal baseline scenarios are not recalculated for changes in drivers over time, while dynamic baseline scenarios are recalculated based on changes in emissions drivers.

The U.S. Energy Information Administration (EIA) develops annual baseline scenarios (reference case scenarios) for U.S.

The goal baseline scenario is used to define allowable emissions in the target year or period and therefore

## Box 5.2 comparison of baseline scenario emissions over time

The U.S. Energy Information Administration (EIA) develops annual baseline scenarios (reference case scenarios) for U.S. energy-  related CO  emissions as part of the 2 Annual Energy Outlook (AEO). Figure 5.3 shows AEO projections for each year between 2005 and 2014 against actual data through 2013 (see black line). The projected emissions levels change dramatically from one year's scenario to the next as a result of updated information about key drivers and updates to included policies.

figure 5.3   u.s. eia annual energy outlook (aeo) reference case scenarios for energy-  related co  emissions 2 (2005-14)

<!-- image -->

has a significant impact on the emission reductions associated with achieving the goal. In order to help ensure environmental integrity, goal baseline scenarios should be developed in a relevant, complete, consistent, transparent, and accurate manner, and they should represent a conservative emissions projection when uncertainty is high. A conservative emissions projection is more likely to underestimate, rather than overestimate, baseline scenario emissions. In order to enable comprehensive and consistent tracking of progress toward the goal, goal baseline scenarios shall cover the same sectors, gases, and in-  jurisdiction and out-  of-  jurisdiction emissions as the goal boundary.

For users that include the land sector in the goal boundary or treat it as a sectoral goal, the goal baseline scenario includes land sector emissions and removals. For users that treat the land sector as an offset, the goal baseline scenario does not include land sector emissions and removals, since this quantity is calculated separately (further described in Section 5.2.7).

All users, regardless of whether they have a baseline scenario goal, may also develop informational baseline scenarios to understand mitigation efforts relative to various reference cases. Informational baselines are useful for carrying out mitigation assessments to inform goal design (described in Section 4.1.2), for assessing whether likely future emissions are consistent with achieving the goal (described in Section 8.8) and for meeting reporting requirements related to emissions projections (for example, under the UNFCCC).

The following sections provide an overview of steps and processes that users should follow when developing a baseline scenario. While they are relevant to developing informational baseline scenarios, only those users with baseline scenario goals are required to follow the accounting and reporting requirements. To develop a baseline scenario in practice, users may need to supplement this chapter with more detailed information related to emissions modeling.

## 5.2.2 consult stakeholders

When developing a baseline scenario, users should convene a stakeholder consultation and review process. Stakeholder consultations allow technical experts, government officials, and representatives from civil society and industry to provide input on the projection methodology, emissions drivers and associated assumptions, policies to be included in the baseline scenario, and data sources. 2

During the review, the baseline scenario and data inputs should be compared with other similar emissions projections at the subnational, national, or international level. At the national or subnational level, projected baseline scenario data can be compared with data from projections developed by other in-  country organizations, such as other government agencies, NGOs, research institutes, or private sector institutions. At the international level, projected energy and CO -  related data can be compared with data from 2 organizations such as the International Energy Agency (IEA) or the U.S. Energy Information Administration (EIA). Projected socioeconomic data in particular should be directly compared to projected data from other organizations. For example, projections of national GDP should be compared to national GDP projections from international organizations such as the International Monetary Fund (IMF) or World Bank.

## 5.2.3 choose emissions projection model

All emissions projections are modeled in some way. Models require input data and assumptions and provide users with estimated projections of future emissions. Models may be complex algorithms that develop baseline scenarios based on projections of economic activity, sectoral and economy-  wide activity data, and assumptions about future changes in emissions drivers. Less complex approaches may rely on extrapolations of historical emissions trends and/or key drivers such as gross domestic product (GDP) and overall emissions intensity. Users shall report the model used to develop the goal baseline scenario.

## 5 . 2 . 3   g u i d a n c e

The choice of model typically reflects a tradeoff among several factors, including available resources, including financial resources and technical expertise; data availability; model performance, including level of sophistication and suitability for jurisdiction; software costs; alignment with other models being used by the jurisdiction; and the expected use of the model outputs. Outlining the advantages and disadvantages of each model is beyond the scope of this standard. However, technical information and case studies on model selection exist that users may consult. 3

There are two major distinctions among models. The first is whether the modelling approach is top-  down, bottom-  up, or a hybrid. The second is whether the model is jurisdictionspecific or generic.

## Top-  down, bottom-  up, and hybrid approaches

A key difference among modeling approaches is how they treat technology, emissions, energy, and the economy. Three major categories of models exist: top-  down, bottom-  up, and hybrid. 4

- · top-  down models focus on projecting overall economic output and the emissions intensity of that output based on forecasts of simulated economic interactions between sectors, taking into account their effect on GDP, consumption, and investment. Top-  down models mainly focus on energy supply sectors and their interaction with economic sectors. They model technology through the degree of substitutability of production inputs and the shares that these represent of the purchase of intermediate inputs. Top-  down models include simple extrapolations of historical trends as well as complex computable general equilibrium (CGE) models such as ENV-  Linkages and SGM.
- · Bottom-  up models use highly disaggregated data on specific technologies to produce detailed projections of energy use by type and sector, based on assumptions about structural and/or policy developments in each sector (accounting models) and/or optimal behavior for economic agents (optimization models). Bottomup models typically do not capture the economic linkages across sectors and represent the energy sector from an engineering perspective, focusing on end use technologies. Modeling considers specific technical performances and costs. Examples of bottom-  up models include LEAP, MAED, MARKAL, MEDEE, and POLES.
- · hybrid models attempt to combine the advantages of both approaches. Examples of hybrid models include MARKAL-  MACRO, NEMS, and WEM.

Developing baseline scenarios using a hybrid approach, which combines bottom-  up sectoral modeling (for example, for energy-  related emissions) with top-  down economic modeling can best enable users to capture technological and sectoral detail as well as macroeconomic linkages across sectors.

## Jurisdiction-  specific versus generic models

Models can be jurisdiction-  specific or generic. Jurisdictionspecific models are purpose-  made models developed by individual jurisdictions and designed to reflect their particular circumstances. Examples of jurisdiction-  specific models include the U.S. National Energy Modeling System (NEMS) model, Canada's Energy-  EconomyEnvironment Model for Canada (E3MC) model, and the United Kingdom's Dynamic Dispatch Model (DDM). Because jurisdiction-  specific models are tailored to fit a jurisdiction's circumstances, they will typically be better able to capture the complexities of its economic and energy systems and therefore should be used, if available.

Generic models are not designed to fit the specifications of any one jurisdiction but instead developed to fit the needs of multiple users. Examples of generic models include the Long-  Range Energy Alternatives Planning System (LEAP) and the Market Allocation (MARKAL) model. Generic models may also be customized by users to fit their specific needs. For users with limited capacity, generic models can provide a more convenient solution than jurisdiction-  specific models for common sectors like electricity generation, cement, and iron and steel. 5 However, for uncommon or diverse sectors, a jurisdiction-  specific or customized generic model may be necessary, since generic models are not typically available for these types of sectors.

If neither a jurisdiction-  specific model nor a generic model is available, users may choose an existing baseline scenario developed for their jurisdiction by a third party as their goal baseline scenario. Examples include emissions projections developed by the International Energy Agency (IEA) and the U.S. Energy Information Administration (EIA). Thirdparty baseline scenarios used as a goal baseline scenario should cover the same sectors and gases as the goal.

## 5.2.4 choose time frame and start year

The time frame for the baseline scenario refers to the period over which emissions are projected. Users with baseline scenario goals shall use a time frame for the baseline scenario that is at least as long as the goal period. For baseline scenario goals, the goal period is the time between the start year (or start period) of the baseline scenario and the target year (for single-  year goals) or last year of the target period (for multi-  year goals). For planning

purposes, users may project emissions into the future beyond the goal period.

Baseline scenarios require a start year or start period as the basis for emissions projections. The choice of start year or period depends on the availability of recent, representative, reliable, and verifiable data. Users that choose a start year should choose the most recent year when historical emissions are not uncharacteristically high or low. A start year with uncharacteristically high emissions may result in a baseline scenario that overestimates emissions. If annual emissions fluctuate highly and multiple years of data are available, users should choose a start period that represents an average of recent historical emissions over those multiple years. This approach provides a more representative and reliable starting point for the projection by smoothing year-  to-  year fluctuations in emissions. Historical emissions data for the start year or period should be collected from the jurisdiction's GHG inventory. See Figure 5.4 for an illustration of a baseline scenario time frame and start period.

figure 5.4 Baseline scenario time frame and start period

<!-- image -->

Users shall report the time frame for the goal baseline scenario and the start year or start period. Users shall report emissions within the goal boundary in the start year or start period, the complete GHG inventory for the start year or period, and the data sources and calculation methods used. Users with separate goals for in-  jurisdiction and out-  of-  jurisdiction emissions shall separately report start year or start period emissions for in-  jurisdiction and out-  of-  jurisdiction emissions.

## 5.2.5 identify emissions drivers and define assumptions

Baseline scenarios are based on assumptions about future changes in emissions drivers. Emissions drivers are socioeconomic and technological parameters that cause emissions to increase or decline. Examples of emissions drivers include:

- · Economic activity (for example, GDP and sectoral composition of GDP)
- · Structural changes in economic sectors (shifts from manufacturing to ser  vice sector jobs, shifts of industrial production between countries, etc.)
- · Energy prices by fuel type
- · Energy supply and demand by fuel type
- · Emissions intensity by fuel type
- · Population and degree of urbanization
- · Technological development
- · Land-  use practices
- · Weather (for example, heating degree days and cooling degree days)

Users should identify key emissions drivers-  emissions drivers that significantly affect baseline scenario emissionsfor each sector and gas included in the goal boundary based on the input requirements of the chosen model. Users shall report which key emissions drivers are included in the goal baseline scenario.

Once emissions drivers have been identified, the next step is to define assumptions about how each driver is most likely to change during the baseline scenario time frame. Users shall report assumptions for key emissions drivers included in the goal baseline scenario. At the end of the goal period, users should report projected trends in emissions drivers (developed at the start of the goal period) alongside

the actual trend in those same drivers (compiled at the end of the goal period).

Users shall report all sources of data used to develop the goal baseline scenario, including data for key drivers (projected and historical), emission factors, and assumptions. User shall justify the choice of whether to develop new baseline data and assumptions or to use published baseline data and assumptions.

See Box 5.3 for one set of examples of drivers and assumptions.

## Box 5.3 examples of drivers and assumptions for u.s. Annual Energy Outlook 2014 reference case scenario

The U.S. Energy Information Administration develops emissions projections for the U.S. energy sector as part of the Annual Energy Outlook using the National Energy Modeling System, a U.S.-  specific hybrid model. Below are assumptions for three drivers (GDP growth, oil prices, and energy consumption) for the 2014 Reference Case Scenario.

table 5.6 average annual percentage gdp growth rate assumptions

|   2012-15 |   2012-25 |   2025-40 |   2012-40 |
|-----------|-----------|-----------|-----------|
|       2.6 |       2.5 |       2.4 |       2.4 |

## table 5.7 oil price assumptions for west texas intermediate (wti) and Brent crude (2012 dollars per barrel)

| sector   | sector   | 2020   | 2020   | 2025   | 2025   | 2030   | 2030   | 2035   | 2035   | 2040   | 2040   |
|----------|----------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| wti      | Brent    | wti    | Brent  | wti    | Brent  | wti    | Brent  | wti    | Brent  | wti    | Brent  |
| 94.57    | 96.57    | 106.99 | 108.99 | 116.99 | 118.99 | 127.77 | 129.77 | 139.46 | 141.46 | 139.46 | 141.46 |

table 5.8 projected energy consumption for select sectors (quadrillion Btu per year)

| sector                                          | 2020                                            | 2025                                            | 2030                                            | 2035                                            | 2040                                            |
|-------------------------------------------------|-------------------------------------------------|-------------------------------------------------|-------------------------------------------------|-------------------------------------------------|-------------------------------------------------|
| residential                                     | 20.38                                           | 20.58                                           | 20.83                                           | 21.09                                           | 21.48                                           |
| commercial                                      | 18.12                                           | 18.77                                           | 19.32                                           | 19.99                                           | 20.88                                           |
| industrial                                      | 25.76                                           | 37.43                                           | 37.94                                           | 38.00                                           | 38.33                                           |
| transportation                                  | 26.47                                           | 25.67                                           | 25.17                                           | 25.20                                           | 25.62                                           |
| Notes: For more information, see U.S. EIA 2014. | Notes: For more information, see U.S. EIA 2014. | Notes: For more information, see U.S. EIA 2014. | Notes: For more information, see U.S. EIA 2014. | Notes: For more information, see U.S. EIA 2014. | Notes: For more information, see U.S. EIA 2014. |

## 5 . 2 . 5   g u i d a n c e

When defining assumptions, users may either (1) use assumptions from published data sources or (2) develop new baseline values.

## Option 1: Use assumptions from published data sources

In some cases, existing data sources of sufficient quality may be available to define assumptions for emissions drivers. Potential data sources of historical or projected data include peer-  reviewed scientific literature, government statistics, reports published by international institutions (such as the IEA, IPCC, IMF, World Bank, UN, etc.), national, regional, state, city, or sector-  level sources specific to the jurisdiction, and economic and engineering analyses and models.

Table 5.9 provides examples of existing data sources for emissions drivers, not all of which will be relevant to every model.

Users should use high-  quality, up-  to-  date, and peer-  reviewed data from recognized and credible sources, if available. When selecting data sources, users should apply the data quality indicators in Table 5.10 as a guide to obtaining the highest quality data available. Users should select data that is the most representative in terms of technology, time, and geography; most complete; and most reliable. Assumptions used should represent how each driver is most likely to change, which may differ from national targets for those drivers. For example, an aspirational government target for economic growth may differ from more realistic growth projections. In this case, the latter should be used.

table 5.9 examples of emissions driver data types and sources

| sector                                 | 2020                                                                                                                                                                    | 2025                                                                                                                                    |
|----------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| macroeconomic variables                | macroeconomic variables                                                                                                                                                 | macroeconomic variables                                                                                                                 |
| macroeconomic drivers                  | GDP, population, household size                                                                                                                                         | National statistics and plans, World Bank, IMF, UN population data                                                                      |
| sectoral drivers                       | Physical production for energy intensive materials; transportation requirements (km/year), agricultural production and irrigated area, commercial floor space           | Macroeconomic studies, national sectoral studies, household surveys, UN FAO Stat database                                               |
| energy demand                          | energy demand                                                                                                                                                           | energy demand                                                                                                                           |
| sector and subsector energy demand     | Fuel use by sector/subsector                                                                                                                                            | National energy statistics, national energy balance, energy sector yearbooks (oil, electricity, or coal), IEA statistics                |
| end-use and technology characteristics | Energy consumption by end use and device, such as new vs. existing building stock or vehicle stock; breakdown by type, vintage, and efficiencies; or simpler breakdowns | Local energy studies and audits, studies in similar countries, general rules of thumb from end-use literature                           |
| response to price and income changes   | Price and income elasticities                                                                                                                                           | Econometric analyses of time-series or cross-sectional data                                                                             |
| energy supply                          | energy supply                                                                                                                                                           | energy supply                                                                                                                           |
| technical characteristics              | Capital and operations and maintenance (O&M) costs, performance, efficiencies, capacity factors                                                                         | Local data, project engineering estimates, EPRI Technical Assessment Guide                                                              |
| energy prices                          | Price of oil, coal, and natural gas                                                                                                                                     | Local utility or government projections, IEA World Energy Outlook , IEA Energy Prices and Taxes Statistics , and fuel price projections |

## table 5.9 examples of emissions driver data types and sources (continued)

| sector                           | 2020                                                                                                                            | 2025                                                                                                                                      |
|----------------------------------|---------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|
| energy supply (continued)        | energy supply (continued)                                                                                                       | energy supply (continued)                                                                                                                 |
| energy supply plans              | New capacity online dates, costs, characteristics                                                                               | National or electric utility plans and projections, other energy sector industries                                                        |
| energy resources                 | Estimated recoverable reserves of fossil fuels, estimated costs and potential for renewable resources                           | Local energy studies, World Energy Council Survey of Energy Resources , IRENA                                                             |
| technology options               | technology options                                                                                                              | technology options                                                                                                                        |
| costs and performance            | Capital and O&M costs, performance, efficiencies, unit intensities, capacity factors                                            | Local energy studies and project engineering estimates; technology suppliers; other mitigation studies                                    |
| penetration rate of technology   | Percentage of new or existing stock replaced per year, overall limits to achievable potential                                   | Extrapolation of trends and expert judgment, optimizing or simulation models                                                              |
| administrative and program costs | For efficiency investment, often expressed in cost per unit of energy saved                                                     | Local and international studies                                                                                                           |
| emission factors                 | emission factors                                                                                                                | emission factors                                                                                                                          |
| emission factors                 | Kg GHG emitted per unit of energy consumed, produced, or transported; Kg GHG emitted/ removed per land-use activity or category | National inventories; IPCC Emission Factor Database (EFDB), CORINAIR, CO2DB, GEMIS, AIR CHIEF, IPCC Technology Characterization Inventory |

Source: Adapted from UNFCCC 2013b.

## table 5.10 data quality indicators

| indicator                        | description                                                                                                                                                                                                                                                                                                           |
|----------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| technological representativeness | The degree to which the data set reflects the relevant technology (or technologies).                                                                                                                                                                                                                                  |
| temporal representativeness      | The degree to which the data set reflects the relevant time period.                                                                                                                                                                                                                                                   |
| geographical representativeness  | The degree to which the data set reflects the relevant geographic location (such as the country, city, or site).                                                                                                                                                                                                      |
| completeness                     | The degree to which the data is statistically representative of the relevant activity. Completeness includes the percentage of locations for which data is available and used out of the total number that relate to a specific activity. Completeness also addresses seasonal and other normal fluctuations in data. |
| reliability                      | The degree to which the sources, data collection methods, and verification procedures used to obtain the data are dependable. Data should represent the most likely value of the parameter over the GHG assessment period.                                                                                            |

Source: Adapted from Weidema and Wesnaes 1996.

<!-- image -->

## Option 2: Developing new baseline assumptions

In some cases, no published baseline assumptions will be available for drivers, or the existing data may be incomplete, of poor quality, or in need of supplementation or further disaggregation. Users should develop new baseline data and assumptions when no relevant data is available that supports the level of accuracy needed to meet the stated objectives.

To develop new assumptions for each driver, users should collect historical data for the driver and then estimate assumptions for each driver that describe how it is most likely to change over the baseline scenario time frame. Assumptions should represent the most likely scenario for each driver, based on evidence, such as peer-  reviewed literature, government statistics, or consultations with experts and stakeholders. If a variety of assumptions are available from reliable sources or assumptions are highly uncertain, users should use conservative assumptions more likely to underestimate GHG emissions in the baseline scenario.

Various methods may be used to develop assumptions, such as regression analysis, simple extrapolation, or various equations, algorithms, or models. Models that allow for conditions to change throughout the baseline scenario time frame are typically the most accurate and should be used where relevant and feasible. A linear extrapolation of historical trends may be used if there are justifiable reasons to assume that historical trends would continue in the baseline scenario.

## 5.2.6 identify policies and actions to include

A jurisdiction's future emissions under a baseline scenario will be affected by existing policies and actions implemented in the jurisdiction, including policies and actions designed to reduce emissions as well as those designed to meet other objectives. Policies and actions are interventions taken or mandated by a government and may include laws, regulations, and standards; taxes, charges, subsidies, and incentives; information instruments; voluntary agreements; implementation of new technologies, processes, or practices; and public or private sector financing and investment, among others. Which policies are included in the baseline scenario and the assumptions made about their likely effects on emissions can have a significant effect on resulting baseline scenario emissions.

Users shall report:

- · The cutoff year for the inclusion of policies-  that is, the year after which no new policies or actions are included in the baseline scenario
- · Key policies and actions included in the baseline scenario
- · Any additional methods and assumptions used to estimate the effects of key included policies and actions on emissions
- · Any significant policies excluded from the baseline scenario, with justification

## 5 . 2 . 6   g u i d a n c e

To reflect the most likely future emissions pathway under a baseline scenario, users should include all policies and actions that (1) have a significant effect on GHG emissions, either increasing or decreasing them, and (2) are implemented or adopted in the year the baseline scenario is developed. Table 5.1 1 provides definitions for implemented, adopted, and planned policies and actions.

## table 5.11 definitions of implemented, adopted, and planned policies and actions

| policy or action status   | definition                                                                                                                                                                                                                                                                                                                             |
|---------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| implemented               | Policies and actions that are currently in effect, as evidenced by one or more of the following conditions: (a) relevant legislation or regulation is in force; (b) one or more voluntary agreements have been established and are in force; (c) financial resources have been allocated; and (d) human resources have been mobilized. |
| adopted                   | Policies and actions for which an official government decision has been made and a clear commitment expressed to proceed with implementation, but that have not yet begun to be implemented (for example, a law has been passed but regulations to implement the law have not yet been established or are not being enforced).         |
| planned                   | Policy/action options that have not been adopted but that are under discussion and have a realistic chance of being adopted and implemented in the future.                                                                                                                                                                             |

Source: UNFCCC 2000.

For policies or actions that are included, users should determine whether they are designed to operate indefinitely or are limited in duration. Users should assume that policies or actions will operate indefinitely unless an end date is explicitly stated.

- (2) discount the maximum effects based on expected limitations in policy implementation, enforcement, or effectiveness that would prevent the policy or action from achieving its maximum potential. 6

Users should only include adopted policies in the baseline scenario if there is reason to believe that the adopted policy will be implemented and if there is enough information to model the impacts of the policy. Furthermore, users should consider the expected degree of policy implementation. Depending on the context, users should either (1) estimate the maximum effects of the policy or action if full implementation and enforcement is most likely or

Users may optionally include planned policies and actions in the baseline scenario, as long as planned policies are distinguished from implemented or adopted policies. For informational purposes, users may develop additional scenarios to understand various plausible emissions trajectories.

Box 5.4 provides a case study of how Chile chose to include policies and actions in its national voluntary baseline scenario goal.

<!-- image -->

## Box 5.4 inclusion of policies and actions in chile's national baseline scenario goal

The Climate Change Office of the Ministry of Environment in Chile applied the draft mitigation goal standard to carry out an exante assessment of Chile's national voluntary goal using information gathered through MAPS Chile, a participatory initiative that facilitated the development of the country's baseline.*

Chile adopted a voluntary baseline scenario goal to reduce emissions 20 percent below the business-  as-  usual emissions growth trajectory by 2020, as projected from year 2007. The baseline scenario was developed through the MAPS Chile initiative. As part of this process, a decision had to be made regarding which policies and actions to include in the baseline scenario. Based on the MAPS Chile consulting process and input from the research team, the government decided to include in the BAU projection all plans, actions, and measures that had an effect on GHG emissions and had been implemented by December 2006. The year 2006 was chosen as the cutoff year for inclusion of policies and actions because it was the last year for which an official national GHG inventory was developed. As a result of the cutoff year, Chile's Renewable Energy Law, which was approved after 2007, was not included in the baseline scenario, and the emission reductions from the policy therefore contribute toward Chile's achievement of the goal. Table 5.12 outlines the policies and actions included in the baseline scenario from each sector.

table 5.12 policies and actions included in chile's national baseline emissions scenario (by sector)

| sector                                        | policies and actions included                                                                                                                                                               |
|-----------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| power generation and electricity transmission | • Current regulations associated with Short Law I and Short Law II of the sector. These laws require the private sector to cover a percentage of power generation through renewable energy. |
| mining and other industries                   | • Compliance measures in the 'Decontamination Plans' for different cities and resolutions related to air pollution, water, and soil.                                                        |
| transportation                                | • None included.                                                                                                                                                                            |
| agriculture and land-use change               | • None included.                                                                                                                                                                            |
| forestry and land-use change                  | • Regulations associated with the DL 701 of the Ministry of Agriculture until 2012. This law regulates deforestation and encourages afforestation.                                          |
| commercial, public, and residential           | • Program Regulators Thermal Conditioning. • The Country Energy Efficiency Program to label bulbs and refrigerators.                                                                        |
| waste                                         | • None included.                                                                                                                                                                            |
| * For more information, see MAPS 2014b.       | * For more information, see MAPS 2014b.                                                                                                                                                     |

Users should consider potential interactions and overlaps between policies and actions included in the baseline scenario and avoid any potential double counting. For guidance on estimating the GHG effects of policies and actions, including identifying overlaps and avoiding double counting, refer to the GHG Protocol Policy and Action Standard .

In addition to policies and actions, users may include transferable emissions units in the baseline scenario that are expected to be sold or retired in the target year or period. Users should account for the use of units either ex ante in the baseline scenario or ex post when they assess goal achievement in the target year. Double counting will result if units are accounted for in the baseline scenario and in the target year. Given the risk of double counting, users should account for the actual use of units ex post when assessing goal achievement. If the baseline scenario does include the expected use of units, only the difference between expected use and actual use in the target year or period should be accounted for.

## 5.2.7 estimate baseline scenario emissions

Users with baseline scenario goals shall estimate and report goal baseline scenario emissions in the target year(s). To do so, users should apply the chosen projection model for the defined baseline scenario time frame, taking into account the identified emissions drivers, assumptions, and policies.

Users including the land sector in the goal boundary or as a sectoral goal shall report net baseline scenario emissions for the sector in the target year or period. Users that develop baseline scenarios for the land sector should use the guidance below, in addition to the guidance in this chapter. For users that treat the land sector as an offset, baseline scenario emissions do not include land sector emissions and removals. This quantity is calculated separately (see Box 5.5).

Users with separate goals for in-  jurisdiction and out-  ofjurisdiction emissions shall separately report baseline scenario emissions for in-  jurisdiction and out-  of-  jurisdiction emissions. Users should report informational baseline scenario emissions, if developed.

## Box 5.5   for users that treat the land sector as an offset: estimating baseline scenario emissions

For users that treat the land sector as an offset, whether to develop a separate baseline scenario for the sector depends on the choice of land sector accounting method. Users will make this choice in Chapter 6. Users that choose the forward-  looking baseline method shall calculate baseline scenario emissions for the land sector separately from other sectors, following the accounting and reporting requirements in this chapter. Baseline scenario emissions in the land sector will be used as an input into calculating the change in net land sector emissions, which will establish a quantity of net emissions that is used to offset emissions from other sectors (see Chapters 8 and 9). Users that treat the land sector as an offset and apply a forward-  looking baseline accounting method for the land sector shall report net baseline scenario land sector emissions in the target year(s) and all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances.

## 5 . 2 . 7   g u i d a n c e

To develop a baseline scenario for the land sector, users should use the guidance provided in this chapter and in addition apply the following guidance specific to the land sector:

- · Because of the high uncertainty inherent in projecting net land sector emissions and the potential for nonadditional land sector emission reductions, users should consider using conservative methods and values when developing a land-  use baseline scenario to maximize environmental integrity.
- · Extrapolation-  based economic forecasts (a type of topdown model) or optimization models (a type of bottomup model) are not recommended for the land sector. Users should instead use an accounting model or a hybrid accounting/computable general equilibrium model.
- · Few generic models or existing projections are available to estimate future emissions and removals for the land sector. Because of the wide range of circumstances present in the land sector, users should use jurisdictionspecific models for estimating baseline scenario emissions or removals from the land sector.

- · Users should determine which disturbance-  related emissions and removals are non-  anthropogenic and therefore eligible to be excluded from the baseline scenario and subsequent accounting of emission and removals. However, if there is a reasonable chance of reducing such emissions, they should be included in the baseline scenario in order to create a robust incentive for their reduction.
- · Users should account for the following drivers in the baseline scenario: causes of past, present, and future land-  use change; policies and measures affecting land and natural resource management; structural changes in the land sector; population and demographic trends; technological development; natural disturbance events; and the age class structure of wooden biomass as well as its management system.
- · For sources of historical emissions factor data, in the context of Tier 1 methods, IPCC default emission factors should be used; for higher tier methods, use should be made of field/inventory data, biomass/ carbon density maps derived from remote sensing and field data, and industry data. Historical activity data are derived from reported agricultural output or forest harvests and academic research.

## 5.2.8 carry out uncertainty and sensitivity analysis

Baseline scenarios are not predictions of the future but rather estimated emissions trajectories given specific assumptions and methods. Therefore, it is unlikely that they will project future emissions levels with high accuracy or certainty. Given the large uncertainties associated with baseline scenarios, users shall report a quantitative estimate or qualitative description of the uncertainty of the results, as well as the range of results from sensitivity analysis for key parameters and assumptions.

## 5 . 2 . 8   g u i d a n c e

Uncertainty analysis is a procedure to quantify or qualify sources of uncertainty. Uncertainty analyses can be used as part of the baseline scenario development process as a tool for guiding data quality improvements and reporting uncertainty results. Users should identify and track key uncertainty sources throughout the process and iteratively check whether the confidence level of the results is adequate for the stated objectives. Users may choose a qualitative or quantitative approach to uncertainty analysis. Quantitative uncertainty analysis can provide more robust results than a qualitative assessment and better assist users in prioritizing data improvement efforts. Including a quantitative uncertainty range in the goal assessment report also adds clarity and transparency to users of the report. For additional information on uncertainty, users should refer to in IPCC 2006: Vol. 1, Chap. 3, 'Uncertainties'; and IPCC 2000.

Uncertainty estimates may be reported in many ways, including qualitative descriptions of uncertainty sources and quantitative representations, such as error bars, histograms, and probability density functions, among others. Users should disclose uncertainty information as completely as possible. Users of the information may then weigh the total set of information provided in judging their confidence in the information. Users should also report on efforts to reduce uncertainty in future revisions of the assessment, if applicable.

Uncertainty can be divided into three categories: parameter uncertainty, scenario uncertainty, and model uncertainty.

parameter uncertainty refers to whether a parameter value used in the development of the baseline scenario accurately represents the true value of the parameter. Measurement errors, inaccurate approximation, unreliable projections, and low quality data sources influence parameter uncertainty. Sources of parameter uncertainty include activity data, emission factor data, GWP values, and assumptions for emissions drivers. If parameter uncertainty can be determined, it can typically be represented as a probability distribution of possible values that includes the chosen value used in the baseline scenario. To identify the influence of parameter values on resulting baseline scenario emissions, users should undertake sensitivity analysis. In addition, users may apply methods such as Monte Carlo analysis to understand the combined uncertainty of multiple parameters.

scenario uncertainty refers to variation in baseline scenario emissions resulting from methodological choices. When the standard includes multiple methodological choices, such as the inclusion of policies, scenario uncertainty is created. To identify the influence of a certain methodological choice on resulting baseline scenario emissions, users should undertake sensitivity analysis.

model uncertainty arises from limitations in the ability of modeling approaches used to reflect the real world. Simplifying the real world into a numeric model introduces inaccuracies, especially when projecting future events. In many cases, model uncertainties can be represented, at least in part, through the parameter or scenario approaches described above. However, some aspects of model uncertainty might not be captured by these classifications and are otherwise very difficult to quantify.

## Sensitivity analysis

Sensitivity analysis assesses the extent to which the outputs of the modeling approach, such as projected activity data, projected emission factors, and projected emissions, vary according to model inputs, such as assumptions and methodological choices.

Sensitivity analysis involves testing a range of values for key parameters (or combination of parameters) known to be uncertain or subject to judgment. Typically, sensitivity analysis is conducted for one parameter at a time. The aim is to quantify the effect that changes in a parameter's value have on the relevant model output. For example, assessing the sensitivity of baseline scenario emissions to changes in GDP may involve testing a range of possible GDP growth rates and analyzing how changes in the growth rate affect emissions.

When developing a baseline scenario, users should identify key parameters that have the most impact on overall baseline scenario emissions and conduct sensitivity analysis on them. Since baseline scenario emissions are often sensitive to changes in GDP, energy intensity of GDP, and energy prices, sensitivity analysis should, at a minimum, be conducted on these parameters. Users also should use sensitivity analysis to develop a range of plausible baseline scenarios.

<!-- image -->

## 5.2.9 develop a range of plausible baseline scenarios

A range of baseline scenarios reflects the upper and lower bounds of plausible emissions trajectories associated with a range of assumptions for key emissions drivers such as GDP, energy prices, population, and technological change. Each baseline scenario in the range can also reflect a different storyline about future events. For example, one baseline may describe a high-  GDP growth scenario, while another describes a low-  GDP scenario. While the development of multiple scenarios can be resource intensive, the presentation of multiple baseline scenarios provides users and stakeholders with information about the sensitivity of baseline scenario emissions to changes in key drivers and methodological choices, which can build confidence in the chosen scenario.

## 5 . 2 . 9   g u i d a n c e

Users should develop a range of plausible baseline scenarios, instead of a single scenario, in order to reflect the range of possible assumptions about future changes in key drivers and the uncertainty associated with any one assumption or parameter. The range of likely values for assumptions should be based on the findings of uncertainty analysis and sensitivity analysis. If a range of scenarios is developed, users should report the range of plausible baseline scenarios.

Once a range of plausible baseline scenarios has been developed, users should choose and report a single baseline scenario against which to set the goal and track progress, since a single baseline provides greater certainty regarding allowable emissions in the target year or period compared to selecting a range of baseline scenarios. To ensure environmental integrity, users should pick a conservative baseline scenario-  underestimating GHG reductions resulting from the goal-  which is an emissions trajectory within the lower bound of the range (see Figure 5.5). If the goal is set against a less conservative baseline scenario located in the upper bound of the range, the ambition of the goal will likely be compromised.

Box 5.6 provides a range of baseline scenarios developed by Chile related to its national voluntary baseline scenario goal.

figure 5.5 range of plausible baseline scenarios

<!-- image -->

start year of baseline scenario target year

## Box 5.6 range of plausible baseline scenarios developed by chile

As mentioned in Box 5.4, the Climate Change Office of the Ministry of Environment in Chile applied the mitigation goal standard to carry out an ex-  ante assessment of Chile's national voluntary goal to deviate from business-  as-  usual emissions growth using information from the MAPS Chile project.

As part of the baseline scenario development process, the MAPS Chile initiative developed a range of plausible baseline scenarios based on different economic growth rates (see Figure 5.6 and Table 5.13).* The results show that the projected baseline scenario emissions in 2020 may range from 124.3 to 177.9 Mt CO e. Depending on the baseline scenario chosen, a 20 percent deviation 2 from business as usual may result in allowable emissions in the target year (2020) that range from 99.4 to 142.4 Mt CO e. The 2 range of baseline scenarios developed by Chile illustrates how sensitive Chile's baseline scenario emissions are to economic growth.

figure 5.6 Baseline scenario emissions levels in 2020 under various gdp growth rates

<!-- image -->

table 5.13 Baseline scenario emissions levels in 2020 based on various gdp growth rate assumptions

| scenario        |   emissions (mt co 2 e) |   average gdp growth rate assumption (%) |
|-----------------|-------------------------|------------------------------------------|
| gdp pessimistic |                   124.3 |                                      3   |
| gdp medium low  |                   139.9 |                                      3.7 |
| gdp medium high |                   158.6 |                                      4.2 |
| gdp optimistic  |                   177.9 |                                      4.8 |
| gdp reference** |                   136.2 |                                      3.4 |
| minimum         |                   124.3 |                                      3   |
| maximum         |                   177.9 |                                      4.8 |

- *   See MAPS Chile 2013.
- **   The reference scenario considers the real growth rate published by the Banco Central de Chile for the years 2007-10. For the following years, this scenario is based on the projections used in different studies developed between the years 2009 and 2012, which are considering the years up until 2030.

<!-- image -->

## endnotes

- 1.  See IPCC 2006.
- 2.  For an example of stakeholder consultations for baseline scenarios, see Søbygaard et al. 2013.
- 3.  For example, see Søbygaard et al. 2013; Farías and Díaz Romero 2014; MAPS 2014a; Clapp and Prag 2012; and Clapp et al. 2009.
- 4.  See Søbygaard et al. 2013 for further information.
- 5.  For information related to capacity building on baseline scenario development, see Søbygaard et al. 2013; and MAPS 2014.
- 6.  Fransen, Barua, and Wood 2014 provides a framework for considering factors that may influence effective policy implementation in more detail.

6

Accounting for the Land Sector

<!-- image -->

<!-- image -->

T his  chapter provides guidance on accounting for emissions and removals from the land sector and is intended for users that include the land sector in the goal boundary, have a separate sectoral goal for the land sector, or treat the land sector as an offset.

## figure 6.1 overview of steps in this chapter

overview and key concepts (section 6.1)

choose land-based or activity-based accounting approach (section 6.2)

<!-- image -->

choose accounting method (section 6.5)

minimize potential risks associated with chosen accounting method (section 6.6)

<!-- image -->

<!-- image -->

<!-- image -->

## 6.1 Overview and key concepts

In this standard, the term 'land sector' refers to the forestland, cropland, grassland, wetland, settlement, and other land categories in Volume 4 of the IPCC's 2006 Guidelines for National Greenhouse Gas Inventories . These categories are sometimes referred to collectively as land use, land-  use change, and forestry (LULUCF), or simply the land sector. They are the categories where removals as well as emissions can occur. This chapter choose land uses or activities (section 6.3)

choose specific carbon pools, fluxes, and categories/ activities (section 6.4)

<!-- image -->

<!-- image -->

decide on treatment of natural disturbances (section 6.7)

revising land sector accounting (section 6.8)

<!-- image -->

does not refer to emissions of non-  CO  gases-  for 2 example, from enteric fermentation, waste disposal, fertilization and rice production-  that are reported to UNFCCC separately under agriculture. Nor does it refer to energy-  related emissions from agriculture or forestry equipment and transportation. These and other nonland-  based emissions should be accounted for separately

table 6.1 accounting requirements in this chapter

| section                                                                        | accounting requirements                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
|--------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| choose land uses or activities (section 6.3)                                   | • Account for emissions and removals arising from land use and land-use change within elected land-use categories or activities.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| choose specific carbon pools, fluxes, and categories/ activities (section 6.4) | • Account for all significant land-based carbon pools, GHG fluxes, and sub-categories/ activities within elected land-use categories or suites of activities. • Account for harvested wood products using one of the relevant IPCC methodologies and good practice guidance and taking account of any UNFCCC or other decisions that are relevant.                                                                                                                                                                                                                                                                                               |
| decide on treatment of natural disturbances (section 6.7)                      | When factoring out natural disturbances: • Exclude any removals on lands affected by a natural disturbance from accounting until they have balanced the quantity of emissions removed from accounting • If relevant, ensure consistency with the treatment of natural disturbances in the base year, base period, or baseline scenario, including by excluding removals associated with the previously disturbed land in the base year or period or baseline • Account for emissions associated with salvage logging • Do not exclude emissions from natural disturbances on lands that are subject to land-use change following the disturbance |
| revising land sector accounting (section 6.8)                                  | Undertake all relevant land-sector accounting and reporting steps again if: • Users change the land sector accounting approach during the goal period • Users add a land category, sub-category, or activity to accounting, or change the treatment of an existing land category, sub-category, or activity • Users revise the goal level to compensate for non-additional emissions or emission reductions                                                                                                                                                                                                                                      |

Note: Reporting requirements are listed in Chapter 11. Some choices regarding the land sector have no requirements and therefore are not referenced in the above box; however, there is guidance throughout the chapter, as relevant.

under their corresponding IPCC inventory sector or category (such as the energy or transportation sectors).

## difference between the land sector and other sectors

As a first step for land-  use accounting, users should develop a GHG inventory for land sector emissions and removals consistent with the IPCC Guidelines for National Greenhouse Gas Inventories . None of the recommendations in this standard are intended to preclude or deviate from existing IPCC guidance. The only exception is that the 2006 IPCC Guidelines combine agriculture, forestry, and other land use in Volume 4 whereas this standard separates LULUCF and agriculture emissions. This is because the latter are treated throughout in the same way as other inventory categories, whereas special rules may be applied to the former. Users should account for non-  land-  based agricultural emissions separately from forestry and other land use for the purpose of mitigation accounting.

Unlike other sectors, the emissions included in a GHG inventory for the land sector may include significant fluxes of both anthropogenic and non-  anthropogenic origin. The two dominant sources of non-  anthropogenic fluxes are (1) natural disturbances, which may include discrete events such as fires, windstorms, hurricanes, landslides, and tsunamis, or more continuous disturbances such as a pest outbreak or prolonged drought, and (2) earlier land-  use management that continues to influence emissions and removals during the goal period, such as forest age-  class structure and associated patterns of harvest and replanting. If these are not taken into account they can significantly distort mitigation needed elsewhere to meet goals. Dealing with these issues gives rise to special accounting rules for the land sector.

The treatment of anthropogenic versus non-  anthropogenic fluxes in the land sector has fundamental implications for how users account for land sector emissions and removals. For some users disturbance-  related emissions or legacy effects may be relatively small compared with total emissions. These users may choose not to use special accounting rules, which is simpler, and may opt to account for the land sector as they would for other sectors included in the goal boundary by using GHG inventory methods.

circumstances may therefore choose to apply special additional land sector accounting methods to minimize the arbitrary effects and better reflect changes in land sector emissions and removals caused by mitigation efforts. This applies especially to users in compliance regimes. Reporting for the land sector should include information on the criteria used to distinguish anthropogenic from nonanthropogenic fluxes, including the justification for doing so.

However, other users may experience frequent non-  anthropogenic disturbance events or legacy effects that cause large fluctuations in GHG inventories. For these users, inventory-  based accounting methods may reflect changes in emissions and removals caused by natural disturbance events in addition to mitigation efforts, rather than mitigation efforts alone. Similarly, users that have undertaken large-  scale land-  use management projects in the past, such as wetlands drainage or afforestation, might find that an inventory-  based approach primarily reflects continuing impacts of past management practices, rather than present mitigation efforts. Users in both of these

The requirements and recommendations contained herein are designed to work both in conjunction with existing accounting frameworks, such as those under the UNFCCC, as well as with national strategies and voluntary mechanisms, and they are applicable to all jurisdictions. This standard draws on progress made by the UNFCCC under the mechanism for reducing emissions from deforestation and forest degradation, including forest conservation, sustainable forest management and the enhancement of carbon stocks (REDD+), as well as Kyoto Protocol mechanisms, but it is not necessarily bound by them.

Users may find it helpful to review other detailed guidance on land sector accounting, such as the 2006 IPCC

<!-- image -->

Guidelines, the 2003 IPCC Good Practice Guidance for Land Use, Land-  Use Change and Forestry , or the 2013 Revised Supplementary Methods and Good Practice Guidance Arising from the Kyoto Protocol.

## 6.2 Choose land-  based or activitybased accounting approach

After deciding on the treatment of emissions and removals from the land sector in Chapter 4 (Section 4.2.3), the next step is to choose the land-  use accounting approach. Users may account for the land sector using a land-  based accounting approach or an activity-  based one. Land-  based accounting assesses net emissions (emissions + removals) of select land-  use categories, while an activity-  based accounting approach assesses net emissions of select land-  use activities. The underlying purpose of both approaches is the same: to delineate the geographic areas, pools, and fluxes included in the goal boundary. Users shall report the chosen accounting approach. Users shall report their use of the managed land proxy, including the definition of 'managed land' that has been adopted, and the locations of managed and unmanaged lands.

## 6 . 2   g u i d a n c e

The choice of land-  based or activity-  based accounting approaches should be determined by the existing structure and scope of the jurisdiction's GHG inventory, as well as capacities, data availability, priorities, and objectives.

## land-  based accounting approach

The land-  based accounting approach determines the scope of accounting based on six land-  use categories: forestland, cropland, grassland, wetland, settlement, and other land. The categories used for land-  based accounting should correspond to the reporting categories in a jurisdiction's GHG inventory. Accounting should cover all lands within the category of interest. For example, if users select cropland as a category, net emissions from all lands classified in the GHG inventory as croplands should be accounted for.

Lands subject to land-  use change should be accounted for under the land-  use category to which they are converted. If accounting for the converted-  to-  land-  use category is not elected, the net emissions should be accounted for under the converted-  from-  land-  use category. 1

In some instances, users may wish to use the managed land proxy in conjunction with land-  based accounting. Under this approach, estimates of emissions and removals on land subject to human management are used as a proxy to exclude non-  anthropogenic fluxes from accounting. The managed land proxy identifies areas of land that are 'unmanaged' are excludes them from the goal boundary based on the assumption that any fluxes occurring on those lands are not directly attributable to human influence.  Users that choose to use the managed land 2 proxy should ensure that they include all lands subject to direct human intervention in the goal boundary, as well as lands on which any identifiable portion of emissions or removals result from anthropogenic activity.

## activity-  based accounting approach

The activity-  based accounting approach bases the accounting on a predetermined set of land-  use practices. For example, a user may decide that the lands, pools, and fluxes to be included in accounting for the activity 'grazing land management' are those affected by livestock ranching, fire prevention, and activities related to savannah restoration. The theory underlying activity-  based accounting is similar to that of the managed land proxy-  to limit accounting to those lands subject to direct human influence and thereby exclude non-  anthropogenic fluxes from accounting.

Activity definitions are jurisdiction-  specific. In order to uphold the environmental integrity of land-  use accounting, users that choose activity-  based accounting should include all anthropogenic activities that result in changes in carbon pools or fluxes and emissions resulting from land-  use change activities. The land-  use activities and subcategories listed in Table 6.2 are for illustrative purposes only and do not represent the complete list of activities for which users may account.

## table 6.2 examples of land-  use activities and subcategories

| select activity categories   | select activity sub-categories                                                                                                                                |
|------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| forest management            | Afforestation/reforestation, deforestation, community forestry, sustainable forest management, enhancement of forest carbon stocks, protected area management |
| cropland management          | Soil carbon management, cropland fertilizer/manure application, agroforestry, controlled burning, vegetation management                                       |
| grassland management         | Soil carbon management, controlled burning, vegetation management, protected area management                                                                  |
| wetland management           | Wetland drainage, wetland rewetting, vegetation management, protected area management                                                                         |

## 6.3 Choose land use categories or activities

## 6.4 Choose specific carbon pools, GHG fluxes, and categories/activities

Users should strive for comprehensive coverage of all anthropogenic emissions and removals within each elected land-  use category or suite of activities. As far as practicable, users should aim to include all landuse categories or suites of activities in accounting. If necessary, users may adopt a stepwise approach to accounting for additional land-  use categories or activities based on data availability and capacity, as well as the contribution of additional categories to total emissions and trends. Land-  use accounting should not include agricultural activities involving fossil fuel use or livestock management . More specifically, land-  use accounting excludes enteric fermentation and manure management but includes manure application to lands, as emissions from this practice as characterized as 'land-  based.'

Users shall report which land-  use categories or activities are included, as well as the percentage of total inventory emissions from the land sector that is included in the goal boundary in the base year or period or baseline scenario, as relevant. Within elected land-  use categories or activities, users shall account for emissions and removals arising from or resulting in land use and land-  use change.

Regardless of whether a user chooses land-  based or activitybased accounting, users should aim for comprehensive coverage of all carbon pools and fluxes of greenhouse gases within each elected land-  use category or suite of activities. Carbon pools are reservoirs containing carbon in the land sector. GHG fluxes include both transfers of carbon from one carbon pool to another and non-  CO  emissions arising 2 from activities such as prescribed burning and manure management. The more comprehensive the coverage is, the greater the overlap of covered emissions and removals will be between land-  based and activity-  based approaches. The key categories approach in Volume 4 of the 2006 IPCC Guidelines for National Greenhouse Gas Inventories should inform, but not limit, the choice of carbon pools, GHG fluxes, and categories included in accounting.

Users adopting the managed land proxy should include all lands subject to direct human intervention, as well as lands on which an identifiable portion of emissions or removals results directly or indirectly from anthropogenic activity. Users that have adopted activity-  based accounting should aim to include all activities within a suite of activities that result in changes in carbon pools or GHG fluxes.

Users shall account for changes in all significant land-  based carbon pools, GHG fluxes, and subcategories/activities within elected land-  use categories or suites of activities.

Significance may be defined in terms of contribution to sectoral or economy-  wide emissions, short- or longterm trends, or mitigation potential, or the uncertainty in emissions or removals. Emissions and subsequent removals from unforeseen, non-  anthropogenic disturbances may be removed from accounting, as explained in Section 6.7.

Users shall report which carbon pools, GHG fluxes, and categories/activities are included within elected land-  use categories or suites of activities.

Users shall report whether harvested wood products, including wood and paper products, are included in accounting. Users shall account for harvested wood products using one of the relevant IPCC methodologies and/or good practice guidance and taking account of any UNFCCC or other decisions that are relevant. The IPCC approach, in which all emissions and removals associated with forest harvesting and the oxidation of wood products are accounted for by the user in the year of harvesting, may be used. This will not guarantee consistency with the treatment of other users. Users party to a common compliance agreement should use the common harvested wood products approach, if one has been agreed.

## 6.5 Choose the accounting method

Land sector accounting methods are used to assess changes in net emissions (emissions + removals) within each land-  use category or activity. The choice of method may have a significant impact on the assessment of goal progress and goal achievement. There are three land sector accounting methods: (1) accounting relative to base year/ period emissions (also known as net-  net); (2) accounting without reference to base year/period or baseline scenario emissions (also known as gross-  net); and (3) accounting relative to a forward-  looking baseline (see Table 6.3).

Each approach is illustrated in Figures 6.2-6.4.

Users that include the land sector in the goal boundary should use an accounting method that is consistent with accounting for the goal, depending on the chosen goal type (see below).

table 6.3 land sector accounting methods options

| accounting method                                                    | description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|----------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| relative to base year/ period emissions                              | • Compares net emissions in the target year(s) with net emissions in the base year. The difference between the two values is applied toward goal achievement. • Accounting under this approach reflects changes in emissions relative to past performance. Section 5.1 provides guidance on calculating net base year land sector emissions.                                                                                                                                                    |
| without reference to base year/period or baseline scenario emissions | • Applies the total quantity of net land sector emissions in the target year(s) toward the goal. • Unlike the other two methods, this type of accounting does not compare net emissions in the target year(s) to any reference case (either historical base year emissions or baseline emissions).                                                                                                                                                                                              |
| forward-looking baseline                                             | • Compares net emissions in the target year(s) with a projection of net baseline scenario emissions in the target year(s).* • The difference between the two values is applied toward goal achievement. Accounting under this approach reflects changes in emissions relative to a reference case that represents the net emissions levels most likely to occur in the absence of activities taken to meet the mitigation goal. Section 5.2 provides guidance on developing baseline scenarios. |

*   Forward-  looking baseline accounting is also a form of net-  net accounting, but it is distinguished here by its use of a baseline scenario projection as the basis of comparison, rather than a base year or period.

<!-- image -->

- · Base year emissions goal : Account relative to base year/period emissions (also known as net-  net accounting)
- · fixed-level goal : Account in the target year/ period, without reference to base year/period or baseline scenario emissions (also known as gross-  net accounting)
- · Base year intensity goal : Account for emissions intensity relative to a base year/period (also known as net-  net accounting)
- · Baseline scenario goal : Use forward-  looking baseline accounting method

For all accounting methods, users should use the same accounting approach for all land categories or activities. Under certain circumstances, however, it may be necessary to account for a specific category, subcategory, or activity using a different approach from the rest of the sector.  In 3 this situation, users shall report the rationale for treating any category, subcategory, or activity differently, the new accounting method chosen and reasons for choosing it, and the potential impacts of the different approach on the land sector and goal accounting.

Users shall report the chosen land sector accounting method(s).

figure 6.2 accounting for the land sector relative to base period emissions

<!-- image -->

figure 6.3   accounting for the land sector in the target year, without reference to a base year/period or baseline scenario emissions

<!-- image -->

figure 6.4 forward-  looking baseline accounting

target year

<!-- image -->

## guidance for choosing land sector accounting method (for users that treat the land sector as an offset)

Users that treat the land sector as an offset or a separate sectoral goal may use any of the three accounting methods to assess changes in land sector emissions and removals. Table 6.4 provides a list of advantages and disadvantages of each accounting method. Users that wish to create a signal for mitigation relative to historical levels may choose to account for emissions relative to a base year. Users that wish to create an incentive for marginal improvements in the land sector may account for it relative to a baseline scenario.

<!-- image -->

## table 6.4 advantages and disadvantages of land-  use accounting methods

| method                                                                | advantages                                                                                                                                                                                                                                                                                                                                                                                | disadvantages                                                                                                                                                                                                                                                                                                                                                                         |
|-----------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| relative to a base year/period emissions                              | • Creates a signal for mitigation relative to historical emissions • Reflects changes in emissions relative to past performance                                                                                                                                                                                                                                                           | • Emission reductions may not be additional to what would have occurred in the absence of a goal • Long-term trends in nonanthropogenic emissions may obscure impacts of anthropogenic mitigation and result in risks in accounting • Requires historical data                                                                                                                        |
| without reference to base year/ period or baseline scenario emissions | • Net emissions are 'what the atmosphere sees' during the target year/period • Relatively easy to calculate                                                                                                                                                                                                                                                                               | • Risk of low environmental integrity; this method creates the potential for accounting for large quantities of net removals that are not associated with long-term sequestration of carbon dioxide emissions • Depending on the size of the removal, accounting for the land sector could provide little signal for accounting for mitigation in other sectors                       |
| forward-looking baseline accounting method                            | • Allows a user to remove anticipated nonanthropogenic emissions and removals from accounting • Creates a signal for changes in land-use management that reduce emissions relative to business-as-usual • Increases the likelihood that emission reductions are additional to those that would have occurred without a goal, but depends on assumptions underlining the baseline scenario | • Highly complex and data-intensive to calculate the baseline scenario • High uncertainty and variability in land sector emissions may lead to baseline scenarios that are not accurate representations of business-as-usual, resulting in non- additional accounting • Users may claim credit for emission reductions even when net emissions increase relative to historical levels |

## 6.6 Minimize potential risks associated with the chosen accounting method

Users should minimize risks associated with the chosen accounting method that would lead to the goal's being set too leniently or that would disincentivize mitigation. The inclusion of non-  additional emissions or removalsthose that would have occurred in the absence of a mitigation goal-  in the accounting may compromise the integrity of the goal. Such emissions and removals may have been 'locked in' by previous events and do not reflect current mitigation efforts. For example, a user in a compliance regime using a historical base period may seek to account for changes in emissions relative to past performance. However, if emissions from the land sector in the base period were particularly high because its forest plantations reached maturity at that time and were harvested, accounting relative to the base year/ period for the land sector would result in credits for emission reductions during the target year or period that would have occurred in the absence of mitigation.

Users should also analyze the uncertainties in levels and trends of emissions and removals to help ensure that changes are real and not the result of uncertainties in estimates. Methods for uncertainty analysis are set out in the IPCC 2003 Good Practice Guidance for Land Use, Land-  Use Change and Forestry and the IPCC 2006

Guidelines for National Greenhouse Gas Inventories . Users should report how land-  use data uncertainty is addressed.

Whether a user should address the risks of non-  additional accounting depends on the treatment of the land sector in relation to the mitigation goal, the accounting method chosen, and other factors such as whether the user is participating in a compliance regime. Several options to limit potential risks in the accounting are listed by accounting method below. One option available under each method is a cap. A cap limits the amount of emissions or removals that can be accounted in the sector. However, the cap may reduce users' incentives to mitigate net emissions in the land sector. Instead of using caps, users should when possible apply alternative techniques, such as jurisdiction-  specific practices for maximizing additionality, conservative methods and data, or increasing the goal level to counteract the effects of non-  additional accounting. Users unable to utilize these approaches may choose to use a cap on accounting in the land sector as a last resort.

level of the goal, and they will need to undertake all accounting and reporting steps again (see Section 6.8).

## 6 . 6   g u i d a n c e

## accounting relative to base year/period emissions

Users shall report the potential risks associated with the accounting method and how those risks are minimized. If users exclude part or all of a land category or a land-  use activity from the goal boundary, users shall report the exclusion, the reason for the exclusion, and the reason for any alternative accounting approach chosen. If a cap is chosen, users shall report the level of the cap. If the goal level is adjusted, users shall report on the new

Accounting relative to base year/period emissions can result in the inclusion of non-  additional emissions or emission reductions when effects, such as natural disturbances, long-  term trends, or age-  class structure, obscure the impacts of land-  use mitigation efforts during the goal period. This consideration is particularly relevant for users that are dependent on incentives for incremental mitigation improvements or are participants in a compliance regime. Users should minimize the risk of non-  additional net emissions. First, they should consider increasing the goal level to compensate for non-  additional net emissions included in accounting. If the goal level is changed, users are required to undertake all accounting and reporting steps for the new goal and recalculate emissions, as relevant (further described in Section 8.4). Second, users can remove the land-  use category/activity affected by the nonanthropogenic event from the economy-  wide or sectoral goal and account for it under a separate, category- or activity-  specific goal. Or third, users can apply a cap on net land sector emissions applied to the goal (see Figure 6.5).

figure 6.5 accounting relative to base year/period emissions using a cap

<!-- image -->

The issue of non-  additional net emissions may also affect accounting when the land sector is treated as an offset and accounted for relative to a base year/period. In this case, users should minimize risks by (1) increasing the goal level or (2) putting a cap on the quantity of net emissions that can be accounted toward the goal (see Figure 6.5, in which base period and target year net emissions are negative because removals outweigh emissions).

## accounting without reference to base year/ period or baseline scenario emissions

This method creates the potential for the accounting to include large quantities of non-  additional emissions or emission reductions in certain circumstances because there is no comparison to base year or period emissions. The method also poses the risk of accounting for large quantities of net removals that are not associated with a long-  term sequestration of carbon dioxide. Users applying this method should therefore consider whether this method maximizes additionality.

If the land-  use category/activity that generates significant non-  additional emissions or emission reductions is included in the goal boundary, users should consider increasing the goal level to compensate for the impacts of non-  additional credits/debits. If the goal level is changed, users are required to undertake all accounting and reporting steps for the new goal and recalculate emissions, as relevant (further described in Section 8.4). The issue of non-  additional credits is especially relevant for forestland, as the age-  class structure of a jurisdiction's forests and the resulting removals from the atmosphere may not represent mitigation additional to that which would have occurred in the absence of a goal.

In addition, a cap on the quantity of net emissions or emission reductions can be applied to the goal in order to limit adverse impacts on the goal (see Figure 6.6).

## forward-  looking baseline accounting method

There are two potential weaknesses of using a baseline scenario for land-  use accounting: (1) difficulty in determining which anticipated emissions and removals are non-  anthropogenic and should thus be excluded from accounting and included in the baseline scenario instead and (2) difficulty in accurately predicting baseline scenario emissions and removals for the sector. Both weaknesses can result in inaccurate baseline scenarios that erode the environmental integrity of accounting, and therefore of mitigation. Users should employ a conservative approach to developing a baseline scenario for the land sector to ameliorate the potential impacts of uncertainty on accounting. Additionally, users should consider using a cutoff date after which the effects of new policies and measures are not included in the baseline in order to maximize the likelihood that accounting captures the associated anthropogenic emissions and removals.

## figure 6.6 accounting without reference to base year/period or baseline scenario emissions using a cap

<!-- image -->

Users should consider two additional methodological means of mitigating the likelihood that inaccurate baseline scenarios will have an adverse impact on accounting: (1) recalculation of the baseline scenario (if the baseline scenario goal is dynamic; see Chapter 5) and (2) use of a cap on the sector's accountable emission removals to limit the sector's impact on the goal (relevant if land sector is included in the goal or used as an offset).

## 6.7 Decide on treatment of natural disturbances

Natural disturbances are non-  anthropogenic events or circumstances such as fire, severe drought and windstorms that cause significant emissions and are beyond the control of, and not materially influenced by, the jurisdiction. When natural disturbances have the potential to significantly impact net emissions from the land sector, users may establish mechanisms to remove the associated emissions and removals from accounting. Users may use a natural disturbance mechanism for individual categories or activities or for the land sector as a whole. Removing emissions and removals associated with natural disturbances can be a highly complex and data-  intensive process.

If removing emissions and removals associated with natural disturbances, users shall :

- · Exclude any removals on lands affected by a natural disturbance from accounting until they have balanced the quantity of emissions removed from accounting. 4 This approach upholds environmental integrity by preventing a jurisdiction from factoring out the emissions from a natural disturbance and also taking credit for the resulting removals. A natural disturbance mechanism should remove from accounting not only the emissions but also the subsequent removals resulting from the recovery of carbon stocks after the disturbance event or circumstance or a new goal has been set that takes account of the condition of the land where the natural disturbance took place.
- · If relevant, ensure consistency with the treatment of natural disturbances in the base year, base period, or baseline scenario, including by excluding removals associated with the previously disturbed land in the base year or period or baseline.
- · Not exclude emissions associated with salvage logging.
- · Not exclude emissions from natural disturbances on lands that are subject to land-  use change following the disturbance.

## Users shall report:

- · All lands subject to the natural disturbance mechanism, including their georeferenced location, year, and types of disturbances.
- · How annual emissions resulting from disturbances and the subsequent removals in those areas are estimated.
- · Evidence demonstrating that no land-  use change has occurred on lands for which the mechanism is applied, and explain the methods and criteria for identifying any future land-  use changes on those land areas during the goal period.
- · Evidence demonstrating that the occurrences were beyond the control of, and not materially influenced by, the user during the goal period, by showing practicable efforts to prevent, manage, or control the occurrences that led to the application of the mechanism.
- · Evidence demonstrating efforts taken to rehabilitate, where practicable, the land for which the mechanism is applied.
- · Evidence demonstrating that emissions associated with salvage logging on forestland subject to natural disturbance will not be/were not excluded from accounting.

## 6 . 7   g u i d a n c e

Two primary technical considerations are associated with factoring out the impacts of natural disturbances ex post:

- · How to determine when the emissions from a natural disturbance event or circumstance are (1) truly nonanthropogenic and (2) significant enough to warrant factoring out
- · How to separate the emissions resulting from the actual disturbance, which may be factored out, from emissions stemming from subsequent anthropogenic activities that generate emissions, such as salvage logging, or subsequent changes in land use, which should not be factored out

Some approaches to factoring out natural disturbances may be applicable at other stages of the land-  use accounting process, such as including a background level of natural

<!-- image -->

disturbance emissions in a forward-  looking baseline scenario. Users employing a baseline scenario to account for forestlands or forest management may consider using the framework formulated for the second commitment period of the Kyoto Protocol. This framework contains a methodology for excluding 'expected' natural disturbance emissions from accounting. This framework also allows users to exclude emissions from 'unexpected' natural disturbances that exceed a certain emission threshold. 5 For more information see also the IPCC's 2013 Revised Supplementary Methods and Good Practice Guidance Arising from the Kyoto Protocol. While this guidance was developed in the context of Kyoto Protocol accounting, the methodological approach to disturbances may be applied more generally.

Although mechanisms to remove emissions and removals from natural disturbances from accounting may be used in conjunction with any accounting method, the additional accounting and reporting burden associated with a natural disturbance mechanism requires users to weigh the potential for large emissions impacts from natural disturbances against the costs of establishing and implementing a mechanism to address those emissions. Therefore, users should consider the necessity of such a provision given their specific circumstances and the potential impacts of natural disturbances given the chosen accounting approaches.

## 6.8 Revising land sector accounting

The following users shall undertake all relevant land-  sector accounting and reporting steps again and report any changes:

- · Users that change the land sector accounting approach during the goal period
- · Users that add a land category, subcategory, or activity to accounting, or change the treatment of an existing land category, subcategory, or activity
- · Users that revise the goal level to compensate for nonadditional emissions or emission reductions

Users that change the land sector accounting approach during the goal period shall also report the reasons for changing approaches and the quantitative and qualitative effects on land sector accounting and overall goal accounting. Section 8.4 provides guidance on defining a significance threshold and revising the mitigation goal.

## endnotes

- 1.  For more information on such categories, see IPCC 2006: Vol. 4, Chap. 2.
- 2.  See IPCC 2003: Chap. 3 .
- 3.  Such circumstances may arise in the context of accounting for forestland remaining forestland (land-  based accounting category approach) or forest management (activity approach). For this specific subcategory/activity, the legacy effects of past management decisions may lead to perverse results when combined with certain accounting approaches.
- 4.  In order to exclude emissions from a natural disturbance event, the land area subject to the disturbance is first georeferenced and the emissions (removed from the land-  use accounting) are quantified. After the event, the land will begin the process of recovery, which will generally include rebuilding soil carbon and/or vegetation. These phenomena will likely result in net removals on the area of recovering land.
- 5.  See paragraph 33, Annex to Decision 2/CMP.7, FCCC/KP/CMP/2011/10/Add.1, March 15, 2012.

7

<!-- image -->

Calculating Allowable Emissions in the Target Year(s)

<!-- image -->

T his  chapter  provides  guidance  on  calculating  allowable  emissions  and emissions  intensity  in  the  target  year  or  target  period.  In  addition,  it provides  guidance  on  calculating  emission  reductions  associated  with achieving  the  mitigation  goal  and  setting  milestones.  All  users  are  required  to fulfill the accounting and reporting requirements in this chapter.

figure 7.1 overview of steps in this chapter

calculate allowable emissions in the target(s) (section 7.1)

calculate allowable emissions intensity in the target year(s) (for users with intensity goals) (section 7.2)

calculate emission reductions associated with achieving the goal (optional) (section 7.3)

set milestones (optional) (section 7.4)

<!-- image -->

<!-- image -->

<!-- image -->

table 7.1 accounting requirements in this chapter

| section                                                                                                                | accounting requirements                                                                                    |
|------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|
| calculate allowable emissions in the target year or period (section 7.1)                                               | • Calculate allowable emissions in the target year(s).                                                     |
| calculate allowable emissions intensity in the target year(s) (for users with base year intensity goals) (section 7.2) | • For users with base year intensity goals: calculate allowable emissions intensity in the target year(s). |

Note: Reporting requirements are listed in Chapter 11. Some goal types have no requirements and therefore are not referenced in the above box; however, there is guidance throughout the chapter, as relevant.

## 7.1 Calculate allowable emissions in the target year(s)

Allowable emissions represent the maximum quantity of emissions that may be emitted in the target year, year or target period, or target period that is consistent with achieving the mitigation goal. Calculating allowable emissions provides users with critical information for decision making, designing mitigation strategies, assessing progress during the goal period, and assessing goal achievement. See Figures 7.2 and 7.3 for examples of allowable emissions in the target year for a base year emissions goal and baseline scenario goal, respectively.

Users shall calculate allowable emissions in the target year(s). Users shall report allowable emissions in the target year (for single-  year goals); in each year of the target period (for annual or average multi-  year goals); or over the target period (for cumulative multi-  year goals). Users with separate goals for in-  jurisdiction and out-  ofjurisdiction emissions shall separately report allowable emissions for in-  jurisdiction and out-  of-  jurisdiction emissions. Users with base year intensity goals shall report the estimated level of output in the target year(s) and the data sources or method used to estimate it.

## 7.1   g u i d a n c e

Users with single-  year goals should use Equation 7.1 to calculate allowable emissions in the target year for the relevant goal type. Users with annual and average multiyear goals should use Equation 7.1 to calculate allowable emissions for each year of the target period. For users with cumulative multi-  year goals, allowable emissions are the maximum quantity of cumulative emissions to be emitted over the target period, as specified by the goal level. 1

Users with base year intensity goals should also calculate allowable emissions. While achievement of base year intensity goals will ultimately be assessed in terms of emissions intensity, it can be helpful for decision makers and other stakeholders to understand the allowable emissions associated with base year intensity goals. Calculating allowable emissions for base year intensity goals requires forecasts of the level of output in the target year(s). Projections of output metrics should be gathered from official data sources. For example, GDP projections should be based on data from national government bodies or international sources such as the International Monetary Fund, World Bank, or Organisation for Economic Co-  operation and Development (OECD).

figure 7.2   example of allowable emissions in the target year for single-  year base year emissions goal

figure 7.3   example of allowable emissions in the target year for a single-  year baseline scenario goal

<!-- image -->

## equation 7.1 calculating allowable emissions in the target year

| goal type*               | calculation method                                                                                                                                                                                                                                        |
|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Base year emissions goal | allowable emissions in the target year (mt co 2 e) = Base year emissions (Mt CO 2 e) - [Base year emissions (Mt CO 2 e) x Percent reduction]                                                                                                              |
| fixed-level goal         | allowable emissions in the target year (mt co 2 e) = Absolute quantity of emissions specified by the goal level (Mt CO 2 e)                                                                                                                               |
| Base year intensity goal | estimated allowable emissions in the target year (mt co 2 e) = [Base year emissions intensity (Mt CO 2 e/level of output) - Base year emissions intensity (Mt CO 2 e/level of output) x Percent reduction] x Projected level of output in the target year |
| Baseline scenario goal** | allowable emissions in the target year (mt co 2 e) = Projected baseline scenario emissions in the target year (Mt CO 2 e) - [Projected baseline scenario emissions in the target year (Mt CO 2 e) x Percent reduction]                                    |

- * Sections 5.1.1, 5.1.2, and 5.2.7 provide guidance on whether to include land sector emissions in base year emissions, base year emissions intensity, and projected baseline scenario emissions.
- **  For dynamic baseline scenario goals, allowable emissions will be subject to change resulting from baseline scenario recalculations.

<!-- image -->

## 7.2 Calculate allowable emissions intensity in the target year(s) (for users with base year intensity goals)

Unlike with other goal types, allowable emissions for base year intensity goals represents an estimate only, since it requires forecasts of the level of output in the target year(s), which are likely to change over time and are unlikely to accurately represent the actual value in the target year(s).

Users with base year intensity goals shall report allowable emissions intensity in the target year or in each year of the target period. Users with single-  year base year intensity goals should use Equation 7.2 to calculate allowable emissions intensity for the target year, while users with multi-  year base year intensity goals should use Equation 7.2 for each year of the target period. Users with separate goals for in-  jurisdiction and out-  of-  jurisdiction emissions intensity shall separately report allowable emissions intensity for in-  jurisdiction and out-  of-  jurisdiction emissions intensity.

## equation 7.2 calculating allowable emissions intensity in the target year

allowable emissions intensity in the target year (t co e/level of output) = 2 Base year emissions intensity (t CO e/level of output) 2 [Base year emissions intensity (t CO e/level of output) × Percent reduction] 2

Note: Section 5.1 provides guidance on whether to include land sector emissions in base year emissions intensity.

## 7.3 Calculate emission reductions associated with achieving the goal (optional)

In addition to calculating allowable emissions, users may find it helpful to calculate the emission reductions associated with achieving the goal, in order to provide policymakers and stakeholders with such information.

Emission reductions associated with achieving the goal are the difference between emissions in the first year of the goal period and allowable emissions in the target year or period. See Equation 7.3 for equations by goal type. Users with multi-  year goals should use Equation 7.3 to calculate emission reductions associated with achieving the goal for each year of the target period. Users with separate goals for in-  jurisdiction and out-  of-  jurisdiction emissions should separately calculate and report emission reductions for each.

For users that are in the middle of the goal period, the quantity of emission reductions associated with achieving the goal calculated in this section is not the same as the quantity of emission reductions still needed to meet the goal, which depends on reporting year emissions rather than base year emissions. The quantity of emission reductions needed within the goal boundary also depends on the planned use of transferable emissions units (described further in Chapter 8).

## 7.4 Set milestones (optional)

Users should consider setting milestones at regular intervals throughout the goal period. Milestones are either informal or formal targets set during the goal period consistent with the broader goal, which can help users stay on track toward achieving the goal, guide goal assessment, inform policy making, and respond to stakeholder demand for intermediate targets. If the milestones are formal targets (for example, see Box 4.3, which describes the United Kingdom's series of goals), users should assess and report progress toward each goal separately. The timing of milestones should be aligned with users' planned frequency for assessing progress during the goal period and may be aligned with political milestones, planning cycles, budget periods, or other relevant time periods.

equation 7.3 calculating emission reductions associated with achieving the goal

| goal type                | calculation method*                                                                                                                                          |
|--------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Base year emissions goal | emission reductions (t co 2 e) = (Base year emissions (t CO 2 e)) - (Allowable emissions in the target year (t CO 2 e))                                      |
| fixed-level goal         | emission reductions (t co 2 e) = (Emissions in the year the goal is adopted (t CO 2 e)) - (Allowable emissions in the target year (t CO 2 2e))               |
| Base year intensity goal | estimated emission reductions (t co 2 e) = (Base year emissions (t CO 2 e)) - (Estimated allowable emissions in the target year (t CO2e))                    |
| Baseline scenario goal** | emission reductions (t co 2 e) = (Projected baseline scenario emissions in the target year (t CO 2 e)) - (Allowable emissions in the target year (t CO 2 e)) |

- * Sections 5.1.1 and 5.2.7 provide guidance on whether to include land sector emissions in base year emissions and projected baseline scenario emissions. For goals framed as a controlled increase in emissions, the calculation of emission reductions will yield a negative number, indicating an increase in emissions over the goal period.
- **    For dynamic baseline scenario goals, emission reductions associated with achieving the goal are subject to change as a result of baseline scenario recalculations.

The emissions levels of each milestone may be based on a linear emissions pathway consistent with achieving the goal (see Figure 7.4). In this case, the pathway should be consistent with the average annual rate of reductions over the goal period associated with achieving the goalcalculated by dividing total emission reductions associated with achieving the goal by the number of years in the goal period. Users should report any milestones set.

## endnotes

- 1.  This quantity is sometimes referred to as a carbon budget.

figure 7.4 example of milestones along a linear emissions pathway

<!-- image -->

<!-- image -->

8

<!-- image -->

## Assessing Progress during the Goal Period

T his chapter provides guidance on assessing and reporting progress during the goal period, before the target year/period is reached. This chapter is optional. The accounting and reporting requirements in this chapter apply to those users that choose to assess progress during the goal period.

figure 8.1 overview of steps in this chapter

choose frequency of assessment (section 8.1)

develop a ghg inventory and calculate reporting year emissions (section 8.2)

<!-- image -->

calculate change in emissions since the start of the goal period (section 8.5)

<!-- image -->

calculate additional emission reductions needed to achieve the goal (section 8.6)

<!-- image -->

<!-- image -->

calculate reporting year emissions intensity (for users with intensity goals) (section 8.3)

assess why emissions have changed since the start of the goal period (section 8.7)

<!-- image -->

<!-- image -->

recalculate emissions during the goal period (if relevant) (section 8.4)

assess whether jurisdiction is on track to achieve goal (section 8.8)

<!-- image -->

## table 8.1 checklist of accounting requirements in this chapter (for users that assess progress during the goal period)

| section                                                                                              | accounting requirements                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
|------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| develop a ghg inventory and calculate reporting year emissions (section 8.2)                         | • Calculate reporting year emissions by aggregating emissions from the GHG inventory for all gases and sectors that are included in the goal boundary and out-of-jurisdiction emissions, if relevant.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| calculate reporting year emissions intensity (for user with base year intensity goals) (section 8.3) | • For users with base year intensity goals: calculate reporting year emissions intensity.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| recalculate base year emissions or baseline scenario emissions (if relevant) (section 8.4)           | • Recalculate: (1) base year emissions, base year emissions intensity, or baseline scenario emissions; (2) allowable emissions or emissions intensity; and/or (3) reporting year emissions if significant changes are made to methods used and/or significant error(s) in original calculations are discovered. • For users with dynamic baseline scenario goals: recalculate baseline scenario emissions by replacing forecasted values with observed values for all significant exogenous emissions drivers. • If baseline scenario emissions are recalculated, recalculate allowable emissions (by re-applying Chapter 7) to ensure consistency. • Recalculate: (1) base year emissions, base year emissions intensity, or baseline scenario emissions; (2) allowable emissions or emissions intensity; and (3) reporting year emissions if significant revisions are made to the goal boundary (for example, changes in sectors, gases, or geographic area). • Recalculate: (1) allowable emissions or emissions intensity; and (2) reporting year emissions if the goal type or goal level is changed or the goal is changed from a single-year goal to a multi-year goal. • For users that change the goal type, goal level, or change from a single-year goal to a multi-year goal: follow all accounting and reporting requirements for the new goal by re-applying all relevant chapters. |
| calculate change in emissions since the start of the goal period (section 8.5)                       | • For users that treat the land sector as an offset: calculate the change in net land sector emissions in the reporting year from selected land-use categories, activities, and pools and fluxes based on the chosen land-use accounting method.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |

Note: Reporting requirements are listed in Chapter 11. Some goal types have no requirements and therefore are not referenced in the above box; however, there is guidance throughout the chapter, as relevant.

## 8.1 Choose frequency of assessment

During the goal period, users should regularly assess and report progress in order to understand emissions trends, progress achieved to date, additional reductions needed to reach allowable emissions, and the likelihood of achieving the goal. (See Figure 8.2 for an example of assessing progress during the goal period.) Users with separate goals for in-  jurisdiction and out-  of-  jurisdiction emissions should separately assess and report progress for in-  jurisdiction and out-  of-  jurisdiction emissions.

The frequency of assessment depends on stated objectives, policymaking needs, data availability, cost, capacity, and stakeholder demand. If feasible, users should report progress on an annual basis. Annual reporting will produce the timeliest and most consistent basis for assessing progress over time. Annual reporting also enables users to aggregate emissions over the entire goal period to calculate cumulative emissions. Once a reporting frequency is chosen, the same frequency should be used throughout the goal period. Users should report the frequency of goal assessment.

figure 8.2 example of assessing progress during the goal period

<!-- image -->

## 8.2 Develop a GHG inventory and calculate reporting year emissions

The first step in assessing progress is to develop a GHG inventory for the reporting year. Users without an inventory for the reporting year will not be able to complete the accounting and reporting steps outlined in this chapter. There may be a time lag between the GHG inventory year and the year in which the inventory is actually published. Similarly, for users with base year intensity goals, official statistics for the unit of output may not be immediately available. While relevant data may be collected in the interim, a complete assessment will need to be based on a published inventory and official statistics. Section 4.1 provides guidance for developing a GHG inventory. Users shall report a complete inventory for the reporting year, including out-  of-  jurisdiction emissions, if relevant.

Users shall calculate reporting year emissions by aggregating emissions from the GHG inventory for all gases and sectors included in the goal boundary and out-  ofjurisdiction emissions, if relevant.

For users that include the land sector in the goal boundary or treat it as a sectoral goal, reporting year emissions include land sector emissions and removals for all selected land-  use categories, activities, and pools and fluxes. For users that treat the land sector as an offset, reporting year emissions do not include land sector emissions and removals. This quantity is calculated separately in Section 8.5.

Users shall report reporting year emissions separately by gas (in tonnes) and in tonnes of carbon dioxide equivalent (CO e). Users that include the land sector in the goal 2 boundary or treat it as a sectoral goal shall report land sector emissions and removals separately for each selected land-  use category, activity, pool, and flux, as relevant, including all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances.

## 8.3 Calculate reporting year emissions intensity (for users with base year intensity goals)

In addition, users with base year intensity goals shall calculate reporting year emissions intensity using Equation 8.1. Data for the level of output should come from official, peer-

## equation 8.1 calculating reporting year emissions intensity

reporting year emissions intensity =

Reporting year emissions (Mt CO e) 2

Level of output (or relevant variable)  in the reporting year reviewed sources that are publicly available and subject to robust QA/QC procedures. Users with base year intensity goals shall report reporting year emissions intensity, the level of output in the reporting year, and the data sources used to determine the value for the level of output.

to determine whether changes or errors are significant enough to trigger any recalculations. Box 8.1 provides guidance on choosing a significance threshold.

## 8.4 Recalculate emissions during the goal period (if relevant)

To maintain the consistency of time-  series data and enable meaningful comparisons of emissions over the goal period, emissions and other values may need to be recalculated as a result of changes in methodology, changes in emissions drivers, or changes to the goal.

## recalculate emissions if required by methodological changes

Users shall recalculate (1) base year emissions, base year emissions intensity, or baseline scenario emissions; (2) allowable emissions or emissions intensity; and (3) reporting year emissions, if any of the following changes occur:

- · Significant changes are made to methods used, including:
- · Inventory calculation methods
- · Emissions projection models
- · Improvements in the accuracy of emission factors or activity data
- · GWP values
- · Significant change to the value of the unit of output in the base year (for users with base year intensity goals)
- · Discovery of significant error(s) in original calculations

Users should undertake GHG inventory recalculations in accordance with guidance provided by the relevant GHG inventory guidelines. In cases where no such guidance is provided, users should refer to IPCC guidance, for example, IPCC 2006: Vol., 1, Chap. 5, 'Time Series Consistency.' Users should choose and report a significance threshold

If a user chooses to use a goal baseline scenario developed by a third party, recalculating baseline scenario emissions will be difficult without using the third-  party model. In this case, if the third party is not available to rerun the model, users should disclose any errors or other changes to parameters that were discovered and, if relevant, justify why the baseline scenario could not be recalculated.

Users shall report any emissions recalculations, including recalculations of base year emissions, base year emissions

## Box 8.1 significance threshold

A significance threshold is a quantitative or qualitative criterion used to determine whether individual or cumulative changes in a parameter (or in parameters), such as the goal boundary, data, methods, or emissions drivers, are significant enough to trigger a recalculation of an emissions level, such as base year emissions, baseline scenario emissions, or net emissions from the land sector. Users may define the significance threshold used.

The determination of significance requires taking into account the individual or cumulative effect of changes in a parameter (or in parameters) on emissions levels. For example, in the case of baseline scenario emissions, a significance threshold of 5 percent means (1) that any change in an individual parameter that results in a 5 percent change in baseline scenario emissions would trigger a recalculation and (2) that any changes in a number of parameters that, when taken together, result in a cumulative 5 percent change to baseline scenario emissions would also trigger a recalculation.

intensity, baseline scenario emissions, and allowable emissions or emissions intensity, and the recalculated values alongside the original values.

## recalculate emissions if required by changes in emissions drivers (for users with dynamic baseline scenario goals)

In addition to recalculating baseline scenario emissions because of the changes outlined above, users with dynamic baseline scenario goals shall recalculate baseline scenario emissions by replacing forecasted values with observed values for all significant exogenous emissions drivers. Exogenous emissions drivers are emissions drivers that are unaffected by mitigation policies or actions implemented to meet the goal. Examples of exogenous drivers may include GDP, population, international energy prices, weather, and structural changes in economic sectors. Users shall provide justification for any key emissions drivers that are not updated.

Recalculating dynamic baseline scenarios allows users to isolate changes in emissions resulting from mitigation efforts as compared to changes in exogenous drivers. Users should recalculate dynamic baseline scenarios during the goal period to ensure that actual changes in exogenous drivers are regularly accounted for. This approach enables users to have a more accurate understanding of allowable emissions and increases the likelihood of achieving the goal. If baseline scenario emissions are recalculated, users shall also recalculate allowable emissions (by reapplying Chapter 7) to ensure consistency.

Users shall report any recalculation of dynamic baseline scenario emissions made during the goal period, including:

- · Which drivers were updated
- · Updated values for each driver alongside the original values
- · Recalculated baseline scenario emissions alongside the original value

Users shall report any recalculations of allowable emissions and recalculated allowable emissions alongside the original value.

## recalculate emissions if required by changes to the goal

Where possible, users should increase the ambition of the mitigation goal over time by expanding the goal boundary to include any previously excluded sectors and gases, changing the goal type to ensure that absolute emission reductions are achieved, and raising the ambition of the goal level. Users with sectoral goals in particular should aim to include more sectors and gases within the goal boundary over time.

If significant revisions are made to the goal boundary (for example, changes in sectors, gases, or geographic area), users shall recalculate (1) base year emissions, base year emissions intensity, or baseline scenario emissions; (2) allowable emissions or emissions intensity; and (3) reporting year emissions. Users should define a significance threshold for determining whether a goal boundary revision is significant and warrants a recalculation.

If the goal type or goal level is changed or the goal is changed from a single-  year goal to a multi-  year goal, users shall recalculate (1) allowable emissions or emissions intensity and (2) reporting year emissions.

In addition to the recalculations above, users that change the goal type, goal level, or change from a single-  year goal to a multi-  year goal shall follow all accounting and reporting requirements for the new goal by reapplying all relevant chapters.

Users shall report any revisions to the goal boundary and any changes to the goal type, goal level, or a change from a single-  year to a multi-  year goal, and any recalculations made, including recalculated and original values.

## 8.5 Calculate change in emissions since the start of the goal period

Calculating the change in emissions between the first year (or years) of the goal period and the reporting year can help decision makers and stakeholders understand trends in emission over the goal period and progress achieved to date, which can inform the design of future policies. Users should calculate and report the change in emissions since the start of the goal period using Equation 8.2.

## equation 8.2 calculating change in emissions since the start of the goal period*

## change in emissions since the start of the goal period (mt co e) = 2

Reporting year emissions (Mt CO e) - Emissions in the first year of the goal period (Mt CO e) 2 2

- * For users that do not treat the land sector as an offset.

For base year emissions goals and base year intensity goals, the first year (or years) of the goal period constitutes (or constitute) the base year. For baseline scenario goals, the first year (or years) of the goal period constitutes (or constitute) the start year or start period of the baseline scenario. For fixedlevel goals, the first year is the year the goal was adopted.

In addition, users with base year intensity goals should calculate and report the change in emissions intensity between the start of the goal period and the reporting year by subtracting base year emissions intensity from reporting year emissions intensity. Users treating the land sector as an offset should refer to Box 8.2 for guidance.

Users should also calculate and report cumulative emissions since the start of the goal period by summing annual emissions for every year between the start of the goal period and the reporting year, if such data exists. Gaps in annual inventory data may be filled by following relevant GHG inventory guidance on data interpolation. For additional guidance on filling data gaps, see IPCC 2006: Vol. 1, Chap. 2, 'Approaches to Data Collection.' Users should report the results of any data interpolation, methods used, and estimates of related uncertainty. When reporting interpolated data, users should differentiate interpolated data from actual GHG inventory data.

## Box 8.2   for users that treat the land sector as an offset: calculating the change in emissions since the start of the goal period

Users that treat the land sector as an offset should first calculate reporting year emissions for all sectors other than the land sector. Next, users shall calculate and report the change in net land sector emissions in the reporting year from selected landuse categories, activities, and pools and fluxes based on the chosen land-  use accounting method. Net land sector emissions are land sector emissions plus removals. (Removals are expressed as a negative number.) See Equation 8.3. Users shall separately report the change in net land sector emissions for each selected land-  use category, activity, pool, and flux, as relevant, including all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances.

## equation 8.3 net land sector emissions

## net land sector emissions (mt co e) = 2

Emissions from selected land-  use categories, activities, pools, and fluxes (Mt CO e) 2

- + Removals from selected land-  use categories, activities, pools, and fluxes (Mt CO e) 2

Depending on the accounting method being used (see Section 6.5), the change in net land sector emissions refers to:

- · for accounting relative to a base year/period : The difference between net land sector emissions in the reporting year and net land sector emissions in the base year (see Equation 8.4)
- · for accounting without reference to a base year/period or baseline scenario : The net land sector emissions in the reporting year relative to a reference case of zero  (see Equation 8.5) 1
- · for forward-  looking baseline accounting method : The difference between net land sector emissions in the reporting year and net land sector emissions in the baseline scenario in the reporting year (see Equation 8.6)

## Box 8.2   for users that treat the land sector as an offset: calculating the change in emissions since the start of the goal period (continued)

Users should calculate the change in net land sector emissions based on their chosen accounting method, using Equation 8.4, Equation 8.5, or Equation 8.6. Users should separately report the change in net land sector emissions for each selected land-  use category, activity, pool, and flux, as relevant.

## equation 8.4 accounting relative to a base year/period

## change in net land sector emissions (mt co e) = 2

Net land sector emissions in the reporting year (Mt CO e) - Net land sector emissions in the base year (Mt CO e) 2 2

## equation 8.5 accounting without reference to a base year/period or baseline scenario

## change in net land sector emissions (mt co e) = 2

Net land sector emissions in the reporting year (Mt CO e) 2

## equation 8.6 forward-  looking baseline accounting method

## change in net land sector emissions (mt co e) = 2

Net land sector emissions in the reporting year (Mt CO e) 2

- Net land sector emissions in the baseline scenario in the reporting year (Mt CO e) 2

When calculating the change in net land sector emissions using the equations above, users should minimize any risks associated with the chosen accounting method using the guidance provided in Section 6.6. Users should consistently apply any use of a natural disturbance mechanism or allowance for legacy effects.

For users applying a cap on the change in net land sector emissions not using a forward-  looking baseline:

- · If the cap amount is equal to or greater than the change in net land sector emissions, then the change in net land sector emissions should be added to reporting year emissions from all other sectors, not the cap amount.
- · If the cap amount is less than the change in net land sector emissions, then the cap amount should be added to reporting year emissions, not the change in net land sector emissions.

After the change in net land sector emissions is calculated, the next step is to calculate the change in emissions since the start of the goal period, taking into account the change in net land sector emissions (see Equation 8.7).

## equation 8.7   calculating change in emissions since the start of the goal period (for users that treat the land sector as an offset)

## change in emissions since the start of the goal period (mt co e) = 2

Reporting year emissions* (Mt CO e) - Emissions in the first year of the goal period* (Mt CO e) 2 2 + Change in net land sector emissions (Mt CO e) 2

* Excluding the land sector.

## Box 8.2   for users that treat the land sector as an offset: calculating the change in emissions since the start of the goal period (continued)

Users with base year intensity goals that treat the land sector as an offset should calculate the change in emissions intensity since the start of the goal period using Equation 8.8.

## equation 8.8   calculating change in emissions intensity since the start of the goal period (for users that treat the land sector as an offset)

## change in emissions intensity since the start of the goal period =

Reporting year emissions intensity* - Base year emissions intensity* + (Change in net land sector emissions / level of output or relevant variable in the reporting year)

- * Excluding the land sector.

<!-- image -->

## 8.6 Calculate additional emission reductions needed to achieve the goal

Understanding the additional emission reductions needed to achieve the goal, relative to progress achieved to date, is critical for designing mitigation strategies that are able to deliver the necessary quantity of reductions. Users should calculate additional emission reductions needed to achieve the goal using Equation 8.9. Users with multi-  year goals should substitute allowable emissions in the first year of the target period for 'allowable emissions' in Equation 8.9. Users with cumulative multi-  year goals should calculate allowable emissions in the first year of the target period by dividing allowable emissions for the target period by the number of years in the target period. Users that treat the land sector as an offset should refer to Box 8.3 for guidance. Users should report the additional emission reductions needed to achieve the goal in absolute and percentage terms.

Box 8.4 provides a case study of calculating the additional emission reductions needed to achieve South Africa's mining sector goal.

equation 8.9 calculating additional emission reductions needed to achieve the goal*

additional emission reductions needed to achieve the goal (mt co e) =

2 2

2 Reporting year emissions (Mt CO e) - Allowable emissions (Mt CO e)

- * For users that do not treat the land sector as an offset.

## Box 8.3   for users that treat the land sector as an offset: calculating additional emission reductions needed to achieve the goal

Users that treat the land sector as an offset should calculate additional emission reductions needed to achieve the goal using Equation 8.10, instead of Equation 8.9.

## equation 8.10   calculating additional emission reductions needed to achieve the goal (for users that treat the land sector as an offset)

## additional emission reductions needed to achieve the goal (mt co e) = 2

Reporting year emissions* (Mt CO e) - Allowable emissions* (Mt CO e) 2 2 + Change in net land sector emissions (Mt CO e)

2

- * Excluding the land sector.

## Box 8.4 calculating additional emission reductions needed to achieve south africa's mining sector goal

South Africa has a sectoral goal for the mining sector to reduce GHG emissions by 15 percent by 2015 relative to a 2006 base year. Promethium Carbon carried out an assessment during the goal period to determine whether the mining sector is on track to achieve the goal.

Base year emissions for the South African mining sector are 10.68 Mt CO e. Allowable emissions in the target year are therefore 2 9.08 Mt CO e, or 0.85 × 10.68 Mt CO e. In the reporting year of 2013, emissions within the goal boundary were reported as 2 2 10.39 Mt CO e. (The goal does not include the land sector.) To calculate the additional emission reductions needed to achieve 2 the goal, Promethium Carbon subtracted allowable emissions from reporting year emissions (10.39 Mt CO e - 9.08 Mt CO e), 2 2 resulting in a difference of 1.31 Mt CO e. Therefore, to achieve the goal, mining sector emissions have to be reduced by an 2 additional 1.31 Mt CO e relative to 2013 levels (see Figure 8.3). 2

figure 8.3 assessing progress toward south africa's mining sector goal

<!-- image -->

## accounting for anticipated use of transferable emissions units

Governments may have plans to acquire or sell transferable emissions units in the target year or period. In such cases, users should account for transferable emissions units when calculating the additional emission reductions needed to achieve the goal by using Equation 8.1 1. (Accounting for the actual use of units in the target year or period is done in Chapter 9.) Accounting for the anticipated use of units is inherently uncertain since information regarding future use of units may be unreliable and actual use of emissions units over the goal period may change. Therefore, this step should only be carried out if the use of transferable emissions units in the target year or period is predetermined, for example through existing long-  term contractual agreements. Users with baseline scenario goals that have already included the anticipated retirement and sale of units in the baseline scenario should not carry out this calculation, since doing so would lead to the double counting of emissions units.

If a jurisdiction is expected to be a net purchaser of emissions units and plans to retire them in the target year or period, fewer domestic emission reductions will be needed to achieve the goal. Conversely, if a jurisdiction is expected to be a net seller of emissions units in the target year or period, the jurisdiction will need to plan for greater domestic emission reductions to achieve the goal. Understanding the quantity of units that are expected to be sold, in particular, can help policymakers design mitigation strategies for any additional emission reductions needed to achieve the goal.

<!-- image -->

## 8.7 Assess why emissions have changed since the start of the goal period

Users should assess why emissions have changed since the start of the goal period to determine whether changes are the result of mitigation policies and actions or other factors, such as changes in economic activity. Information on why emissions have changed can inform the design of future mitigation strategies.

## 8 . 7   g u i d a n c e

If the anticipated use of transferable emissions units is accounted for, users should report the emission reductions needed to achieve the goal, taking into account the use of units.

One method to assess why emissions have changed is decomposition analysis, which may be used to determine the effect of changes in various emissions drivers-  such as economic activity, population, energy prices, and GHG intensity of energy-  on overall emissions. To carry out decomposition analysis, users should identify the relevant emissions drivers for the sectors or subsectors being analyzed, collect data on how each driver changed over the goal period, and then estimate the fraction of the total change in emissions that can be attributed to each of the drivers. Box 8.5 provides an example of decomposition analysis of CO  emissions trends from passenger cars in the 2 European Union.

equation 8.11 accounting for anticipated use of transferable emissions units

## emission reductions needed to achieve the goal, taking into account use of units (mt co e) = 2

(Emission reductions needed to achieve the goal (Mt CO e)) 2

- + (Units anticipated to be sold in the target year or target period (Mt CO e)) 2
- - (Units anticipated to be retired in the target year or target period (Mt CO e)) 2

## Box 8.5 example of decomposition analysis of co  emissions trends from passenger cars in the european union 2

Figure 8.4 illustrates a decomposition analysis that shows the effect of various emissions drivers on emissions from passenger cars in the European Union (EU) for the periods 1990-2008, 1990-2000, and 2000-2008. The individual emissions drivers are listed in the legend below the figure.

Based on the analysis, policymakers are able to understand why emissions have changed during each period. In each period, increased passenger transport activity caused the largest increase in emissions, while decreased fuel intensity caused the largest decrease in emissions. If mitigation policies were implemented to reduce fuel intensity, policymakers would have an indication that these policies contributed to the decrease in emissions over each time period. They would also be able to see that the positive effects of these policies were counteracted by increases in passenger transport activity. With this information, policymakers might focus future policies on reducing passenger transport activity.

figure 8.4 decomposition analysis of co  emissions trends from passenger cars in the eu, 1990-2008 2

<!-- image -->

<!-- image -->

A more simplified approach for understanding why energyrelated emissions have changed in a sector or subsector is to monitor the emissions drivers identified using the Kaya identity.  The Kaya identity disaggregates energy-  related 2 GHG emissions into four emissions drivers: population, GDP per capita, energy intensity of GDP, and emissions intensity of energy consumption. By separately tracking changes in each driver, users can identify which drivers have changed the most during the goal period. If one or more drivers changes significantly over time, users should try to determine whether changes are the result of mitigation policies or other factors. To understand the GHG impacts of particular mitigation policies, users should refer to the GHG Protocol Policy and Action Standard .

## 8.8 Assess whether the jurisdiction is on track to achieve the goal

After completing the accounting steps in this chapter, users should assess whether the jurisdiction is on track to achieve the goal. Achievement of the goal will ultimately be assessed using inventory data in the target year(s), as well as data on transferable emissions units and emissions and removals form the land sector. While emissions may change before the target year(s) for factors beyond the control of the jurisdiction, posing challenges to goal achievement, efforts to understand whether the jurisdiction is on track to meet the goal can inform policy planning processes and increase the likelihood of achieving the goal. Users should report the results of any progress assessments undertaken and the methods used.

To carry out an assessment of progress, users should apply Chapter 5 to develop an informational baseline scenario that includes all implemented and adopted policies and uses the reporting year as the start year. Users should then compare baseline scenario emissions in the target year(s) to allowable emissions. Any difference between the two values represents the emission reductions that will need to be achieved by additional mitigation policies and actions. See Box 8.6 for a case study on how New York City tracks progress toward its mitigation goal using an informational baseline scenario representing a BAU emissions trajectory.

Users may also compare total estimated emission reductions in the target year or period expected from key implemented and planned mitigation policies and actions to the additional emission reductions needed to meet the goal. To do so, users should estimate the ex-  ante GHG effects of key policies and actions in the target year or period using the GHG Protocol Policy and Action Standard . Then users may aggregate these effects to estimate total estimated emission reductions. 3 If total estimated emission reductions from key policies and actions are equivalent to the additional emission reductions needed to meet the goal, then users may be on track toward meeting their goal. If total estimated emission reductions are lower, users will likely need to implement additional mitigation strategies. See Box 8.7.

## Box 8.6 example of assessing progress: new york city

Figure 8.5 shows how New York City assesses progress toward its goal to reduce emissions 30 percent below 2005 levels by 2030. In 2013, the city assessed whether or not it was on track to meet its goal by developing a business-  as-  usual scenario based on 2011 data, the most recent year of emissions data (labeled 'business as usual from 2011' in the figure). Allowable emissions are represented in the figure by the dotted line labeled 'Allowable emissions (2030)' The 2011 BAU scenario shows emissions increasing up to 2030, therefore additional mitigation policies are being planned and implemented by the city to ensure that the goal is reached (represented in the figure by the colored wedges). Without this interim progress report, decision makers would lack information on the progress achieved to date toward the city's goal and the additional actions needed to achieve it.

figure 8.5  new york city's progress toward meeting its goal

<!-- image -->

## Box 8.7. tracking progress toward israel's national baseline scenario goal

Israel has adopted a goal to reduce greenhouse gas emissions by 20 percent relative to baseline scenario emissions by 2020. The Samuel Neaman Institute (SNI), in collaboration with the Israel Ministry of Environmental Protection, carried out an assessment to track Israel's progress toward meeting its goal and to determine what additional emission reductions were needed to meet the goal.

each set of measures: 10.5 Mt CO e from energy efficiency 2 measures, 2.7 Mt CO e from waste management measures, 2 2.4 Mt CO e from transportation measures, and 0.3 Mt CO e 2 2 from green buildings measures.) Based on the National Action Plan, an additional 5.9 Mt CO e of reductions were needed 2 (21.8 Mt CO e - 15.9 Mt CO e). 2 2

Goal baseline scenario emissions were estimated to be 109 million tonnes (Mt) CO e in 2020. Therefore, allowable 2 emissions in the target year were calculated to be 87.2 Mt CO e in 2020 (0.8 x109 Mt CO e), requiring emission 2 2 reductions of 21.8 Mt CO e relative to the goal baseline 2 scenario emissions (109 - 87.2 = 21.8 Mt CO e). To meet the 2 goal, Israel has implemented a National Action Plan consisting of energy efficiency, waste management, transportation, and green building measures.

To estimate the emission reductions still needed to meet the goal, SNI estimated the emission reductions expected to result from Israel's National Action Plan, which is estimated to reduce emissions by 15.9 Mt CO e in 2020, relative to 2 a baseline scenario. (GHG reductions were estimated for

A partial funding freeze has led to implementation of only some of the plan's aspects, which in and of themselves only reduce emissions by 3.5 Mt CO e by 2020, rather than by 2 15.9 Mt CO e as expected. At the same time, however, natural 2 gas has been introduced into the Israeli economy at a rate faster than estimated in the national baseline scenario, such that an additional reduction of 6.6 Mt CO e is now expected. 2 Likewise, an additional 1.8 Mt CO e reduction is now expected 2 from renewable energy generation following a complementary target of 10 percent power generation from renewables by 2020. 4 Thus, expected emission reductions now expected are 11.9 Mt CO e (3.5 + 6.6 + 1.8 Mt CO e), which is 45 percent 2 2 of the 21.8 Mt CO e emission reductions necessary to achieve 2 a 20 percent reduction from baseline scenario emissions in 2020. As a result, Israel plans to implement additional actions over the period 2014-20. See Figure 8.6.

figure 8.6 tracking progress toward israel's goal

<!-- image -->

In addition, users should track GHG-  related performance indicators by sector in order to understand past trends and the impact of future changes on emissions. Examples of performance indicators include new car fuel efficiency, installation rates for home insulation, total renewable energy capacity, and emissions intensity of energy, among others (actual change in emissions will result from the interaction of technological change and human behavior). Decomposition analysis may be useful to identify which indicators users should track, as it identifies drivers of significant emissions changes. For each indicator, users may estimate the value in the target year or period associated with meeting the goal and then regularly track progress against that value. Users may also design policies and actions that target each indicator.

## endnotes

- 1.  In the case of accounting for the land sector in the target year/ period without reference to net emissions in the base year/period or a baseline scenario, the change in net land sector emissions does not represent a true change in emissions, compared to accounting relative to base year/period emissions or forwardlooking baseline accounting, because no reference case is used for accounting. However, for simplicity this standard uses the term 'change in net land sector emissions' in relation to all three accounting methods.
- 2.  See Kaya and Yokobori 1997.
- 3.  Users should exercise caution in aggregating the results of goal assessments for different policies and actions. Estimates of GHG effects should not be directly aggregated across individual policies, actions, and projects if they affect the same emissions sources or sinks and potential interactions exist between those being aggregated. In such a case, the sum would either overcount or undercount actual emissions resulting from the combination of policies, actions, and projects. See the GHG Protocol Policy and Action Standard for more information.
- 4.  Israel Government Decision # 4450, January 2009.

<!-- image -->

9

Assessing Goal Achievement

<!-- image -->

T his  chapter  provides  guidance  on  assessing  and  reporting  whether  the mitigation goal has been achieved. Users are required to apply this chapter at the end of the target year (for single-   year goals), at the end of each year of the target period (for multi-   year goals), or at the end of the target period (for cumulative multi-  year goals).

figure 9.1 overview of steps in this chapter develop a ghg inventory and calculate target year or period emissions (section 9.1)

determine quantity of transferable emissions units retired and sold (section 9.2)

<!-- image -->

recalculate base year emissions or baseline scenario emissions, if relevant (section 9.5)

<!-- image -->

assess goal achievement (section 9.6)

<!-- image -->

<!-- image -->

calculate accountable emissions (section 9.3)

calculate emission reductions and cumulative emissions (section 9.7)

<!-- image -->

<!-- image -->

calculate accountable emissions intensity (if relevant) (section 9.4)

assess why emissions have changed since the start of the goal period (optional) (section 9.8)

table 9.1 checklist of accounting requirements in this chapter for users that assess goal achievement

| section                                                                                            | accounting requirements                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
|----------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| develop a ghg inventory and calculate target year or period emissions (section 9.1)                | • Calculate target year or period emissions by aggregating emissions from the GHG inventory for all gases and sectors that are included in the goal boundary, including out-of-jurisdiction emissions, if relevant.                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| determine quantity of transferable emissions units retired and sold (section 9.2)                  | • Do not double count, double sell, or double claim transferable emissions units. • Correct relevant registries, accounts, and reported emissions in the event that double counting is observed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| calculate accountable emissions (section 9.3)                                                      | • Calculate accountable emissions. • For users that treat the land sector as an offset: calculate the change in net land sector emissions from selected land-use categories, activities, and pools and fluxes based on the chosen land-use accounting method. • For users that have chosen to cap the quantity of land sector emissions and removals that can be applied toward the goal: apply the cap when calculating accountable emissions.                                                                                                                                                                                                                                    |
| calculate accountable emissions intensity (for users with base year intensity goals) (section 9.4) | • For users that treat the land sector as an offset: calculate the change in net land sector emissions in the reporting year from selected land-use categories, activities, and pools and fluxes based on the chosen land-use accounting method.                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| recalculate base year emissions or baseline scenario emissions (section 9.5)                       | • Recalculate: (1) base year emissions, base year emissions intensity, or baseline scenario emissions; (2) allowable emissions or emissions intensity; (3) reporting year emissions, and/or (4) target year(s) emissions if significant changes are made to methods used and/or significant error(s) in original calculations are discovered. • For users with dynamic baseline scenario goals: recalculate baseline scenario emissions by replacing forecasted values with observed values for all exogenous emissions drivers. • If base year or baseline scenario emissions are recalculated, recalculate allowable emissions (by re-applying Chapter 7) to ensure consistency. |
| assess goal achievement (section 9.6)                                                              | • Compare accountable emissions to allowable emissions in the target year(s) to assess goal achievement at the end of the goal period. • For users with base year intensity goals: compare accountable emissions.                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |

Note: Reporting requirements are listed in Chapter 11. Some goal types have no requirements and therefore are not referenced in the above box; however, there is guidance throughout the chapter, as relevant.

## 9.1 Develop a GHG inventory and calculate target year or period emissions

Users shall report goal achievement at the end of the target year (for single-  year goals), at the end of each year of the target period (for annual and average multi-  year goals), or at the end of the entire target period (for cumulative multiyear goals), when the relevant data become available.

The first step in assessing goal achievement is to develop a GHG inventory. Users without an inventory for the target year or relevant year(s) of the target period will not be able to complete the accounting and reporting steps outlined in this chapter. There may be a time lag between the GHG inventory year and the year in which the inventory is actually published. Similarly, for users with base year intensity goals, official statistics for the unit of output may not be immediately available. While relevant data may be

collected in the interim, a complete assessment of goal achievement will need to be based on a published inventory and official statistics. Section 4.1 provides guidance on developing a GHG inventory. Users shall report a complete inventory for the target year (for single-  year goals), relevant year of the target period (for annual and average multi-  year goals), or over the target period (for cumulative multi-  year goals), including out-  of-  jurisdiction emissions, if relevant.

After developing a GHG inventory, users shall calculate target year or period emissions by aggregating emissions from the GHG inventory for all gases and sectors included in the goal boundary, including out-  of-  jurisdiction emissions, if relevant.

For users that include the land sector in the goal boundary or treat it as a sectoral goal, target year or period emissions include land sector emissions and removals for all selected land-  use categories, activities, and pools and fluxes. For users that treat the land sector as an offset, target year or period year emissions do not include land sector emissions and removals. This quantity is calculated separately in Section 9.3.

Users shall report emissions in the target year (for singleyear goals), relevant year of the target period (for annual and average multi-  year goals), or over the target period (for cumulative multi-  year goals) separately by gas (in tonnes) and in tonnes of carbon dioxide equivalent (CO e). Users 2 that include the land sector in the goal boundary or treat it as a sectoral goal shall report emissions and removals separately for each selected land-  use category, activity, pool, and flux, as relevant, including all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances.

## 9.2 Determine quantity of transferable emissions units retired and sold

Users shall report the type, vintage, and quantity (in terms of Mt CO e) of transferable emissions units retired and 2 sold in the target year, relevant year of the target period, or over the target period. Units that have been applied toward the goal are retired permanently and cannot be used again by the retiring jurisdiction or any other jurisdiction.

When accounting for units, users shall not double count, double sell, or double claim units. Users with baseline scenario goals that have included the anticipated retirement and sale of units in the baseline scenario should account for the difference between the anticipated use and actual use of units in the target year, relevant year of the target period, or over the target period; otherwise double counting will result. In the event that, despite preventive measures, double counting is observed, users shall correct relevant registries, accounts, and reported emissions. Apportionment of liability for rectifying double counting (either by the seller or buyer) should be incorporated into contracts for transferable emissions units. Users should use the GHG balance sheets provided in Appendix A to report and track the retirement and sales of transferable emissions units.

## 9.3 Calculate accountable emissions

Accountable emissions are the quantity of emissions and removals that users apply toward achieving the goal, and may take into account sales and retirement of transferable emissions units and change in net land sector emissions, depending on goal design. Users shall calculate accountable emissions. Users that do not treat the land sector as an offset should use Equation 9.1 (as illustrated in Figure 9.2). Users that treat the land sector as an offset should calculate accountable emissions using the guidance provided in Box 9.1. Users with cumulative multi-  year goals should calculate accountable emissions for each year of the target period and then sum the results.

Users shall report accountable emissions in the target year (for single-  year goals), relevant year of the target period (for annual and average multi-  year goals), or over the target period (for cumulative multi-  year goals), separately by gas (in tonnes) and in tonnes of carbon dioxide equivalent (CO e). 2

Users that include the land sector in the goal boundary or treat it as a sectoral goal and have chosen to cap the quantity of land sector emissions and removals that can be applied toward the goal shall apply the cap when calculating accountable emissions. Box 8.2 provides guidance on applying a cap.

<!-- image -->

## equation 9.1 calculating accountable emissions*

## accountable emissions (mt co e) = 2

Target year emissions (Mt CO e) + Transferable emissions units sold in the target year (Mt CO e) 2 2 - Transferable emissions units retired in the target year (Mt CO e)

2

- * For users that do not treat the land sector as an offset.
- * For users that do not treat the land sector as an offset.

figure 9.2 calculating accountable emissions*

<!-- image -->

## Box 9.1 for users that treat the land sector as an offset: calculating accountable emissions

Users that treat the land sector as an offset should first calculate target year or period emissions for all sectors other than the land sector. Next, such users shall calculate and report the change in net land sector emissions from selected land-  use categories, activities, and pools and fluxes based on the chosen land-  use accounting method.

To calculate the change in net land sector emissions, users should follow the guidance provided in Box 8.2 and use Equations 8.4, 8.5, and 8.6, as relevant. When using the equations, users should substitute 'target year' values for 'reporting year' values. Users with cumulative multi-  year goals should calculate the change in net land sector emissions for each year of the target period and then sum the results. Users shall separately report the change in net land sector emissions for each selected landuse category, activity, pool, and flux, as relevant, including all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances.

Users that have chosen to cap the quantity of land sector emissions and removals that can be applied toward the goal shall apply the cap to the change in net land sector emissions. Box 8.2 provides guidance on applying a cap.

After calculating target year or period emissions and the change in net land sector emissions, users shall calculate accountable emissions by accounting for sales and retirement of transferable emissions units (see Equation 9.2).

Figure 9.3 provides an illustration of calculating accountable emissions for users that treat the land sector as an offset.

## equation 9.2 calculating accountable emissions (for users that treat the land sector as an offset)

## accountable emissions (mt co e) = 2

Target year emissions* (Mt CO e) + Transferable emissions units sold in the target year (Mt CO e) - Transferable 2 2 emissions units retired in the target year (Mt CO e) + Change in net land sector emissions (Mt CO e) 2 2

* Excluding the land sector.

## figure 9.3 calculating accountable emissions (for users that treat the land sector as an offset)

<!-- image -->

## 9.4 Calculate accountable emissions intensity (if relevant)

Users with base year intensity goals shall calculate accountable emissions intensity. Users that do not treat the land sector as an offset should use Equation 9.3. Users that treat the land sector as an offset should calculate accountable emissions intensity using Equation 9.4. Data for the level of output should come from official, peerreviewed sources that are publicly available and subject to robust QA/QC procedures. Users shall report accountable emissions intensity, the level of output in the target year, and the data sources used to determine the level of output.

## 9.5 Recalculate base year emissions or baseline scenario emissions (if relevant)

To maintain the consistency of time-  series data and enable meaningful comparisons of emissions at the end of the goal period, emissions and other values may need to be recalculated. Recalculations at the end of the goal period may be based on changes in methodology or changes in emissions drivers (for users with dynamic baseline scenario goals).

## recalculate emissions if required by methodological changes

Before assessing goal achievement, users shall recalculate (1) base year emissions, base year emissions intensity, or

## equation 9.3 calculating accountable emissions intensity*

accountable emissions intensity  =

Accountable emissions (Mt CO e) 2

Level of output (or relevant variable) in the target year

- * For users that do not treat the land sector as an offset.

## equation 9.4 calculating accountable emissions intensity (for users that treat the land sector as an offset)

accountable emissions intensity  =

Accountable emissions (Mt CO e) + Change in net land sector emissions (Mt CO e) 2 2

Level of output (or relevant variable) in the target year baseline scenario emissions; (2) allowable emissions or emissions intensity; (3) reporting year emissions; and (4) target year or period emissions if:

- · Significant changes are made to methods, including:
- · Inventory calculation methods
- · Emissions projection models
- · Improvements in the accuracy of emission factors or activity data
- · GWP values
- · Significant change to the value of the unit of output in the base year (for users with base year intensity goals)
- · Significant errors in original calculations are discovered

For guidance on recalculating emissions necessitated by methodological changes, see Section 8.4.

Users shall report any emissions recalculations, including recalculations of base year emissions, base year emissions intensity, baseline scenario emissions, and allowable emissions or emissions intensity, and the recalculated values alongside the original values.

## recalculate emissions if required by changes in emissions drivers (for users with dynamic baseline scenario goals)

In addition to recalculating baseline scenario emissions because of the changes outlined above, users with dynamic baseline scenario goals shall recalculate baseline scenario emissions by replacing forecasted values with observed values for all exogenous emissions drivers.

<!-- image -->

Exogenous emissions drivers are emissions drivers unaffected by mitigation policies or actions implemented to meet the goal. Examples of exogenous drivers may include GDP, population, international energy prices, weather, and structural changes in economic sectors.

Recalculating dynamic baseline scenarios allows users to isolate changes in emissions resulting from mitigation efforts as compared to changes in exogenous drivers. If baseline scenario emissions are recalculated, users shall also recalculate allowable emissions (by reapplying Chapter 7) to ensure consistency.

Users shall report dynamic baseline scenario recalculations made during the goal period, which drivers were updated, updated values alongside original values, and recalculated emissions alongside the original values. Users shall report any recalculations of allowable emissions and recalculated allowable emissions alongside the original value.

## 9.6 Assess goal achievement

To assess goal achievement at the end of the goal period, users shall compare accountable emissions to allowable emissions in the target year or relevant year(s) of the target period. Users with base year intensity goals shall compare accountable emissions intensity to allowable emissions intensity in the target year or relevant year(s) of the target period. Table 9.2 illustrates how to compare accountable emissions to allowable emissions to determine whether the goal was achieved.

Users shall report the difference between accountable emissions (or emissions intensity) and allowable emissions (or emissions intensity), and whether the goal was achieved or not achieved. Users with separate goals for

table 9.2 assessing goal achievement

| if . . .                                      | then . . .           |
|-----------------------------------------------|----------------------|
| accountable emissions - < allowable emissions | Goal is achieved     |
| accountable emissions > allowable emissions   | Goal is not achieved |

in-  jurisdiction and out-  of-  jurisdiction emissions shall separately report goal achievement for each goal.

If accountable emissions and allowable emissions are similar values in the target year(s), but not the same value, the difference between the values could be a result of uncertainties in the data rather than real-  world differences.

Users should compare the two values by rounding each to appropriate levels of significant figures to avoid overstating the precision of the results.

Box 9.2 provides a case study of assessing goal achievement for the city of Seattle.

## Box 9.2 assessing goal achievement for the city of seattle

The U.S. city of Seattle adopted a goal to reduce emissions by 7 percent by 2012 relative to a 1990 base year. Base year emissions are 6.13 Mt CO e. In which case, allowable emissions in the target year (2012) are 5.70 Mt CO e, or 0.93 × 6.13 Mt CO e. 2 2 2

The Stockholm Environment Institute-  U.S. (SEI) carried out an ex-  post assessment of Seattle's goal to determine whether or not it was achieved. The city's 2012 GHG inventory indicated that target year emissions were 6.13 Mt CO e. Furthermore, the city's public 2 electric utility retired 0.091 Mt CO e of offset credits in 2012. Based on this information, SEI calculated accountable emissions to be 2 6.04 Mt CO e by subtracting retired units from emissions within the goal boundary (6.13-  0.091 = 6.04 Mt CO e). 2 2

Accountable emissions exceeded allowable emissions by 0.34 Mt CO e, and, thus, Seattle's goal was not achieved. Figure 9.4 2 presents the results of the analysis.

figure 9.4 assessing goal achievement for the city of seattle

<!-- image -->

## 9.7 Calculate emission reductions and cumulative emissions (optional)

In addition to the steps above, users should carry out the following calculations of emission reductions and cumulative emissions over the goal period to better understand progress toward the goal.

- · Calculate and report emission reductions achieved relative to base year or baseline scenario emissions by subtracting base year emissions from accountable emissions or by subtracting accountable emissions from baseline scenario emissions in the target year or period, respectively.

target year or period. If annual emissions data are not available, users may interpolate data as needed. User should follow relevant GHG inventory guidance for data interpolations, for example as provided in IPCC 2006. Users should report input data used for calculating cumulative emissions, separated by actual and interpolated emissions data.

- · For base year intensity goals, calculate and report the reduction in emissions intensity relative to base year emissions intensity by subtracting base year emissions intensity from emissions intensity in the target year or period.
- · Calculate and report cumulative emissions over the goal period by summing accountable emissions for all years between the start of the goal period and the
- · Calculate and report emission reductions relative to an informational baseline scenario, if developed.

<!-- image -->

## 9.8 Assess why emissions have changed since the start of the goal period (optional)

When assessing goal achievement, users should assess why emissions have changed over the goal period using qualitative and quantitative methods, such as regression analysis or decomposition analysis. Section 8.7 provides guidance on decomposition analysis. See Box 9.3 for a case study that describes why emissions in Seattle changed over the goal period.

It should be noted that just because a goal has been achieved does not necessarily mean that the jurisdiction's emissions trajectory has been transformed over a longer period. It will be important to look at underlying policies and actions put in place to meet the goal and evaluate their sustainability and the implied long-  term rates of decarbonization across sectors.

<!-- image -->

## Box 9.3 understanding why the city of seattle's emissions changed over the goal period

The U.S. city of Seattle adopted a goal to reduce emissions by 7 percent by 2012 relative to a 1990 base year. The Stockholm Environment Institute-  U.S. (SEI) carried out an ex-  post evaluation to assess whether the city achieved the goal. While the goal was not achieved (as described in Box 9.2), total emissions in the goal boundary did decline by 1 percent between the base year (1990) and the target year (2012), and per capita emissions declined by 19 percent.

SEI performed a decomposition analysis to find out why emissions decreased. After developing a citywide GHG inventory, SEI identified the most significant drivers of changes in emissions over the period. Emission increases were largely attributed to population and economic growth, as well as growth in use of ozone depleting substitutes, while emission decreases were attributed to a wide variety of factors, including:

- · A decrease in carbon intensity of Seattle City Light's electricity, as the utility moved away from coal and gas in its supply portfolio
- · More efficient cars and trucks
- · Building efficiency, including smaller dwellings and fuel switching
- · Increased efficiency of air travel

Each of these factors led to reductions in emissions of at least 200,000 t CO e by 2012 compared to baseline emissions. 2

Figure 9.5 shows the full results of the decomposition analysis.

figure 9.5 contribution of various factors to the decrease in ghg emissions between 1990 and 2012

<!-- image -->

10

Verification

<!-- image -->

T his  chapter  provides  guidance  on  how  to  carry  out  verification  of  the mitigation goal assessment report. While verification is not a requirement, carrying out verification helps give the user and stakeholders confidence in the results of the report.

## 10.1 Introduction

Verification is the process of assessing whether the reported information is relevant, complete, accurate, consistent, transparent, and without material misstatements, thereby providing a level of assurance or confidence in the findings. Verifiers assess reported information against agreed criteria, following a rigorous and systematic process. The verification process involves an evaluation of whether the principles of GHG accounting have been met and a review of users' justifications for chosen accounting methods and assumptions. Verification should be a cooperative, iterative process that provides feedback and enables users to improve accounting practices.

Assurance can be provided before, during, or after the goal period. Depending on when it is provided, it may be referred to as validation or verification. While the terminology differs, the approach for validation and verification is essentially the same:

- · validation provides assurance of goal design, base year emissions or emissions intensity, baseline scenario emissions, and allowable emissions, among other accounting steps
- · verification provides assurance of progress assessments undertaken during the goal period and assessments of goal achievement undertaken at the end of the goal period

For the purposes of this standard, the term 'verification' encompasses both verification and validation.

Verification is also related to quality assurance and quality control. Users should use any combination of verification and QA/QC, depending on stated objectives and circumstances. For additional guidance on verification and QA/QC, see IPCC 2006: Vol. 1, Chap. 6, 'Quality Assurance/ Quality Control and Verification.'

Users should decide whether and what type of verification to pursue depending on stated objectives. To meet objectives such as external reporting, verification may be required, while to meet objectives such as internal decision making, verification may not be necessary.

Users should verify the goal assessment. Users shall report whether the goal assessment was verified, and if so the type of verification performed (first party or third party), the relevant competencies of the verifier(s), and the opinion issued by the verifier.

## 10.2 Benefits of verification

Verification can provide a variety of benefits, including:

- · Increased confidence that the reported information can provide a robust basis for the design of GHG mitigation strategies and other decision-  making needs
- · Enhanced internal accounting and reporting practices, such as data collection, estimation methods, and internal reporting systems, and facilitation of learning and knowledge transfer
- · Improved efficiency in subsequent processes for updating GHG mitigation strategies and when planning or implementing further mitigation goals
- · Increased confidence in the results reported by other entities using the Mitigation Goal Standard , promoting a credible representation of the efforts undertaken by different jurisdictions participating in a collective goal
- · Greater stakeholder trust in the reported results

## 10.3 Key concepts

Table 10.1 includes key concepts related to assurance and verification.

- · Increased confidence in progress reported toward the goal

<!-- image -->

## table 10.1 key concepts

| concept                           | description and examples                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
|-----------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| assertion                         | A statement by the user on goal progress or achievement. The assertion is presented to the verifier performing assurance. • Example of an assertion: 'The mitigation has been achieved. The achievement of the goal is assessed in conformity with the GHG Protocol Mitigation Goal Standard.'                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| assessment report                 | An assessment report, completed by the user, documents all required accounting steps and reporting requirements are recorded.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| assurance opinion                 | The results of the verification of the user's assertion; that is, the estimated reduction in GHG emissions. If the verifier determines that a conclusion cannot be expressed, the opinion should cite the reason. • See Table 10.3 for examples of assurance opinions.                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| assurance standards               | Standards or requirements used by verifiers, which determine how the assurance process and the verification steps are performed to be able to formulate an assurance opinion. • Example: ISO 14064-3 Specification with Guidance for the Validation and Verification of Greenhouse Gas Assertions.                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| evidence                          | Data sources, estimation methods, and documentation used to assess progress and that support the subject matter of the reporting entity's assertion. Evidence should be sufficient in quantity and appropriate in quality. Examples include: GHG inventory data and methods, data sources for socioeconomic data used to develop baseline scenarios, internal audit reports on goal progress.                                                                                                                                                                                                                                                                                                                                            |
| materiality                       | Central to a verifier's activities is assessing the risks of material discrepancies related to the goal assessment report. Material discrepancies are differences between information reported by the user and information that would result from the proper application of the Mitigation Goal Standard's requirements and guidance. A material discrepancy occurs when individual or aggregate errors, omissions, and misrepresentations have an impact on the goal assessment that is significant enough to influence the decisions by stakeholders. A materiality threshold is the quantitative level of material discrepancy (for example, five percent) above which an assertion is considered in nonconformity with the standard. |
| Mitigation Goal Standard criteria | Requirements and guidance of the Mitigation Goal Standard against which the reported results of the goal will be assessed. Table 2.4 of the Mitigation Goal Standard summarizes the main requirements of the standard.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| subject matter                    | The subject matter of the verification is the accounting and reporting results and supporting information included in the assessment report. The type of verification performed will determine which subject matter(s) should be assessed. See Section 10.4.                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| verification                      | Process that results in an assurance opinion on whether an assertion is in conformity with the Mitigation Goal Standard's requirements.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |

## 10.4 Subject matter relevant to the Mitigation Goal Standard

The goal assessment report is the ultimate subject matter assessed in the assurance process. To verify that these results represent a true and fair account of progress achieved toward the goal in conformity with the Mitigation Goal Standard , the verifier assesses whether all the requirements of the standard are met. Each step in the standard constitutes a subject matter, and the verifier needs to check that the information reported meets the requirements and that the methods and assumptions used are reasonable. The main steps, or subject matter, in the Mitigation Goal Standard are:

- · Designing the mitigation goal, including defining the goal boundary
- · Choice of base year and estimation of base year emissions, as relevant
- · Development of baseline scenario and estimation of baseline scenario emissions, as relevant
- · Accounting for the land sector
- · Calculating allowable emissions in the target year or period
- · Assessing progress during the goal period
- · Assessing goal achievement

See Table 2.4 in Chapter 2 for the full list of accounting requirements. Box 10.1 provides an illustration of the verification procedures for land sector accounting.

## 10.5 Types of verification

First-  party verifiers or third-  party verifiers may be used. Both first- and third-  party verifiers should follow similar procedures and processes. Table 10.2 provides descriptions of both types of verification.

Verification could also be done by a partner organization or by the party receiving the data, rather than by an internal or independent party.

Assurance provided by a third-  party verifier offers a higher degree of objectivity and independence, and is therefore likely to increase the credibility of the goal assessment for external stakeholders. First-  party verification can provide confidence in the reliability of the goal assessment, and it can be a useful learning experience for users prior to commissioning third-  party verification. However, firstparty verification can also be susceptible to threats to the independence of the verification. Typical threats include allegiance to an employing entity, pending renewal of funding for a goal based on reported progress, promotion of an employee conditional on goal progress, or political pressure and other conflicts of interest between the user and the verifier. These threats should be assessed throughout the verification process. Users receiving firstparty verification should report how potential conflicts of interest were avoided during the verification process.

<!-- image -->

## Box 10.1 example of verification for land sector accounting

GHG accounting methodologies for the land sector are often complex and include many different data inputs. This box illustrates how a verifier should carry out an assurance assessment of land-  sector accounting based on the requirements of this standard.

## land sector accounting and the mitigation goal :

Verifiers should focus on whether the user has justified the treatment of the land sector vis-  à-  vis the user's mitigation goal. If the sector is being used as an offset, verification should establish whether the user has provided a qualitative or quantitative description of how land-  use accounting is expected to affect the overall goal.

land-  based and activity-  based accounting : Verifiers should determine whether a user has provided sufficient rationale for choosing land-  based or activity-  based accounting.

inclusion of land uses and activities : The critical element here is completeness. Verifiers should focus on identification and minimization of anthropogenic fluxes not included in accounting. This may be accomplished by comparing the results of land-  use accounting to GHG inventory data for emissions and removals from the land sector to determine which fluxes, if any, are included in the inventory but missing from accounting toward the goal. Independent data (data not used to calculate land sector emissions) on anthropogenic emissions and removals, where available, may also be used to check the completeness of the accounting. Verification should highlight any potential inconsistencies between total anthropogenic fluxes (all anthropogenic fluxes 'seen' by the atmosphere) and those included in land sector accounting.

land sector accounting method : Verifiers should address the accuracy, consistency, and transparency of the accounting method used for the land sector. As a first step, verification should establish that a user has provided a sufficient description and justification of its chosen method. For example, has the user included explanations of how the land-  use base year or baseline scenario was calculated, including the data, methods, models, and assumptions used? Verification should also determine whether the pools and fluxes included in the base year or baseline scenario are the same as those included in the land-  use accounting. For users using land-  based accounting, verification should ensure that the lands included in the base year or baseline scenario are the same lands included in accounting, and that the managed land proxy, if used, is applied consistently. For activity-  based accounting, verification should ensure that the activities included in the base year or baseline scenario are consistent with those included in the goal assessment.

Verification should further assess whether the methods used achieve the stated objectives. For example, if a user has stated that it wishes to smooth out the effects of interannual variability on accounting, verification would check to see that a base period, rather than a base year, was used, and that it was of sufficient length. To the extent possible, verification should assess the accuracy of the calculations themselves. The more information a user provides regarding justification and calculations, the more verification can help strengthen and streamline the accounting process.

natural disturbance provision : Verification should focus on whether natural disturbances have been treated consistently in the base year or baseline scenario and accounting. Verification should also check that the natural disturbance accounting and reporting requirements have been satisfied, including whether the user demonstrated that the disturbance was beyond the control of, and not materially influenced by, the jurisdiction; whether the lands subject to the disturbance were identified; and whether removals from lands identified as having been subjected to a natural disturbance are excluded from accounting until they balance the excluded emissions, or a new goal has been adopted taking account of the condition of the land on which the disturbance occurred.

allowance for legacy effects : Verification should consider whether allowance for legacy effects has sought to remove background trends from accounting, such as trends related to forest age-  class structure, so that the effects of mitigation can be revealed in an unbiased manner. In particular, verification should identify any departure from background trends in order to increase the estimated mitigation effect. Verification should also ensure that the methods used in estimating the allowance for legacy effects are consistent with methods used in the greenhouse gas inventory calculation.

## table 10.2 types of verification

| type of verification     | description                                                                                                                                                                                                                                             |
|--------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| first-party verification | Internal verification performed by independent person(s) from within the reporting entity. Example: person(s) from a different department in an organization not involved in the process of planning, implementing, and reporting on a mitigation goal. |
| third-party verification | Assurance performed by person(s) from an independent entity. Examples: independent accounting, engineering, or analysis organization; accredited third-party verification body.                                                                         |

## 10.6 Levels of assurance

## 10.7 Competencies of verifiers

The level of assurance refers to the degree of confidence stakeholders can have in the goal assessment results. There are two levels of assurance: limited and reasonable. Limited assurance provides a 'negative opinion' that states that no errors were detected. Reasonable assurance provides a 'positive opinion' that states that all assertions are valid. Table 10.3 provides examples of limited and reasonable assurance opinions.

The level of assurance requested by the user will determine the rigor of the verification process and the amount of evidence required. The highest level of assurance that can be provided is a reasonable level of assurance. Absolute assurance is typically not provided since it is not feasible to test 100 percent of the inputs to the goal assessment.

Selecting a competent verifier is critical for the assurance opinion to have the credibility needed to support user's and stakeholders' needs. A competent verifier has the following characteristics:

- · Assurance expertise and verification experience
- · Knowledge and experience of GHG accounting and reporting, GHG inventory methods and assessments, and mitigation goal assessments, including baseline scenario development, accounting for transferable emissions units, and land sector accounting
- · Knowledge of the reporting entity's activities
- · Ability to assess the emission sources included in the goal boundary and the magnitude of potential errors, omissions, and misrepresentations

## table 10.3 levels of assurance

| assurance opinion    | nature of opinion                                                                                                                                                                                                                                                           |
|----------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| limited assurance    | Negative opinion • Example: 'Based on our verification, we are not aware of any material modifications that should be made to the reporting entity's assertion that the mitigation goal was achieved and is in conformity with the GHG Protocol Mitigation Goal Standard .' |
| reasonable assurance | Positive opinion • Example: 'In our opinion, the reporting entity's assertion that the mitigation goal was achieved is fairly stated, in all material respects, and is in conformity with the GHG Protocol Mitigation Goal Standard .'                                      |

<!-- image -->

- · Ability to assess baseline scenario emissions (if relevant), including the selected modeling approach, drivers, and assumptions, as well as the magnitude of potential errors, omissions, and misrepresentations
- · Credibility, independence, and the professional skepticism required to challenge data, methods, and other information

## 10.8 Verification process

Many elements have to be considered as part of the systematic process for providing assurance that an assertion of goal progress is in conformity with the Mitigation Goal Standard . The following sections describe the main elements of the verification process, assuming that the user has already selected a type and a level of assurance that suit the stated objectives and has identified a competent verifier.

## timing of the verification

The timing of verification depends on the subject matter and needs of the user. For example, verification can be performed before the implementation of the goal when the user, as part of its planning activities, wants to obtain confidence that a goal is likely to achieve a certain level of emissions in the target year or period. Alternatively, assurance can be performed before a user's public release of an interim or final goal assessment report to provide an update on progress and inform a potential adjustment of course or to conclude on the final performance and effectiveness of a goal. This allows for any material issues to be corrected before the release of the assurance opinion (or revised opinion) and the assertion of goal achievement. Verification can also be performed during the goal period to assess progress achieved to date and additional reductions needed to meet the goal.

The work should be initiated long enough before the planned date of implementation of the goal, or the release date of the assessment report, so that the verification is useful in improving the assessment of progress, when necessary. The time required for verification is dependent on the nature and complexity of the subject matter and the level of assurance selected.

## preparing for verification

Preparing for verification is a matter of ensuring that the evidence the verifier needs is easily accessible. The type of evidence and documentation that the verifier will request depends on the subject matter, the type of goal considered, and the type and level of assurance being sought. To ensure that the assurance evidence is available, it is helpful to document the process of assessing goal progress.

Prior to initiating verification, the reporting entity should ensure that the following are prepared and available to the verifier:

- · The entity's written assertion
- · The goal assessment report and a description of the tools, methods, and data used
- · Sufficient and appropriate evidence, such as goal planning documentation, decisions and supporting rationale, interim monitoring reports, internal evaluations and performance reports, and peer reviews

## steps of verification

Verification, whether performed by a first- or thirdparty verifier providing limited or reasonable assurance, features several common steps:

- 1.  planning and scoping: The verifier will initiate preparations around the assurance plan, which identifies the level and objectives of the assurance, the criteria and scope (subject matter and materials to be verified), the materiality threshold, and the activities and schedule the verifier implements to assess the assertion against the Mitigation Goal Standard criteria.
- 2.  identifying data, methods, and assumptions: This step involves identifying GHG sources included in the goal boundary and the associated assumptions, methods, and socioeconomic data used for estimating the GHG emissions from those sources in the GHG inventory, base year, baseline scenario, and land-  use accounting approach, as relevant.
- 3.  verification: Next, the verifier will carry out activities as planned in the schedule, such as collecting and analyzing the evidence and appraising it against the Mitigation Goal Standard 's principles and requirements. The verification process generally includes the following steps:
- · Determine whether the requirements in the standard are correctly interpreted by the user and the goal assessment is in conformance with the accounting and reporting requirements.
- · Assess the relevance, completeness, consistency, transparency, and accuracy of the data/information provided, as well as the reliability and credibility of data sources.
- · Where multiple methodological choices, equations, or parameters are available to the user, determine whether adequate justification for the selected choice has been provided.
- · Check whether all the assumptions and data used are clearly disclosed along with references and sources, and whether justifications are provided (where required) that are reasonable and supported by evidence.
- · Identify issues that require further elaboration, research, or analysis.
- o complete these steps, verifications should T consider the following activities:
- · Interviewing relevant stakeholders and experts
- · Reviewing relevant documents, including available goal assessment reports or studies of other similar policies or actions
- · Cross-  checking information provided by the assessment entity with independent sources other than those used; for example, through independent research
- · Other standard auditing techniques and procedures
- 4.  assessing materiality: This step includes determining if the verification findings support the user's assertion on goal progress. Depending on the level of assurance and materiality threshold agreed, the verifier assesses whether the information reported by the entity is in conformity with the Mitigation Goal Standard criteria or if there is any material discrepancy in the information reported.

<!-- image -->

## 5.  forming and reporting an assurance opinion:

Once the verifier has made an assessment against the stated objectives and criteria of the assurance plan, an assurance opinion is formed, which depends on the level of assurance agreed. As part of the assurance opinion, the verifier should report the following:

- · A description of the mitigation goal
- · A reference to the user's assertion included in the goal assessment report
- · A description of the assurance process
- · A list of the Mitigation Goal Standard 's principles and requirements
- · A description of the user's and the verifier's responsibilities
- · Whether the verification was performed by a first or third party
- · The verification standard used to perform the verification; for example, ISO 14064-3: Specification with Guidance for the Validation and Verification of Greenhouse Gas Assertions
- · How any potential conflicts of interest were avoided in the case of first-  party assurance
- · A summary of the work performed
- · The level of assurance achieved (limited or reasonable); if the verifier determines that an opinion cannot be expressed, a statement of the reason
- · The materiality threshold
- · Any additional details regarding the verifier's conclusion, including details on any discrepancies noted or issues encountered in performing the verification
- · Practical suggestions to help rectify any discrepancies

<!-- image -->

11

Reporting

## 11.1 Required information

Users shall report at least the following information about the mitigation goal assessed and the methodology used to carry out the assessment.

<!-- image -->

T his chapter provides reporting requirements that outline which information  shall    be  publicly  reported  in  order  for  a  goal  assessment to  be  in  conformance  with  the  GHG  Protocol Mitigation  Goal  Standard . The relevance of each reporting requirement depends on the user's goal type and the stage of goal implementation. This chapter also lists optional reporting information that users should report if relevant. A sample reporting template is available at www.ghgprotocol.org/mitigation-  goal-  standard.

At the end of the goal period, users shall develop and make publicly available a goal assessment report that provides evidence of the goal design and evidence on progress achieved or whether the goal has been achieved. The goal assessment report should be completed as soon as possible after the reporting year, target year, or relevant year of the target period (given time lags related to availability of data, especially GHG inventory data). Users should specify when and where reports are published and how the public can obtain copies.

## chapter 4: designing a mitigation goal

- · The GWP values used
- · The percentage of total inventory emissions that is included in the goal boundary in the base year or start year of the baseline scenario, including the land sector, if relevant
- · Geographic areas included in the goal boundary
- · Any geographic areas excluded from the goal boundary
- · Sectors and subsectors included in the goal boundary, including definitions of covered sectors and subsectors
- · Any sectors excluded from the goal boundary, with justification
- · Any out-  of-  sector emissions included in the sectoral goal boundary (for users with sectoral goals)
- · How emissions and removals from the land sector are treated in the goal (included in the goal boundary, treated as a sectoral goal, treated as an offset, or not accounted for)

- · For subnational jurisdictions: whether the goal covers out-  of-  jurisdiction emissions and, if so, which out-  ofjurisdiction emissions are included and excluded from the goal boundary
- · Greenhouse gases included in the goal boundary
- · If all seven Kyoto Protocol gases are not included in the goal boundary, justification for why certain gases are excluded.
- · Mitigation goal type
- · If a base year intensity goal is chosen, the unit of variable
- · If a baseline scenario goal is chosen, whether the baseline scenario is static or dynamic
- · If a dynamic baseline scenario goal is chosen, the baseline scenario recalculation policy at the start of the goal period, including which exogenous drivers will trigger a recalculation
- · The base year or base period
- · Whether the goal is a single-  year goal or a multi-  year goal
- · If a multi-  year goal is chosen, whether the goal is an average, annual, or cumulative multi-  year goal
- · If single-  year is chosen, the target year
- · If multi-  year goal is chosen, the target period
- · The length of the goal period
- · If   oupled short-  term and long-  term goals are chosen, c the length of the goal period for each goal
- · Any limit on the quantity of transferable emissions units that may be applied toward the goal, if defined, and the anticipated amount of units to be used to meet the goal
- · The maximum and anticipated amount of units to be used from time periods before the goal ('banked' units)
- · Anticipated issuance of crediting scheme units that will be valid for use by another Party, if known
- · Anticipated net transfers of allowance units between emissions trading systems, if known
- · Types of transferable emissions units eligible to be applied toward the goal
- · Vintages of transferable emissions units eligible to be applied toward the goal
- · Mechanisms in place to prevent double counting of transferable emissions units
- · The goal level
- · If separate goals are chosen for in-  jurisdiction emissions and out-  of-  jurisdiction emissions (or for different scopes), separate goal levels for in-  jurisdiction and outof-  jurisdiction emissions (or for different scopes)

## chapter 5:   estimating Base year or Baseline scenario emissions

## For users with base year emissions goals and base year intensity goals:

- · Complete GHG inventory for the base year or base period and the calculation methods used
- · Base year emissions separately by gas (in tonnes) and in tonnes of carbon dioxide equivalent (CO e), as well as 2 the sources of data and calculation methods used
- · The percentage of total inventory emissions that is included in the goal boundary in the base year
- · For users including the land sector in the goal boundary or as a sectoral goal :
- · Emissions, removals, and net emissions (emissions plus removals) for all selected land-  use categories, activities, and pools and fluxes in the base year
- · All calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances
- · Net emissions from each elected land-  use category or activity
- · For users treating the land sector as an offset and accounting for the sector relative to a base year/period:
- · Net base year emissions for the land sector
- · All calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances
- · Net emissions from each elected land-  use category or activity

## For users with base year intensity goals:

- · Base year emissions intensity, the level of output in the base year, and data sources used
- · Base year emissions intensity for in-  jurisdiction emissions and out-  of-  jurisdiction emissions (for users with separate goals for in-  jurisdiction emissions and outof-  jurisdiction emissions)

## For users with baseline scenario goals:

- · Baseline scenario emissions in the target year or period
- · For users including the land sector in the goal boundary or as a sectoral goal, net baseline scenario emissions for the sector in the target year or period
- · Baseline scenario emissions for in-  jurisdiction emissions and out-  of-  jurisdiction emissions (for users with separate goals for in-  jurisdiction emissions and out-  of-  jurisdiction emissions)

- · The percentage of total inventory emissions that is included in the goal boundary in the start year
- · For users that treat the land sector as an offset and apply a forward-  looking baseline accounting method:
- · Net baseline scenario land sector emissions in the target year(s)
- · All calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances.
- · The model used to develop the goal baseline scenario
- · Time frame for the baseline scenario, including the start year or start period
- · Emissions within the goal boundary in the start year or start period, the complete GHG inventory for the start year or period, and the data sources and calculation methods used
- · Start year or start period emissions for in-  jurisdiction emissions and out-  of-  jurisdiction emissions (for users with separate goals for in-  jurisdiction emissions and outof-  jurisdiction emissions)
- · Assumptions for key emissions drivers included in the baseline scenario
- · All sources of data used to develop the baseline scenario, including data for key drivers (projected and historical), emission factors, and assumptions
- · Justify the choice of whether to develop new baseline data and assumptions or to use published baseline data and assumptions
- · The cutoff year for the inclusion of policies-  that is, the year after which no new policies or actions are included in the baseline scenario
- · Key policies and actions included in the baseline scenario
- · Any additional methods and assumptions used to estimate the effects of key included policies and actions on emissions
- · Any significant policies excluded from the baseline scenario, with justification
- · Key emissions drivers included in the baseline scenario
- · A quantitative estimate or qualitative description of the uncertainty of the results, as well as the range of results from sensitivity analysis for key parameters and assumptions

<!-- image -->

## chapter 6: accounting for the land sector

- · The chosen land sector accounting approach: landbased accounting or activity-  based accounting
- · Any use of a managed land proxy that has been adopted including the definition of 'managed land' and the locations of managed and unmanaged lands
- · Land sector categories or activities included in land sector accounting
- · Carbon pools, GHG fluxes, and categories/activities included within elected land sector categories or suites of activities
- · If any specific category, subcategory, or activity is accounted for with a different approach from the rest of the sector, the rationale for the treating the category, subcategory, or activity differently; the new accounting method chosen and reasons for choosing it; and the potential impacts of the different approach on the land sector and goal accounting.
- · Percentage of total inventory emissions from the land sector that is included in the goal boundary in the base year or period or baseline scenario, as relevant
- · Whether harvested wood products, including wood and paper products, are included in accounting
- · The chosen land sector accounting method(s): relative to a base year/period; without reference to a base year/ period or baseline; or relative to a forward-  looking baseline
- · Potential risks associated with the chosen accounting method and how those risks are minimized
- · If part or all of a land category or a land-  use activity from the goal boundary is excluded to minimize potential risks, the exclusion, the reason for the exclusion, and the reason for any alternative accounting approach chosen
- · If a cap on removals is adopted, the level of the cap
- · If the goal level is adjusted, the new level of the goal
- · For the following users, any changes resulting from recalculations:
- · Users that change the land sector accounting approach during the goal period
- · Users that add a land category, subcategory, or activity to accounting, or change the treatment of an existing land category, subcategory, or activity
- · Users that revise the goal level to compensate for non-  additional emissions or emission reductions
- · For users that change the land sector accounting approach during the goal period, the reasons for changing
- approaches and the quantitative and qualitative effects on land sector accounting and overall goal accounting
- · Any changes to included land sector categories, activities, carbon pools, or GHG fluxes that significantly affect net land sector emissions
- · Any changes to the treatment of the land sector or the goal level (to compensate for non-  additional emissions or removals)

## For users adopting a natural disturbance mechanism:

- · All lands subject to the natural disturbance mechanism, including their georeferenced location, year, and types of disturbances
- · How annual emissions resulting from disturbances and the subsequent removals in those areas are estimated
- · Demonstration that no land-  use change has occurred on lands for which the mechanism is applied, and explanation of the methods and criteria for identifying any future land-  use changes on those land areas during the goal period
- · Demonstration that the occurrences were beyond the control of, and not materially influenced by, the user during the goal period, by demonstrating practicable efforts to prevent, manage, or control the occurrences that led to the application of the mechanism
- · Demonstration of efforts taken to rehabilitate, where practicable, the land for which the mechanism applied

<!-- image -->

- · Demonstration that emissions associated with salvage logging on forestland subject to natural disturbance will not be/were not excluded from accounting

## chapter 7:   calculating allowable emissions in the target year(s)

- · Allowable emissions in the target year (for single-  year goals), in each year of the target period (for annual or average multi-  year goals), or over the target period (for cumulative multi-  year goals)
- · Allowable emissions for in-  jurisdiction emissions and out-  of-  jurisdiction emissions (for users with separate goals for in-  jurisdiction emissions and out-  of-  jurisdiction emissions)
- · For users with base year intensity goals, estimated level of output in the target year(s) and the data sources or method used to estimate it

## For users with base year intensity goals:

- · Allowable emissions intensity in the target year or in each year of the target period
- · Allowable emissions intensity for in-  jurisdiction emissions intensity and out-  of-  jurisdiction emissions intensity (for users with separate goals for in-  jurisdiction emissions and out-  of-  jurisdiction emissions)

<!-- image -->

## chapter 8:   assessing progress during the goal period

## For users that assess progress during the goal period:

- · Complete inventory for the reporting year, including outof-  jurisdiction emissions, if relevant
- · Reporting year emissions by gas (in tonnes) and in tonnes of carbon dioxide equivalent (CO e) 2
- · For users that include the land sector in the goal boundary or treat it as a sectoral goal, land sector emissions and removals separately for each selected land-  use category, activity, pool, and flux, as relevant, including all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances
- · For users that treat the land sector as an offset, the change in net land-  use emissions in the reporting year, separately reported for each selected land-  use category, activity, pool, and flux, as relevant, including all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances
- · For users with base year intensity goals, reporting year emissions intensity, the level of output in the reporting year, and the data sources used to determine the level of output
- · Any emissions recalculations, including recalculations of base year emissions, base year emissions intensity, baseline scenario emissions, and allowable emissions or emissions intensity, and the recalculated values alongside the original values
- · For users with dynamic baseline scenarios:
- · Any recalculations made during the goal period, which drivers were updated, updated values alongside original values, and recalculated emissions alongside the original values
- · Any recalculations of allowable emissions and recalculated allowable emissions alongside the original values
- · Any revisions to the goal boundary and any changes to the goal type, goal level, or a change from a singleyear to a multi-  year goal, and any recalculations made, including recalculated and original values

## chapter 9: assessing goal achievement

- · Goal achievement at the end of the target year (for single-  year goals), at the end of each year of the target period (for annual and average multi-  year goals), or at the end of the entire target period (for cumulative multi-  year goals)
- · For users with separate goals for in-  jurisdiction emissions and out-  of-  jurisdiction emissions: separately report goal achievement for in-  jurisdiction emissions and out-  of-  jurisdiction emissions
- · Complete GHG inventory for the target year (for singleyear goals), relevant year of the target period (for annual multi-  year and average multi-  year goals), or over the target period (for cumulative multi-  year goals), including out-  of-  jurisdiction emissions, if relevant
- · Target year emissions (for single-  year goals), relevant year of the target period (for annual and average multiyear goals), or over the target period (for cumulative multi-  year goals) separately by gas (in tonnes) and in tonnes of carbon dioxide equivalent (CO e) 2
- · Accountable emissions in the target year (for singleyear goals), relevant year of the target period (for annual and average multi-  year goals), or over the target period (for cumulative multi-  year goals) separately by gas (in tonnes) and in tonnes of carbon dioxide equivalent (CO e) 2
- · The type, vintage, and quantity (in terms of tonnes of carbon dioxide equivalent) of transferable emissions units retired and sold in the target year, relevant year of the target period, or over the target period
- · For users that include the land sector in the goal boundary or treat it as a sectoral goal, emissions and removals separately for each selected land-  use category, activity, pool, and flux, as relevant, including all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances
- · For users that treat the land sector as an offset, the change in net land-  use emissions in the target year(s), separately reported for each selected land-  use category, activity, pool, and flux, as relevant, including all calculation methods used, including any use of special accounting provisions, such as those associated with natural disturbances
- · For those users that treat the land sector as an offset:
- · The change in net land sector emissions in the target year(s) and the calculation methods used
- · For users with base year intensity goals: accountable emissions intensity, the level of output in the target year or period, and the data sources used to determine the level of output
- · Any emissions recalculations, including recalculations of base year emissions, base year emissions intensity, baseline scenario emissions, and allowable emissions or emissions intensity, and the recalculated values alongside the original values
- · Any dynamic baseline scenario recalculations made during the goal period, which drivers were updated, updated values alongside original values, and recalculated emissions alongside the original values
- · Any recalculations of allowable emissions and recalculated allowable emissions alongside the original value
- · The difference between accountable emissions (or emissions intensity) and allowable emissions (or emissions intensity)
- · Whether the goal was achieved or not achieved (separately for in-  jurisdiction emissions goal and out-  of-  jurisdiction emissions goal, if relevant)

<!-- image -->

## chapter 10: verification

- · Whether the goal assessment was verified, and if so, the type of verification performed (first party or third party), the relevant competencies of the verifier(s), and the opinion issued by the verifier

<!-- image -->

## 11.2 Optional reporting information

Users should report the following information, where relevant:

## chapter 4: designing a mitigation goal

- · A rationale for any excluded territories and an indication of the magnitude of emissions (in Mt CO e) associated 2 with the excluded territories
- · If sector definitions are used that deviate from the most recent IPCC Guidelines for National Greenhouse Gas Inventories , an explanation for why IPCC defined sectors were not used and information on the alternative sector definitions, including an explanation of how non-  IPCC sector definitions correspond to IPCC definitions
- · The goal level for non-  land sectors and the goal level with the effect of the land sector included

## chapter 5:   estimating Base year or Baseline scenario emissions

- · Goal baseline scenario emissions by sector
- · Informational baseline scenarios, if developed
- · At the end of the goal period, projected trends in emissions drivers (developed at the start of the goal period) alongside the actual trend in those same emissions drivers (compiled at the end of the goal period)
- · Range of plausible baseline scenarios, if developed, and where the goal baseline scenario is located within the range

## chapter 6: accounting for the land sector

- · How land-  use data uncertainty is addressed

## chapter 7:   calculating allowable emissions in the target year(s)

- · Emission reductions associated with achieving the goal
- · Any milestones set

## chapter 8:   assessing progress during the goal period

- · Change in emissions between the first year (or years) of the goal period and the reporting year
- · For users with base year intensity goals, change in emissions intensity between the start of the goal period and the reporting year
- · Additional emission reductions needed to achieve the goal
- · Cumulative emissions since the start of the goal period
- · Results of any data interpolation, methods used, and estimates of related uncertainty

## chapter 9: assessing goal achievement

- · The retirement and sales of transferable emissions units in both the target year or period as well as throughout the goal period
- · Emission reductions achieved relative to base year emissions or baseline scenario emissions
- · For users with base year intensity goals, reduction in emissions intensity relative to base year emissions intensity
- · Cumulative emissions over the goal period
- · Emission reductions relative to informational baseline scenario emissions, if developed

## chapter 10: verification

- · For users receiving first-  party verification, how potential conflicts of interest were avoided during the verification process
- · What plan or action the party being verified will put in place to address any discrepancies or fulfill the recommendations

Appendix

## Sample GHG Balance Sheet

This appendix provides a sample GHG balance sheet for a multi-  year base year emissions goal.

<!-- image -->

|                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           | 1                                                                                                                                                         | 2                                                                                                                                                         | 3                                                                                                                                                         | 4                                                                                                                                                         | 5                                                                                                                                                         | 6                                                                                                                                                         |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           | 2010                                                                                                                                                      | target period                                                                                                                                             | target period                                                                                                                                             | target period                                                                                                                                             | target period                                                                                                                                             | cumulative emissions=                                                                                                                                     |
| ghg balance sheet for mitigation goals accounting                                                                                                         | ghg balance sheet for mitigation goals accounting                                                                                                         | ghg balance sheet for mitigation goals accounting                                                                                                         | (Base year)                                                                                                                                               | 2014                                                                                                                                                      | 2015                                                                                                                                                      | 2016                                                                                                                                                      | 2017                                                                                                                                                      | (2) + (3) + (4) + (5)                                                                                                                                     |
| emissions and removals within the goal boundary (mt co 2 e)                                                                                               | emissions and removals within the goal boundary (mt co 2 e)                                                                                               | emissions and removals within the goal boundary (mt co 2 e)                                                                                               | emissions and removals within the goal boundary (mt co 2 e)                                                                                               | emissions and removals within the goal boundary (mt co 2 e)                                                                                               | emissions and removals within the goal boundary (mt co 2 e)                                                                                               | emissions and removals within the goal boundary (mt co 2 e)                                                                                               | emissions and removals within the goal boundary (mt co 2 e)                                                                                               | emissions and removals within the goal boundary (mt co 2 e)                                                                                               |
| a                                                                                                                                                         | total emissions (excluding the land sector)                                                                                                               | total emissions (excluding the land sector)                                                                                                               | 1,000                                                                                                                                                     | 900                                                                                                                                                       |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | In-jurisdiction emissions (scope 1)                                                                                                                       | In-jurisdiction emissions (scope 1)                                                                                                                       | 800                                                                                                                                                       | 700                                                                                                                                                       |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Out-of-jurisdiction emissions (scope 2 and/or 3)                                                                                                          | Out-of-jurisdiction emissions (scope 2 and/or 3)                                                                                                          | 200                                                                                                                                                       | 200                                                                                                                                                       |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
| B                                                                                                                                                         | net land sector emissions                                                                                                                                 | net land sector emissions                                                                                                                                 | -100                                                                                                                                                      | -150                                                                                                                                                      |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Total land sector emissions                                                                                                                               | Total land sector emissions                                                                                                                               | 50                                                                                                                                                        | 50                                                                                                                                                        |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | In-jurisdiction emissions (scope 1)                                                                                                                       | In-jurisdiction emissions (scope 1)                                                                                                                       | 50                                                                                                                                                        | 50                                                                                                                                                        |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Out-of-jurisdiction emissions (scope 2 and/or 3)                                                                                                          | Out-of-jurisdiction emissions (scope 2 and/or 3)                                                                                                          | 0                                                                                                                                                         | 0                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Total land sector removals                                                                                                                                | Total land sector removals                                                                                                                                | -150                                                                                                                                                      | -200                                                                                                                                                      |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | In-jurisdiction removals (scope 1)                                                                                                                        | In-jurisdiction removals (scope 1)                                                                                                                        | -150                                                                                                                                                      | -200                                                                                                                                                      |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Out-of-jurisdiction removals (scope 2 and/or 3)                                                                                                           | Out-of-jurisdiction removals (scope 2 and/or 3)                                                                                                           | 0                                                                                                                                                         | 0                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
| transferable emissions units (mt co 2 e)                                                                                                                  | transferable emissions units (mt co 2 e)                                                                                                                  | transferable emissions units (mt co 2 e)                                                                                                                  | transferable emissions units (mt co 2 e)                                                                                                                  | transferable emissions units (mt co 2 e)                                                                                                                  | transferable emissions units (mt co 2 e)                                                                                                                  | transferable emissions units (mt co 2 e)                                                                                                                  | transferable emissions units (mt co 2 e)                                                                                                                  | transferable emissions units (mt co 2 e)                                                                                                                  |
| c                                                                                                                                                         | total credits retired                                                                                                                                     | total credits retired                                                                                                                                     | 0                                                                                                                                                         | 50                                                                                                                                                        |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Credits retired                                                                                                                                           | Type A (e.g., CDM)                                                                                                                                        | 0                                                                                                                                                         | 30                                                                                                                                                        |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | by type                                                                                                                                                   | Type B                                                                                                                                                    | 0                                                                                                                                                         | 20                                                                                                                                                        |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
| d                                                                                                                                                         | total credits sold                                                                                                                                        | total credits sold                                                                                                                                        | 0                                                                                                                                                         | 10                                                                                                                                                        |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Credits sold                                                                                                                                              | Type A (e.g., CDM)                                                                                                                                        | 0                                                                                                                                                         | 5                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | by type                                                                                                                                                   | Type B                                                                                                                                                    | 0                                                                                                                                                         | 5                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
| e                                                                                                                                                         | total allowances                                                                                                                                          | retired                                                                                                                                                   | 0                                                                                                                                                         | 10                                                                                                                                                        |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Allowances                                                                                                                                                | Type A (e.g., EUA)                                                                                                                                        | 0                                                                                                                                                         | 5                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | retired by type                                                                                                                                           | Type B                                                                                                                                                    | 0                                                                                                                                                         | 5                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
| f                                                                                                                                                         | total allowances sold                                                                                                                                     | total allowances sold                                                                                                                                     | 0                                                                                                                                                         | 5                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | Allowances sold                                                                                                                                           | Type A (e.g., EUA)                                                                                                                                        | 0                                                                                                                                                         | 3                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
|                                                                                                                                                           | by type                                                                                                                                                   | Type B                                                                                                                                                    | 0                                                                                                                                                         | 2                                                                                                                                                         |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
| change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) | change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) | change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) | change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) | change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) | change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) | change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) | change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) | change in net land sector emissions (mt co 2 e) (for users that treat the land sector as an offset and accounting relative to base year/period emissions) |
| g                                                                                                                                                         | (B) reporting year - (B) base year                                                                                                                        | (B) reporting year - (B) base year                                                                                                                        | n/a*                                                                                                                                                      | -50                                                                                                                                                       |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
| accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      | accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      | accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      | accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      | accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      | accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      | accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      | accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      | accountable emissions (mt co 2 e) (for all users except those treating the land sector as an offset)                                                      |
| h                                                                                                                                                         | (A) + (B) - (C) + (D) - (E) + (F)                                                                                                                         | (A) + (B) - (C) + (D) - (E) + (F)                                                                                                                         | n/a*                                                                                                                                                      | 705                                                                                                                                                       |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |
| accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     | accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     | accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     | accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     | accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     | accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     | accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     | accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     | accountable emissions (mt co 2 e) (for users that treat the land sector as an offset)                                                                     |
| i                                                                                                                                                         | (A) - (C) + (D) - (E) + (F) + (G)                                                                                                                         | (A) - (C) + (D) - (E) + (F) + (G)                                                                                                                         | n/a*                                                                                                                                                      | 805                                                                                                                                                       |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |                                                                                                                                                           |

- * This calculation does not take place in the base year.

## Abbreviations and Acronyms

| AAU    | assigned amount unit                          | GPC                                                 | Global Protocol for Community-Scale                       |
|--------|-----------------------------------------------|-----------------------------------------------------|-----------------------------------------------------------|
| AEO    | Annual Energy Outlook                         |                                                     | Greenhouse Gas Emission Inventories                       |
| AFOLU  | agriculture, forestry, and other land use     | GWP                                                 | global warming potential                                  |
| AR5    | Fifth Assessment Report                       | HFCs                                                | hydrofluorocarbons                                        |
| BAU    | business as usual                             | ICLEI                                               | International Council for Local Environmental Initiatives |
| BECCS  | bioenergy with carbon capture and storage     | IEA                                                 | International Energy Agency                               |
| Btu    | British thermal unit                          | IMF                                                 | International Monetary Fund                               |
| C40    | Cities Climate Leadership Group               | IPCC                                                | Intergovernmental Panel on Climate Change                 |
| CDM    | Clean Development Mechanism                   | IPPU                                                | industrial processes and product use                      |
| CDR    | carbon dioxide removal                        | IRENA                                               | International Renewable Energy Agency                     |
| CER    | certified emission reduction                  | ISIC                                                | International Standard Industrial Classification          |
| CGE    | computable general equilibrium                | ITL                                                 | International Transaction Log                             |
| CH 4   | methane                                       | JI                                                  | Joint Implementation                                      |
| CITL   | Community Independent Transaction Log         | LEAP                                                | Long-range Energy Alternatives Planning System            |
| CITSS  | Compliance Instrument Tracking System Service | LEDS                                                | low emissions development strategies                      |
| CO 2   | carbon dioxide                                | LULUCF                                              | land use, land-use change, and forestry                   |
| CO 2 e | carbon dioxide equivalent                     | MAED                                                | Model for Analysis of Energy Demand                       |
| DDM    | Dynamic Dispatch Model                        | MAPS                                                | mitigation action plans and scenarios                     |
| EFDB   | Emission Factor Database                      | MARKAL                                              | Market Allocation model                                   |
| EIA    | U.S. Energy Information Administration        | MEDEE                                               | Long-term Demand Prospective Model                        |
| EPRI   | Electric Power Research Institute             | Mt CO e million tonnes of carbon dioxide equivalent | Mt CO e million tonnes of carbon dioxide equivalent       |
| ERU    | emission reduction unit                       | NAICS                                               | North American Industrial Classification Standard         |
| E3MC   | Energy-Economy-Environment Model for Canada   | NAMA                                                | nationally appropriate mitigation action                  |
| ETS    | emission trading system                       | NEMS                                                | National Energy Modeling System                           |
| EU     | European Union                                | NF 3                                                | nitrogen trifluoride                                      |
| EUA    | European Union allowance                      | NGO                                                 |                                                           |
| GDP    | gross domestic product                        |                                                     | nongovernmental organization                              |
| GHG    | greenhouse gas                                | N 2 O NZU                                           | nitrous oxide New Zealand unit                            |

<!-- image -->

| OECD       | Organisation for Economic Co-operation and Development                           | SNI UN        | Samuel Neaman Institute                                                   |
|------------|----------------------------------------------------------------------------------|---------------|---------------------------------------------------------------------------|
| PFCs       | perfluorocarbons                                                                 | UN FAO        | Food and Agriculture Organization                                         |
| POLES      | Prospective Outlook on Long-term Energy Systems                                  |               | of the United Nations                                                     |
| QA         | quality assurance                                                                | UNFCCC United | Nations Framework                                                         |
| QC         | quality control                                                                  | VER           | Convention on voluntary emission reduction or verified emission reduction |
| QELRC      | quantified emission limitation or reduction commitment                           | WBCSD         | World Business Council for Sustainable Development                        |
| REDD+ RGGI | Reducing Emissions from Deforestation and Forest Degradation Regional Greenhouse | WEM           | World Energy Model                                                        |
| SEI        | Stockholm Environment Institute-U.S.                                             | WEPS+         | World Energy Projection System Plus                                       |
|            |                                                                                  | WRI           | World Resources Institute                                                 |
| SF 6       | sulfur hexafluoride                                                              |               |                                                                           |
| SGM        | Second Generation Model                                                          | WTI           | West Texas Intermediate                                                   |

<!-- image -->

| Accountable emissions                                     | The quantity of emissions and removals that users apply toward achieving the goal. This value is compared to allowable emissions to assess goal achievement.                                                                                                                                                              |
|-----------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Activity-based accounting                                 | Land-use accounting approach that assesses land-use emissions and removals based on select land-use activities.                                                                                                                                                                                                           |
| Activity data                                             | A quantitative measure of a level of activity that results in GHG emissions. Activity data is multiplied by an emission factor to estimate the GHG emissions associated with a process or an operation.                                                                                                                   |
| Additional emission reductions needed to achieve the goal | The difference between reporting year emissions and allowable emissions in the target year or first year of the target period.                                                                                                                                                                                            |
| Adopted policies and actions                              | Policies and actions for which an official government decision has been made and there is a clear commitment to proceed with implementation, but that have not yet begun to be implemented (for example, a law has been passed but regulations to implement law have not yet been established or are not being enforced). |
| Allowable emissions                                       | The maximum quantity of emissions that may be emitted in the target year, year of the target period, or over the entire target period that is consistent with achieving the mitigation goal.                                                                                                                              |
| Allowance                                                 | Generated by emissions trading programs and issued to emitting entities to be traded or used to comply with emissions obligation.                                                                                                                                                                                         |
| Annual multi-year goal                                    | Mitigation goal that aims to reduce, or control the increase of, annual emissions by a specified amount each year over a target period relative to a base year or baseline scenario.                                                                                                                                      |
| Average multi-year goal                                   | Mitigation goal that aims to reduce, or control the increase of, annual emissions by an average amount each year over a target period relative to a base year or baseline scenario.                                                                                                                                       |
| Base period                                               | An average of multiple years of historical data against which emissions are compared over time.                                                                                                                                                                                                                           |
| Base period emissions                                     | GHG emissions and removals within the goal boundary in the base period.                                                                                                                                                                                                                                                   |
| Base year                                                 | A specific year of historical data against which emissions are compared over time.                                                                                                                                                                                                                                        |
| Base year emissions                                       | Emissions and removals in the base year for all gases and sectors included in the goal boundary, including out-of-jurisdiction emissions, if relevant.                                                                                                                                                                    |
| Base year emissions goal                                  | Mitigation goal that aims to reduce, or control the increase of, emissions relative to an emissions level in a historical base year.                                                                                                                                                                                      |
| Base year intensity goal                                  | Mitigation goal that aims to reduce emissions intensity (emissions per unit of another variable, typically GDP) by a specified quantity relative to a historical base year.                                                                                                                                               |

## Baseline scenario

## Baseline scenario assumption

## Baseline scenario emissions

## Baseline scenario goal

## Business-  as-  usual (BAU) scenario

Cap

## Change in net land sector emissions

## CO 2 equivalent (CO e) 2

Cumulative emissions

Cumulative multi-  year goal

Decomposition analysis

Double counting

## Dynamic baseline scenario

## Dynamic baseline scenario goal

Emission factor

Emission reduction

A reference case that represents future events or conditions most likely to occur in the absence of activities taken to meet the mitigation goal.

Numerical value that defines how an emissions driver in a baseline scenario is most likely to change over a defined future time period.

An estimate of GHG emissions or removals associated with a baseline scenario.

Mitigation goal that aims to reduce emissions by a specified quantity relative to a projected emissions baseline scenario.

A reference case that represents future events or conditions most likely to occur as a result of implemented and adopted policies and actions.

A cap limits the quantity of land sector emissions or removals that can be accounted for toward the achievement of the mitigation goal.

Depending on the accounting method chosen, the change in net land sector emissions refers to either (1) the difference between net land sector emissions in the reporting year and net land sector emissions in the base year (for the net-  net accounting method), (2) net land sector emissions in the reporting year relative to a reference case of zero (for gross-  net accounting method), or (3) the difference between net land sector emissions in the reporting year and net land sector emissions in the baseline scenario in the reporting year (for a forward-  looking baseline accounting method).

The universal unit of measurement to indicate the global warming potential (GWP) of each greenhouse gas, expressed in terms of the GWP of 1 unit of carbon dioxide. It is used to evaluate releasing (or avoiding releasing) different greenhouse gases against a common basis.

Sum of annual emissions over a defined time period.

Multi-  year mitigation goal that aims to limit cumulative emissions to a fixed absolute amount over a target period.

Method for determining the effect of changes in various emissions drivers on year-  toyear changes in overall emissions levels.

Occurs when the same transferable emissions unit is counted toward the mitigation goal of more than one jurisdiction. Double counting includes double claiming, double selling, and double issuance of units.

Baseline scenario that is recalculated during the goal period based on changes in emissions drivers.

Mitigation goal that aims to reduce, or control the increase of, emissions relative to a dynamic baseline scenario.

A factor that converts activity data into GHG emissions data.

Reduction in greenhouse emissions relative to a base year or baseline scenario.

| Emission reductions associated with achieving the goal   | The difference between emissions in the first year of the goal period and allowable emissions in the target year or period.                                                                                                                                                                                                                                                                                                            |
|----------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Emissions                                                | The release of greenhouse gases into the atmosphere. For simplicity, this standard often uses the term 'emissions' as shorthand for 'emissions and removals.'                                                                                                                                                                                                                                                                          |
| Emissions drivers                                        | Socioeconomic parameters that cause emissions to grow or decline, such as economic activity, population, and energy prices.                                                                                                                                                                                                                                                                                                            |
| Emissions estimation method                              | An equation, algorithm, or model that quantitatively estimates GHG emissions. For example, a simple emissions estimation method is the following equation: GHG emissions = emission factor × activity data. An emissions estimation method is comprised of parameters.                                                                                                                                                                 |
| Emissions intensity                                      | Greenhouse gas emissions per unit of another variable, such as economic output (GDP), energy (MWh), or population.                                                                                                                                                                                                                                                                                                                     |
| Emissions level                                          | The quantity of greenhouse gas emissions in a given year.                                                                                                                                                                                                                                                                                                                                                                              |
| Emissions source                                         | Any process, activity or mechanism that releases a greenhouse gas into the atmosphere.                                                                                                                                                                                                                                                                                                                                                 |
| Ex-ante assessment                                       | Prospective analysis of expected future events.                                                                                                                                                                                                                                                                                                                                                                                        |
| Ex-post assessment                                       | Retrospective analysis of past events.                                                                                                                                                                                                                                                                                                                                                                                                 |
| Fixed-level goal                                         | A mitigation goal that aims to reduce, or limit the increase of, emissions to an absolute emissions level in a target year.                                                                                                                                                                                                                                                                                                            |
| Flux                                                     | Includes both transfers of carbon from one carbon pool to another and non-CO 2 emissions arising from activities such as prescribed burning and manure management.                                                                                                                                                                                                                                                                     |
| Geographic boundary                                      | The physical territory included in the goal boundary.                                                                                                                                                                                                                                                                                                                                                                                  |
| Global warming potential (GWP)                           | A factor describing the radiative forcing impact (degree of harm to the atmosphere) of 1 unit of a given GHG relative to 1 unit of CO 2 .                                                                                                                                                                                                                                                                                              |
| Goal assessment                                          | The evaluation of progress toward a mitigation goal, which can include the evaluation of goal achievement at the end of the goal period.                                                                                                                                                                                                                                                                                               |
| Goal baseline scenario                                   | A baseline scenario used to set a baseline scenario goal and assess goal achievement.                                                                                                                                                                                                                                                                                                                                                  |
| Goal boundary                                            | The greenhouse gases, sectors, geographic area, and in-jurisdiction and out-of- jurisdiction emissions covered by a mitigation goal.                                                                                                                                                                                                                                                                                                   |
| Goal level                                               | The quantity of emission reductions or emissions and removals within the goal boundary in the target year or period that the jurisdiction commits to achieving.                                                                                                                                                                                                                                                                        |
| Goal period                                              | The definition of the goal period depends on the goal type. For base year emissions goals and base year intensity goals, it is the time between the base year and the target year or period. For baseline scenario goals, it is the time between the start year of the baseline scenario and target year or period. For fixed-level goals, it is the time between the year in which the goal is adopted and the target year or period. |

| Goal type                        | The way the goal is framed. This standard covers four goal types: base year emissions goals, fixed-level goals, base year intensity goals, and baseline scenario goals.                                                                                                                                                                                                                                                                                                                                               |
|----------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Greenhouse gases (GHGs)          | For the purposes of this standard, GHGs are the seven gases covered by the Kyoto Protocol: carbon dioxide (CO 2 ), methane (CH 4 ), nitrous oxide (N 2 O), hydrofluorocarbons (HFCs), perfluorocarbons (PFCs), sulfur hexafluoride (SF 6 ), and nitrogen trifluoride (NF 3                                                                                                                                                                                                                                            |
| Greenhouse gas inventory         | A quantified list of a jurisdiction's GHG emissions and removals by source, sector, and gas.                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Implemented policies and actions | Policies and actions currently in effect, as evidenced by one or more of the following: (a) relevant legislation or regulation is in force; (b) one or more voluntary agreements have been established and are in force; (c) financial resources have been allocated; and (d) human resources have been mobilized.                                                                                                                                                                                                    |
| Informational baseline scenario  | A baseline scenario used to inform goal design and mitigation assessments, assess progress, and meet reporting requirements. Informational baseline scenarios are not used to set a baseline scenario goal or assess goal achievement (see goal baseline scenario).                                                                                                                                                                                                                                                   |
| In-jurisdiction emissions        | Emissions from sources located within a jurisdiction's geopolitical boundary.                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Jurisdiction                     | The geographic territory over which a government exercises political authority.                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Land-based accounting            | Land-use accounting approach that assesses land sector emissions and removals based on select land-use categories.                                                                                                                                                                                                                                                                                                                                                                                                    |
| Land sector                      | Refers to the following land-use categories: forestland, cropland, grassland, wetland, and settlement, consistent with Volume 4 of the IPCC Guidelines for National Greenhouse Gas Inventories (2006). It includes emissions and removals from land in agricultural production and grazing lands/grasslands. However, it does not cover accounting for GHG fluxes from on-farm agricultural activities, such as manure management or fossil fuel- based emissions from on-farm use of electricity, heat, or vehicles. |
| Land sector accounting approach  | The way land sector emissions and removals are accounted for toward the goal-from either select land-use categories or select land-use activities. There are two accounting approaches for the land sector: land-based accounting and activity-based accounting.                                                                                                                                                                                                                                                      |
| Land sector accounting method    | Used to assess emissions and removals within each selected land-use category or activity. Land-use accounting methods include the net-net (accounting relative to base year/period emissions), forward-looking baseline, and gross-net methods (accounting without reference to base year/period or baseline scenario emissions).                                                                                                                                                                                     |
| Leakage                          | Increase in emissions outside of the mitigation goal boundary that result as a consequence of activities, such as policies, actions, and projects, implemented to meet the goal.                                                                                                                                                                                                                                                                                                                                      |
| Legacy effect                    | When past management has an effect on carbon stocks that cause stocks to vary even in the presence of sustainable management.                                                                                                                                                                                                                                                                                                                                                                                         |

| Managed land proxy            | Estimates of emissions and removals on managed lands that are used as a proxy to remove non-anthropogenic fluxes as part of the land-based accounting approach.                                                                                                                                                                                                  |
|-------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Materiality                   | Concept that individual or aggregation of errors, omissions, or misrepresentations could affect the goal assessment and mistakenly influence decision making.                                                                                                                                                                                                    |
| Mitigation goal               | Commitment to reduce, or limit the increase of, GHG emissions or emissions intensity by a specified quantity, to be achieved by a future date.                                                                                                                                                                                                                   |
| Multi-year goal               | A goal designed to achieve emission reductions or reductions in intensity over several years of a target period.                                                                                                                                                                                                                                                 |
| Net GHG emissions             | The aggregation of GHG emissions and removals.                                                                                                                                                                                                                                                                                                                   |
| Offset credit                 | Represents the reduction, removal, or avoidance of GHG emissions from a specific project that is used to compensate for GHG emissions occurring elsewhere. One offset credit represents 1 tonne of CO 2 equivalent.                                                                                                                                              |
| Out-of-jurisdiction emissions | Emissions from sources located outside of a jurisdiction's geopolitical boundary that occur as a consequence of activities within that boundary.                                                                                                                                                                                                                 |
| Parameter                     | A variable that is part of an emissions estimation equation. For example, 'emissions per kWh of electricity' and 'quantity of electricity supplied' are both parameters in the equation '0.5 kg CO 2 e/kWh of electricity × 100 kWh of electricity supplied = 50 kg CO 2 e.'                                                                                     |
| Parameter uncertainty         | Uncertainty regarding whether a parameter value used in the assessment accurately represents the true value of a parameter.                                                                                                                                                                                                                                      |
| Peer-reviewed                 | Literature that has been subject to independent evaluation by experts in the same field prior to publication.                                                                                                                                                                                                                                                    |
| Planned policies and actions  | Policy/action options that are under discussion and have a realistic chance of being adopted and implemented in the future but that have not yet been adopted.                                                                                                                                                                                                   |
| Policy and action             | An interventions taken or mandated by a government, institution, or other entity, which may include laws, regulations, and standards; taxes, charges, subsidies and incentives; information instruments; voluntary agreements; implementation of new technologies, processes, or practices; and public or private sector financing and investment, among others. |
| Pool                          | A reservoir in the land sector containing carbon.                                                                                                                                                                                                                                                                                                                |
| Removal                       | Removal of GHG emissions from the atmosphere through sequestration or absorption; for example, when carbon dioxide is absorbed by forests and other vegetation during photosynthesis.                                                                                                                                                                            |
| Reporting year                | The year of emissions data that is used to assess goal progress or achievement.                                                                                                                                                                                                                                                                                  |
| Reporting year emissions      | Emissions and removals in the reporting year for all gases and sectors included in the goal boundary, including out-of-jurisdiction emissions, if relevant.                                                                                                                                                                                                      |
| Retired                       | Refers to a unit used by the purchaser and no longer valid for future sale.                                                                                                                                                                                                                                                                                      |

| Sensitivity analysis          | Assesses the extent to which the outputs of an emissions modeling approach- projected activity data, projected emission factors, and projected emissions-vary according to model inputs-assumptions, projected values for key emissions drivers, and methodological choices.                                                                                                                            |
|-------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Single-year goal              | A goal designed to achieve reduction in emissions or emissions intensity by a single target year.                                                                                                                                                                                                                                                                                                       |
| Start period                  | The first years of a baseline scenario.                                                                                                                                                                                                                                                                                                                                                                 |
| Start period emissions        | Average emissions level within the goal boundary in the start period.                                                                                                                                                                                                                                                                                                                                   |
| Start year                    | The first year of a baseline scenario.                                                                                                                                                                                                                                                                                                                                                                  |
| Start year emissions          | Emissions within the goal boundary in the start year.                                                                                                                                                                                                                                                                                                                                                   |
| Static baseline scenario      | A baseline scenario fixed throughout the goal period and not recalculated based on changes in emissions drivers.                                                                                                                                                                                                                                                                                        |
| Static baseline scenario goal | Mitigation goal that aims to reduce, or control the increase of, emissions relative to a static baseline scenario.                                                                                                                                                                                                                                                                                      |
| Target period                 | For multi-year goals, a period of several consecutive years over which the mitigation goal is to be achieved, which are the last years of the goal period.                                                                                                                                                                                                                                              |
| Target year                   | For single-year goals, the year by which the goal is to be met, which is the last year of the goal period.                                                                                                                                                                                                                                                                                              |
| Target year emissions         | Emissions and removals in the target year(s) for all gases and sectors included in the goal boundary, including out-of-jurisdiction emissions, if relevant.                                                                                                                                                                                                                                             |
| Transferable emissions units  | Emissions allowances and offset credits from market mechanisms outside the goal boundary that are used toward meeting a mitigation goal or are sold to other jurisdictions.                                                                                                                                                                                                                             |
| Treatment of the land sector  | The way emissions and removals from the land sector are included or not included in the goal boundary. This standard has four land sector treatment options: (1) include in the goal boundary; (2) treat as separate sectoral goal; (3) treat as offset; or (4) do not account for the land sector.                                                                                                     |
| Uncertainty                   | (1) Quantitative definition: Measurement that characterizes the dispersion of values that could reasonably be attributed to a parameter. (2) Qualitative definition: A general and imprecise term that refers to the lack of certainty in data and methodology choices, such as the application of nonrepresentative factors or methods, incomplete data on sources and sinks, or lack of transparency. |

## References

Allen, Myles, David Frame, Chris Huntingford, Chris Jones, Jason Lowe, Malte Meinshausen, and Nicolai Meinshausen. 2009. 'Warming Caused by Cumulative Carbon Emissions towards the Trillionth Tonne.' Nature 458: 1 163-66. Accessible at http://www.nature.com/nature/journal/v458/ n7242/full/nature08019.html.

Clapp, Christa, Katia Karousakis, Barbara Buchner, and Jean Chateau. 2009. 'National and Sectoral GHG Mitigation Potential: A Comparison across Models.' Paris: Organisation for Economic Co-  operation and Development (OECD). Accessible at http://www.oecd.org/env/cc/44050733.pdf.

Clapp, Christa, and Andrew Prag. 2012. 'Emissions Baselines for National Climate Policy: Options for Improving Transparency and Consistency.' Paris: Organisation for Economic Co-  operation and Development (OECD). Accessible at http://www.oecd.org/env/cc/CCXG%20(2012)3%20 National%20Baselines.pdf.

The Climate Registry. 2013. General Reporting Protocol: Version 2.0 . Accessible at http://www.theclimateregistry.org/ downloads/2013/03/TCR\_GRP\_Version\_2.0.pdf.

Committee on Climate Change (CCC). 2008. 'Building a LowCarbon Economy-  The UK's Contribution to Tackling Climate Change.' London: Stationary Office. Accessible at http:// archive.theccc.org.uk/aws3/TSO-  ClimateChange.pdf.

Estrada, M., D. Lee, B. Murray, R. O'Sullivan, J. Penman, and C. Streck. 2014. Land Use in a Future Climate Agreement . Prepared with support from cooperative agreement # SLMAQM-13-  CA-1128 with U.S. Department of State.

European Environment Agency (EEA). 201 1. Greenhouse Gas Emissions in Europe: A Retrospective Analysis for the Period 1990-2008 . Copenhagen: EEA. Accessible at http:// www.eea.europa.eu/publications/ghg-  retrospective-  trendanalysis-1990-2008.

Farías, Carlos Benavides, and Manuel Díaz Romero. 2014. Selection of Long-  Range Energy Systems Modelling Platforms: The MAPS Chile Experience . Mitigation Action Plans and Scenarios (MAPS). Cape Town, South Africa: MAPS. Accessible at http://www.mapsprogramme.org/wp-  content/ uploads/Paper\_Selection-  of-  energy-  modelling-  platforms-  theMAPS-  Chile-  experience.pdf.

Fransen, Taryn, Priya Barua, and Davida Wood. 2014. 'Climate Policy Implementation Tracking Framework.' WRI Working Paper. Washington, DC: World Resources Institute. Accessible at http://www.openclimatenetwork.org.

GHG Protocol Corporate Standard . 2004. Washington, DC: World Resources Institute and World Business Council for Sustainable Development. Accessible at http://www. ghgprotocol.org/standards/corporate-  standard.

GHG Protocol for Project Accounting . 2005. Washington, DC: World Resources Institute and World Business Council for Sustainable Development. Accessible at http://www. ghgprotocol.org/standards/project-  protocol.

GHG Protocol Global Protocol for Community-  Scale Greenhouse Gas Emission Inventories (GPC). 2014. Washington, DC: World Resources Institute, C40 Cities Climate Leadership Group, and ICLEI. Accessible at http:// www.ghgprotocol.org/city-  accounting.

GHG Protocol Policy and Action Standard . 2014. Washington, DC: World Resources Institute. Accessible at http://www. ghgprotocol.org/policy-  and-  action-  standard.

Gillenwater, Michael. 2012. 'What Is Wrong with 'Real' Carbon Offsets?' Greenhouse Gas Measurement and Management 2, no. 4: 167-70. Accessible at http://www.tandfonline.com/ doi/abs/10.1080/20430779.2013.781879#.UcnLYDSR96w.

Global Protocol for Communities (GPC). 2014. Washington, DC: World Resources Institute, C40 Cities Climate Leadership Group, and ICLEI. Accessible at http://www.ghgprotocol.org/ city-  accounting.

Intergovernmental Panel on Climate Change (IPCC). 2000. Good Practice Guidance and Uncertainty Management in National Greenhouse Gas Inventories . Accessible at http:// www.ipcc-  nggip.iges.or.jp/public/gp/english.

Intergovernmental Panel on Climate Change (IPCC). 2003. Good Practice Guidance for Land Use, Land-  Use Change and Forestry. Accessible at http://www.ipcc-  nggip.iges.or.jp/public/ gpglulucf/gpglulucf.html.

Intergovernmental Panel on Climate Change (IPCC). 2006. Guidelines for National Greenhouse Gas Inventories . Accessible at http://www.ipcc-  nggip.iges.or.jp/public/2006gl.

<!-- image -->

Intergovernmental Panel on Climate Change. 2013 Revised Supplementary Methods and Good Practice Guidance Arising from the Kyoto Protocol. Accessible at http://www.ipcc-  nggip. iges.or.jp/home/2013KPSupplementaryGuidance\_inv.html.

Intergovernmental Panel on Climate Change (IPCC). 2013. 'Summary for Policymakers.' In Climate Change 2013: The Physical Science Basis. Contribution of Working Group I to the Fifth Assessment Report of the Intergovernmental Panel on Climate Change , ed. T. F. Stocker, D. Qin, G.-  K. Plattner, M. Tignor, S. K. Allen, J. Boschung, A. Nauels, Y. Xia, V. Bex, and P.M. Midgley. Cambridge: Cambridge University Press.

Intergovernmental Panel on Climate Change (IPCC). (O. Edenhofer, R. Pichs-Madruga, Y. Sokona, S. Kadner, J. Minx, and S. Brunner). 2014. '2014: Technical Summary.' In Climate Change 2014: Mitigation of Climate Change. Contribution of Working Group III to the Fifth Assessment Report of the Intergovernmental Panel on Climate Change. Cambridge: Cambridge University Press.

Kaya, Yoichi, and Keiichi Yokobori. 1997. Environment, Energy and the Economy: Strategies for Sustainability . New York: United Nations University Press.

Lazarus, Michael, Anja Kollmuss, and Lambert Schneider. 'Single-  year mitigation targets: Unchartered territory for emissions trading and unit transfers.' Stockholm: Stockholm Environment Institute.

MAPS Chile (Opciones de mitigación para enfrentar el cambio climático). 2013. Fase 1 del proyecto, reporte final, escenarios referenciales para la mitigación del cambio climático: Línea base 2007-2030 y dominio requerido por la ciencia en Chile . Santiago: Government of Chile. Accessible at http:// www.mapschile.cl/files/Fase\_1\_MAPS\_Chile.pdf.

Matthews, H. Damon, Nathan Gillett, Peter Stott, and Kirsten Zickfeld. 2009. 'The Proportionality of Global Warming to Cumulative Carbon Emissions.' Nature 459: 829-32. Accessible at http://www.nature.com/nature/journal/v459/ n7248/full/nature08047.html.

Meinshausen, Malte, Nicolai Meinshausen, William Hare, Sarah Raper, Katja, Frieler, Reto Knutti, David Frame, and Myles Allen. 2009. 'Greenhouse-  Gas Emission Targets for Limiting Global Warming to 2C.' Nature 458: 1 158-62. Accessible at http://www.nature.com/nature/journal/v458/ n7242/full/nature08017.html.

Mitigation Action Plans and Scenarios (MAPS). 2014a. 'Modelling.' Accessible at http://www.mapsprogramme.org/ category/themes/modelling-  methodologies/.

Mitigation Action Plans and Scenarios (MAPS). 2014b. 'Chile.' Accessible at http://www.mapsprogramme.org/category/ projects/chile-  projects/.

New York City. 2013. 'PLANYC: Progress Report 2013.' Accessible at http://s-media.nyc.gov/agencies/planyc2030/ pdf/planyc\_progress\_report\_2013.pdf.

Offset Quality Initiative. 2008. 'Ensuring Offset Quality: Integrating High Quality Greenhouse Gas Offsets into North American Cap-  and-  Trade Policy.' Accessible at http:// www.offsetqualityinitiative.org/pdfs/OQI\_Ensuring\_Offset\_ Quality\_7\_08.pdf.

Prag, Andrew. 2012. 'Overlap of Carbon Market Mechanisms.' Presentation given at CEPS Carbon Market Forum, third meeting of the Task Force on New Market Mechanisms under the AWG-  LCA, July 2012. Accessible at http://www.ceps.eu/ files/AndrewPrag.pdf.

Prag, Andrew, Christina Hood, and Pedro Martins Barata. 2013. 'Made to Measure: Options for Emissions Accounting under the UNFCCC.' Climate Change Expert Group Paper No. 2013 (1). Paris: Organisation for Economic Co-  operation and Development. Accessible at: http:/ /www.oecd.org/env/cc/ Made%20to% 20Measure\_Final.pdf.

Sathaye, Jayant, and Steve Meyers. 1995. Greenhouse Gas Mitigation Assessment: A Guidebook . Prepared by Countries Studies Management Team and Lawrence Berkeley Laboratory. Accessible at http://ies.lbl.gov/iespubs/ggma/ghgcontents.html.

Søbygaard, Jacob K., Peter Larsen, Sixten Rygner Holm, Ulla Blatt Bendtsen, Andrew Prag, and Daniel Puig. 2013. 'National Greenhouse Gas Emissions Baseline Scenarios: Learning from Experiences in Developing Countries.' Danish Energy Agency (DEA), Organisation for Economic Co-  operation and Development (OECD), and UNEP Risø Centre. Accessible at http://www.uneprisoe.org/Newsbase/2013/04/NewPublication-  Launched-  National-  Greenhouse-  Gas-  EmissionsBaseline-  Scenarios.

Tirpak, Dennis, M. Adler, D. Bleviss, J. Christensen, O. Davidson, D. Phantumvanit, J. Rabinovitch, J Sathaye, and C. Smyser. 1995. 'Chapter 27: Methods for Assessment of Mitigation Options.' In Climate Change 1995: The IPCC Second Assessment Report: Scientific-  Technical Analyses of Impacts, Adaptations, and Mitigation of Climate Change , ed. Robert T. Watson, M.C. Zinyowera, and Richard H. Moss. Cambridge: Cambridge University Press. Accessible at http:/ /www.ipcc-  wg2.gov/publications/SAR/ SAR\_Chapter%2027.pdf.

United Nations Environment Programme (UNEP). 2013. The Emissions Gap Report 2013 . Nairobi, Kenya: United Nations Environment Programme. Accessible at http://www.unep.org/ pdf/UNEPEmissionsGapReport2013.pdf.

United Nations Framework Convention on Climate Change (UNFCCC). 2000. 'Review of Implementation of the Commitments and of Other Provisions of the Convention: UNFCCC Guidelines on Reporting and Review.' FCCC/ CP/1999/7. Bonn: UNFCCC. Accessible at http://unfccc. int/files/national\_reports/annex\_i\_natcom/\_guidelines\_ for\_ai\_nat\_comm/application/pdf/01\_unfccc\_reporting\_ guidelines\_pg\_80-100.pdf.

UNFCCC. 2010. 'Decision 2/CP.15.' FCCC/CP/2009/Add.1. Bonn: UNFCCC. Accessible at http://unfccc.int/resource/ docs/2009/cop15/eng/11a01.pdf.

UNFCCC. 2013a. 'Mitigation Assessments.' Accessible at http://unfccc.int/resource/cd\_roms/na1/mitigation/index.htm.

UNFCCC. 2013b. 'Mitigation Assessments: Module 5.1, Mitigation Assessment Tools in the Energy Sector.' Accessible at http://unfccc.int/resource/cd\_roms/na1/mitigation/ Module\_5/Module\_5\_1/a\_Mitigation\_assessment\_tools\_ energy/Module5\_1.ppt.

United Kingdom. 201 1. 'Implementing the Climate Change Act 2008: The Government's Proposal for Setting the Fourth Carbon Budget.' Policy Statement. Accessible at https://www. gov.uk/government/publications/implementing-  the-  climatechange-  act-2008-  the-  government-  s-  proposal-  for-  setting-  thefourth-  carbon-  budget-  policy-  statement.

U.S. Energy Information Administration (U.S. EIA). 2014. 'Annual Energy Outlook 2014: With Projections to 2040.' Washington, DC: U.S. Department of Energy. Accessible at: http://www.eia.gov/forecasts/aeo/pdf/0383(2014).pdf.

U.S. Environmental Protection Agency (U.S. EPA). 2013. 'Chapter 2: Trends in Greenhouse Gas Emissions.' In Inventory of U.S. Greenhouse Gas Emissions and Sinks: 1990-201 1 . Washington, DC: U.S. EPA. Accessible at http://www.epa.gov/ climatechange/Downloads/ghgemissions/US-  GHG-  Inventory2013-  Chapter-2-  Trends.pdf.

Weidema, B. P., and M. S. Wesnaes. 1996. 'Data Quality Management for Life Cycle Inventories: An Example of Using Data Quality Indicators.' Journal of Cleaner Production 4 (3-4): 167-74.

World Wildlife Fund. 2008. 'WWF Guidelines on the Key Principles Required for Robust Voluntary Carbon Offset Project Standards: A Paper to Accompany the Report Making Sense of the Voluntary Carbon Market: A Comparison of Carbon Offset Standards . ' Washington, DC: WWF.

Zickfeld, Kirsten, Michael Eby, H. Damon Matthews, Andrew Weaver, and Hans Joachim Schellnhuber. 2009. 'Setting Cumulative Emissions Targets to Reduce the Risk of Dangerous Climate Change.' Proceedings of the National Academy of Sciences of the United States of America 106 (38): 16129-34. Accessible at http://www.pnas.org/ content/106/38/16129.

## Contributors

## Technical Working Group members-  Chapter leads

Rachael Jonassen

The George Washington University

Pedro Martins Barata

Get 2C

Marian Van Pelt

ICF International

Nora Greenglass

Independent (formerly Woods Hole Research Center)

Pete Erickson

Stockholm Environment Institute-  U.S.

Kate Larsen

Rhodium Group

## Technical Working Group members

Tomas Wyns

Center for Clean Air Policy

Claudio M. Gesteira

CentroClima, Federal University of Rio de Janeiro

Christa Clapp

CICERO

Tim Kelly

Conservation Council of South Australia

Jacob Krog Søbygaard

Danish Energy Agency

Melanie Ford

Department of Climate Change and Energy Efficiency, Australia

Miguel Rescalvo

DNV KEMA

Michael Gillenwater

GHG Management Institute

Lucas Bossard

International Finance Corporation

Andrew Prag

Organisation for Economic Co-  operation and Development (OECD)

Harmke Immink

Promethium Carbon

Miriam Lev-  On

Samuel Neaman Institute, Technion, Haifa, Israel

Bundit Limmeechokchai

Thailand Greenhouse Gas Management Organization

Neta Meidav

United Kingdom Department of Energy and Climate Change

Sekai Ngarize

United Kingdom Department of Energy and Climate Change

Yanna Antypas

United States Energy Information Administration

## Pilot testing organizations

Maricel Gibbs

Independent Consultant, Chile

Vishal Bhavsar

Mahindra Lifespaces Developers Limited, India

Usmani Sabah

Mahindra Lifespaces Developers Limited, India

Andrés Pirazzoli

Ministry of Environment, Chile

Meike Sophie Siemens

Ministry of Environment, Chile

Harmke Immink

Promethium Carbon, South Africa

Miriam Lev-  On

Samuel Neaman Institute, Technion, Haifa, Israel

Perry Lev-  On

Samuel Neaman Institute, Technion, Haifa, Israel

Peter Erickson

Stockholm Environment Institute-  U.S.

Kevin Tempest

Stockholm Environment Institute-  U.S.

Adrian Gault

United Kingdom Committee on Climate Change

## Reviewers

| Stefanie Glese-Bogdan                        | 3M                                                                                      | Seidy Alfaro                             | Ente Costarricense de                                                                                |
|----------------------------------------------|-----------------------------------------------------------------------------------------|------------------------------------------|------------------------------------------------------------------------------------------------------|
| Fabio Peyer                                  | Amcor Ltd.                                                                              |                                          | Acreditación (ECA)                                                                                   |
| Gerald Rebitzer                              | Amcor Ltd.                                                                              | Dominique Blain                          | Environment Canada                                                                                   |
| Arturo Cepeda                                | Artequim Co. Ltd.                                                                       | Dipankar Ghosh                           | Ernst and Young                                                                                      |
| Eros Artuso                                  | AS Management & Consulting SARL                                                         | Sandro Federici                          | Food and Agriculture Organization of the United Nations                                              |
| Peter Saling                                 | BASF California Air Resources Board                                                     | Alexander Fisher                         | German Federal Ministry for the Environment, Nature Conservation, Building and Nuclear Safety (BMUB) |
| Ryan McCarthy Courtney Smith Florence Daviet | California Air Resources Board Canadian Parks and Wilderness Society                    | Voltaire Acosta Jose Salim Soto          | GIZ Philippines Golder Associates S.A.                                                               |
| Carolina Dubeux                              | Centro Clima, Federal University of Rio de Janeiro                                      | Wei Zeng                                 | Hubei University of Technology ICLEI-Local Governments                                               |
|                                              | C40 Cities Climate                                                                      | Chang Deng-Beck                          | for Sustainability                                                                                   |
| Michael Doust Alvin Mejia                    | Leadership Group Clean Air Asia Climatekos                                              | Maryke van Staden Maria Gutierrez        | ICLEI-Local Governments for Sustainability Independent                                               |
| Robert Tippmann Anthea Harris                | Climate Change Authority, Australia                                                     | Raihan Uddin Ahmed                       | Infrastructure Development Company Limited                                                           |
| Kath Rowley                                  | Climate Change Authority,                                                               | James Mwangi                             | Intasave Partnership Kenya King Mongkut's University of Technology                                   |
|                                              | Australia                                                                               | Siriluk Chiarakorn                       |                                                                                                      |
| Kathryn Smith                                | Climate Change Authority, Australia Climate Policy Initiative                           | Julia Kalloz                             | LMI                                                                                                  |
| Jeff Deason Marion Vieweg                    | Current Future                                                                          | Koji Ina                                 | Ministry of Economy, Trade, and Industry, Japan                                                      |
| Ken Xie Sebastian Wienges                    | Department of Climate Change and Energy Efficiency, Australia Deutsche Gesellschaft für | Joseph Kuabi Bavueza Diana Guzmán Torres | Ministry of Energy, Democratic Republic of the Congo Ministry of Environment                         |
| Luis Roberto Chacón Nimisha Pandey           | Internationale Zusammenarbeit (GIZ) GmbH EMA The Energy and Resources                   | Oscar Vázquez                            | Ministry of Environment of Mexico City                                                               |
|                                              | Institute (TERI)                                                                        | Hoang Van Tam                            | Ministry of Industry and Trade, Vietnam                                                              |
| Samantha Keen                                | Energy Research Centre, University of Cape Town                                         | Brad Upton                               | National Council for Air and Stream Improvement (NCASI)                                              |
| Marta Torres Gunfaus                         | Energy Research Centre, University of Cape Town                                         | Takayoshi Sonoda                         | Nippon Kaiji Kentei Quality Assurance Ltd.                                                           |
| Harald Winkler                               | Energy Research Centre, University of Cape                                              | Einar Telnes                             | Norad Oeko-Institut                                                                                  |
| Xiao Gao                                     | Town Energy Research Institute,                                                         | Anke Herold                              | Oeko-Institut                                                                                        |
|                                              | NDRC, China Energy Research Institute,                                                  | Anne Siemons Kazuyoshi Sasaki            | Overseas Environmental                                                                               |
| Zhu Songli                                   |                                                                                         | James Mwangi                             | Cooperation Center, Japan Partnership Kenya                                                          |
|                                              | NDRC, China                                                                             | John Lanchbery                           | the                                                                                                  |
| Mariluz Quirós                               | Ente Costarricense de Acreditación (ECA)                                                |                                          | Royal Society for Protection of Birds                                                                |

## Reviewers (continued)

| Gareth Phillips Li Peng                       | Sindicatum Sustainable Resources SinoCarbon Innovation & Investment Co., Ltd.   | Alejandro Solís Tenorio                            | Universidad Autónoma de Guadalajara, Mexico University College London         |
|-----------------------------------------------|---------------------------------------------------------------------------------|----------------------------------------------------|-------------------------------------------------------------------------------|
| José Romero                                   | Swiss Federal Office for the Environment FOEN                                   | Danny Cullenward Matthew Brander                   | University of California, Berkeley University of Edinburgh                    |
| Ruth Wood                                     | Tyndall Centre for Climate Change Research, University of Manchester            | Nate Aden Juan-Carlos Altamirano Hyacinth Billings | World Resources Institute World Resources Institute World Resources Institute |
| Miguel Angel Cervantes Jason Funk Jeremy Webb | UNDP LECB Program, Mexico Union of Concerned Scientists United Nations Economic | Yamide Dagnet Thomas Damassa Wee Kean Fong         | World Resources Institute World Resources Institute                           |
| Gyami Shrestha                                | Commission for Africa United States Carbon Cycle                                | Taryn Fransen Apurba Mitra                         | World Resources Institute World Resources Institute World Resources Institute |
| Christopher                                   | Science Program United States Department of Agriculture, Forest Ser-            | Jennifer Morgan Janet Ranganathan Stephen Russell  | World Resources Institute World Resources Institute World Resources Institute |
| Woodall                                       | vice Research                                                                   | Mary Sotos                                         | World Resources Institute                                                     |
| Christine Dragisic Alexia Kelly               | United States Department of State United States Department of State             | Laura Malaguzzi Valeri                             | World Resources Institute                                                     |

## Funders

This standard development process was generously supported by the German Federal Ministry for the Environment, Nature Conservation, Building and Nuclear Safety based on a decision of the German Bundestag. Additional support was provided by the Ministry of Foreign Affairs of the Netherlands, Siemens AG, and the United Kingdom Department of Energy and Climate Change.

WRI would also like to thank the following funders for supporting the pilot testing of the standard: City of Seattle, Gold Fields Limited, Harmony Gold Mining Company Limited, Israel Ministry of Environmental Protection, Kumba Iron Ore Limited, the Low Emission Capacity Building Project (European Commission, governments of Australia and Germany), PPC Limited, the Strategic Climate Institutions Programme (SCIP), and the United Nations Development Programme (UNDP).

<!-- image -->

<!-- image -->

## disclaimer

## dedication

The GHG Protocol Mitigation Goal Standard is designed to promote best practice GHG accounting and reporting. It has been developed through an inclusive multistakeholder process involving experts from nongovernmental organizations, governments, businesses, and others convened by the World Resources Institute. While WRI encourages use of the Mitigation Goal Standard by all relevant organizations, the preparation and publication of reports or program specifications based fully or partially on this standard is the full responsibility of those producing them. Neither WRI nor other individuals who contributed to this standard assume responsibility for any consequences or damages resulting directly or indirectly from its use in the preparation of reports or program specifications or the use of reported data based on the standard.

This standard is dedicated to Andrei Bourrouet, a member of the Advisory Committee, who passed away in 2013. Andrei was the environmental representative from the Costa Rican Institute of Electricity and formerly the Viceminister of Energy and Environmental Management at the Costa Rican Ministry of Environment, Energy, and Telecommunications. Andrei devoted his career to furthering climate change policymaking in Costa Rica and internationally.

<!-- image -->

## about the world resources institute

WRI is a global research organization that works closely with leaders to turn big ideas into action to sustain a healthy environment  -    the foundation of economic opportunity and human well-  being.

## our challenge

Natural resources are at the foundation of economic opportunity and human well-  being. But today, we are depleting Earth's resources at rates that are not sustainable, endangering economies and   people's lives.   People depend on clean water, fertile land, healthy forests, and a stable climate. Livable cities and clean energy are essential for a sustainable planet. We must address these urgent, global challenges this decade.

## our vision

We envision an equitable and prosperous planet driven by the wise management of natural resources. We aspire to create a world where the actions of government, business, and communities combine to eliminate poverty and sustain the natural environment for all   people.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Printed on Chorus Art Silk, an FSC-certified paper with 30% pcw recycled content and with inks that are of soy content.

Stock photography: Shutterstock.com

Design: Alston Taggart, Studio Red Design, with assistance from Elliott Beard and Tanya Nuchols.

ISBN: 978-1-56973-844-3

Printed in USA

<!-- image -->

<!-- image -->

The Greenhouse Gas Protocol provides the foundation for sustainable climate strategies. GHG Protocol standards are the most widely used accounting tools to measure, manage and report greenhouse gas emissions.

<!-- image -->