---
document_id: sbti_land_transport
title: "Land Transport Science-Based Target-Setting Guidance"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "SBTi"
year: 2022
original_file: "sbti_land_transport_sector_guidance.pdf"
tables_detected: 97
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## LAND TRANSPORT SCIENCE-BASED TARGET-SETTING GUIDANCE

Version 1.1

October 2024

om the SBTi's website

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ABOUT SBTi

The Science Based Targets initiative (SBTi) is a corporate climate action organization that enables companies and financial institutions worldwide to play their part in combating the climate crisis.

We develop standards, tools and guidance which allow companies to set greenhouse gas (GHG) emissions reductions targets in line with what is needed to keep global heating below catastrophic levels and reach net-zero by 2050 at latest.

The SBTi is incorporated as a charity, with a subsidiary which will host our target validation services. Our partners are CDP, the United Nations Global Compact, the We Mean Business Coalition, the World Resources Institute (WRI), and the World Wide Fund for Nature (WWF).

## DISCLAIMER

Although reasonable care was taken in the preparation of this document, the Science Based Targets initiative (SBTi) affirms that the document is provided without warranty, either expressed or implied, of accuracy, completeness or fitness for purpose. The SBTi hereby further disclaims any liability, direct or indirect, for damages or loss relating to the use of this document to the fullest extent permitted by law. The information (including data) contained in the document is not intended to constitute or form the basis of any advice (financial or otherwise). The SBTi does not accept any liability for any claim or loss arising from any use of or reliance on any data or information in the document.

This document is protected by copyright. Information or material from this document may be reproduced only in unaltered form for personal, non-commercial use. All other rights are reserved. Information or material used from this document may be used only for the purposes of private study, research, criticism, or review permitted under the Copyright Designs &amp; Patents Act 1988 as amended from time to time ('Copyright Act'). Any reproduction permitted in accordance with the Copyright Act shall acknowledge this document as the source of any selected passage, extract, diagram, content or other information.

The SBTi reserves the right to revise this document according to a set revision schedule or as advisable to reflect the most recent emissions scenarios, regulatory, legal or scientific developments, and GHG accounting best practices.

'Science Based Targets initiative' and 'SBTi' refer to the Science Based Targets initiative, a private company registered in England number 14960097 and registered as a UK Charity number 1205768.

© SBTi 2024

## VERSION HISTORY

| Version     | Change/update description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Release date   | Effective dates   |
|-------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|-------------------|
| Version 1   | Minor revision of the Transport Science-Based Target-Setting Guidance (2018): ● Name change from Transport Guidance to Land Transport Guidance. ● Compilation of SBTi target-setting criteria for Land Transport, presenting current criteria and recommendations found across existing documents and guidance from the Science Based Targets initiative (SBTi). ● The inclusion of the Rationale for the New 1.5°C Target-Setting Method for Automakers (Annex I) and corresponding criteria. ● Moving of the Transport Science-Based Target Setting Guidance Version (2018) (Annex II). | 20 March 2024  | 20 April 2024     |
| Version 1.1 | Technical correction to the Transport Science-Based Target-Setting Guidance (2018), included herein as Annex II: ● Correction in Sections 3.4.1 and 3.4.2 regarding accounting for scope 3 category 11 emissions from the use of sold auto parts as either direct or indirect emissions.                                                                                                                                                                                                                                                                                                  | 1 October 2024 | 1 October 2024    |

## CONTENTS

| 1. INTRODUCTION..................................................................................................................6                         |
|------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2. LAND TRANSPORT SECTOR: GENERAL CRITERIA......................................................                                                           |
| 3. LAND TRANSPORT SECTOR: CRITERIA FOR AUTOMAKERS..................................... ANNEX I: RATIONALE FOR THE NEW SBTi 1.5°C TARGET-SETTING METHOD FOR |
| 1. The need for a new 1.5°C target-setting method for automakers................................ 12                                                        |
| 2. Scenario description.....................................................................................................13                             |
| 3. New sector-specific criteria for automakers................................................................. 16                                         |
| 4. Looking forward: official SBTi 1.5°C sector standards................................................. 17                                               |
| ANNEX II: TRANSPORT SCIENCE-BASED TARGET-SETTING GUIDANCE VERSION 1.2                                                                                      |
| MAY 2018...............................................................................................................................19                  |

## 1. INTRODUCTION

The intention of this document is to set out a compilation of the SBTi target-setting criteria for land transport, presenting current criteria and recommendations found across existing documents from the Science Based Targets initiative (SBTi), and new criteria for 1.5ºC target-setting for automakers.

This document enters into force 30-days from publication.

An indicative (but not exhaustive) list of entities whose activities are considered part of the land transport sectors include: passenger and freight transport companies (road and rail), logistics service providers, carriers, postal companies, road vehicle manufacturers, autopart manufacturers, and in general companies with large land transport emissions in their value chain.

For more information and detailed guidance on each criterion and recommendations, please also refer to Annex I, Rationale for the New SBTi 1.5°C Target-Setting Method for Automakers, and Annex II, Transport Science-Based Target-Setting Guidance Version 1.2 May 2018.

This document compiles the criteria in force at the time of publication and reflects:

- ● The SBTi-wide increase in ambition to 1.5ºC for scope 1 and 2 targets, in force since July 2022.
- ● The pause on automaker targets, introduced from 28 March 2022 due to the lack of 1.5ºC method for these emissions, and the subsequent lifting of that pause upon the introduction of a new approach for automakers, which is implemented in this document following a public consultation over October-November 2023.

This document does not introduce new requirements, except for the new criteria for automakers (section 3), and one new criterion on disclosure of sub-targets (Land Transport C5), introduced to increase transparency and align with SBTi practice for other sectors.

This document uses precise language to indicate requirements, recommendations and permissible options that companies may choose to follow.

- ● The terms 'shall' or 'must' are used throughout this document to indicate what is required for companies to be in conformance with the SBTi Criteria.
- ● The term 'should' is used to indicate a recommendation.
- ● The term 'may' is used to indicate that an option is permissible or allowable.

This document is intended for corporates submitting targets to the SBTi. Companies should utilize this document while completing the target submission form(s) to ensure that any proposed targets meet all relevant criteria.

Companies are invited to familiarize themselves with the SBTi cross-sector resources, i.e. the Getting Started Guide for Science-Based Target Setting followed by reviewing the

requirements of target setting in the SBTi Corporate Near-Term Criteria and SBTi Corporate Net-Zero Standard Criteria. To understand these requirements in more depth, companies should then review the Procedure for Validation of SBTi Targets and use the Corporate Near-Term Tool and the Corporate Net-Zero Tool to begin developing targets, and use the Criteria Assessment Indicators (CAI) document to ensure its science-based targets are in line with the SBTi criteria, the Land Transport Guidance and the GHG Protocol Accounting Standards.

## 2. LAND TRANSPORT SECTOR: GENERAL CRITERIA

Current criteria and recommendations found across existing documents and guidance: Entities with use-phase emissions from land transport shall follow the SBTi's cross-sector criteria, as well as the criteria in Table 1 below, and should also follow relevant recommendations and guidance in the Transport Science-Based Target-Setting Guidance (refer to Annex II in this document).

Table 1. General land transport sector criteria

| CRITERION                                                                             | DESCRIPTION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
|---------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Land Transport C1 - Well-to-Wheel (WTW) Emissions Coverage of Each Transport Category | All targets (absolute or intensity) covering land transport activities must be on a WTW basis. Refer to the GLEC Framework V3.0 on how Tank-to-Wheel (TTW) and WTT are accounted for across scopes and categories.                                                                                                                                                                                                                                                                                           |
| Land Transport C2 - Activity Disclosure and Projections                               | Companies setting transport sector SDA targets must disclose and report base year, most recent year and target year activity data, in terms of passenger-kilometers or metric tonne-kilometers transported depending on the transport category, with credible and justifiable growth projections.                                                                                                                                                                                                            |
| Land Transport C3 - Emissions Allocation Eligibility                                  | For all companies using the SDA Transport Tool' to set transport SDA targets, the emissions covered must be in scope 3, related to transportation activities outside of the company's organizational boundary.                                                                                                                                                                                                                                                                                               |
| Land Transport C4 - Optional or Mandatory Transport SDA Targets                       | The transport sector guidance "Transport Science-Based Target-Setting Guidance (2018)" and associated transport sector well-below 2ºC SDA targets are applicable to and optional for companies with scope 3 GHG emissions (tCO2e) from passenger and/or freight transportation activities, as listed in the 'type of transport-related emissions' column in Table 1 of that 2018 transport sector guidance. (The transport SDA shall not be used by automakers to set targets covering scope 3 category 11.) |
| Land Transport C5 - Disclosure of Sub-targets                                         | Where intensity targets set for scope 3 using the transport SDA are aggregated with other scope 3 targets on an absolute basis, the intensity sub-target shall also be disclosed in target wording and in annual reporting.                                                                                                                                                                                                                                                                                  |

## 3. LAND TRANSPORT SECTOR: CRITERIA FOR AUTOMAKERS

New specific criteria for automaker targets are summarized in Table 2 below following the introduction of the new 1.5°C target-setting approach for automakers.

Refer to the Rationale for the New 1.5°C Target-Setting Method for Automakers (Annex I) and the Transport Science-Based Target-Setting Guidance 2018 (Annex II).

Table 2. Automakers criteria table

| CRITERION                                                  | DESCRIPTION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
|------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Automaker-C1 - Companies Required to set Automaker Targets | Companies whose emissions from manufacturing and lifecycle use of the following vehicles are more than 5% of the company's total scope 1, 2 and 3 emissions are considered to be automakers: Cars and vans: ● 2-3 wheelers - All motorized vehicles having two or three wheels aimed at the mobility of persons on all types of roads. ● Light duty vehicles - All motorized vehicles having four wheels aimed at the mobility of persons on all types of roads, up to nine persons per vehicle and 3.5 tonnes (t) of gross vehicle weight. Buses and trucks: ● Buses - Buses (more than nine seats) and BRT systems (Bus Rapid Transit). ● Mini-buses. ● Medium freight trucks - Commercial vehicles with a gross vehicle weight (GVW) from 3.5 t to 15 t; they include small lorries, rigid trucks, and tractor-trailers as well as large vans. ● Heavy freight trucks - Commercial vehicles with a GVW greater than 15 t, they typically serve long-haul delivery of goods, have from two or more axles and a power rating of between 200 and 600 kW. Companies that are considered to be automakers must set automaker targets that include 100% of scope 3 category 11 emissions at 1.5ºC ambition, in line with criteria Automaker-C2 to C7. |
| Automaker-C2 Target Boundary                               | The SBTi Corporate Near-Term Criteria and Corporate Net-Zero Standard Criteria apply for scope 1 and 2 emissions and all scope 3 categories except for category 11. Automaker targets must cover 100% of use-phase emissions reported in scope 3 category 11 regardless of overall scope 3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |

| CRITERION                                                              | DESCRIPTION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
|------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                                        | coverage. Targets must cover the entire sales portfolio across the vehicle categories specified in Automaker-C1, without geographical exclusions. For use-phase emissions, the reporting boundary on a WTW basis must cover all operational modes including idling, repositioning and empty running, and add any other clarifications. Automakers shall report real world emissions and adjust test cycle emissions to reflect real emissions: ● Manufacturers are required to test the fuel consumption and corresponding emissions from the exhaust of newly produced vehicles using the Worldwide Harmonized Light Vehicle Test Procedure (WLTP) adjustment factors/formulas for passenger cars, vans, and light commercial vehicles (up to 3.5 t). ● Manufacturers are required to test the fuel consumption and corresponding emissions from the exhaust of newly produced vehicles using World Harmonized Heavy-Duty Certification (WHDC) adjustment factors/formulas for trucks, buses and coaches (over 3.5 t). ● Companies must use the adjustment factors/formulas of the Worldwide Harmonized Test Cycle (WLTC) to obtain real actual emissions. |
| Automaker-C3 - Well-to-Wheel Emissions (WTW) Coverage                  | Calculation of GHG emissions for automakers' scope 3 category 11 targets shall be on a WTW basis.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Automaker-C4 - Target-Setting Method for Scope 3 Category 11           | Automakers must set absolute emission reduction targets for emissions for the use of sold products (scope 3 category 11) consistent with limiting warming to 1.5°C according to SBTi approved methods and pathways.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Automaker-C5 - Expressing Absolute Targets in Intensity Terms          | Absolute automaker targets may be expressed in intensity terms (e.g. per unit sold) in the target language, but to do so, companies must disclose credible and justifiable projected target year unit sales and use those to calculate intensity reductions equivalent to the absolute target ambition. Companies setting automaker scope 3 category 11 targets must disclose credible and justifiable projected target year passenger-kilometers or metric tonne-kilometers of sold manufactured vehicles.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Automaker-C6 - Phase Out of Internal Combustion Engines (ICE) Vehicles | Car and van automakers setting science-based targets shall commit to work toward the phase out of new ICE cars and vans by 2035 in leading markets and by 2040 globally (or earlier as per local applicable regulation), and set interim targets consistent with this long-term goal.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |

| CRITERION                                    | DESCRIPTION                                                                                                                                                                                                                                                                                                                                                                                                         |
|----------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                              | To demonstrate this commitment, car and van automakers must publish a statement alongside their science-based targets (and may demonstrate this commitment by, for example, signing the ZEV Declaration). The statement must follow the format, 'Company X commits to work toward the phase out of new internal combustion engine vehicles by 2035 in leading markets and by 2040 globally [or add earlier dates].' |
| Automaker-C7 - Near and Long-Term SBTi Tools | Minimum ambition of near-term targets shall be calculated using the scope 3 tab in the SBTi Corporate Near-Term Tool, where WTW absolute emissions for the lifetime of vehicles sold in base year (entire portfolio) shall be entered. Minimum ambition of long-term targets shall be calculated in accordance with the SBTi's Corporate Net-Zero Standard Criteria using the Corporate Net-Zero Tool.              |

| RECOMMENDATION                | DESCRIPTION                                                                                                                                                                                                                                                                              |
|-------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Automaker-R1 - Target Wording | Suggested target wording for automaker targets: '[Company Name] commits to reduce absolute scope 1 and 2 GHG emissions X% by [target year] from a [base year] base year, and absolute scope 3 GHG emissions from use of sold products X% by [target year] from a [base year] base year'. |

## ANNEX I: RATIONALE FOR THE NEW SBTi 1.5°C TARGET-SETTING METHOD FOR AUTOMAKERS

## 1. The need for a new 1.5°C target-setting method for automakers

The Science Based Target initiative (SBTi) completed and delivered a target-setting guidance and tool for passenger transport, freight transport, and automaker Original Equipment Manufacturers (OEMs) in May 2018. These resources, developed with support from the International Council for Clean Transportation (ICCT) Partnership on Sustainable, Low Carbon Transport (SLoCaT), and Smart Freight Centre (SFC) were based on a well-below 2°C (WB2C) method derived from the Sustainable Development Scenario (SDS) included in the Energy Technology Perspectives 2020 publication by the International Energy Agency (IEA).

In response to the urgency and scale of the climate emergency and the success of science-based targets to date, the SBTi ratcheted its expectations for businesses by ensuring all targets align with a 1.5°C future. Since July 2022, the SBTi only validates targets aligned with a minimum level of ambition of 1.5°C for scope 1 and 2 and WB2C for scope 3. In April 2023, the SBTi updated its cross-sector near-term target-setting criteria (V5.1), requiring companies to set scope 1 and 2 targets aligned with a 1.5°C ambition. The ambition upgrade extended to scope 3, setting the minimum ambition from 2°C to WB2C.

As the SBTi had previously required WB2C targets for scope 3 category 11 of automakers, we temporarily paused nearand long-term target validations and target updates for automakers until 1.5°C scope 3 methods for use-phase emissions from new road vehicles were developed and approved. This pause applied to all newly manufactured road vehicles classified as: new light duty passenger vehicles, new light commercial vehicles, new medium freight trucks and new heavy freight trucks. Therefore, automakers have been unable to submit scope 3 category 11 targets until a 1.5°C-aligned method for new road vehicles was developed.

Addressing specific emission categories directly related to a company's main activity has significant potential to improve the credibility and consistency of decarbonization claims for both nearand long-term targets. As the vast majority of automakers' overall emissions originate from end-users driving the vehicles, company-wide decarbonization claims aligned with 1.5°C should accordingly be consistent across vehicle use-phase emissions, accounted for under scope 3 category 11 'use of sold products'.

As per our legacy guidance, OEMs must submit emission reduction targets covering scope 3 category 11 targets inclusive of entire portfolio sales across all vehicle categories and encompassing all regions. The minimum level of ambition for scope 3 category 11 is 1.5°C, while the minimum level of ambition for near-term targets over the rest of scope 3 categories is WB2C (according to current criteria). The minimum level of ambition for net-zero scope 3 target-setting category 11 is 1.5°C.

The SBTi aims to continue to develop methodologies that will support decarbonization at the pace and scale required by science. There is currently no Sectoral Decarbonization Approach (SDA) for transport that allows companies to align their use-phase emissions targets of new road vehicles with 1.5°C methods. In pursuit of the goal of attaining technical completeness, and to support companies in the transport sector that are ready to set 1.5°C aligned targets now, we are releasing a new 1.5°C target-setting method for automakers. This 1.5°C aligned target-setting method for automakers meets the SBTi's criteria for scenarios approved for science-based target setting: it is plausible, consistent, and responsible (SBTi, 2019).

To ensure automakers can align the majority of emissions with a 1.5°C trajectory, this 1.5°C target-setting method for automakers allows the lifting of the temporary pause put in place by the SBTi, while it updates the SDA Transport Tool methods and makes these respective changes to the SBTi criteria. Long-term targets must be set and validated in accordance with the SBTi's Net-Zero Standard Criteria using the Corporate Net-Zero Tool. This provides a method for automakers to tackle near and long-term target setting.

This new 1.5°C target-setting method is intended for OEMs and automakers. Autopart manufacturers are not impacted by the new method and therefore they can use any of the scope 3 methods and are subject to the minimum scope 3 ambition (WB2C).

Adopting this 1.5°C target-setting also provides a short-term, accessible option for OEM companies that are ready to submit net-zero targets now. The 1.5°C target-setting method for automakers will be reviewed and may be superseded upon the completion of the sector standards update process. For more information about future plans for development of the updated 1.5°C passenger, freight and OEM guidance, see section 4.

## 2. Scenario description

The underlying data in the SDA Transport Tool are sourced from the detailed transport methods in the IEA Mobility Model (MoMo). The emissions scenarios embedded in the SDA tool are the 2°C scenario (2DS) and the beyond 2°C scenario (B2DS). The new SBTi 1.5°C target-setting method for automakers is derived from the updated IEA MoMo. 1

The sector methods of the IEA Net Zero Emissions (NZE) scenario (IEA, 2021) define the upper bound of sector carbon emissions for all sectors for which SBTi has developed guidance (Chang et al., 2021). 2 To ensure that the overall emissions budget for a 1.5°C temperature goal, including all sectors, is not exceeded, it is important to confirm that sector methods derived from alternative sources fall below the corresponding NZE budget assigned to that sector.

The IEA transport team has confirmed that it is now technically feasible to produce a sector method for new road vehicles that is 1.5°C aligned. Currently, the B2DS and WB2C scenarios for new light duty vehicles results in average annual absolute reductions of 2.5% (target timeframe 2020-2050); it is therefore reasonable following the updated IEA MoMo, to

1 IEA Mobility Model (MoMo)'s February 2021 version.

2 IEA NZE sector emissions taken from World Energy Outlook update 2022 (IEA 2022).

use the 1.5°C cross-sector method as we would expect reductions equal or steeper than 4.2% for the sector.

According to the IEA's World Energy Outlook 3 , the NZE scenario data shows (refer to Table 1) that, on average, road transport must reduce total emissions by at least 2.7% annually between 2020 and 2030. Specifically, on-road passenger cars need to reduce emissions by at least 4.0% annually between 2020 and 2030 and achieve 98.4% reductions by 2050. The sectoral CO2 reductions can be considered similar to the SBTi cross-sector 1.5°C ambition equivalent to 4.2% from 2020 by 2030 for increasingly more fuel-efficient new vehicles. This supports the option of allowing OEMs to use general absolute contraction as the method while the transport sector SDA method is updated.

Table 1. World Energy Outlook (WEO) NZE data shows that sectoral CO2 reductions are similar to those of the SBTi's cross-sector 1.5°C ambition (4.2% per year from 2020 by 2030)

| NET ZERO EMISSIONS BY 2050 SCENARIO (MT CO2)   |   NET ZERO EMISSIONS BY 2050 SCENARIO (MT CO2) |   NET ZERO EMISSIONS BY 2050 SCENARIO (MT CO2) |   NET ZERO EMISSIONS BY 2050 SCENARIO (MT CO2) |   NET ZERO EMISSIONS BY 2050 SCENARIO (MT CO2) | TOTAL % REDUCTION   | LINEAR ANNUAL REDUCTION   | LINEAR ANNUAL REDUCTION   |
|------------------------------------------------|------------------------------------------------|------------------------------------------------|------------------------------------------------|------------------------------------------------|---------------------|---------------------------|---------------------------|
|                                                |                                           2020 |                                           2030 |                                           2040 |                                           2050 | 2020-2050           | 2020-2050                 | 2020-2030                 |
| Road                                           |                                           5485 |                                           3988 |                                           1370 |                                            195 | 96.4%               | 3.2%                      | 2.7%                      |
| Passenger cars                                 |                                           2803 |                                           1691 |                                            422 |                                             45 | 98.4%               | 3.3%                      | 4.0%                      |

## 2.1 Absolution Contraction Target v SDA Average Portfolio Intensity

The Absolute Contraction 4 Approach emphasizes reducing greenhouse gas emissions to a specific level regardless of the intensity growth for OEMs. By setting a specific target for emission reduction, regardless of growth, it ensures that the overall emissions decrease over time. This approach aligns with the goal of limiting global warming to 1.5°C.

The Absolute Contraction Approach is a method to align with near-term targets and transition towards a more ambitious net-zero target. While the SBTi is focused on achieving the 1.5°C target, the absolute contraction method provides a stepping stone towards that goal by ensuring consistent reduction in emissions.

This method considers the absolute reduction of emissions, which means companies are expected to reduce their emissions regardless of their growth or expansion plans. By using this approach, it enables the transport sector to make substantial progress while working towards more ambitious targets specific to their industry.

3 World Energy Outlook (IEA) 2022.

4 The Absolute Contraction Approach is a one-size-fits-all method that ensures that companies setting targets deliver absolute emissions reductions in line with global decarbonization methods.

Currently the SBTi's target-setting approach for automakers requires the following input:

- ● Base year average WtW intensity over the entire portfolio of sold vehicles in category i. 5
- ● Total annual driving distance in base year (in vehicle-kilometer) for sold vehicles in category i.
- ● Total annual driving distance in target year (in vehicle-kilometer) for sold vehicles in category i.

Automakers using the SDA approach would demonstrate target achievement by assessing their target year weighted average WtW intensity over the entire sales of sold vehicles against their target year intensity modeled through the SDA.

Under the Absolute Contraction Approach automakers need to provide the following input:

- ● Total use phase WtW emissions (i.e., sum of lifetime WtW emissions per sold vehicle in category i).

Under this method, automakers shall use the Absolute Contraction Approach to set targets over scope 3 category 11. Automakers would demonstrate target achievement by assessing target year total use phase WtW emissions, against their base year emissions levels, and determine the reduction level against their validated science-based targets. No exclusions are allowed under category 11, with 100% of WtW emissions required to be covered under a 1.5°C aligned target.

The minimum ambition of 1.5°C aligned targets is a 4.2% linear annual reduction between the base year and target year plus an adjustment for base years later than 2020. With this adjustment, targets with a base year later than 2020 must reduce emissions by at least the same amount overall as targets with a 2020 base year. This base year dependent calculation must be applied to determine ambition over the mandatory WtW emissions from eligible vehicle types in an automakers' scope 3 category 11 target.

This formula is to be used for near-term target setting (e.g., between 5-10 years)

)

<!-- formula-not-decoded -->

For long-term targets modeled using the Absolute Contraction Approach with a target year of 10 years or more from the date of submission, the minimum ambition is 90%. 6 This means

5 "Category i" refers to a specific category or type of vehicle. The categorization can be based on various factors, such as vehicle size, fuel type, technology, or market segment. For example, the automotive industry often categorizes vehicles into different segments like sedans, SUVs, sports cars, electric vehicles, hybrid vehicles, etc.

6 This formula is to be used for near-term target setting (e.g., between 5-10 years), refer to the formula in Table 7 in the Corporate Net-Zero Standard V1.2. For long-term science-based targets the minimum reduction is calculated as an overall amount (e.g., 90% overall), refer to Annex B (section B1.1) of the SBTi Corporate Net-Zero Standard.

that the target must reduce greenhouse gas emissions by at least 90% from the base year by the target year.

Absolute targets may still be expressed in intensity terms (per unit sold) if companies provide, in their target submission, transparent target year growth assumptions and use that to calculate intensity reductions accordingly. For example, automakers can calculate the absolute ambition required and the absolute reductions required by the target year, then using base and target year sales volumes as the activity metric, express the equivalent of the absolute target in intensity terms within the target language. Automakers cannot use physical or economic intensity methods to model targets over use of sold products (category 11).

Near-term targets can be calculated using the scope 3 tab in the SBTi Corporate Near-Term Tool, where WtW absolute emissions for the lifetime of vehicles sold in base year (entire portfolio) shall be entered. Long-term targets must also be set and can only be validated in accordance with the SBTi's Corporate Net-Zero Standard Criteria using the Corporate Net-Zero Tool.

Near-term targets must cover a minimum of 5 and a maximum of 10 years from the date the target is submitted to the SBTi for validation. Long-term targets are emission reduction targets that cover more than 10 years from the date of submission.

## 3. New sector-specific criteria for automakers

The ICCT has modeled 7 the projected pace of the Zero Emission Vehicles transition considering government announcements and proposals, and compared these methods with goals to limit warming to 2°C and 1.5°C. This modeling identified a method to stay below 2°C if governments adopt policies to phase out sales of internal combustion engine (ICE) light-duty vehicles by 2035 and heavy-duty vehicles by 2040, and hit interim EV sales milestones in 2025 and 2030.

In 2021, at the United Nations' COP26, the Zero Emission Vehicles Declaration (ZEV Declaration) 8 was launched by a leadership group of more than 100 countries, businesses, and organizations pledged to work toward 100% zero-emission car and van sales (e.g., one that produces zero greenhouse gas emissions at the tailpipe) by 2040 globally and 2035 for leading markets.

The minimum requirement of this new 1.5°C target-setting approach for car and van automakers is that they commit to work towards the phase out of new ICE cars and vans in leading markets by 2035 and by 2040 globally or earlier as per local and international level frameworks and regulations, and have interim targets consistent with this long-term goal.

- 3.1 OEMs must submit category 11 targets inclusive of entire portfolio sales across all vehicle categories 9 (passenger new light duty vehicles; freight new light commercial

7 https://theicct.org/sites/default/files/publications/ZEVTC\_Accelerating-transition\_dec2021.pdf

8 The Declaration | Accelerating to Zero Coalition

9 Refer to page 8 of the Transport Science-Based Target Setting Guidance

vehicles, new medium freight trucks and new heavy freight trucks) and encompassing all regions. The minimum level of ambition for category 11 for new sold road vehicles is 1.5°C.

- 3.2 Car and van automakers setting science-based targets shall commit to work toward the phase out of new ICE cars and vans by 2035 in leading markets and by 2040 globally (or earlier as per local applicable regulation), and set interim targets consistent with this long-term goal. To demonstrate this commitment car and van automakers must publish a statement alongside their science-based targets, and should demonstrate this by, for example, signing the ZEV Declaration. 10 The statement must follow the format, 'Company X commits to work toward the phase out of new internal combustion engine vehicles by 2035 in leading markets and by 2040 globally [or add earlier dates].'

## 4. Looking forward: official SBTi 1.5°C sector standards

The SBTi will develop a 1.5°C scenario offering a robust and credible path for the road and rail sector to set science-based targets that are aligned with 1.5°C of warming, as well as with industry expectations for technology deployment.

The SBTi is prioritizing the development of a 1.5°C aligned target-setting standard for automakers along with a review and update of the passenger, freight and OEM sector target-setting guidance through a formal sector standard setting process. This will involve the advice of an Expert Advisory Group (EAG) and the Technical Council, utilizing an inclusive industry and stakeholder engagement approach, with extensive opportunities for feedback from the general public.

The new 1.5°C target-setting method offers a robust and credible path for automakers to phase out of the ICE. However, this 1.5°C target-setting method for automakers may be superseded as part of the sector standard update developed through the SBTi's customary sector standard development process. If the 1.5°C target-setting method for automakers published in this document is superseded by an updated method released through the updated sector standard, targets set before the release of the updated 1.5°C method will remain valid until a company updates its targets or reaches its 5-year mandatory recalculation period. After a 6-month grace period following the release of the updated method, new target submissions will be required to use the updated standard.

Following the release of the updated sector standard, companies looking to undertake new submissions are advised to consult the SBTi website and most current resources for the latest information on recalculation.

10 The Declaration | Accelerating to Zero Coalition

## References

Chang, A.; Anderson, C.; Aden, N. (2021). Pathways to Net-Zero: SBTi Technical Summary. https://sciencebasedtargets.org/resources/files/method-to-Net-Zero.pdf

International Energy Agency [IEA]. (2021). Net Zero by 2050.

https://iea.blob.core.windows.net/assets/beceb956-0dcf-4d73-89fe1310e3046d68/NetZeroby2050-ARoadmapfortheGlobalEnergySector\_CORR.pdf

International Energy Agency [IEA]. [2022]. World Energy Outlook 2022.

https://www.iea.org/reports/world-energy-outlook-2022

Science Based Targets initiative [SBTi]. (2019). Foundations of Science-based Target Setting.

https://sciencebasedtargets.org/resources/files/foundations-of-SBT-setting.pdf

## ANNEX II: TRANSPORT SCIENCE-BASED TARGET-SETTING GUIDANCE VERSION 1.2 MAY 2018

## FOR REFERENCE ONLY

Note: Refer to the Maritime Guidance and Aviation Technical Report for information to set 1.5°C-aligned science-based targets for those sectors.

<!-- image -->

TRANSPORT SCIENCE-BASED TARGET SETTING GUIDANCE

<!-- image -->

<!-- image -->

## ACKNOWLEDGEMENTS

This  guidance  was  developed  by  WWF  on  behalf  of  the  Science Based Targets initiative  (SBTi). The  Science  Based Targets  initiative mobilizes  companies to set science-based targets and boost their competitive advantage in the transition to the low-carbon economy. It is a collaboration between CDP, the United Nations Global Compact, World Resources Institute (WRI) and the World Wide Fund for Nature (WWF) and one of the We Mean Business Coalition commitments.

For this project we counted on the support of three technical partners which are global organizations working on sustainability and transport:

- • Smart Freight Centre (SFC)
- • Partnership on Sustainable, Low Carbon Transport (SLoCaT)
- • International Council on Clean Transportation (ICCT)

During the development of this work we also had the advice from technical experts:

- • Ecofys, a Navigant Company
- • International Energy Agency (IEA)

A technical advisory group of dedicated experts from industry and NGOs provided detailed input  during  the  planning  phase  and  on various drafts of the guidance and tool.

A public workshop was organized in Paris in July 2017 to get input on key methodological choices from other stakeholders not directly engaged in the project, plus two consultation webinars were held during the month of August 2017.

## Primary authors:

Irma Paola Delgado Luna, WWF Fernando Rangel Villasana, WWF

## Editor:

Suzanne Greene, MIT Sustainable Logistics Initiative and Technical Advisor, Smart Freight Centre

Cover and back cover photos: © Michael Buckley / WWF-Canada

- © 1986 Panda Symbol WWF - World Wide Fund For Nature (also known as World Wildlife Fund)
- ® 'WWF' is a WWF Registered Trademark.

## ABOUT OUR TECHNICAL PARTNERS

<!-- image -->

Smart Freight Centre (SFC) was established in 2013 as a global non-profit organization leading the way to  a  more  efficient  and  environmentally  sustainable global freight and logistics sector. SFC works with businesses and other stakeholders to remove market barriers catalyzing sector-wide action to improve fuel efficiency, reduce emissions and lower operating costs.

<!-- image -->

The Partnership on Sustainable, Low Carbon Transport (SLoCaT) promotes the integration of sustainable  transport  in  global  policies  on  sustainable development and climate change and leveraging action in support of the implementation of the global policies. SLoCaT consists of a multi-stakeholder partnership of over 90 organizations, which is supported by the SLoCaT Foundation.

<!-- image -->

The International Council on Clean Transportation is an independent nonprofit organization founded to provide first-rate, unbiased research and technical and scientific analysis to environmental regulators. Its mission is to improve the environmental performance and energy efficiency of road, marine, and air  transportation,  in  order  to  benefit  public  health and mitigate climate change.

## CONTENT

| 1   | About this guidance                                            | About this guidance                                                        |   06 |
|-----|----------------------------------------------------------------|----------------------------------------------------------------------------|------|
| 2   | General guidance on science-based target-setting for transport | General guidance on science-based target-setting for transport             |   07 |
|     | 2.1                                                            | Basic steps to use the SDATransport tool                                   |   07 |
|     | 2.2                                                            | Target formulation                                                         |   10 |
|     | 2.3                                                            | Target recalculation                                                       |   10 |
|     | 2.4                                                            | Tool boundaries and future improvements                                    |   10 |
|     | 2.5                                                            | Data quality                                                               |   12 |
| 3   | User-specific target-setting guidance                          | User-specific target-setting guidance                                      |   13 |
|     | 3.1                                                            | Companies that own / control vehicles                                      |   13 |
|     | 3.2                                                            | Companies that subcontract / purchase transport services                   |   16 |
|     | 3.3                                                            | Road vehicle manufacturers                                                 |   17 |
|     | 3.4                                                            | Companies that manufacture road vehicle parts                              |   19 |
| 4   | Methodological choices                                         | Methodological choices                                                     |   20 |
|     | 4.1                                                            | Selection of decarbonization scenarios from the International EnergyAgency |   20 |
|     | 4.2                                                            | Sectoral Decarbonization Approach (SDA)                                    |   22 |
|     | 4.3                                                            | Carbon accounting methodologies                                            |   23 |
|     | 4.4                                                            | Well to Wheelemissions boundary                                            |   24 |
| 5   | ANNEX                                                          | ANNEX                                                                      |   25 |

## FOREWORD

Implementation of the Paris Agreement calls for ambitious climate action at global scale. The transition to a low/zero carbon economy is underway and accelerating globally. Every sector in every market is undergoing transformation. Non-state actors play a key role in driving change and already commenced to do so: so far more than 400 companies have joined the Science Based Targets initiative (SBTi) and committed to set GHG emission reduction targets in line with the Paris Agreement goals. Leading businesses recognize this opportunity and the imperative to be part of the solution.

The transport sector must not lag behind. Today it represents 23% of all energyrelated global emissions and it is one of the fastest growing sectors.  The analysis of sectoral transformations implied by current Nationally Determined Contributions (NDCs) shows that transport is one of the sectors where climate action ambition is particularly insufficient in the light of the requirements of mid-century Paris-compatible transformations. And yet, decarbonizing the transport sector is feasible through disruptive technological innovation, land-use planning and transport demand management, modal shift and shifting to electric mobility, but we need to make it happen faster. Companies setting ambitious science-based targets on transport can send a strong signal for local, regional and national policies to increase the level of ambition and steer the transition.

Science-based targets specify how much and how quickly a company needs to reduce its greenhouse gas emissions to future-proof its growth. This report does not present a new approach; it is based on current science-based target methods, and GHG accounting standards. It shows the conclusions of a group of experts (industry and non-industry representatives) that have over the past year focused on developing best practices for science-based target-setting in the transport sector. By using the Sectoral Decarbonization Approach- Transport tool and this report, companies can get on track with a well-below 2°C world.

Thanks to its holistic vision and international network, WWF, the world's foremost NGO dedicated to nature conservation, active in over 100 countries, calls for strong action to prepare and radically transform the transport systems around the world towards a decarbonized economy.

Special thanks to our Technical Partners, Advisors and Consultative Group members for contributing to the realization of this project.

Pascal Canfin CEO, WWF France

1

## ABOUT THIS GUIDANCE

This document supports companies that are interested in setting  science-based  targets  for  transport  greenhouse gas (GHG) emissions according to the new, refined pathways in the Sector Decarbonization Approach (SDA) Transport tool (Learn more about the SDA method and tool in Section 4.3). It builds on the existing manual and guidance of  the  Science  Based  Targets  initiative  (SBTi)  for  setting science-based targets.

The underlying data in the SDA Transport tool are sourced from the detailed transport pathways in the International Energy Agency's (IEA) Mobility Model (MoMo) 1 . The emissions scenarios embedded in the SDA tool are the 2°C scenario (2DS) and the Beyond 2°C scenario (B2DS).

This document contains guidance on how to set targets for transport emissions across different emissions scopes and for  different  tool  end-users.  Examples  of  end-users  are: passenger transport companies, logistics service providers, shippers, carriers, postal companies, road vehicle manufacturers, auto part manufacturers, and in general companies with large transport emissions in their value chain.

Policymakers  can  also  use  this  guidance  to  inform  the development of transport programs and regulations.

The Guidance is divided into three chapters. Chapter 2 is a user's general guidance on the transport categories included in the tool, the data to use in the target modeling exercise and the output users can expect to obtain. Chapter 3 contains more specific guidance per end-user, divided into companies that own or control a fleet of vehicles,  companies  that  manufacture  new  road vehicles, companies with large transport emissions in their value chain  and  companies  that  manufacture  road  vehicle parts. The type of guidance provided is GHG emissions that the company should estimate to model a target -including aggregation of emissions scopes to obtain Wellto-Wheel (WTW) emissions-, definitions of activity units, the approaches a company can use to set science-based targets, and the interpretation of results derived with the SDA Transport tool.

Finally Chapter 4 describes the methodological choices made to build the tool and to produce this Guidance document.

1 IEA (2017), Mobility Model, August 2017 version, database and simulation model, www.iea.org/etp/etpmodel/transport/

2

## GENERAL GUIDANCE ON SCIENCE-BASED TARGET-SETTING FOR TRANSPORT

## 2.1 BASIC STEPS TO USE THE SDA TRANSPORT TOOL

- 1 Identify the transport categories you will need to model your company's target.

The following transport categories are available in the tool:

Table 1. Transport pathways available in the SDA Transport tool

| Tool end-users                                                                                  | Type of transport- related emissions   | Transport category        | Description                                                                                                                                                        |
|-------------------------------------------------------------------------------------------------|----------------------------------------|---------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Companies that own / control vehicles Companies that subcon- tract/ purchase transport services | Passenger transport emissions          | 2-3 Wheelers              | All motorized vehicles having two or three wheels aimed at the mobility of persons on all types of roads                                                           |
| Companies that own / control vehicles Companies that subcon- tract/ purchase transport services | Passenger transport emissions          | Light duty vehicles (LDV) | All motorized vehicles having four wheels aimed at the mobility of persons on all types of roads, up to nine persons per vehicle and 3.5 t of gross vehicle weight |
| Companies that own / control vehicles Companies that subcon- tract/ purchase transport services | Passenger transport emissions          | Buses                     | Buses (more than nine seats) and BRT systems (Bus Rapid Transit)                                                                                                   |
| Companies that own / control vehicles Companies that subcon- tract/ purchase transport services | Passenger transport emissions          | Mini-buses                | Minibuses                                                                                                                                                          |
| Companies that own / control vehicles Companies that subcon- tract/ purchase transport services | Passenger transport emissions          | Urban rail 2              | Metros, high capacity/high frequency commuter rail services, tramways and light rail 3                                                                             |
| Companies that own / control vehicles Companies that subcon- tract/ purchase transport services | Passenger transport emissions          | Non-urban rail            | High-speed rail (intercity rail services crossing long distances between sta- tions and having a maximum speed that exceeds 250 km/h)                              |

2 While countries may define rail modes different, the SBTi adopts the definitions from the Rail Handbook (2017) from the IEA and the International Union of Railways (UIC).

- 3 · Metros are urban rail transport services with short headways and high commercial speed operated by vehicles specifically designed for high capacity transport (e.g. including standing passengers and a large number of doors to enable rapid boarding and operations), running on an exclusive right-of-way urban network with regular station spacing, without any interference from other traffic or level crossings, and often developed as an underground and/or elevated network.
- • Commuter rail includes heavy rail services operating in urban areas and at the boundary between urban and suburban areas, primarily to serve trans-
- port needs of commuters needing access to urban environments.
- • Tramways and light rail, i.e. urban guided transport systems with extensive segregated network sections, mostly at-grade.

Note : This document also provides general guidance for companies that manufacture road vehicle parts (See Section 3.4).

| Tool end-users                               | Type of transport- related emissions   | Transport category                                    | Description                                                                                                                                                                                                  |
|----------------------------------------------|----------------------------------------|-------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                              | Freight transport emissions            | 2-3 Wheelers                                          | All motorized vehicles having two or three wheels aimed at the mobility of goods on all types of roads                                                                                                       |
|                                              | Freight transport emissions            | Light commercial vehicles (LCV)                       | Pickups, vans and small trucks with a gross vehicle weight (GVW) of less than 3.5 t, used for the transportation of goods 4                                                                                  |
|                                              | Freight transport emissions            | Medium freight trucks (MFTs) 5                        | Commercial vehicles with a GVWfrom 3.5 t to 15 t; they include small lorries, rigid trucks and tractor-trailers as well as large vans 6                                                                      |
|                                              | Freight transport emissions            | Heavy freight trucks (HFTs) 7                         | Commercial vehicles with a gross vehicle weight (GVW) greater than 15 tonnes (t), they typically serve long-haul delivery of goods, have from two or more axles and a power rating of between 200 and 600 kW |
|                                              | Freight transport emissions            | Rail 8                                                | Trains to transport goods in dedicated or shared rail tracks                                                                                                                                                 |
|                                              | Aviation & Shipping emissions          | Sea transport                                         | Passenger cruises. Maritime transport activities (domestic and international marine bunkers; contain- erized and non- containerized)                                                                         |
|                                              | Aviation & Shipping emissions          | Air transport                                         | Air transport activities (commercial and non-commercial flights for passenger and freight)                                                                                                                   |
| Companies that manufacture new road vehicles | Emissions from new vehicles            | Passenger- New light duty vehicles                    | WTWemissions related to the use-phase of original equipment manufacturers (OEMs)                                                                                                                             |
| Companies that manufacture new road vehicles | Emissions from new vehicles            | Freight- New light commercial vehicles                | WTWemissions related to the use-phase of original equipment manufacturers (OEMs)                                                                                                                             |
| Companies that manufacture new road vehicles | Emissions from new vehicles            | Freight- New medium freight trucks                    | WTWemissions related to the use-phase of original equipment manufacturers (OEMs)                                                                                                                             |
| Companies that manufacture new road vehicles | Emissions from new vehicles            | Freight- New heavy freight trucks                     | WTWemissions related to the use-phase of original equipment manufacturers (OEMs)                                                                                                                             |
| Companies that manufacture new road vehicles | Emissions from new vehicles            | Passenger- New light duty vehicles (Fuel economy)     | Fuel economy of OEMs -the related emissions are tank-to-wheel (TTW)                                                                                                                                          |
| Companies that manufacture new road vehicles | Emissions from new vehicles            | Freight- New light commercial vehicles (Fuel economy) | Fuel economy of OEMs -the related emissions are tank-to-wheel (TTW)                                                                                                                                          |
| Companies that manufacture new road vehicles | Emissions from new vehicles            | Freight- New medium freight trucks (Fuel economy)     | Fuel economy of OEMs -the related emissions are tank-to-wheel (TTW)                                                                                                                                          |
| Companies that manufacture new road vehicles | Emissions from new vehicles            | Freight- New heavy freight trucks (Fuel economy)      | Fuel economy of OEMs -the related emissions are tank-to-wheel (TTW)                                                                                                                                          |

- 4 In general, the LCV fleet consists of vans, chassis cab-style vehicles, small open lorries and pickup trucks. They are used for a variety of tasks, including small-scale 'last-mile' deliveries, such as a postal or commercial delivery services, and for transporting industrial goods and building materials to and from work sites. They are also used to provide services, such as repairs, plumbing and heating, and office support.
- 5 Definitions provided in the report: 'The Future of Trucks' (IEA, 2017).
- 6 They tend to perform regional operations but also include public and commercial service vehicles, such as garbage trucks or fire-fighting trucks. In countries with a less-developed highway network infrastructure, the function of some MFTs is similar to that of heavy-freight trucks: they are used in long-haul operations and for transporting goods from central distribution hubs (warehouses and ports) to their final destinations, such as retail firms, or for transporting bulk building materials and resources.
- 7 Together, HFTs and MFTs comprise heavy-duty trucks.
- 8 The MoMo definition leaves open specifications of speed, distance and wagon type. This category also includes road trains: multiple trailers pulled by a single tractor unit.

- 2 Define	a	commitment	period. As per the SBTi criteria all targets must cover a minimum of 5 years and a maximum of 15 years from the date the target is submitted to the SBTi for an official validation. The SBTi recommends choosing the most recent year for which data is available as the base year, taking into consideration the representativeness of the year to your company's operations. Preferably, the selected base and target year should ensure forward-looking ambition of an emissions reduction target, rather than covering emissions reductions achieved to date. The earliest base year that can be selected by the company in the tool is 2010 and the latest target year is 2050. Companies are encouraged to develop long-term targets (e.g. 2050) in addition to mid-term targets.
- 3 Collect all base year data required to model a target with the tool. Collect all data per transport category for your global operations for the selected base year.
- 4 Estimate the activity in the target year: Project the activity for the selected target year. For example by calculating the growth rate based on historical data or by using future growth rates as estimated by the company. Alternatively, you may project your activity for the selected target year by applying the default growth rate of the transport category selected which is provided in the tool.
- 5 Select the type of transport-related emissions. The types of transport-related emissions available in the tool are: passenger transport, freight transport, emissions from new vehicles and aviation and shipping.
- 6 Select a transport category and enter required data. The SDA Transport tool allows the modeling of targets for a single transport category at a time. When users select a transport category from the dropdown menu, the tool will automatically show the input data you will need to enter. Users are required to fill-in all fields with their data as per previous steps  9 .
- 7 Review the target-modeling results. The SDA Transport tool currently models targets using two emissions scenarios (2DS and B2DS). For more information on emissions scenarios and the Mobility Model please consult Section 4.2. Two sections are shown below the input section, one for each scenario. The tables summarize the emissions and emissions intensity in the base year and target year selected, as calculated by the SDA Transport tool. The tool also produces graphs showing the emissions intensity pathway of the transport category if available, and the carbon budget for the company. All pathways provided in the tool are global pathways.

Table 2. Required data to use the SDA Transport tool

|                                                                                      | WTWbase                             | Base year activity         | Base year activity     | Base year activity       | Informative                                                         |
|--------------------------------------------------------------------------------------|-------------------------------------|----------------------------|------------------------|--------------------------|---------------------------------------------------------------------|
| Type of transport-related emissions                                                  | Type of transport-related emissions | Passenger- kilometer (pkm) | Tonne- kilometer (tkm) | Vehicle- kilometer (vkm) | Base year fuel economy: Liters of gasoline equivalent (lge)/ 100 Km |
| Companies that own / control vehicles Companies that subcontract/ transport services | Passenger                           |                            |                        |                          |                                                                     |
| Companies that own / control vehicles Companies that subcontract/ transport services | Freight                             |                            |                        |                          |                                                                     |
| purchase                                                                             | Aviation and Shipping               |                            |                        |                          |                                                                     |
| Companies that manufacture new road vehicles                                         | Passenger                           |                            |                        |                          |                                                                     |
| Companies that manufacture new road vehicles                                         | Freight                             |                            |                        |                          |                                                                     |

Fields labeled 'Well to Tank emissions in base year' and 'Tank to Wheel emissions in base year' are optional.

## 2.2 TARGET FORMULATION

Target formulations must indicate the emissions covered, the base year and target year selected, the percentage reduction and the units. As per the SBTi criteria, targets can be expressed on an absolute basis (tCO2e) or intensity basis (e.g. gCO2e/pkm, tCO2e/tkm).

Shorter statements are clearer and more transparent. Activities, strategies or additional information (e.g. percentage of electric vehicle sales) can be part of other documents, like sustainability reports. Example:

Company A commits to reduce its scope 1, 2 and 3  emissions  (from  upstream  transportation  and distribution) 40% by 2030 from a 2017 base-year.

Company B commits to reduce its scope 1, 2 and 3 emissions (from fuel and energy related activities) per passenger-kilometer 35% by 2025 from a 2015 base-year.

## 2.3 TARGET RECALCULATION

To ensure consistent performance tracking over time, the target should be recalculated to reflect significant changes that would compromise its relevance and consistency. The SBTi recommends that companies check the validity of their target projections annually. At a minimum, targets should be reassessed every five years. The company should notify  the  SBTi  (if  participating  in  the  initiative)  of any significant changes and report these major changes publicly.

A  target  recalculation  should  be  triggered  by  significant changes in:

- · Company structure (e.g. acquisition, divestiture, mergers, insourcing or outsourcing)

Companies setting a target for multiple passenger transport categories or multiple freight transport categories can aggregate the tool results to obtain a single GHG reduction target by using weighted averages.

To participate in  the  SBTi,  companies  need to complete a submission form. The form requires disclosure of emissions per scope in the base year, activity figures, and other data  to  perform  the  assessment.  The  SBTi  also  recommends  providing  detailed  information  such  as  regionalized targets, percentage of vehicles sales per power train, occupancy rates or load factors used, etc. All information is treated as confidential and is only used for the purpose of  assessing  compliance  against  current  science-based target methods and SBTi criteria.

For resources related to the SBTi Call to Action, the business case for science based targets and other available materials, please consult:

http:/ /sciencebasedtargets.org/resources/

- · Data used in setting the target (e.g. discovery of significant errors or a number of cumulative errors that are collectively significant)
- · Other assumptions used with science-based target-setting methods

The SBTi reserves the right to withdraw or adjust the tool at any time for updates and/or amendments to its calculations  or  third-party  data.  Adjustments  can  include changes to the decarbonization pathways embedded in the tool, which need to reflect model improvements and changes in the remaining carbon budget available as the world strives to mitigate GHG emissions across all sectors  in  the  economy.  For  further  details  please  refer  to the terms of use and disclaimer in the SDA transport tool.

- · Growth projections

## 2.4 TOOL BOUNDARIES AND FUTURE IMPROVEMENTS

The embedded decarbonization pathways in the tool are those  of  the  International  Energy  Agency's  (IEA)  Mobility Model (MoMo)  10 . The pathways cover WTW emissions expressed as CO -equivalent  11 , this includes the footprint 2 of electricity in electric vehicles. The WTT part covers the emissions  of  fossil  fuels  and  biofuels 12 , yet  it  excludes land use change (LUC) emissions. The possibility of adding LUC emissions to the pathways was explored, as MoMo provides an estimate (not in the default figures). Due to the high  uncertainty  associated with  LUC  emissions,  a  decision was made to exclude them from the underlying decarbonization pathways for the time being.

However, this is almost entirely ameliorated since LUC is included in neither the base year nor the future year of the scenario, so the relative change is not all that different. Also, both the GHG Protocol Scope 3 Standard and the Product Standard, require companies to use Life Cycle Analysis to calculate  emissions  and  removals  from  biogenic  sources,  non-biogenic sources and land-use change impacts, when applicable (e.g. sectors with scarce opportunities to decarbonize such as aviation, shipping and long-haul road transportation).

This  means that while  the  scenarios  defining  the  decarbonization rate do not include LUC, companies must use WTW accounting including LUC in calculating their emissions. Thus, companies are inherently incentivized against shifting to high carbon biofuels, as this would either have a limited reduction potential or actually increase emissions after LUC is included.

Since methods to calculate LUC can widely differ, companies should disclose the method used to calculate these impacts in the inventory report. It is important to note that bioenergy (aka biogenic) emissions and removals  13  must be reported within the WTW boundary, to accurately reflect emissions reductions across time.

Also, the embedded decarbonization pathways in the tool models are global, meaning the tool provides no regional focus. This does not mean that the company will have to use a global emission factor for their activities in different regions in their reporting, but that it will converge to a global pathway when using the SDA Transport tool.

Although  this  might  be  perceived  as  not  equitable  for companies  with  electric  vehicles  operating  in  countries with low-carbon grid electricity, it does provide the right incentive to penetrate those markets.

Some companies operating only in developed countries might already be below the global intensity pathways for the sector. It can also be that country sector-targets con- sidered in the National Determined Contributions (NDCs) or national regulations are more stringent than the global  sector  pathways in this tool. In these cases, the SBTi strongly encourages companies to use regional or country  pathways  that  are  more  ambitious  than  the  global pathway.

Some  potential  improvements  to  be  considered  for  a second phase of this project include:

- · Inclusion of 1.5°C scenarios, when available
- · Inclusion of LUC emissions guidance
- · Development of regional pathways for transport modes that operate only at the national or regional level
- · Development of transport pathways for subsectors not currently covered by the tool, for example river transportation which is relevant in some geographies
- · More in-depth study and refinement of the aviation (e.g. inclusion of non-CO -forcings) and shipping 2 sector

In  addition,  it  is  desirable  to  explore  a  more  holistic  approach for vehicle manufacturers to also consider emissions from materials sourcing and the impacts across the value chain due to the uptake of new technologies.

Since  reducing  transport  emissions  requires  a  profound transformation of mobility and freight services, apart from setting  science-based  targets,  companies  together  with other  stakeholders  need  to  identify  concrete  actions  as well as understand the challenges, the opportunities and the enabling conditions at different scales to succeed in this  task  to  decarbonize  the  sector.  Several  international initiatives 14 launched since COP21 are exploring their complementarities  and  committed  to  scale-up  bold  action at  different  levels.  These  initiatives  are  producing  global macro-road maps, national road maps, evaluating the effectiveness  of  mitigation  actions  and  actively  engaging with companies.

10 Except for Aviation and Shipping; for these two sectors, the tool calculates targets based on the absolute emissions reductions recommended by the IPCC at the global level (IPCC, 2014).

11 Best practice for GHG reporting and science-based target-setting is to use CO2equivalent across all scopes (scopes 1, 2 and 3). For the purpose of joining the initiative, emissions exclusions cannot be greater than 5%.

12 Largely based on data from the Joint Research Centre, EUCAR and CONCAWE (JEC, 2014).

13 The GHG Protocol Accounting and Reporting Standard for scope 1 and 2 emissions recommends to report biogenic emissions outside the scopes, but as an item in the company's GHG inventory. The WTW approach commonly used in the transport sector does not make such a distinction.

14 For example: The Paris Process on Mobility and Climate (PPMC), led by Movin'On (successor of former 'Michelin Challenge Bibendum') and the Partnership on Sustainable, Low Carbon Transport (SLoCaT);  The 'Decarbonising Transport' initiative of the International Transport Forum (ITF) and The Deep Decarbonization Pathways Project for Transport (DDPP-T) led by the Institute for Sustainable Development and International Relations (IDDRI).

## 2.5 DATA QUALITY

Companies must use data that is most representative of the actual fuel and energy consumption. Default activity data is acceptable, but they are less accurate and limit a company's ability to truly track performance and progress towards targets. Thus, when used, the source and potential uncertainty of the adopted default data should be clearly disclosed.

Companies should collect high quality ('primary') data from suppliers  and  other value  chain  partners  for  scope  3  activities  deemed  most  relevant  (i.e.  emissions  hotspots  by mode or region) and/or strategically targeted for GHG reductions. Chapter 7 of the GHG Protocol Scope 3 Standard provides further guidance on data quality issues; the Global  Logistics  Emissions  Council  (GLEC)  Framework  offers additional details for freight transport.

Regardless of the limitations around data quality, companies are encouraged to set science-based targets as soon  as  possible  to  have  a  likely  chance  to  reach  the goals of the Paris Agreement. Companies can have targets  in  place  while  continue  to  improve  their  reporting through  collaboration  with  suppliers.  Any  resulting  adjustments  that  lead  to  increases  or  decreases  in  emissions due to improvements in data quality needs to be transparent and justified.

## USER-SPECIFIC TARGET-SETTING GUIDANCE

## 3.1 COMPANIES THAT OWN / CONTROL VEHICLES

## 3.1.1  GHG emissions and activity

The emissions trajectories in the Mobility Model (MoMo) are  derived  from  a  series  of  mode  specific  technological  and  efficiency  assumptions  embedded  in  the  model across time. Although the SDA Transport tool uses these trajectories to assign targets to companies, the aim is not to prescribe any mitigation option in particular but to reach the emissions reductions required within a given temperature scenario to limit the most dangerous impacts of climate change.

To use the tool, companies must use WTW emissions accounting for all their transport operations. Usually companies  adhere  to  the  GHG  reporting  guidance  of  the  GHG Protocol.

Figure  1  shows  the  approximate  equivalence  between the  scopes  used  in  the  GHG  Protocol  and  the  WTW accounting.

Figure 1 Aggregation of scopes to obtain Well-to-Wheel emissions

<!-- image -->

Note: Tank-to-Wheel emissions are equivalent to scope 1 emissions.

Emissions from ports, storage rooms and other supportive  facilities  and  services  should  be  reported  under  the appropriate  scope  in  the  company's  GHG  inventory.  For the  purpose  of  the  modeling  exercise,  these  should  be excluded when using the SDA Transport tool. Companies can in fact, use other methods (sectorial or not-sectorial) to model targets for the company's non-transport emissions. In the end, the expectation is that company-wide targets will be set covering all GHG emissions sources.

MoMo  activity  projections  per  transport  mode  are  expressed either in passenger-kilometer (pkm) or tonne-kilometer units (tkm). The emissions intensity pathways constructed in the SDA Transport tool use these units, which are  based  on  global  average  occupancy  rates  and  load factors embedded in MoMo (See Annex II).

## BOX 1. GLEC Framework Guidance - idling, repositioning and empty running

All emissions related to the operation of vehicles should be included in the base year emissions of the  company.  This  includes  the  emissions  from idling,  repositioning  and  empty  running.  This  is common practice for scope 1 and scope 2 reporting, where empty running and idling is inherently included vis a vis the actual fuel use.

Carbon  intensity  calculations  should  take  the total  amount  of  fuel  used  for  both  loaded  and empty trips and divide it by the tonne-kilometers related to the actual useful work done (e.g., the loaded trips).

When using the tool, companies will be asked to provide pkm or tkm figures for all their global operations in the base year and target year selected. Companies may include the operating personnel in their pkm figures. Generally,  passenger  transport  companies  use  the  metric 'revenue  passenger  kilometer'  which  is  the  number  of kilometers  traveled  by  paying  passengers  (number  of revenue passengers multiplied by the total distance traveled).  Likewise,  companies  may  include  the  operating personnel and extra fuel when optionally carried in their tkm figures.

This is the so called 'payload distance' which refers only to revenue-generating cargo. Companies should publically disclose the assumptions on occupancy rates and load factors used to estimate their inventory's figures.

MoMo considers a number of decarbonization measures that  impact  the  global  growth  demand  assumption,  including 'shift' and 'avoid' measures. The extent to which polices drive measures leading  to avoidance of transport activity  or  modal  shifts  is  different  in  the  2DS  and  B2DS, therefore requiring different levels of policy interventions and technology deployment.

## 3.1.2  Target-setting approaches &amp; results interpretation

The principle of intensity convergence is used for almost all transport categories available in the tool (except aviation and shipping). The convergence approach is applied to homogeneous sectors (sectors that can be described with a common metric, eg. tkm, pkm), and assumes that the carbon intensity of a company converges towards the carbon intensity  of  the  sector  at  a  rate  that  ensures  not exceeding  the  emissions  scenario  carbon  budget.  The carbon budget can be that for 2ºC, well-below 2°C, or any other emissions scenario embedded in the tool.

The rate of intensity decarbonization is not the same for all companies within the sector. It is also important to mention that for companies already below the sector's intensity can still converge towards the sector's intensity in 2050, or continue a decarbonization trajectory below the sector's average without necessarily converging in 2050. As mentioned before, the sector trajectory is a global one, which intrinsically  requires  companies  below  the  sector's  average to continue on such trend.

Therefore, companies using the tool for transport activities should interpret the resulting goal as a function of the company's initial carbon intensity, the sector's decarbonization  trajectory  (e.g.  for  2°C  or  well  below  2°C)  and  the company's projected growth relative to the growth of the sector. The growth projection of the company is taken into account  to  estimate  the  market  share  parameter  in  the convergence equation.

Figure 2 shows the graphic interpretation of the emissions intensity convergence approach.

<!-- image -->

## Aviation &amp; Shipping

Aviation and shipping are an interesting case in the transport sector due to their international presence and the existence of global decarbonization goals for these two. In the case of aviation, the Air Transport Action Group (ATAG) set environmental goals for the short, medium and long-term in 2016, including: an annual efficiency goal for 2020, a goal to stabilize emissions growth from 2020 with the use of offsets, and  to  reduce  net  emissions  from  aviation  50%  by  2050 compared to a 2005 base-year (ATAG, 2018).

Since the SBTi does not allow the use of offsets to report progress against science-based targets, and since the sector's  50%  reduction goal (if  interpreted  as  gross  emissions) is  comparable  to  the  Intergovernmental  Panel  on  Climate Change (IPCC) 2°C minimum requirement at the global level, the SDA Transport tool uses a linear interpretation of the IPCC 2°C range which is between 49 and 72% reduction  15 .

Therefore,  the  tool  only  asks  for  tCO2e  figures  from  air transport-related activities in the base year, and no activity figures, as the target-setting approach is contraction. This approach requires all companies within a given sector, region or globally to reduce emissions at the same rate. The contraction approach will result in a company's trajectory parallel to the sector, regardless of the company's starting carbon footprint.

Figure 3 shows the graphic interpretation of the absolute emissions contraction approach.

Figure 3. Absolute emissions contraction approach.

<!-- image -->

For the same reasons than for aviation and to boost ambition in the short-term, the SDA Transport tool also uses the IPCC reduction range 49-72% (linear trajectory) to calculate targets for shipping activities. This range may be updated with the introduction of new science. Also, the SBTi will review new emissions trajectories for these sectors as they become available, for potential integration into the tool.

Manuel Pulgar-Vidal, leader of WWF's global climate and energy programme, said: 'The new goal of IMO is very welcome news, a good first step and an important policy signal. Shipping is responsible for more than 2 per cent of global emissions, and this is growing. The agreement today is an opportunity to bend this curve to align with the Paris Agreement, but it needs to translate into urgent action - now.'

In the case of shipping, the International Maritime Organization (IMO) recently reached an agreement for the sector that includes as for aviation, a target on emissions intensity by 2030, and a long term target to reduce emissions at least 50%  by  2050  compared  to  a  2008  base-year  (Greenbiz, 2018). The level of ambition for the sector goal may be increased in the future as negotiations continue, and in light with the 1.5°C upcoming IPCC report.

Even when using the contraction approach, a company can define an intensity target. The SBT tool calculates the required absolute emissions trajectory towards a target year. Together  with  sector-wide  or  company-specific  growth projections,  an  intensity  target  can  be  calculated  using the absolute emissions target level from the SBT tool and the company's projected activity in the target year. When companies commit to such an intensity target, it is essential to regularly review the growth projections. This should be done at least every five years, ideally even in shorter cycles. In addition, companies may not set a weaker target in the case of negative growth.

## BOX 2. Recommendations for companies that own / control vehicles

- · Logistics service providers, shippers and carriers using more than one transport mode (multimodal) would need to model their targets by using each of the transport modes in which it operates, by providing the share of activity for each of these and the projected growth. Since projections can change over time, companies are recommended to check the validity of their targets every five years, and adjust the targets accordingly.
- · Companies are encouraged to consider different mitigation options in line with the 'avoid, shift and improve' concept.
- · Companies are also encouraged to develop strategies to improve their service efficiency (for example, increasing the number of passenger per kilometer or the number of tonnes per kilometer as allowed by local regulations).

15 The range of percent decrease in emissions is due to uncertainty in emissions modeling projections. Additionally, a decrease of 49% is actually the lower threshold when recognizing that global net negative emissions would be required (-103 to -118%) in the second half of the century; Table 6.3 in Chapter 6 of the Fifth Assessment Report, Working Group III).

## 3.2 COMPANIES THAT SUBCONTRACT / PURCHASE TRANSPORT SERVICES

## 3.2.1  GHG emissions and activity

Emissions  from  transport  activities  that  occur  in  a  company's  value  chain  are  indirect  emissions  (scope  3)  that are reported by the company buying the services to fulfill its core business operations. These emissions are generally emissions from logistics operations (e.g. transportation of  raw  materials  or  finished  products)  or  business  travel. Companies using the SDA Transport tool for their scope 3 emissions in the value chain can use the trajectories available for companies that own / control vehicles.

Figure 4. Transport activities in the value chain (scope 3)

|                                         | Passenger transport                                        | Freight transport                                                                                             |
|-----------------------------------------|------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------|
| Scope 3. Categories in the GHG Protocol | Category 6: Business travel Category 7: Employee commuting | Category 4: Upstream transportation and distribution Category 9: Downstream transporta- tion and distribution |

Emissions and activity data (pkm or tkm) can be challenging  to  obtain  for  subcontracted  transport.  However,  the GLEC Framework provides guidance on how companies can estimate these figures from supplier's data. Nevertheless, in some cases it might be necessary to rely on default data that may not accurately represent actual transportation activities. Despite uncertainty, companies are encouraged to set targets while continue improving data quality.

As for scope 1 and 2, default data life cycle emissions factors should be considered as they normally include WTT and TTW emissions.

BOX 3. GLEC Framework Guidance - scope 3 guidance for idling, reposition and empty running

The GLEC Framework suggests three options for including  idling,  reposition  and  empty  running in  scope  3  absolute  emissions  calculations  (e.g. tonnes CO e): 2

- a)  Adopt an average load factor (e.g. 50%). If using a default factor, such as from Defra or the GLEC Framework, adjustments for empty running, repositioning and idling are embedded in the default values.
- b)  Adopt a company or region-specific load factor based on actual operating conditions.
- c)  Scale by loaded distances by appropriate factors to consider empty running.

In the case of logistics, the Smart Freight Centre through the GLEC Framework and other organizations are creating new collaboration platforms to gather more accurate / granular data in the supply chain:

http:/ /www.smartfreightcentre.org/

## 3.2.2  Target-setting approaches &amp; results interpretation

For categories 4 and 9 in the GHG Protocol, upstream and downstream  transportation  and  distribution,  companies can use the SDA Transport tool with the convergence approach  for  GHG  target-setting.  Alternatively,  companies may use the contraction approach with the IPCC 5th AR reduction range mentioned before. This second approach is recommended for transport emissions in the value chain when activity data is not available.

Company A commits to have 70% of its key suppliers by emissions (including transporting services) setting science-based targets by 2020.

The  SBTi  also  accepts  supplier  engagement  targets  to mainstream  science-based  targets  in  the value  chain  16 . A target language example is:

16 Please consult the SBTi criteria on supplier engagement targets.

For Categories 6 and 7, business travel and employee commuting,  an  absolute  approach  is  recommended  with  the IPCC  5th  AR  reduction  range.  Although  companies  could use the tool with the convergence approach to determine a target for these categories if emissions and activity data is available, the limited market share attributed in the tool to employee commuting and business travel will result in inappropriate targets; especially if the travel is sporadic.

## BOX 4. Recommendations for companies that subcontract / purchase transport services

- · In order to meet the 2DS and B2DS for freight transportation, systemic improvements in the near term are required. For example, by taking action in the supply chain, improving logistics and routing, and by deploying energy efficiency measures. Collaboration and coordination among shippers, logistics service providers and carriers is therefore crucial to decarbonize freight transport despite a projected growth in demand.
- · Companies are implementing strategies to reduce emissions from air travel, as it is one of the most carbon intensive modes. They do so, for example, by promoting the use of online meetings and web conferencing, and by implementing internal policies for employee travel. It is expected that corporate users of air travel compare the service providers in the market, not only based on economic factors, but also on environmental ones (e.g. preference for companies with a climate strategy including science-based targets).
- · Companies are starting to implement car-sharing programs with employees, to reduce emissions and to promote employee integration. Other strategies are based on incentive schemes to encourage employees to bike, walk or take the train to work.

## 3.3 ROAD VEHICLE MANUFACTURERS

## 3.3.1  GHG emissions &amp; activity

Use phase emissions from newly manufactured vehicles are indirect emissions (scope 3) that are reported by the manufacturing company that sells the vehicles. Use phase emissions of vehicle manufacturers is therefore part of the transport carbon budget. The SDA Transport tool only has pathways  for  road  vehicle  manufacturers  (WTW).  Emissions  during  manufacturing  are  not  covered  in  the  SDA Transport tool, nor emissions from battery manufacturing for electric vehicles.

Figure 5. Emissions covered in the pathways for newly manufactured vehicles.

<!-- image -->

Road vehicle manufacturers are required to test the emissions generation from the exhaust of newly produced vehicles.  Different  test  procedures  can  yield  performance figures that do not correspond to actual driving emissions.

Fuel economy of LDVs: The values used in the embedded pathways in MoMo are estimated through a normalization of regional test procedures to the Worldwide Harmonized Test Cycle (WLTP), based on the conversion factors developed by ICCT (ICCT, 2014)  17 . The assumed gap between the WLTP and real-world (on-road) emissions is 1.1 for all regions and at all times.

Note: As per the GHG Scope 3 Standard, Category 11 includes the total expected lifetime emissions from all relevant products sold in the reporting year across the company's product portfolio. A reporting company's scope 3 emissions from use of sold products include the scope 1 and scope 2 emissions of end users, and it uses life cycle emission factors for fuels and for electricity.

According to the IEA (OECD/IEA, 2017), to be able to meet the 2DS targets, it is necessary to reduce the gap between tested  and  on-road  fuel  economy.  Moving  towards  the WLTP  would  better  reflect  real-world  vehicle  operation. Therefore,  for  science-based  target-setting,  companies must use the adjustment factors / formulas of the WLTP to obtain real / actual emissions if using a different standard.

17 The IEA specifically used equation 4.2 (Single regression with zero intercept - all data), with the slopes given in table 5.2 (Single regression with zero intercept)..

Fuel economy of HDVs: From the IEA's report The Future of Trucks (IEA, 2017): 'Estimations of the fuel economies for LCVs, MFTs and HFTs relied primarily on research on tested and real-world specific fuel consumption under various drive cycles, vehicle loads and mission profiles, largely leveraging on the analysis recently developed by the ICCT for the Global Fuel Economy Initiative (GFEI, 2016), complemented by information on the fuel consumption of vehicles reported by communities of vehicle users, such as those reviewed by Tietge et al. (2015) in the case of cars.'

As with LDVs, for LCVs a 1.1 conversion factor is used in the MoMo and the values are for the WLTP test cycle. For MFTs and HFTs, the values are real-world operations, under representative loads.

## Well-to-Wheel emissions

The emissions pathways built in the SDA Transport tool for the manufacturing of new road vehicles is composed by WTT emissions from stock vehicles, and by TTW emissions for new vehicles (mix of power trains). The former was taken as an approximation because MoMo does not have  WTT  emissions  for  newly  manufactured  vehicles. The WTW approach reflects the shift of emissions from one scope to another, for example due to electrification. The WTW emissions pathways are then divided by the activity in vkm for new vehicles to build the intensity pathways.

In absence of a normalized test procedure for MFTs and HFTs,  companies  are  invited  to  present  and  justify  their own estimates / simulations based on fuel consumption specific duty cycles to the SBTi.

As  companies  make  assumptions  for  the  type  of  fuels plugged into the fuel tanks, original equipment manufacturers (OEMs) can also make assumptions of the average grid electricity factors for their sales across markets.

## 3.3.2  Target-setting approaches &amp; results interpretation

Manufacturers of LDVs and HDVs can use the SDA Transport  tool  directly  for  scope  3  GHG  target-setting  (convergence approach).

## BOX 5. Recommendations for road vehicle manufacturers

The carbon intensity of new vehicles (per transport category) will converge towards the carbon intensity pathway for new vehicles  18 . These pathway differ from those applied to companies that own or control vehicles, since they exclude the stock vehicles emissions.

The unit used in the convergence formula is gCO2e/vkm 19 . Manufacturers are encouraged to use the occupancy rates factors and load factors of MoMo (Annex II) to covert target year results from vkm to pkm or tkm.

Vehicle manufacturers producing different vehicle types must aggregate their intensity figures to set a companywide  science-based  target  for  their  scope  3  emissions. Example:

Company A commits to reduce the emissions intensity (gCO e/vkm) of its product portfolio X% by 2 2030 from a 2015 base-year.

The  SDA Transport  tool  also  provides  the  possibility  for road  vehicle  manufacturers  to  obtain  results  in  liters  of gasoline equivalent per 100 kilometers (lge/100 km). This metric purely reflects the fuel economy of new vehicles (TTW portion). The lge numerator already reflects the effect of power train electrification.

- 1. Check the validity of your targets. To ensure consistent tracking of performance over time, the target should be recalculated to reflect significant changes that would compromise its relevance and consistency. For example, changes in growth projections, significant changes in the mix of products, company structure (e.g. mergers, divestments), and other relevant assumptions used in the target modeling exercise.
- 2. Engage with regulators to promote demand of more efficient low or zero carbon vehicle types.
- 3. Explore new business models. Electrification of road transport is required to meet the 2DS and B2DS goals. Therefore, the decarbonization of the power sector and the development of a smart grid systems (including vehicle-to-grid technologies) will require close collaboration among governments, users and solutions providers.

## 3.4 COMPANIES THAT MANUFACTURE ROAD VEHICLE PARTS

## 3.4.1  GHG emissions and activity

For  auto  part  manufacturers, the  use  of  sold  products may  give  rise  to  either  direct  or  indirect  emissions  in scope 3 category 11 depending on the application of the auto part. While it is more common for vehicle manufacturers, in reality  a  vehicle  is  composed  of  a number  of  components  /  auto  parts  that  contribute  to the consumption of energy in the vehicle. Some components contribute more than others to the ultimate vehicle  emissions,  and  the  determination  of  the  exact percentage contribution can be complicated.

Under  the  GHG  Protocol,  companies  are  required  to report direct use phase emissions, and may also include indirect-use  emissions  when  these  are  expected  to  be significant. However, there is no guidance on significance thresholds.  Therefore,  indirect  use-phase  emissions  of auto part manufacturers are of voluntary reporting.

For auto part manufacturers reporting these emissions, the recommendation is to use WTW emissions factors, as vehicle manufacturers.

## BOX 6. Michelin's scope 3 emissions

According to Michelin's research, the tire's contribution to fuel consumption is between 20 and 25%  for  passenger  cars,  and  30-35%  for  trucks. A fraction of this is used to overcome the rolling resistance,  the  rest  of  the  energy  is  consumed within the dynamic elements of a vehicle.

Michelin reports on these emissions every year as a key part of their climate strategy. The company  is  working  with  its  researchers  to  further push the boundaries of rolling resistance of its tires to reduce energy consumption and therefore emissions.

These improvements must be balanced by regulatory  limits,  since  there  is  a  trade-off  between improving rolling resistance and safety.

There  are  different  levers  of  decarbonization  that  can reduce  the  energy  needs  in  a  vehicle,  for  example: improved aerodynamics, reduced rolling resistance, weight  reductions,  internal  combustion  (ICE)  efficiency gains, enhanced powertrain efficiency, etc. Together with vehicle  manufacturers, auto part manufacturers can work  towards  influencing  one  or  more  of  these  levers to different degrees.

Michelin and WWF are currently exploring a target-setting approach based on the assumption of current and long-term fuel consumption contribution from tires across vehicles with different powertrains.

## 3.4.2  Target-setting approaches &amp; results interpretation

During the development of the SDA Transport tool, the possibility  of  building  a  science-based  pathway  for  auto  part manufacturers was considered. Such an exercise would require a more in-depth analysis and understanding of the assumptions in MoMo.

In  the  absence  of  2°C/Well-below  2°C  pathways  for  auto part manufacturers, companies can use other approaches for target-setting:

The aggregation level in MoMo does not currently allow the development  of  specific  pathways  for  different  auto  part manufactures. An approach for tire manufacturers is being explored. The pathway would reflect the contribution of tires to the fuel consumption of the vehicle (different per power train)  and  the  need to decarbonize the transport sector in line with a well-below 2°C world.

- · Absolute emission reduction targets that are consistent with the level of decarbonization required to keep global temperature increase below 2°C compared to pre-industrial temperatures.
- · Ambitious performance-based targets that contribute to the reduction of energy needs in a vehicle.

18 This method is not applicable to companies with a product portfolio that already yields a zero emissions footprint in the TTW part (e.g. EV manufacturers), although they are welcome to apply to and participate in the SBTi.

19   The assumed average lifetime of road vehicles in MoMo  varies by vehicle type, region, and over time. The assumed average global kilometers per year can be found in Annex III,

<!-- image -->

## METHODOLOGICAL CHOICES

## 4.1 SELECTION OF DECARBONIZATION SCENARIOS FROM THE INTERNATIONAL ENERGY AGENCY

The International Energy Agency low carbon scenarios are created using the ETP-TIMES model (OECD/IEA, 2017). It is used to determine the least-cost technology mix needed to meet the final demand for three sectors: industry, transport, and buildings.

pathways; and electricity (with emissions according to the average national generation mix as modelled by the ETPTIMES model in the relevant scenario).

The  ETP-TIMES  model  starts  from  primary  energy  supply and conversion to final energy demand up to 2060. It models the current situation in the conversion sectors (e.g. existing capacity stock, operating costs, and conversion efficiencies) and then integrates the technical and economic characteristics of existing technologies that can be added to the energy system. In this way it can determine the least-cost  technology  mix  needed to meet the final demand. This final demand is determined by the sub-models of  the  specific  end-use  sectors.  The  transport  sector  is modeled with Mobility Model (MoMo).

MoMo is a simulation model of detailed transport activity projections, vehicle activity, energy demand, and well-towheel greenhouse gas (GHG) and pollutant emissions according to user-defined policy scenarios to 2060.

It integrates 27 countries and regions, historical data from 1975 to 2015 (or 1990 to 2015 for certain countries). It models future trends over five-year steps to create scenarios to the year 2060, which are integrated into the broader ETP framework using a combination of 'what if' analysis expert judgment and backcasting. It has national and regional resolution split for both urban and   non-urban geographies into parameters including vehicle stock, activity, energy use and emissions; passenger and transport services by major motorized transport modes (including a wide range of power train technologies), as well as fuel supply options: gasoline and diesel, biofuels (ethanol and biodiesel via various production pathways) and synthetic alternatives to liquid fuels (coal-to-liquid and gas-to-liquid); gaseous fuels, including natural gas (CNG and liquefied petroleum gas) and hydrogen via various production

MoMo estimates on energy use are based on stocks, utilization  (travel  per  vehicle),  and  vehicle  energy  intensity (energy use per vehicle, i.e. fuel economy). Emissions are calculated via fuel emission factors for CO2 and pollutants on a vehicle and well-to-wheel basis for all modes. The results of the modeling exercise are validated and calibrated against the IEA's energy balances.

Cost evolution  of  technology,  policy  frameworks  and  oil prices are the primary drivers of technology penetration in transport. In each scenario, the model aggregates the total costs across modes and regions of vehicle production, operations and maintanence, fuel  outlays, and infrastructure investments.

## To learn about MoMo:

https:/ /www.iea.org/etp/etpmodel/transport/

To learn about the major assumptions in the IEA's mod- eling (GDP, oil prices and population growth): https:/ /www.iea.org/etp/etpmodel/assumptions/

To learn more about the penetration of road vehicle technologies:

https:/ /www.iea.org/topics/transport/

MoMo  adopts  the  'avoid,  shift  and  improve'  paradigm through  the  assumptions  made  on  technologies  and policies.    Technological  drivers  in  the  model  are  mainly assumptions on the cost evolution of the technology and the policy framework. Elasticities and case studies on policy impacts are used to model the behavioural response to  pricing,  regulatory,  and other policies (such as investment in compact cities or public transit infrastructure  or fare subsidies). These factors together with oil prices can significantly alter technology penetration patterns.

The ETP 2017 describes the potential role and impact of the 'autonomous and connected vehicles, electrification, and  sharing'  (ACES),  yet  it  recognizes  that  to  date,  the magnitude  of  their  effects  and  the  direction  of  mobility patterns, energy use and emissions it still uncertain and it can only be speculated on.

The IEA Mobility Model (MoMo) was selected as the modeling scenario for the following reasons:

- · Compatibility with IEA ETP sectoral budgets (basis for SDA tool): The Sector Decarbonization Approach uses the sector carbon budgets and activity projections from the IEA's annual publication: Energy Technology Perspectives (ETP) Report (OECD/IEA, 2017). IEA's modeling includes energy, industry, buildings and transport. The transport part is derived from the Mobility Model exercise. Table 3 shows the carbon budget of the 2DS and B2DS in the ETP report.
- · Availability of both B2DS and 2DS scenarios: According to the Paris Agreement global emissions need to be reduced at a level to hold the increase in the global average temperature to well below 2°C above pre-industrial levels and to pursue efforts to limit the temperature increase to 1.5°C above pre-industrial levels, recognizing that this would significantly reduce the risks and impacts of climate
- change. Therefore, the SBTi encourages companies to set targets in line with these temperature thresholds. At the time of this project, the IEA's work was the closest readily available model that introduced the 'well below 2°C' pathway. The IEA's B2DS scenario when projected to 2100 is expected to lead to 1.75°C temperature outcome with a 50% chance.
- · Its mitigation levers are transparent: Although MoMo is only available through a License Agreement, its assumptions, including mitigation levers, can be tracked through the publicly available spreadsheets and the ETP Report. As for any other model, it is a perfectible model that it is updated every year through peer-review by experts in the field and the MoMo partners.
- · It covers both passenger and freight transport: The main objective of the SDA tool refinement for the transport sector was to be as comprehensive as possible. The refinement and inclusion of passenger and freight transport pathways will not only facilitate the modeling of SBTs for vehicle owners, but also for other companies highly dependent on logistics services and for road vehicle manufacturers. MoMo's level of disaggregation is suitable to derive subsector pathways per transport mode.

Table 3. CO  budget assumptions in the 2DS and BD2DS (GtCO ). 2 2

| SCENARIO   | Total CO 2 budget (2015-2100)   |   LULUCF (2015-2100) | Energy sector CO 2 budget (2015 -2100)   | Energy sector CO 2 budget (2015-2060)   |
|------------|---------------------------------|----------------------|------------------------------------------|-----------------------------------------|
| 2DS        | 1,140                           |                  -30 | 1,170*                                   | 1,000*                                  |
| B2DS       | 720                             |                  -30 | 750                                      | 750                                     |

* Includes emissions from industrial processes and fuel combustion. Source: IEA- ETP, 2017

## BOX 7. The IEA's 2DS and B2DS modeling in a nutshell

decarbonization, not only through reducing emissions intensity, but also absolute emissions.

Excerpt  from  the  IEA's  Energy  Technologies  Perspectives Report 2017:

- · The final energy demand in the B2DS is around 45 EJ (10%) lower than the 2DS in 2060 and marginally lower (4%) than 2014 levels.
- · Final energy demand in the B2DS reflects the significant role of electrification of end-use sectors (particularly ground transport and buildings) in order to achieve this ambitious pathway.
- · Oil experiences the greatest decline in its share, from almost 40% in 2014 to 16%, an absolute decline of 96 EJ, reflecting the shift away from petrol- and diesel-fueled vehicles.
- · In the B2DS, WTW emissions from transport have to decrease by 89% by 2060 compared to 2015 emissions, while in the 2DS 54% over the same time frame. All transport modes must contribute to
- · The transport sector provides over 50 GtCO  of ad2 ditional emissions reductions compared with the 2DS, primarily through energy efficiency (57%), fuel switching (28%) and renewables (15%).
- · The role of biofuels in transport is lower in the B2DS than in the 2DS in 2060 - 24 EJ compared with 30 EJ - due in part to a 20% overall reduction in transport energy demand between the two scenarios.
- · A 1.75°C pathway would require the emissions intensity of power generation to fall from around 520 gCO /kWh today to become carbon negative, 2 at -10 gCO /kWh, in 2060. 2
- · Scenario estimates of total expenditure on vehicles, infrastructure and fuels show that the cumulative costs of transport in the RTS are about USD 130 trillion (2015 USD PPP) higher than those of the 2DS, and USD 110 trillion higher than in the B2DS.

## 4.2 SECTORAL DECARBONIZATION APPROACH (SDA)

The Sectoral Decarbonization Approach (SDA) tool was developed by the SBTi partners with technical support from Ecofys. The SDA tool allocates the energy-related carbon budget to different sectors. The allocation takes into account inherent differences among sectors, such as mitigation potential and how fast each sector can grow relative to economic and population growth.

allocation method. The assumption is that the emissions intensity of each company in the same sector will converge with the sector emissions intensity by 2050.

Within each sector, companies can derive their sciencebased targets based on their relative contribution to the total  sector  activity  and  their  carbon  intensity  relative  to the sector's intensity in the base year. Therefore, the rate of reduction varies per company depending on how close their intensity is at present compared to the sector. Using the detailed sector scenarios from the IEA's 2DS and B2DS models, it is possible to estimate the 2DS or B2DS compatible carbon intensity for each sector scenario by dividing the total direct emissions of the sector in any given year by the total activity of the sector in the same year. This yields a sector intensity pathway.

For homogeneous sectors physical activity indicators - for example,  tons  of  cement,  passenger-kilometers  (pkm), kilowatt-hours (KWh) - convergence is used as the carbon

## 4.2.1  Convergence

In designing the SDA method for all sectors, it was anticipated that, in the long run, large companies will have equal opportunities to abate the GHG emissions of their activities. To reduce GHG emissions, three elements are important to consider: (1) the energy efficiency of the process; (2) the carbon intensity of the energy used; and, (3) the emis-

## 4.2.2  Market share parameter

One of the parameters used in the convergence approach for homogeneous sectors is the company's expected activity growth. This input parameter is used in the SDA tool to estimate the company's market share compared to the sector's  total  activity  in  any  given  year  (selected  target year).

After  beta-testing  the  first  SDA  Excel  tool,  stakeholders raised the potential threat of over allocating the carbon budget when companies underestimate their growth. To prevent this situation, the SBT team introduced a cap to the  market  share  parameter,  only  in  cases  in which  the company  projects  to  decrease  their  market  share  (any market  parameter  above  1.00  is  brought  down  to  1.00). In  all  other  cases,  the  decarbonization pathway is main-

A company's intensity pathway-given by the SDA toolmultiplied  by  their  projected  activity  yield  a  company's carbon budget in absolute terms for the target period. In principle, the sum of these budgets should be contained within  the  sector  projected  budget  given  by  the  IEA  in each of the above-mentioned scenarios.

The pathways built in the SDA Transport tool are based on the  MoMo's figures  for  stock vehicles.  Stock vehicles  are those  already  in  circulation  plus  the  new  additions  each year.  Emissions  are  Well-to-Wheel  (WTW)  reflecting  not only the direct use emissions from fuel combustion (TTW: Tank-to-Wheel) but also upstream emissions related to fuel production and distribution (WTT: Well-to-Tank), as well as electricity generation for electric vehicles.

The WTW emissions pathways are then divided by the corresponding activity (pkm, tkm) to build the intensity pathways. The WTW approach reflects the shift of emissions from one scope to another, for example due to electrification.

sions related to the process and its design. Although there are still differences in energy efficiency among world regions, these differences will tend to disappear in the long term because of the convergence of the energy efficiency technologies, as shown by historic trends (WRI, CDP, WWF, 2015).

tained as if the market share remained constant throughout  the  target  period. This  safeguard  is  deemed  robust and justifiable since it preserves the carbon budget integrity. Since the tool came after the SDA technical paper was published in  2014,  this  safeguard  is  not  captured  in  the notes of the document.

According to Krabbe, et. al. (2015): 'The intensity pathways of the fast-growing companies are steepened to account for their increase in market share. If this is not accounted for, the sector average intensity will increase owing to the growth, resulting in an exceedance of the sector's carbon budget. The opposite happens to the intensity pathways of the companies that show a decreasing market share. Although this might seem unrealistic or unfair, it  makes

sense from a business perspective, because when a company's market share is decreasing, it will probably invest less in new, more efficient technologies, and vice versa.'

## 4.2.3  Sector developments

Some of the benefits of setting targets using a sector-specific method are the possibility of setting targets based on a common intensity unit used by peers (transparency), and the possibility to capture the mitigation opportunities and associated costs available for the sector (tailored).

However, acknowledging that some sectors are still highly aggregated, the Science Based Targets Initiative is working on other sector developments, and invites interested stakeholders  to  contribute  to  the  development  of  new sector pathways in line with the Paris Agreement goals.

## 4.3 Carbon accounting methodologies

Science-based targets (SBTs) are based on the emissions calculated and reported by the company. As such, a target is only as good as the emissions data that feeds the model. Companies adopting SBTs will need to calculate emissions intensity and absolute emissions values for each transport mode.

To promote comparability and transparency of emissions calculations, three methodologies are encouraged:

<!-- image -->

<!-- image -->

## For general GHG reporting guidance and passenger transport: Greenhouse Gas Protocol

Developed by the World Resources Institute and the World Business Council for Sustainable Development, the Greenhouse Gas Protocol is considered baseline methodology for carbon accounting and reporting, and is widely used by industry. The SBT has adopted the Corporate Accounting and Reporting Standard for scope 1 emissions and the Corporate Value Chain Accounting and Reporting Standard for scope 3 (WRI &amp; WBCSD, 2004 and WRI &amp; WBCSD, 2011, respectively).

The methodology provides a 'basic training' on carbon accounting that is useful for understanding the terminologies, creating a plan for setting up accounting systems, and provides default factors where data are unknown. The GHG Protocol is the base methodology for CDP reporting.

## For products GHG reporting guidance: Greenhouse Gas Protocol

Developed  by  the  World  Resources  Institute  and  the  World  Business  Council  for  Sustainable  Development,  the  GHG  Protocol  Product  Life  Cycle Accounting and  Reporting  Standard  (referred  to  as  the  Product  Standard)  provides  requirements and guidance for  companies  and  other  organizations  to  quantify  and  publicly  report  an  inventory  of  GHG  emissions  and  removals  associated  with  a  specific  product.  The  primary  goal  of  this  standard  is  to  provide  a  general  framework for  companies  to  make  informed  choices  to  reduce  greenhouse  gas  emissions from  the  products  (goods  or  services)  they  design,  manufacture,  sell,  purchase, or  use.  The  GHG  Protocol  Scope  3  Standard  and  GHG  Protocol  Product  Standard both take a value chain or life  cycle  approach  to  GHG  accounting  and were developed simultaneously.

The  convergence  formula,  including  the  market  share parameter, comply with the following condition: for every year the sum of all individual company emissions targets does not exceed the sector's total carbon budget.

<!-- image -->

## For freight transport specific guidance: Global Logistics Emissions Council Framework

Developed by Smart Freight  Centre,  the  Global  Logistics  Emissions  Council  (GLEC) Framework (Smart Freight Centre, 2015) is built in accordance with the GHG Protocol and includes guidance specific to the logistics sector and its customers. It covers all regions, modes of transport and scopes, and includes a set of default factors specific to freight transport. The GLEC Framework will be the methodology for freight transport, alongside the GHG Protocol, in the new 2018 CDP transport questionnaire.

## 4.4 Well to Wheel emissions boundary

The boundary for GHG inventories and reductions targets should be as wide and accurate as possible.  Emissions not covered under a target cannot be managed / reduced.

scenario-specific  estimated  average  grid  carbon  intensity) (OECD/ IEA, 2017). TTW emissions cover the energy used once transformed (e.g. combustion of the fuel during vehicle use). Together these form the WTW emissions.

The emissions from the use of a vehicle consists of WTT and TTW emissions. WTT emissions occur upstream in the value chain of the fuel production; these are based on attributional life-cycle assessment studies of fossil-derived fuels  (e.g. gasoline,  diesel,  compressed  and  liquefied natural gas), biofuels and electricity (based on time -and

The SBTi requires companies to cover WTW emissions for GHG target-setting,  as  more  opportunities  for  mitigation are captured in a WTW basis, as well as the shift of emissions between TTW and WTT due to the switch in power train technologies.

5

## ANNEX

## Annex I. Default factors for fuel consumption and emissions

The Smart Freight Centre has produced an excellent compendium of consumption factors per tonne-kilometer for logistics in the GLEC Framework: Module 1. Default consumption factors and sources .

Also, Smart Freight Centre commissioned VTT Technical Research Centre of Finland to review the sources of fuel emissions factors used in standards, databases and methodologies, in the transport / logistics sector: Module 2: Fuelbased emissions factors.

Many of the sources listed by the SFC have also information on passenger transport:

- · http:/ /www.smartfreightcentre.org/glec/what-is-glec

The GHG Protocol also provides a life-cycle data bases and tools across sectors.

- · http:/ /www.ghgprotocol.org/life-cycle-databases
- · http:/ /www.ghgprotocol.org/calculation-tools

The MoMo 2017 uses the WTT emissions factors from the JRC Concawe 2011 study.

- · http:/ /iet.jrc.ec.europa.eu/about-jec/downloads

Global electricity intensity in  MoMo 2017:

| Intensity - Electricity generation (kgCO2/MWh), World   |   Intensity - Electricity generation (kgCO2/MWh), World |   Intensity - Electricity generation (kgCO2/MWh), World |   Intensity - Electricity generation (kgCO2/MWh), World |   Intensity - Electricity generation (kgCO2/MWh), World |   Intensity - Electricity generation (kgCO2/MWh), World |   Intensity - Electricity generation (kgCO2/MWh), World |   Intensity - Electricity generation (kgCO2/MWh), World |
|---------------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------|
|                                                         |                                                 2014    |                                                 2025    |                                                 2030    |                                                 2035    |                                                 2040    |                                                 2045    |                                                 2050    |
| 2DS                                                     |                                                  572.02 |                                                  360.85 |                                                  245.22 |                                                  150.87 |                                                   97.38 |                                                   55.77 |                                                   36.5  |
| B2DS                                                    |                                                  572.02 |                                                  330.18 |                                                  228.79 |                                                  140.69 |                                                   71.91 |                                                   20.35 |                                                   -8.02 |

## Annex II. Average occupancy rates and load factors used in MoMo, 2017

| Freight load (tonne per vkm), World, 2DS   | Freight load (tonne per vkm), World, 2DS   | Freight load (tonne per vkm), World, 2DS   | Freight load (tonne per vkm), World, 2DS   | Freight load (tonne per vkm), World, 2DS   |
|--------------------------------------------|--------------------------------------------|--------------------------------------------|--------------------------------------------|--------------------------------------------|
|                                            | 2015                                       | 2020                                       | 2025                                       | 2030                                       |
| 2-3 Wheelers                               | 0.24                                       | 0.24                                       | 0.23                                       | 0.22                                       |
| Light vehicles                             | 0.68                                       | 0.71                                       | 0.73                                       | 0.76                                       |
| Large road                                 | 12.30                                      | 13.10                                      | 13.73                                      | 14.09                                      |
| Rail                                       | 1,613.02                                   | 1,603.25                                   | 1,594.61                                   | 1,588.46                                   |
| Shipping                                   | 20,496.07                                  | 21,051.66                                  | 21,359.83                                  | 21,769.62                                  |

| Freight load (tonne per vkm), World, B2DS   | Freight load (tonne per vkm), World, B2DS   | Freight load (tonne per vkm), World, B2DS   | Freight load (tonne per vkm), World, B2DS   | Freight load (tonne per vkm), World, B2DS   |
|---------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|
|                                             | 2015                                        | 2020                                        | 2025                                        | 2030                                        |
| 2-3 Wheelers                                | 0.24                                        | 0.24                                        | 0.23                                        | 0.22                                        |
| Light vehicles                              | 0.68                                        | 0.71                                        | 0.75                                        | 0.79                                        |
| Large road                                  | 12.30                                       | 13.17                                       | 13.97                                       | 14.55                                       |
| Rail                                        | 1,613.02                                    | 1,603.25                                    | 1,594.61                                    | 1,588.46                                    |
| Shipping                                    | 20,496.07                                   | 21,007.56                                   | 21,295.55                                   | 21,673.05                                   |

| Passenger load (people per vkm), World, 2DS   |   Passenger load (people per vkm), World, 2DS |   Passenger load (people per vkm), World, 2DS |   Passenger load (people per vkm), World, 2DS |   Passenger load (people per vkm), World, 2DS |
|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|
|                                               |                                       2015    |                                       2020    |                                       2025    |                                       2030    |
| 2-3 Wheelers                                  |                                          1.17 |                                          1.17 |                                          1.17 |                                          1.17 |
| Light vehicles                                |                                          1.59 |                                          1.62 |                                          1.62 |                                          1.6  |
| Large road                                    |                                         15.11 |                                         15.46 |                                         15.71 |                                         15.87 |
| Rail                                          |                                        349.11 |                                        353.84 |                                        353.32 |                                        340.16 |

| Passenger load (people per vkm), World,   |         |         |         |    B2DS |
|-------------------------------------------|---------|---------|---------|---------|
|                                           | 2015    | 2020    | 2025    | 2030    |
| 2-3 Wheelers                              |    1.17 |    1.17 |    1.17 |    1.17 |
| Light vehicles                            |    1.59 |    1.62 |    1.62 |    1.6  |
| Large road                                |   15.11 |   15.42 |   15.61 |   15.62 |
| Rail                                      |  349.11 |  353.04 |  350.49 |  333.6  |

## Annex III. Assumed average km per year for road vehicles

From  MoMo 2017:

| Passenger mileage (thousand km/year per vehicle), World, 2DS   |   Passenger mileage (thousand km/year per vehicle), World, 2DS |   Passenger mileage (thousand km/year per vehicle), World, 2DS |   Passenger mileage (thousand km/year per vehicle), World, 2DS |   Passenger mileage (thousand km/year per vehicle), World, 2DS |
|----------------------------------------------------------------|----------------------------------------------------------------|----------------------------------------------------------------|----------------------------------------------------------------|----------------------------------------------------------------|
|                                                                |                                                        2015    |                                                        2020    |                                                        2025    |                                                        2030    |
| 2-3 Wheelers                                                   |                                                           7.18 |                                                           7.26 |                                                           7.23 |                                                           7.22 |
| Light vehicles                                                 |                                                          13.56 |                                                          13.1  |                                                          12.77 |                                                          12.55 |
| Large road                                                     |                                                          31.1  |                                                          30.14 |                                                          29.74 |                                                          29.42 |

| Freight mileage (thousand km/year per vehicle), World, 2DS   |   Freight mileage (thousand km/year per vehicle), World, 2DS |   Freight mileage (thousand km/year per vehicle), World, 2DS |   Freight mileage (thousand km/year per vehicle), World, 2DS |   Freight mileage (thousand km/year per vehicle), World, 2DS |
|--------------------------------------------------------------|--------------------------------------------------------------|--------------------------------------------------------------|--------------------------------------------------------------|--------------------------------------------------------------|
|                                                              |                                                      2015    |                                                      2020    |                                                      2025    |                                                      2030    |
| 2-3 Wheelers                                                 |                                                         6.56 |                                                         6.65 |                                                         6.92 |                                                         7.23 |
| Light vehicles                                               |                                                        16.06 |                                                        15.55 |                                                        15.36 |                                                        15.56 |
| Large road                                                   |                                                        27.18 |                                                        26.7  |                                                        26.66 |                                                        26.96 |

| Passenger mileage (thousand km/year per vehicle), World, B2DS   |   Passenger mileage (thousand km/year per vehicle), World, B2DS |   Passenger mileage (thousand km/year per vehicle), World, B2DS |   Passenger mileage (thousand km/year per vehicle), World, B2DS |   Passenger mileage (thousand km/year per vehicle), World, B2DS |
|-----------------------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------|
|                                                                 |                                                         2015    |                                                         2020    |                                                         2025    |                                                         2030    |
| 2-3 Wheelers                                                    |                                                            7.18 |                                                            7.25 |                                                            7.23 |                                                            7.17 |
| Light vehicles                                                  |                                                           13.56 |                                                           13.03 |                                                           12.64 |                                                           12.11 |
| Large road                                                      |                                                           31.1  |                                                           30.16 |                                                           29.86 |                                                           29.81 |

| Freight mileage (thousand km/year per vehicle), World, B2DS   |   Freight mileage (thousand km/year per vehicle), World, B2DS |   Freight mileage (thousand km/year per vehicle), World, B2DS |   Freight mileage (thousand km/year per vehicle), World, B2DS |   Freight mileage (thousand km/year per vehicle), World, B2DS |
|---------------------------------------------------------------|---------------------------------------------------------------|---------------------------------------------------------------|---------------------------------------------------------------|---------------------------------------------------------------|
|                                                               |                                                       2015    |                                                       2020    |                                                       2025    |                                                       2030    |
| 2-3 Wheelers                                                  |                                                          6.56 |                                                          6.66 |                                                          6.93 |                                                          7.29 |
| Light vehicles                                                |                                                         16.06 |                                                         15.49 |                                                         15.25 |                                                         15.38 |
| Large road                                                    |                                                         27.18 |                                                         26.46 |                                                         26.42 |                                                         26.51 |

## GLOSSARY

## Carbon dioxide emission budget (or carbon budget):

For a given temperature rise limit, for example a  2°C long-term  limit,  the  corresponding  carbon  budget reflects  the  total  amount  of  carbon  emissions  that can be emitted for temperatures to stay below that limit. Stated differently, a carbon budget is the area under a carbon dioxide (CO ) emission trajectory that 2 satisfies  assumptions  about  limits  on  cumulative emissions estimated to avoid a certain level of global mean surface temperature rise.

Carbon dioxide equivalent (CO e): 2 A way to place emissions of various radiative forcing agents on a common  footing  by  accounting  for  their  effect  on  climate. It describes, for a given mixture and amount of greenhouse gases, the amount of CO  that would 2 have the same global warming ability, when measured over a specified time period.

Sectoral  Decarbonization  Approach  (SDA): The  SDA is  differentiated  from  other  existing  science-based target methods by virtue of its subsector-level approach  and  global  least-cost  mitigation  perspective, in line with the carbon budget related to a given temperature goal. Currently, the SDA tool uses the sector  decarbonization  trajectories  of  the  International Energy Agency (IEA).

Convergence  approach  used  in  the  Sectoral  Decarbonization Approach (SDA): The convergence approach  for  homogeneous  sectors  in  the  SDA  is based on the assumption that the carbon intensity of a company convergences towards the carbon intensity of the sector at a rate that ensures not exceeding the sectoral carbon budget. The rate of convergence of a company is a function of the initial carbon intensity of the company, the carbon intensity of the sector,  and  the  growth  of  the  company  relative  to the growth of the sector.

Contraction approach used in the Sectoral Decarbonization Approach (SDA): The contraction approach assigns to companies the same percentage of absolute emission reductions as is required for the sector selected within a given time period.

Scenario: A  description  of  how  the  future  may  unfold based  on  'if-then'  propositions.  Scenarios  typically include  an  initial  socio-economic  situation  and  a description  of  the  key  driving  forces  and  future changes in emissions, temperature or other climate change-related variables.

Integrated  assessment  models: Models  that  seek  to combine  knowledge  from  multiple  disciplines  in the form of equations and/or algorithms in order to explore complex environmental problems. As such, they describe the full chain of climate change, from production of greenhouse gases to atmospheric responses. This necessarily includes relevant links and feedbacks between socio-economic and biophysical processes.

## International Energy Agency (IEA), 2°C scenario (2DS):

The 2°C Scenario (2DS) lays out an energy system pathway and a CO  emissions trajectory consistent 2 with at least a 50% chance of limiting the average global temperature increase to 2°C by 2100. Annual energy-related CO  emissions are reduced by 70% 2 from today's levels by 2060, with cumulative emissions of around 1,170 gigatonnes of CO  (GtCO ) be2 2 tween  2015  and  2100  (including  industrial  process emissions). To stay within this range, CO  emissions 2 from fuel combustion and industrial processes must continue their decline after 2060, and carbon neutrality  in  the  energy  system  must  be  reached  before  2100.

In transport, this reflects clear policy choices favouring  less  energy  intensive  modes,  the  rapid  uptake of  all  cost-effective  energy efficiency opportunities and the transition towards a much higher reliance on low-carbon energy carriers by 2060.

## International Energy Agency (IEA), Beyond 2°C scenario

(B2DS): The  Beyond  2°C  Scenario  (B2DS)  explores how far deployment of technologies that are already available or in the innovation pipeline could take us beyond the 2DS. Technology improvements and deployment are pushed to their maximum practicable limits across the energy system in order to achieve net-zero emissions by 2060 and to stay net zero or below thereafter, without requiring unforeseen technology breakthroughs or limiting economic growth.

This  'technology  push'  approach  results  in  cumulative  emissions  from  the  energy  sector  of  around 750  GtCO   between  2015  and  2100, which  is  con2 sistent  with  a  50%  chance  of  limiting  average  future temperature increases to 1.75°C. Energy sector emissions  reach  net  zero  around  2060,  supported by  significant  negative  emissions  through  deployment of bioenergy with carbon capture and storage (CCS).  The  B2DS  falls  within  the  Paris  Agreement range  of  ambition,  but  does  not  purport  to  define a  specific  temperature  target  for  'well  below  2°C'. In  transport,  this  requires  even  greater  reliance  on the most efficient modes, a very rapid deployment of zero-carbon vehicle technologies and energy carriers to shift away from fossil fuels, and needs to be accompanied  by  effective  near-term  accelerated and ambitious policy changes.

## IEA's	 definition	 of	 Thank-to-wheel	 emissions	 (TTW) :

Tank-to-wheel emissions cover all the energy used once transformed, this is emissions occurring during the combustion of the fuels by vehicles.

IEA's definition	 of	 Well-to-thank	 emissions	 (WTT): Well-to-tank  emissions  are  based  on  attributional life-cycle  assessment  studies  of  fossil-derived  fuels (e.g. gasoline, diesel, compressed and liquefied natural gas), biofuels and electricity (based on timeand  scenario-specific  estimated  average  grid  carbon intensity).  Energy  use  and  emissions  resulting from pipeline transport are accounted for under 'Energy  industry  own  use'  in  the  International  Energy Agency own modeling.

IEA's	 definition	 of	 Well-to-wheel	 emissions	 (WTW): Together, TTW and WTT make up WTW GHG emissions. This does not include emissions from vehicle or battery manufacturing, or those offset by material recycling, among others.

Passenger - kilometer: A passenger-kilometer, abbreviated  as  pkm,  is  the  unit  of  measurement  representing the transport of one passenger by a defined mode of transport (road, rail, air, sea, inland waterways etc.) over one kilometer.

Tonne - kilometer: A  tonne-kilometer,  abbreviated  as tkm, is a unit of measure of freight transport which represents the transport of one tonne of goods (including  packaging  and  tare  weights  of  intermodal transport units) by a given transport mode (road, rail, air,  sea, inland waterways, pipeline etc.) over a distance of one kilometer.

## SCOPES DEFINITIONS IN THE GHG PROTOCOL:

Scope 1 emissions: Emissions  derived  from  the  combustion of fossil  fuels  in  the vehicle;  generally  derived from invoices (e.g. liters of gasoline purchased).

Scope 2 emissions: Emissions  derived  from  the  combustion of fossil  fuels  to  produce  electricity  that  is consumed in the companies' vehicles. The GHG Protocol  Scope  2  Protocol  allow  companies  to  report these emissions in two ways.

Location-based  method  for  scope  2  accounting: A method to quantify scope 2 GHG emissions based on average energy generation emission factors for defined locations, including local, subnational, or national boundaries.

Market-based  method  for  scope  2  accounting: A method to quantify scope 2 GHG emissions based on GHG emissions emitted by the generators from which the reporter contractually purchases electricity  bundled with  instruments,  or  unbundled  instruments on their own.

## Scope 3 Category 3 'Fuel and energy related activities':

This category includes emissions related to the production  of  fuels  and  energy  purchased  and  consumed by the reporting company in the reporting year  that  are  not  included  in  scope  1  or  scope  2.

This category includes emissions from four distinct activities:  1)  upstream  emissions  from  purchased fuels (extraction, production,  and  transportation of  fuels  consumed  by  the  reporting  company);  2) Upstream  emissions  of  purchased  electricity  (extraction,  production,  and  transportation  of  fuels consumed in the generation  of  electricity,  steam, heating,  and  cooling  that  is  consumed  by  the  reporting  company);  3)  T&amp;D  losses  (generation  of electricity, steam, heating, and cooling that is consumed (i.e., lost) in a T&amp;D system - reported by end user);  and,  4)  Generation  of  purchased  electricity that is sold to end users (generation of electricity, steam,  heating,  and  cooling  that  is  purchased  by the reporting company and sold to end users - reported by utility company or energy retailer).

Scope 3 Category 6 'Business travel': This category includes emissions from the transportation of employees for business-related activities in vehicles owned or operated by third parties, such as aircraft, trains, buses, and passenger cars.

Scope 3 Category 7 'Employee commuting': This category includes emissions from the transportation of employees between their homes and their worksites.

Scope  3  Category  4  'Upstream  transportation  and distribution': This category  includes  emissions from the transportation and distribution of products (excluding fuel and energy products) purchased or acquired by the reporting company in the reporting year in vehicles and facilities not owned or operated by the reporting company, as well as other transportation and distribution services purchased by the reporting company in the reporting year (including both inbound and outbound logistics).

Scope 3 Category 9 'Downstream transportation and distribution': This category includes emissions from transportation and distribution of products sold by the reporting company in the reporting year between the reporting company's operations and the end consumer (if not paid for by the reporting company),  in  vehicles  and  facilities  not  owned  or  controlled by the reporting company.

Bioenergy: Energy  derived  from  any  form  of  biomass such as recently living organisms or their metabolic by-products.

Bioenergy and Carbon Dioxide Capture and Storage (BECCS): The application of Carbon Dioxide Capture and Storage (CCS) technology to bioenergy conversion processes.

Uncertainty: A cognitive state of incomplete knowledge that can result from a lack of information or from disagreement about what is known or even knowable.

## Resources

WRI &amp; WBCSD, 2004, Greenhouse Gas Protocol: A Corporate Accounting  and  Reporting  Standard  (Revised  Edition): http:/ /www.ghgprotocol.org/files/ ghgp/public/ghg-protocol-revised.pdf

WRI &amp; WBCSD, 2011, Greenhouse Gas Protocol Corporate  Value  Chain  (Scope  3)  Accounting  and Reporting  Standard: http:/ /www.ghgprotocol.org/ files/ghgp/public/Corporate-Value-Chain-Accounting-Reporing-Standard\_041613.pdf

WRI &amp; WBCSD, 2011, Greenhouse Gas Protocol Product Life  Cycle  Accounting  and  Reporting  Standard: http:/ /www.ghgprotocol.org/sites/default/files/ ghgp/standards/Product-Life-Cycle-AccountingReporting-Standard\_041613.pdf

Smart Freight Centre, 2016, GLEC Framework for Logistics Emissions Methodologies: http:/ /www. smartfreightcentre.org/info/glec-frameworkdownload-form

WRI, CDP, WWF, 2015, Science-based Target-setting Manual (Draft Version): http:/ /sciencebasedtargets. org/2015/09/23/for-public-comment-sciencebased-target-setting-manual/

## References

ATAG (2018). Website accessed May 1st, 2018: https:/ / www.atag.org/our-activities/climate-change.html

Greenbiz  (2018).  Website  accessed  May  1st,  2018: https:/ /www.greenbiz.com/article/shippingindustry-has-quietly-gone-without-climateplan-until-now?utm\_source=newsletter&amp;utm\_ medium=email&amp;utm\_term=newsletter-typegreenbuzz-daily&amp;utm\_content=2018-04-15&amp;utm\_ campaign=newsletter-type-greenbuzz-daily110209&amp;mkt\_tok=eyJpIjoiTlRsaFpEZGxOamRoWlRjNSIsInQiOiJ1elo3bWpkYm5VbjUybXlMU2pVcktTZ3 pZRWFnTkRpd2JKRlY5cFF6Z2ViMSt4a09JbXROcjZ EMTZ5cmVBaklhdU5VdEtkQU5FWFwvWTdKU3d4WjFocFZWenZNRmx0d242VWJvVnBKVVwvU1B0NmpSSE04eXRxa1pCemtHU2FTZHdiIn0%3D

ICCT  (2014).  'Development  of  Test  Cycle  Conversion Factors  among  Worldwide  Light-duty  vehicles CO2 Emissions Standards', ICCT White Paper, September  2014.  Accessible  at: https:/ /www.theicct. org/sites/default/files/publications/ICCT\_LDV-test-cycle-conversion-factors\_sept2014.pdf

IEA (2017). Mobility Model, August 2017 version, database and simulation model, www.iea.org/etp/etpmodel/transport/

IEA (2017). 'The Future of Trucks, Implications for energy and the environment', IEA Insight Series 2017.

IPCC (2014). Working Group III - Fifth Assessment Report.  Accessible  at: http:/ /www.ipcc.ch/ipccreports/tar/wg3/index.php?idp=311

Krabbe, O, Linthorst, G, Blok, K,  Crijns-Graus, W, van Vuuren, DP, Hohne, Niklas, Faria, P, Aden, N &amp; Carrillo-Pineda, A  (2015).  'Aligning  corporate  greenhouse-gas emissions targets with climate goals', Nature Climate Change.

OECD/IEA  (2017).  'Energy  Technology  Perspectives Report 2017, Catalysing Energy Technology Transformations', International Energy Agency.

WRI,  CDP,  WWF  (2015).  'Sectoral  Decarbonization Approach (SDA): A method for setting corporate emissions  reduction  targets  in  line  with  climate science', Science Based Targets initiative.

<!-- image -->

http:/ /sciencebasedtargets.org/transport-2/

Download our new transport-specifi  c technical resources and explore science based target setting for your company today.