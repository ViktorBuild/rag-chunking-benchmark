---
document_id: ghg_scope3_intro
title: "Technical Guidance for Calculating Scope 3 Emissions: Introduction & Fundamentals"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_intro_fundamentals.pdf"
tables_detected: 4
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Technical Guidance for Calculating Scope 3 Emissions (version 1.0) SF6 HFCs PFCs processing of sold products

Supplement to the Corporate Value Chain (Scope 3) Accounting &amp; Reporting Standard N2O transportation and distribution use of sold products

CH4

end-of-life treatment of

CO2

purchased electricity, steam, heating &amp; cooling for own use

purchased goods and

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

This document was developed in partnership with the Carbon Trust.

## GHG Protocol and Carbon Trust Team

Martin Barrow, Carbon Trust Benedict Buckley, World Resources Institute Tom Caldicott, Carbon Trust Tom Cumberlege, Carbon Trust John Hsu, Carbon Trust Scott Kaufman, Carbon Trust Kevin Ramm, Carbon Trust David Rich, World Resources Institute Will Temple-Smith, Carbon Trust

## World Resources Institute Contributors

Cynthia Cummis, World Resources Institute Laura Draucker, World Resources Institute Sofia Khan, World Resources Institute Janet Ranganathan, World Resources Institute Mary Sotos, World Resources Institute

## Acknowledgments

The GHG Protocol is grateful to the following people and organizations for providing written comments on an earlier draft of this document:

Gorm Kjærbøll, AB Electrolux

Katrina Destree Cochran, Alcatel-Lucent

Isabel Bodlak, Allianz SE

Arturo Cepeda, Artequim.com Ltd

George Vergoulas, Arup

Nicola Paczkowski, BASF SE

Will Schreiber, Best Food Forward

Ricardo Teixeira and Sara Pax, Bluehorse Associates

Marshall Chase, BSR Clean Cargo Working Group

Frances Way, Carbon Disclosure Project

Peggy Foran, The Climate Registry

Christopher Gleadle, The CMG Consultancy

Michael Van Brunt, Covanta Energy Corporation

Dr. Klaus Hufschlag and Patric Pütz, Deutsche Post DHL

Rob Rouse, The Dow Chemical Company

Dawn Rittenhouse, DuPont

Chris Brown and Bernhard Grünauer, E.ON AG

Corinne Reich-Weiser, Enviance

Daniel Hall, ForestEthics

Concepción Jiménez-González, GlaxoSmithKline

Thaddeus Owen, Herman Miller

Don Adams, Keystone Foods

Dr. John Andrews, Landcare Research

Maria Atkinson, Lend Lease Sustainability Solutions

Jordi Avelleneda and Mads Stensen, Maersk Line and Damco

David B. Goldstein, Natural Resources Defense Council

Johannes Partl and Duncan Noble, PE International and Five Winds International

Jorge Alberto Plauchu Alcantara, Plauchu Consultores

Nick Shufro, PricewaterhouseCoopers LLP

William Lau, SGS-CSTC Standards Technical Services Co., Ltd

Zoltán Hajdu, Soltub Ltd.

Erika Kloow, TetraPak

Yoshikazu Kato, The Japanese Gas Association

Yutaka Yoshida, Tokyo Gas Co., Ltd.

Alice Douglas, UK Department of Environment, Food and Rural Affairs (Defra)

Matt Clouse, John Sottong, and Jesse Miller, U.S. Environmental Protection Agency

Bryan Steverson, U.S. General Services Administration

Keith James, Waste &amp; Resources Action Programme (WRAP)

Nisitha Dasanayake

<!-- image -->

## Introduction

<!-- image -->

A standing  of  a  company's  greenhouse  gas  (GHG)  emissions.  Until  recently, n  effective  corporate  climate  change  strategy  requires  a  detailed  undercompanies  have  focused  on  emissions  from  their  own  operations  under scope  1  and  scope  2  of  the  GHG  Protocol.  Increasingly  companies  understand  the need  to also account  for GHG  emissions  along  their  value  chains  and  product portfolios to comprehensively manage GHG-related risks and opportunities.

The GHG  Protocol  Corporate  Value  Chain  (Scope  3)  Accounting  and  Reporting Standard (referred  to  as  the Scope  3  Standard ),  the  parent  document  to  this guidance, offers an internationally accepted method to enable GHG management of  companies'  value  chains.  This  guidance  document  serves  as  a  companion  to the Scope 3 Standard to  offer  companies  practical  guidance on calculating their scope 3 emissions. It provides information not contained in the Scope 3 Standard , such as methods for calculating GHG emissions for each of the 15 scope 3 categories, data sources, and worked examples.

Please  refer  to  the Scope  3  Standard for  requirements  and  guidance  related  to scope 3 accounting and reporting.

## Descriptions of scope 3 categories

Figure I shows the 15 distinct reporting categories in scope 3 and also shows how scope 3 relates to scope 1 (direct emissions from owned or controlled sources) and scope 2 (indirect emissions from the generation of purchased purchased electricity, steam, heating and cooling consumed by the reporting company). Scope 3 includes all other indirect emissions that occur in a company's value chain. The 15 categories in scope 3 are intended to provide companies with a systematic framework to measure, manage, and reduce emissions across a corporate value chain. The categories are designed to be mutually exclusive to avoid a company double counting emissions among categories.

Table I gives descriptions of each of the 15 categories. The Scope 3 Standard requires companies to quantify and report scope 3 emissions from each category.

CO2

CH4

N2O

CO2

CH4

SF6

N2O

HFCs

PFCs

HFCs

Figure [I] Overview of GHG Protocol scopes and emissions across the value chain CO2 CH4 N2O HFCs CO2 CH4 N2O

SF6

PFCs

SF6

PFCs

CO2

purchased goods and

services purchased

goods and services

transportation and distribution

transportation and distribution

employee and distribution

<!-- image -->

c

commuting d in  e travel ts

leased assets franchises

employe leased asse

investments commuting

leased assets generate ommuting e

commuting franchises

employe leased assets

operations ployee ing em commut

leased assets employee

commuting employee  ents commuting leased assets commuting leased assets ure 1.1 of investm Source: Fig Scope 3 Standard.

investments employee

commuting employee

leased assets commuting

investments investments

investments company

lea vehiclessed assets

leased assets leased assets

leased assets franchises

investments leased assets

franchises franchises

franchises leased assets

franchises

H

comp faciliti

comp vehicl

## Table [I]  Description and boundaries of scope 3 categories

## Upstream scope 3 emissions

## Category

## Category description

- 1.    Purchased goods and services
- 2.    Capital goods
- 3.    Fuel- and energyrelated activities (not included in scope 1 or scope 2)
- · Extraction, production, and transportation of goods and services purchased or acquired by the reporting company in the reporting year, not otherwise included in Categories 2 - 8
- · Extraction, production, and  transportation of capital goods purchased or acquired by the reporting company in the reporting year
- · Extraction, production, and transportation of fuels and energy purchased or acquired  by the reporting company in the reporting year, not already accounted for in scope 1 or scope 2, including:
- a. Upstream emissions of purchased fuels (extraction, production, and transportation of fuels consumed by the reporting company)
- b. Upstream emissions of purchased electricity (extraction, production, and transportation of fuels consumed in the generation of electricity, steam, heating, and cooling consumed by the reporting company)
- c. Transmission and distribution (T&amp;D) losses (generation of electricity, steam, heating and cooling that is consumed (i.e., lost) in a T&amp;D system) - reported by end user
- d. Generation of purchased electricity that is sold to end users (generation of electricity, steam, heating, and cooling  that is purchased by the reporting company and sold to end users) - reported by utility company or energy retailer only

## Minimum boundary

- · All upstream (cradle-to-gate) emissions of purchased goods and services
- · All upstream (cradle-to-gate) emissions of purchased capital goods
- a. For upstream emissions of purchased fuels: All upstream (cradle-to-gate) emissions of purchased fuels (from raw material extraction up to the point of, but excluding combustion)
- b. For upstream emissions of purchased electricity: All upstream (cradle-to-gate) emissions of purchased fuels (from raw material extraction up to the point of, but excluding, combustion by a power generator)
- c. For T&amp;D losses: All upstream (cradle-to-gate) emissions of energy consumed in a T&amp;D system, including emissions from combustion
- d. For generation of purchased electricity that is sold to end users: Emissions from the generation of purchased energy

## Table [I]  Description and boundaries of scope 3 categories  (continued)

## Upstream scope 3 emissions

## Category

## Category description

- 4.    Upstream transportation and distribution
- 5.    Waste generated in operations
- 6.  Business travel
- 7.    Employee commuting
- 8.    Upstream leased assets
- · Transportation and distribution of products purchased by the reporting company in the reporting year between a company's tier 1 suppliers and its own operations (in vehicles and facilities not owned or controlled by the reporting company)
- · Transportation and distribution services purchased by the reporting company in the reporting year, including inbound logistics, outbound logistics (e.g., of sold products), and transportation and distribution between a company's own facilities (in vehicles and facilities not owned or controlled by the reporting company)
- · Disposal and treatment of waste generated in the reporting company's operations in the reporting year (in facilities not owned or controlled by the reporting company)
- · Transportation of employees for business-related activities during the reporting year (in vehicles not owned or operated by the reporting company)
- · Transportation of employees between their homes and their worksites during the reporting year (in vehicles not owned or operated by the reporting company)
- · Operation of assets leased by the reporting company (lessee) in the reporting year and not included in scope 1 and scope 2 - reported by lessee

## Minimum boundary

- · The scope 1 and scope 2 emissions of transportation and distribution providers that occur during use of vehicles and facilities (e.g., from energy use)
- · Optional: The life cycle emissions associated with manufacturing vehicles, facilities, or infrastructure
- · The scope 1 and scope 2 emissions of waste management suppliers that occur during disposal or treatment
- · Optional: Emissions from transportation of waste
- · The scope 1 and scope 2 emissions of transportation carriers that occur during use of vehicles (e.g., from energy use)
- · Optional: The life cycle emissions associated with manufacturing vehicles or infrastructure
- · The scope 1 and scope 2 emissions of employees and transportation providers that occur during use of vehicles (e.g., from energy use)
- · Optional: Emissions from employee teleworking
- · The scope 1 and scope 2 emissions of lessors that occur during the reporting company's operation of leased assets (e.g., from energy use)
- · Optional: The life cycle emissions associated with manufacturing or constructing leased assets

## Table [I]  Description and boundaries of scope 3 categories  (continued)

## Downstream scope 3 emissions

## Category

## Category description

- 9.    Downstream transportation and distribution
- 10.    Processing of sold products
- 11.    Use of sold products
- 12.    End-of-life treatment of sold products
- 13.    Downstream leased assets
- · Transportation and distribution of products sold by the reporting company in the reporting year between the reporting company's operations and the end consumer (if not paid for by the reporting company), including retail and storage  (in vehicles and facilities not owned or controlled by the reporting company)
- · Processing of intermediate products sold in the reporting year by downstream companies (e.g., manufacturers)
- · End use of goods and services sold by the reporting company in the reporting year
- · Waste disposal and treatment of products sold by the reporting company (in the reporting year) at the end of their life
- · Operation of assets owned by the reporting company (lessor) and leased to other entities in the reporting year, not included in scope 1 and scope 2 reported by lessor

## Minimum boundary

- · The scope 1 and scope 2 emissions of transportation providers, distributors, and retailers that occur during use of vehicles and facilities (e.g., from energy use)
- · Optional: The life cycle emissions associated with manufacturing vehicles, facilities, or infrastructure
- · The scope 1 and scope 2 emissions of downstream companies that occur during processing (e.g., from energy use)
- · The direct use-phase emissions of sold products over their expected lifetime (i.e., the scope 1 and scope 2 emissions of end users that occur from the use of: products that directly consume energy (fuels or electricity) during use; fuels and feedstocks; and GHGs and products that contain or form GHGs that are emitted during use)
- · Optional: The indirect use-phase emissions of sold products over their expected lifetime (i.e., emissions from the use of products that indirectly consume energy (fuels or electricity) during use)
- · The scope 1 and scope 2 emissions of waste management companies that occur during disposal or treatment of sold products
- · The scope 1 and scope 2 emissions of lessees that occur during operation of leased assets (e.g., from energy use).
- · Optional: The life cycle emissions associated with manufacturing or constructing leased assets

## Table [I]  Description and boundaries of scope 3 categories (continued)

## Downstream scope 3 emissions

<!-- image -->

## Category description

- · Operation of franchises in the reporting year, not included in scope 1 and scope 2 - reported by franchisor
- · Operation of investments (including equity and debt investments and project finance) in the reporting year, not included in scope 1 or scope 2

Source: Table 5.4 from the Scope 3 Standard

## How to use this document

The 15 sections in this document correspond to the 15 scope 3 categories in table II. Each section follows the structure below:

- · Category description (from chapter 5 of the Scope 3 Standard )
- · Summary of calculation methods (and decision tree if applicable)
- · For each calculation method:
- · Activity data needed
- · Emission factors needed
- · Data collection guidance
- · Calculation formula
- · Example(s)

The Scope 3 Standard contains a lot of important information that is not repeated in this calculation guidance document, including business goals for conducting a scope 3 assessment; accounting and reporting principles; setting the scope 3 boundary; setting reduction targets; and reporting. This document should be used in conjunction with the Scope 3 Standard when calculating emissions. The following Scope 3 Standard chapters contain information that is especially relevant to performing various emissions calculations:

- · Chapter 4, which defines the accounting and reporting principles (relevance, completeness, consistency, transparency, accuracy)
- · Chapter 5, which defines each of the 15 scope 3 categories and provides detailed descriptions of which activities are included in each scope 3 category
- · Chapter 6, which provides guidance on setting the scope 3 boundary
- · Chapter 7, which provides guidance on collecting data, including prioritizing data collection efforts, selecting among different types of data, and ensuring data quality
- · Chapter 8, which provides guidance on allocating emissions
- · Chapter 10, which describes assurance procedures
- · Chapter 11, which defines scope 3 reporting requirements
- · Appendix B, which describes uncertainty in scope 3 inventories
- · Appendix C, which describes how to create a data management plan

## Minimum boundary

- · The scope 1 and scope 2 emissions of franchisees that occur during operation of franchises (e.g., from energy use)
- · Optional: The life cycle emissions associated with manufacturing or constructing franchises
- · See the description of category 15 (Investments) in section 5.5 for the required and optional boundaries

## Selecting calculation methods

For most scope 3 categories, this document offers multiple calculation methods. Within each section, the calculation methods are ranked in order of specificity, 1  from most to least specific to a company's actual activities. In general, more specific methods yield higher quality scope 3 emissions data whereas less specific methods yield lower quality scope 3 emissions data. However, the more specific methods are often more time and labor intensive. The best method for each category depends on factors described below.

Companies should select calculation methods for each scope 3 activity within a category based on the following criteria:

- · The relative size of the emissions from the scope 3 activity
- · The company's business goals (see chapter 2 of the Scope 3 Standard )
- · Data availability
- · Data quality
- · The cost and effort required to apply each method
- · Other criteria identified by the company.

Companies should select calculation methods that ensure that the inventory appropriately reflects the GHG emissions of the activities and serves the decision-making needs of users, both internal and external to the company.

Note that each scope 3 category may contain multiple activities (for example air travel and road travel could be two different activities within category 6, Business travel). If appropriate, different calculation methods can be used to calculate emissions from different activities within a category. This guide uses the term 'should' to indicate recommendations for calculations.

Companies are required to report a description of the methodologies used to calculate emissions for each scope 3 category (see chapter 9 of the Scope 3 Standard ).

## Screening to prioritize data collection

The Scope 3 Standard recommends that companies identify which scope 3 activities are expected to have the most significant GHG emissions, offer the most significant GHG reduction opportunities, and are most relevant to the company's business goals. Companies should begin by conducting a screening process, using less specific data, to determine the size of GHG emissions in each of the 15 categories. Then each category can be examined to determine whether to further refine its emission estimates.

This document offers guidance on how to decide which categories require a more precise, and often more labor-intensive, method of data collection, and which might be adequately served by a less precise method. In most cases, the categories that generate the largest amount of emissions should receive the most precise data collection treatment, however, some smaller categories that are important to customers or employees may benefit from more precise treatment as well. Categories most relevant to the company's business goals may also receive more attention. The business goals most frequently cited by companies as reasons for developing a scope 3 inventory were to: (1) identify and understand the risks and opportunities associated with value chain emissions; (2) identify GHG reduction opportunities, set reduction targets, and track performance; and (3) engage value chain partners in GHG management. See chapter 2 of the Scope 3 Standard .

- 1 If a calculation method is specific to a company's activity, the calculation is based on data relating directly to the particular activity in question, such as data collected from a transport provider relating to journeys carried out. In contrast, less specific methods use data that does not directly relate to the activity, such as industry average emission factors.

Collecting higher quality data for priority activities allows companies to focus resources on the most significant GHG emissions in the value chain, more effectively set reduction targets, and track and demonstrate GHG reductions over time.

As a result of the screening, a company might decide that, in addition to using more precise data for activities with the most emissions, it will seek higher quality data for activities that present the most significant risks and opportunities in the value chain, and for activities where more accurate data can be easily obtained. Conversely, it may choose to rely on relatively less accurate data for activities that are expected to have insignificant emissions or where accurate data is difficult to obtain.

To start the screening, a company can apply the criteria in table II to each of the 15 categories to find out where the bulk of its scope 3 GHG emissions occur. Note that to facilitate the initial screening, companies can use the less specific calculation methods listed for each category (i.e., the methods at the bottom of the decision trees). See section 7.1 of the Scope 3 Standard for more guidance on prioritizing data collection efforts. More specific methods can be applied later to priority categories.

Table [II] Criteria for identifying relevant scope 3 activities

| Criteria                     | Description of activities                                                                                                                                                                                 |
|------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Size                         | They contribute significantly to the company's total anticipated scope 3 emissions                                                                                                                        |
| Influence                    | There are potential emissions reductions that could be undertaken or influenced by the company                                                                                                            |
| Risk                         | They contribute to the company's risk exposure (e.g., climate change related risks such as financial, regulatory, supply chain, product and technology, compliance/litigation, and reputational risks)    |
| Stakeholders                 | They are deemed critical by key stakeholders (e.g., customers, suppliers, investors or civil society)                                                                                                     |
| Outsourcing                  | They are outsourced activities previously performed in-house or activities outsourced by the reporting company that are typically performed in-house by other companies in the reporting company's sector |
| Sector guidance              | They have been identified as significant by sector-specific guidance                                                                                                                                      |
| Spending or revenue analysis | They are areas that require a high level of spending or generate a high level of revenue (and are sometimes correlated with high GHG emissions)                                                           |
| Other                        | They meet any additional criteria developed by the company or industry sector                                                                                                                             |

Source: Adapted from table 6.1 from the Scope 3 Standard

## Using a combination of calculation methods

Companies may use a combination of calculation methods for various scope 3 categories throughout the inventory, as well as for various scope 3 activities within each scope 3 category. For example, within each scope 3 category, a company may use more specific methods for the activities that contribute most to emissions and less specific methods for the activities that contribute least to emissions.

Companies should take practical approaches to reduce costs and complexity without overly compromising quality. These may include:

- · Applying more accurate data/calculations for large contributors
- · Applying less accurate data/calculations for small contributors
- · Grouping or combining similar activity data (e.g., goods and services)
- · Obtaining data from representative samples and extrapolating the results to the whole
- · Using proxy techniques.

## Example: Using a combination of calculation methods

A coffee company purchased coffee beans from 100 different suppliers in the reporting year. If 10 of these suppliers account for 85 percent of the quantity of purchased beans, the company may decide to calculate emissions associated with the coffee beans from these 10 suppliers using primary data collected from the suppliers, either using the 'supplier-specific method' or the 'hybrid method' (see chapter 1 for descriptions of the calculation methods for scope 3 category 1). The company may then choose to extrapolate to 100 percent based on the 85 percent of the beans for which data was collected.

The company spent a total of $20 million on purchasing coffee beans. The company also purchased a small quantity of sugar, totaling $1 million for the year. As the sugar only accounts for a small proportion of the company's total expenditure, the company may choose not to engage with the sugar suppliers, but instead use secondary emission factors, using either the 'average-data method' or the 'spend-based method.'

Significance of an activity's emission contribution to the inventory is a key consideration when determining the appropriate level of data specificity to calculate the emissions.

## Overview of data types

Calculating emissions requires the use of two types of data: activity data and emission factors.

'Activity data' is a quantitative measure of a level of activity that results in GHG emissions (for example, liters of fuel consumed, or kilograms of material purchased). An 'emission factor' is a factor that converts activity data into GHG emissions data (for example kg CO  emitted per liter of fuel consumed, or kg CO  emitted per kilograms of material 2 2 produced). More examples of activity data and emission factors are provided in table 7.2 in the Scope 3 Standard .

Companies are required to report a description of the types and sources of activity data and emission factors used to calculate the inventory (see chapter 11 in the Scope 3 Standard ).

## Material/product emission factors in scope 3 accounting

Two types of emission factors can be used for calculating emissions associated with a material or product:

- · Life cycle emission factors , which include emissions that occur at every stage of a material/product's life, from raw material acquisition or generation of natural resource to end of life
- , which include all emissions that occur
- · Cradle-to-gate (sometimes referred to as 'upstream') emission factors in the life cycle of a material/product up to the point of sale by the producer.

In general, cradle-to-gate emission factors should be used to calculate emissions associated with goods or services (e.g. category 1 (Purchased goods and services) and category 2 (Capital goods).

## Energy emission factors in scope 3 accounting

Two types of emission factors are used to convert energy activity data into emissions data:

- · Life cycle emission factors , which include not only the emissions that occur from combusting the fuel, but all other emissions that occur in the life cycle of the fuel such as emissions from extraction, processing, and transportation · Combustion emission factors , which include only the emissions that occur from combusting the fuel.

Companies should use life cycle emission factors to calculate scope 3 emissions related to fuels and energy consumed in the reporting company's value chain, except for category 3 (Fuel- and energy-related activities not included in scope 1 or scope 2). Combustion emission factors are used to calculate scope 1 emissions (in the case of fuels) and scope 2 emissions (in the case of electricity).

Two activities within scope 3 category 3 require special consideration when selecting emission factors:

- · Upstream emissions of purchased fuels (i.e., extraction, production, and transportation of fuels consumed by the reporting company)
- · Upstream emissions of purchased electricity (i.e., extraction, production, and transportation of fuels consumed in the generation of electricity, steam, heating, and cooling that is consumed by the reporting company).

To calculate emissions from these two activities, companies should use emission factors that include upstream emissions (i.e., extraction, production, and transportation) but exclude emissions from combustion, since emissions from combustion are accounted for in scope 1 (in the case of fuels), in scope 2 (in the case of electricity), and in a separate memo item (in the case of direct CO  emissions from combustion of biomass or biofuels). See Chapter 3 of the 2 Scope 3 Standard .

These emission factors that exclude combustion are referred to as 'upstream emission factors,' since they include all life cycle stages of the fuel up to but excluding the final stage - combustion.

## Applicable greenhouse gases and global warming potential values

For each of the 15 scope 3 categories, companies are required to calculate emissions of all the GHGs required by the United Nations Framework Convention on Climate Change (UNFCCC)/Kyoto Protocol at the time the inventory is being compiled. National reporting guidelines under the UNFCCC and the Kyoto Protocol require that specific GHGs be included in national GHG emissions inventories. To remain consistent with national inventory practices, the GHG Protocol requires that these same GHGs also be reported in corporate GHG emissions inventories. Originally, the requirements of the UNFCCC/Kyoto Protocol, and therefore of the GHG Protocol, were limited to a set of six individual GHGs or classes of GHGs: carbon dioxide (CO ), methane (CH ), nitrous oxide (N O), hydrofluorocarbons (HFCs), 2 4 2 perfluorocarbons (PFCs), sulphur hexafluoride (SF ). However, changes to international accounting and reporting rules 6 under the UNFCCC/Kyoto Protocol now also require the reporting of another GHG, nitrogen trifluoride (NF ). 3

As the Scope 3 Standard was released before NF  was added to the list of GHGs covered by UNFCCC/Kyoto Protocol, 3 reporting NF  was not originally included as a requirement in the Scope 3 Standard. However an amendment has been 3 published on the GHG Protocol website (http://www.ghgprotocol.org/) which supersedes the original requirements of the Scope 3 Standard and it is now a requirement that NF  be included. 3

In this document, carbon dioxide equivalent (CO e) emissions represent emissions of all greenhouse gases, aggregated 2 and converted to units of CO e using global warming potential (GWP) values. 2

GWP values describe the radiative forcing impact (or degree of harm to the atmosphere) of one unit of a given GHG relative to one unit of carbon dioxide. GWP values convert GHG emissions data for non-CO  gases into units of CO e. 2 2

Companies may either use the Intergovernmental Panel on Climate Change (IPCC) GWP values agreed to by United Nations Framework Convention on Climate Change (UNFCCC) or the most recent GWP values published by the IPCC. GWP values should be based on a 100-year time horizon. See section 7.2 of the Scope 3 Standard for more information on GWP values. Companies are required to disclose the source of GWP values used to calculate the inventory (see chapter 11 of the Scope 3 Standard ).

## Primary data and secondary data

Companies may use either primary or secondary data to calculate scope 3 emissions. Table III provides definitions of these types of data.

## Table [III] Types of data

## Data type

Primary Data

## Description

Data from specific activities within a company's value chain

Secondary Data

Data that is not from specific activities within a company's value chain

Source: Table 7.4 from the Scope 3 Standard.

Primary data includes data provided by suppliers or others that directly relate to specific activities in the reporting company's value chain.

Secondary data includes industry-average-data (e.g., from published databases, government statistics, literature studies, and industry associations), financial data, proxy data, and other generic data. In certain cases, companies may use specific data from one activity in the value chain to estimate emissions for another activity in the value chain. This type of data (i.e., proxy data) is considered secondary data, since it is not specific to the activity whose emissions are being calculated.

See table 7.4 in the Scope 3 Standard for examples of primary and secondary data by scope 3 category.

## Collecting primary data

Primary activity data may be obtained through meter readings, purchase records, utility bills, engineering models, direct monitoring, mass balance, stoichiometry, or other methods for obtaining data from specific activities in the company's value chain.

If possible, companies should collect energy or emissions data from suppliers and other value chain partners to obtain site-specific data for priority scope 3 categories and activities (see 'Screening to prioritize data collection,' above, for guidance on identifying priority categories). To do so, companies should identify relevant suppliers from which to seek GHG data. Suppliers may include contract manufacturers, materials and parts suppliers, capital equipment suppliers, fuel suppliers, third-party logistics providers, waste management companies, and other companies that provide goods and services to the reporting company.

In general, companies should seek activity data or emissions data from suppliers that are as specific as possible to the product purchased from the supplier, following the hierarchy in table IV.

## Table [IV] Levels of data (ranked in order of specificity)

| Data Type                                          | Description                                                                                                                |
|----------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|
| Product-level data                                 | Cradle-to-gate GHG emissions for the product of interest                                                                   |
| Activity-, process-, or production line-level data | GHG emissions and/or activity data for the activities, processes, or production lines that produce the product of interest |
| Facility-level data                                | GHG emissions and/or activity data for the facilities or operations that produce the product of interest                   |
| Business-unit-level data                           | GHG emissions and/or activity data for the business units that produce the product of interest                             |
| Corporate-level data                               | GHG emissions and/or activity data for the entire corporation                                                              |

Source: Table 7.7 from the Scope 3 Standard.

For more information on collecting primary data and guidance on issues such as how to treat the confidentiality concerns of suppliers, refer to section 7.4 of the Scope 3 Standard .

## Collecting secondary data

When using secondary databases, companies should prefer those that are internationally recognized, provided by national governments, or peer-reviewed. Companies can use the data-quality indicators in section 7.3 of the Scope 3 Standard to select the secondary data sources that are the most complete, reliable, and representative to the company's activities in terms of technology, time, and geography.

Secondary data sources can cover different stages in the value chain. Care should be taken to understand the boundaries covered by the data to minimize the potential for double counting errors across the value chain.

The secondary data sources included in the calculation resources of each category are examples and not an exhaustive list. The GHG Protocol website has a more comprehensive list of secondary data sources at:  http://www.ghgprotocol. org/Third-Party-Databases.

For additional guidance on prioritizing data collection efforts, selecting data, collecting data, and filling data gaps, see chapter 7 of the Scope 3 Standard .

## Environmentally-extended input output (EEIO) data

Environmentally-extended input output (EEIO) models estimate energy use and/or GHG emissions resulting from the production and upstream supply chain activities of different sectors and products in an economy. The resulting EEIO emissions factors can be used to estimate cradle-to-gate GHG emissions for a given industry or product category. EEIO data are particularly useful in screening emissions sources when prioritizing data collection efforts. EEIO models are derived by allocating national GHG emissions to groups of finished products based on economic flows between industry sectors.

The output of EEIO models is typically a quantity of GHGs emitted per unit of revenue in a particular industry sector. For example, an EEIO model may estimate that the sector 'paper mills' emits 1,520 tonnes CO e per $1 million revenue, 2 meaning that, on average, 1,520 tonnes of CO e are emitted during all upstream supply chain activities associated with 2 generating $1 million revenue from that sector.

The advantages of EEIO data include:

- · Comprehensive coverage of the entire economy (i.e., no emissions sources are excluded from the system boundary)
- · Simplicity of method and application
- · Time and cost savings as data requirements are less onerous than in a process-based approach.

The disadvantages of EEIO data include:

- · Broad sector averages may not represent nuances of unique processes and products, especially for nonhomogenous sectors
- · Assumption of linear attribution between monetary and environmental flows provides only indicative results (i.e., EEIO models cannot distinguish between products of different monetary value within a single sector)
- · Lacks specificity and accuracy of process-based approaches
- · Difficult to measure and demonstrate results of reduction efforts
- · EEIO databases are generally limited to a specific geographic region, (e.g., United States) and are not available in some world regions.

## Process-based data

Process-based data is derived from assessing all the known energy and environmental inputs of a particular process and calculating the direct emissions associated with the outputs of the process. It is particularly applicable for unique processes and individual product level analysis.

The advantages of process-based data include:

- · High level of specificity and focus
- · Detailed analysis and possibility of unique insights to particular processes
- · Straightforward concept.

The disadvantages of process based data include:

- · Collection of data may be time, cost, and labor intensive
- · Lack of comparability as the system boundary and the data are selected by the practitioner
- · Data requirements may render large-scale, multi-product analysis impractical.

## Combining EEIO and process-based data

Companies may combine the top down EEIO approach with the bottom-up, process-based approach to leverage the benefits of both approaches. For example, the upstream emissions of purchased goods could be calculated using an EEIO approach, whereas downstream emissions from use and end-of-life could be calculated using a process-based approach.

Companies are required to report a description of the types and sources of data used to calculate emissions for each scope 3 category (see chapter 11 of the Scope 3 Standard ).

## Using proxy data to fill data gaps

Companies should use the guidance in section 7.3 of the Scope 3 Standard, 'Guidance for selecting data' to assess the quality of available data. If data of sufficient quality are not available, companies may use proxy data to fill data gaps. Proxy data is data from a similar activity that is used as a stand-in for the given activity. Proxy data can be extrapolated, scaled up, or customized to be more representative of the given activity (e.g., partial data for an activity can be extrapolated or scaled up to represent 100 percent of the activity).

If a large company has access to 80 out of 100 manufacturing facilities it can extrapolate this information to fill the gap. It would first group the activity data by similar characteristics, such as facility type or location, then calculate an intensity ratio for a group of facilities where data is available (e.g., quantity of emissions per unit of production output). This figure can then be applied to the unknown facilities in that group.

Section 7.5 of the Scope 3 Standard 'Guidance for collecting secondary data and filling data gaps' provides more information on the use of proxy data and its advantages and disadvantages.

If data are unavailable for a large number of sites or if a company needs to collect a large quantity of data for a scope 3 category, but finds it impractical or impossible to collect data from each individual activity, the company may use appropriate sampling techniques to extrapolate data from a representative sample of activities. See Appendix A for guidance on sampling methods.

## Improving data quality over time

Collecting data, assessing data quality, and improving data quality is an iterative process. When selecting data sources, companies should first apply data quality indicators and assess data quality, then review the quality of the collected data, using the same data quality assessment approach. In their initial years of scope 3 data collection, companies may need to use data of relatively low quality due to limited availability. Over time, companies should seek to improve the data quality of the inventory by replacing lower quality data with higher quality data as it becomes available. In particular, companies should prioritize data quality improvement for activities that have:

- · Relatively low data quality
- · Relatively high emissions.

Companies are required to provide a description of the data quality of reported scope 3 emissions data to ensure transparency and avoid misinterpretation of data (see chapter 11 of the Scope 3 Standard ). Refer to section 7.3 for guidance on describing data quality; Appendix B for guidance on uncertainty; and section 9.3 for guidance on recalculating base year emissions when making improvements in data quality over time.

It is unlikely that all of a company's relevant suppliers will be able to provide it with GHG inventory data. (See table 7.8 of the Scope 3 Standard for a list of challenges and guidance for collecting primary data from suppliers.) In such cases, companies should encourage suppliers to develop GHG inventories in the future and may communicate their efforts to encourage more suppliers to provide GHG emissions data in the public report.

If changes in data quality result in significant differences in emissions estimates, companies are required to recalculate base year emissions applying the new data sources. Refer to page 106 of the Scope 3 Standard for guidance on base year recalculations for improvements in data accuracy over time. Appendix C of the Scope 3 Standard also provides a useful resource for developing a data management plan and improving data management.

## GHG Protocol publications and tools

Several GHG publications and calculation tools offer help in calculating emissions from various scope 3 categories. In particular, several cross-sector and sector-specific calculation tools available on the GHG Protocol website (http://www. ghgprotocol.org/calculation-tools/all-tools) provide step-by-step guidance together with electronic worksheets to help companies calculate GHG emissions from specific sources or sectors.