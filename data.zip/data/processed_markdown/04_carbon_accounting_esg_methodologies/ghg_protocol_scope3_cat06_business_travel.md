---
document_id: ghg_scope3_ch06_business_travel
title: "Scope 3 Guidance - Category 6: Business Travel"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat06_business_travel.pdf"
tables_detected: 14
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

6

## Category 6: Business Travel

## Category description

<!-- image -->

T related activities in vehicles owned or operated by third parties,  such  as  aircraft, his category includes emissions from the transportation of employees for businesstrains, buses, and passenger cars.

Emissions from transportation in vehicles owned or controlled by the reporting company are accounted for in either scope 1 (for fuel use), or in the case of electric vehicles, scope 2 (for electricity use). Emissions from leased vehicles operated by the reporting company not included in scope 1 or scope 2 are accounted for in scope 3, category 8 (Upstream leased assets). Emissions from transportation of employees to and from work are accounted for in scope 3, category 7 (Employee commuting). See table 6.1.

Emissions from business travel may arise from:

- · Air travel
- · Rail travel
- · Bus travel
- · Automobile travel (e.g., business travel in rental cars or employee-owned vehicles other than employee commuting to and from work)
- · Other modes of travel.

Companies may optionally include emissions from business travelers staying in hotels.

A reporting company's scope 3 emissions from business travel include the scope 1 and scope 2 emissions of transportation companies (e.g., airlines).

6

## Table [6.1] Accounting for employee transportation across the value chain

| Activity                                                                                                                        | Relevant category of emissions                                                               |
|---------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|
| Emissions from transportation in vehicles owned or controlled by the reporting company                                          | Scope 1 (for vehicles that consume fuel) and scope 2 (for vehicles that consume electricity) |
| Emissions from the transportation of employees for business-re- lated activities in vehicles owned or operated by third parties | Scope 3, category 6 (Business travel)                                                        |
| Emissions from transportation of employees to and from work                                                                     | Scope 3, category 7 (Employee commuting)                                                     |
| Emissions from leased vehicles operated by the reporting com- pany not included in scope 1 or scope 2                           | Scope 3, category 8 (Upstream leased assets)                                                 |

## Calculating emissions from business travel

Figure 6.1 gives a decision tree for selecting a calculation method for emissions from business travel. Companies may use one of the following methods to calculate scope 3 emissions from business travel:

- · Fuel-based method , which involves determining the amount of fuel consumed during business travel (i.e., scope 1 and scope 2 emissions of transport providers) and applying the appropriate emission factor for that fuel
- · Distance-based method , which involves determining the distance and mode of business trips, then applying the appropriate emission factor for the mode used
- · Spend-based method , which involves determining the amount of money spent on each mode of business travel transport and applying secondary (EEIO) emission factors.

## Figure [6.1] Decision tree for selecting a calculation method for emissions from business travel

<!-- image -->

6

## Fuel-based method

The calculation methodology for the fuel-based method does not differ from the fuel-based method in category 4 (Upstream transport and distribution). For guidance on calculating emissions using this method, refer to the guidance for category 4 (Upstream transport and distribution). Companies may optionally collect data on the number of hotel nights incurred during business travel by hotel type. Under this method, they add the number of hotel nights and the emissions factor of the hotel (as shown in the distance-based method below) to the fuel-based method in category 4 (Upstream transport and distribution).

## Distance-based method

If data on fuel use is unavailable, companies may use the distance-based method.

The distance-based method involves multiplying activity data (i.e., vehicle-kilometers or person-kilometers travelled by vehicle type) by emission factors (typically default national emission factors by vehicle type). Vehicle types include all categories of aircraft, rail, subway, bus, automobile, etc.

## Activity data needed

Companies should collect data on:

- · Total distance travelled by each mode of transport (air, train, bus, car, etc.) for employees in the reporting year.

Where possible, companies should also collect data on:

- · Countries of travel (since transportation emission factors vary by country)
- · Specific types of vehicles used for travel (since transportation emission factors vary by vehicle types) from transport providers
- · The specific passenger vehicle type and the relevant emission factor.

Companies may optionally collect data on the number of hotel nights incurred during business travel by hotel type.

Activity data should be expressed as the number of kilometers travelled or kilometers travelled per person for a particular vehicle type (e.g., passenger-kilometer). The activity data should be summed to obtain total annual kilometers or person-kilometers travelled by each vehicle type used by the company.

## Emission factors needed

Companies should collect:

- · Emission factors for each mode of transport (e.g., aircraft, rail, metro, bus, taxi, bus), expressed in units of greenhouse gas (CO , CH , N O, HFC, or CO e) emitted per kilometer or per passenger-kilometer travelled. 2 4 2 2

Companies may optionally use emission factors for hotel stays by hotel type (e.g., kilograms of CO e emitted per hotel night). 2

Note: For air travel emission factors, multipliers or other corrections to account for radiative forcing may be applied to the GWP of emissions arising from aircraft transport. If applied, companies should disclose the specific factor used.

## Data collection guidance

Methods of data collection include:

- · Automatic tracking of distance travelled by mode through a travel agency or other travel providers
- · Automatic tracking of distance travelled by mode through internal expense and reimbursement systems, which may require adding new questions on distance travelled and mode of transport to travel or expense forms submitted by employees
- · Annual surveys/questionnaires of employees
- · Working with travel providers (e.g., transportation companies, hotels) to obtain GHG emissions data.

Collecting travel data from all employees may not be feasible. In such a case, companies may extrapolate from a representative sample of employees to the total business travel of all employees. For example, a company may have 4,000 employees, each of whom has different travel profiles. The company may extrapolate from a representative sample of 400 employees to approximate the total business travel of all employees. Companies may also choose to group or combine data from business travellers with similar travel profiles. See Appendix A for more information on sampling methods.

## Calculation resources include:

- · GHG Protocol Calculation Tool, 'Mobile Combustion GHG Emissions Calculation Tool. Version 2.0. June 2009,' developed by World Resources Institute, available at http://www.ghgprotocol.org/calculation-tools/all-tools
- · U.S. EPA Climate Leaders GHG Inventory Protocol, 'Optional Emissions from Commuting, Business Travel and Product Transport,' available at: http://www.epa.gov/stateply/documents/resources/commute\_travel\_product.pdf
- · For UK organizations, the Department for Transport provides guidance and a calculation tool for work-related travel at: http://www2.dft.gov.uk/pgr/sustainable/greenhousegasemissions/.

Once the company has determined total annual distance travelled by each mode of transport (aggregated across all employees), apply the formula below to calculate emissions.

## Calculation formula [6.1] Distance-based method

## CO 2 e emissions from business travel =

## sum across vehicle types:

∑ (distance travelled by vehicle type (vehicle-km or passenger-km) × vehicle specific emission factor (kg CO e/vehicle-km or kg CO e/passenger-km)) 2 2

+

## (optional)

∑ (annual number of hotel nights (nights) × hotel emission factor (kg CO e/night)) 2

6

6

## Example [6.1] Calculating emissions from business travel using the distance-based method

istances travelled and modes of transport. Company A is a financial services company. Every year, it sends groups of professionals to industry conferences in the United Kingdom, Australia, and the United States. For each group, the company has collected activity data on the typical d

Data was collected via employee questionnaires and information provided by travel agencies and transportation companies. It is assumed that each member of the group travelled the same amount in the same business trip.

|         |     | Road Travel          |    | Location      |   Distance (km) |    |
|---------|-----|----------------------|----|---------------|-----------------|----|
| Group 1 |  10 | Hybrid               |  2 | United States |              50 |  1 |
| Group 2 |  20 | Average gasoline car |  2 | Australia     |             200 |  2 |
| Group 3 | 100 | Four wheel drive     |  3 | United States |             100 |  4 |

## Air Travel

| Employee Group   |   Number of employees in group | Flight type   | Distance (km)   |   Emission factor (kg CO 2 e/passenger-km) |
|------------------|--------------------------------|---------------|-----------------|--------------------------------------------|
| Group 1          |                             10 | Long haul     | 10,000          |                                          5 |
| Group 2          |                             20 | Short haul    | 15,000          |                                          6 |
| Group 3          |                            100 | Long haul     | 12,000          |                                          5 |

Note: the activity data and emission factors in this example are for illustrative purposes only.

6

## Example [6.1] Calculating emissions from business travel using the distance-based method (continued)

han medium-haul flights due to the additional weight of fuel. Many countries have specific definitions of types of Three types of flights are identified for calculating emission factors. Short-haul flights have higher emission factors due to strong influence of the landing/take off cycle on emissions, whereas long-haul flights have slightly higher emissions t flights. Below is an indicative description:

- · Short haul - flights less than 3 hours in length
- · Medium haul - flights 3-6 hours in length
- · Long haul - journeys made by wide-bodied aircrafts that fly long distance, typically more than 6.5 hours.

## total business travel emissions of Company A can be calculated as follows:

emissions from road travel = ∑ (distance travelled by vehicle type (vehicle-km or passenger-km) × vehicle specific emission factor (kg CO e/vehicle-km or kg CO e/passenger-km)) 2 2 = (10/2 × 50 × 1) + (20/2 × 200 × 2) + (100/3 × 100 × 4) = 17,583.33 kg CO e

2

emissions from air travel = ∑ (distance travelled by vehicle type (vehicle-km or passenger-km) × vehicle specific emission factor (kg CO e/vehicle-km or kg CO e/passenger-km)) 2 2 = (10 × 10,000 × 5) + (20 × 15,000 × 6) + (100 × 12,000 × 5)

= 8,300,000 kg CO e 2

total emissions from employee travel = emissions from road travel + emissions from air travel

= 17,583.33 + 8,300,000 = 8,317,583.33 kg CO e

2

## Spend-based method

If it is not possible to use either the fuel- or distance-based methods, companies may use the spend-based method. The calculation method is same as the spend-based method described in Category 4: Upstream Transportation and Distribution, with the difference that the activity data is the amount spent on business travel by type/mode of transport. Refer to the spend-based method in Category 4 for a description of this method.

Companies may optionally collect data on the number of hotel nights incurred during business travel by hotel type.