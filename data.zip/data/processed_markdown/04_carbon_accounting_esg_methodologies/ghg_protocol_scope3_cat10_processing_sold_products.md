---
document_id: ghg_scope3_ch10_processing_sold_products
title: "Scope 3 Guidance - Category 10: Processing of Sold Products"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat10_processing_sold_products.pdf"
tables_detected: 9
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Category description

C by third  parties  (e.g.,  manufacturers)  subsequent  to  sale  by  the  reporting ategory  10  includes  emissions  from  processing  of  sold  intermediate  products company.  Intermediate  products  are  products  that  require  further  processing, transformation,  or  inclusion  in  another  product  before  use  (see  box  5.3  of  the Scope 3 Standard ),  and  therefore  result  in  emissions  from  processing  subsequent  to  sale  by  the reporting company and before use by the end consumer. Emissions from processing should be allocated to the intermediate product.

In certain cases, the eventual end use of sold intermediate products may be unknown. For example, a company that produces an intermediate product with many potential downstream applications, each of which has a different GHG emissions profile, may be unable to reasonably estimate the downstream emissions associated with these various end uses. See section 6.4 of the Scope 3 Standard for guidance in cases where downstream emissions associated with sold intermediate products are unknown.

See section 5.6 of the Scope 3 Standard for guidance on the applicability of category 10 to final products and intermediate products sold by the reporting company. A reporting company's scope 3 emissions from processing of sold intermediate products include the scope 1 and scope 2 emissions of downstream value chain partners (e.g., manufacturers).

## Calculating emissions from processing of sold products

Figure 10.1 gives a decision tree for selecting a calculation method for calculating scope 3 emissions from processing of sold products. Companies may use either of two methods:

- · Site-specific method , which involves determining the amount of fuel and electricity used and the amount of waste generated from processing of sold intermediate products by the third party and applying the appropriate emission factors
- · Average-data method , which involves estimating emissions for processing of sold intermediate products based on average secondary data, such as average emissions per process or per product.

Companies should choose a calculation method based on their business goals and their ability to collect data from processing of sold intermediate products by third parties. In many cases, collecting primary data from downstream value chain partners may be difficult. In such cases, companies should use the average-data method.

## Figure [10.1] Decision tree for selecting a calculation method for emissions from processing of sold products

Does processing of sold products contribute significantly to scope 3 emissions (based on screening) or is engagement with customers otherwise relevant to the business goals?

Use site-specific method

Can customers provide energy or GHG data related to processing of sold intermediate products?

yes yes

no no

Use average-data method

## Site-specific method

To calculate emissions from the processing of sold products by third parties, companies should collect either of the following types of data from downstream value chain partners:

- · Relevant activity data (e.g., fuel use, electricity use, refrigerant use, and waste) and relevant emission factors for each downstream process
- · GHG emissions data for each downstream process calculated by downstream value chain partners.

If downstream processes involve intermediate goods and/or material inputs other than those sold by the reporting company, emissions should be allocated between intermediate product(s) sold by the reporting company and other intermediate products/material inputs. All processing steps through to the production of the final finished product should be accounted for within this category. For examples of allocating emissions, refer to chapter 8 of the Scope 3 Standard .

If data cannot be obtained from downstream third party partners, the average data method should be used.

## Activity data needed

Companies should first collect data on the types and quantities of intermediate goods sold by the reporting company.

Companies should then collect either site-specific GHG emissions data provided by downstream value chain partners or site-specific activity data from downstream processes, including:

- · Quantities of energy (including electricity and fuels) consumed in process(es)
- · To the extent possible, mass of waste generated in process(es)
- · If applicable, activity data related to non-combustion emissions (i.e., industrial process or fugitive emissions).

## Emission factors needed

If site-specific activity data is collected, companies should also collect:

- · Emission factors for fuels
- · Emission factors for electricity
- · To the extent possible, emission factors for waste outputs
- · If applicable, emission factors related to non-combustion emissions (i.e., industrial process or fugitive emissions).

## Data collection guidance

Companies should collect data on the types and mass of intermediate goods sold by the reporting company from internal records.

Companies should request either GHG emissions data or activity data from downstream processes from the downstream value chain partners that control those processes. Downstream partners can obtain this data from, for example:

- · Internal IT systems
- · Utility bills
- · Purchase receipts
- · Meter readings.

Data sources for emission factors include:

- · The list of data sources provided on the GHG Protocol website (www.ghgprotocol.org/standards/scope-3-standard)
- · Company or manufacturer developed emission factors
- · Industry associations
- · For activity data, emission factors, and formulas for process and fugitive emissions, see the GHG Protocol website (http://www.ghgprotocol.org/calculation-tools/all-tools) and the IPCC 2006 Guidelines (http://www.ipcc-nggip.iges. or.jp/public/2006gl/index.html).

## CO 2 e emissions from processing of sold intermediate products =

## sum across fuel consumed in the processing of sold intermediate products:

∑ (quantity of fuel consumed (e.g., liter)

× life cycle emission factor for fuel source (e.g., kg CO e/liter)) 2

+

## sum across electricity consumed in the processing of sold intermediate products:

∑ (quantity of electricity consumed (e.g., kWh)

× life cycle emission factor for electricity (e.g., kg CO e/kWh)) 2

+

sum across refrigerants used in the processing of sold intermediate products:

∑ (quantity of refrigerant leakage (kg) × Global Warming Potential for refrigerant (kg CO e/kg)) 2

+

sum across process emissions released in the processing of sold intermediate products

+

to the extent possible, sum across waste generated in the in the processing of sold intermediate products:

∑ (mass of waste output (kg) × emission factor for waste activity (kg CO e/kg)) 2

## Example [10.1] Calculating emissions from processing of sold products using the site-specific method

utputs of processing the resin into handles. The information is summarized in the tables below: Company A, which produces plastic resin, is an exclusive supplier to Company B, which produces plastic handles for consumer goods. Company A collects information from Company B regarding the fuel and electricity used and waste o

| Fuel and electricity consumed   | Amount (kWh)   |   Emission factor (kg CO 2 e/kWh) |
|---------------------------------|----------------|-----------------------------------|
| Natural Gas                     | 3,500          |                               0.2 |
| Electricity                     | 2,000          |                               0.5 |

| Waste          |   Amount (kg) |   Emission factor (kg CO 2 e/kg waste) |
|----------------|---------------|----------------------------------------|
| Waste products |            50 |                                    0.5 |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data.

Emissions are calculated by multiplying activity data by respective emission factors, as follows:

## emissions from fuel consumed:

∑ (quantity of fuel consumed (e.g., liter) × emission factor for fuel source (e.g., kg CO e/liter)) 2 = 3,500 × 0.2 = 700 kg CO e

2

## emissions from electricity consumed:

- ∑ (quantity of electricity consumed (e.g., kWh) × emission factor for electricity (e.g., kg CO e/kWh)) 2

= 2,000 × 0.5 = 1,000 kg CO e 2

## emissions from waste output:

- ∑ (mass of waste output (kg) × emission factor for waste activity (kg CO e/kg))

2

2 = 50 × 0.5 = 25 kg CO e

## total emissions from processing of sold intermediate products

= emissions from fuel + emissions from electricity + emissions from waste = 700 + 1,000 + 25 = 1,725 kg CO e

2

## Average data method

In this method, companies collect data on the type of downstream process(es) involved in transforming or processing sold intermediate products into final products and apply relevant industry average emission factors to determine emissions. The method should be used when it is not possible to collect data from downstream value chain partners.

If the downstream processes use multiple types of inputs, companies should allocate emissions to the intermediate product sold by the reporting company. See chapter 8 of the Scope 3 Standard for guidance on allocation.

## Activity data needed

For each type of sold intermediate product, companies should collect data on:

- · The process(es) involved in transforming or processing sold intermediate products into an usable state final product, subsequent to sale by the reporting company
- · Information needed for allocation (e.g., mass, economic value).

## Emission factors needed

Companies should collect:

- · Average emission factors for processing stages required to transform the sold intermediate product into a final product, expressed in units of emissions (e.g., CO , CH , N O) per unit of product (e.g., kg CO /kg of final product). 2 4 2 2

Care should be taken when selecting secondary data sources to understand the boundaries of the data and whether any additional calculation is required to avoid double counting.

## Data collection guidance

Data sources for activity data include:

- · Purchasing records
- · Internal data systems
- · Industry-average data from associations or databases.

Data sources for emission factors include:

- · Life cycle databases
- · The GHG Protocol website (http://www.ghgprotocol.org/calculation-tools/all-tools)
- · Companies or manufacturers
- · Industry associations.

Calculation resources include:

- · GHG Protocol Calculation Tool, 'Stationary Combustion GHG Emissions Calculation Tool. Version 2.0. June 2009,' developed by World Resources Institute, available at http://www.ghgprotocol.org/calculation-tools/all-tools
- · Defra GHG Conversion Factors, developed by the UK Department of Environment, Food and Rural Affairs (Defra), available at www.defra.gov.uk/environment/business/reporting/conversion-factors.htm.

## Calculation formula [10.2] Average-data method

## CO 2 e emissions from processing of sold intermediate products =

## sum across intermediate products:

∑ (mass of sold intermediate product (kg)

× emission factor of processing of sold products (kg CO e/kg of final product)) 2

## Example [10.2] Calculating emissions from processing of sold products using the average data method

ompany E collects industry average emission factors for the relevant processes. The information is summarized in the Company E is a producer of sugar and an exclusive supplier to Company F, which makes candy. Company F confirms with Company E that after sugar is purchased, there are further processes before the final candy product is produced. C table below:

| Process                                                          | Mass of sold intermediate product (kg)   |   Emission factor of processing stages (kg CO 2 e/kg) |
|------------------------------------------------------------------|------------------------------------------|-------------------------------------------------------|
| Candy mixing, cooking, molding, cooling, wrapping, and packaging | 1,000                                    |                                                   1.5 |

Note: the activity data and emissions factors are illustrative only, and do not refer to actual data.

## emissions from candy mixing and cooking process:

∑ (mass of sold intermediate product × emission factor of processing stages (kg CO e/kg of final product)) 2 = 1,000 × 1.5 = 1,500 kg CO e 2