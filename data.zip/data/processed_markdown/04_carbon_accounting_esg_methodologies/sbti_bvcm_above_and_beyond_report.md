---
document_id: sbti_bvcm_above_beyond
title: "Above and Beyond: An SBTi Report on Beyond Value Chain Mitigation (BVCM)"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "SBTi"
year: 2024
original_file: "sbti_bvcm_above_and_beyond_report.pdf"
tables_detected: 67
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

ABOVE AND BEYOND: AN SBTI REPORT ON THE DESIGN  AND IMPLEMENTATION OF BEYOND VALUE CHAIN MITIGATION (BVCM)

VERSION 1.0

FEBRUARY 2024

## ACKNOWLEDGMENTS

This document was developed by the Science Based Targets initiative, with support from Systemiq and Climate Focus.

This report is funded in part by the Gordon and Betty Moore Foundation and the Climate and Land Use Alliance. The funders do not necessarily share the positions expressed in the publication.

The following individuals also provided support with translation of this document from English into Japanese, French, Mandarin, Spanish, Portuguese and Arabic: Akihiko Haga, Aline Bayon, Lucine Courthaudon, Kenza Taoufik, Brenda Chan, Esteban Badilla, Abigail Martinez, Inder Rivera, Fernanda Carvalho and Hana Zayed.

The SBTi would also like to acknowledge the members of the BVCM Expert Advisory Group and the SBTi partner organization Working Group: Alexander Farsan, Angela Anderson, Amir Safaei, Amir Sokolowski, Andika Putraditama, Anita Otubu, Anshari Rahman, Bhaskar Singh Karky, Bogolo Kenewendo, Brad Schallert, Candace Vinke, Carlijn Nouwen, Chandra Shekhar Silori, Chidi Oti-Obihara, Daniel Zarin, David Burns, Derik Broekhoff, Diksha Pillay, Disha Agarwal, Donna Lee, Duan Maosheng, Elijah Innes-Wimsatt, Frances Seymour, Gabriel Chaves Barboza, Gilles Dufrasne, Hans Näsman, Hilda Galt, Hilde Stroot, Jenny Ahlen, John Holler, Johnny White, Juliette de Grandpre, Karol Gobczynski, Katie Lebling, Kelley Kizzier, Kerry Constabile, Keyvan Macedo, Kuki Soejachmoen, Lene Peterson, Mark Kenber, Meera Atreya, Melissa Gallant, Morten Rossé, Nguyen Phi Hung, Paola Delgado Luna, Patricia Pinho, Paul Vermaak, Pedro Faria, Rob Macquarie, Robert Höglund, Roberta Barbieri, Ronan Hodge, Ruhana Zariwala, Simon Petley, Stephan Singer, Tanja Havemann, Tereza Bicalho, Thiago Chagas, Tim Juliani, Tim Young, Xiaolu Zhao, Zeke Hausfather.

Finally, the SBTi would like to acknowledge the SBTi Technical Council for review.

## Disclaimers

Although reasonable care was taken in the preparation of this document, SBTi hereby states and affirms that the document is provided without warranty, either expressed or implied, of accuracy, completeness, or fitness for purpose. SBTi hereby further disclaims any liability, direct or indirect, for damages or loss relating to the use of this document to the fullest extent permitted by law. This document is based on a voluntary framework or procedures and is not intended to replace the legal or regulatory requirements of any country.

The information (including data) contained in the document is not intended to constitute or form the basis of any advice (financial or otherwise). SBTi does not accept any liability for any claim or loss arising from any use of or reliance on any data or information in the document.

SBTi accepts no liability for the reliability of any information provided by third parties. Applicable to all documents where copyright is asserted.

This document is protected by copyright. Information or material from this document may be reproduced only in unaltered form for personal, non-commercial use. All other rights are reserved. Information or material used from this document may be used only for the purposes of private study, research, criticism, or review permitted under the Copyright Designs &amp; Patents Act 1988 as amended from time to time ('Copyright Act'). Any reproduction permitted in accordance with the Copyright Act shall be acknowledged.

© SBTi 2024

Partner Organizations:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Authors:

Scarlett Benson

Alice Farrelly Emma Watson Haley Kazanecki Martina Massei Astrid von Preussen Charlotte Steck Danick Trouwloon

## Project/Review team:

Alberto Carrillo Pineda

Aman Sidhu

Christa Anderson

Emma Borjigin-Wang

Ginger Kowal

Hugo Ernest-Jones

Luke Pritchard

Maria Outters

Martha Stevenson

Paulina Tarrant

Piera Patrizio

Roman Czebiniak

Rosie Williams

In collaboration with:

<!-- image -->

<!-- image -->

## FOREWORD

The world is dangerously close to surpassing the 1.5°C threshold of global warming, with billions of people already suffering the impacts of climate change. There is a rapidly closing window of opportunity to avoid the most devastating impacts of climate change and to unlock new and better forms of growth.

The private sector has a critical role in averting the dangers ahead through the investment, innovation, and the transformation of their business models and the alignment of their financing flows with a net-zero future.

It is therefore heartening to witness the rapid increase in companies working to reduce their emissions in line with a 1.5°C pathway through the Science Based Targets initiative (SBTi), with growth in 2023 across all continents.

Yet private-sector climate finance is not increasing at the necessary pace and there are real public-sector constraints in the wake of the pandemic. There is an untapped opportunity to generate powerful multipliers through collaborative financing partnerships between countries and their governments, multilateral institutions, and the private sector.

The SBTi's Beyond Value Chain Mitigation (BVCM) recommendation is thus an important and timely resource for companies as they work to manage the immense risks of climate change and enhance longterm value.

Private-sector investment into BVCM can unlock debtfree financial resources for sustainable, low-carbon, resilient growth. If aggregated appropriately it can be a valuable strategic source of finance for developing countries, many of whom are highly debt-constrained.

Integrity is paramount. Investment by companies into mitigation beyond their own value chains must not displace efforts to reduce their scope 1, 2 and 3 emissions. Finance must deliver genuine and additional mitigation at prices that reflect the social cost of carbon, and these will be rising over time. The social dimensions of the low-carbon transition are also fundamental; BVCM can help catalyze financing for just transitions and investments needed in the poorest countries that are often the least responsible and yet more vulnerable to climate change.

Private-sector companies have a powerful opportunity to shape the new economy by investing in climate action both within and beyond their value chains. The SBTi's recommendation on BVCM is consistent with, and can help foster, achieving both the quality and quantity of investment that will be essential if we are to avoid catastrophe for our children and grandchildren.

## Lord Nicholas Stern

Chair of the Grantham Research Institute on Climate Change and the Environment at the London School of Economics

<!-- image -->

Current production and consumption systems are driving a triple planetary crisis of climate change, biodiversity loss and pollution and waste. This drives increased insecurity, decreased resilience, and worsening socioeconomic and environmental outcomes in a vicious cycle.

The science is clear: we must decarbonize and dematerialize our economy through the implementation of supply-side measures to improve the efficiency of production systems and demandside measures to reduce resource use and overall production and consumption. We must address the root causes of the planetary crises through natural resource management to protect, restore and regenerate nature and support wellbeing across the global population.

As a former Minister of Environment and Climate Change in Brazil and the Co-Chair of the International Resource Panel, it is clear to me that the global environmental challenges that we face require global solutions. There is a need to bring diverse actors together around just, pragmatic and solution-oriented pathways.

Companies have a fundamental role to play in this endeavor. The SBTi's new report on beyond value chain mitigation is thus an important step in defining corporate leadership to address the triple planetary crisis. It is essential for leading companies to go beyond their sciencebased emission reduction targets to support other economic and social actors to mitigate emissions.

## Izabella Teixeira

Former Minister of the Environment and Climate Change of Brazil and Co-Chair of the International Resource Panel

<!-- image -->

Solving the climate crisis requires the deployment of a wide range of solutions - from protecting and restoring forests at scale, and implementing new energy solutions to developing technologies for removing and storing CO2 from the atmosphere.

<!-- image -->

## I founded Milkywire, a technology-

driven climate and nature platform, in 2018 to enable companies and individuals to support the range of solutions needed to achieve global climate goals. Our Climate Transformation Fund focuses on contributions to innovative climate projects and seeks to maximize long-term CO2 reduction or removal per dollar spent.

Corporate climate leadership means reducing value chain emissions and also taking responsibility for unabated emissions through BVCM. BVCM represents an important tool for companies to contribute to global climate goals. I therefore welcome the work of the SBTi in providing much needed guidance for companies on this topic. In particular, the SBTi's principles for BVCM (scale, financing need, co-benefits and climate justice) will be highly valuable in guiding companies towards high-integrity and high-impact investments.

Our ongoing work at Milkywire to provide additional guidelines for companies operationalizing BVCM, in collaboration with Gold Standard, will complement and build upon the firm foundation now provided by the SBTi.

## Nina Siemiatowski

Founder and Chief Executive Officer of Milkywire

## EXECUTIVE SUMMARY

## EXECUTIVE SUMMARY

<!-- image -->

## THE CLIMATE CRISIS AND CORPORATE CLIMATE ACTION

The world is dangerously close to passing the 1.5°C threshold , beyond which humanity and other species are exposed to existential and irreversible negative impacts. To avoid the most severe climate impacts, global mean surface temperature must be stabilized at or below 1.5°C of warming. This translates to a peaking of global greenhouse gas (GHG) emissions before 2025 at the latest, halving of emissions by 2030 and reaching net-zero carbon dioxide emissions (CO2) by mid-century. 1

Impacts are already being felt across the world. At today's level of warming (estimated at between 0.95 and 1.2°C), tens of millions of people are already exposed to temperature extremes. 2,3  In 2022, climate change and La Niña drove overall losses of USD 270 billion and insured losses of USD 120 billion. 4

Progress to address the climate crisis is insufficient. There is a significant gap in terms of the globally committed levels of climate mitigation and climate finance and what is needed to limit warming to 1.5°C. Estimates suggest that annual mitigation finance needs to surpass USD 8.4 trillion per year between 2023 and 2030, and to rise to USD 10.4 trillion per year in the following two decades, compared to just USD 1.2 trillion a year today. 5

Private sector adoption of emission reduction targets can play a significant role in addressing emissions within corporate value chains. This is consistent with the Intergovernmental Panel on Climate Change (IPCC) Sixth Assessment Report (AR6) which states that 'unless there are immediate and deep emissions reductions across all sectors, limiting global warming to 1.5°C will be beyond reach.' 6

However, it is also important to catalyze private sector finance to mitigate emissions that occur beyond corporate value chains, mitigation opportunities that are commonly underserved by traditional finance mechanisms. For example, the United Nations Environment Programme highlights that private sector funding of nature-based solutions both within and beyond corporate value chains must increase dramatically and quickly. 7

## BEYOND VALUE CHAIN MITIGATION (BVCM) OVERVIEW

The SBTi drives ambitious corporate climate action by enabling businesses and financial institutions globally to set science-based greenhouse gas emissions reduction targets . The SBTi Corporate Net-Zero Standard provides guidance, criteria, and recommendations for companies to set 1.5°C aligned climate targets. Companies are required to set near- and long-term targets to abate their value chain emissions, reaching a residual level in line with 1.5°C scenarios by no later than 2050. Companies are also required to neutralize the climate impact of any residual emissions at the net-zero target year and any GHG emissions released thereafter through the permanent removal and storage of carbon from the atmosphere. 8

The SBTi recommends that companies also deliver beyond value chain mitigation (BVCM) to accelerate global progress towards net-zero by supporting other economic and social actors to reduce and/or remove GHG emissions and by taking responsibility for their unabated emissions that contribute to climate change. BVCM activities and investments are not accounted for in the company's scope 1, 2 or 3 GHG inventory and therefore do not count towards achieving value-chain emission reduction targets. Efforts to deliver BVCM must not replace or delay corporate value chain decarbonization in line with a 1.5°C pathway - instead, BVCM is a mechanism by which companies go above and beyond value chain abatement.

This document sets out suggestions to support the BVCM recommendation of the SBTi Corporate Net-Zero Standard (R9) and to provide companies with proposals for the design and implementation of high-integrity and high-impact BVCM strategies.

At the time of publication, the SBTi does not have plans to validate BVCM claims, particularly given that others are already working to define BVCM-related claims, including the Voluntary Carbon Market Integrity Initiative (VCMI).

<!-- image -->

## THE BUSINESS CASE FOR BVCM

Funding of BVCM, if done right, can unlock an array of opportunities, mitigate future risks and protect and enhance long-term value. The business case for BVCM will depend on the region, market and industry in which the company operates and ultimately the extent to which the company is impacted by the changing physical environment linked to climate change and the associated changes in policy, financial markets, consumer markets, society and technology. For example, a food and agricultural company might identify supply chain resilience opportunities from deploying BVCM towards the restoration of landscapes ecologically linked to its supply chain.

## BVCM GOALS AND PRINCIPLES

The BVCM Goals and Principles below have been developed to suggest to companies how they could move towards high-impact and high-integrity BVCM activities and investments.

## BVCM Goals

<!-- image -->

<!-- image -->

## Principles

<!-- image -->

Deliver additional near-term mitigation outcomes to achieve the peaking of global emissions in the mid-2020s and the halving of global emissions by 2030.

Drive additional finance into the scale-up of nascent climate solutions and enabling activities to unlock the systemic transformation needed to achieve net-zero by mid-century globally.

Scale :

<!-- image -->

<!-- image -->

<!-- image -->

Maximize mitigation outcomes

Financing need :

Focus on underfinanced mitigation

Co-benefits : Support the SDGs

Climate justice :

Address inequality

## SUGGESTIONS FOR DESIGNING AND IMPLEMENTING BVCM STRATEGIES

Figure 1 and Table 1 below show the steps that a company might take in designing and implementing a BVCM strategy. The SBTi suggests that companies periodically review their BVCM pledges and strategies - in this sense, the four steps are cyclical in nature. The details underpinning each step described in the table below are outlined in more detail in the main body of this document.

Figure 1: Four high-level steps for designing and implementing high-integrity and high-impact BVCM strategies

<!-- image -->

## Table 1:  Summary of step-by-step recommendations

## STEP 1: SET AND WORK TO DELIVER A NET-ZERO TARGET

1.1: Develop and disclose a full GHG emissions inventory

1.2: Set, submit, validate and disclose a science-based net-zero target

1.3: Develop, disclose and work towards a net-zero aligned climate transition plan

2.1: Determine the business case and strategic objectives for BVCM

## 2.2: Define the time period of the BVCM pledge

- Develop a comprehensive emissions inventory that covers at least 95% of companywide scope 1 and 2 GHG emissions and includes a complete scope 3 inventory.
- Update the GHG inventory on an annual basis.
- Have the GHG inventory verified annually by an independent third party.
- Publicly report the GHG inventory and verification statement annually in the company financial statement, the company website and through the CDP questionnaire.
- Please refer to the SBTi Corporate Net-Zero Standard for the full set of criteria and recommendations.
- Develop, disclose and annually update a net-zero aligned climate transition plan in line with the recommendations of the Transition Plan Taskforce (TPT), including reporting on progress.

## STEP 2: ESTABLISH A BVCM PLEDGE

- Consider how BVCM can unlock opportunities, minimize future risks and protect and enhance the company's long-term value.
- Define strategic objectives for BVCM.
- Integrate the strategic objectives for BVCM into the company's climate transition plan and associated disclosures to facilitate a holistic and strategic approach to climate action both within and beyond the value chain.
- Determine the forward-looking pledge period. It is recommended that this covers a period of five years or greater.
- Publicly report on the BVCM pledge period.
- Periodically review the BVCM pledge.

2.3: Define the scale of the BVCM pledge

3.1: Define quality standards and guardrails for BVCM activities and investments

3.2: Deploy resources and finance towards a portfolio of BVCM activities

## STEP 2: ESTABLISH A BVCM PLEDGE

- The SBTi recognizes the varying 'ability to pay' for BVCM across sectors (based on differing profitability margins) and thus welcomes all efforts by companies to deliver BVCM. The SBTi also recognizes that requirements of certification standards or claims codes may dictate the scale of a BVCM pledge. As an informative guide, the SBTi describes an approach whereby a company would:
- a. Apply a science-based carbon price to unabated scope 1, 2 and 3 emissions each year or over a defined pledge period to determine a financial budget for climate action beyond the scope of the company's science-based target.
- b. Use this budget to fund a combination of near-term BVCM outcomes (aligned with BVCM Goal 1) and long-term BVCM finance (aligned with BVCM Goal 2), as well as wider categories of climate action.
- -As a suggestion, the SBTi proposes that companies use a portion of this budget to deliver ex-post, quantified BVCM outcomes (measured in tCO2e) equivalent to at least 50% of the company's unabated scope 1, 2 and 3 emissions. It is recommended that these emissions reductions and removals are verified by independent third parties using standardized methodologies and that they adhere to recognized high-quality criteria.
- -For companies that are not able to align with this suggestion, the SBTi also provides examples of other methods for determining the scale of a BVCM pledge (see Annex D).

## STEP 3: TAKE ACTION TO DELIVER BVCM

- Commit to minimum quality standards to ensure additionality, permanence and avoidance of leakage and avoidance of double counting where relevant.
- Establish, commit to and disclose safeguarding principles to ensure that BVCM activities do not have an adverse social or environmental impact.
- Direct finance and resources where they are most needed in line with the BVCM Goals and Principles defined within this document.
- Publicly disclose how the company's BVCM activities and investments are aligned with the SBTi's BVCM Goals and Principles.

## 4.1: Establish a BVCM Measurement Reporting and Verification (MRV) framework to measure

4.2: Report annually on BVCM activities, investments, and outcomes

## STEP 4: REPORT BVCM ACTIVITIES AND OUTCOMES

- Develop a BVCM MRV framework to measure, report and verify the mitigation outcomes as a result of BVCM funding over a period of time.
- Rely on existing standards and reporting frameworks to qualify and assure BVCM activities and investments.
- Have BVCM mitigation outcomes verified by an independent third party that assesses the accuracy and completeness of an emissions reduction or removal intervention.
- Where carbon credits are the mechanism for deploying BVCM, credits should be verified by an independent third party to the protocols of a high-quality carbon standard.
- In the absence of existing standards, develop and disclose BVCM-specific indicators and metrics that can be independently assured by an approved auditor following internationally accepted assurance standards.
- Publicly disclose annual verification certificates or statements.
- Report transparently on the finance deployed towards BVCM, as well as the mitigation interventions and outcomes and co-benefits delivered on an annual basis (in line with the company's GHG inventory reporting period). Emissions reductions and removals should be reported separately.
- Report on BVCM activities and investment through the annual CDP questionnaire, within the annual financial statement and the annual sustainability reports or website.
- For companies that have not been able to align with the suggestion described in step 2.3 above, it is recommended that they report on the GHG externality linked to their unabated emissions. This means applying a science-based carbon price to unabated scope 1, 2 and 3 emissions and then reporting the total cost of those emissions minus the finance deployed towards BVCM and wider categories of climate action (adaptation and loss and damage).
- As per the other steps:

Step 1.1 : Publicly report the GHG inventory and verification statement annually in the company financial statement, the company website and through the CDP questionnaire.

Step 1.2 : Disclose details of the company's validated net-zero target as well as progress towards the target on an annual basis in line with the SBTi's Corporate Net-Zero Standard.

Step 1.3 : Develop, disclose and annually update a net-zero aligned climate transition plan in line with the recommendations of the Transition Plan Taskforce (TPT), including reporting on progress.

4.2: Report annually on BVCM activities, investments, and outcomes

## 4.3: Make transparent and accurate BVCM claims

## STEP 4: REPORT BVCM ACTIVITIES AND OUTCOMES

Step 2.1 : Integrate the strategic objectives for BVCM into the company's climate transition plan and associated disclosures.

Step 2.2 : Publicly report on the forward-looking BVCM pledge over the defined period.

Step 2.3 : Report the scale of the BVCM pledge and where carbon prices are used to determine the scale of the pledge, report on the source of this price and justification for the price chosen.

Step 3.1 : Establish, commit to and disclose safeguarding principles to ensure that BVCM activities do not have an adverse social or environmental impact.

Step 3.2 : Publicly disclose how the company's BVCM activities and investments are aligned with the SBTi's BVCM Goals and Principles.

Step 4.1 : Publicly disclose annual verification certificates or statements of BVCM outcomes.

Step 4.3 : Transparently and accurately communicate a company's BVCM engagement, by backing headline claims (such as a BVCM pledge) with a strong narrative and clear reporting justifying the scale of the BVCM pledge, describing the portfolio of associated activities and investments, as well as the guardrails for BVCM activities and investments.

- Ensure that claims comply with laws and regulation that govern and regulate environmental statements and claims in relevant jurisdictions.
- Choose the type of BVCM claim (e.g., compensation or contribution claims) in the context of the business objectives and regulatory context.
- Support headline claims (such as the BVCM pledge) with nuanced narrative claims which report the full content, context and limitations of the claim.
- Ensure that BVCM claims meet general requirements of high-integrity and highambition environmental claims. The VCMI defines Principles for Climate Mitigation Claims Credibility, whereby claims should:
- -Be clear to the target audience(s);
- -Be conservative;
- -Be transparent;
- -Be traceable;
- -Be true and verifiable;
- -Be accurate;
- -Be relevant and not misleading;
- -Be informative;
- -Set the right incentives for the target audience. 9
- As far as possible, companies should ensure that their BVCM claims are externally audited or certified.

## CONTENTS

| ACKNOWLEDGMENTS                                                       |   2 |
|-----------------------------------------------------------------------|-----|
| FOREWORD                                                              |   4 |
| EXECUTIVE SUMMARY                                                     |   6 |
| The climate crisis and corporate climate action                       |   6 |
| Beyond value chain mitigation (BVCM) overview                         |   7 |
| The business case for BVCM                                            |   8 |
| BVCM Goals and Principles                                             |   8 |
| Suggestions for designing and implementing BVCM strategies            |   9 |
| INTRODUCTION                                                          |  17 |
| The SBTi                                                              |  18 |
| The Corporate Net-Zero Standard                                       |  18 |
| BVCM in the Corporate Net-Zero Standard                               |  18 |
| The purpose and structure of this document                            |  19 |
| BVCM: DEFINITION AND RATIONALE                                        |  21 |
| BVCM defining features                                                |  22 |
| The scientific rationale for BVCM                                     |  25 |
| BVCM Goals and portfolio design Principles                            |  27 |
| THE BUSINESS CASE FOR BVCM                                            |  29 |
| BVCM benefits linked to changes in the physical environment           |  31 |
| BVCM benefits linked to changes in the policy environment             |  32 |
| BVCM benefits linked to changes in financial markets                  |  32 |
| BVCM benefits linked to market changes                                |  32 |
| BVCM benefits linked to changes in society's expectation of companies |  33 |
| BVCM benefits linked to changes in technology                         |  33 |

| RECOMMENDATIONS FOR DESIGNING AND IMPLEMENTING ABVCMSTRATEGY                  |   35 |
|-------------------------------------------------------------------------------|------|
| Step 1: Set and Work to Deliver a Net-Zero Target                             |   38 |
| Step 2: Establish a BVCM Pledge                                               |   41 |
| Step 3: Take Action to Deliver BVCM                                           |   45 |
| Step 4: Report BVCMActivities and Outcomes                                    |   48 |
| ILLUSTRATIVE CASE STUDIES                                                     |   55 |
| Umbrella Corporation                                                          |   57 |
| Rede Camp                                                                     |   60 |
| Pikatto                                                                       |   62 |
| Vihaan Ventures                                                               |   64 |
| ACRONYMS                                                                      |   67 |
| GLOSSARY                                                                      |   70 |
| ANNEXA: BVCMAND NEUTRALIZATION OF RESIDUAL EMISSIONS                          |   84 |
| ANNEX B: ILLUSTRATIVE EXAMPLES OF BVCM                                        |   87 |
| Principle 1. Scale: Maximize mitigation outcomes                              |   89 |
| Principle 2. Financing need: Focus on underfinanced mitigation                |   92 |
| Principle 3. Co-benefits: Supporting the Sustainable Development Goals (SDGs) |   93 |
| Principle 4. Climate Justice: Addressing inequality                           |   94 |
| ANNEX C: WIDER CATEGORIES OF CLIMATE ACTION                                   |   96 |
| Climate change adaptation                                                     |   97 |
| Addressing climate change loss and damage                                     |   98 |
| ANNEX D: METHODS FOR DETERMINING THE NATUREAND SCALE OFABVCMPLEDGE            |   99 |
| Ton-for-ton: linking BVCM to unabated value chain emissions                   |  100 |
| Money-for-ton: applying a carbon price to unabated value chain emissions      |  102 |
| Money-for-money: linking BVCM to a portion of revenue or profit               |  103 |
| ANNEX E: CARBON PRICING                                                       |  104 |
| Voluntary corporate adoption of carbon pricing                                |  105 |
| Types of carbon prices                                                        |  106 |
| Science-based carbon pricing                                                  |  111 |

| ANNEX F: DEVELOPMENTOFTHIS REPORT                                     |   112 |
|-----------------------------------------------------------------------|-------|
| Timeline of activities                                                |   113 |
| BVCM public consultation                                              |   114 |
| Further research                                                      |   117 |
| ANNEX G: MAPPING OFTHE BVCM REPORTWITHTHEVCMI CLAIMS CODE OF PRACTICE |   118 |
| REFERENCES                                                            |   123 |

<!-- image -->

## INTRODUCTION

<!-- image -->

## THE SBTI

The Science Based Targets initiative (SBTi) drives ambitious corporate climate action by enabling businesses and financial institutions globally to set science-based greenhouse gas emissions reduction targets.

It was formed as a collaboration between CDP, the United Nations Global Compact, World Resources Institute (WRI), the World Wide Fund for Nature (WWF) and the We Mean Business Coalition. The SBTi's goal is to enable companies worldwide to do what climate science requires of the global economy: to halve emissions by 2030 and achieve net-zero before 2050.

The SBTi develops criteria and provides tools and guidance to enable businesses and financial institutions to set GHG emissions reduction targets in line with what science tells us is needed to keep global heating below 1.5°C.

## THE CORPORATE NET-ZERO STANDARD

In October 2021, the SBTi published the Corporate Net-Zero Standard which provides guidance, criteria, and recommendations for companies to set near- and long-term climate targets consistent with scenarios that limit global temperature rise to 1.5°C with no or limited overshoot. The Corporate Net-Zero Standard comprises four key components:

- Near-term science-based targets (SBTs) : Companies are required to set 5-10-year targets to reduce emissions within the company value chain in line with 1.5°C pathways. 1
- Long-term SBTs : Companies are required to set targets to reduce emissions within the company value chain to a residual level in line with 1.5°C scenarios by no later than 2050. 2
- Beyond value chain mitigation (BVCM) : Companies are encouraged to take immediate and consistent action to mitigate emissions beyond their value chains to support global efforts to limit global temperature rise to 1.5°C. 3
- Neutralization of any residual i  emissions : Companies are required to neutralize the climate impact of any residual emissions at the net-zero target year and any greenhouse gas (GHG) emissions released into the atmosphere thereafter through the permanent removal and storage of carbon from the atmosphere.
- i Residual emissions are those which cannot be completely eliminated despite implementing all available mitigation measures contemplated in pathways that limit warming to 1.5°C with no or limited overshoot. A company's residual emissions are its scope 1, 2, and 3 emissions that remain once its long-term target has been achieved.

<!-- image -->

## BVCM IN THE CORPORATE NET-ZERO STANDARD

BVCM is defined in the Corporate Net-Zero Standard as 'mitigation action or investments that fall outside a company's value chain, including activities that avoid or reduce GHG emissions, or remove and store GHGs from the atmosphere.' 10

It is included as a best practice recommendation rather than a criterion which must be met for a company's netzero target to be validated by the SBTi. The BVCM recommendation is formulated as follows:

"R9 - Beyond value chain climate mitigation: Companies should take action or make investments outside their own value chains to mitigate GHG emissions in addition to their near-term and long-term science-based targets. For example, a company could provide annual support to projects, programs and solutions that provide quantifiable benefits to climate, especially those that generate additional co-benefits for people and nature. Companies should report annually on the nature and scale of those actions pending further guidance.' 11

## THE PURPOSE AND STRUCTURE OF THIS DOCUMENT

This document provides suggestions to support the BVCM recommendation (R9) included within the Corporate Net-Zero Standard. Its purpose is to support companies in the design and implementation of BVCM strategies to accelerate progress towards global net-zero. It is structured as follows:

- BVCM definition and rationale : provides the definition of BVCM and rationale for why it is an important mechanism to accelerate global progress to net-zero;
- The business case for BVCM : provides description, timelines and impact expected, including opportunities for risk management and value creation;
- Suggestions for the design and implementation of the BVCM strategy : describes the steps involved in a BVCM pledge and implementation cycle, including setting a net-zero climate target, establishing a BVCM pledge, taking action to deliver BVCM and reporting BVCM activities and outcomes;
- Illustrative case studies : provides fictional examples to illustrate how companies in a range of sectors might implement the recommendations of this report;
- Supporting annexes : includes supplementary materials on topics such as carbon pricing.

As a guide for companies implementing the BVCM recommendation within the SBTi Corporate Net-Zero Standard, where the term 'should' is used it indicates a suggestion or that which is advised but not required to conform to the R9 specification in the SBTi Corporate Net-Zero Standard.

It is important to note, that, at the time of publication, the SBTi does not have plans to validate BVCM claims. The SBTi's core focus is on defining voluntary claims related to the commitment to and achievement of near- and long-term science-based value chain abatement and net-zero in alignment with SBTi standards. Furthermore, other market players are working to define BVCM-related claims, including the Voluntary Carbon Market Integrity Initiative (VCMI) which focuses specifically on claims related to the use of high-quality carbon credits. Throughout this document, links to the November 2023 VCMI Claims Code of Practice are provided to support companies that are implementing the recommendations of this BVCM report and preparing to make VCMI Carbon Integrity Silver, Gold or Platinum claims. Annex G also provides a mapping of the VCMI Claims Code of Practice and the SBTi's BVCM report.

<!-- image -->

## BVCM: DEFINITION AND RATIONALE

<!-- image -->

## BVCM: DEFINITION AND RATIONALE

## BVCM DEFINING FEATURES

BVCM is defined as mitigation action or investments that fall outside a company's value chain, including activities that avoid or reduce GHG emissions, or remove and store GHGs from the atmosphere. 12  Companies can deliver beyond value chain mitigation through a range of instruments including through the purchase and retirement of high-quality carbon credits and direct investments (e.g., equity, debt or project finance).

It is important to emphasize that a company's efforts to deliver BVCM must not replace or delay efforts to reduce its scope 1, 2 and 3 emissions in line with a

<!-- image -->

1.5°C pathway. This is consistent with the Intergovernmental Panel on Climate Change (IPCC) Sixth Assessment Report (AR6) which states that 'unless there are immediate and deep emissions reductions across all sectors, limiting global warming to 1.5°C will be beyond reach' and 'that options are available now in every sector that can at least halve emissions by 2030.' 13

Instead, BVCM is a mechanism by which companies can go above and beyond their science-based targets to accelerate the global net-zero transition by helping other economic and social actors to reduce and/or remove GHG emissions today and by funding activities which can expect to deliver BVCM in the longer term. It can also be a way for companies to take responsibility for their unabated emissions as they transition to net-zero.

Given the urgency of the climate crisis, the SBTi encourages all companies working to decarbonize their operations and wider value chains to take immediate and consistent action to deliver BVCM.

Figure 2: Illustration of beyond value chain mitigation

<!-- image -->

## Table 2: Summary of BVCM defining features

| Definition                                          | Mitigation action or investments that fall outside a company's value chain, including activities that avoid or reduce GHGemissions, or remove and store GHGs from the atmosphere.                                                                                                                                                                                                                                                           |
|-----------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Purpose                                             | emissions. BVCM allows companies                                                                                                                                                                                                                                                                                                                                                                                                            |
| Eligible mitigation outcomes                        | BVCM includes both GHGemissions reductions and carbon dioxide removals.                                                                                                                                                                                                                                                                                                                                                                     |
| Where and how are mitigation outcomes accounted for | Mitigation outcomes would not be accounted for in the company's scope 1, 2 3 GHGinventory. One method for accounting for BVCM interventions is using intervention (or project) accounting methods which measure system-wide GHGimpacts relative to a counterfactual baseline scenario or performance benchmark that represent the conditions most likely to occur in the absence of the mitigation project that generates the credit. 14,ii |
| Timing                                              | Once a company has set a net-zero target, it is encouraged to and consistent action to deliver BVCM each year as it transitions                                                                                                                                                                                                                                                                                                             |
| Status within the SBTi Corporate Net-Zero Standard  | Companies are recommended , but not required, to deliver BVCM. Companies are recommended , but not required, to report annually on the nature and scale of their BVCM activities and investments.                                                                                                                                                                                                                                           |

Please see Annex A for a comparison of the defining features of BVCM and neutralization of residual emissions.

ii In life cycle assessment (LCA), inventory methods correspond to attributional methods and intervention methods correspond to consequential methods.

## THE SCIENTIFIC RATIONALE FOR BVCM

## Boundaries for avoiding the most catastrophic impacts of climate change

Scientific consensus indicates that the 'safe boundary' to avoid the most severe climate impacts on humans and other species requires stabilization of the global mean surface temperature at or below 1.5°C of warming. 15,16 According to the IPCC, the remaining carbon budget for a 50% chance of limiting warming to 1.5˚C with no or limited overshoot is only 500 gigatons CO2 (GtCO2), which translates to a peaking of global GHG emissions before 2025, a 43% reduction by 2030, and reaching net-zero CO2 emissions around mid-century. 17

However, at today's level of warming (estimated between 0.95 and 1.2°C), tens of millions of people are already exposed to temperature extremes. 18,19  In some regions of the world, climate impacts are so frequent and severe that no adaptation strategies can fully avoid losses and damages. 20  The Earth Commission therefore concludes that the 'just boundary' of climate change should be set at or below 1.0°C - a threshold that has already been passed. 21

## The emissions and climate finance gap

The 'emissions gap' typically refers to the gap between the committed levels of climate mitigation and what is needed to achieve 1.5°C. Estimates suggest that policies presently in place around the world, if fully implemented, would limit warming to just 2.7°C - representing a significant overshoot of the 1.5°C safe boundary of climate change, and an even greater overshoot of the just boundary described by the Earth Commission. 22

Correspondingly, there is a significant climate finance gap; the Climate Policy Initiative estimates that annual mitigation finance needs to surpass USD 8.4 trillion per year between 2023 and 2030, and to rise to USD 10.4 trillion per year in the following two decades, compared to just USD 1.2 trillion a year today. 23

## Climate finance is needed to scale existing climate solutions and to innovate new solutions for net-zero

The IPCC AR6 highlights that 'options are available now in every sector that can at least halve emissions by 2030.' 24 Similarly, the International Energy Agency (IEA) states that existing technologies provide nearly all of the emissions reductions required to 2030. 25  However, in the longer-term to achieve net-zero by 2050, the IEA estimates that almost 50% of emissions reductions will need to come from technologies currently at demonstration or prototype stage and which need funding to rapidly scale. 26

While the IPCC 1.5°C-consistent pathways with no or limited overshoot place heavy emphasis on deep, rapid and sustained cuts to emissions in all sectors, they also rely on carbon dioxide removals (CDR) to neutralize the climate impact of emissions from sources that are difficult, impossible or take more time to eliminate. 27 As with emissions reduction solutions, existing CDR solutions (e.g., afforestation, reforestation and management of existing forests) are expected to provide the lion's share of CDR in 2030 (78-100%) while the contribution of novel CDR methods, such as direct air carbon capture and storage and enhanced weathering, will increase throughout the century. 28  Investment into CDR innovation and R&amp;D is needed now since the amount of CDR needed in the second half of the century will only be feasible if we see substantial capital deployment in the next ten years. 29

## The role of corporates in addressing the global mitigation and finance gap

Closing the emissions gap requires scaling-up the adoption and implementation of strategies to mitigate emissions from activities within corporate operations and wider value chains, but also, emissions from activities not sitting directly within corporate value chains, many of which are commonly underserved by traditional finance mechanisms. While the adoption of voluntary emission reduction targets can play a significant role in addressing emissions within corporate value chains, it is also important important to catalyze private sector finance to mitigate emissions from other sources.

Furthermore, it is important to note that the transition towards net-zero aligned business models is a long-term transition. Emissions released into the atmosphere before achieving full or near-full elimination of emissions will accumulate in the atmosphere, contributing to global warming and driving physical climate impacts.

## BVCM: a mechanism for bridging the gap

BVCM is therefore a way for companies to help accelerate global progress towards net-zero by supporting other economic and social actors to reduce and/or remove GHG emissions both today and in the longer term. It also represents a mechanism for companies to take responsibility for their unabated emissions that are contributing to climate change as they transition their business models to a state of net-zero.

The potential to deliver climate finance and unlock additional mitigation is significant. To illustrate, if in 2022 all companies with SBTi-validated science-based targets had delivered BVCM equivalent to 100% of their unabated scope 1 and 2 emissions, this would have resulted in 422 million metric tons of CO2e of BVCM in that year. 30 This is more than 2.5x the volume of carbon credits retired in the voluntary carbon market globally in 2022, and greater than the United Kingdom's GHG emissions for 2022. 31

Given the urgency and scale of the climate crisis, the SBTi therefore encourages all companies to take immediate and consistent action to deliver BVCM.

<!-- image -->

## BVCM GOALS AND PORTFOLIO DESIGN PRINCIPLES

Based on the scientific rationale for BVCM described above, the SBTi has established two goals which companies can use to inform the design and implementation of their BVCM strategies.

The first goal places emphasis on realizing additional mitigation outcomes this decade (measured in metric tons of carbon dioxide equivalent). In alignment with Article 6.2 of the Paris Agreement, the SBTi proposes that these mitigation outcomes should be verified and generated in respect of or representing mitigation from 2021 onward. 32

The second goal is focused on driving new financial flows towards the scale-up of climate solutions and enabling activities needed to unlock systemic transformation in the longer term, towards mid-century and thereafter. This is aligned with the IPCC definition of climate mitigation finance in which the expected effect aims to reduce net greenhouse gas (GHG) emissions. Where the mitigation outcome is expected in the future or where mitigation outcomes are difficult to quantify, companies are recommended to report on the  action taken (for example the amount of monetary support provided), and where possible to conduct forward-looking (or ex-ante) assessments to estimate future impacts of implemented or potential actions.

## BVCM Goals

<!-- image -->

Deliver additional near-term mitigation outcomes to achieve the peaking of global emissions in the mid-2020s and the halving of global emissions by 2030.

<!-- image -->

Drive additional finance into the scale-up of nascent climate solutions and enabling activities to unlock the systemic transformation needed to achieve net-zero by mid-century globally.

In addition to the two BVCM Goals, the SBTi proposes a set of Principles for companies to consider when deciding on the portfolio of activities to support as they implement BVCM. These four principles are shown in the table below alongside illustrative (non-exhaustive) examples of aligned mitigation opportunities. These examples are discussed in more detail in Annex B.

## BVCM Portfolio design principles

<!-- image -->

## Scale :

Maximize mitigation outcomes

<!-- image -->

## Financing need :

Focus on underfinanced mitigation

<!-- image -->

<!-- image -->

Climate justice : Address inequality

<!-- image -->

## Principle-aligned mitigation opportunities include those that:

- Have lower abatement costs e.g., reduced conversion of natural ecosystems and energy efficiency.
- Prevent ecological and climate tipping points e.g., protecting the climate sink function of natural ecosystems and phase-out of fossil fuels.
- Avoid high-carbon technology or infrastructure lock-in e.g., renewable energy generation and distribution, green hydrogen, phase-out of fossil fuels.
- Have the potential to generate cascading positive impacts e.g., energy storage, green-hydrogen and demand-side interventions such as dietary shift.
- Provide finance at the jurisdictional or landscape level e.g., jurisdictional REDD+, jurisdictional fossil fuel phase-out, and progressive climate policy advocacy.
- Need private sector finance to support countries' delivery (and potentially enhancement) of Nationally Determined Contributions (NDCs) to the Paris Agreement.
- Are underfinanced and in need of concessional or debt-free finance due to limited return on investment (ROI), longer payback periods or higher investment risk , e.g., early phase-out of coal, forest restoration and conservation of natural ecosystems.
- Deliver co-benefits such as adaptation, resilience, livelihoods, water security, biodiversity, e.g., through the protection and restoration of coastal ecosystems and urban nature-based solutions.
- Deliver mitigation in lower income, more vulnerable countries e.g., countries with comparatively low per capita emissions and exposed to greater temperature variability.
- Support disadvantaged and marginalized groups most impacted by climate change, e.g., economically disadvantaged people, women, children, youth and elderly people, members of ethnic and religious minorities, Indigenous Peoples, people with health problems and/or disabilities, migrants and displaced people, and rural populations.
- Support and ensure the leadership and ownership efforts of Indigenous Peoples and local communities to deliver climate mitigation and adaptation through the protection and restoration of their traditional and customary lands.
- Support the just transition e.g., by facilitating the retraining of workers across sectors affected by the transition to net-zero.

## THE BUSINESS CASE FOR BVCM

<!-- image -->

## THE BUSINESS CASE FOR BVCM

Companies funding BVCM can also unlock an array of opportunities, mitigate future risks and protect and enhance long-term value. However, the business case for BVCM varies across companies depending on factors such as the region, market and industry in which the company operates, its size and market share, and ultimately the extent to which the company is impacted by the changing physical environment linked to climate change and the associated changes in policy, financial markets, consumer markets, society and technology.

In 2023, the SBTi engaged with more than 200 companies from a range of sectors through the combination of an online survey and one-to-one interviews to better understand the business case for BVCM. Consumer-facing companies highlighted BVCM as an opportunity to differentiate their brand. Companies that are highly dependent on natural capital identified BVCM as an opportunity to enhance resilience across their operations and supply chains. Companies in higher emitting sectors identified BVCM as an opportunity to scale the availability of CDR technologies needed to neutralize residual emissions in the future. Across all sectors, companies highlighted benefits linked to talent acquisition and retention and many highlighted BVCM as a core part of their social license to operate. 34

## Figure 3:  Illustrative quotes from the SBTi's engagement with companies on BVCM during 2023

<!-- image -->

<!-- image -->

'We communicate our investments to employees, investors, policymakers, and customers and we need different narratives for each.'

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

'Our BVCM investments and climate efforts are on an extremely important recruitment tool. We need to live up to the standard we are setting.'

'There is a growing expectation among investors that our actions and targets are validated by third parties and science-based.'

'The carbon credits we will have to buy in 2040 are an added cost to our business. We need a market that has adequate scale and integrity.'

'Our customers care about our sustainability goals and targets and will ask us about our progress. Sustainability is a license to operate.'

<!-- image -->

Resilience and security of supply

'We invest in landscapes adjacent to our sourcing areas to support the health of those landscapes to secure future access to commodities.'

## BVCM BENEFITS LINKED TO CHANGES IN THE PHYSICAL ENVIRONMENT

Companies face acute and chronic physical risks as a result of climate change (e.g., rising temperatures, sea-level rise, extreme weather events, resource scarcity, ecosystem degradation), as well as systemic risks linked to climate tipping points and ecosystem collapse. Climate change and La Niña drove overall losses of USD 270 billion and insured losses of USD 120 billion in 2022. 35

By funding BVCM, companies can mitigate physical climate risks and realize opportunities linked to resilience and climate adaptation. For example, activities that protect mangrove ecosystems have enormous benefits: mangrove forests provide more than USD 80 billion per year in avoided losses from coastal flooding, and efforts to protect them could deliver more than 60 million tCO2e a year of climate mitigation over the next two decades. 36,37

## BVCM BENEFITS LINKED TO CHANGES IN THE POLICY ENVIRONMENT

Companies face risks as a result of policies designed to constrain activities driving climate change, e.g., taxes and charges on polluting activities and tradable permits in cap-and-trade systems. 38  Companies also face climaterelated litigation or legal risk as a result of claims being brought before the courts. 39

BVCM activities and investments as a supplement to scope 1, 2 and 3 abatement could potentially reduce future policy or litigation risk where BVCM is aligned with the polluter pays principle set out in the 1992 Rio Declaration which signifies that those who produce pollution should bear the costs of managing it to prevent damage to human health or the environment. 40,41

Companies can also realize opportunities linked to governmental efforts to incentivize corporate action on climate, e.g., subsidies and tax incentives. 42 Tax credits can be designed to allow businesses to deduct a certain percentage of green investment costs from their taxes. The Inflation Reduction Act in the United States includes 24 tax credits - most of which relate to climate and energy policies - and is anticipated to drive USD 380 billion of investment into renewable energy and sustainable technologies. 43  Companies that responded to the SBTi's 2023 BVCM public consultation perceived tax incentives as having the biggest potential impact in driving BVCM investment. 44

Policy-related opportunities also exist for organizations to utilize their BVCM funding activities to collaborate with governments to access new markets through financing BVCM through public-private partnerships and blended finance instruments.

## BVCM BENEFITS LINKED TO CHANGES IN FINANCIAL MARKETS

Concern about climate change has been cited as the most common reason for financial groups to exclude companies from their portfolios, according to research from a coalition of non-profit environmental and sustainability groups. 45 Correspondingly, many investors see purpose-led brands as a key to future-proofing their portfolio, recognizing sustainability as an opportunity for growth. 46 BVCM thus presents an opportunity to retain and attract investors.

Moreover, companies can realize opportunities linked to new sustainability-linked financial mechanisms by underwriting or financing green bonds and infrastructure (e.g., low-emission energy production, energy efficiency, grid connectivity, or transport networks).

## BVCM BENEFITS LINKED TO MARKET CHANGES

Companies face market risks due to shifts in supply and demand for products and services as a result of climate change. They can also realize opportunities to increase market share through brand differentiation linked to climate leadership. Recent analysis showed that 14% of consumers cite ESG as their top buying criteria and more than 70% of consumers are willing to pay a reasonable premium (10-25%) for sustainability. 47 Numerous surveys have shown that corporate donations attract customers: Mintel, for example, found that charitable giving affects nearly three-quarters (73%) of Americans' spending decisions. Half of the consumers surveyed said they would switch to a company that supports a cause they believe in, including 61% of adults aged 41 or younger. 48 BVCM therefore represents an opportunity for companies to differentiate themselves from their peers and appeal to socially and environmentally minded consumers.

## BVCM BENEFITS LINKED TO CHANGES IN SOCIETY'S EXPECTATION OF COMPANIES

The social license to operate refers to the ongoing acceptance of a company or industry's business practices and operating procedures by its employees, stakeholders, and the general public. Companies can erode the social license by failing to take externalities into account even if they have already committed to reducing their value chain emissions in the short and long term, and as a result their core strategies may not be achievable. 49 Demonstrating a commitment to addressing the climate crisis through BVCM can help businesses avoid costs linked to loss of the social license to operate - for example, replacing an employee costs, on average, 21% of their annual pay. 50   It can also be an important factor in job selection, with more than 40% of millennials reporting that they seek jobs with a purpose. 51

## BVCM BENEFITS LINKED TO CHANGES IN TECHNOLOGY

BVCM is a mechanism by which companies can deploy funds beyond their sector and their value chains to realize opportunities linked to technology R&amp;D and innovation. As such, BVCM activities that accelerate technological innovation brings opportunities to access new markets and for associated return on investment. The global climate tech market is expected to reach USD 182.5 billion at a compound annual growth rate of 24.5% during forecast period 2023 to 2033. 52

BVCM also represents an opportunity to accelerate the development of CDR technologies needed to neutralize the impact of residual emissions by mid-century and thus to mitigate future costs and secure access to permanent removals.

## Table 3: Illustrative examples of companies realizing benefits from BVCM activities and investments

| SOURCES OF CLIMATE- RELATED RISKS AND OPPORTUNITIES   | ILLUSTRATIVE EXAMPLES OF COMPANIES REALIZING BENEFITS FROM BVCM ACTIVITIES ANDINVESTMENTS                                                                                                                                                              |
|-------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Changes in the physical environment                   | A manufacturing company funds the restoration of coastal ecosystems adjacent to its production facilities to mitigate the risk of cost increases or loss of revenue linked to storm surges damaging production facilities.                             |
| Changes in the policy landscape                       | A media company invests into a blended finance mechanism that finances nature-based solutions in sub-Saharan Africa whereby development finance is leveraged to attract and de-risk private sector investments into developing and emerging economies. |
| Changes in financial markets                          | A fashion company funds the protection of the Amazon rainforest to signal that it is a purpose-led brand and to attract investors focused on purposeful businesses.                                                                                    |

| SOURCES OF CLIMATE- RELATED RISKS AND OPPORTUNITIES   | ILLUSTRATIVE EXAMPLES OF COMPANIES REALIZING BENEFITS FROM BVCM ACTIVITIES ANDINVESTMENTS                                                                                                                                                                                                                  |
|-------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Changes in markets                                    | A telecommunications company funds solar mini grids to differentiate itself from peers and to unlock opportunities for price premiums linked to climate leadership.                                                                                                                                        |
| Changes in society's expectation of companies         | A high profit technology company funds a portfolio of BVCM activities to demonstrate to civil society and regulators that its privileged economic position is balanced by tangible social responsibility.                                                                                                  |
| Changes in technology                                 | An aviation company funds BVCM by purchasing direct air carbon capture and storage (DACCS) carbon credits to help scale the availability of this technology to ensure that permanent carbon removals are available and affordable when the company has committed to neutralize residual emissions in 2050. |

<!-- image -->

## RECOMMENDATIONS FOR DESIGNING AND IMPLEMENTING A BVCM STRATEGY

<!-- image -->

## RECOMMENDATIONS FOR DESIGNING AND IMPLEMENTING A BVCM STRATEGY

The diagram below shows the high-level steps that a company could take in designing and implementing a BVCM strategy. The SBTi recommends that companies periodically review their BVCM pledges and strategies - in this sense, the four steps below are cyclical in nature.

Figure 5: Four high-level steps for designing and implementing high-integrity and highimpact BVCM strategies

<!-- image -->

## STEP 1: SET AND WORK TO DELIVER A NET-ZERO TARGET

- 1.1: Develop and disclose a full GHG emissions inventory
- 1.2: Set, submit, validate and disclose a science-based net-zero target
- 1.3: Develop, disclose and work towards a net-zero aligned climate transition plan

## STEP 2: ESTABLISH A BVCM PLEDGE

- 2.1: Determine the business case and strategic objectives for BVCM
- 2.2: Define the time period of the BVCM pledge
- 2.3: Define the scale of the BVCM pledge

## STEP 3: TAKE ACTION TO DELIVER BVCM

- 3.1: Define quality standards and guardrails for BVCM activities and investments
- 3.2: Deploy resources and finance towards a portfolio of BVCM activities

## STEP 4: REPORT BVCM ACTIVITIES AND OUTCOMES

- 4.1: Establish a BVCM measurement, reporting and verification (MRV) framework
- 4.2: Report annually on BVCM activities, investments and outcomes
- 4.3: Make transparent and accurate BVCM claims

<!-- image -->

<!-- image -->

## SET AND WORK TO DELIVER A NET-ZERO TARGET

The first step in designing and implementing a BVCM strategy is to set and disclose a validated net-zero climate target in line with the SBTi's Corporate NetZero Standard and to develop an associated climate transition plan. This comprises the following sub-steps:

Develop a full GHG emissions inventory 1.1

Set, submit, validate and disclose a science-based net-zero target 1.2

Develop, disclose and work towards a net-zero aligned climate transition plan 1.3

## 1.1: Develop a full GHG emissions inventory

Under the Corporate Net-Zero Standard, companies are required to have a comprehensive emissions inventory that covers at least 95% of company-wide scope 1 and 2 GHG emissions and includes a complete scope 3 inventory. The Corporate Net-Zero Standard highlights the necessary steps for aligning with the GHG Protocol and SBTi Criteria.

Companies should make their GHG emissions inventory publicly available on the company's website and update it annually. It is also recommended that companies disclose their inventory annually through CDP and have their GHG inventory verified by an independent third party.

For companies intending to make VCMI Carbon Integrity Silver, Gold or Platinum claims (based on the VCMI November 2023 publication) related to their BVCM performance, this first step is aligned with the VCMI Foundational Criterion 1 to maintain and publicly disclose an annual GHG emissions inventory.

Useful resources for implementing step 1.1 include the following Greenhouse Gas Protocol documents:

- The Corporate Accounting and Reporting Standard which provides requirements and guidance for organizations preparing corporate level GHG inventories.
- The Scope 2 Guidance which provides further guidance on measuring and reporting GHG inventory for emissions arising from purchased or acquired electricity, steam, heat and cooling.
- The Corporate Value Chain (Scope 3) Standard and supporting Scope 3 Calculation Guidance which provide a standardized framework for corporate value chain emissions accounting and reporting.
- The draft Land Sector and Removal Guidance which explains how companies should account for and report GHG emissions and removals from land management, land use change, biogenic products, carbon dioxide removal technologies, and related activities.

## 1.2: Set, submit, validate and disclose a science-based net-zero target

Companies should follow the Corporate Net-Zero Standard to set and submit net-zero targets for validation to the SBTi. Once targets are validated by the SBTi, companies are encouraged to disclose their net-zero targets publicly and through CDP.

To ensure consistent tracking of performance over time, the target should be recalculated, as needed, to reflect significant changes that would compromise its relevance and consistency. The SBTi recommends that companies check the validity of their target projections annually. At a minimum, targets must be reassessed every five years.

For companies intending to make VCMI Carbon Integrity Silver, Gold or Platinum claims (based on the VCMI November 2023 publication) related to their BVCM performance, this step links to the VCMI Foundational Criterion 2 to set and publicly disclose validated science-based near-term emissions reduction targets, and publicly commit to reaching net-zero emissions no later than 2050.

Useful resources for implementing step 1.2 include the following SBTi documents:

- The Corporate Net-Zero Standard which provides guidance, recommendations and requirements to support companies in setting net-zero targets through the SBTi. Chapter 7 of the Corporate Net-Zero Standard sets out the criteria that net-zero targets must meet to be approved as science-based by the SBTi.
- The Getting Started Guide, a simple step-by-step guide to help companies understand how to set a sciencebased target in their specific situation.
- The SBTi target-setting tool, a tool to calculate near-term science-based targets in line with the SBTi ambition requirements.
- The SBTi Net-Zero tool, a target-setting tool to calculate long-term science-based targets in line with SBTi ambition requirements.

## 1.3: Develop, disclose and work towards a net-zero aligned climate transition plan

Companies should develop and disclose a climate transition plan - a time-bound action plan that clearly outlines how the organization will pivot its existing assets, operations, and entire business model towards the delivery of its net-zero target. Climate transition plans are a vital tool to demonstrate to capital markets and stakeholders that an organization is committed to achieving a 1.5°C pathway, and that its business model will remain relevant (i.e., profitable) in a net-zero carbon economy. 53

In line with the recommendations of the Transition Plan Taskforce (TPT), companies should report material information about their transition plan within their financial reports, including annual reporting on progress against quantified and timebound metrics and targets and information about any direct and indirect engagement activities with the government, regulators, public sector organizations, communities, and civil society that it is undertaking or plans as part of its transition plan. 54

For companies intending to make VCMI Carbon Integrity Silver, Gold or Platinum claims (based on the VCMI November 2023 publication) related to their BVCM pledges and performance, this step links to the VCMI Foundational Criterion 3 to demonstrate that the company is on track towards meeting a near-term emissions reduction target and minimizing cumulative emissions over the target period, and the VCMI Foundational Criterion 4 to demonstrate that the company's public policy advocacy supports the goals of the Paris Agreement and does not represent a barrier to ambitious climate regulation.

Useful resources for implementing step 1.3 include:

- The Transition Plan Taskforce (TPT) Disclosure Framework which provides guidance for robust and credible transition plan disclosures.
- CDP's technical note which provides guidance on how organizations disclosing through CDP can demonstrate that they have a credible climate transition plan in place.

<!-- image -->

<!-- image -->

## ESTABLISH A BVCM PLEDGE

## The second step is to establish a BVCM pledge which comprises the sub-steps below:

- 2.1 Determine the business case and strategic objectives for BVCM
- 2.2

Define the time period of the BVCM pledge

- 2.3

Define the scale of the BVCM pledge

## 2.1: Determine the business case and strategic objectives for BVCM

The existential case for beyond value chain mitigation is clear - climate change is one of the most significant risks that companies face today. 55  However, developing a robust business case for BVCM is a crucial step to create internal buy-in and secure the necessary human and financial resources. The business case for BVCM will differ from one company to the next depending on factors including the region, market and industry in which it operates.

In developing a business case, companies should consider how BVCM can unlock opportunities, minimize future risks and protect and enhance the company's long-term value. There are a wide range of financial and non-financial drivers for BVCM that a company should look to identify.

Financial drivers include the opportunity to attract and retain investment, resilience across the value chain, profit growth, new market opportunities and government incentives. Non-financial drivers include enhanced brand reputation and differentiation, competitive advantage, customer demand, risk mitigation, license to operate, employee attraction, wellbeing, and retention and community and society wellbeing.

For example, a food and agricultural company might identify supply chain resilience opportunities from restoration of landscapes ecologically linked to its supply chain. A consumer facing company might identify opportunities for green premium or brand loyalty linked to BVCM activities. A company in a heavy emitting sector might consider funding the scale-up of CDR technology as a long-term risk management strategy to secure access to removals needed for neutralizing its residual emissions at the net-zero target date and thereafter.

In establishing the business case, companies should also define their strategic objectives for BVCM. For example, if a company is looking to enhance its brand value through BVCM, the company will most likely want to make a consumerfacing claim which will influence the nature and scale of their BVCM pledge.

These strategic objectives should be integrated into and disclosed within the company's climate transition plan to facilitate a holistic and strategic approach to climate action both within and beyond the value chain.

Useful resources for implementing step 2.1 include:

- The Climate Financial Risk Forum's Risk Management Chapter which outlines approaches to managing the risks associated with climate change.
- Guidance from the World Business Council for Sustainable Development (WBCSD) and the Committee of Sponsoring Organizations of the Treadway Commission on Applying Enterprise Risk Management to Environmental, Social and Governance-related Risks.
- The Task Force on Climate-related Financial Disclosures's (TCFD's) Guidance on Risk Management Integration and Disclosure which helps address some of the issues companies may face in implementing the TCFD Risk Management recommendation.
- The Taskforce on Nature-related Financial Disclosure's (TNFD's) Nature-related Risk and Opportunity Management and Disclosure Framework which provides guidance on risk assessments for use by both corporates and financial institutions in the context of applying the TNFD framework.

<!-- image -->

## 2.2: Define the time period of the BVCM pledge

The SBTi recommends that companies make a forward-looking commitment to a given amount of BVCM each year over a period of five years or longer (see the SBTi Criteria and Recommendations). A company might also choose to align the BVCM pledge cycle with its five-year mandatory science-based target recalculation exercise to improve the efficiency of internal climate management processes.

It is also important for companies to periodically review their BVCM pledges and strategies to ensure that they are deploying resources and finance towards activities that support the business's strategic objectives and which deliver the greatest impact for climate and nature. This is because the mitigation activities that are most urgently in need of finance and the business-specific risks and opportunities are likely to shift over time. For example, demonstrating climate leadership and taking responsibility for unabated emissions through BVCM is likely to become an increasingly important factor in a company's social license to operate and therefore a company might decide to ratchet its ambition over time.

## 2.3: Define the scale of the BVCM pledge

The SBTi acknowledges the varying 'ability to pay' for BVCM across sectors (based on differing profitability margins). The SBTi therefore welcomes all efforts by companies to go above and beyond their value chain emissions reductions targets through BVCM based on their business case and the ability to secure internal buy-in and financial resources.

If a company's objective for implementing BVCM is to make claims, the SBTi also recognizes that the size of their pledge would likely be determined on the specific requirements of the BVCM certification standard or claims code that they decide to follow (e.g. VCMI Claims Code of Practice Carbon Integrity Silver, Gold or Platinum claims tiers specify the amount of carbon credits that need to be purchased and retired in order to make a given claim).

The SBTi considers that best practice is aligned with the polluter pays principle iii and thus entails taking full responsibility for unabated emissions, whereby a company would:

<!-- image -->

Apply a science-based carbon price to unabated scope 1, 2 and 3 emissions iv each year or over a defined commitment period to determine a financial budget. Annex E provides further information on science-based carbon pricing.

<!-- image -->

- Use this budget to fund a combination of near-term BVCM outcomes (aligned with BVCM Goal 1) and long-term BVCM finance (aligned with BVCM Goal 2), as well as wider categories of climate action (see Annex C for further information on these wider categories of climate action). 2
- As a guide, given the critical urgency of mitigation this decade, the SBTi recommends that companies use a portion of the budget each year to deliver ex-post, quantified mitigation outcomes-generated in respect of or representing mitigation from 2021 onward and measured in tCO2e-equivalent to at least 50% of the company's remaining scope 1, 2 and 3 emissions. v  It is recommended that these emissions reductions and removals are verified by third parties using standardized methodologies and that they adhere to high-quality criteria.
- iii The polluter pays principle set out in the 1992 Rio Declaration signifies that those who produce pollution should bear the costs of managing it to prevent damage to human health or the environment.
- iv Application of the carbon price to historic emissions would also be considered best practice for some sectors, but there is acknowledgement that this would be highly challenging for many companies given the magnitude of lifetime emissions.
- v  There is a lack of scientific literature to draw from to inform how a company should split such a budget between mitigation, adaptation, addressing loss and damage and wider activities that foster an enabling environment. The recommendation to fund ex-post mitigation outcomes equivalent to 50% of unabated emissions is thus a rough guide as opposed to a science-based recommendation.

When applying a carbon price companies should report on the source of this price and a justification for the price chosen.

It is important to note that the SBTi acknowledges that this vision of best practice would involve significant costs for some companies and is therefore unlikely to be widely adopted at this point in time.

Beyond this best practice recommendation, there are other methods by which companies can determine the scale of the contribution to BVCM. These methods are explored in Annex D of this document.

Useful resources for implementing step 2.3 include:

- Annex C of this document (Wider Categories of Climate Action).
- Annex D of this document (Methods for Determining the Nature and Scale of a BVCM Pledge).
- Annex E of this document (Carbon Pricing).
- WWF's Corporate Climate Mitigation Blueprint is a tool configured for companies to craft an action plan for maximizing their climate impact. Section 3 provides guidance on quantifying a financial commitment by pricing remaining emissions.
- WWF's Fit for Paris report on how companies should finance additional climate action includes guidance on quantifying additional investments.
- CDP's Carbon Pricing: Disclosure Best Practice includes information on types of internal carbon pricing mechanisms and common price determination methods.
- Carbon Pricing Unlocked's How-to Guide to Corporate Internal Carbon Pricing provides guidance on emerging best practice for designing and implementing an internal carbon pricing approach.
- Carbon Pricing Unlocked's briefing paper on Internal Carbon Pricing for low-carbon finance provides

guidance on linking climate-related opportunities and risks to financing

decisions for investors and banks.

- Report of the High-Level Commission on Carbon Prices provide recommendations on carbon pricing.
- The VCMI Claims Code of Practice provides companies with a rulebook on credible use of high-quality carbon credits and associated climate claims.

<!-- image -->

<!-- image -->

## TAKE ACTION TO DELIVER BVCM

The second step is to establish a BVCM pledge which comprises the sub-steps below:

- 3.1

Define quality standards and guardrails for BVCM activities and investments

- 3.2 Design a portfolio of BVCM activities and investments

## 3.1: Define quality standards and guardrails for BVCM

The SBTi's first BVCM Goal places emphasis on realizing additional mitigation outcomes this decade (measured in metric tons of carbon dioxide equivalent). In alignment with Article 6.2 of the Paris Agreement, the SBTi proposes that these mitigation outcomes are verified and generated in respect of or representing mitigation from 2021 onward. 56  It is also recommended that companies establish minimum quality standards to ensure additionality, permanence and avoidance of leakage and double counting where relevant.

The second BVCM Goal is focused on driving new financial flows towards the scale-up of climate solutions and enabling activities needed to unlock systemic transformation in the longer-term, towards mid-century and thereafter. This is aligned with the IPCC definition of climate mitigation finance in which the expected effect aims to reduce net greenhouse gas (GHG) emissions. 57  It is recommended that companies define minimum quality standards where finance is deployed towards this goal.

Companies should also commit to and disclose safeguarding principles to ensure that their BVCM activities do not have an adverse impact on:

- Human rights
- Conservation of biological diversity
- Core labor rights
- Access and equity
- Marginalized and vulnerable groups
- Gender equity
- Women's empowerment
- Indigenous peoples
- Involuntary resettlement
- Protection of natural habitats
- Climate change
- Pollution prevention
- Resource efficiency
- Public health
- Physical and cultural heritage
- Lands and soil conversion

<!-- image -->

A number of tools can be used to ensure these safeguarding principles are observed including:

- risk categorization,
- environmental and social impact assessments,
- management or action plans, stakeholder consultations,
- grievance and redress mechanisms,
- monitoring and verification,
- transparency requirements, and;
- project exclusion lists. 58

<!-- image -->

Useful resources for step 3.1 include:

- Carbon Credit Quality Initiative (CCQI) provides transparent information on the quality of carbon credits.
- The Tropical Forest Credit Integrity (TFCI) Guide was developed for companies interested in purchasing carbon credits in the voluntary carbon markets and to assist individuals and teams responsible for developing and implementing corporate climate mitigation net-zero strategies.
- The Climate, Community and Biodiversity Standards (CCB Standards) evaluates land management projects from the early stages of development through to implementation.
- The Sustainable Development Verified Impact Standard (SD VISta) is a standard for certifying the benefits of social and environmental projects.
- Gold Standard for the Global Goals is a standard that provides tools and guidance to accelerate global progress toward climate security and sustainable development. It provides tools and guidance. Certification provides the confidence that results are measured and verified and translate to real impact in social value.
- The Cancun Safeguards - also known as the REDD+ safeguards - aim to ensure that REDD+ initiatives adequately address sensitive issues such as the rights of Indigenous Peoples and traditional communities, social participation, preservation of natural ecosystems, the permanence of achieved REDD+ results and the risk of displacement pressure from deforestation and forest degradation to other areas. These safeguards were developed for countries but are also a useful reference for companies.
- The Integrity Council for the Voluntary Carbon Market (ICVCM) defines ten Core Carbon Principles and an Assessment Framework for evaluating whether carbon credits and carbon-crediting programs reach the ICVCM's threshold for quality and integrity.
- 'Positive Results, no Negative Consequences: No-harm options for Article 6' is a paper which defines safeguard principles and tools for mitigation activities under the Paris Agreement's Article 6.
- The European Securities and Markets Authority's paper on the 'Do No Significant Harm' definitions and criteria across the EU Sustainable Finance framework.

## 3.2: Design a portfolio of BVCM activities and investments

The business objectives for BVCM defined in step 2.1 will to some extent inform the company's strategy for directing finance and resources towards different mitigation activities. For example, a company might choose to fund the restoration of coastal ecosystems adjacent to its production facilities to mitigate the risk of cost increases or loss of revenue linked to climate change induced storm surges damaging said facilities. Food and agricultural companies might choose to fund nature protection and restoration in the value-chain adjacent landscapes to build resilience and security of supply. Different types of instruments can be used to fund different activities.

However, given the need for global emissions to peak by 2025 and the speed at which new climate technologies need to be scaled, the SBTi recommends that companies consider the BVCM Goals and Principles defined in this document when designing a portfolio of BVCM activities and investments. Please refer to Annex B of this document for more detail.

There is also a need for the private sector to contribute towards wider categories of climate action including adaptation and addressing loss and damage. Annex C contains additional information on these pillars of climate action.

Companies should publicly disclose how the company's BVCM activities and investments are aligned with the SBTi's BVCM Goals and Principles.

Useful resources for implementing step 3.2 include:

- The IPCC Working Group III Sixth Assessment Report (2022), notably Figure SPM.2 which provides regional GHG emissions per capita, Figure SPM.7 which provides an overview of mitigation options and their estimated ranges of costs and potentials in 2030, and Figure SPM.8 which shows synergies and trade-offs between sectoral and system mitigation options and the SDGs.
- The 2023 Climate Inequality Report is a useful resource for Principle 4 on climate justice, notably Figure 10 which shows the predicted change in temperature variability until the end of the century across countries versus emissions per capita between 1990 and 2013.
- The Independent High-Level Expert Group on Climate Finance's 2022 report on Finance for climate action: Scaling up investment for climate and development is a useful resource for Principle 2 on financing need, notably Figure 5.1 shows financing sources for investment and spending priorities for climate action and related development goals.
- The Systems Change Lab monitors, learns from and mobilizes action toward the transformational shifts needed to protect both people and the planet. In particular, its finance dashboard is a useful resource for companies looking to identify where private sector finance is most needed, and its 2023 State of Climate Action report which highlights where action must urgently accelerate this decade to reduce greenhouse gas emissions, scale-up carbon removal and increase climate finance.
- The Climate Policy Initiative's Global Landscape of Climate Finance (2023) which provides an overview of climate mitigation and adaptation finance and highlights gaps that can be useful for companies in choosing how to direct their finance.

<!-- image -->

## REPORT BVCM ACTIVITIES AND OUTCOMES

## The fourth step is to report BVCM activities and outcomes:

- 4.1 Establish a BVCM measurement, reporting and verification (MRV) framework
- 4.2 Report annually on BVCM activities, investments, and outcomes
- 4.3 Make transparent and accurate BVCM claims

## 4.1: Establish a BVCM measurement, reporting and verification (MRV) framework

Companies will need to develop a BVCM MRV framework to measure, report and verify the mitigation outcomes as a result of BVCM funding over a period of time.

The SBTi recommends that mitigation outcomes are verified by an independent third-party reviewer that assesses the accuracy and completeness of an emissions reduction or removal intervention. The third-party reviewer should be independent of the organizations that have gathered and/or provided the data and those that will use the data. Third-party verification provides an independent assessment of the systems and processes used to monitor and report, and independent verifiers can bring objective opinions and recommendations to the data collection, management, and reporting processes.

Wherever possible companies should rely on existing standards and reporting frameworks to qualify and assure BVCM activities and investments.

The corresponding design of the MRV framework will depend on the mix of mitigation activities and investments chosen in step 3.2. For example, where carbon credits are the mechanism by which companies intend to channel finance, companies should have their credits verified by an independent third party according to the protocols of a high-quality carbon standard. Companies can also use carbon market ratings agencies to provide additional checks and/or the Carbon Credit Quality Initiative (CCQI) tool which provides transparent information on the quality of carbon credits. Standards such as Climate, Community and Biodiversity Standards (CCB Standards), the Sustainable Development Verified Impact Standard (SD VISta) and Gold Standard for the Global Goals (GS4GG) offer the certification of SDG benefits.

<!-- image -->

Public and multilateral standards and reporting initiatives can also provide criteria for BVCM assurance. For example, climate standards and labels or sustainable reporting rules often require external audits or certifications. In the absence of existing standards, companies would have to develop and disclose BVCM-specific indicators and metrics that can be independently assured. Where no specific certification rules exist, external assurance can also be conducted by an approved auditor following internationally accepted assurance standards, such as ISAE 3000 (revised) and ISO 14064-3 or an equivalent national standard. The use of internationally established auditing procedures helps to improve quality in the provision of assurance services. Successful certification and validation processes end with a third-party report confirming a statement of 'limited' or 'reasonable' assurance. Such a report should be published.

It is acknowledged that certain actions or investments made by a company in alignment with the SBTi's second BVCM Goal could result in mitigation outcomes that are very difficult to quantify. For example, support for activities related to capacity building, behavior change, or policy advocacy can directly or indirectly deliver mitigation outcomes, but quantifying, attributing and accounting for the mitigation impact associated with a company's action or investment is challenging. Despite this, the funding of these activities is critical to ensure that there is an effective enabling environment in which mitigation can occur. In these circumstances, companies are recommended to report on the action taken (for example the amount of monetary support provided), and where possible to conduct forward-looking (or ex-ante) assessments to estimate future impacts of implemented or potential actions.

Useful resources for implementing step 4.1 include:

- GHG Protocol's Protocol for Project Accounting provides specific principles, concepts, and methods for quantifying and reporting GHG reductions from climate mitigation projects.
- Gold Standard for the Global Goals sets the standard for climate and development to quantify, certify and maximize their impact.
- Verra's Verified Carbon Standard Program is the world's most widely used greenhouse gas crediting program.
- The REDD+ Environmental Excellence Standard, Version 2.0 sets out ART requirements for the quantification, monitoring, and reporting of GHG emissions and removals; demonstration of implementation of the Cancun Safeguards; and verification, registration, and issuance of TREES credits.
- The Verified Carbon Standard Jurisdictional and Nested REDD+ (JNR) Framework provides an accounting and verification framework for jurisdictional REDD+ programs and nested projects.
- The Sustainable Development Verified Impact Standard (SD VISta) is a standard for certifying the benefits of social and environmental projects.
- Breakthrough Energy's Emerging Climate Technology Framework defines a technology-agnostic methodology to quantify the expected impact of early-stage investments made in emerging climate technologies.
- The Gold Standard Fund Requirements Registry is a publicly available repository of all Funds and Portfolios applying the Gold Standard Fund Requirements. This ensures that all Funds, Portfolios and their impacts are visible in the public domain throughout every stage of the Gold Standard assurance cycle.
- VCMI Monitoring Reporting and Assurance (MRA) Framework outlines the requirements and standards that bring integrity and rigor to the VCMI Claims Code, ensuring that for each VCMI Claim issued, underlying information is appropriately evaluated, evidenced, and verified.
- ISAE 3000 (revised) applies to any assurance engagement other than an audit or review of historical financial information, including different forms of reporting of non-financial information.
- ISO 14064-3:2019 applies to organization, project and product GHG statements.

## 4.2: Report annually on BVCM activities, investments, and outcomes

The Corporate Net-Zero Standard states that companies should report annually on the nature and scale of BVCM. When companies submit net-zero targets to the SBTi for validation, companies are also requested to provide information on any BVCM measures and whether they will report them separately from the scope 1, 2 and 3 inventory.

Reporting and transparency around BVCM activities and outcomes is essential, as different companies will likely take different approaches in terms of the scale of the BVCM funding, and the outcomes achieved. As such, the SBTi recommends that companies report transparently on the finance deployed towards BVCM, as well as the mitigation outcomes and co-benefits delivered on an annual basis (in line with the company's GHG inventory reporting period). Emissions reductions and removals should be reported separately.

Where companies use a carbon price to determine the size of their BVCM pledge, companies should report the chosen carbon price, the methodology or source that informs it and a justification for the price chosen.

For companies that have not been able to align with the best practice recommendation described in step 2.3, it is recommended that they report on the GHG externality linked to their unabated emissions. This means applying a science-based carbon price to unabated scope 1, 2 and 3 emissions and then reporting the total cost of emissions minus the finance deployed towards BVCM and wider categories of climate action (adaptation and loss and damage). See Annex E for more information on carbon pricing.

In addition, there are a number of reporting and disclosure recommendations across the other steps, summarized below:

<!-- image -->

- 1.1 Publicly report the GHG inventory and verification statement annually in the company financial statement, the company website and through the CDP questionnaire.
- 1.2 Disclose details of the company's validated net-zero target as well as progress towards the target on an annual basis in line with the Corporate Net-Zero Standard.
- 1.3 Develop, disclose, and annually update a net-zero aligned climate transition plan in line with the recommendations of the Transition Plan Taskforce (TPT), including reporting on progress.
- 2.1 Integrate the strategic objectives for BVCM into the company's climate transition plan and associated disclosures.
- 2.2 Publicly report on the forward-looking BVCM pledge over the defined period.
- 2.3 Report the scale of the BVCM pledge and where carbon prices are used to determine the scale of the pledge, report on the source of this price and a justification for the price chosen.
- 3.1 Establish, commit to, and disclose safeguard principles to ensure that BVCM activities do not have an adverse social or environmental impact.
- 3.2 Publicly disclose how the company's BVCM activities and investments are aligned with the SBTi's BVCM Goals and Principles.
- 4.1 Publicly disclose annual verification certificates or statements of BVCM outcomes.
- 4.3 Transparently and accurately communicate a company's BVCM engagement, by backing headline claims with a strong narrative and clear reporting justifying the scale of the BVCM pledge, describing the portfolio of associated activities and investments, as well as the guardrails for BVCM activities and investments.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

It is considered best practice for companies to report on their BVCM activities and investment through the annual CDP questionnaire, within their financial statements and in their annual sustainability reports and/or websites.

Useful resources for implementing step 4.2 include:

- Carbon Market Watch's "Checklist and template for effective beyond value chain mitigation action" provides a useful set of questions to guide companies in transparently reporting their approach to BVCM. It serves as a complement to existing sustainability disclosure frameworks and provides transparency and comparability across companies' strategies.
- CDP Climate Change questionnaire for companies.
- VCMI Monitoring Reporting and Assurance (MRA) Framework outlines the requirements and standards that bring integrity and rigor to the VCMI Claims Code, ensuring that for each VCMI Claim issued, underlying information is appropriately evaluated, evidenced, and verified.
- The State of California's AB 1305 (Voluntary Carbon Market Disclosures Act) mandates disclosures of how a company achieves net-zero, carbon neutral, and other significant emission reduction claims.
- Recommendations of the Task Force on Climate-related Financial Disclosures (TCFD) include climate-related financial disclosures that are designed to solicit decision-useful, forward-looking information that can be included in mainstream financial filings.
- Transition Plan Taskforce (TPT) 'gold standard' Disclosure Framework sets out good practice for robust and credible transition plan disclosures as part of annual reporting on forward business strategy.
- TCFD Recommendations and Guidance - TPT Disclosure Framework: Technical mapping which sets out the main provisions of the TCFD Recommendations and Guidance relevant to transition planning and identifies the relevant TPT Disclosure Recommendations.
- International Financial Reporting Standards (IFRS) S2 Climate-related Disclosures - TPT Disclosure Framework: Technical mapping which sets out the main provisions in IFRS S2 that contain disclosure requirements relevant to transition planning and identifies the relevant TPT Disclosure Recommendations.
- TPT Disclosure Framework European Sustainability Reporting Standards: Comparison which identifies for each TPT Recommendation - relevant provisions of European Sustainability Reporting Standards (ESRS) 2 General Disclosures and ESRS E1 Climate Change that require disclosure of related information.

<!-- image -->

## 4.3: Make transparent and accurate BVCM claims

Climate claims are a key part of the business case for BVCM, since they allow companies to differentiate themselves in the eyes of consumers, investors, and other stakeholders based on their climate actions. The International Social and Environmental Accreditation and Labelling (ISEAL) Alliance defines a claim as a message used to describe or promote a product, process, business, or service with respect to its sustainability attributes or credentials. 59 Claims can be presented in sustainability reports, press releases, labels, advertising, or other marketing material, which may or may not be consumer facing. Headline climate claims are short, marketingfocused claims used to convey climate-related achievements and they should be supported by narrative claims which are typically longer descriptive claims made to convey more detailed progress or status-based achievements, for example, describing actions undertaken or planned and sharing data about achievements made. 60

At present there is a diversity of claims when companies finance mitigation beyond their value chain through different mechanisms, reflecting among others the differing business cases and objectives for BVCM as well as the diversity in underlying BVCM activities and investments. BVCM claims can be distinguished in terms of whether they relate to the volume of mitigation delivered or the finance deployed towards BVCM.

Historically, companies have linked BVCM to their own emissions implying some level of counterbalancing or netting out of the company's unabated emissions. For example, climate compensation claims are those which convey to audiences that avoiding, reducing or removing GHG emissions beyond the value chain of a company counterbalances or 'nets out' emissions released within the operations or value chain of a company. An example of a compensation claim is the carbon neutrality claim. Compensatory claims are increasingly the subject of public scrutiny and regulation in different jurisdictions.

On the other hand, climate contribution claims are those which convey to audiences that the organization has provided support or finance to actions beyond the company's value chain (including through collective action) with an expected climate mitigation outcome (where the actions are relevant to the expected performance outcome). Unlike compensation claims, the contribution claim does not imply that the BVCM outcomes are netting out or counterbalancing the claimants' remaining value chain emissions, but instead are communicated as a contribution to global climate mitigation efforts or even the efforts of a country.

The SBTi does not have plans to validate BVCM claims. However, SBTi recommends that companies carefully construct their BVCM claims as part of their BVCM strategy. BVCM claims overall should meet general requirements of high-integrity and high-ambition environmental claims. As far as possible, companies should ensure that their BVCM claims are externally audited or certified, increasing their credibility over self-declared environmental messages.

## Regulatory considerations of BVCM claims

It is important to note that there are increasing examples of public efforts to regulate corporate climate claims through both law and softer regulatory instruments such as guidance from consumer, competition and financial authorities. Companies are recommended to ensure that claims comply with environmental claims regulations in relevant jurisdictions. Prominent examples of new or emerging claims regulation and guidance include:

- The European Parliament and the Council of the EU struck a deal to ban advertisements that make 'claims based on emissions offsetting schemes that a product has neutral, reduced or positive impact on the environment' by 2026. 61  This latest decision concludes negotiations on the Empowering Consumers for the Green Transition (ECGT) directive, which the European Commission published in March 2023, with the intention of updating existing EU consumer protection legislation that was no longer fit for purpose. 62
- France's Decree No. 2022-539, which aims to prevent greenwashing by specifying rules for carbon offsetting and carbon neutrality claims, came into force in January 2023. It requires companies to report annually on their products' life cycle emissions as well as those emissions that are offset. 63
- The US State of California's bill AB-1305 on voluntary carbon market disclosures puts in place disclosure requirements for entities that purchase or use voluntary carbon credits and that make claims regarding the achievement of net-zero emissions, claims that the entity, related entity, or a product is 'carbon neutral,' or makes other claims implying the entity, related entity, or a product does not add net carbon dioxide or greenhouse gases to the climate or has made significant reductions to its carbon dioxide or greenhouse gas emissions. 64
- In December 2022, the US Federal Trade Commission consulted on potential updates to its Green Guides for the Use of Environmental Marketing Claims. In doing so, it requested public comment on four specific issues, of which carbon offsetting was one, explicitly inviting 'comments on whether the revised Guides should provide additional information on related claims and issues.' 65

<!-- image -->

## Example of BVCM Claims Guidance

The VCMI defines Principles for Climate Mitigation Claims Credibility, whereby claims should:

- Be clear to the target audience(s) : Claims should be clearly stated, enabling target audiences to interpret them accurately and objectively. The message should be objective and traceable. The claimant should make best efforts to ensure that the claim cannot be misinterpreted, notwithstanding the fact that it cannot ultimately control how a claim is interpreted by a third party.
- Be transparent : The underlying information and evidence that substantiates a claim should be transparent, and all assumptions, data and relevant information should be transparently disclosed.
- Be traceable : All data underlying a claim should be traceable (e.g., in the case where carbon credits are purchased and retired to make BVCM claims, they should be able to be traced back to their point of issuance).
- Be true and verifiable : A claim should be truthful and substantiated by evidence that can be verified.
- Be accurate : Generalizations should be avoided when accuracy is possible.
- Be conservative : If there is uncertainty in a claim's substantiating data, conservative estimates should be applied.
- Be relevant and not misleading : A claim should not seek to distract key audiences from a company's most detrimental impacts on the climate and environment. A company should make claims in context, relative to the company's full value chain and societal impacts.
- Be informative : A claim should help the target audience learn more about the nature of the claim being made.
- Set the right incentives for the target audience : A claim should not incentivize negative environmental behavior and ideally should encourage the consumer to take further positive environmental action. 66

Useful resources for implementing step 4.3 include:

- VCMI's Claims Code of Practice and the Supplementary Guidance set out guidance and key steps for companies on the credible use of carbon credits as part of their climate commitments and on the associated claims that may be publicly made regarding the use of those credits. VCMI's Carbon Integrity Silver, Gold or Platinum claims are BVCM claims where the purchase and retirement carbon credits are used for companies to go beyond science-based targets.
- GHG Protocol's draft Land Sector and Removal Guidance includes a section on target setting on activities covered within the guidance and proposes a distinction between compensation and contribution targets.
- ISEAL's Making Credible Jurisdictional Claims Good Practice Guide helps ensure that sustainability claims made by jurisdictions, landscape initiatives and the companies that source from or support them, are credible. ISEAL describes 'attribution claims' as those where an entity can show a causal link between their supporting action and a change in performance or direct impact. In contrast, ISEAL describes 'contribution claims'' which require companies to bring evidence that they contributed to a specific landscape or jurisdictional performance outcome if their actions are relevant to that performance outcome, are timely (leading to improvements in a timely manner), and at a scale to meaningfully impact performance.
- Gold Standard's guidance on Fairly Contributing to Global Net-Zero: Considerations for credible claims aims to assist companies in making credible claims, based on responsibly contributing, at a fair scale, to global net-zero efforts and beyond. It argues that it is necessary to trend away from inward focused claims, such as carbon neutrality, towards more collective action, contribution-led claims language to truly take responsibility and to make a significant contribution to mitigating the climate emergency.

## ILLUSTRATIVE CASE STUDIES

<!-- image -->

It is expected that there will be diversity in the interpretation of this report in terms of the scale of BVCM pledge and in terms of what exactly is funded, and the types of claims made. This reflects the diversity of companies and the range of factors that will influence the specificities of each company's business case - factors such as the size, region, market, and industry in which the company operates and the extent to which the company is impacted by the changing physical environment linked to climate change and the associated changes in policy, financial markets, consumer markets, society and technology.

To bring this guide to light, this section sets out four illustrative case studies. These fictional case studies do not necessarily reflect best practice in terms of the scale of the BVCM pledges. Instead, these case studies illustrate how companies of varying sizes, profit pools, and sectors might all follow the steps and consider the recommendations described in this paper.

Image source: 1PointFive and Carbon Engineering

## UMBRELLA CORPORATION

<!-- image -->

## Company context

Umbrella Corporation is an international food and beverage company headquartered in Houston, United States. In 2022 its GHG inventory comprised 1.5 million tCO2e of scope 1 and 2 emissions and 15 million tCO2e of scope 3 emissions. The company had profits in the same year of USD 8 billion. Its profits were therefore USD 485 per tCO2e of scope 1, 2 and 3 emissions.

The company has validated near-term SBTs covering its energy/industry emissions and its land sector emissions in accordance with the SBTi's FLAG Guidance. In order to achieve FLAG targets the company will primarily focus on reducing emissions from land use change. Umbrella Corporation commits to no-deforestation with a 2025 target year as required by the SBTi FLAG Guidance, and has also set a no-conversion commitment (covering all natural ecosystems). The company aligns its no-deforestation and no-conversion commitment with the Accountability Framework initiative (AFi). The company has also set a net-zero target which has been validated by the SBTi.

Umbrella Corporation has set and disclosed a climate transition plan that aligns with its net-zero commitment. This plan describes its objectives and priorities for responding and contributing to the transition towards a low GHG emissions, climate-resilient economy and how it intends to capture climate-related opportunities, avoid adverse impacts for stakeholders and society, and safeguard the natural environment.

## The business case for BVCM

As part of this transition planning process, Umbrella Corporation identified climate-related financial risk which is likely to undermine the long-term success of the business - the company sources agricultural commodities from water scarce areas across the tropical belt and is already seeing impacts from climate change and deforestation take hold. Shifting temperature extremes and precipitation rates are affecting water availability and are reducing productivity/yields of one of its signature commodities. Additionally, there are labor shortages as malaria rates increase and field hours are reduced due to heat exposure. The main drivers of deforestation and forest degradation in the region are the expanding agricultural footprint for international and domestic consumption and fuelwood collection. The company has also identified opportunities for green premiums and market growth linked to shifting consumer behavior in support of sustainability outcomes.

The Chief Financial Officer (CFO) and her team have therefore identified BVCM as an opportunity for risk mitigation and long-term value creation. They have identified significant long-term financial benefits in funding BVCM to build resilience in landscapes geographically and ecologically linked to the value chain and improve security of supply of key commodities. They have also identified through consumer research that organizational and product-level labels relating to BVCM would help to differentiate the brand and increase the company's market share.

## Determining the pledge and securing internal buy-in

The finance team conducted research on science-based carbon prices and identified Kaufman et al. (2022) as a credible source of a 1.5°C aligned carbon price. They select the upper estimate of a 2025 carbon price of USD 64/ tCO2e. If Umbrella Corporation applied this price to 100% of unabated scope 1, 2 and 3 emissions it would cost USD 1.056 billion or 13% of profits in 2022. While the CFO and the board recognize that this is consistent with internalizing their GHG externality, they consider this to be infeasible given shareholder expectations.

Instead, the company chooses to make a VCMI Carbon Integrity Silver claim and to purchase and retire highquality carbon credits equal to 20% of Umbrella Corporation's remaining emissions (i.e., 20% of 16.5 million tCO2e, equating to 3.3 million tCO2e). The company is committed to paying a fair price for high-quality carbon credits that cover the full project and implementation costs and provide a premium for local communities. They also expect carbon credit prices in the voluntary carbon market to increase over time. They therefore estimate that, at an illustrative average price of USD 50 per carbon credit, they should set aside an annual budget of USD 165 million, or 2% of profit.

The CFO and her team believe that this level of investment is justifiable given future savings resulting from reduced supply chain disruptions and associated price increases and volatility in key commodities, as well as the expected growth in market share due to brand differentiation. The company therefore decides to tap into its significant marketing and advertising budget to unlock additional resources.

At the same time, the CFO recognizes the need to transparently report on the company's climate-related risks to investors and therefore reports the company's remaining GHG externality of USD 891 million in its annual financial report, alongside the calculation and the source of the carbon price used (Kaufman et al., 2022).

The Umbrella Corporation board approves the CFO's proposal and decides to make its BVCM pledge over a fiveyear period to ensure that it delivers the greatest impact for climate and nature while also aligning with internal business planning processes.

## Designing a portfolio of BVCM

The company has a validated SBTi target and is therefore funding regenerative agricultural practices throughout its supply chain and has achieved zero deforestation. Carbon credits are the preferred mechanism for this company's BVCM funding, based on company policy. However, the CFO has concerns about integrity given some of the recent attacks in the media and so she follows the guidance of CCQI and TFCI as well as approaching an organization that provides third-party verification using standardized methodologies. Umbrella Corporation also commits to minimum quality standards and safeguarding principles to avoid any potentially adverse impacts of its BVCM investment. In particular, the company establishes regular environmental and social impact assessments and periodic stakeholder consultations.

Given the company's BVCM objectives to enhance brand value and build resilience in the landscapes surrounding its supply chain for their signature commodity, it identifies a priority in addressing the regional broader drivers of deforestation. Umbrella Corporation would also like to address the broader impacts of climate change, beyond its sourcing region, given it is a global company.

Based on the company's objectives and using the SBTi's principles for deploying resources and finance to BVCM, Umbrella Corporation delivered 3.3 million tCO2e of verified BVCM, representing 20% of its 2022 scope 1, 2 and 3 footprint, across the following activities:

- 3 million tCO2e of emissions reductions from jurisdictional REDD+ within the region of their signature commodity - following the guidance of the TFCI, development of these credits includes securing land tenure for Indigenous Peoples to slow land speculation, region-wide certification for the signature commodity, restoration of riparian zones and expanded silvopasture practices across grazing lands, etc.
- 299,900 tCO2e of biogenic removals linked to restoration of degraded land with a mix of native species within the region of their signature commodity.
- 100 tCO2e of verified removals from direct air capture and carbon storage (DACCS).

As a high performer on their in-supply chain targets, the company is excited that there are opportunities to address the larger impacts of climate change adjacent to and beyond their supply chain. The company reports these funding activities transparently in their annual submission to CDP and within their corporate social responsibility (CSR) report which they link to on their company website. Umbrella Corporation's CSR report also includes a statement confirming the company has complied with the VCMI Claims Code of Practice and the Foundational Criteria and sought third-party assurance of reported information.

<!-- image -->

## MRV and claims

To assist with the company's reporting over time, Umbrella Corporation develops a BVCM measurement, reporting and verification (MRV) framework and engages in parallel an independent third-party reviewer to provide an independent assessment.

Additionally, the company develops a marketing campaign showing how it is contributing to the contributing to global climate action within and beyond within and beyond its operations, including special interest stories from the programs it is supporting. Given Umbrella Corporation's performance on its SBTi target and the fact that it is delivering verified mitigation outcomes beyond the value chain proportional to 20% of the company's remaining emissions, Umbrella Corporation communicates to their customers and prospective employees that they are aligned with VCMI Carbon Integrity Silver claim.

## REDE CAMP

## Company context

SBTi-validated netzero and near-term science-based targets

<!-- image -->

Rede Camp is a technology company headquartered in Campinas, Brazil. Its 2023 GHG footprint was 0.5 million tCO2e of scope 1 and 2 emissions and 10 million tCO2e of scope 3 emissions.  The company had profits in the same year of USD 70 billion. Its profits were therefore USD 6,667 per tCO2e of scopes 1, 2 and 3 emissions.

2021 base year

<!-- image -->

Rede Camp has SBTi-validated net-zero and near-term science-based targets, both of which use 2021 as the base year. It has developed a climate transition plan in line with the recommendations of the Transition Plan Taskforce and in its 2023 disclosure was proud to report progress towards the delivery of its climate targets. As part of its plans the company will embrace principles of reducing, reusing, and recycling in order to reduce electronic waste and maximize the lifespan of their products.

## The business case for BVCM

The highly profitable technology company, which operates in a competitive market, identifies commercial interest in demonstrating to consumers and regulators that its privileged economic position is balanced by tangible social responsibility. Rede Camp is known as a technology innovation leader within its sector and believes that it has a responsibility to invest beyond its sector to support the development of the next generation of climate technology solutions.  Additionally, the company sees an opportunity to enhance the reputation of the brand and is conscious that talent attraction and retention hinges on its ability to demonstrate its global corporate responsibility in real and meaningful ways, especially to employees under the age of 30.

The company's shareholders are investors that are keenly aware of climate-related financial risk and have a history of active engagement and voting in support of Rede Camp sustainability initiatives. Likewise, the company founder and Chief Executive Officer is a public advocate for progressive climate action, and she believes that the company's values and activities should be aligned with building a low-carbon, nature-positive and equitable future.

The Chief Sustainability Officer and his team have therefore identified significant long-term financial benefits associated with BVCM to build resilience and continuity in the investor base and internal talent pool and have also identified through consumer research that investing in the next generation of climate technology solutions would help to differentiate the brand.

## Determining the pledge and securing internal buy-in

Given the company makes USD 6,667 of profit for every metric ton of scope 1, 2 and 3 emissions, it recognizes the importance of taking full responsibility for its unabated emissions as it transitions to net-zero. Rede Camp therefore chooses to apply a carbon price to its unabated emissions. It identifies the High-Level Commission on Carbon Prices (2017) as a credible source (which estimated that carbon prices needed to reach USD 50/tCO2 to 100/tCO2 by 2030 to be on track to keep temperatures below 2°C). 67 It chooses to align with the mid-point estimate of USD 75/tCO2e. It applies this to 100% of unabated scope 1, 2 and 3 emissions which translates to a cost of USD 787.5 million or 1.1% of profits.

The company's executive team and board believe that this level of investment is justifiable given the existential threat of climate change, the company's values, the importance of demonstrating social and environmental

responsibility to consumers, investors, regulators and current and prospective employees and its greater ability to pay compared to other sectors.

Rede Camp's revenue and profits are relatively stable year-to-year, and it has a strong economic outlook over the next five years. It therefore decides to commit to taking responsibility for unabated emissions between 2024 and 2030 to align with its near-term value chain emission reduction target year of 2030.

## Designing a portfolio of BVCM and wider climate action

In line with the SBTi's BVCM Goals and Principles, Rede Camp recognizes the need to unlock near-term mitigation at scale, as well as funding innovation needed for the longer-term transition to net-zero.

As a Brazilian company with operations, supply chains and consumers across South America, the company wants to have a significant focus on halting deforestation in the Amazon rainforest. It also sources copper and other precious metals from the Democratic Republic of Congo and is alarmed by the soaring rates of deforestation in this country. It has put in place policies to ensure the sustainable mining of metals but sees the opportunity to support activities beyond its supply chain to address deforestation in the region. As a technology leader, it also sees an opportunity to use its networks and its expertise in this field to drive climate technology innovation beyond its sector.

Rede Camp therefore designed a portfolio of activities as follows:

- It commits to the purchase and retirement of 5.5 million tCO2e of REDD+ carbon credits each year over the commitment period to reduce emissions from deforestation and degradation in the Amazon rainforest and the Congo Basin. It uses the TFCI Guide to identify high-quality credits.
- USD 100 million in annual support of multi-stakeholder platforms in landscapes adjacent to its supply chain - including the Cerrado biome in the State of São Paulo - to promote constituency building, spatial mapping, and strategic planning to enable the protection, sustainable management and restoration of natural ecosystems. This activity also aligns with the company's nature targets that will be submitted to the Science Based Target Network (SBTN) for validation.
- USD 250 million annual funding of catalyst programs supporting the scale-up of emerging climate technologies including methane destruction, long duration energy storage, green hydrogen, and cold storage infrastructure.
- USD 150 million of investment into a blended finance mechanism that supports climate mitigation, adaptation, and the just transition in emerging economies.

Rede Camp also commits to minimum quality standards and safeguarding principles to avoid any potentially adverse impacts of its BVCM activities. The company demonstrates this commitment through regular environmental and social impact assessments and periodic stakeholder consultations.

<!-- image -->

## MRV and claims

Rede Camp develops a BVCM measurement, reporting and verification framework and engages in parallel an independent third-party reviewer to provide an independent assessment. It makes a headline climate contribution claim and the BVCM funding and outcomes are reported transparently in its annual submission to CDP and as part of its climate transition plan annual disclosure. Additionally, the company launches a marketing campaign highlighting the breakthroughs that their funds are contributing to with a focus on the teams advancing the technology.

## PIKATTO

## Company context

<!-- image -->

Pikatto is a software and telecommunications start-up headquartered in Tokyo, Japan. As a relatively young company, sustainability has been built into the business from the outset and the company is already sourcing 100% renewable energy across its operations and has implemented sustainable sourcing policies. The company sells products and services which help their customers to reduce emissions and so the business strategy is inherently linked to the global transition to net-zero. Its largest consumer market is in Japan, but it is increasingly expanding into China, India, and Indonesia.

42% by 2030

Pikatto is eligible to follow the SBTi's streamlined validation route for small and medium-sized enterprises (SMEs) and therefore commits to reduce its absolute scope 1 and scope 2 GHG emissions 42% by 2030 from a 2022 base year, and to measure and reduce its scope 3 emissions. It also commits to reach net-zero at the latest by 2050, reducing absolute scope 1, 2 and 3 GHG emissions 90% by 2050 from a 2022 base year. Its scope 1 and 2 footprint in 2022 was 500 tCO2e. It has estimated its scope 3 footprint but is working to improve scope 3 primary data and emission factors before it sets a quantitative near-term scope 3 target.

In 2022 the company had a revenue of USD 35 million and profits of USD 5 million. Its profit is USD 10,000 per metric ton of scope 1 and 2 emissions.

## The business case for BVCM

While sustainability is central to Pikatto's business activities and brand, it identifies BVCM as an opportunity to differentiate the brand further. Its brand identity focuses on connection and networking and has an internal ethos about learning from nature - particularly through complex natural networks.

The company has witnessed damage to its operations and experienced supply chain disruptions linked to flooding across Japan that has increased in severity and frequency in recent years as a result of climate change.

## Determining the pledge and securing internal buy-in

The senior leadership team identified BVCM as an opportunity to help Pikatto to maintain its competitive edge and become more resilient to climate-related weather events.

While the company works to improve its scope 3 footprint, it decided to tie its BVCM commitment to its scope 1 and 2 emissions only. It chose to adopt a social cost of carbon and uses Rennert et al. (2022) as its source which calculates a mean social cost of carbon at USD 185/tCO2e. 68

Based on this social cost of carbon applied to its scope 1 and 2 emissions in 2022, it defined a budget of USD 92,500 (or 1.85% of profit) which it deployed towards a range of activities to take responsibility for its unabated emissions.

## Designing a portfolio of BVCM

Based on the company's objectives and SBTi's Goals and Principles for BVCM, Pikatto deployed its USD 92,500 budget equally between the following activities:

- Verified renewable energy generating credits in India.
- High Forest cover, Low Deforestation (HFLD) jurisdictional credits (under the REDD+ Environmental Excellence Standard (TREES) from the Architecture for REDD+ Transactions) to protect intact forests in Southeast Asia.
- The expansion of green spaces in and around Japanese cities, and protection and restoration of marshes and reefs to buffer coats and absorb floodwaters.

<!-- image -->

## MRV and claims

Pikatto reported its funding activities and the associated outcomes transparently in its annual submission to CDP and within its CSR report. It made a headline climate contribution claim and launched a marketing campaign that demonstrates its commitments to climate action, highlighting the linkages between digital connectivity and nature's intact networks.

## VIHAAN VENTURES

<!-- image -->

Vihaan Ventures is a private equity firm headquartered in Delhi, India. It has USD 30 billion of assets under management and in 2022 saw profits of USD 2.5 billion. It has a large portfolio of investments in affordable clean energy and water, financing commercial solar PV installations, rural solar minigrid installations and water sanitation and infrastructure across Asia. Vihaan Ventures' 2022 GHG footprint was 200 tCO2e of scope 1 and 2 emissions and 7,000 tCO2e of scope

50% by 2030

3 emissions (categories 1-14). It uses the Partnership for Carbon Accounting Financials (PCAF) framework to quantify its scope 3 financed emissions of 1 million tCO2e. Its profits were therefore USD 2,482 per tCO2e of scopes 1, 2 and 3 emissions.

The firm has a validated near-term science-based target with a base year of 2022, in accordance with the SBTi Financial Institutions Guidance. It commits to reduce absolute scope 1 and 2 emissions by 50% by 2030. Its portfolio targets are focused on ensuring that all of its portfolio companies establish SBTs and reduce their emissions along 1.5°C pathways. The targets cover 100% of its total investment and lending activities by invested capital as of 2022. The company has not yet set a net-zero target as SBTi guidance for net-zero targets for Financial Institutions is forthcoming. It has developed a climate transition plan in line with the recommendations of the Transition Plan Taskforce and has reported good progress towards its 2030 target.

## The business case for BVCM

Vihaan Ventures is a profitable private equity firm and has embedded sustainability into its investment activities. It has also identified climate-related financial risks associated with the businesses the firm is invested in. In 2022, the firm established a Philanthropy Committee and is in the process of developing a philanthropy strategy covering climate, water, nature and education. Vihaan Ventures has decided to engage in BVCM as risk mitigation for their business investments and as part of its philanthropic efforts, distinct from its core investment activities. It also sees BVCM as an opportunity to explore new thematic areas which could be relevant to its investment activities in the future.

## Determining the pledge and securing internal buy-in

Given the firm's high profitability and fluctuations in its annual GHG emissions footprint, it decides to tie its BVCM pledge to its annual profitability, committing 1.5% of annual profits to BVCM. It also encourages its portfolio companies to consider BVCM in the context of their climate transition planning.

## Designing a portfolio of BVCM

Informed by the firm's objectives and the SBTi's BVCM report, Vihaan Ventures deployed its USD 37.5 million annual budget between the following activities, primarily in Asia and sub-Saharan Africa:

- Jurisdictional REDD+ carbon credits.
- Renewable energy generating carbon credits.
- Energy efficiency carbon credits.
- Landfill gas capture
- The protection and restoration of coastal ecosystems.
- Cold storage projects focused on reducing food loss and waste in sub-Saharan Africa and India.
- Carbon dioxide removal credits linked to DACCS, bioenergy with carbon dioxide capture and storage (BECCS) and biochar.
- Initiatives focused on fossil fuel phase-out at the jurisdictional level.
- Just transition philanthropic activities supporting the retraining of workers across sectors affected by the transition to net-zero.
- Support for progressive climate-related policy advocacy.

<!-- image -->

## MRV and claims

Vihaan Ventures develops a BVCM measurement, reporting and verification framework and engages in parallel an independent third-party reviewer to provide an independent assessment. The BVCM funding and outcomes are reported transparently in its annual submission to CDP and as part of its climate transition plan annual disclosure. Vihaan Ventures launches a marketing campaign focused on contributing '1.5% of profits for a 1.5°C world'.

The BVCM funding and outcomes are reported separately from Vihaan Ventures' investment portfolio and its associated financed emissions. The BVCM funds are not aggregated with the investment portfolio for the purposes of calculating financed emissions or making claims.

## Table 4: Comparison of the illustrative case studies

| Umbrella Corporation                                                                             | Rede Camp                                                                                                                      | Pikatto                                                                                                         | Vihaan Ventures                       |
|--------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|---------------------------------------|
| Sector Food and beverage                                                                         | Technology Software and telecommunications SME                                                                                 |                                                                                                                 | Private equity                        |
| Profit (USD) 8 billion                                                                           | 70 billion 5                                                                                                                   | million                                                                                                         | 2.5 billion                           |
| 2 emissions 1.5 million                                                                          | 0.5 million                                                                                                                    | 500                                                                                                             | 7,200                                 |
| emissions 15 million                                                                             | 10 million                                                                                                                     | Not calculated                                                                                                  | 1 million                             |
| Profit per 1tCO2e (USD) 485                                                                      | 6,667                                                                                                                          | 10,000 (based on scope 1 and 2 only)                                                                            | 2,482                                 |
| Method used to determine Ton-for-ton method applied to 20% of scope 1, 2 and 3 emissions         | Money-for-ton method, based on the application of a target-consistent carbon price of USD 75 to its scope 1, 2 and 3 emissions | Money-for-ton method, based on the application of a social cost of carbon of USD 185 to scope 1 and 2 emissions | Money-for-money, based on 1.5% profit |
| Annual financial contribution to 165 million (based on estimated average carbon price of USD 50) | 787.5 million                                                                                                                  | 92,500                                                                                                          | 37.5 million                          |
| Financial contribution as a %of profit 2%                                                        | 1.1%                                                                                                                           | 1.85%                                                                                                           | 1.5%                                  |

## ACRONYMS

## ACRONYMS

Table 5:  Acronyms used in this document

| TERM      | DEFINITION                                                                       |
|-----------|----------------------------------------------------------------------------------|
| AFOLU     | Agriculture, Forestry and Other Land Use                                         |
| AR6       | IPCC's Sixth Assessment Report                                                   |
| ART TREES | Architecture for REDD+ Transactions, The REDD+ Environmental Excellence Standard |
| BVCM      | Beyond value chain mitigation                                                    |
| CAGR      | Compound annual growth rate                                                      |
| CCQI      | Carbon Credit Quality Initiative                                                 |
| CDR       | Carbon dioxide removal                                                           |
| CO2       | Carbon dioxide                                                                   |
| DACCS     | Direct Air Carbon Capture and Storage                                            |
| ESG       | Environmental, social and corporate governance                                   |
| EAG       | Expert Advisory Group                                                            |
| ETS       | Emissions trading scheme                                                         |
| FLAG      | Forest, land, and agricultural sector                                            |
| GHG       | Greenhouse Gas                                                                   |
| GHGP      | Greenhouse Gas Protocol                                                          |
| GtCO2     | One billion metric tons of carbon dioxide                                        |
| HFLD      | High forest, low deforestation                                                   |
| ICVCM     | Integrity Council for the Voluntary Carbon Market                                |
| IAM       | Integrated assessment model                                                      |
| IEA       | International Energy Agency                                                      |

| TERM   | DEFINITION                                                                  |
|--------|-----------------------------------------------------------------------------|
| IPCC   | Intergovernmental Panel on Climate Change                                   |
| ISEAL  | International Social and Environmental Accreditation and Labelling Alliance |
| LCA    | Life cycle assessment                                                       |
| MAC    | Marginal abatement cost                                                     |
| MRV    | Measurement, reporting and verification                                     |
| NDCs   | Nationally Determined Contributions                                         |
| PES    | Payment-for-ecosystem-services                                              |
| R&D    | Research and development                                                    |
| REDD+  | Reducing Emissions from Deforestation and Forest Degradation                |
| ROI    | Return on investment                                                        |
| SME    | Small and medium-sized enterprise                                           |
| SBT    | Science-based target                                                        |
| SBTi   | Science Based Targets initiative                                            |
| SBTN   | Science Based Target Network                                                |
| SCC    | Social cost of carbon                                                       |
| SDGs   | Sustainable Development Goals                                               |
| TCFD   | Task Force on Climate-related Financial Disclosures                         |
| TNFD   | Taskforce on Nature-related Financial Disclosures                           |
| TPT    | Transition Plan Taskforce                                                   |
| TCO2e  | Metric tons of carbon dioxide equivalent                                    |
| UNFCCC | United Nations Framework Convention on Climate Change                       |
| VCMI   | Voluntary Carbon Market Integrity Initiative                                |
| WBCSD  | World Business Council for Sustainable Development                          |
| WRI    | World Resources Institute                                                   |
| WWF    | World Wide Fund for Nature                                                  |

## GLOSSARY

## GLOSSARY

A glossary of key terms used in this document is provided below, however readers are encouraged to refer to the SBTi's online glossary which is kept up to date: sciencebasedtargets.org/glossary.

| TERM                                         | DEFINITION                                                                                                                                                                                                                                                                                                                                                               |
|----------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.5°C aligned scenario                       | Scenario in which the global average temperature is limited to 1.5°C above pre-industrial levels with no or limited overshoot.                                                                                                                                                                                                                                           |
| 1.5°C aligned target                         | Ascience-based target derived from a 1.5°C aligned scenario via an approved target-setting method.                                                                                                                                                                                                                                                                       |
| Abatement                                    | Measures that companies take to prevent, reduce, or eliminate sources of GHG emissions within their value chain.                                                                                                                                                                                                                                                         |
| Adaptation                                   | Adjustments in ecological, social or economic systems in response to actual or expected climatic stimuli and their effects or impacts. Adaptation refers to changes in processes, practices and structures to moderate potential damages or to benefit from opportunities associated with climate change. 69                                                             |
| Additionality                                | Additionality is the extent to which something happens as a result of an intervention that would not have occurred in the absence of the intervention. Additionality is a defining concept of interventions quantified with consequential accounting, including carbon credit projects and programs.                                                                     |
| Annual unabated value chain emissions        | The scope 1, 2 and 3 emissions that remain in a given year as a company progresses towards the delivery of its near- and long-term science-based target.                                                                                                                                                                                                                 |
| Assurance                                    | Demonstration that specified requirements relating to a product, process, system, person or entity are fulfilled. 70                                                                                                                                                                                                                                                     |
| Avoided emissions (product-level accounting) | Product-related avoided emissions are emission reductions that occur outside of the life cycle or value chain of a product or service, but as a result of the use of that product. 71 Avoided emissions account for the favorable differences in the GHG emissions impact of a product (good or service) relative to the situation where that product does not exist. 72 |
| Base year (or period)                        | A historic datum (a specific year or an average over multiple years) against which a company's emissions are tracked over time. 73                                                                                                                                                                                                                                       |
| Base year recalculation                      | Retroactive recalculation of a target base year GHGinventory to reflect changes that have occurred since it was originally calculated, for example a change in company structure or accounting methodology used, to ensure the consistency and relevance of the reported GHGemissions information. 74                                                                    |

| TERM                                                      | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-----------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Benefit sharing                                           | Benefit sharing is the allocation of the proceeds from carbon credits to local stakeholders involved in a carbon credit project or program. 75                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Beyond value chain mitigation (BVCM)                      | Mitigation action or investments that fall outside a company's value chain, including activities that avoid or reduce GHG emissions, or remove and store GHGs from the atmosphere.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Biochar                                                   | Carbon-rich material produced from the thermochemical conversion of biomass in an oxygen-limited environment. Biochar may be added to soils to improve soil functions and to reduce greenhouse gas emissions from biomass and soils, and for carbon sequestration.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Bioenergy                                                 | Energy derived from any form of biomass or its metabolic by-products. 76 This may include but is not limited to energy generated from the combustion of biomass and energy derived from recently living organisms.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Bioenergy with carbon dioxide capture and storage (BECCS) | Bioenergy with carbon capture and storage (BECCS) involves any energy pathway where CO2 is captured from a biogenic source and permanently stored. 77                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Carbon credit                                             | Acarbon credit is a tradable unit that represents one metric ton of greenhouse gas (GHG) emission reductions or removals. Carbon credits are uniquely serialized, issued, tracked, and retired by means of an electronic registry. Carbon credits in the voluntary carbon market (VCM) are generated by the activities of projects and programs that are certified by carbon standards. Credited GHGreductions or removal enhancements are quantified using project or intervention accounting methods, which quantify system-wide GHGimpacts relative to a counterfactual baseline scenario or performance benchmark that represent the conditions most likely to occur in the absence of the mitigation project or program that generates the credit. |
| Carbon dioxide capture and storage (CCS)                  | A process in which a relatively pure stream of carbon dioxide (CO2) from industrial and energy-related sources is separated (captured), conditioned, compressed and transported to a storage location for long-term isolation from the atmosphere. This is sometimes referred to as carbon capture and storage. 78 Usually the CO2 is captured from large point sources, such as power generation or industrial facilities, and then stored permanently in an underground geological formation.                                                                                                                                                                                                                                                         |
| Carbon dioxide equivalent                                 | The amount of carbon dioxide (CO2) emission that would cause the same integrated radiative forcing or temperature change, over a given time horizon, as an emitted amount of a greenhouse gas (GHG) or a mixture of GHGs.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Carbon dioxide removals (CDR) / Carbon removals           | Anthropogenic activities removing carbon dioxide (CO2) from the atmosphere and durably storing it in geological, terrestrial, or ocean reservoirs, or in products. 79                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |

| TERM                         | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
|------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Carbon offset credit         | A carbon credit is a tradable unit that represents one metric ton of greenhouse gas (GHG) emission reductions or removals. When a carbon credit is purchased and retired for offsetting purposes, it is sometimes referred to as a carbon offset credit.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Carbon pricing               | Carbon pricing is an instrument that captures the external costs of greenhouse gas (GHG) emissions - the costs of emissions that the public pays for, such as damage to crops, health care costs from heat waves and droughts, and loss of property from flooding and sea level rise - and ties them to their sources through a price, usually in the form of a price on the carbon dioxide (CO2) emitted. 80                                                                                                                                                                                                                                                                                                                                                                                   |
| Claim (about sustainability) | A message used to describe or promote a product, process, business, or service with respect to its sustainability attributes or credentials. 81                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Climate change mitigation    | A human intervention to reduce emissions or enhance the sinks of GHGs. 82                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Climate compensation claim   | Claims which convey to audiences that the organization has delivered BVCM proportional to a stated percentage of unabated value chain emissions and that the BVCM outcomes counterbalance or 'net out' that stated percentage of unabated value chain emissions. The draft GHGProtocol Land Sector and Removals Guidance describes 'compensation targets' related to the use of carbon credits as 'a target for achieving mitigation external to the target boundary through purchasing and retiring GHGcredits (also called offsets or carbon credits) to compensate for annual or cumulative unabated emissions in the target boundary, if allowed under the relevant target setting program or target setting policy.' 83 An example of a compensation claim is the carbon neutrality claim. |
| Climate contribution claim   | Claims which convey to audiences that the organization has provided support or finance to actions beyond the company's value chain (including through collective action) with an expected climate mitigation outcome (where the actions are relevant to the expected performance outcome). Unlike compensation claims, the contribution claim does not imply that the BVCMoutcomes are netting out or counterbalancing the claimants' remaining value chain emissions, but instead are communicated as a contribution to global climate mitigation efforts or even the efforts of a country.                                                                                                                                                                                                    |
| Climate impact metric        | Measure of the actual effects or outcomes of an organization's activities on the climate. The most common impact metric is GHGemissions.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Climate justice              | Justice that links development and human rights to achieve a human- centered approach to addressing climate change, safeguarding the rights of the most vulnerable people and sharing the burdens and benefits of climate change and its impacts equitably and fairly. 84                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |

| TERM                           | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
|--------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Climate neutral claim          | The IPCC defines climate neutrality as the concept of a state in which human activities result in no net effect on the climate system. Achieving such a state would require balancing of residual emissions with emission (carbon dioxide) removal as well as accounting for regional or local biogeophysical effects of human activities that, for example, affect surface albedo or local climate. 85 Typically companies use the term climate neutral to describe the practice of purchasing and retiring carbon credits equivalent to the volume of unabated emissions - either at the organizational or product level - in a given period. |
| Climate-related financial risk | Financial risks related to the physical impacts of climate change as well as the transition to a low-carbon economy (e.g., legal, technology, reputation). 86                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Climate tipping point          | Climate tipping points represent a certain temperature threshold where there is unstoppable and self-perpetuating change in a climate system - change which would take effect on timescales varying from a few years to centuries. 87                                                                                                                                                                                                                                                                                                                                                                                                           |
| Co-benefit                     | A positive effect that a policy or measure aimed at one objective has on another objective, thereby increasing the total benefit to society or the environment. Co-benefits are also referred to as ancillary benefits. 88                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Conversion (of land)           | Change of a natural ecosystem to another land use or profound change in a natural ecosystem's species composition, structure or function. Deforestation is one form of conversion (conversion of natural forests). Conversion includes severe degradation or the introduction of management practices that result in a substantial and sustained change in the ecosystem's former species composition, structure or function. Change to natural ecosystems that meets this definition is considered to be conversion regardless of whether or not it is legal.                                                                                  |
| Debt finance                   | In contrast to equity finance, debt finance is a method of raising capital by selling debt instruments, such as bonds or notes. Typically, the funds are paid off with interest at an agreed later date.                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Decarbonization                | The process by which countries, individuals or other entities aim to achieve zero fossil carbon existence. Typically refers to a reduction of the carbon emissions associated with electricity, industry and transport. 89 Please note that the term 'decarbonization' refers only to CO2 mitigation, while 'abatement' also includes non-CO2 mitigation.                                                                                                                                                                                                                                                                                       |
| Deforestation                  | Loss of natural forest as a result of 1) conversion to agriculture or other non-forest land use, 2) conversion to a tree plantation, or 3) severe and sustained degradation.                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |

| TERM                                                                                          | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-----------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Degradation (of land)                                                                         | Changes within a natural ecosystem that significantly and negatively affect its species composition, structure and/or function and reduce the ecosystem's capacity to supply products, support biodiversity and/or deliver ecosystem services. Degradation may be considered conversion if it: is large-scale and progressive or enduring; alters ecosystem composition, structure, and function to the extent that regeneration to a previous state is unlikely; or leads to a change in land use (e.g., to agriculture or other use that is not a natural forest or other natural ecosystem). 90                                                                      |
| Direct air carbon dioxide capture and storage (DACCS) / Direct air capture and storage (DACS) | Chemical process by which CO2 is captured directly from the ambient air, with subsequent storage. Also known as direct air capture and storage (DACS). 91 The captured CO2 can be injected into geological reservoirs or used to make long-lasting products.                                                                                                                                                                                                                                                                                                                                                                                                            |
| Disclosure                                                                                    | Public sharing of information by companies. In the context of the SBTi, this includes information related to science-based targets and metrics that inform the target. Disclosure is a mechanism for transparency.                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Double claiming                                                                               | A type of double counting in which the same emission reduction or removal is claimed by two different entities towards achieving mitigation targets or goals. The double claiming of emissions reductions and removals often happens between a company's GHGinventory and the national inventory where that mitigation outcome occurred. In the context of voluntary carbon markets, double claiming can occur between a country, jurisdiction or other entity that reports lower emissions or higher removals for the purpose of demonstrating achievement of a mitigation target or goal and the entity retiring the carbon credit for the purpose of making a claim. |
| Double counting                                                                               | A situation in which a single emission reduction or removal is counted more than once towards achieving mitigation targets or goals. Double counting can refer to a situation in which a quantity of GHGemissions is included in more than one organization's GHGinventory. This can occur across scopes (scope 1, 2 and 3) and within a single scope due to differing consolidation approaches, differing emissions calculation methodologies, and the intentional design of emissions accounting standards.                                                                                                                                                           |
| Emissions inventory/ GHGinventory                                                             | The exhaustive calculated GHGemissions arising from activities within a company's organizational boundary and value chain corresponding to scope 1 and 2 GHGemissions and scope 3 GHGemissions respectively, displayed with all scope 1 emissions aggregated, all scope 2 emissions aggregated and scope 3 GHGemissions disaggregated by categories 1-15. GHGinventories also include biogenic emissions, but these are reported separately from the scopes. 92                                                                                                                                                                                                         |

| TERM                                                                        | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|-----------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Emissions reductions                                                        | Measures that companies take to prevent, reduce, or eliminate sources of GHGemissions within or beyond their value chain. Examples include reducing energy use, switching to renewable energy, and reducing chemical fertilizer use.                                                                                                                                                                                                                                                                                                                 |
| Emission scopes / scope 1 emissions / scope 2 emissions / scope 3 emissions | The GHGProtocol Corporate Standard classifies an organization's GHG emissions into three scopes: Scope 1 emissions are direct GHGemissions from operations owned or controlled by the reporting company. Scope 2 emissions are indirect GHGemissions from purchased electricity, heating/cooling, or steam. Scope 3 emissions are all indirect emissions (not included in scope 2) that occur in the value chain of the reporting organization, including both upstream and downstream emissions.                                                    |
| Enhanced weathering                                                         | Enhancing the removal of carbon dioxide (CO2) from the atmosphere through dissolution of silicate and carbonate rocks by grinding these minerals to small particles and actively applying them to soils, coasts or oceans. 93                                                                                                                                                                                                                                                                                                                        |
| Equity (in climate change)                                                  | Equity is the principle of fairness in burden sharing and is a basis for understanding how the impacts and responses to climate change, including costs and benefits, are distributed in and by society in more or less equal ways. It is often aligned with ideas of equality, fairness and justice and applied with respect to equity in the responsibility for, and distribution of, climate impacts and policies across society, generations, and gender, and in the sense of who participates and controls the processes of decision-making. 94 |
| Equity finance                                                              | Equity financing is the process of raising capital through the sale of shares.                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Financed emissions                                                          | Absolute emissions that banks and investors finance through their loans and investments. 95 Financed emissions can be calculated and disclosed by financial institutions at an asset class level or at portfolio level. Financed emissions are separate from 'facilitated emissions' and should be separately reported.                                                                                                                                                                                                                              |
| Forest                                                                      | Land spanning more than 0.5 hectares with trees higher than 5 meters and a canopy cover of more than 10% or trees able to reach these thresholds in situ. It does not include land that is predominantly under agricultural or other land use. Forest includes natural forests and tree plantations. For the purpose of implementing no-deforestation supply chain commitments, the focus is on preventing the conversion of natural forests. 96                                                                                                     |

| TERM                                         | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
|----------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Forest, land and agriculture (FLAG)          | FLAG designates the SBTi Forest, Land and Agriculture project, sectors, methodologies and targets. The terms 'FLAG-related emissions' and 'Agriculture, Forestry and Other Land Use (AFOLU) emissions' are used interchangeably in the SBTi FLAG Guidance.                                                                                                                                                                                                                                                                                                                                             |
| FLAG (forest, land, and agriculture) targets | A target that applies to a company's GHGemissions from AFOLU (Agriculture, forestry, and other land use), including GHGemissions associated with land use change (LUC), emissions from land management, and biogenic removals.                                                                                                                                                                                                                                                                                                                                                                         |
| Forest restoration                           | The process of assisting the recovery of a forest (natural or managed), as well as its associated conservation values, which has been degraded or damaged but is still above 10% canopy cover.                                                                                                                                                                                                                                                                                                                                                                                                         |
| Fungibility                                  | Being of such a nature that one part or quantity may be replaced by another equal part or quantity in the satisfaction of an obligation.                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| GHGexternality                               | Most of the impacts of GHGemissions do not fall on those conducting the activities - instead they fall on future generations or people living in developing countries, for example - so those responsible for the emissions do not pay the cost. The adverse effects of GHGs are therefore 'external' to the market. This leads to the market failure of climate change. The greenhouse gas externality is accompanied by a number of other market failures, including those arising from a lack of information about how to reduce emissions, network effects and a lack of innovation incentives. 97 |
| Greenhouse gas inventory boundary            | The activities and their associated direct and indirect emissions that are included in the GHG inventory. It results from the chosen organizational and operational boundaries.                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Greenhouse gases (GHGs)                      | Gases which absorb and re-emit infrared radiation, thereby trapping it in Earth's atmosphere and causing the greenhouse gas effect. They include carbon dioxide (CO2), methane (CH4), nitrous oxide (N2O), hydrofluorocarbons (HFCs), perfluorocarbons (PFCs), sulfur hexafluoride (SF6), and nitrogen trifluoride (NF3).                                                                                                                                                                                                                                                                              |
| Green hydrogen                               | Green hydrogen is defined as hydrogen produced from electrolysis of water using renewable electricity. 98                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Green premium                                | The green premium is the extra price producers can extract - and customers are willing to pay - over and above other price 'extras' such as those relating to the physical characteristics or carbon costs associated with producing a commodity. 99                                                                                                                                                                                                                                                                                                                                                   |

| TERM                                             | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
|--------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Greenwashing                                     | Greenwashing is the act of making false or misleading statements about the environmental benefits of a product or practice. It can be a way for companies to continue or expand their polluting as well as related harmful behaviors, all while gaming the system or profiting off well-intentioned, sustainably minded consumers. 100                                                                                                                                                                                                       |
| Headline climate claim                           | Headline climate claims are short, marketing-focused claims used to convey climate-related achievements and they should be supported by narrative claims which are, typically, longer descriptive claims made to convey more detailed progress or status-based achievements, for example, describing actions undertaken or planned and sharing data about achievements made. 101                                                                                                                                                             |
| High-carbon technology or infrastructure lock-in | High-carbon technology or infrastructure lock-in occurs when fossil fuel-intensive systems perpetuate, delay or prevent the transition to low- carbon alternatives. 102                                                                                                                                                                                                                                                                                                                                                                      |
| Internal carbon pricing                          | Internal carbon pricing is a tool an organization uses internally to guide its decision-making process in relation to climate change impacts, risks and opportunities. 103                                                                                                                                                                                                                                                                                                                                                                   |
| Investment                                       | The term investment is broadly defined as 'putting money into activities or organizations with the expectation of making a profit.' Most forms of investment involve some form of risk taking, such as investment in equities, debt, property, projects, and even fixed interest securities, which are subject to inflation risk, among other risks.                                                                                                                                                                                         |
| Intervention (or project) accounting             | Intervention (or project) accounting methods which measure system-wide GHGimpacts relative to a counterfactual baseline scenario or performance benchmark that represent the conditions most likely to occur in the absence of the mitigation project that generates the credit. 104                                                                                                                                                                                                                                                         |
| Just transition                                  | Greening the econoy in a way that is as fair and inclusive as possible to everyone concerned, creating decent work opportunities and leaving no one behind. 105 A just transition incorporates key principles, such as respect and dignity for vulnerable groups, the creation of decent jobs, social protection, employment rights, fairness in energy access and use, and social dialogue and democratic consultation with the relevant stakeholders, while coping with the effects of asset-stranding and the transition to net-zero. 106 |
| La Niña                                          | La Niña refers to the periodic cooling of ocean surface temperatures in the central and east-central equatorial Pacific. Typically, La Niña events occur every three to five years or so, but on occasion can occur over successive years. 107 The atmosphere cools in response to the cold ocean surface, and less water evaporates. The cooler, dry air is dense. 108                                                                                                                                                                      |

| TERM                           | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|--------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Land use change                | Transformation from one land use category (e.g., cropland, grassland, forest/woodland, urban/industrial, wetland/tundra) to another category (e.g., transformation from natural forest to cropland).                                                                                                                                                                                                                                                                                                                                                                                 |
| Leakage (of GHGemissions)      | When a mitigation activity carbon crediting project or program displaces emission-creating activities outside the project or program boundary rather than halting them in actual terms. Leakage of GHGemissions can occur when mitigation activities: (a) shift location (activity-shifting leakage); (b) indirectly affect areas that are hydrologically connected (ecological leakage); (c) impact the supply or demand of an emissions-intensive product or service (market leakage); or (d) impact upstream or downstream emissions (upstream/downstream emissions leakage). 109 |
| Life cycle assessment (LCA)    | Compilation and evaluation of the inputs, outputs, and potential environmental impacts of a product system throughout its life cycle. 110 LCA is a tool for the analysis of the environmental burden of product at all stages in their life cycle - from the extraction of resources, through the production of materials, product parts and the product itself, and the use of the product to the management after it is discarded, either by reuse, recycling or final disposal (in effect, therefore, 'from the cradle to grave').                                                |
| Long-term science-based target | GHGreduction targets that are in line with what the latest climate science deems necessary to reach net-zero and limit warming to 1.5°C above pre- industrial levels at the global or sector level and that are achieved by 2050 at the latest.                                                                                                                                                                                                                                                                                                                                      |
| Loss and damage                | While there is no internationally agreed upon definition for loss and damage, it usually refers to the negative effects of climate change that go beyond what people can adapt to ('hard limits' to adaptation), or where adaptation options exist but a community doesn't have the resources to access or utilize them ('soft limits' limits to adaptation). 111                                                                                                                                                                                                                    |
| Money-for-money method         | This is a method for determining the scale of a BVCM pledge. Using this method, a company would allocate a share of revenue or profit towards funding climate mitigation beyond the value chain. The volume of finance deployed towards BVCM would be determined by the chosen denominator (e.g., profit or revenue) and the chosen percentage.                                                                                                                                                                                                                                      |
| Money-for-ton method           | This is a method for determining the scale of a BVCM pledge. Using this method, a company would channel finance into BVCM based on predefined reference price of the unabated GHGemissions of that company in a defined period (e.g., in a given year or since the inception of the company). The volume of finance deployed towards BVCM would be determined by the chosen cost of carbon (e.g., a social cost of carbon or otherwise) and the unabated emissions in that defined period.                                                                                           |

| TERM                                 | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                    |
|--------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Narrative claim                      | In contrast to headline claims, narrative claims are descriptive claims made to convey more detailed progress or status-based achievements, for example, describing actions undertaken or planned and sharing data about achievements made. 112                                                                                                                                                               |
| Nature-based solutions (NbS)         | Nature-based Solutions (NbS) are actions to protect, sustainably manage and restore natural and modified ecosystems in ways that address societal challenges effectively and adaptively, to provide both human well-being and biodiversity benefits. 113                                                                                                                                                      |
| Near-term science-based target       | GHGreduction targets that are in line with what the latest climate science deems necessary to limit warming to 1.5°C above pre-industrial levels and that are achieved within a five- to ten-year timeframe from the date of submission to the SBTi.                                                                                                                                                          |
| Net-zero emissions                   | Net-zero emissions are achieved when anthropogenic emissions of greenhouse gases to the atmosphere are balanced by anthropogenic removals over a specified period. 114                                                                                                                                                                                                                                        |
| Net-zero science-based target        | Anet-zero science-based target is a greenhouse gas mitigation target that implies: Reducing scope 1, 2, and 3 emissions to zero or a residual level consistent with reaching global net-zero emissions or at a sector level in eligible 1.5°C-aligned pathways; and Permanently neutralizing any residual emissions at the net-zero target year and any GHGemissions released into the atmosphere thereafter. |
| Neutralization of residual emissions | Measures that companies take to counterbalance the climate impact of unabatable (i.e., residual) GHGemissions which are released into the atmosphere at and after net-zero target date through permanent removal and storage of CO2 from the atmosphere.                                                                                                                                                      |
| Offsetting                           | The term 'offsetting' refers to actions that a company takes to deliver mitigation outside of its value chain as a substitute for abatement of value chain emissions in line with a 1.5°C pathway.                                                                                                                                                                                                            |
| Payment for ecosystem services (PES) | Payments for Ecosystem Services is the name given to a variety of arrangements through which the beneficiaries of environmental services, from watershed protection and forest conservation to carbon sequestration and landscape beauty, reward those whose lands provide these services with subsidies or market payments. 115                                                                              |
| Permanence/ durability               | The longevity of a carbon pool and the stability of its stocks, given the management and disturbance environment in which it occurs.                                                                                                                                                                                                                                                                          |

| TERM                                | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
|-------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Polluter pays principle             | The polluter pays principle set out in the 1992 Rio Declaration signifies that those who produce pollution should bear the costs of managing it to prevent damage to human health or the environment.                                                                                                                                                                                                                                                                                                                                                                                             |
| Progress (of science-based targets) | Advancement towards achieving an established target prior to the target year and after the base year. Progress refers to actions and/or improvements in performance that demonstrate, or serve as credible proxies for, positive change towards fulfilling commitments.                                                                                                                                                                                                                                                                                                                           |
| Project finance                     | Asset class that includes loan or equity with known use of proceeds that is designated for a clearly defined activity or set of activities, such as the construction of a gas-fired power plant, a wind or solar project, or energy efficiency projects.                                                                                                                                                                                                                                                                                                                                          |
| REDD and REDD+                      | Countries established the REDD+ framework to protect forests as part of the Paris Agreement. 'REDD' stands for Reducing Emissions from Deforestation and forest Degradation in developing countries. The '+' stands for additional forest-related activities that protect the climate, namely sustainable management of forests and the conservation and enhancement of forest carbon stocks. Under the framework with these REDD+ activities, developing countries can receive results-based payments for emission reductions when they reduce deforestation.                                    |
| Residual emissions                  | Residual emissions represent the emissions that cannot be completely eliminated despite implementing all available mitigation measures contemplated in pathways that limit warming to 1.5°C with no or limited overshoot. In the context of science-based targets, residual emissions refer to the company's scope 1, scope 2, and scope 3 emissions that remain once its long-term emissions reduction target has been achieved.                                                                                                                                                                 |
| Science-based carbon price          | A carbon price represents the economic value of GHGemissions. The SBTi considers science-based carbon prices to be those which are based on: (a) robust scientific assessment of the external cost of GHGemissions (the costs of emissions that the public pays for, such as damage to crops, health care costs from heat waves and droughts, and loss of property from flooding and sea level rise); (b) robust scientific assessment of the expected costs associated with achieving a 1.5°C pathway; and/or (c) the true and complete cost to fully and permanently abate a given GHGemission. |
| Science-based target                | Corporate targets to mitigate GHGemissions that are in line with what the latest climate science says is necessary to meet the goals of the Paris Agreement - to pursue efforts to limit warming to 1.5°C.                                                                                                                                                                                                                                                                                                                                                                                        |

| TERM                                      | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
|-------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Scope 3 categories                        | 15 distinct categories as defined by the GHGProtocol intended to provide companies with a systematic framework to organize, understand, and report on the diversity of scope 3 activities within a corporate value chain                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Sink (of GHGemissions)                    | Any biological or technological process, activity or mechanism that removes greenhouse gases from the atmosphere. 116                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Small and medium-sized enterprises (SMEs) | Businesses that maintain revenues, assets, or a number of employees below a certain threshold. The SBTi considers SMEstobecompanies that meet all of the following criteria: 1. Have less than 10,000 tCO2e across scope 1 and location-based scope 2. 2. Are not classified in the financial institution (FI) sector and oil and gas (O&G) sector. 3. Are not required to set targets using sector-specific criteria (such as the SDA) developed by the SBTi (see the SBTi's sector guidance documents for requirements). 4. Are not a subsidiary of a parent company whose combined businesses fall into the standard validation route. And that meet two or more of the following: 1. Employ <250 employees 2. Turnover of < EUR 50 million 3. Total assets of <EUR 25 million 4. Are not in a mandatory FLAG sector Please note that the SME definition has been effective from 1 January 2024. Before then, the SBTi defined SMEs as companies with fewer than 500 employees. |
| Social cost of carbon (SCC)               | The SCC is estimated as the net present value of climate change impacts over the next 100 years (or longer) of one additional metric ton of carbon emitted to the atmosphere today. It is the marginal global damage costs of carbon emissions. 117                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Standard                                  | Document that provides a set of criteria and/or guidelines established by an authority, organization, or consensus, to ensure uniformity, consistency, and interoperability in a particular context.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Supply chain                              | A supply chain is the entire system of processes and resources required to produce and sell a product from start to finish, typically starting with raw materials and ending with the customer in possession of the product.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |

| TERM                                                                                 | DEFINITION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|--------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Target-consistent approach to carbon pricing/ marginal abatement cost (MAC) approach | The target-consistent approach to carbon pricing determines the most cost-effective way to reach an agreed upon goal, such as a temperature limit for global warming. The costs associated with abating greenhouse gas emissions are used to inform the calculation of a time path of carbon prices that reflects the least-cost pathway to meeting these goals. 118                                                                                                                                                                                                                                           |
| Target period                                                                        | The time frame between the base year and target year.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Ton-for-ton method                                                                   | This is a method for determining the scale of a BVCM pledge. Using this method, a company would deliver mitigation beyond its value chain proportional to the climate impact of some percentage of the GHGs emissions of that company in a defined period (e.g., in a given year or since a reference year). The volume of finance deployed towards BVCM would be determined by the price that a company pays per tCO2e of BVCM (in the case of carbon credits, this would be determined by market prices) and the percentage of unabated emissions that are being 'matched' with BVCM in that defined period. |
| Transition plan                                                                      | A time-bound action plan that outlines how an organization will pivot its existing assets, operations and business model toward a trajectory aligned with established science-based targets. According to CDP, transition plans are considered credible if they support a strategy for climate transition, contain verifiable and quantifiable key performance indicators which are tracked regularly, are integrated into an organization's existing mainstream filings, and provide an accountability mechanism. 119                                                                                         |
| Value chain emissions                                                                | A company's scope 1, 2, and 3 emissions as defined by the GHGProtocol Corporate Accounting and Reporting Standard.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Vintage                                                                              | The year in which the carbon emission reduction or removal associated with a carbon credit took place. Because the verification process can take two to three years from project/program inception, projects/programs may generate credits for already-reduced emissions. In the context of scope 2 accounting, vintage reflects the date of energy generation from which the contractual instrument is derived. 120                                                                                                                                                                                           |
| Voluntary carbon market (VCM)                                                        | A marketplace that encompasses all transactions of carbon credits that are not purchased with the intention to surrender into an active regulated carbon market. It includes carbon credits purchased with the intent to resell or retire to meet certain environmental claims.                                                                                                                                                                                                                                                                                                                                |

## ANNEX A: BVCM AND NEUTRALIZATION OF RESIDUAL EMISSIONS

## ANNEX A: BVCM AND NEUTRALIZATION OF

## RESIDUAL EMISSIONS

The table below compares the key features of BVCM and neutralization of residual emissions.

Table 6: Comparing BVCM and neutralization

| BEYOND VALUE CHAIN MITIGATION                                                                                                                                                     | NEUTRALIZATION OF RESIDUAL EMISSIONS                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Definitions                                                                                                                                                                       | Definitions                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Mitigation action or investments that fall outside a company's value chain, including activities that avoid or reduce GHGemissions, or remove and store GHGs from the atmosphere. | Measures that companies take to counterbalance the climate impact of unabatable (i.e. residual) GHG emissions which are released into the atmosphere at and after net-zero target date through permanent removal and storage of CO2 from the atmosphere.                                                                                                                                                                                                          |
| Eligible mitigation outcomes                                                                                                                                                      | Eligible mitigation outcomes                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| BVCM includes both GHGemissions reductions and carbon removals.                                                                                                                   | Neutralization is limited to the removal of carbon from the atmosphere and storage with a permanence that is commensurate with the impact of the GHG released into the atmosphere, considering, amongst others, its radiative forcing and residence time. The SBTi will provide further guidance on eligible solutions/technologies and associated guardrails to ensure the permanence of neutralization in future iterations of the Corporate Net-Zero Standard. |

| BEYOND VALUE CHAIN MITIGATION                                                                                                                                                                                                                                                                                                                                                                                                            | NEUTRALIZATION OF RESIDUAL EMISSIONS                                                                                                                                                                                                                                                                                                                              |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Purpose                                                                                                                                                                                                                                                                                                                                                                                                                                  | Purpose                                                                                                                                                                                                                                                                                                                                                           |
| BVCM allows companies to take responsibility for unabated emissions that continue to be released into the atmosphere as they progress towards the delivery of their near- and long-term targets and to accelerate the global net-zero transition by helping other economic and social actors to reduce and/or remove GHGemissions.                                                                                                       | Neutralization helps companies counterbalance the impact of emission sources that remain unabatable (i.e., residual emissions).                                                                                                                                                                                                                                   |
| Where and how are mitigation outcomes accounted for                                                                                                                                                                                                                                                                                                                                                                                      | Where and how are mitigation outcomes accounted for                                                                                                                                                                                                                                                                                                               |
| Mitigation outcomes would not be accounted for in the company's scope 1, 2 or 3 GHGinventory. One method for accounting for BVCM interventions is using intervention (or project) accounting methods which measure system-wide GHGimpacts relative to a counterfactual baseline scenario or performance benchmark that represent the conditions most likely to occur in the absence of the mitigation project that generates the credit. | The permanent removals to neutralize the impact of residual emissions can occur within or beyond the company's value chain. See the forthcoming Land Sector and Removals guidance from the GHG Protocol for further information on accounting for removals.                                                                                                       |
| Timing                                                                                                                                                                                                                                                                                                                                                                                                                                   | Timing                                                                                                                                                                                                                                                                                                                                                            |
| Once a company has set a net-zero target, it is encouraged to take immediate and consistent action to deliver BVCMeach year as it transitions to net-zero.                                                                                                                                                                                                                                                                               | Neutralization of residual emissions is required to counterbalance any potential residual and unabatable emission source once emissions have been reduced to an emissions level consistent with limiting warming to 1.5°C.                                                                                                                                        |
| SBTi Corporate Net-Zero Standard recommendations and requirements                                                                                                                                                                                                                                                                                                                                                                        | SBTi Corporate Net-Zero Standard recommendations and requirements                                                                                                                                                                                                                                                                                                 |
| Companies are recommended , but not required, to deliver BVCM. Companies are recommended to report annually on the nature and scale of their BVCM activities and investments.                                                                                                                                                                                                                                                            | Companies are required to remove carbon from the atmosphere and permanently store it once the long-term science-based target has been achieved and thereafter. Companies are recommended to disclose information such as planned milestones and near-term investments that demonstrate the integrity of commitments to neutralize unabated emissions at net-zero. |

## ANNEX B: ILLUSTRATIVE EXAMPLES OF BVCM

## ANNEX B:

## ILLUSTRATIVE EXAMPLES OF BVCM

This annex provides supplementary information to support companies when considering how to operationalize the BVCM Goals and Principles set out within this document. In doing so, it provides illustrative and non-exhaustive examples of mitigation activities that companies could consider when designing a BVCM portfolio of activities and investments.

As discussed within this document, the SBTi highlights the importance of delivering near-term mitigation outcomes as well as providing funding for innovation and enabling activities to scale climate solutions in the longer-term. The document does not specify how these different Goals or Principles should be weighted by companies as all elements are fundamental in addressing the climate crisis.

## BVCM Goals

<!-- image -->

<!-- image -->

Deliver additional near-term mitigation outcomes to achieve the peaking of global emissions in the mid-2020s and the halving of global emissions by 2030.

Drive additional finance into the scale-up of nascent climate solutions and enabling activities to unlock the systemic transformation needed to achieve net-zero by mid-century globally.

<!-- image -->

## SCALE: MAXIMIZE MITIGATION OUTCOMES

## Where are there opportunities to fund activities that deliver the maximum verifiable near-term mitigation impact given the financial resources available?

Given the need to cut emissions rapidly and significantly, the mitigation potential of a funding activity (the tCO2e per unit of finance deployed) is an important factor in prioritizing BVCM activities and investments as it will maximize mitigation outcomes. Activities which are scalable today and with lower abatement costs include reduced conversion of forests and other ecosystems and energy efficiency. 121

Purchasing and retiring high-quality, verified carbon credits is one way to ensure that mitigation outcomes have occurred. There are initiatives such as the Carbon Credit Quality Initiative (CCQI) which provide transparent information on the quality of carbon credits - it is recommended that companies use tools such as the CCQI to identify carbon credits which are most likely to deliver real emissions reductions and enhanced removals. Companies are encouraged to pay a fair price for carbon credits that takes into account the full costs of a mitigation project or program, including the opportunity cost of land conversion where relevant.

## Where are there opportunities to fund activities that prevent ecological and climate tipping points?

Analysis published in 2022 points to a set of 16 tipping points where past a certain temperature threshold there is unstoppable and self-perpetuating change in a climate system - change which would take effect on timescales varying from a few years to centuries. 123  Maximizing the tCO2e of mitigation delivered will therefore be important in preventing climate tipping points linked to temperature thresholds.

Tipping points are also triggered through localized feedbacks in certain ecosystems. For example, deforestation and forest degradation reduce evapotranspiration which reduces rainfall and further drives forest degradation. Similarly, local fires can intensify drought and drive forest loss which can trigger 'mega fires.' 124

Conversion and degradation of natural ecosystems not only releases carbon into the atmosphere, but it also reduces the future sequestration potential of nature. Between 2012 and 2021, the land CO2 sinks took up around 30% of the CO2 emitted to the atmosphere (11.4 GtCO2). 125  High integrity tropical forests are the most important land sink and are estimated to remove and store around 3.6 GtCO2 per year (net) from the atmosphere. 126  However, due to deforestation and degradation, the sink function is increasingly under threat.

As such, funding to protect and restore natural ecosystems - in particular tropical forests - is critical in maintaining the land sink and avoiding tipping points. The SBTi Forest, Land and Agriculture (FLAG) sector methods incentivize forest, agriculture and land companies to fund the prevention of further deforestation and

conversion within their value chains, but it is also critical that FLAG companies and companies from non-FLAG sectors support the protection and restoration of natural ecosystems through BVCM. This includes funding activities such as:

- Activities that improve land management and/or address drivers of deforestation and degradation in explicit support of landscape and jurisdictional strategies and where mitigation impacts are monitored (e.g., land tenure security, responsible production practices, forest restoration, design and planning phases in support of landscape and jurisdictional activities);
- Payment for ecosystem services (PES) projects/programs that work to protect natural ecosystems;
- Purchasing and retiring high-quality, verified jurisdictional and/or nested REDD+ carbon credits;
- Activities that protect the sink function of intact forests and other natural ecosystems;
- Demand-side measures that reduce land use such as activities which support a shift towards healthy and more sustainable diets and reducing food loss and waste.

## Where are there opportunities to finance mitigation activities that avoid high-carbon technology or infrastructure lock-in?

Committed existing infrastructure (coal-fired power plants, pipelines, gas-powered vehicles, etc.) will cumulatively emit about 658 GtCO2 if operated as it has been historically, using up the remaining carbon budget. More than half of these emissions would come from the electricity sector. Infrastructure in China, the United States and the 27 member states of the European Union represent approximately 41%, 9% and 7% of the total, respectively. 127 This indicates that little or no new CO2-emitting infrastructure can be commissioned, and that existing infrastructure may need to be retired early (or be retrofitted with carbon capture and storage technology). The most cost-effective premature infrastructure retirements will be in the electricity and industry sectors, where nonemitting alternatives are available and affordable. 128

Companies should therefore consider supporting the development and scaling of low carbon energy generation technologies where they are additional (i.e., where it is not already cost competitive) in a manner tied to the accelerated phase out of coal and other fossil fuels linked to the electricity and industry sectors.

## Where are there opportunities to finance mitigation activities that have the potential to have cascading positive impacts and deliver long-term systemic change?

According to the International Energy Agency (IEA), without a major acceleration in clean energy innovation, reaching net-zero emissions by 2050 will not be achievable. Technologies that are available on the market today provide nearly all the emissions reductions required to 2030 in the IEA's Net Zero Emissions by 2050 Scenario (NZE). However, reaching net-zero emissions in 2050 will require widespread use after 2030 of technologies that are still under development today. By 2050, it is expected that almost 50% of emissions reductions will come from technologies currently at demonstration or prototype stage and which need to rapidly scale. 129

There is therefore the need for the private sector to provide finance beyond their value chains to support the development of emerging climate technology. 130

The novel carbon dioxide removals (CDR) industry also needs to grow by four to six orders of magnitude by midcentury to meet the Paris temperature goals; as such, funding for CDR innovation and R&amp;D is needed now to achieve the necessary scale. 131

Companies should also consider where they can contribute to market tipping points that shift market dynamics in favor of low-carbon solutions. As an illustrative example, the University of Exeter and Systemiq argue that the development of large-scale green hydrogen production will enable the decarbonization of several industrial and long-distance transport sectors and thus has significant potential to contribute to market tipping points. They also argue that investment into alternative proteins has systemic potential since it can reduce pressure for land use change as well as emissions from livestock farming. 132

Companies and financial institutions can deploy finance directly or through funds such as the Breakthrough Energy Catalyst which funds and invests in projects and companies developing and utilizing emerging climate technologies that reduce emissions, working to accelerate the adoption of these technologies worldwide and reduce their green premiums. 133

## Where are there opportunities to fund activities at the jurisdictional or landscape level?

Funding into jurisdictional, national and sub-national scale mitigation programs can also drive systemic change by providing incentives for policymakers to implement policies in support of the net-zero transition. Examples include jurisdictional REDD+ and jurisdictional fossil fuel phase-out.

The private sector also has a role in accelerating progressive net-zero and just transition aligned public policymaking. It is highly challenging if not impossible to quantify the impact of this category of action in terms of mitigation outcomes but it is a critical activity nonetheless.

The Race to Zero campaign which seeks to build momentum around the shift to a decarbonized economy includes a starting line criteria which requires signatories to, within 12 months of joining the campaign, align external policy and engagement, including membership in associations, to the goal of halving emissions by 2030 and reaching global netzero by 2050. The Race to Zero also defines leadership practices on this front, whereby signatories should proactively advocate for governments to align their goals and actions to 1.5°C and advocate for appropriate regulation and facilitating measures to ensure that alignment to 1.5°C becomes the default for all actors.

The Global Standard on Responsible Corporate Climate Lobbying is an example of a useful resource as it helps companies and investors to assess and ensure that all lobbying efforts are directed towards the attainment of the Paris Goals. 134

<!-- image -->

<!-- image -->

## FINANCING NEED: FOCUS ON UNDERFINANCED MITIGATION

Where are there opportunities to fund mitigation activities that need private sector finance to support delivery (and potentially enhancement) of Nationally Determined Contributions (NDCs) to the Paris Agreement?

Companies can engage with host country governments, development partners, and local civil society to understand where private sector finance is needed to support and go beyond the delivery of country NDC goals and targets. In addition, there may be opportunities for blended finance mechanisms to de-risk private investment into climate mitigation in lower income countries.

Where are there opportunities to finance mitigation activities that are underfinanced and in need of concessional or debt-free finance due to limited return on investment (ROI), longer payback periods or higher investment risk?

There are different funding needs across mitigation options, with different risk and return profiles. Companies should channel funds where it is 'financially additional' - for example, into capital-constrained markets in which project developers or governments are unable to obtain commercial financing for climate mitigation due to high risk or limited ROI. Mitigation areas in need of concessional or debt-free finance and which could be considered as part of companies' BVCM programs include early phase-out of coal, forest restoration and conservation of natural ecosystems. 135

When companies are implementing BVCM in support of the goal of delivering near-term mitigation, the SBTi proposes mitigation outcomes are verified and generated in respect of or representing mitigation from 2021 onward. In the case of carbon credits, newer credits (those that have a newer vintage) should be valued more highly than older credits. It is easier to determine that newer credits are financially additional because credits from older vintages may represent GHG emission reductions or removals from activities that no longer need finance incentives from the voluntary carbon market. 136

<!-- image -->

<!-- image -->

## CO-BENEFITS: SUPPORTING THE SDGS

## Where are there opportunities to fund mitigation activities which deliver co-benefits such as adaptation, resilience, livelihoods, water security, biodiversity?

Companies should look to channel funds and resources towards mitigation activities which also support the delivery of the wider SDGs. Nature-based solutions - actions that protect, sustainably manage, and restore natural and modified ecosystems to address societal challenges effectively and adaptively, and that simultaneously provide human wellbeing and biodiversity benefits - have significant co-benefits when well designed and carefully implemented by and for local communities and are therefore considered priority mitigation activities. 137,138

## Examples of nature-based solutions include:

- Activities such as forest management to reduce the risk of intense wildfires.
- Restoration of wetlands to absorb and filter flood waters.
- Agroforestry to make better use of soil moisture and reduce evaporation, expansion of green spaces in and around cities.
- Protection and restoration of mangroves, marshes and reefs to buffer coasts and absorb floodwaters. 139

<!-- image -->

<!-- image -->

## CLIMATE JUSTICE: ADDRESSING INEQUALITY

## Where are there opportunities to fund mitigation activities in countries with comparatively low per capita emissions that are exposed to greater temperature variability?

Companies should consider funding climate mitigation in lower income countries that are least responsible and yet most vulnerable to climate change. Low-income countries will see themselves exposed to more volatile temperatures and more frequent temperature anomalies with potentially devastating effects on agricultural output, while regions with the highest responsibility for climate change may experience reduced temperature volatility. 140

## Where are there opportunities to finance mitigation activities that support disadvantaged and marginalized groups most impacted by climate change?

An equity focused approach also addresses inequalities between different social groups. Climate change has a greater impact on low-income and disadvantaged groups that have fewer resources and less access to opportunities. Disadvantaged and marginalized groups vary across contexts but typically include economically disadvantaged people, women, children, youth and elderly people, members of ethnic and religious minorities, Indigenous Peoples, people with health problems and/or disabilities, migrants and displaced people, and rural populations. 141 Companies should therefore consider the distribution of the costs and benefits of climate change and the need to engage disadvantaged social groups in decision-making when developing and deploying a portfolio of BVCM activities.

Companies should also look to support equitable and transparent benefit sharing. In the context of carbon markets, benefit sharing is the allocation of the proceeds from carbon credits to local stakeholders involved in a carbon credit project or program. Benefit sharing rewards local actors for past contributions to climate mitigation and incentivizes future contributions of local stakeholders to mitigation activities. 142

<!-- image -->

## Where are there opportunities to support and ensure the leadership and ownership efforts of Indigenous Peoples and local communities?

Securing the human rights as well as the land and resource rights of Indigenous Peoples and local communities is also critical. In the context of growing pressures from outside groups seeking to farm, log, mine, drill for oil and gas, etc., on Indigenous and community lands and the threats these pressures pose to traditional norms, institutions, and knowledge, it is more important than ever to secure customary rights and strengthen traditional institutions. Integrated approaches are needed - focusing not only on tenure security, but also on complementary regulatory frameworks and financial, technical, and legal assistance to support local forest management systems and advance sustainable livelihood alternatives. Companies should therefore look to support and ensure the leadership and ownership efforts of Indigenous Peoples and local communities who are protecting their traditional and customary lands.

## Where are there opportunities to support the just transition to net-zero?

The IPCC states that 'climate finance in support of a just transition is likely to be a key to a successful low-carbon transition globally.' 143 The International Labour Organisation defines a just transition as 'greening the economy in a way that is as fair and inclusive as possible to everyone concerned, creating decent work opportunities and leaving no one behind.' 144  A just transition incorporates key principles, such as respect and dignity for vulnerable groups, the creation of decent jobs, social protection, employment rights, fairness in energy access and use, and social dialogue and democratic consultation with the relevant stakeholders, while coping with the effects of assetstranding and the transition to net-zero. 145

While companies should support a just transition through their own policies and strategies (e.g., by ensuring dialogue and participation of impacted groups in their climate transition planning processes) and through advocating for public policy that incorporates the just transition, they can also provide financial support for a just transition beyond the value chain.

Companies can deploy funding towards activities that maximize job creation for marginalized communities or in low-income countries, provide financial support to farmers - in particular smallholders - to improve the sustainability of agricultural practices and support the retraining of workers across sectors affected by the transition to netzero, including the energy sector.

For example, the Just Energy Transition Partnerships (JETPs) incorporate blended finance mechanisms where public finance from governments is used to leverage and attract private sector finance in support of just power sector decarbonization strategies.

<!-- image -->

## ANNEX C: WIDER CATEGORIES OF CLIMATE ACTION

## ANNEX C: WIDER CATEGORIES OF CLIMATE ACTION

BVCM is defined as mitigation action or investments that fall outside a company's value chain, including activities that avoid or reduce GHG emissions, or remove and store GHGs from the atmosphere. 146 The BVCM Goals defined by the SBTi place focus on both near-term mitigation as well as scaling finance to innovate novel climate solutions and enabling activities needed to reach net-zero. However, climate mitigation is just one aspect in addressing the climate crisis - adaptation and loss and damage are considered to be the other two pillars of climate action. These wider set of activities which are in need of finance are discussed below.

## CLIMATE CHANGE ADAPTATION

Climate change adaptation refers to changes in processes, practices, and structures to moderate potential damages or to benefit from opportunities associated with climate change. 147

Estimated annual adaptation financing needs are USD 160-340 billion by 2030 and USD 315-565 billion by 2050. 148 While adaptation finance increased by 28% in 2021/2022 compared to the previous year, reaching USD 63 billion, there remains a significant adaptation finance gap. 149

There is an increasing recognition of the importance of stimulating private sector funding for adaptation to supplement constrained public sector funding. 150,151  While hard to measure, the private sector currently contributes a small percentage of overall adaptation finance. 152

Companies can invest into adaptation by climate-proofing their internal operations and supply chains to address climate risks, or providing finance, goods or services for others to implement or facilitate adaptation and resilience building programs within or beyond the value chain.

<!-- image -->

## ADDRESSING CLIMATE CHANGE LOSS AND DAMAGE

While there is no internationally agreed upon definition for loss and damage, it usually refers to the negative effects of climate change that go beyond what people can adapt to ('hard limits' to adaptation), or where adaptation options exist but a community doesn't have the resources to access or utilize them ('soft limits' to adaptation). 153,154

Economic losses and damages are those affecting resources, trade and labor, for example as a result of damage to critical infrastructure and property or supply chain disruptions. 155 Non-economic losses are those which are harder to quantify and monetize but often have severe impacts on communities' well-being, for example due to the loss of life, forced migration and losses to biodiversity and cultural heritage. 156

Addressing loss and damage thus refers to activities or funds to help people after they have experienced climaterelated impacts. This is often considered the 'third pillar of climate action', alongside mitigation and adaptation. 157

It is important to note the distinction and overlap between humanitarian assistance and addressing loss and damage. The former occurs primarily in reaction to an event, while the latter can also include proactive anticipatory measures such as contingency funds and insurance. 158

Loss and damage became a headline issue within the United Nations Framework Convention on Climate Change (UNFCCC) in 2022 where COP27 Parties agreed to establish a dedicated loss and damage fund. 159  At COP28, Parties agreed that the United Nations (UN) Office for Disaster Risk Reduction and the UN Office for Project Services will host the secretariat of the Santiago Network for Loss and Damage, a platform to catalyze technical assistance to developing countries that are particularly vulnerable to the adverse effects of climate change. 160

ANNEX D: METHODS FOR DETERMINING THE NATURE AND SCALE OF A BVCM PLEDGE

## ANNEX D: METHODS FOR DETERMINING THE

## NATURE AND SCALE OF A BVCM PLEDGE

Step 2.3 Step 2.3 of the four-step process set out in this document describes a best practice approach for determining the scale of a BVCM pledge. This annex provides additional information on methods which companies can use to determine the scale of a BVCM pledge, including how they could be adapted to take into account ability or willingness to pay.

<!-- image -->

## TON-FOR-TON: LINKING BVCM TO UNABATED VALUE CHAIN EMISSIONS

Using this method, a company would deliver mitigation beyond its value chain proportional to the climate impact of some percentage of the GHGs emissions of that company in a defined period (e.g., in a given year or since a reference year).

The volume of finance deployed towards BVCM would be determined by the price that a company pays per tCO2e of BVCM (in the case of carbon credits, this would be determined by market prices) and the percentage of unabated emissions that are being 'matched' with BVCM in that defined period.

The best practice application of this method would be delivering verified mitigation outside the value chain proportional to the climate impact of at least 100% of scopes 1, 2 and 3 emissions that year. Inclusion of historic emissions might also be considered best practice for some sectors, but there is acknowledgement that for some this would be extremely challenging given the magnitude of lifetime emissions.

The best practice adoption of this method will also be impacted by the claim that a company intends to make. For example, if a company's claim seeks to convey that the BVCM outcomes are counterbalancing its remaining emissions, then higher standards are required in terms of permanence, additionality, avoidance of double claiming, avoidance of leakage and potentially also fungibility for that claim to remain accurate. Alternatively, if the claim is communicated as a contribution to global climate mitigation efforts, reputational risk to the claimant is lessened since it is not necessary to demonstrate that the positive environmental impact of the BVCM outcome is

equivalent to or greater than the negative impact of the company's unabated emissions. For contribution claims, companies should still take measures to ensure that BVCM outcomes are delivered (e.g., through third-party verification) and companies should report transparently on environmental quality attributes.

The application of this method could also be adjusted based on 'willingness' or 'ability' to pay. For willingness to pay, a company could simply choose the amount of mitigation they intend to deliver, for example delivering BVCM to match 50% of unabated scopes 1 and 2 and 10% of scope 3 emissions. For ability to pay, there could be a weighting applied to the company's responsibility based, for example, on its profitability per unabated tCO2e of value chain emissions.

<!-- image -->

## Benefits of this method include:

- The commitment is framed based on mitigation (measured in tCO2e) delivered and therefore it ensures mitigation occurs and places an emphasis on near-term action.
- There is a clear tCO2e metric for impact measurement and verification.
- Since it is tied to unabated emissions, it creates a de facto internal carbon price which incentivizes value chain emission reductions.
- Some argue that it incentivizes mitigation at least cost to society as companies can resort to the least-cost mitigation option to deliver their commitment.

## Potential drawbacks of this method include:

- It may result in more limited deployment of finance as companies can resort to the least-cost option to deliver their commitment under this method.
- Linked to the above, there is a risk that companies optimize the price of mitigation outcomes at the expense of quality.
- There is no link between funding volume and the GHG externality linked to unabated emissions since the price paid for a mitigation outcome is typically determined by supply and demand.
- There is increasing backlash associated with compensatory claims that seek to convey that the tCO2e of unabated value chain emissions are netted out or counterbalanced by the tCO2e of BVCM (resulting in regulatory risk, litigation risk and reputational risk).
- There is increasing backlash associated with claims that mislead consumers about the climate impact of products or services (resulting in regulatory risk, litigation risk and reputational risk).

<!-- image -->

<!-- image -->

## MONEY-FOR-TON: APPLYING A CARBON PRICE TO UNABATED VALUE CHAIN EMISSIONS

Using this method, a company would channel finance into BVCM based on a predefined reference price of the unabated GHG emissions of that company in a defined period (e.g., in a given year or since the inception of the company).

The volume of finance deployed towards BVCM would be determined by the chosen cost of carbon (e.g., a social cost of carbon or otherwise) and the unabated emissions in that defined period.

Best practice application of this method would entail use of a science-based carbon price (see Annex E) and applying this to 100% of unabated scopes 1, 2 and 3 emissions in that year. The carbon price should be aligned with credible academic sources and the company should report transparently on the cost of carbon used and the method for determining it. Inclusion of historic emissions might also be considered best practice for some sectors as above.

Given this method determines a financial budget, as opposed to a targeted level of mitigation outcomes, the company can channel some portion of finance to mitigation with uncertain or unquantifiable mitigation outcomes, for example to ensure that finance supports R&amp;D into emerging climate technologies and the creation of an enabling environment for mitigation to occur.

Where the social cost of carbon is used, it would follow that the company could allocate some portion of this finance into adaptation, loss and damage since this pricing mechanism represents the damage caused by unabated emissions.

The application of this method could also be adjusted based on 'willingness' or 'ability' to pay. For willingness to pay, a company could choose a defined fixed carbon price of e.g., USD 10/tCO2e. For ability to pay, there could be a weighting applied to the company's responsibility, e.g., based on the company's profitability per unabated tCO2e of value chain emissions.

<!-- image -->

## Benefits of this method include:

- Where a science-based carbon price is used, it can increase the amount of finance mobilized from private sector entities participating in BVCM.
- Since the method determines a financial budget as opposed to a targeted level of mitigation outcomes, it may increase funding for higher cost mitigation options or investments with uncertain or unquantifiable outcomes (e.g., technical risk phase of R&amp;D, landscape readiness and implementation activities).
- Since it is tied to unabated emissions, it creates a de facto internal carbon price which incentivizes value chain emission reductions.
- Where a science-based carbon price is used, notably the social cost of carbon, it is consistent with the polluter pays principle in that there is a link between the volume of finance and the externality linked to unabated emissions.
- Claims are less likely to imply the fungibility of unabated value chains and BVCM, thereby reducing risk of greenwash.

<!-- image -->

<!-- image -->

## Potential drawbacks of this method include:

- Since the method determines a financial budget as opposed to a targeted level of mitigation outcomes, it places less emphasis on guaranteed mitigation outcomes.
- Impact metrics are less well-established for financing targets.
- It is difficult to establish the 'right' price of carbon (see Annex E).
- If the chosen price of carbon is too low, it may not generate sufficient finance or mitigation to address the externality associated with unabated emissions.
- Claims are less well-established.

<!-- image -->

## MONEY-FOR-MONEY: LINKING BVCM TO A PORTION OF REVENUE OR PROFIT

Using this method, a company would allocate a share of revenue or profit towards funding climate mitigation beyond the value chain. The volume of finance deployed towards BVCM would be determined by the chosen denominator (e.g., profit or revenue) and the chosen percentage.

This method determines a financial budget, as opposed to a targeted level of mitigation outcomes, and therefore the company can channel some portion of finance to mitigation with uncertain or unquantifiable mitigation outcomes, for example to ensure that finance supports R&amp;D into emerging climate technologies and the creation of an enabling environment for mitigation to occur.

<!-- image -->

## Benefits of this method include:

- Since the method determines a financial budget as opposed to a targeted level of mitigation outcomes, it may increase funding for higher cost mitigation options or investments with uncertain or unquantifiable outcomes (e.g., technical risk phase of R&amp;D, landscape readiness and implementation activities).
- It lends itself to a potentially attractive consumer-facing claim which is easy to communicate.

## Potential drawbacks of this method include:

- Since the method determines a financial budget as opposed to a targeted level of mitigation outcomes, it places less emphasis on guaranteed mitigation outcomes.
- It is difficult to establish a scientific basis for determining a best practice application in terms of the share of the chosen financial metric to be channeled into BVCM.
- Impact metrics are less well-established for financing targets.
- Claims are less well-established.
- If the chosen share of profit (or other metric) is too low, it may not generate sufficient finance or mitigation to address the externality linked to unabated emissions.
- It does not incentivize value chain abatement as it is not linked to the company's unabated value chain emissions.

## ANNEX E: CARBON PRICING

A

b

## ANNEX E:

## CARBON PRICING

## VOLUNTARY CORPORATE ADOPTION OF CARBON

Companies are voluntarily implementing carbon pricing in a number of ways, including: 161

- Shadow carbon pricing : Where a company applies a theoretical internal cost of carbon in a project planning process to test the feasibility of capital expenditure and R&amp;D investment decisions. The objective is to enable screening of potential business risks associated with future GHG regulation and to support business cases to shift investments to low-carbon options. 1
- Implicit carbon pricing : Which helps companies to quantify the capital investments required to meet climate-related targets. Some companies with emissions reduction targets calculate their implicit carbon price by dividing the cost of abatement by the tCO2e abated. 2
- Internal carbon fee : Where a company deploys funds to climate action based on applying an internal carbon price to its unabated emissions. 3
- Internal trading : Where business units within a company price their unabated emissions and internally trade their allocated carbon credits based on respective emissions. 4

CDP's 2021 Carbon Pricing report showed that nearly half (226) of the world's 500 biggest companies were at that time putting a price on carbon or planning to do so within the next two years. More than one third of companies that responded to CDP's internal carbon pricing questions in 2020 are either currently or planning to use an internal price on carbon (1,159 companies). The median internal carbon price disclosed to CDP by companies in 2020 was USD 25/ tCO2e. While many companies use multiple types of carbon pricing depending on their needs, shadow pricing was most often used with over five in ten companies implementing this pricing type. 162

<!-- image -->

## TYPES OF CARBON PRICES

There are a number of different methods for determining a carbon price, with differing purposes and different methodological approaches. The section below provides an overview of the methods, benefits, and downsides of different types of carbon pricing.

- The social cost of carbon (SCC) or marginal damage approach
- The marginal abatement cost (MAC) or target-consistent approach
- Policy-driven carbon pricing (carbon taxes and emissions trading schemes)
- Carbon pricing based on project cost
- Carbon pricing based on market dynamics
- Industry carbon price benchmarks

## Social cost of carbon (SCC) or marginal damages approach

The SCC is estimated as the net present value of climate change impacts over the next 100 years (or longer) of one additional metric ton of carbon emitted to the atmosphere today. It is the marginal global damage costs of carbon emissions. 163 As such, the SCC can be used to value the economic benefit that results from reducing 1 tCO2e. 164

The available quantitative estimates of the social cost of carbon emissions adopt models of varying degrees of sophistication. The essential linkages in all models are from emissions to atmospheric concentration, from concentrations to temperature change, and from temperature change to damage. 165  There is a wide variation in estimates of the social cost of carbon since there are various methodological choices and assumptions that impact the resulting financial value such as the discount rate; the equity weighting (weighting impacts of different regions as some regions may experience greater damages due to climate change); the time horizon chosen; the climate model used and the approach to valuing damages and impacts on economic growth. Meta-analysis from Wang et al. (2019) finds that recent SCC estimates range from under USD 0/tCO2e to over USD 8,000 tCO2e. 166  This variation is also highlighted in Table 7 below.

According to the High-Level Commission on Carbon Prices and the IPCC, many of the impact functions used in modeling exercises to calculate the social costs of carbon are biased downward because they fail to consider important risks and costs associated with climate change, such as biodiversity loss, long-term impacts on labor productivity and economic growth, impacts on the poorest and most vulnerable, rising political instability and the spread of violent conflicts, ocean acidification, large migration movements, as well as the possibility of extreme and irreversible changes. 167 Dietz et al. warn that consideration of climate tipping points increases the social cost of carbon by ~25%; and there is a ~10% chance that they could more than double the social cost of carbon. 168

Integrated Assessment Models (IAMs) used to calculate the SCC also do not consider the global cost of reaching any particular temperature or emissions target. As such, inadequate treatment of risk and uncertainty and/or an excessively high discount rate can mean that the social cost of carbon could be insufficient to deliver the climate targets set in the Paris Agreement.

Equity concerns have also been raised between current and future generations, and between rich and poor. The social cost of carbon tends to favor the needs of the present generation over those of future generations, since future damages are often heavily discounted due to the inherent uncertainty. However, equity can be accounted for by adjusting the discount rate: a lower rate places a higher value on future damages, meaning that the impact on future generation is weighted more fairly. 169

## Table 7: Comparing non-exhaustive sources of the SCC to highlight the range in prices depending on methods

| SOURCE OF SCC                                | USD/ TCO2E   | NOTES                                                                |
|----------------------------------------------|--------------|----------------------------------------------------------------------|
| Stern, 2006 170                              | 85           | 0.1% discount date                                                   |
| Ackerman and Stanton, 2012 171               | 900          | SCC in 2010, 1.5% discount date                                      |
| Obama Administration, 2013 172               | 43           | 2007 USD, 3% discount date                                           |
| Nordhaus, 2014 173                           | 18.6         | 2005 US prices, SCC grows at 3% per year to 2050, 4.5% discount rate |
| Moore and Diaz, 2015 174                     |              | Considers tipping points                                             |
| Cai, Lenton and Lontzek, 2016 175            | 220          | Considers tipping points                                             |
| Umweltbundesamt (UBA), 2023 176              | EUR 228      | 2020, 1% discount rate                                               |
| Umweltbundesamt (UBA), 2023 176              | EUR 237      | 2022, 1% discount rate                                               |
| Umweltbundesamt (UBA), 2023 176              | EUR 241      | 2030, 1% discount rate                                               |
| Umweltbundesamt (UBA), 2023 176              | EUR 286      | 2050, 1% discount rate                                               |
| Biden Administration, 2021 177               | 3-5          | 2020 USD, 3% discount date                                           |
| US Environmental Protection Agency, 2022 178 | 51           | 2020 USD, 2.5% discount rate                                         |
| US Environmental Protection Agency, 2022 178 | 120          | 2020 USD, 2% discount rate                                           |
| US Environmental Protection Agency, 2022 178 | 190          | 2020 USD, 1.5% discount rate                                         |
| US Environmental Protection Agency, 2022 178 | 340          | 2020 USD, 2% discount date                                           |
| Rennert et al., 2022 179                     | 185          | 2020 USD, 2% discount date                                           |

## The marginal abatement cost (MAC) or target-consistent approach

The marginal abatement cost (MAC) approach, or target-consistent approach, provides monetary estimates for abating an additional metric ton of greenhouse gas emissions based on the cost and benefits for implementing the measure or technology used to abate such emission. 180

The MAC is usually presented on a curve, as a series of costs for various abatement options in ascending order, showing how the MAC increases for each additional unit of emission reduction. Each point on the MAC curve represents the ratio of the cost and emission reduction potential of individual technologies and actions. To generate these cost figures, experts consider factors such as the discount rate, the lifetime of the technology, investment and operating costs, and energy prices.

This method can compare the cost of achieving specific emission reductions within a certain sector considering the entire portfolio of available mitigation options. It is a valuable tool for setting an achievable emission reduction target, and calculating the costs associated with meeting it, both on an aggregate economic level and for specific sectors.

However, the MAC does not incorporate a variety of factors that will have an impact on whether the technologies can achieve their abatement potential. The MAC only presents the maximum abatement potential of a particular technology without fully considering institutional, techno-economic, social and/or other barriers. The MAC also does not consider wider social benefits of reducing carbon emissions or the costs of continued emissions. It is often based on 'expert' estimates that lack transparency on the underlying assumptions, and it is based on static numbers that cannot capture how dynamic decisions made over time will impact the estimates.

The calculation method depends on the model - sometimes carbon price assumptions are an input, other times they are endogenous. For example, the International Energy Agency Net Zero by 2050 Scenario uses carbon price assumptions as an input into the Global Energy and Climate Model. 181  In contrast, in the Network for Greening the Financial System (NGFS) scenarios, which are based on three IAMs, the carbon price is an endogenous variable in that it is determined based on what is required for the technologies needed to stay within the carbon budget to be in a viable state. 182

As with the SCC, target-consistent carbon prices are dependent on the assumptions and inputs of the model underpinning the scenario and thus will vary across models and can be prone to bias of the model group. Quality of the inputs into the model equates to quality of the outputs. Moreover, process-based IAMs like those used in the NGFS scenarios and the IPCC scenarios often rely on carbon price as the main transition policy lever which means that the impact of other policy tools (price-based vs environmental regulation) are not fully captured. 183

The High-Level Commission on Carbon Prices concluded in 2017 that carbon prices needed to be at the level of USD 40/metric tons of carbon dioxide (tCO2) to USD 80/tCO2 in 2020 and reach USD 50/tCO2 to 100/tCO2 by 2030 to be on track to keep temperatures below 2°C. Adjusted for inflation, prices would need to reach USD 61 to USD 122 by 2030 in 2023 USD. 184

More recently, Kaufman et al. (2022) defined a 'near-term to net-zero (NT2NZ) approach' which is a form of targetconsistent carbon pricing. The NT2NZ estimates the CO2 prices needed in the near term for consistency with a netzero CO2 emissions target. The illustrative NT2NZ CO2 prices for the United States for a 2050 net-zero CO2 emission target are estimated at USD 34 to USD 64/tCO2e in 2025 and USD 77 to USD 124/tCO2e in 2030. The authors argue that this approach avoids uncertainties in estimates of climate damages inherent in estimates of the SCC as well as uncertainties in long-term decarbonization costs and highlight that the estimates are most influenced by assumptions about complementary policies and oil prices. 185

## Table 8: Comparing non-exhaustive sources of the target-consistent approachprices depending on methods

| SOURCE OF TARGET- CONSISTENT APPROACH   | °C    |   PERIOD OF PRICE | USD/ TCO2E   | NOTES                  |
|-----------------------------------------|-------|-------------------|--------------|------------------------|
| HLCCP, 2017 186                         | 2°C   |              2020 | 40-80        |                        |
|                                         | 2°C   |              2030 | 61-122       | Adjusted for inflation |
| Kaufman et al., 2022 187                | 1.5°C |              2025 | 34-64        | For the US             |
| Kaufman et al., 2022 187                | 1.5°C |              2030 | 22-124       | For the US             |

## Policy-driven carbon pricing

The two types of policy-driven carbon pricing methods are carbon taxation or emissions trading system prices. A decade ago, only 7% of global emissions were covered by either a carbon tax or an emissions trading scheme (ETS). Today, almost a quarter of global GHG emissions (23%) are covered by 73 instruments. Most existing programs are in high income countries in North America and Europe. 188

## Emissions trading schemes

An ETS places a limit or a 'cap' on the amount of GHG emissions for a certain group of entities. The covered entities need to submit one allowance for each metric ton of CO2e emitted during a compliance period, usually a year. The ETS also allows emitters with lower emissions to sell their extra emission units (or 'allowances') to higher emitters, thereby establishing a market price for emissions. 189  In a cap-and-trade program, the government issues a limited number of emissions allowances (also known as permits), each of which grants the holder the right to emit one metric ton of CO2. Allowances can be distributed in a number of ways: they can be directly allocated to firms or facilities (a concept called free allocation of allowances) or sold through auction markets. The limited, governmentcontrolled supply of allowances 'caps' the total amount of emissions. Allowances can be traded, and their sale and purchase (supply and demand) yield a market price for allowances - essentially the price of one metric ton of CO2 emissions. 190 An ETS may include price stability mechanisms like price floors and banking/borrowing provisions, while future emissions caps could also be adjusted, if needed, to help stabilize prices. 191

Under a pure ETS, emissions are fixed by the cap and prices vary based on market conditions linked to the supply and demand for emissions allowances. 192

The price of emissions allowances (UKA) traded on the United Kingdom's ETS was GBP 51.04/tCO2e in May 2023 (roughly USD 63). 193 The price of emissions allowances traded on the European Union's ETS reached a record high of EUR 100.34/tCO2e in February 2023 (roughly USD 109). 194

## Carbon taxes

A carbon tax is different from an ETS in that the emission reduction outcome of a carbon tax is not predefined, but the carbon price is. In their pure forms, carbon taxes provide certainty over emissions prices while emissions are determined by market factors, and vice versa for an ETS. Under carbon taxation, governments can provide certainty over future emissions prices by specifying the future trajectory of tax rates, leaving emissions to be market determined. 195

While economic theory suggests that a carbon tax should be set equal to the social cost of carbon, and that the tax rate should rise over time with the growth rate of the marginal damages from emissions, this is rarely the case. In most carbon tax schemes, tax rates are fixed and adjusted on a discretionary basis according to progress on emissions goals. 196 As an example, Japan's carbon tax, called the Global Warming Countermeasures Tax, is set at JPY 289/tCO2e (roughly USD 2). 197

## Carbon pricing based on project cost

A cost-based pricing model considers the implementation costs of a mitigation project and is used to help ensure ongoing viability.

The Fairtrade minimum pricing model is an example of how this works in practice. It calculates a minimum price that ensures the average costs of a project will be covered, plus an additional 'Fairtrade Premium' on top that goes directly to the local community to fund activities that help them adapt and become more resilient to an already changing climate. The minimum price is calculated based on the sum of investment costs (machinery and computing), project costs (transport, training, monitoring), carbon costs (certification and verification), and the business margin for the project to make a small profit. Any revenues associated with the project are deducted, e.g., from the sale of low-carbon electricity. The 'Fairtrade Premium' is then added to this cost and goes directly to the local community to fund activities that help them adapt and become more resilient to an already changing climate. 198,199

In avoided conversion mitigation projects or programs, pricing should also consider the opportunity cost of converting the land, e.g., to cropland. For example, Li et al., (2020) demonstrate that in Indonesia the average opportunity cost from avoiding oil palm-based deforestation is USD 24.42/tCO2e. 200

## Carbon pricing based on market dynamics

Carbon prices on the voluntary carbon market are informed by market dynamics in that the amount of money expected, required, or given in payment for a carbon credit is driven by supply and demand, regardless of the implications for the project or program in terms of long-term viability.

In the voluntary carbon market, the underlying attributes of the carbon credit and the associated project also inform the price by driving demand for credits with particular attributes. Price trends are therefore an indicator of market preference, e.g., current preference for co-benefit projects reflected in higher-than-average prices. According to S&amp;P (2021), the following attributes can influence the price of carbon on the voluntary carbon market: the type of project (carbon credits from removal projects are typically priced higher than those from avoidance projects), the vintage of the credit (more recent vintage usually means higher price), the geography of the project, and the certifier. 201

According to Ecosystem Marketplace, the global weighted average price of carbon on the voluntary carbon market was USD 4/tCO2e in 2021. Prices vary according to project type, ranging from an average of USD 1.18/ tCO2e for transportation projects up to USD 8.81/tCO2e for agriculture projects. Ecosystem Marketplace report that projects with non-carbon environmental co-benefits have higher prices relative to Ecosystem Marketplace's global average. 202

While market pricing can be effective at driving competition and reducing the cost of achieving an objective, prices do not necessarily support the ongoing viability of a project, which can have negative impacts on communities supporting the project, and in most cases, they do not reflect the actual environmental or social damages caused by a company's unabated emissions. 203

## Industry carbon price benchmarks

Industry carbon price benchmarks are the internal carbon prices used by companies and disclosed through CDP. The average internal carbon price represents an industry average of prices used by companies. As mentioned above, the median internal carbon price disclosed to CDP by companies in 2020 was USD 25/tCO2e. 204

<!-- image -->

## SCIENCE-BASED CARBON PRICING

The SBTi considers science-based carbon prices to represent the economic value of GHG emissions, based on:

- robust scientific assessment of the external cost of GHG emissions (the costs of emissions that the public pays for, such as damage to crops, health care costs from heat waves and droughts, and loss of property from flooding and sea level rise);
- robust scientific assessment of the expected costs associated with achieving a 1.5°C pathway; and/or
- the true and complete cost to fully and permanently abate a given GHG emission

## ANNEX F: DEVELOPMENT OF THIS REPORT

## ANNEX F:

## DEVELOPMENT OF THIS REPORT

## TIMELINE OF ACTIVITIES

Following the launch of the Corporate Net-Zero Standard v1.0 in October 2022, the SBTi initiated work to develop an informative guide on BVCM in October 2022. The SBTi assembled an Expert Advisory Group (EAG) comprising 50 individuals that provided input on various topics throughout the development of the report (see the BVCM EAG Terms of Reference).

In March and April 2023, the SBTi conducted a corporate engagement exercise to understand more about companies' existing BVCM funding activities, alongside motivators, barriers, and potential new incentive mechanisms to drive finance. 212 companies responded to an online survey and a further 22 companies were interviewed.

In June and July 2023, the SBTi held a six-week public consultation on BVCM. The results of the public consultation and the corporate engagement exercise were published on the SBTi website in September 2023.

<!-- image -->

## BVCM PUBLIC CONSULTATION

The public consultation process was designed to elicit feedback from a diverse set of stakeholders on the topic of BVCM to inform the development of SBTi products.

The BVCM Public Consultation document was structured around nine topics:

- Defining BVCM : What activities and investments can companies count towards their BVCM commitments? 1
- Overarching process for BVCM : What are the steps companies need to take when designing and implementing their BVCM strategies? 2
- Determining the nature and scale of the commitment to BVCM : How do companies determine how much BVCM they will deliver each year either in terms of how much finance they will deploy or how much mitigation they will deliver? 3

4

- Deploying finance and resources across BVCM activities : To which BVCM activities should companies channel their finance and resources in the near-term, and how might this change over time?
- BVCM-related claims : What level of guidance should the SBTi provide on BVCM-related claims? 5
- Reporting on BVCM : What do companies need to report on their BVCM activities and investments, where and how often? 6
- Incentives for BVCM : What barriers need to be addressed and what new incentive mechanisms could be established to encourage companies to finance and deliver BVCM? 7
- Terminology : Where is there an inconsistent use of terminology and how can the SBTi support standardization of terminology? 8
- Illustrative case studies : How do these recommendations get operationalized by companies? How might this look different across sectors? 9

The SBTi received 268 responses from respondents based in 33 countries, of which 27% were submitted by individuals representing corporates, financial institutions (FIs) and small and medium-sized enterprises (SMEs); 10% representing civil society organizations (non-business member-led) and 6% research and academia. The corporate and SME respondents covered a wide range of sectors, in particular technology, food, beverage and tobacco and electric utilities.

The full results can be found on the SBTi website and are summarized below.

## Table 9: High-level results of the BVCM public consultation

<!-- image -->

<!-- image -->

<!-- image -->

| CONSULTATION TOPIC                                           | HIGH-LEVEL FEEDBACK                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | HOWTHISFEEDBACKWASINCORPORATED INTO THESBTI'S BVCMGUIDE                                                                                                                                                                                                                                                                                                                                                                                                                                  |
|--------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Defining BVCM 1                                              | 49% of all respondents felt that the SBTi should maintain the definition of BVCM as stated in the 2021 Corporate Net-Zero Standard, while 43% of respondents believe that the SBTi should amend the definition to also capture mitigation actions or investments that may not have guaranteed outcomes.                                                                                                                                                                                                                                                                                                                                                                              | The SBTi has maintained the definition of BVCM as set out in the Corporate Net- Zero Standard and has provided further clarity on the scope, purpose, and timing of BVCM. The SBTi has introduced two BVCM goals which emphasize the importance of both near-term mitigation outcomes and funding to unlock longer term mitigation outcomes.                                                                                                                                             |
| Overarching process for BVCM 2                               | 90% of respondents found the overarching process visualization in the public consultation helpful but also suggested the process diagram could more clearly articulate the cyclical nature of steps.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | The steps companies would need to take when designing and implementing their BVCM strategies have been clarified and the cyclical nature is described.                                                                                                                                                                                                                                                                                                                                   |
| Determining the nature and scale of the commitment to BVCM 3 | The public consultation document presented three methods for determining the nature and scale of the commitment to BVCM i.e., 'how much' BVCM a company should deliver or how much finance a company should deploy in support of BVCM. The three methods were ton- for-ton, money-for-ton, and money- for-money. Overall, there was a slight preference for ton-for-ton when considering which method would result in the greatest outcome for climate and which method best reflects corporate climate leadership. However, civil society organizations, research and academia, and climate change focused consultancies and solution providers are more in favor of money-for-ton. | The SBTi BVCM report acknowledges the varying ability to pay for BVCM across sectors and thus welcomes all efforts by companies to deliver BVCM. The SBTi also recognizes that requirements of certification standards or claims codes may dictate the scale of a commitment to BVCM. The guide also describes a best practice approach based on application of a science-based carbon price and includes an annex on other methods for determining the scale of a commitment (Annex D). |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| CONSULTATION TOPIC                                       | HIGH-LEVEL FEEDBACK                                                                                                                                                                                                                                                                                                                                                | HOWTHISFEEDBACKWASINCORPORATED INTO THESBTI'S BVCMGUIDE                                                                                                                                                                                                                                                                        |
|----------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Deploying finance and resources across BVCM activities 4 | 90% of respondents found the combination of the six principles for BVCM portfolio design, the guiding questions, illustrative examples of aligned mitigation actions, cross- cutting minimum standards and social safeguards, and case studies were helpful. 64% of respondents felt that the SBTi needs to provide more guidance on the operationalization of the | The six principles set out in the consultation document were changed into two Goals for BVCM, underpinned by four Principles. The BVCM report includes an overview of safeguard principles and tools for their implementation as well as illustrative examples of BVCM actions that align with the BVCM Goals and Principles.  |
| BVCM-related claims 5                                    | On average, respondents think that the SBTi should be more directive than not in providing guidance on BVCM claims. Respondents highlighted the need for the SBTi to be clear on its position with regards to carbon neutrality claims.                                                                                                                            | The BVCM guide now includes a discussion on the role of claims and re-emphasizes the general principles underpinning best-practice claims. It also encourages claims to be externally audited or certified for enhanced credibility and points to other sources for additional nuance on best practice for making BVCM claims. |
| Reporting on BVCM 6                                      | Respondents recommended that companies report on BVCM through various channels - notably in their sustainability reports or websites (63% of respondents), and through a submission to the SBTi (56% of respondents).                                                                                                                                              | The BVCM report recommends that companies report transparently on BVCM on an annual basis and provides a set of high-level reporting recommendations and links to relevant resources.                                                                                                                                          |
| Incentives for BVCM 7                                    | Fear of greenwash accusation and lack of a credible BVCM claim were cited as the top barriers preventing BVCM investment. Tax incentives and assessment of BVCM claims were identified as the top new incentive mechanisms in terms of their potential impact in driving BVCM investment.                                                                          | Incentives for BVCM are not explicitly discussed in the BVCM report but are the focus of a complementary research paper entitled "Raising the Bar: An SBTi report on accelerating corporate adoption of BVCM".                                                                                                                 |

<!-- image -->

<!-- image -->

| CONSULTATION TOPIC          | HIGH-LEVEL FEEDBACK                                                                                                                                                                                                                                                                                                                               | HOWTHISFEEDBACKWASINCORPORATED INTO THESBTI'S BVCMGUIDE                                                                                                              |
|-----------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Terminology 8               | Respondents provided suggested edits to terminology: 'offsetting' was the most frequently identified term but with conflicting perspectives on the value and appropriate definition of the term. Respondents provided suggestions for additional terms that the SBTi should seek to define and/or standardize - most notably 'avoided emissions'. | The SBTi has published an updated glossary that aims to support consistency and standardization of terminology use across the SBTi standards and guidance documents. |
| Illustrative case studies 9 | More than 90% of respondents felt that the illustrative case studies were helpful.                                                                                                                                                                                                                                                                | The illustrative case studies were updated to reflect the content of the report.                                                                                     |

<!-- image -->

## FURTHER RESEARCH

There are a number of topics discussed within this report which have relevance for the development of the SBTi's standards and have thus been identified as important research topics within the SBTi. These include (but are not limited to) accounting for BVCM, permanence, carbon pricing, equity considerations and pathways for CDR scale-up. In addition, further research is needed on the ability and responsibility of different sectors to contribute to BVCM, a topic which was discussed in depth in the SBTi's BVCM public consultation document. These research efforts are ongoing.

<!-- image -->

ANNEX G: MAPPING OF THE BVCM REPORT WITH THE VCMI CLAIMS CODE OF PRACTICE

## ANNEX G: MAPPING OF THE BVCM REPORT WITH

## THE VCMI CLAIMS CODE OF PRACTICE

This annex describes the ways in which the SBTi's BVCM report and the VCMI Claims Code of Practice align and how they can be used by companies in concert.

## BVCM and carbon credits

BVCM is defined as mitigation action or investments that fall outside a company's value chain, including activities that avoid or reduce GHG emissions, or remove and store GHGs from the atmosphere. It is included as a recommendation in the SBTi Corporate Net-Zero Standard.

Companies can fund beyond value chain mitigation through a range of instruments such as the purchase and retirement of high-quality carbon credits and direct investments (e.g., equity, debt or project finance).

The SBTi highlights the importance of delivering near-term mitigation outcomes as well as providing funding for innovation and enabling activities to scale climate solutions and unlock future mitigation. Near-term mitigation outcomes can be funded through the purchase and retirement of carbon credits, while funding for innovation and enabling activities for future mitigation to occur would typically be provided via other instruments.

## Purpose of the SBTi BVCM Report and the VCMI Claims Code of Practice

The purpose of the SBTi BVCM report is to support companies in the design and implementation of high-integrity and high-impact BVCM strategies to accelerate global progress to net-zero. The SBTi does not have plans to validate BVCM claims, given its core focus on value chain targets.

In November 2023 the VCMI published its Claims Code of Practice (Claims Code) with the purpose of guiding companies and other non-state actors on how they can credibly make voluntary use of carbon credits as part of their climate commitments and on how they communicate their use of those credits. The Claims Code sets out three types of BVCM claims (Carbon Integrity Silver, Gold and Platinum) that companies can make related to the purchase and retirement of high-quality carbon credits.

Since carbon credit purchase and retirement is a possible funding mechanism for BVCM, the SBTi's BVCM report and the VCMI Claims Code of Practice can therefore be applied by companies in concert.

## Going above and beyond value chain abatement

The SBTi emphasizes that a company's efforts to deliver BVCM must not replace or delay efforts to reduce its scope 1, 2 and 3 emissions in line with a 1.5°C pathway; instead it is a mechanism by which companies can go above and beyond their science-based net-zero targets.

This is consistent with the VCMI Carbon Integrity Silver, Gold and Platinum Claims where carbon credit purchase and retirement is above and beyond the company's efforts to reduce their scope 1, 2 and 3 emissions in line with a 1.5°C pathway. The VCMI Claims Code of Practice requires companies to set, validate and be making progress towards the delivery of near-term science-aligned targets that are in line with the SBTi's criteria or an equivalent science-aligned target setting framework, and to publicly commit to reaching net-zero emissions no later than 2050, in line with globally recognized sustainability frameworks or guidance (including, but not limited to the SBTi Corporate Net-Zero Standard).

## The scale of a BVCM pledge

The SBTi acknowledges the varying ability of companies to pay for BVCM. The SBTi therefore welcomes all efforts by companies to go above and beyond their value chain emissions reductions targets through BVCM based on their business case and the ability to secure internal buy-in and financial resources.

If a company's objective for implementing BVCM is to make organization-level claims, the SBTi also recognizes that the size of their pledge (i.e., the amount of BVCM that they deliver) would likely be determined on the specific requirements of the BVCM certification standard or claims code that they decide to follow. VCMI Carbon Integrity Silver, Gold or Platinum claims define the scale of BVCM through high-quality carbon credit purchase and retirement as follows:

- VCMI Carbon Integrity Silver requires the purchase and retirement of high-quality carbon credits in an amount equal to or greater than 10%, and less than 50% of a company's remaining scope 1, 2 and 3 emissions once it has demonstrated progress towards its near-term emission reduction targets.
- VCMI Carbon Integrity Gold requires the purchase and retirement of high-quality carbon credits in an amount equal to or greater than 50%, and less than 100% of a company's remaining scope 1, 2 and 3 emissions once it has demonstrated progress towards its near-term emission reduction targets.
- VCMI Carbon Integrity Platinum requires the purchase and retirement of high-quality carbon credits in an amount equal to or greater than 100% of a company's remaining scope 1, 2 and 3 emissions, once it has demonstrated progress towards its nearterm emission reduction targets.

<!-- image -->

<!-- image -->

<!-- image -->

The SBTi BVCM report - which as mentioned has a broader focus than carbon credits - proposes that best practice would be for a company to take full responsibility for climate impact of their unabated emissions as they transition to a state of net-zero. In order to do so, the SBTi suggests that companies apply a science-based carbon

price to their unabated emissions to determine a financial budget that can be used to fund a combination of near-term BVCM outcomes, and long-term BVCM funding for innovation and enabling activities, and even wider categories of climate action related to adaptation, loss and damage. Given the urgency of mitigation this decade, the SBTi suggests that companies use a portion of the budget each year to deliver quantified mitigation outcomes generated in respect of or representing mitigation from 2021 onward and measured in tCO2e equivalent to at least 50% of the company's remaining scope 1, 2 and 3 emissions. This recommendation therefore aligns with the VCMI Carbon Integrity Gold and Platinum claims.

Since credible estimates of the science-based carbon price are higher than the average market price for highquality carbon credits today, a company following the SBTi's best practice recommendation could fulfill the VCMI Carbon Integrity Gold or Platinum claim requirements and still have remaining budget to spend on a range of additional climate action, including activities which expect to deliver mitigation in the longer-term (by funding the scale-up of nascent climate solutions and enabling activities needed to achieve net-zero), as well as adaptation and loss and damage.

## Quality

The VCMI Claims Code of Practice requires that carbon credits used towards the VCMI Claims are of the highest quality - they must meet the Integrity Council for the Voluntary Carbon Market (ICVCM) Core Carbon Principles (CCPs) and qualify under its Assessment Framework. VCMI has developed a set of transitional measures for companies to adhere to in the interim as supply of CCP-Approved credits scale-up in the market. The SBTi also recommends that companies that are funding BVCM through the purchase and retirement of carbon credits use credits that are of high-quality and references ICVCM's CCPs as well as other standards and guidelines such as TFCI and CCQI.

## Portfolio design

The VCMI Claims Code of Practice states that companies 'should prioritize projects based on the quality of the climate mitigation and co-benefit impacts they are expected to deliver. However, the importance of early investment in carbon removal projects should be reinforced... VCMI encourages companies to use carbon dioxide removals as part of their carbon credits portfolio and invest in future carbon removals.' 205

While emphasizing the importance of both emissions reductions and removals, the VCMI Claims Code of Practice does not provide guidance on the underlying project types that should be funded through carbon credit purchase and retirement.

The SBTi BVCM report describes a range of illustrative mitigation and enabling activities that need to be funded to achieve net-zero globally. These are framed in the context of BVCM Goals and Principles that are designed to guide companies towards high-impact and high-integrity BVCM activities and investments. Companies that intend to make VCMI Carbon Integrity Silver, Gold or Platinum claims could therefore use the SBTi's BVCM report to help inform their decision-making with regards to which carbon credits to purchase and retire.

## REFERENCES

## REFERENCES

- 1 Intergovernmental Panel on Climate Change (IPCC). (2022). Summary for Policymakers. In: Climate Change 2022 - Mitigation of Climate Change: Working Group III Contribution to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. https/ /:doi.org/10.1017/9781009157926.001
- 2 IPCC. (2023). Summary for Policymakers. In: Climate Change 2023 - Synthesis Report. A Report of the Intergovernmental Panel on Climate Change. Contribution of Working Groups I, II and III to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. https:/ /www.ipcc.ch/report/ar6/syr/ downloads/report/IPCC\_AR6\_SYR\_SPM.pdf
- 3 Rockström, J., Gupta, J., Qin, D. et al. (2023). Safe and just Earth system boundaries. Nature. https:/ /doi. org/10.1038/s41586-023-06083-8
- 4 Munich RE. (2023). Climate change and La Nina driving losses: the natural disaster figures for 2022. https:/ /www.munichre.com/en/company/media-relations/media-information-and-corporate-news/mediainformation/2023/natural-disaster-figures-2022.html
- 5 Climate Policy Initiative (CPI). (2023). Global Landscape of Climate Finance 2023. https:/ /www. climatepolicyinitiative.org/wp-content/uploads/2023/11/Global-Landscape-of-Climate-Finance-2023.pdf
- 6 IPCC. (2022). Climate Change 2022 - Mitigation of Climate Change: Working Group III Contribution to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. https:/ /www.ipcc.ch/report/ar6/ wg3/downloads/report/IPCC\_AR6\_WGIII\_FullReport.pdf
- 7 United Nations Environment Programme (UNEP). (2022). State of Finance for Nature: Time to Act Doubling investment by 2025 and eliminating nature-negative finance flows. https:/ /wedocs.unep. org/20.500.11822/41333
- 8 Science Based Targets Initiative (SBTi). (2023). SBTI Corporate Net-Zero Standard. https:/ / sciencebasedtargets.org/resources/files/Net-Zero-Standard.pdf
- 9 Voluntary Carbon Markets Integrity Initiative (VCMI). (2023). Claims Code - Supplementary Guidance. https:/ / vcmintegrity.org/wp-content/uploads/2023/11/Claims-Code-Supplementary-Guidance-November-2023.pdf
- 10 Ibid.
- 11 SBTi. (2023). SBTI Corporate Net-Zero Standard. Op cit.
- 12 Ibid.
- 13 IPCC. (2022). Full Report. Op cit.
- 14 Greenhouse Gas Protocol. (2022). Draft Land Sector and Removals Guidance: Part 1: Accounting and Reporting Requirements and Guidance. https:/ /ghgprotocol.org/sites/default/files/2022-12/Land-Sector-andRemovals-Guidance-Pilot-Testing-and-Review-Draft-Part-1.pdf
- 15 Rockström, J., Gupta, J., Qin, D. et al. (2023). Op cit.
- 16 IPCC. (2022). Full Report. Op cit.

- 17 IPCC. (2023). Summary for Policymakers. Op cit.
- 18 Ibid.
- 19 Rockström, J., Gupta, J., Qin, D. et al. (2023). Op cit.
- 20 Boehm, S., &amp; Schumer, C. (2023, March 20). 10 Big Findings from the 2023 IPCC Report on Climate Change. World Resources Institute. https:/ /www.wri.org/insights/2023-ipcc-ar6-synthesis-report-climate-change-findings
- 21 Rockström, J., Gupta, J., Qin, D. et al. (2023). Op cit.
- 22 Climate Action Tracker (2023). 2100 Warming Projections: Emissions and expected warming based on pledges and current policies. December 2023. Available at: https:/ /climateactiontracker.org/global/ temperatures/
- 23 Climate Policy Initiative. Op cit.
- 24 IPCC. (2022). Full Report. Op cit.
- 25 IEA. (2021). Net Zero by 2050. https:/ /www.iea.org/reports/net-zero-by-2050
- 26 Ibid.
- 27 IPCC. (2018). Global Warming of 1.5°C. https:/ /www.ipcc.ch/sr15/
- 28 Smith, S. M., Geden, O., Nemet, G., Gidden, M., Lamb, W. F., Powis, C., Bellamy, R., Callaghan, M., Cowie, A., Cox, E., Fuss, S., Gasser, T., Grassi, G., Greene, J., Lück, S., Mohan, A., Müller-Hansen, F., Peters, G., Pratama, Y., Repke, T., Riahi, K., Schenuit, F., Steinhauser, J., Strefler, J., Valenzuela, J. M., and Minx, J. C. (2023). The State of Carbon Dioxide Removal - 1st Edition. https:/ /osf.io/w3b4z/
- 29 Ibid.
- 30 SBTi. (2022). SBTi Monitoring Report 2022. https:/ /sciencebasedtargets.org/resources/files/ SBTiMonitoringReport2022.pdf
- 31 Climate Focus. (2022). Voluntary Carbon Market - 2022 Overview. https:/ /climatefocus.com/wp-content/ uploads/2023/01/VCM-Dashboard-2022-Overview-1.pdf
- 32 UNFCCC (2021). Decision -/CMA.3: Guidance on cooperative approaches referred to in Article 6, paragraph 2, of the Paris Agreement, Annex, paragraph 1. https:/ /unfccc.int/sites/default/files/resource/cma3\_auv\_12a\_ PA\_6.2.pdf
- 33 Kreibiehl, S., Yong Jung, T., Battiston, S., Carvajal, P.E., Clapp, C., Dasgupta, D., Dube, N., Jachnik, R., Morita, K., Samargandi, N., &amp; Williams, M. (2022). Investment and finance. In IPCC, 2022: Climate Change 2022 - Mitigation of Climate Change. Contribution of Working Group III to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. https:/ /www.ipcc.ch/report/ar6/wg3/downloads/report/IPCC\_ AR6\_WGIII\_Chapter15.pdf
- 34 SBTi. (2023). Beyond Value Chain Mitigation (BVCM) Research: March and April 2023 Corporate Engagement Results. https:/ /sciencebasedtargets.org/resources/files/BVCM-Results-of-corporate-engagement-survey.pdf
- 35 Munich RE. Op cit.
- 36 Roe, S., Streck, C. et al. (2021). Land-based measures to mitigate climate change: Potential and feasibility by country. Global Change Biology, 27 (23). https:/ /doi.org/10.1111/gcb.15873
- 37 Global Commission on Adaptation. (2019). Adapt Now: a Global Call for Leadership on Climate Resilience. https:/ /gca.org/wp-content/uploads/2019/09/GlobalCommission\_Report\_FINAL.pdf

- 38 Gupta, S., D. A. Tirpak, N. Burger, J. Gupta, N. Höhne, A. I. Boncheva, G. M. Kanoan, C. Kolstad, J. A. Kruger, A. Michaelowa, S. Murase, J. Pershing, T. Saijo, A. Sari. (2007). Policies, Instruments and Co-operative Arrangements. In IPCC (2007): Climate Change 2007 - Mitigation. Contribution of Working Group III to the Fourth Assessment Report of the Intergovernmental Panel on Climate Change https:/ /www.ipcc.ch/site/ assets/uploads/2018/02/ar4-wg3-chapter13-2.pdf
- 39 Setzer, J. and Higham, C. (2023). Global Trends in Climate Change Litigation: 2023 Snapshot. London: Grantham Research Institute on Climate Change and the Environment and Centre for Climate Change Economics and Policy, London School of Economics and Political Science. https:/ /www.lse.ac.uk/ granthaminstitute/wp-content/uploads/2023/06/Global\_trends\_in\_climate\_change\_litigation\_2023\_ snapshot.pdf
- 40 Grantham Research Institute. (2022). Explainers: What is the polluter pays principle? https:/ /www.lse.ac.uk/ granthaminstitute/explainers/what-is-the-polluter-pays-principle/
- 41 United Nations General Assembly. (1992).  Rio Declaration on Environment and Development. Report of the United Nations Conference on Environment and Development. https:/ /www.un.org/en/development/desa/ population/migration/generalassembly/docs/globalcompact/A\_CONF.151\_26\_Vol.I\_Declaration.pdf
- 42 S. Gupta et al. Op cit.
- 43 Thomson Reuters. (2023). How tax credits can be used to capitalize on the Green Transition. https:/ /www. thomsonreuters.com/en-us/posts/esg/tax-credits-green-transition/
- 44 SBTi. (2023). Summary of responses to the Science Based Targets initiative's public consultation on Beyond Value Chain Mitigation (BVCM). https:/ /sciencebasedtargets.org/resources/files/BVCM-Public-ConsultationResults.pdf
- 45 Financial Exclusions Tracker. https:/ /financialexclusionstracker.org/
- 46 Bain &amp; Company. (2022). Purpose-led Brands Can Reshape the Consumer Goods Industry if They Can Scale... https:/ /www.bain.com/insights/purpose-led-brands-can-reshape-the-consumer-goods-industry-if-they-canscale/
- 47 Ibid.
- 48 Forman, A. (2021, 16 December). Boosting Charitable Giving Can Also Boost Profits. MIT Sloan Management Review. https:/ /sloanreview.mit.edu/article/boosting-charitable-giving-can-also-boost-profits/
- 49 Perez, L. et al. (2022, 10 August). Does ESG really matter - and why? McKinsey Quarterly. https:/ /www. mckinsey.com/capabilities/sustainability/our-insights/does-esg-really-matter-and-why
- 50 Chamberlain, A. (2017, March 6). Why Do Employees Stay? A Clear Career Path and Good Pay, for Starters. Harvard Business Review. https:/ /hbr.org/2017/03/why-do-employees-stay-a-clear-career-path-and-goodpay-for-starters
- 51 Bain &amp; Company. Op cit.
- 52 Global Newswire. (2023, July 3). Global Climate Tech Market is expected to generate worth of USD 182.54 billion at CAGR of 24.5% during forecast period 2023 to 2033. https:/ /www.globenewswire.com/newsrelease/2023/07/04/2698797/0/en/Global-Climate-Tech-Market-is-expected-to-generate-worth-of-US-18254-Billion-at-CAGR-of-24-5-during-forecast-period-2023-to-2033-Data-by-Future-Market-Insights-Inc.html
- 53 CDP. Climate Transition Plans. https:/ /www.cdp.net/en/guidance/guidance-for-companies/climate-transition-plans
- 54 Transition Plan Taskforce. https:/ /transitiontaskforce.net/

- 55 World Economic Forum. (2023). Global Risks Report 2023. https:/ /www.weforum.org/publications/global-risksreport-2023/digest/
- 56 UNFCCC (2021). Op cit.
- 57 Kreibiehl, S. et al. Op cit.
- 58 Arens, C. and Mersmann, F. (2018). Positive Results, no Negative Consequences. No-harm options for Article 6. Wuppertal Institute for Climate, Environment and Energy. https:/ /epub.wupperinst.org/frontdoor/deliver/ index/docId/7123/file/7123\_Article6.pdf
- 59 ISEAL Alliance. (2015). Sustainability Claims Good Practice Guide: Sustainability Standards Systems' Guide to Developing and Managing Environmental, Social and/or Economic Claims. https:/ /www.isealalliance.org/ sites/default/files/resource/2017-11/ISEAL\_Claims\_Good\_Practice\_Guide.pdf
- 60 Hewlett, O., Magrath, D., Hamilton, E., Leugers, S., &amp; Ballantyne, J. (2023). Fairly Contributing to Global Net Zero Considerations for Credible Claims. Gold Standard. https:/ /www.goldstandard.org/sites/default/files/ fairly\_contributing\_to\_global\_net\_zero\_-\_considerations\_for\_credible\_claims.pdf
- 61 European Parliament News. (2023, September 19). EU to ban greenwashing and improve consumer information on product durability. https:/ /www.europarl.europa.eu/news/en/press-room/20230918IPR05412/ eu-to-ban-greenwashing-and-improve-consumer-information-on-product-durability
- 62 European Commission Directorate-General for Justice and Consumers. (2022). Proposal for a Directive on empowering consumers for the green transition and annex. https:/ /commission.europa.eu/publications/ proposal-directive-empowering-consumers-green-transition-and-annex\_en
- 63 Legifrance. (2022). Décret n° 2022-539 du 13 avril 2022 relatif à la compensation carbone et aux allégations de neutralité carbone dans la publicité. https:/ /www.legifrance.gouv.fr/jorf/id/JORFTEXT000045570611
- 64 California Legislative Information. (2023). Assembly Bill No. 1305 - Voluntary carbon market disclosures. https:/ /leginfo.legislature.ca.gov/faces/billTextClient.xhtml?bill\_id=202320240AB1305
- 65 Federal Register. (2022). Guides for the Use of Environmental Marketing Claims. https:/ /www.federalregister. gov/documents/2022/12/20/2022-27558/guides-for-the-use-of-environmental-marketing-claims
- 66 VCMI. Op cit.
- 67 Carbon Pricing Leadership Coalition. (2017).  Report of the High-Level Commission on Carbon Prices. https:/ / www.carbonpricingleadership.org/report-of-the-highlevel-commission-on-carbon-prices
- 68 Rennert, K., Errickson, F., Prest, B.C. et al. (2022). Comprehensive evidence implies a higher social cost of CO2. Nature 610, 687-692. https:/ /doi.org/10.1038/s41586-022-05224-9
- 69 International Standards Organization (ISO). IWA 42:2022(en) Net zero guidelines. https:/ /www.iso.org/obp/ui/ en/#iso:std:iso:iwa:42:ed-1:v1:en
- 70 ISEAL Alliance. (2023). ISEAL Code of Good Practice: draft glossary version 1. https:/ /www.isealalliance.org/ get-involved/resources/iseal-code-good-practice-draft-glossary
- 71 Greenhouse Gas Protocol. (2017). Do We Need a Standard to Calculate "Avoided Emissions"? https:/ /ghgprotocol.org/blog/do-we-need-standard-calculate-%E2%80%9Cavoidedemissions%E2%80%9D#:~:text=Avoided%20%20emissions%20are%20%20emission%20%20 reductions,the%20use%20of%20that%20product%20
- 72 World Resources Institute. (2023). Estimating and Reporting the Comparative Emissions Impacts of Products. https:/ /ghgprotocol.org/sites/default/files/2023-03/18\_WP\_Comparative-Emissions\_final.pdf

- 73 Greenhouse Gas Protocol. (2004). A Corporate Accounting and Reporting Standard - Revised Edition. https:/ / ghgprotocol.org/sites/default/files/standards/ghg-protocol-revised.pdf
- 74 Ibid.
- 75 Climate Focus. (2023). Chapter 12: How are voluntary carbon market benefits shared? In: The Voluntary Carbon Market Explained (VCM Primer). https:/ /vcmprimer.org/chapter-12-how-are-voluntary-carbon-marketbenefits-shared/
- 76 IPCC. (2018). Annex 1: Glossary. In: Global Warming of 1.5°C.. https:/ /www.ipcc.ch/site/assets/uploads/ sites/2/2022/06/SR15\_AnnexI.pdf
- 77 IEA. Bioenergy with Carbon Capture and Storage. https:/ /www.iea.org/energy-system/carbon-captureutilisation-and-storage/bioenergy-with-carbon-capture-and-storage
- 78 IPCC. (2018). Annex 1. Op cit.
- 79 Ibid.
- 80 The World Bank. Carbon Pricing Dashboard. https:/ /carbonpricingdashboard.worldbank.org/what-carbon-pricing
- 81 ISEAL Alliance. (2015). Sustainability Claims Good Practice Guide: Sustainability Standards Systems' Guide to Developing and Managing Environmental, Social and/or Economic Claims. https:/ /www.isealalliance.org/ sites/default/files/resource/2017-11/ISEAL\_Claims\_Good\_Practice\_Guide.pdf
- 82 IPCC. (2018). Annex 1. Op cit.
- 83 Greenhouse Gas Protocol. (2022). Op cit.
- 84 IPCC. (2022). Climate Change 2022: Impacts, Adaptation and Vulnerability. Contribution of Working Group II to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. https:/ /doi. org/10.1017/9781009325844
- 85 IPCC. (2018). Annex 1. Op cit.
- 86 Task Force on Climate-related Financial Disclosures (TCFD). (2017). Recommendations of the Task Force on Climate-related Financial Disclosures. https:/ /assets.bbhub.io/company/sites/60/2020/10/FINAL-2017-TCFDReport-11052018.pdf
- 87 Armstrong McKay, D. I.,  Staal, A., Abrams, J.F., et al. (2022). Exceeding 1.5°C global warming could trigger multiple climate tipping points. Science. 377(6611), eabn7950. https:/ /doi.org/10.1126/science.abn7950
- 88 IPCC. (2022). Climate Change 2022: Impacts, Adaptation and Vulnerability. Op cit.
- 89 IPCC. (2018). Annex 1. Op cit.
- 90 Accountability Framework. (2019). Terms and Definitions. https:/ /accountability-framework.org/fileadmin/ uploads/afi/Documents/Definitions\_doc/Definitions-2020-5.pdf
- 91 IPCC. (2018). Annex 1. Op cit.
- 92 Greenhouse Gas Protocol. (2004). Op cit.
- 93 IPCC. (2018). Annex 1. Op cit.
- 94 Ibid.
- 95 Partnership for Carbon Accounting Financials (PCAF). (2022). Financed Emissions: The Global GHG Accounting and Reporting Standard, Part A. https:/ /carbonaccountingfinancials.com/files/downloads/PCAFGlobal-GHG-Standard.pdf

- 96 Accountability Framework. Op cit.
- 97 Grantham Research Institute. (2014). Explainers: Why do economists describe climate change as a market failure? https:/ /www.lse.ac.uk/granthaminstitute/explainers/why-do-economists-describe-climate-change-asa-market-failure/
- 98 National Grid. (2023). Energy explained: The hydrogen colour spectrum. https:/ /www.nationalgrid.com/ stories/energy-explained/hydrogen-colour-spectrum
- 99 CRU. (2023, March 9). Demystifying green premia. https:/ /sustainability.crugroup.com/article/demystifyinggreen-premia
- 100  NRDC (2023). What is greenwashing. https:/ /www.nrdc.org/stories/what-greenwashing
- 101  Hewlett, O. et al. (2023). Op cit.
- 102  Sato, I., Elliott, B. and Schumer, C. (2021, May 25). What is carbon lock-in and how can we avoid it? https:/ / www.wri.org/insights/carbon-lock-in-definition
- 103  The World Bank. Carbon Pricing Dashboard. https:/ /carbonpricingdashboard.worldbank.org/what-carbon-pricing
- 104  Greenhouse Gas Protocol. (2022). Op cit.
- 105  International Labour Organization (ILO). Climate change and financing a just transition. https:/ /www.ilo.org/ empent/areas/social-finance/WCMS\_825124/lang--en/index.htm
- 106  Denton, F., K. Halsnæs, K. Akimoto, S. Burch, C. Diaz Morejon, F. Farias, J. Jupesta, A. Shareef, P. SchweizerRies, F. Teng, E. Zusman. (2022). Accelerating the transition in the context of sustainable development. In IPCC, (2022): Climate Change 2022: Mitigation of Climate Change. Contribution of Working Group III to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. Op cit. https:/ /ipcc.ch/report/ ar6/wg3/downloads/report/IPCC\_AR6\_WGIII\_Chapter17.pdf
- 107  National Weather Service. (2012). La Nina: How does it impact our winter locally? https:/ /www.weather.gov/ iwx/la\_nina
- 108  NASA Earth Observatory. World of Change: El Nino, La Nina and Rainfall. https:/ /earthobservatory.nasa.gov/ world-of-change/ENSO
- 109  The Integrity Council for the Voluntary Carbon Market (ICVCM). (2023). Section 5: Definitions. In: Core Carbon Principles 2023. https:/ /icvcm.org/wp-content/uploads/2023/07/CCP-Section-5-R2-FINAL-26Jul23.pdf
- 110  ISO. ISO 14040:2006:  Environmental management - Life cycle assessment: Principles and Framework. https:/ /www.iso.org/standard/37456.html
- 111  Bhandari, P., Warszawski, N., Cogan, D. and Gerholdt, R. (2022, December 14). What is "Loss and Damage" from Climate Change? https:/ /www.wri.org/insights/loss-damage-climate-change
- 112  Hewlett, O. et al. Op cit.
- 113  IUCN. (2020). Global Standard for Nature-based Solutions. A user-friendly framework for the verification, design and scaling up of NbS. https:/ /doi.org/10.2305/IUCN.CH.2020.08.en
- 114  IPCC. (2018). Annex 1. Op cit.
- 115  WWF. Payments for Ecosystem Services. https:/ /wwf.panda.org/discover/knowledge\_hub/where\_we\_work/ black\_sea\_basin/danube\_carpathian/our\_solutions/green\_economy/pes/
- 116  Greenhouse Gas Protocol. (2022). Op cit.

- 117  UK Government Department for Food and Rural Affairs (DEFRA). (2005). The Social Cost of Carbon. https:/ / assets.publishing.service.gov.uk/media/5a7ba114ed915d41476219e4/aeat-scc-report.pdf
- 118  Stern, N., Stiglitz, J., Karlsson, K., Taylor, C. (2022). A Social Cost of Carbon Consistent with a Net-Zero Climate Goal. Roosevelt Institute. https:/ /rooseveltinstitute.org/wp-content/uploads/2022/01/RI\_Social-Cost-of-Carbon\_202201-1.pdf
- 119  CDP. (2023). Are Companies Developing Credible Climate Transition Plans? https:/ /cdn.cdp. net/cdp-production/cms/reports/documents/000/006/785/original/Climate\_transition\_plan\_ report\_2022\_%2810%29.pdf?1676456406
- 120  Greenhouse Gas Protocol. (2015). GHG Protocol Scope 2 Guidance. https:/ /ghgprinotocol.org/sites/default/ files/ghgp/standards/Scope%202%20Guidance\_Final\_0.pdf
- 121  IPCC. (2022). Summary for Policymakers, Figure 7. In: Climate Change 2022 - Mitigation of Climate Change. Contribution of Working Group III to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. https:/ /www.ipcc.ch/report/ar6/wg3/figures/summary-for-policymakers/IPCC\_AR6\_WGIII\_ FigureSPM7.png
- 122  Carbon Credit Quality Initiative (2023, June 15). Home. https:/ /carboncreditquality.org/
- 123  Armstrong McKay, D. I.,  Staal, A., Abrams, J.F., et al. (2022). Exceeding 1.5°C global warming could trigger multiple climate tipping points. Science. 377(6611), eabn7950. https:/ /doi.org/10.1126/science.abn7950
- 124  Boulton, C.A., Lenton, T.M. &amp; Boers, N. (2022). Pronounced loss of Amazon rainforest resilience since the early 2000s. Nature Climate Change. 12, 271-278. https:/ /doi.org/10.1038/s41558-022-01287-8
- 125  Houghton, R. A., and Nassikas, A. A. (2018). Negative emissions from stopping deforestation and forest degradation, globally. Glob. Change Biol. 24, 350-359. https:/ /doi.org/10.1111/gcb.13876
- 126  Hubau, W., Lewis, S.L., Phillips, O.L., Affum-Baffoe, K., Beeckman, H., Cuní-Sanchez, A., et al. (2020). Asynchomous carbon sink saturation in African and Amazonian tropical forests. Nature. 2020;579:80-87. https:/ /doi.org/10.1038/s41586-020-2035-0
- 127  Tong, D., Zhang, Q., Zheng, Y., Caldeira, K., Shearer, C., Hong, C., Qin, Y., &amp; Davis, S.J. (2019).  Committed emissions from existing energy infrastructure jeopardize 1.5 °C climate target. Nature. 572, 373-377. https:/ / doi.org/10.1038/s41586-019-1364-3
- 128  Ibid.
- 129  IEA. (2021). Op cit.
- 130  Faria, P., Boldyreva, T., Fonai, G., Issa, A., &amp; Hunt, V. (2021). Emerging Climate Technology Framework. Carbon Disclosure Project. https:/ /cdn.cdp.net/cdp-production/comfy/cms/files/files/000/005/163/original/ECT\_ Framework\_v1.1\_%284%29.pdf
- 131  Smith, S. M. et al. Op cit.
- 132  Systemiq, University of Exeter, &amp; Bezos Earth Fund. (2023). The Breakthrough Effect: How to Trigger a Cascade of Tipping Points to Accelerate the Net Zero Transition. https:/ /www.systemiq.earth/wp-content/ uploads/2023/01/The-Breakthrough-Effect.pdf
- 133  Breakthrough Energy Catalyst. Accelerating the Deployment of Emerging Climate Technologies. Breakthrough Energy, LLC. Retrieved June 12th, from https:/ /breakthroughenergy.org/our-work/catalyst/
- 134  Climate Lobbying. (2022). Global Standard on Responsible Corporate Climate Lobbying - Appendix.  https:/ / climate-lobbying.com/wp-content/uploads/2022/03/2022\_global-standard-responsible-climate-lobbying\_ APPENDIX.pdf

- 135  Songwe V., Stern N., &amp; Bhattacharya A. (2022). Finance for climate action: Scaling up investment for climate and development. Grantham Research Institute on Climate Change and the Environment, London School of Economics and Political Science. https:/ /www.lse.ac.uk/granthaminstitute/wp-content/uploads/2022/11/ IHLEG-Finance-for-Climate-Action-1.pdf
- 136  Climate Focus. (2023). The Voluntary Carbon Market Explained (VCM Primer). https:/ /vcmprimer.files. wordpress.com/2023/01/20230118\_vcm-explained\_all-chapters\_compressed\_final.pdf
- 137  Tye, S., Pool, J.R., and Gallardo Lomeli, L. (2022). The Potential for Nature-Based Solutions Initiatives to Incorporate and Scale Climate Adaptation. World Resources Institute. https:/ /doi.org/10.46830/ wriwp.21.00036
- 138  Seddon, N., A. Smith, P. Smith, I. Key, A. Chausson, C. Girardin, J. House, S. Srivastava, B. Turner, Getting the message right on nature-based solutions to climate change. Glob. Change Biol. 27, 1518-1546 (2021).
- 139  Tye, S. et al. Op cit.
- 140  Chancel, L., Bothe, P., and Voituriez, T. Fair Taxes for a Sustainable Future in the Global South. World Inequality Lab. https:/ /wid.world/wp-content/uploads/2023/01/CBV2023-ClimateInequalityReport-2.pdf
- 141  Bouye, M., O'Connor, D., Tankou, A., Grinspan, D., Waskow, D., Chattopadhyay, S., &amp; Scott, A. (2021). Achieving Social Equity in Climate Action: Untapped Opportunities and Building Blocks for Leaving No One Behind. World Resources Institute. https:/ /files.wri.org/d8/s3fs-public/2021-11/achieving-social-equity-climate-action. pdf?VersionId=k1xcA2QYZm42dCEb4KeeDkTSXqzl4LI7
- 142  Climate Focus. (2022). Chapter 11: Benefit Sharing. In: The Voluntary Carbon Market: Explained. https:/ / vcmprimer.files.wordpress.com/2023/01/20230118\_vcm-explained\_all-chapters\_compressed\_final.pdf
- 143  IPCC. (2022). Climate Change 2022: Impacts, Adaptation and Vulnerability. Op cit.
- 144  ILO. Op cit.
- 145  Denton, F. et al. Op cit.
- 146  Ibid
- 147  ISO. IWA 42:2022(en) Op cit.
- 148  UNEP. (2022). Adaptation Gap Report 2022: Too Little, Too Slow. https:/ /www.unep.org/resources/adaptationgap-report-2022
- 149  Climate Policy Initiative. Op cit.
- 150  United Nations Development Programme (UNDP). Engaging the Private Sector. https:/ /www.adaptation-undp. org/privatesector/
- 151  Tall, A., Lynagh, S. Blanco Vecchi, C. et al. (2021). Enabling Private Investment in Climate Adaptation and Resilience. https:/ /documents1.worldbank.org/curated/en/566041614722486484/pdf/Enabling-Private-Investment-inClimate-Adaptation-and-Resilience-Current-Status-Barriers-to-Investment-and-Blueprint-for-Action.pdf
- 152  Climate Policy Initiative. Op cit.
- 153  Bhandari, P. et al. What is "Loss and Damage" from Climate Change? Op cit.
- 154  IPCC. (2022). Climate Change 2022: Impacts, Adaptation and Vulnerability. Op cit.
- 155  Bhandari, P. et al. What is "Loss and Damage" from Climate Change? Op cit.
- 156  Chatham House. (2022, December 6). Explainer: What is loss and damage? https:/ /www.chathamhouse. org/2022/08/what-loss-and-damage

- 157  Bhandari, P. et al. What is "Loss and Damage" from Climate Change? Op cit.
- 158  Bhandari, P., Warszawaski, N. and Thangata, C. (2022, December 28). The Current State of Play on Financing Loss and Damage. https:/ /www.wri.org/technical-perspectives/current-state-play-financing-loss-and-damage
- 159  Bhandari, P. et al. What is "Loss and Damage" from Climate Change? Op cit.
- 160  United Nations Climate Change. (2023, December 13). COP28 Agreement Signals "Beginning of the End" of the Fossil Fuel Era. Press Release. https:/ /unfccc.int/news/cop28-agreement-signals-beginning-of-the-end-ofthe-fossil-fuel-era
- 161  CDP. (2022). What is Internal Carbon Pricing and How Can it Help Achieve Your Net-Zero Goal? https:/ /cdn. cdp.net/cdp-production/cms/reports/documents/000/006/374/original/ICP\_White\_paper\_Final\_%281%29. pdf?1653572442
- 162  CDP. (2021). Putting a Price on Carbon. https:/ /cdn.cdp.net/cdp-production/cms/reports/ documents/000/005/651/original/CDP\_Global\_Carbon\_Price\_report\_2021.pdf?1618938446
- 163  DEFRA. Op cit.
- 164  Resources for the Future (RFF) and New York State Energy Research and  Development Authority (NYSERDA). (2020). Estimating the Value of Carbon: Two Approaches. https:/ /www.rff.org/publications/reports/estimatingthe-value-of-carbon-two-approaches/
- 165  Pearce, D. (2002). The Social Cost of Carbon and its Policy Implications. https:/ /www.ucl.ac.uk/~uctpa15/ SOCIAL\_COST\_OF\_CARBON.pdf
- 166  Wang, P., Deng, X., Zhou, H. &amp; Yu, S. (2019). Estimates of the social cost of carbon: a review based on metaanalysis. J. Clean. Prod. 209, 1494-1507. https:/ /doi.org/10.1016/j.jclepro.2018.11.058
- 167  Carbon Pricing Leadership Coalition. Op cit.
- 168  Dietz, S., Rising, J., Stoerk, T. and Wagner, G. (2021). Economic impacts of tipping points in the climate system. PNAS. 118 (34). https:/ /www.pnas.org/doi/pdf/10.1073/pnas.2103081118
- 169  Polasky, S. and Dampha, N. K. (2021). Discounting and Global Environmental Change. Annual Review of Environment and Resources. Vol 46: 691-717. https:/ /doi.org/10.1146/annurev-environ-020420-042100
- 170  Stern, N. (2006). The Economics of Climate Change: The Stern Review. HM Treasury of the UK Government. https:/ /webarchive.nationalarchives.gov.uk/ukgwa/20100407172955mp\_/http:/ /www.hm-treasury.gov.uk/d/ Executive\_Summary.pdf
- 171  Ackerman, F. &amp; Stanton, E. (2012). Climate Risks and Carbon Prices: Revising the Social Cost of Carbon. Economics, 6(1), 20120010. https:/ /doi.org/10.5018/economics-ejournal.ja.2012-10
- 172  The White House. (2013). Technical Support Document: Technical Update of the Social Cost of Carbon for Regulatory Impact Analysis - Under Executive Order 12866. https:/ /obamawhitehouse.archives.gov/sites/ default/files/omb/assets/inforeg/technical-update-social-cost-of-carbon-for-regulator-impact-analysis.pdf
- 173  Nordhaus, W. (2014). Estimates of the Social Cost of Carbon: Concepts and Results from the DICE-2013R Model and Alternative Approaches. JAERE, Vol.1, Issue 1/2. https:/ /doi.org/10.1086/676035
- 174  Moore, F., Diaz, D. (2015).Temperature impacts on economic growth warrant stringent mitigation policy. Nature Clim Change 5, 127-131. https:/ /doi.org/10.1038/nclimate2481
- 175  Cai, Y., Lenton, T. and Lontzek, T. (2016). Risk of multiple interacting tipping points should encourage rapid CO2 emission reduction. Nature Clim Change 6, 520-525. https:/ /doi.org/10.1038/nclimate2964

- 176  Umweltbundesamt (2023). Methodenkonvention 3.1 zur Ermittlung von Umweltkosten - Kostensätze Stand 12/2020 und eigene Berechnungen. https:/ /www.umweltbundesamt.de/daten/umwelt-wirtschaft/ gesellschaftliche-kosten-von-umweltbelastungen#gesamtwirtschaftliche-bedeutung-der-umweltkosten
- 177  Interagency Working Group on Social Cost of Greenhouse Gases (IWG). Technical Support Document: Social Cost of Carbon, Methane, and Nitrous Oxide: Interim Estimates under Executive Order 13990 (2021).
- 178  US Environmental Protection Agency. (2022). Report on the Social Cost of Greenhouse Gases. https:/ / subscriber.politicopro.com/eenews/f/eenews/?id=00000184-77c6-d07e-a5fd-f7df41f80000
- 179  Rennert, K., Errickson, F., Prest, B.C. et al. (2022). Comprehensive evidence implies a higher social cost of CO2. Nature 610, 687-692 . https:/ /doi.org/10.1038/s41586-022-05224-9
- 180  RFF and NYSERDA. Op cit.
- 181  IEA. (2022). Global Energy and Climate Model: Documentation. https:/ /iea.blob.core.windows.net/ assets/3a51c827-2b4a-4251-87da-7f28d9c9549b/GlobalEnergyandClimateModel2022Documentation.pdf
- 182  NGFS. (2022). Climate Scenarios Database: Technical Documentation V3.1 https:/ /www.ngfs.net/sites/ default/files/media/2022/11/21/technical\_documentation\_ngfs\_scenarios\_phase\_3.pdf
- 183  Monasterolo, I., Nieto, M.J. and Schets, E. (2023). The Good, the Bad and the Hot House World: Conceptual Underpinnings of the NGFS Scenarios and Suggestions for Improvement. https:/ /doi.org/10.53479/29533
- 184  https:/ /static1.squarespace.com/static/54ff9c5ce4b0a53decccfb4c/t/59b7f2409f8d ce5316811916/1505227332748/CarbonPricing\_FullReport.pdf
- 185  https:/ /www.nature.com/articles/s41558-020-0880-3#:~:text=This%20approach%20dovetails%20with%20 the,2%20prices%20alongside%20a%20portfolio
- 186  Carbon Pricing Leadership Coalition. Op cit.
- 187  Kaufman, N., Barron, A.R., Krawczyk, W. et al. (2020). A near-term to net zero alternative to the social cost of carbon for setting carbon prices. Nat. Clim. Chang. 10, 1010-1014. https:/ /doi.org/10.1038/s41558-020-0880-3
- 188  World Bank. 2023. State and Trends of Carbon Pricing. http:/ /hdl.handle.net/10986/39796
- 189  Ibid.
- 190  RFF. (2019). Carbon Pricing 101. https:/ /media.rff.org/documents/Carbon\_Pricing\_Explainer.pdf
- 191  Parry, I.. Black, S. and Zhunussova, K. (2022). Carbon Taxes or Emissions Trading Systems? Instrument Choice and Design. IMF Staff Climate Note 2022/006. https:/ /www.imf.org/-/media/Files/Publications/Staff-ClimateNotes/2022/English/CLNEA2022006.ashx
- 192  Ibid.
- 193  UK Emission Trading System (UK-ETS) carbon pricing from January 2022 to July 2023. https:/ /www.statista. com/statistics/1322275/carbon-prices-united-kingdom-emission-trading-scheme/
- 194  Daily European Union Emission Trading System (EU-ETS) carbon pricing from 2022 to 2023. https:/ /www. statista.com/statistics/1322214/carbon-prices-european-union-emission-trading-scheme/
- 195  Parry, I. et al. Op cit.
- 196  Ibid.
- 197  International Carbon Action Partnership. (2023, February 22). Japan's Cabinet approves policy roadmap including plans foir national ETS. https:/ /icapcarbonaction.com/en/news/japans-cabinet-approves-policy-

## roadmap-including-plans-national-ets

- 198  Fairtrade Climate Standard. (2015). https:/ /files.fairtrade.net/standards/Climate-Standard\_EN.pdf
- 199  Gold Standard. Carbon Pricing: What is a carbon credit worth? https:/ /www.goldstandard.org/blog-item/ carbon-pricing-what-carbon-credit-worth
- 200  Xi Li, Xufang Zhang and Hongqiang Yang. (2020). Estimating the opportunity costs of avoiding oil palmbased deforestation in Indonesia: Implications for REDD+. Chinese Journal of Population, Resources and Environment. Vol.18, Issue 1. https:/ /doi.org/10.1016/j.cjpre.2021.04.010
- 201  Favasuli, S. and Sebastian, V. (2021). Voluntary carbon markets: how they work, how they're priced and who's involved. S&amp;P Global: Commodity Insights. https:/ /www.spglobal.com/commodityinsights/en/market-insights/ blogs/energy-transition/061021-voluntary-carbon-markets-pricing-participants-trading-corsia-credits#article0
- 202  Ecosystem Marketplace. (2022). State of the Voluntary Carbon Markets 2022 Q3.  https:/ /www. ecosystemmarketplace.com/publications/state-of-the-voluntary-carbon-markets-2022/
- 203  Gold Standard. Carbon Pricing: What is a carbon credit worth? Op cit.
- 204  CDP. (2021). Op cit.
- 205   VCMI. Op cit.

<!-- image -->

For general information and technical queries contact us at: info@sciencebasedtargets.org

<!-- image -->

/science-based-targets

<!-- image -->

<!-- image -->

Partner Organizations:

<!-- image -->

<!-- image -->

Science Based Targets

<!-- image -->

sciencebasedtargets.org

In collaboration with:

<!-- image -->

<!-- image -->