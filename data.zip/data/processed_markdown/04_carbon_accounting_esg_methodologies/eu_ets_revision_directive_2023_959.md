---
document_id: eu_ets_directive_2023_959
title: "Directive (EU) 2023/959 Amending the EU Emissions Trading System (ETS Directive)"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "European Parliament and Council"
year: 2023
original_file: "eu_ets_revision_directive_2023_959.pdf"
tables_detected: 6
converted_with: "Docling v2.32 (TableFormer)"
---

EN

L  130/134

## DIRECTIVE (EU) 2023/959 OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL

## of 10 May 2023

amending Directive 2003/87/EC establishing a system for greenhouse gas emission allowance trading within  the  Union  and  Decision  (EU)  2015/1814  concerning  the  establishment  and  operation  of  a market stability reserve for the Union greenhouse gas emission trading system

(Text with EEA relevance)

THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,

Having regard to the Treaty on the Functioning of the European Union, and in particular Article 192(1) thereof,

Having regard to the proposal from the European Commission,

After transmission of the draft legislative act to the national parliaments,

Having regard to the opinion of the European Economic and Social Committee ( ), 1

Having regard to the opinion of the Committee of the Regions ( ), 2

Acting in accordance with the ordinary legislative procedure ( ), 3

## Whereas:

- (1) The  Paris  Agreement ( ),  adopted  on  12  December  2015 4 under  the  United  Nations  Framework  Convention  on Climate Change (UNFCCC) (the 'Paris Agreement'), entered into force on 4 November 2016. The Parties to the Paris Agreement have agreed to hold the increase in the global average temperature well below 2 °C above pre-industrial levels and to pursue efforts to limit the temperature increase to 1,5 °C above pre-industrial levels. That commitment has been reinforced with the adoption under the UNFCCC of the Glasgow Climate Pact on 13 November 2021, in which the Conference of the Parties to the UNFCCC, serving as the meeting of the Parties to the Paris Agreement, recognises  that  the  impacts  of  climate  change  will  be  much  lower  at  a  temperature  increase  of  1,5 o C,  compared with 2  C, and resolves to pursue efforts to limit the temperature increase to 1,5  C. o o
- (2) The urgency of the need to keep the Paris Agreement goal of 1,5 °C alive has become more significant following the findings of the Intergovernmental Panel on Climate Change in its Sixth Assessment Report that global warming can only be limited to 1,5 °C if strong and sustained reductions in global greenhouse gas emissions within this decade are immediately undertaken.
- (3) Tackling climate- and environmental-related challenges and reaching the objectives of the Paris Agreement are at the core of the communication of the Commission of 11 December 2019 on 'The European Green Deal' (the 'European Green Deal').
- (4) The European Green Deal combines a comprehensive set of mutually reinforcing measures and initiatives aimed at achieving climate neutrality in the Union by 2050, and sets out a new growth strategy that aims to transform the Union  into  a  fair  and  prosperous  society,  with  a  modern,  resource-efficient  and  competitive  economy  where economic growth is decoupled from resource use. It also aims to protect, conserve and enhance the Union's natural capital, and protect the health and well-being of citizens from environment-related risks and impacts. This transition affects workers from various sectors differently. At the same time, that transition has gender equality aspects as well as a particular impact on some disadvantaged and vulnerable groups, such as older people, persons with disabilities,

( 1 ) OJ C 152, 6.4.2022, p. 175.

( 2 ) OJ C 301, 5.8.2022, p. 116.

( 3 ) Position  of  the  European  Parliament  of  18  April  2023  (not  yet  published  in  the  Official  Journal)  and  decision  of  the  Council  of 25 April 2023.

( 4 ) OJ L 282, 19.10.2016, p. 4.

EN

16.5.2023

persons with a minority racial or ethnic background and low and lower-middle income individuals and households. It also imposes greater challenges on certain regions, in particular structurally disadvantaged and peripheral regions, as well as on islands. It must therefore be ensured that the transition is just and inclusive, leaving no one behind.

- (5) On  17  December  2020,  the  Union  submitted  its  nationally  determined  contribution  (NDC)  to  the  UNFCCC, following its approval by the Council. Directive 2003/87/EC of the European Parliament and of the Council ( ), as 5 amended by, inter alia,  Directive  (EU)  2018/410  of  the  European  Parliament  and  of  the  Council ( ),  is  one  of  the 6 instruments cited, subject to revision in light of the enhanced 2030 target, in the general description of the target in the Annex to that submission. The Council stated in its conclusions of 24 October 2022 that it stands ready, as soon as possible after the conclusions of the negotiations on the essential elements of the 'Fit for 55' package, to update, as appropriate, the NDC of the Union and its Member States, in line with paragraph 29 of the Glasgow Climate Pact to reflect  how the final outcome of  the essential elements of  the 'Fit for 55' package implements the Union headline target  as  agreed  by  the  European  Council  in  December  2020.  As  the  EU  Emissions  Trading  System  (EU  ETS), established by Directive 2003/87/EC, is a cornerstone of the Union's climate policy and constitutes its key tool for reducing  greenhouse  gas  emissions  in  a  cost-effective  way,  the  amendments  to  Directive  2003/87/EC,  including with regard to the scope thereof, adopted through this Directive are part of the essential elements of the 'Fit for 55' package.
- (6) The necessity and the value of delivering on the European Green Deal have only grown in light of the very severe effects  of  the  COVID-19  pandemic  on  the  health,  the  living  and  working  conditions  and  the  well-being  of  the Union's  citizens.  Those  effects  have  shown  that  our  society  and  our  economy  need  to  improve  their  resilience  in relation to external shocks and act early to prevent or mitigate the effects of external shocks in a manner that is just and  results  in  no  one  being  left  behind,  including  those  at  risk  of  energy  poverty.  European  citizens  continue  to express strong views that this applies in particular to climate change.
- (7) The Union committed to reducing the Union's economy-wide net greenhouse gas emissions by at least 55 % compared to 1990 levels by 2030 in the updated NDC submitted to the UNFCCC Secretariat on 17 December 2020.
- (8) Through the adoption of Regulation (EU) 2021/1119 of the European Parliament and of the Council ( ), the Union 7 has enshrined in legislation the objective of economy-wide climate neutrality by 2050 at the latest and the aim of achieving negative emissions thereafter. That Regulation also establishes a binding Union domestic reduction target for net greenhouse gas emissions (emissions after deduction of removals) of at least 55 % compared to 1990 levels by  2030,  and  provides  that  the  Commission  is  to  endeavour  to  align  all  future  draft  measures  or  legislative proposals, including budgetary proposals, with the objectives of that Regulation and, in any case of non-alignment, provide the reasons for such non-alignment as part of the impact assessment accompanying those proposals.
- (9) All  sectors  of  the  economy  need  to  contribute  to  achieving  the  emission  reductions  established  by  Regulation (EU) 2021/1119. Therefore, the ambition of the EU ETS should be adjusted so as to be in line with the economywide net greenhouse gas emission reduction target for 2030, the objective of achieving climate neutrality by 2050 at the latest and the aim of achieving negative emissions thereafter, as laid down in Regulation (EU) 2021/1119.

( 5 ) Directive 2003/87/EC of the European Parliament and of the Council of 13 October 2003 establishing a system for greenhouse gas emission allowance trading within the Union and amending Council Directive 96/61/EC (OJ L 275, 25.10.2003, p. 32).

( 6 ) Directive  (EU)  2018/410  of  the  European  Parliament  and  of  the  Council  of  14  March  2018  amending  Directive  2003/87/EC  to enhance cost-effective emission reductions and low-carbon investments, and Decision (EU) 2015/1814 (OJ L 76, 19.3.2018, p. 3).

( 7 ) Regulation (EU) 2021/1119 of the European Parliament and of the Council of 30 June 2021 establishing the framework for achieving climate neutrality and amending Regulations (EC) No 401/2009 and (EU) 2018/1999 ('European Climate Law') (OJ L 243, 9.7.2021, p. 1).

EN

- (10) The EU ETS should incentivise  production  from installations  that  partly  reduce  or  fully  eliminate  greenhouse  gas emissions. Therefore, the description of some categories of activities in Annex I to Directive 2003/87/EC should be amended to ensure that installations performing an activity listed in that Annex and meeting the capacity threshold related  to  the  same  activity,  but  not  emitting  any  greenhouse  gases,  are  included  within  the  scope  of  the  EU  ETS, and thereby ensure there is equal treatment of installations in the sectors concerned. In addition, free allocation for the production of a product should take into account, as guiding principles, the circular use-potential of materials and the fact that the benchmark should be independent of the feedstock or the type of production process, where the production processes have the same purpose. It is therefore necessary to modify the definition of the products and of  the  processes  and  emissions  covered  for  some  benchmarks,  to ensure  a  level  playing  field  for  installations using  new  technologies  that  partly  reduce  or  fully  eliminate  greenhouse  gas  emissions,  and  installations  using existing technologies. Notwithstanding those guiding principles, the revised benchmarks for 2026 to 2030 should continue to distinguish between primary and secondary production of steel and aluminium. It is also necessary to decouple the update of the benchmark values for refineries and for hydrogen to reflect the increasing importance of production of hydrogen, including green hydrogen, outside the refineries sector.
- (11) Following the modification of the definitions of the products and of the processes and emissions covered for some benchmarks, it is necessary to ensure that producers do not receive double compensation for  the same emissions with both free allocation and indirect costs compensation, and thus to adjust accordingly the financial measures to compensate indirect costs passed on in electricity prices.
- (12) Council  Directive  96/61/EC ( ) 8 was  repealed  by  Directive  2010/75/EU  of  the  European  Parliament  and  of  the Council ( ). The references to Directive 96/61/EC in Article 2 of Directive 2003/87/EC and in its Annex IV should 9 be  updated  accordingly.  Given  the  need  for  urgent  economy-wide  emission  reductions,  Member  States  should  be able to act to reduce greenhouse gas emissions that are within the scope of the EU ETS also through policies other than emission limits adopted pursuant to Directive 2010/75/EU.
- (13) In its communication of 12 May 2021 entitled 'Pathway to a Healthy Planet for All - EU Action Plan: Towards Zero Pollution  for  Air,  Water  and  Soil',  the  Commission  calls  for  the  steering  of  the  Union  towards  zero  pollution  by 2050, by reducing air, freshwater, sea and soil pollution to levels which are no longer expected to be harmful for health and natural ecosystems. Measures under Directive 2010/75/EU, as the main instrument regulating air, water and soil pollutant emissions, will often also enable greenhouse gas emissions to be reduced. In line with Article 8 of Directive 2003/87/EC, Member States should ensure coordination between the permit requirements of Directive 2003/87/EC and those of Directive 2010/75/EU.
- (14) Recognising that new innovative technologies will often allow emissions of both greenhouse gases and pollutants to be  reduced,  it  is  important  to  ensure  synergies  between  measures  delivering  reductions  of  emissions  of  both greenhouse gases and pollutants, in particular Directive 2010/75/EU, and review their effectiveness in this regard.
- (15) The definition of electricity generators was used to determine the maximum amount of free allocation to industry in the period from 2013 to 2020, but led to different treatment of cogeneration power plants compared to industrial installations.  In  order  to  incentivise  the  use  of  high  efficiency  cogeneration  and  to  level  the  playing  field  for  all installations receiving free allocation for heat production and district heating, all references to electricity generators in  Directive  2003/87/EC  should  be  deleted.  In  addition,  Commission  Delegated  Regulation  (EU)  2019/331 ( 10 ) specifies the details relating to the eligibility of all industrial processes for free allocation. Therefore, the provisions on  carbon  capture  and  storage  in  Article  10a(3)  of  Directive  2003/87/EC  have  become  obsolete  and  should be deleted.

( 8 ) Council Directive 96/61/EC of 24 September 1996 concerning integrated pollution prevention and control (OJ L 257, 10.10.1996, p. 26).

( 9 ) Directive  2010/75/EU  of  the  European  Parliament  and  of  the  Council  of  24  November  2010  on  industrial  emissions  (integrated pollution prevention and control) (OJ L 334, 17.12.2010, p. 17).

( 10 ) Commission Delegated Regulation (EU) 2019/331 of 19 December 2018 determining transitional Union-wide rules for harmonised free  allocation  of  emission  allowances  pursuant  to  Article  10a  of  Directive  2003/87/EC  of  the  European  Parliament  and  of  the Council (OJ L 59, 27.2.2019, p. 8).

EN

- (16) Greenhouse gases that are not directly released into the atmosphere should be considered emissions under  the EU ETS and allowances should be surrendered for those emissions unless they are stored in a storage site in accordance with Directive 2009/31/EC of the European Parliament and of the Council ( 11 ),  or  they are permanently chemically bound in a product so that they do not enter  the atmosphere under normal use and do not enter the atmosphere under  any  normal  activity  taking  place  after  the  end  of  the  life  of  the  product.  The  Commission  should  be empowered  to  adopt  delegated  acts  specifying  the  conditions  according  to  which  greenhouse  gases  are  to  be considered as permanently chemically bound in a product so that they do not enter the atmosphere under normal use and do not enter  the atmosphere under any normal activity after  the end of  the life of  the product, including obtaining a carbon removal certificate, where appropriate, in view of regulatory  developments with regard to the certification  of  carbon  removals.  Normal  activity  after  the  end  of  the  life  of  the  product  should  be  understood broadly, covering  all the activities taking place after the end  of the life of the product,  including  reuse, remanufacturing, recycling and disposal, such as incineration and landfill.
- (17) International maritime transport activity, consisting of voyages between ports under the jurisdiction of two different Member States or between a port under the jurisdiction of a Member State and a port outside the jurisdiction of any Member State, has been the only means of transportation not included in the Union's past commitments to reduce greenhouse gas emissions. Emissions from fuel sold in the Union for voyages that depart in one Member State and arrive  in  a  different  Member  State  or  a  third  country  have  grown  by  around  36  %  since  1990.  Those  emissions represent  close  to  90  %  of  all  Union  navigation  emissions,  as  emissions  from  fuel  sold  in  the  Union  for  voyages departing  from  and  arriving  in  the  same  Member  State  have  been  reduced  by  26  %  since  1990.  In  a  business-asusual  scenario,  emissions  from  international  maritime  transport  activities  are  projected  to  grow  by  around  14  % between 2015 and 2030 and by 34 % between 2015 and 2050. If the climate change impact of maritime transport activities grows as projected, it would significantly undermine reductions made by other sectors to combat climate change  and  therefore  to  achieve  the  economy-wide  net  greenhouse  gas  emission  reduction  target  for  2030,  the Union's climate-neutrality objective by 2050 at the latest, and the aim of achieving negative emissions thereafter, as laid down in Regulation (EU) 2021/1119, and the objectives of the Paris Agreement.
- (18) In  2013,  the  Commission  adopted  a  strategy  for  progressively  integrating  maritime  transport  emissions  into  the Union's  policy  for  reducing  greenhouse  gas  emissions.  As  a  first  step  in  this  approach,  the  Union  established  a system  to  monitor,  report  and  verify  emissions  from  maritime  transport  in  Regulation  (EU)  2015/757  of  the European Parliament and of  the Council ( 12 ),  to  be  followed  by  the  laying  down  of  reduction  targets  for  maritime transport  and  the  application  of  a  market-based  measure.  In  line  with  the  commitment  of  the  co-legislators expressed  in  Directive  (EU)  2018/410,  action  by  the  International  Maritime  Organization  (IMO)  or  the  Union should start from 2023, including preparatory work on adoption and implementation of a measure ensuring that the  sector  duly contributes  to  the  efforts  needed  to  achieve  the  objectives  agreed  under  the  Paris  Agreement,  and due consideration being given by all stakeholders.
- (19) Pursuant to Directive (EU) 2018/410, the Commission should report to the European Parliament and to the Council on  the  progress  achieved  in  the  IMO  towards  an  ambitious  emission  reduction  objective,  and  on  accompanying measures to ensure that maritime transport duly contributes to the efforts needed to achieve the objectives agreed under the Paris Agreement. Efforts to limit global maritime emissions through the IMO are under way and should be  encouraged,  including  the  rapid  implementation  of  the  Initial  IMO  Strategy  on  Reduction  of  Greenhouse  Gas Emissions  from  Ships,  adopted  in  2018,  which  also  refers  to  possible  market-based  measures  to  incentivise greenhouse gas emission reductions from international shipping. However, while recently there has been progress in  the  IMO,  this  has  so  far  not  been  sufficient  to  achieve  the  objectives  of  the  Paris  Agreement.  Given  the international  character  of  shipping,  it  is  important  that  the  Member  States  and  the  Union  within  their  respective competences  work  with  third  countries  to  step  up  diplomatic  efforts  to  strengthen  global  measures  and  make progress on the development of a global market-based measure at IMO level.

( 11 ) Directive 2009/31/EC of the European Parliament and of the Council of 23 April 2009 on the geological storage of carbon dioxide and amending Council Directive 85/337/EEC, European Parliament and Council Directives 2000/60/EC, 2001/80/EC, 2004/35/EC, 2006/12/EC, 2008/1/EC and Regulation (EC) No 1013/2006 (OJ L 140, 5.6.2009, p. 114).

( 12 ) Regulation  (EU)  2015/757  of  the  European  Parliament  and  of  the  Council  of  29  April  2015  on  the  monitoring,  reporting  and verification of carbon dioxide emissions from maritime transport, and amending Directive 2009/16/EC (OJ L 123, 19.5.2015, p. 55).

EN

- (20) Carbon dioxide (CO2) emissions from maritime transport account for around 3 to 4 % of Union emissions. In the European Green Deal, the Commission stated its intention to take additional measures to address greenhouse gas emissions  from  maritime  transport  through  a  basket  of  measures  to  enable  the  Union  to  reach  its  emission reduction  targets.  In  this  context,  Directive  2003/87/EC  should  be  amended  to  include  maritime  transport  in the  EU  ETS  in  order  to  ensure  that  that  sector  contributes  its  fair  share  to  the  increased  climate  objectives  of  the Union  as  well  as  to  the  objectives  of  the  Paris  Agreement,  which  in  Article  4(4)  states  that  developed  countries should  continue  to  take  the  lead  by  undertaking  economy-wide  emission  reduction  targets,  while  developing countries are encouraged to move over time towards economy-wide emission reduction or limitation targets. While emissions from international aviation outside Europe were to be capped from January 2021 by global market-based action,  an  action  that  caps  or  puts  a  price  on  maritime  transport  emissions  is  not  yet  in  place.  It  is  therefore appropriate that the EU ETS cover a share of the emissions from voyages between a port under the jurisdiction of a Member State and a port under  the jurisdiction of a third country, with the third country being able to decide on appropriate action in respect of the other share of emissions.

The extension of the EU ETS to maritime transport should thus include half of the emissions from ships performing voyages arriving at a port under the jurisdiction of a Member State from a port outside the jurisdiction of a Member State, half of the emissions from ships performing voyages departing from a port under the jurisdiction of a Member State and arriving at a port outside the jurisdiction of a Member State, all of the emissions from ships performing voyages arriving at a port under the jurisdiction of a Member State from a port under the jurisdiction of a Member State, and all of the emissions within a port under the jurisdiction of a Member State. This approach has been noted as a practical way to solve the issue of common but differentiated responsibilities and capabilities, which has been a longstanding challenge in the UNFCCC context. The coverage of a share of the emissions from both incoming and outgoing voyages between the Union and third countries ensures the effectiveness of  the EU ETS, in particular by increasing  the  environmental  impact of  the  measure  compared  to a  geographical scope  limited  to voyages within the  Union,  while  limiting  the  risk  of  evasive  port  calls  and  the  risk  of  delocalisation  of  transhipment  activities outside  the  Union.  To  ensure  a  smooth  inclusion  of  the  sector  in  the  EU  ETS,  the  surrendering  of  allowances  by shipping companies should be gradually increased with respect to verified  emissions  reported for  the years  2024 and 2025.

To protect the environmental integrity of the system, where fewer allowances are surrendered compared to verified emissions for maritime transport during those years, once the difference between verified emissions and allowances surrendered  has  been  established  each  year,  an  amount  of  allowances  corresponding  to  that  difference  should  be cancelled.  From  2026,  shipping  companies  should  surrender  the  number  of  allowances  corresponding  to  all  of their  verified  emissions.  While  the  climate  impact  of  maritime  transport  is  mainly  due  to  its  CO 2 emissions, non-CO2 emissions represent a significant share of emissions from ships. According to the Fourth IMO Greenhouse Gas  Study  2020,  methane  emissions  increased  significantly  over  the  period  from  2012  to  2018.  Methane  and nitrous  oxide  emissions  will  likely  grow  over  time,  in  particular  with  the  development  of  vessels  powered  by liquefied  natural  gases  or  other  energy  sources.  The  inclusion  of  methane  and  nitrous  oxide  emissions  would  be beneficial for environmental integrity and for incentivising good practices. Those emissions should first be included in Regulation (EU) 2015/757 from 2024, and they should be included in the EU ETS from 2026.

- (21) The extension of the scope of Directive 2003/87/EC to maritime transport will lead to changes in the cost of such transport. All parts of  the Union will be affected by that extension of scope as the goods transported to and from ports  within  the  Union  by  maritime  transport  have  their  origin  or  destination  in  the  different  Member  States, including in landlocked Member States. The allocation of allowances to be auctioned by the Member States should therefore,  in  principle,  not  change  as  a  consequence  of  the  inclusion  of  maritime  transport  activities,  and  should include all Member States. However, Member States will be affected to different extents. In particular, Member States with  a  high  reliance  on  shipping  will  be  most  exposed  to  the  effect  of  the  extension.  Member  States  with  a  large maritime sector compared to their  relative size will  be more affected by the extension of  the EU ETS to maritime transport.  It  is  therefore  appropriate  to  provide  additional  time-limited  assistance  to  those  Member  States  in  the form  of  additional  allowances  to  support  decarbonisation  of  maritime  activities  and  for  the  administrative  costs incurred.  The  assistance  should  be  gradually  introduced  in  parallel  with  the  introduction  of  surrender  obligations and thus with the increased effect on those Member States. Within the context of the review of Directive  2003/87/EC,  the  Commission  should  consider  the  relevance  of  that  additional  assistance  in  light,  in particular, of  the development in the number of shipping companies under  the responsibility of different Member States.

EN

- (22) The EU ETS should contribute significantly to reducing greenhouse gas emissions from maritime activities and to increasing  efficiency  in  relation  to  such  activities.  The  use  of  EU  ETS  revenues  pursuant  to  Article  10(3)  of Directive 2003/87/EC should include, inter alia, the promotion of climate-friendly transport and public transport in all sectors.
- (23) Renewing fleets of ice-class ships and developing innovative technology that reduces the emissions of such ships will take  time  and  require  financial  support.  Currently,  the  design  of  ice-class  ships,  which  enables  them  to  sail  in  ice conditions,  leads  to  such  ships  consuming  more  fuel  and  emitting  more  than  ships  of  similar  size  designed  for sailing  only in  open water. Therefore, a flag-neutral method should be implemented under  this Directive allowing for  a  reduction,  until  31  December 2030, of allowances to be surrendered by shipping companies on the basis of their ships' ice class.
- (24) Islands with no road or rail link with the mainland are more dependent on maritime transport than the other regions and depend on maritime links for  their  connectivity.  In  order  to assist  islands  with  a  small  population  to  remain connected following the inclusion of maritime transport activities within the scope of Directive 2003/87/EC, it is appropriate to provide for the possibility for a Member State to request a temporary derogation from the surrender obligations  under  that  Directive  for  certain  maritime  transport  activities  with  islands  with  a  population  of  fewer than 200 000 permanent residents.
- (25) It  should  be  possible  for  Member  States  to  request  that  a  transnational  public  service  contract  or  a  transnational public  service  obligation  between  two  Member  States  be  temporarily  exempted  from  certain  obligations  under Directive  2003/87/EC.  That  possibility  should  be  limited  to  connections  between  a  Member  State  without  a  land border  with another Member State and the geographically closest Member State, such as the maritime connection between  Cyprus  and  Greece,  which  has  been  absent  for  over  two  decades.  That  temporary  derogation  would contribute to addressing the compelling need to provide a service of general interest and ensure connectivity as well as economic, social and territorial cohesion.
- (26) Taking into account the special characteristics and permanent constraints of the outermost regions of the Union as recognised  in  Article  349  of  the  Treaty on  the  Functioning  of  the  European  Union  (TFEU),  and  given  their  heavy dependence  on  maritime  transport,  special  consideration  should  be  given  to  preserving  the  accessibility  of  such regions and efficient connectivity by means of maritime transport. Therefore, a temporary derogation from certain obligations pursuant to Directive 2003/87/EC should be provided for emissions from maritime transport activities between a port  located in  an  outermost  region  of  a  Member  State  and  a  port  located  in  the  same  Member  State, including ports located in the same outermost region and in another outermost region of the same Member State.
- (27) The provisions of Directive 2003/87/EC as regards maritime transport activities should be kept under review in light of  future  international  developments  and  efforts  undertaken  to  achieve  the  objectives  of  the  Paris  Agreement, including  the  second  global  stocktake  in  2028,  and  subsequent  global  stocktakes  every  five  years  thereafter, intended to inform successive NDCs. Those provisions should also be reviewed in the event of the adoption by the IMO of a global market-based measure to reduce greenhouse gas emissions from maritime transport. To this end, the Commission should present a report to the European Parliament and to the Council within 18 months of the adoption of such a measure and before it becomes operational. The Commission should in that report examine that global  market-based  measure  as  regards  its  ambition  in  light  of  the  objectives  of  the  Paris  Agreement,  its  overall environmental integrity, including in comparison with the provisions of Directive 2003/87/EC covering maritime transport,  and  any  issue  related  to  the  coherence  of  the  EU  ETS  and  that  measure.  In  particular,  the  Commission should  in  its report  take  into  account  the  level  of participation  in that global  market-based  measure,  its enforceability, transparency, penalties for non-compliance, the processes for public input, the monitoring, reporting and verification of emissions, registries and accountability. Where appropriate, the report should be accompanied by a legislative proposal to amend Directive 2003/87/EC in a manner that is consistent with the Union 2030 climate target and the climate-neutrality objective set out in Regulation (EU) 2021/1119, and with the aim of preserving the environmental  integrity  and  effectiveness  of  Union  climate  action,  in  order  to  ensure  coherence  between  the implementation of the global market-based measure and the EU ETS, while avoiding any significant double burden, and  thereby  recalling  the  Union's  competence  to  regulate  its  share  of  emissions  from  international  shipping voyages, in line with the obligations of the Paris Agreement.

EN

- (28) With the increased costs of shipping which the extension of Directive 2003/87/EC to maritime transport activities entails,  there  is,  in  the  absence  of  a  global  market-based  measure,  a  risk  of  evasion.  Evasive  port  calls  to  ports outside of the Union and relocation of transhipment activities to ports outside of the Union will not only diminish the environmental benefits of internalising the cost of emissions from maritime transport activities but can also lead to additional emissions due to the extra distance travelled to evade the requirements of Directive 2003/87/EC. It is therefore  appropriate  to  exclude  from  the  definition  of  'port  of  call'  certain  stops  at  non-Union  ports.  That exclusion  should  be  targeted  at  ports  in  the  Union's  vicinity  where  the  risk  of  evasion  is  greatest.  A  limit  of  300 nautical miles from a port under the jurisdiction of a Member State constitutes a proportionate response to evasive behaviour, balancing the additional burden and the risk of evasion. Moreover, the exclusion from the definition of 'port of call' should only apply to stops by container ships at certain non-Union ports, where the transhipment of containers accounts for most container traffic. For such shipments, the risk of evasion, in the absence of mitigating measures, also consists in port hubs being shifted to ports outside the Union, aggravating the effects of the evasion. To  ensure  the  proportionality  of  the  measure  and  that  it  results  in  equal  treatment,  account  should  be  taken  of measures in third countries that have an effect equivalent to Directive 2003/87/EC.
- (29) The Commission should review the functioning of Directive 2003/87/EC in relation to maritime transport activities in the light of experience in applying that Directive, including detecting evasive behaviour in order to prevent such behaviour at  an early  stage, and  should  then propose measures  to ensure  the effectiveness of  that  Directive.  Such measures could include increased surrender  requirements for  voyages where the evasion risk is higher, such as to and from a port that is located in the Union's vicinity, in a third country that has not adopted measures similar to Directive 2003/87/EC.
- (30) Emissions  from  ships  below  5 000 gross  tonnage  represent  less  than  15  %  of  emissions  from  ships,  taking  into account  the  scope  of  application  of  this  Directive,  but  are  emitted  by  a  large  number  of  ships.  For  reasons  of administrative practicability, it is too early to include ships below 5 000 gross tonnage in the EU ETS from the start of  the inclusion of maritime transport, but their inclusion in the future would improve the effectiveness of the EU ETS  and  potentially  reduce  evasive  behaviour  with  the  use  of  ships  below  the  5 000 gross  tonnage  threshold. Therefore, no later  than 31 December 2026, the Commission should present a report to the European Parliament and to the Council in which it should examine the feasibility and economic, environmental and social impacts of the inclusion in Directive 2003/87/EC of emissions from ships below 5 000 gross tonnage, including offshore ships.
- (31) The  person  or  organisation  responsible  for  the  compliance  with  the  EU  ETS  should  be  the  shipping  company, defined as the shipowner or any other organisation or person, such as the manager or the bareboat charterer, that has  assumed  the  responsibility  for  the  operation  of  the  ship  from  the  shipowner  and  that,  on  assuming  such responsibility, has agreed to take over all the duties and responsibilities imposed by the International Management Code  for  the  Safe  Operation  of  Ships  and  for  Pollution  Prevention.  This  definition  is  based  on  the  definition  of 'company' in Article 3, point (d), of Regulation (EU) 2015/757, and in line with the global data collection system established in 2016 by the IMO.
- (32) The emissions from a ship depend, inter alia, on the vessel energy efficiency measures taken by the shipowner, and on the fuel, the cargo carried and the route and the speed of the ship, which can be under the control of a different entity  from  the  shipowner.  The  responsibilities  for  purchasing  fuel  or  taking  operational  decisions  that  affect  the greenhouse  gas  emissions  of  the  ship  can  be  assumed  by  an  entity  other  than  the  shipping  company  under  a contractual  arrangement.  At  the  time  the  contract  is  negotiated,  the  latter  aspects,  in  particular,  would  not  be known  and  thus  the  ultimate  emissions  from  the  ship  covered  by  Directive  2003/87/EC  would  be  uncertain. However,  unless  the  carbon  costs  were  passed  on  to  the  entity  operating  the  ship,  the  incentives  to  implement operational measures for fuel efficiency would be limited. In line with the 'polluter pays' principle and to encourage the  adoption  of  efficiency  measures  and  the  uptake  of  cleaner  fuels,  the  shipping  company  should  therefore  be entitled, under national law, to claim reimbursement for the costs arising from the surrender of allowances from the entity that is directly responsible for the decisions affecting the greenhouse gas emissions of the ship.

EN

While such a mechanism of reimbursement could be subject to a contractual arrangement, Member States should, to reduce administrative costs,  not be  obliged to ensure  or  check the existence of such contracts,  but  should instead provide  for,  in national  law,  a  statutory  entitlement  for the shipping  company  to  be  reimbursed  and  the corresponding access to justice  to enforce  that  entitlement.  For  the  same  reasons,  that  entitlement,  including  any possible  conflict  relating  to  the  reimbursement  between  the  shipping  company  and  the  entity operating  the  ship, should  not  affect  the  obligations  of  the  shipping  company  vis-à-vis  the  administering  authority  in  respect  of  a shipping company or the enforcement measures that might be necessary against such a company to ensure there is full  compliance  by  that  company  with  Directive  2003/87/EC.  At  the  same  time,  as  the  purpose  served  by  the provision  concerning  the  entitlement  to  reimbursement  is  closely  connected  with  the  Union,  in  particular  in relation  to the  compliance with obligations under  this Directive by a shipping company vis-à-vis a given Member State, it is important that that entitlement be observed throughout the Union, in all contractual relations that allow an  entity  other  than  the  shipowner  to  determine  the  cargo  carried  or  the  route  and  the  speed  of  the  ship,  in  a manner  that  safeguards  undistorted  competition  in  the  internal  market,  which  can  include  provisions  preventing parties to such contractual agreements from circumventing the entitlement to reimbursement by including a choice of law clause.

- (33) In order  to reduce the administrative burden on shipping companies, one Member State should be responsible for each  shipping  company.  The  Commission  should  publish  an  initial  list  of  shipping  companies  that  performed  a maritime transport activity  falling within  the  scope  of  the  EU  ETS,  which specifies  the  administering authority  in respect  of  a  shipping  company.  The  list  should  be  updated  regularly  and  at  least  every  two  years  to  reattribute shipping  companies  to  another  such  administering  authority  as  relevant.  For  shipping  companies  registered  in  a Member  State,  the  administering  authority  in  respect  of  a  shipping  company  should  be  that  Member  State.  For shipping  companies  registered  in  a  third  country,  the  administering  authority  in  respect  of  a  shipping  company should be the Member State in which the shipping company had the greatest estimated number of port calls from voyages  falling  within  the  scope  of  Directive  2003/87/EC  in  the  preceding  four  monitoring  years.  For  shipping companies which are registered in a third country and which did not perform any voyage falling within the scope of Directive 2003/87/EC in the preceding four monitoring years, the administering authority in respect of a shipping company should be the Member State where a ship of the shipping company started or ended its first voyage falling within the scope of that Directive. The Commission should publish and update, as relevant, on a biennial basis a list of shipping companies falling within the scope of Directive 2003/87/EC, specifying the administering authority in respect of a  shipping  company.  In order  to ensure  equal  treatment of  shipping  companies,  Member States should follow  harmonised  rules  for  the  administration  of  shipping  companies  for  which  they  have  responsibility,  in accordance with detailed rules to be established by the Commission.
- (34) Member States should ensure that the shipping companies that they administer comply with the requirements of Directive  2003/87/EC.  In  the  event  that  a  shipping  company  fails  to  comply  with  those  requirements  and  any enforcement measures taken by the administering authority in respect of a shipping company have failed to ensure compliance, Member States should act in solidarity. As a last resort measure, Member States, except for the Member State whose flag the ship is flying, should be able to refuse entry to the ships under the responsibility of the shipping company concerned, and the Member State whose flag the ship is flying should be able to detain that ship.
- (35) Shipping companies should monitor and report their aggregated emissions data from maritime transport activities at company  level  in  accordance  with  the  rules  laid  down  in  Regulation  (EU)  2015/757.  The  reports  on  aggregated emissions data at company level should be verified in accordance with the rules laid down in that Regulation. When performing verification  at  company  level,  the  verifier  should  not  verify  the  emissions  reports  at  ship  level  or  the reports  at  ship  level  to  be  submitted  where  there  is  a  change  of  company,  as  those  reports  at  ship  level  will  have been already verified.
- (36) Based on experience from similar tasks related to environmental protection, the European Maritime Safety Agency (EMSA)  or  another  relevant  organisation  should,  as  appropriate  and  in  accordance  with  its  mandate,  assist  the Commission and the administering authorities in respect of a shipping company in relation to the implementation of Directive 2003/87/EC. Owing to its experience with the implementation of Regulation (EU) 2015/757 and its IT tools,  EMSA should assist the administering authorities in respect of a shipping company, in particular as regards the monitoring, reporting and verification of emissions generated by maritime transport activities under the scope of  Directive  2003/87/EC,  by  facilitating  the  exchange  of  information  or  developing  guidelines  and  criteria.  The

EN

Commission, assisted by EMSA, should endeavour to develop appropriate monitoring tools, as well as guidance to facilitate and coordinate verification and enforcement activities related to the application of Directive 2003/87/EC to  maritime  transport.  As  far  as  practicable,  such  tools  should  be  made  available  to  the  Member  States  and  the verifiers in order to better ensure robust enforcement of the national measures transposing Directive 2003/87/EC.

- (37) In parallel to the adoption of this Directive, Regulation (EU) 2015/757 is being amended to provide for monitoring, reporting and verification rules that are necessary for an extension of the EU ETS to maritime transport activities and to provide for the monitoring, reporting and verification of emissions of additional greenhouse gases and emissions from additional ship types.
- (38) Regulation  (EU)  2017/2392  of  the  European  Parliament  and  of  the  Council ( 13 ) amended  Article  12(3)  of Directive 2003/87/EC to allow all operators to use all allowances that are issued. The requirement for greenhouse gas emissions permits to contain an obligation to surrender allowances, pursuant to Article 6(2), point (e), of that Directive, should be aligned accordingly.
- (39) Achieving the Union's emission reduction target for 2030 will require a reduction in the emissions of  the sectors covered by the EU ETS of 62 % compared to 2005. The Union-wide quantity of allowances of the EU ETS needs to be  reduced  to  create  the  necessary  long-term  carbon  price  signal  and  impetus  for  that  degree  of  decarbonisation. The total quantity of allowances should be reduced in 2024 and 2026 to bring it more in line with actual emissions. Moreover,  the  linear  reduction  factor  should  be  increased  in  2024  and  in  2028,  also  taking  into  account  the inclusion of emissions from maritime transport. The steeper cap trajectory resulting from those changes will lead to significantly  greater  levels  of  cumulative  emission  reductions  up  to  2030  than  would  have  occurred  pursuant  to Directive  (EU)  2018/410.  The  figures  relating  to  the  inclusion  of  maritime  transport  should  be  derived  from  the emissions  from  maritime  transport  activities  that  are  addressed  in  Article  3ga  of  Directive  2003/87/EC  and reported  in  accordance  with  Regulation  (EU)  2015/757  for  2018  and  2019  in  the  Union  and  the  States  of  the European Economic Area and the European Free Trade Association, adjusted, from 2021 until 2024, by the linear reduction  factor  for  the  year  2024.  The  linear  reduction  factor  should  be  applied  in  2024  to  the  increase  of  the Union-wide quantity of allowances in that year.
- (40) Achieving the increased climate ambition will require substantial public and private resources in the Union as well as in  Member  States  to  be  dedicated  to  the  climate  transition.  To  complement  and  reinforce  the  substantial  climaterelated spending in the Union budget, all auction revenues that are not attributed to the Union budget in the form of  own  resources,  or  the  equivalent  financial  value  of  such  auction  revenues,  should  be  used  for  climate-related purposes, with the exception of the revenues used for the compensation of indirect carbon costs. The list of climaterelated purposes in Article 10(3) of Directive 2003/87/EC should be expanded to cover additional purposes with a positive environmental impact. This should include use for financial support to address social aspects in lower- and middle-income households by reducing distortive taxes and targeted reductions of duties and charges for renewable electricity. Member States should report annually on the use of auctioning revenues in accordance with Article 19 of Regulation (EU) 2018/1999 of  the European Parliament and of  the Council ( 14 ),  specifying,  where  relevant  and  as appropriate, which revenues are used and the actions that are taken to implement their integrated national energy and climate plans and their territorial just transition plans.

( 13 ) Regulation (EU) 2017/2392 of the European Parliament and of the Council of 13 December 2017 amending Directive 2003/87/EC to continue current limitations of scope for aviation activities and to prepare to implement a global market-based measure from 2021 (OJ L 350, 29.12.2017, p. 7).

( 14 ) Regulation (EU) 2018/1999 of the European Parliament and of the Council of 11 December 2018 on the Governance of the Energy Union and Climate Action, amending Regulations (EC) No 663/2009 and (EC) No 715/2009 of the European Parliament and of the Council,  Directives  94/22/EC,  98/70/EC,  2009/31/EC,  2009/73/EC,  2010/31/EU,  2012/27/EU  and  2013/30/EU  of  the  European Parliament and of the Council, Council Directives 2009/119/EC and (EU) 2015/652 and repealing Regulation (EU) No 525/2013 of the European Parliament and of the Council (OJ L 328, 21.12.2018, p. 1).

EN

- (41) Member States' auctioning revenues will increase as a result of the inclusion of maritime transport in the EU ETS. Therefore,  Member  States  are  encouraged  to  increase  the  use  of  EU  ETS  revenues  pursuant  to  Article  10(3)  of Directive  2003/87/EC  to  contribute  to  the  protection,  restoration  and  better  management  of  marine-based ecosystems, in particular marine protected areas.
- (42) Significant financial resources are needed to implement the goals of the Paris Agreement in developing countries and the Glasgow Climate Pact urges developed country Parties to urgently and significantly scale up their provision of climate finance. In its conclusions on the Preparations for the 27th Conference of the Parties to the UNFCCC (COP 27),  the  Council  recalls  that  the  Union  and  its  Member  States  are  the  largest  contributor  to  international  public climate finance and have more than doubled their contribution to climate finance to support developing countries since  2013.  In  those  conclusions,  the  Council  also  renews  the  strong  commitment  made  by  the  Union  and  its Member States to continue scaling up their  international climate finance towards the developed countries' goal of mobilising  at  least  USD  100  billion  per  year  as  soon  as  possible  and  through  to  2025  from  a  wide  variety  of sources, and expects the goal to be met in 2023.
- (43) To address the distributional and social effects of the transition in low-income Member States, an additional amount of 2,5 % of the Union-wide quantity of allowances from 2024 to 2030 should be used to fund the energy transition of the Member States with a gross domestic product (GDP) per capita below 75 % of the Union average in the years 2016 to 2018, through the Modernisation Fund referred to in Article 10d of Directive 2003/87/EC.
- (44) The beneficiary Member States should be able to use the resources allocated to the Modernisation Fund to finance investments  involving  the  adjacent  Union  border  regions  when  this  is  relevant  to  the  energy  transition  of beneficiary Member States.
- (45) Further incentives to reduce greenhouse gas emissions by using cost-efficient techniques should be provided. To that end, the free allocation of emission allowances to stationary installations from 2026 onwards should be conditional on investments in techniques to increase energy efficiency and reduce emissions, in particular for large energy users. The Commission should ensure that the application of that conditionality does not jeopardise a level playing field, environmental  integrity  or  equal  treatment  of  installations  across  the  Union.  The  Commission  should  therefore, without  prejudice  to  the  rules  applicable  under  Directive  2012/27/EU  of  the  European  Parliament  and  of  the Council ( 15 ),  adopt  delegated  acts  supplementing  this  Directive  to  address  any  issue  identified  in  particular  on  the above-mentioned principles and provide for administratively simple rules for  the application of the conditionality. Those  rules  should  be  part  of  the  general  rules  on  free  allocation,  using  the  established  procedure  for  national implementing measures, and provide for timelines, for criteria for the recognition of implemented energy efficiency measures, as well as for alternative measures to reduce greenhouse gas emissions. In addition, incentives to reduce greenhouse  gas  emissions  should  be  further  reinforced  for  installations  with  high  greenhouse  gas  emission intensities.  To  that  end,  from  2026  onwards,  the  free  allocation  of  emission  allowances  to  the  20  %  stationary installations with the highest emission intensities under a given product benchmark should also be conditional on the setting-up and implementation of climate-neutrality plans.
- (46) The Carbon Border Adjustment Mechanism (CBAM), established under Regulation (EU) 2023/956 of the European Parliament  and  of  the  Council ( 16 ),  is  set  to  replace  the  mechanisms  established  under  Directive  2003/87/EC  to prevent  the  risk  of  carbon  leakage.  To  the  extent  that  sectors  and  subsectors  are  covered  by  that  measure,  they should  not  receive  free  allocation.  However,  a  transitional  phasing-out  of  free  allowances  is  needed  to  allow producers,  importers  and  traders  to  adjust  to  the  new  regime.  The  reduction  of  free  allocation  should  be implemented by applying a factor to free allocation for CBAM sectors, while CBAM is phased in. The CBAM factor should be equal to 100 % for the period between the entry into force of that Regulation and the end of 2025, and subject to the application of provisions referred to in Article 36(2), point (b), of that Regulation, should be equal to 97,5 % in 2026, 95 % in 2027, 90 % in 2028, 77,5 % in 2029, 51,5 % in 2030, 39 % in 2031, 26,5 % in 2032 and 14 % in 2033. From 2034, no CBAM factor should apply.

( 15 ) Directive  2012/27/EU  of  the  European  Parliament  and  of  the  Council  of  25  October  2012  on  energy  efficiency,  amending Directives 2009/125/EC and 2010/30/EU and repealing Directives 2004/8/EC and 2006/32/EC (OJ L 315, 14.11.2012, p. 1).

( 16 ) Regulation (EU) 2023/956 of the European Parliament and of the Council of 10 May 2023 establishing a carbon border adjustment mechanism (see page 52 of this Official Journal).

EN

The relevant delegated acts on free allocation should be adjusted accordingly for the sectors and subsectors covered by CBAM. The free allocation no longer provided to the CBAM sectors based on this calculation (CBAM demand) is to  be  added  to  the  Innovation  Fund,  so  as  to  support  innovation  in  low-carbon  technologies,  carbon  capture  and utilisation (CCU), carbon capture, transport and geological storage (CCS), renewable energy and energy storage, in a way that contributes to mitigating climate change. In this context, special attention should be given to projects in CBAM sectors. To respect the proportion of the free allocation available for non-CBAM sectors, the final amount to be deducted from the free allocation and made available under the Innovation Fund should be calculated based on the proportion that the CBAM demand represents in respect of the free allocation needs of all sectors receiving free allocation.

- (47) In order to mitigate potential carbon leakage risks related to goods subject to CBAM and produced in the Union for export  to  third  countries  which  do  not  apply  the  EU  ETS  or  a  similar  carbon  pricing  mechanism,  an  assessment should  be  carried  out  before  the  end  of  the  transitional  period  under  Regulation  (EU)  2023/956.  Where  that assessment concludes that there is such a carbon leakage risk, the Commission should, where appropriate, submit a legislative  proposal to address that carbon leakage risk in a manner  that is compliant with the rules of  the World Trade  Organization.  Moreover,  Member  States  should  be  allowed  to  use  auction  revenues  to  address  any  residual risk of  carbon  leakage in CBAM sectors and in accordance with State aid rules. Where allowances coming from a reduction of free allocation in application of  the conditionality rules are not fully used to exempt the installations with  the  lowest  greenhouse  gas  emission  intensity  from  the  cross-sectoral  correction,  50  %  of  those  residual allowances  should  be  added  to  the  Innovation  Fund.  The  other  50  %  should  be  auctioned  on  behalf  of  Member States and they should use the revenue therefrom to address any residual risk of carbon leakage in CBAM sectors.
- (48) In  order  to  better  reflect  technological  progress  while  ensuring  emission  reduction  incentives  and  properly rewarding innovation, the minimum adjustment of the benchmark values should be increased from 0,2 % to 0,3 % per  year,  and  the  maximum  adjustment  should  be  increased  from  1,6  %  to  2,5  %  per  year.  For  the  period  from 2026 to 2030, the benchmark values should thus be adjusted within a range of 6 % to 50 % compared to the value applicable  in  the  period  from  2013  to  2020.  In  order  to  provide  predictability  to  installations,  the  Commission should adopt implementing acts determining the revised benchmark values for free allocation as soon as possible before the start of the period from 2026 to 2030.
- (49) To  incentivise  new  breakthrough  technologies  in  the  steel  industry  and  to  avoid  a  significantly  disproportionate reduction  of  the  benchmark  value  and  in  light  of  the  particular  situation  of  the  steel  industry  such  as  the  high emission intensity and the international and Union market structure, it is necessary to exclude from the calculation of the hot metal benchmark value for the period from 2026 to 2030 installations that were operational during the reference period from 2021 to 2022 and that would otherwise be included in that calculation due to the review of the definition of the product benchmark for hot metal.
- (50) To reward best performers and innovation, installations whose greenhouse gas emission levels are below the average of  the  10  %  most efficient  installations  under  a  given  benchmark  should  be  excluded  from  the  application  of  the cross-sectoral correction factor. Allowances that are not allocated due to a reduction of free allocation in application of  the  conditionality  rules  should  be  used  to  cover  the  deficit  in  the  reduction  of  free  allocation  resulting  from excluding best performers from the application of the cross-sectoral correction factor.
- (51) In order to speed up the decarbonisation of the economy while strengthening the industrial competitiveness of the Union, an additional 20 million allowances from the quantity which could otherwise be allocated for free and an additional 5 million allowances from the quantity which could otherwise be auctioned should be made available to the  Innovation  Fund.  When  reviewing  the  timing  and  sequencing  of  the  auctioning  for  the  Innovation  Fund established in Commission Regulation (EU) No 1031/2010 ( 17 ) in view of the changes introduced by this Directive, the Commission should consider making available larger amounts of resources in the first years of implementation of the revised Directive 2003/87/EC to boost the decarbonisation of relevant sectors.

( 17 ) Commission Regulation (EU) No 1031/2010 of 12 November 2010 on the timing, administration and other aspects of auctioning of greenhouse gas emission allowances pursuant to Directive 2003/87/EC of the European Parliament and of the Council establishing a system for greenhouse gas emission allowances trading within the Union (OJ L 302, 18.11.2010, p. 1).

EN

16.5.2023

- (52) A comprehensive approach to innovation is essential for achieving the objectives of Regulation (EU) 2021/1119. At Union  level,  the  necessary  research  and  innovation  efforts  are  supported,  among  other  things,  through  Horizon Europe,  which  includes  significant  funding  and  new  instruments  for  the  sectors  coming  under  the  EU  ETS. Consequently, the Commission should seek synergies with Horizon Europe and, where relevant, with other Union funding programmes.
- (53) The Innovation Fund should support innovative techniques, processes and technologies, including the scaling-up of such  techniques,  processes  and  technologies,  with  a  view  to  their  broad  roll-out  across  the  Union.  Breakthrough innovation should be prioritised in the selection of projects supported through grants.
- (54) The  scope  of  the  Innovation  Fund  referred  to  in  Article  10a(8)  of  Directive  2003/87/EC  should  be  extended  to support innovation in low- and zero-carbon technologies and processes that concern the consumption of fuels in the buildings, road transport and additional sectors, including collective forms of transport such as public transport and coach services. In addition, the Innovation Fund should serve to support investments to decarbonise maritime transport, including investments in energy efficiency of ships, ports and short-sea shipping, in electrification of the sector, in sustainable alternative fuels, such as hydrogen and ammonia that are produced from renewables, in zeroemission  propulsion  technologies  such  as  wind  technologies,  and  in  innovations  with  regard  to  ice-class  ships. Special  attention  should  be  given  to  innovative  projects  contributing  to  decarbonising  the  maritime  sector  and reducing  all  of  its  climate  impacts,  including  black  carbon  emissions.  In  that  respect,  the  Commission  should provide for dedicated topics in Innovation Fund calls for proposals. Those calls should take biodiversity protection, noise and water pollution issues into account. As far as maritime transport is concerned, projects with clear added value for the Union should be eligible.
- (55) Pursuant to Article 9 of Commission Delegated Regulation (EU) 2019/1122 ( 18 ), where aircraft operators no longer operate flights covered by the EU ETS, their accounts are set to 'excluded' status, and processes may no longer be initiated  from  those  accounts.  To  preserve  the  environmental  integrity  of  the  EU  ETS,  allowances  which  are  not issued to aircraft operators, due to them ceasing operations, should be used to cover any shortfall in surrenders by those operators, and any leftover allowances should be used to accelerate action to tackle climate change by being placed in the Innovation Fund.
- (56) Technical  assistance  from  the  Commission  focused  on  Member  States  from  which  few  or  no  projects  have  been submitted so far would contribute to achieving a high number of project applications for funding by the Innovation Fund across all Member States. That assistance should, among other  things, support activities aimed at improving the  quality  of  proposals  for  projects  located  in  the  Member  States  from  which  few  or  no  projects  have  been submitted, for example through sharing information, lessons learned and best practice, and at boosting the activities of  national  contact  points.  Other  measures  serving  the  same  aim  include  measures  to  raise  awareness  of  funding options  and  increase  the  capacity  of  those  Member  States  to  identify  and  support  potential  project  applicants. Project  partnerships  across Member States and matchmaking between potential applicants, in particular for largescale projects, should also be promoted.
- (57) In order to improve the role of Member States in the governance of the Innovation Fund and increase transparency, the Commission should report to the Climate Change Committee on the implementation of the Innovation Fund, providing an analysis of the expected impact of awarded projects by sector and by Member State. The Commission should  also  provide  the  report  to  the  European  Parliament  and  to  the  Council  and  make  it  public.  Subject  to  the agreement  of  applicants,  following  the  closure  of  a  call  for  proposals,  the  Commission  should  inform  Member States  of  the  applications  for  funding  of  projects  in  their  respective  territories  and  should  provide  them  with detailed information of  those applications in order  to facilitate the Member States' coordination of  the support to projects. In addition, the Commission should inform the Member States about the list of pre-selected projects prior to the award of the support. Member States should ensure that the national transposition provisions do not hamper innovation and are technologically neutral, while the Commission should provide technical assistance, in particular

( 18 ) Commission  Delegated  Regulation  (EU)  2019/1122  of  12  March  2019  supplementing  Directive  2003/87/EC  of  the  European Parliament and of the Council as regards the functioning of the Union Registry (OJ L 177, 2.7.2019, p. 3).

EN

to Member States with low effective participation, in order to improve the effective geographical participation in the Innovation  Fund  and  increase  the  overall  quality  of  submitted  projects.  The  Commission  should  also  ensure comprehensive  monitoring  and  reporting,  including  information  on  progress  towards  effective,  quality-based geographical coverage across the Union and appropriate follow-up.

- (58) In  order  to  align  with  the  comprehensive  nature  of  the  European  Green  Deal,  the  selection  process  for  projects supported through grants should give priority to projects addressing multiple environmental impacts. In order  to support  the  replication  and  the  faster  market  penetration  of  the  technologies  or  solutions  that  are  supported, projects funded by the Innovation Fund should share knowledge with other relevant projects as well as with Unionbased researchers having a legitimate interest.
- (59) Contracts for difference (CDs), carbon contracts for difference (CCDs) and fixed premium contracts are important elements for the triggering of emission reductions in industry through the scaling-up of new technologies, offering the  opportunity  to  guarantee  investors  in  innovative  climate-friendly  technologies  a  price  that  rewards  CO 2 emission reductions above those induced by the prevailing carbon price level in the EU ETS. The range of measures that  the  Innovation  Fund  can  support  should  be  extended  to  provide  support  to  projects  through  competitive bidding,  leading  to  the  award  of  CDs,  CCDs  or  fixed  premium  contracts.  Competitive  bidding  would  be  an important mechanism for supporting the development of decarbonisation technologies and optimising the use of available resources. It would also offer certainty to investors in those technologies. With a view to minimising any contingent  liability  for  the  Union  budget,  risk  mitigation  should  be  ensured  in  the  design  of  CDs  and  CCDs  and appropriate coverage by a budgetary commitment should be provided with full coverage at least for  the first two rounds  of  CDs  and  CCDs  with  appropriations  resulting  from  the  proceeds  of  auctioning  of  allowances  allocated pursuant to Article 10a(8) of Directive 2003/87/EC.

No  such  risks  exist  for  fixed  premium  contracts  because  the  legal  commitment  will  be  covered  by  a  matching budgetary commitment. In addition, the Commission should conduct, after concluding the first two rounds of CDs and CCDs, and each time it is necessary thereafter,  a qualitative  and  quantitative  assessment of  the  financial  risks arising  from  their  implementation.  The  Commission  should  be  empowered  to  adopt  a  delegated  act  to  provide, based  on  the  results  of  that  assessment,  for  an  appropriate  provisioning  rate  rather  than  full  coverage  for subsequent rounds of CDs or CCDs. Such an approach should take into account any elements that could reduce the financial risks for the Union budget, in addition to the allowances available in the Innovation Fund, such as possible sharing of liability with Member States, on a voluntary basis, or a possible re-insurance mechanism from the private sector. It is therefore necessary to provide for derogations from parts of Title X of Regulation (EU, Euratom)  2018/1046  of  the  European  Parliament  and  of  the  Council ( 19 ).  The  provisioning  rate  for  the  first  two rounds of CDs and CCDs should be 100 %.

However, by way of derogation from Article 210(1), Article 211(1) and (2) and Article 218(1) of that Regulation, a minimum provisioning rate of 50 % as well as a maximum share of revenue from the Innovation Fund to be used for  provisioning  of  30  %  should  be  set  in  this  Directive  for  subsequent  rounds  of  CDs  and  CCDs  and  the Commission should be able to specify the provisioning rate necessary on the basis of the experience from the first two calls for proposals and the amount of revenue to be used for provisioning. The total financial liability borne by the Union budget should thus not exceed 60 % of the proceeds from auctioning for the Innovation Fund. Moreover, as  provisioning  will  come,  in  general,  from  the  Innovation  Fund,  derogations  should  be  made  from  the  rules  in Articles  212,  213  and  214  of  Regulation  (EU,  Euratom)  2018/1046  relating  to  the  common  provisioning  fund established by Article 212 of that Regulation. The novel nature of CDs and CCDs might also necessitate derogations from  Article  209(2),  points  (d)  and  (h),  of  that  Regulation,  given  that  they  do  not  rely  on  leverage/multipliers  or depend entirely on an ex ante assessment, from Article 219(3), due to the link to Article 209(2), point (d), and from Article 219(6) thereof, as implementing partners will not have credit or equity exposures under a guarantee. The use of  any  derogation  from  Regulation  (EU,  Euratom)  2018/1046  should  be  limited  to  what  is  necessary.  The Commission should be empowered to amend the maximum share of revenue from the Innovation Fund to be used for provisioning by no more than 20 percentage points above what is provided for in this Directive.

( 19 ) Regulation (EU, Euratom) 2018/1046 of the European Parliament and of the Council of 18 July 2018 on the financial rules applicable to  the  general  budget  of  the  Union,  amending  Regulations  (EU)  No  1296/2013,  (EU)  No  1301/2013,  (EU)  No  1303/2013, (EU) No  1304/2013,  (EU) No  1309/2013,  (EU) No  1316/2013,  (EU) No  223/2014,  (EU) No  283/2014,  and Decision No 541/2014/EU and repealing Regulation (EU, Euratom) No 966/2012 (OJ L 193, 30.7.2018, p. 1).

EN

- (60) The  Innovation  Fund  is  subject  to  the  general  regime  of  conditionality  for  the  protection  of  the  Union  budget established by Regulation (EU, Euratom) 2020/2092 of the European Parliament and of the Council ( 20 ).
- (61) Where an installation's activity is temporarily suspended, free allocation is adjusted to the activity levels which are mandatorily reported annually. In addition, competent authorities can suspend the issuance of emission allowances to  installations  that  have  suspended  operations  as  long  as  there  is  no  evidence  that  they  will  resume  operations. Therefore, operators should no longer be required to demonstrate to the competent authority that their installation will  resume  production  within  a  specified  and  reasonable  time  in  the  event  of  a  temporary  suspension  of  the activities.
- (62) Corrections of free allocation granted to stationary installations pursuant to Article 11(2) of Directive 2003/87/EC can require granting additional free allowances or transferring back surplus allowances. The allowances set aside for new entrants under Article 10a(7) of Directive 2003/87/EC should be used for those purposes.
- (63) Since 2013, electricity producers have been obliged to purchase all the allowances they need to generate electricity. Nevertheless,  in  accordance  with  Article  10c  of  Directive  2003/87/EC,  some  Member  States  have  the  option  of providing transitional free allocation for the modernisation of the energy sector for the period from 2021 to 2030. Three  Member  States  have  chosen  to  use  that  option.  Given  the  need  for  rapid  decarbonisation,  especially  in  the energy  sector,  the  Member  States  concerned  should  only  be  able  to  provide  this  transitional  free  allocation  for investments  carried  out  until  31  December  2024.  They  should  be  able  to  add  any  remaining  allowances  for  the period from 2021 to 2030 that are not used for such investments, in the proportion they determine, to the total quantity  of  allowances  that  the  Member  State  concerned  receives  for  auctioning,  or  use  them  to  support investments within the framework of the Modernisation Fund. With the exception of the deadline for notification thereof,  allowances  transferred  to  the  Modernisation  Fund  should  be  subject  to  the  same  rules  concerning investments that are applicable to the allowances already transferred pursuant to Article 10d(4) of Directive 2003/87/EC. To ensure predictability and transparency with regard to the amount of allowances available either  for  auctioning  or  for  the  transitional  free  allocation,  and  with  regard  to  the  assets  managed  by  the Modernisation Fund, Member States should inform the Commission of the amounts of remaining allowances to be used for each purpose, respectively, by 15 May 2024.
- (64) The scope of  the  Modernisation  Fund  should  be  aligned  with  the  most  recent  climate  objectives  of  the  Union  by requiring  that  investments  are  consistent  with  the  objectives  of the European  Green  Deal  and  Regulation (EU) 2021/1119, and eliminating the support to any investments related to energy generation based on fossil fuels, except  as  regards  the  support  for  such  investments  with  revenue  from  allowances  voluntarily  transferred  to  the Modernisation  Fund  in  accordance  with  Article  10d(4)  of  Directive  2003/87/EC.  In  addition,  limited  support  for such investments should continue to be possible with revenue from the allocations referred to in Article 10(1), third subparagraph, of that Directive under certain conditions, in particular where the activity qualifies as environmentally sustainable under Regulation (EU) 2020/852 of the European Parliament and of the Council ( 21 ) and as regards the allowances  auctioned  until  2027.  For  the  latter  category  of  allowances,  the  downstream  uses  of  non-solid  fossil fuels  should,  in  addition,  not  be  supported with revenue from  allowances auctioned after 2028. Furthermore, the percentage of the Modernisation Fund that needs to be devoted to priority investments should be increased to 80 % for the Modernisation Fund allowances transferred in accordance with Article 10d(4) of Directive 2003/87/EC and referred to in Article 10(1), third subparagraph, of that Directive, and to 90 % for  the additional amount of 2,5 % from the Union-wide quantity of allowances.

Energy  efficiency  including  in  industry,  transport,  buildings,  agriculture  and  waste;  heating  and  cooling  from renewable sources; as well as support for households to address energy poverty, including in rural and remote areas, should be included within the scope of the priority investments. In order to increase transparency and better assess the  impact  of  the  Modernisation  Fund,  the  Investment  Committee  should  report  annually  to  the  Climate  Change Committee  on  experience  with  the  evaluation  of  investments,  in  particular  in  terms  of  emission  reductions  and abatement costs.

( 20 ) Regulation (EU, Euratom) 2020/2092 of the European Parliament and of the Council of 16 December 2020 on a general regime of conditionality for the protection of the Union budget (OJ L 433 I, 22.12.2020, p. 1).

( 21 ) Regulation (EU) 2020/852 of the European Parliament and of the Council of 18 June 2020 on the establishment of a framework to facilitate sustainable investment, and amending Regulation (EU) 2019/2088 (OJ L 198, 22.6.2020, p. 13).

EN

- (65) Directive  (EU)  2018/410  introduced  provisions relating  to the  cancellation  by  Member  States  of  allowances  from their  auction  volume  in  respect  of  closures  of  electricity-generation  capacity  in  their  territory.  In  view  of  the increased climate ambition of the Union and the resulting accelerated decarbonisation of the electricity sector, such cancellation  has  become  increasingly  relevant.  Therefore,  the  Commission  should  assess  whether  the  use  by Member  States  of  cancellation  can  be  facilitated  by  amending  the  relevant  delegated  acts  adopted  pursuant  to Article 10(4) of Directive 2003/87/EC.
- (66) Adjustments  to  free  allocation  introduced  in  Directive  (EU)  2018/410  and  put  into  effect  by  Commission Implementing Regulation (EU) 2019/1842 ( 22 ) improved the efficiency and incentives provided  by free allocation, but  increased  the  administrative  burden  and  rendered  the  historical  date  of  issuance  of  free  allocation  of  28 February  inoperative.  In  order  to  better  take  into  account  the  adjustments  to  free  allocation,  it  is  appropriate  to make adjustments to the compliance cycle. The deadline for competent authorities to grant free allocation should therefore be postponed from 28 February to 30 June and the deadline for operators to surrender allowances should be postponed from 30 April to 30 September.
- (67) Commission Implementing Regulation (EU) 2018/2066 ( 23 ) lays down rules on the monitoring of emissions from biomass, which are consistent with the rules on the use of biomass laid down in the Union legislation on renewable energy.  As  the  legislation  becomes  more  elaborate  on  the  sustainability  criteria  for  biomass  with  the  latest  rules established  in  Directive  (EU)  2018/2001  of  the  European  Parliament  and  of  the  Council ( 24 ), the  conferral  of implementing powers in Article 14(1) of Directive 2003/87/EC should be explicitly extended to the adoption of the necessary  adjustments  for  the  application  in  the  EU  ETS  of  sustainability  criteria  for  biomass,  including  biofuels, bioliquids  and  biomass  fuels.  In  addition,  the  Commission  should  be  empowered  to  adopt  implementing  acts  to specify how to account for the storage of emissions from mixes of zero-rated biomass and biomass that is not from zero-rated sources.
- (68) Renewable liquid and gaseous fuels of non-biological origin and recycled carbon fuels can be important for reducing greenhouse gas emissions in sectors that are hard to decarbonise. Where recycled carbon fuels and renewable liquid and  gaseous  fuels  of  non-biological  origin  are  produced  from  captured  CO 2 under  an  activity  covered  by  this Directive,  the  emissions  should  be  accounted  for  under  that  activity.  To  ensure  that  renewable  fuels  of  nonbiological origin and recycled carbon fuels contribute to greenhouse gas emission reductions, and to avoid double counting  for  fuels  that  do  so,  it  is  appropriate  to  explicitly  extend  the  empowerment  in  Article  14(1)  of Directive  2003/87/EC  to  the  adoption  by  the  Commission  of  implementing  acts  laying  down  the  necessary adjustments  for  how  to  account  for  the  eventual  release  of  CO ,  in  a  way  that  ensures  that  all  emissions  are 2 accounted  for,  including  where  such  fuels  are  produced  from  captured  CO 2 outside  the  Union,  while  avoiding double counting and ensuring appropriate incentives are in place for capturing emissions, taking also into account the treatment of those fuels under Directive (EU) 2018/2001.
- (69) As CO2  is also expected to be transported by means other than pipelines, such as by ship and by truck, the current coverage in Annex I to Directive 2003/87/EC for transport of greenhouse gases for  the purpose of storage should be  extended  to  all  means  of  transport  for  reasons  of  equal  treatment  and  irrespective  of  whether  the  means  of transport are covered by the EU ETS. Where the emissions from the transport are also covered by another activity under  Directive  2003/87/EC,  the  emissions  should  be  accounted  for  under  that  other  activity  to  prevent  double counting.

( 22 ) Commission Implementing Regulation (EU) 2019/1842  of 31 October 2019 laying down  rules for the application of Directive  2003/87/EC  of  the  European  Parliament  and  of  the  Council  as  regards  further  arrangements  for  the  adjustments  to  free allocation of emission allowances due to activity level changes (OJ L 282, 4.11.2019, p. 20).

( 23 ) Commission Implementing Regulation (EU) 2018/2066 of 19 December 2018 on the monitoring and reporting of greenhouse gas emissions pursuant  to Directive 2003/87/EC  of  the  European  Parliament  and  of the Council  and  amending  Commission Regulation (EU) No 601/2012 (OJ L 334, 31.12.2018, p. 1).

( 24 ) Directive  (EU)  2018/2001  of  the  European  Parliament  and  of  the  Council  of  11  December  2018  on  the  promotion  of  the  use  of energy from renewable sources (OJ L 328, 21.12.2018, p. 82).

EN

- (70) The exclusion from the EU ETS of installations exclusively using biomass has led to situations where installations combusting a high share of biomass have obtained windfall profits by receiving free allowances greatly exceeding actual  emissions.  Therefore,  a  threshold  value  for  zero-rated  biomass  combustion  should  be  introduced,  above which installations are excluded from the EU ETS. The introduction of a threshold would provide more certainty as to which installations are under the EU ETS scope and would enable free allowances to be more evenly distributed to sectors more at risk of carbon leakage in particular. The threshold should be set at a level of 95 % to balance the advantages and disadvantages for installations of remaining under the scope of the EU ETS. Therefore, installations that have retained the physical capacity to burn fossil fuels should not be incentivised to revert to the use of such fuels. A threshold of 95 % would ensure that if an installation uses fossil fuels with the purpose of remaining within the scope of the EU ETS to benefit from free allocation allowances, the carbon costs related to the use of those fossil fuels would be sufficiently important to act as a disincentive.

That  threshold  would also  ensure  that  installations  using  a  sizeable  quantity of  fossil  fuels  will  remain  within  the monitoring obligations of the EU ETS, thus avoiding potential circumvention of existing monitoring, reporting and verification obligations. At the same time, installations which combust a lower share of zero-rated biomass should continue to be encouraged, through a flexible mechanism, to reduce fossil fuel combustion further while remaining under the scope of the EU ETS until their use of sustainable biomass is so substantial that their inclusion under the EU ETS is no longer justified. In addition, experience has shown that the exclusion of installations exclusively using biomass, effectively being a 100 % threshold except for the combustion of fossil fuels during start-up and shutdown phases, requires a reassessment and more precise definition. The 95 % threshold allows for the combustion of fossil fuels during start-up and shutdown phases.

- (71) In  order  to incentivise  the  uptake  of  low- and  zero-carbon technologies,  Member States  should provide operators with the options of remaining within the scope of the EU ETS until the end of the current and next five-year period referred to in Article 11(1) of Directive 2003/87/EC if the installation changes its production process to reduce its greenhouse gas emissions and no longer meets the threshold of 20 MW of total rated thermal input.
- (72) The  European  Securities  and  Markets  Authority  (ESMA)  published  its  final  report  on  emission  allowances  and associated derivatives on 28 March 2022. The report is a comprehensive analysis of the integrity of the European carbon market and has provided expertise and recommendations in relation to upholding the proper functioning of the  carbon  market.  In  order  to  continuously  monitor  market  integrity  and  transparency,  the  reporting  by  ESMA should  be  conducted  on  a  regular  basis.  ESMA  is  already  assessing  market  developments  and,  where  necessary, provides  recommendations,  in  the  area  of  its  competence,  in  its  report  on  trends,  risks  and  vulnerabilities  in accordance  with  Article  32(3)  of  Regulation  (EU)  No  1095/2010  of  the  European  Parliament  and  of  the Council ( 25 ). Analysis of the European carbon market, which includes the auctions of emission allowances, on-venue and over-the-counter trading in emission allowances and derivatives thereof, should be part of that annual reporting. This obligation would lead to streamlining of the reporting done by ESMA and allow for cross-market comparisons, in particular due to strong linkages between the EU ETS and commodity derivative markets.

Such regular analysis by ESMA should in particular monitor any market volatility and price evolution, the operation of  the  auctions  and  trading  operations  on  the  markets,  liquidity  and  the  volumes  traded,  and  the  categories  and trading  behaviour  of  market  participants,  including  speculative  activity  significantly  impacting  on  prices.  Its assessments should, where relevant, include recommendations to improve market integrity and transparency as well as  reporting  obligations,  and  to  enhance  the  prevention  and  detection  of  market  abuse  and  help  in  maintaining orderly markets for emission allowances and derivatives thereof. The Commission should take due account of the assessments and recommendations in the context of the annual carbon market report and, where necessary, in the reports to ensure the better functioning of the carbon market.

( 25 ) Regulation  (EU)  No  1095/2010  of  the  European  Parliament  and  of  the  Council  of  24  November  2010  establishing  a  European Supervisory Authority (European Securities and Markets Authority), amending Decision No 716/2009/EC and repealing Commission Decision 2009/77/EC (OJ L 331, 15.12.2010, p. 84).

EN

- (73) In order to further incentivise investments required for the decarbonisation of district heating and to address social aspects related to high energy prices and the high greenhouse gas emission intensity of district heating installations, in  Member  States  with  a  very  high  share  of  emissions  from  district  heating  in  comparison  with  the  size  of  the economy,  operators  should  be  able  to  apply  for  additional  transitional free allocation for district heating installations  and  the  additional  value  of  the  free  allocation  should  be  invested  to  significantly  reduce  emissions before 2030. To ensure those reductions take place, the additional transitional free allocation should be conditional on investments made and on emission reductions achieved as laid down in climate-neutrality plans to be drawn up by operators for their relevant installations.
- (74) Unexpected  or  sudden  excessive  price  increases  in  the  carbon  market  can  negatively  affect  market  predictability, which  is  essential  for  the  planning  of  decarbonisation  investments.  Therefore,  the  measure  which  applies  in  the event of excessive price fluctuations in the market for emissions allowance trading covered under Chapters II and III of Directive 2003/87/EC should be strengthened in a careful manner to improve its reactivity to unwarranted price fluctuations. If the triggering condition based on the increase in the average allowance price is met, this rule-based safeguard  measure  should  apply  automatically,  thereby  resulting  in  a  release  of  a  predetermined  number  of allowances from the market stability reserve established by Decision (EU) 2015/1814 of  the European Parliament and of the Council ( 26 ). The triggering condition should be closely monitored by the Commission and published on a monthly basis in order to improve transparency. To ensure the orderly auctioning of the allowances released from the market stability reserve pursuant to this safeguard measure and to improve market predictability, this measure should not apply again until at least twelve months after the end of the previous release of allowances in the market under the measure.
- (75) The  communication  of  the  Commission  of  17  September  2020 entitled  'Stepping  up  Europe's  2030  climate ambition - Investing in a climate-neutral future for the benefit of our people' underlined the particular challenge of reducing  the  emissions  in  the  buildings  and  road  transport  sectors.  Therefore,  the  Commission  announced  that  a further expansion of emissions trading could include emissions from buildings and road transport, while indicating that  covering  all  emissions  from  fuel  combustion  would  present  important  benefits.  Emissions  trading  should  be applied  to  fuels  used  for  combustion  in  the  buildings  and  road  transport  sectors  as  well  as  in  additional  sectors which correspond to industrial  activities  not  covered  by  Annex  I  to  Directive  2003/87/EC  such as  the  heating  of industrial  facilities  ('buildings,  road  transport  and  additional  sectors').  For  those  sectors,  a  separate  but  parallel emissions trading system should be established to avoid any disturbance of the well-functioning emissions trading system for stationary installations and aviation. The new system is accompanied by complementary policies shaping expectations  of  market participants  and  aiming  for  a  carbon  price  signal  for  the  whole  economy while  providing measures  to  avoid  undue  price  impacts.  Previous  experience  has  shown  that  the  development  of  the  new  system requires setting up an efficient monitoring, reporting and verification system. With a view to ensuring synergies and consistency with the existing Union infrastructure for  the EU ETS, it is appropriate to set up an emissions trading system for the buildings, road transport and additional sectors via an amendment to Directive 2003/87/ЕC.
- (76) In order  to establish the necessary implementation framework and to provide a reasonable timeframe for reaching the  2030  target,  emissions  trading  in  the  buildings,  road  transport  and  additional  sectors  should  start  in  2025. During the first years, the regulated entities should be required to hold a greenhouse gas emissions permit and to report their emissions for the years 2024 to 2026. The issuance of allowances and compliance obligations for those entities should be applicable as from 2027. This sequencing would allow emissions trading in those sectors to start in  an  orderly  and  efficient  manner.  It  would  also  allow  the  measures  to  be  in  place  to  ensure  a  socially  fair introduction  of  emissions  trading  into  the  buildings,  road  transport  and  additional  sectors,  so  as  to  mitigate  the impact of the carbon price on vulnerable households and transport users.
- (77) Due  to  the  very  large  number  of  small  emitters  in  the  buildings,  road  transport  and  additional  sectors,  it  is  not possible to establish the point of regulation at the level of entities directly emitting greenhouse gases, as is the case for stationary installations and aviation. Therefore, for reasons of technical feasibility and administrative efficiency, it is more appropriate to establish the point of regulation further upstream in the supply chain. The act that triggers the compliance obligation under  the new emissions trading system should be the release for consumption of fuels which  are  used  for  combustion  in  the  buildings  and  road  transport  sectors,  including  for  road  transport  of

( 26 ) Decision  (EU)  2015/1814  of  the  European  Parliament  and  of  the  Council  of  6  October  2015  concerning  the  establishment  and operation of a market stability reserve for  the Union greenhouse gas emission trading scheme and amending Directive 2003/87/EC (OJ L 264, 9.10.2015, p. 1).

EN

16.5.2023

greenhouse gases for the purpose of their geological storage, as well as in the additional sectors which correspond to industrial  activities  not  covered  by  Annex  I  to  Directive  2003/87/EC.  To  avoid  double  coverage,  the  release  for consumption of fuels which are used in activities under Annex I to that Directive should not be covered.

- (78) The regulated entities in the buildings, road transport and additional sectors and the point of regulation should be defined  in  line  with  the  system  of  excise  duty  established  by  Council  Directive  (EU)  2020/262 ( 27 ), with  the necessary adaptations, as that Directive already lays down a robust control system for all quantities of fuels released for consumption for  the purposes of paying excise duties. Final consumers of fuels in those sectors should not be subject to obligations under Directive 2003/87/EC.
- (79) The regulated entities falling within the scope of the emissions trading system in the buildings, road transport and additional  sectors  should  be  subject  to  similar  greenhouse  gas  emissions  permit  requirements  as  the  operators  of stationary  installations.  It  is  necessary  to  establish  rules  on  permit  applications,  conditions  for  permit  issuance, content,  and  review,  and  any  changes  related  to  the  regulated  entity.  In  order  for  the  new  system  to  start  in  an orderly manner, Member States should ensure that regulated entities falling within the scope of the new emissions trading system have a valid permit as of the start of the system in 2025.
- (80) The total quantity of allowances for the new emissions trading system should follow a linear trajectory to reach the emission  reduction  target  for  2030,  taking  into  account  the  cost-efficient  contribution  of  the  buildings  and  road transport  sectors  of  43  %  emission  reductions  by  2030  compared  to  2005  and  of  the  additional  sectors,  a combined cost-efficient contribution of 42 % emission reductions by 2030 compared to 2005. The total quantity of allowances should be established for the first time in 2027, to follow a trajectory starting in 2024 from the value of the 2024 emissions limits, calculated in accordance with Article 4(2) of Regulation (EU) 2018/842 of the European Parliament and of the Council ( 28 ) on the basis of the reference emissions for the sectors covered for 2005 and the period from 2016 to 2018 as determined under Article 4(3) of that Regulation. Accordingly, the linear  reduction factor should be set at 5,10 %. From 2028, the total quantity of allowances should be set on the basis of the average reported emissions for the years 2024, 2025 and 2026, and should decrease by the same absolute annual reduction rate  as  set  from  2024,  which  corresponds  to a  5,38  %  linear  reduction  factor  compared to the  comparable  2025 value  of  the  above  defined  trajectory.  If  those  emissions  are  significantly  higher  than  that  trajectory  value  and  if such divergence is not due to small-scale differences in emission measurement methodologies, the linear reduction factor should be adjusted to reach the required level of emission reduction in 2030.
- (81) The  auctioning  of  allowances  is  the  simplest  and  the  most  economically  efficient  method  for  allocating  emission allowances, and also avoids windfall profits. Both the buildings and road transport sectors are under relatively little or  non-existent  competitive  pressure  from  outside  the  Union  and  are  not  exposed  to  a  risk  of  carbon  leakage. Therefore, allowances for buildings and road transport should only be allocated via auctioning, without there being any free allocation.
- (82) In  order  to  ensure  a  smooth  start  to  the  new  emissions  trading  system  and  taking  into  account  the  need  of  the regulated  entities  to  hedge  or  buy  ahead  allowances  to  mitigate  their  price  and  liquidity  risk,  a  higher  amount  of allowances should be auctioned early on. In 2027, the auction volumes should therefore be 30 % higher  than the total  quantity  of  allowances  for  2027.  This  amount  would  be  sufficient  to  provide  liquidity,  both  if  emissions decrease in line with the reductions needed, and in the event that emission reductions only materialise progressively. The  detailed  rules  for  that  front-loading  of  auction  volumes  should  be  established  in  a  delegated  act  related  to auctioning, adopted pursuant to Article 10(4) of Directive 2003/87/EC.

( 27 ) Council Directive (EU) 2020/262 of 19 December 2019 laying down the general arrangements for excise duty (OJ L 58, 27.2.2020, p. 4).

( 28 ) Regulation  (EU)  2018/842  of  the  European  Parliament  and  of  the  Council  of  30  May  2018  on  binding  annual  greenhouse  gas emission  reductions  by  Member  States  from  2021  to  2030  contributing  to  climate  action  to  meet  commitments  under  the  Paris Agreement and amending Regulation (EU) No 525/2013 (OJ L 156, 19.6.2018, p. 26).

EN

- (83) The  distribution  rules  on  auction  shares  are  highly  relevant  for  any  auction  revenues  that  would  accrue  to  the Member States, especially in view of  the need to strengthen  the ability of  the Member States to address the social impacts  of  a  carbon  price  signal  in  the  buildings  and  road  transport  sectors.  Notwithstanding  the  fact  that  those buildings, road transport and additional sectors have very different characteristics, it is appropriate to set a common distribution rule similar  to the one applicable to stationary installations. The majority of the allowances should be distributed among  all Member  States  on  the  basis of the average distribution of the emissions in road transportation,  commercial  and  institutional  buildings  and  residential  buildings,  during  the  period  from  2016  to 2018.
- (84) The introduction of the carbon price in the buildings and road transport sectors should be accompanied by effective social compensation, especially in view of the existing levels of energy poverty. About 34 million Europeans, nearly 6,9 % of the Union population, have said that they cannot afford to heat their home sufficiently in a 2021 Unionwide  survey.  To  achieve  effective  social  and  distributional  compensation,  Member  States  should  be  required  to spend the auction revenues from emissions trading for  the buildings, road transport and additional sectors on the climate  and  energy-related  purposes  already  specified  for  the  existing  emissions  trading  system,  giving  priority  to activities  that  can  contribute to  addressing  social  aspects  of  the  emissions  trading  in  the  buildings,  road  transport and  additional  sectors,  or  for  measures  added  specifically  to  address  related  concerns  for  those  sectors,  including related policy measures under Directive 2012/27/EU.

A  new  Social  Climate  Fund  established  by  Regulation  (EU)  2023/955  of  the  European  Parliament  and  of  the Council ( 29 ) will  provide  dedicated  funding  to  Member  States  to  support  the  most  affected  vulnerable  groups, especially households in energy or transport poverty. The Social Climate Fund will promote fairness and solidarity between and within Member States while mitigating the risk of energy and transport poverty during the transition. It will build on  and  complement  existing  solidarity mechanisms,  in  synergy with other Union  spending programmes and funds. 50 million allowances from the EU ETS pursuant to Article 10a(8b) of Directive  2003/87/EC  and  150  million  allowances  from  emissions  trading  in  the  buildings,  road  transport  and additional  sectors,  and  revenue  generated  from  the  auctioning  of  allowances  concerning  the  buildings,  road transport and additional sectors, up to a maximum of EUR 65 000 000 000, should be used for the financing of the Social  Climate  Fund  in  the  form  of  external  assigned  revenue  on  a  temporary  and  exceptional  basis,  pending  the discussions  and  deliberations  on  the  Commission's  proposal  of  22  December  2021 for  a  Council  Decision amending Decision (EU, Euratom) 2020/2053 on the system of own resources of the European Union concerning the  establishment  of  a  new  own  resource  based  on  the  EU  ETS  in  accordance  with  Article  311,  third  paragraph, TFEU.

It  is  necessary  to provide that, where a decision is adopted in accordance with Article 311, third paragraph, TFEU establishing that new own resource, the same revenue should cease to be externally assigned when such a decision enters into force. With regard to the Social Climate Fund, the Commission is, in the event of the adoption of such a decision,  to  present,  as  appropriate,  the  necessary  proposals  in  accordance  with  Article  27(4)  of  Regulation (EU)  2023/955.  This  is  without  prejudice  to  the  outcome  of  the  post-2027  Multiannual  Financial  Framework negotiations.

- (85) Reporting on the use of auctioning revenues should be aligned with the current reporting established by Regulation (EU) 2018/1999.
- (86) Regulated  entities  covered  by  the  new  emissions  trading  system  should  surrender  allowances  for  their  verified emissions  corresponding  to  the  quantities  of  fuels  they  have  released  for  consumption.  They  should  surrender allowances for the first time for their verified emissions in 2027. In order to minimise the administrative burden, a number of rules applicable to the existing emissions trading system for stationary installations and aviation should be  made  applicable  to  the  new  emissions  trading  system  for  the  buildings,  road  transport  and  additional  sectors, with  the  necessary  adaptations.  This  includes,  in  particular,  rules  on  transfer,  surrender  and  cancellation  of allowances,  as  well  as  the  rules  on  the  validity  of  allowances,  penalties,  competent  authorities  and  reporting obligations of Member States.

( 29 ) Regulation (EU) 2023/955 of  the European Parliament and of  the Council of 10 May 2023 establishing a Social Climate Fund and amending Regulation (EU) 2021/1060 (see page 1 of this Official Journal).

EN

- (87) Certain Member States already have national carbon taxes that apply to the buildings, road transport and additional sectors covered by Annex III to Directive 2003/87/EC. Therefore, a temporary derogation should be introduced until the end of 2030. To ensure the objectives of Directive 2003/87/EC are achieved and that the new emissions trading system is coherent, the option of applying that derogation should only be available where the national tax rate is higher than the average auctioning price for the relevant year, and should only apply to the surrender obligation of the  regulated  entities  paying  such  a  tax.  To  ensure  stability  and  transparency  of  the  system,  the  national  tax, including the relevant tax rates, should be notified to the Commission by the end of the transposition period of this Directive.  The  derogation  should  not  affect  the  external  assigned  revenue  for  the  Social  Climate  Fund  or,  if established  in  accordance  with  Article  311,  third  paragraph,  TFEU,  an  own  resource  based  on  the  auctioning revenues from emissions trading in the buildings, road transport and additional sectors.
- (88) For emissions trading in the buildings, road transport and additional sectors to be effective, it should be possible to monitor emissions with high certainty and at reasonable cost. Emissions should be attributed to regulated entities on the basis of fuel quantities released for consumption and combined with an emission factor. Regulated entities should  be  able  to  reliably  and  accurately  identify  and  differentiate  the  sectors  in  which  the  fuels  are  released  for consumption, as well as the final users of the fuels, in order to avoid undesirable effects, such as a double burden. In the small number of cases where double counting between emissions in the existing EU ETS and the new emissions trading system for the buildings, road transport and additional sectors cannot be avoided, or where costs arise due to the  surrender  of  allowances  for  emissions  from  activities  not  covered  by  Directive  2003/87/EC,  Member  States should  use  such  revenue  to  compensate  for  the  unavoidable  double  counting  or  other  such  costs  outside  the buildings,  road  transport  and  additional  sectors  in  accordance  with  Union  law.  Implementing  powers  should therefore  be  conferred  on  the  Commission  to  ensure  uniform  conditions  for  avoiding  double  counting  and allowances  being  surrendered  for  emissions  not  covered  by  the  emissions  trading  system  for  buildings,  road transport and additional sectors, and for providing financial compensation. To further mitigate any issues of double counting, the deadlines for monitoring and surrendering in the new emissions trading system should be one month after the deadlines in the existing system for stationary installations and aviation. To have sufficient data to establish the total quantity of allowances for the period from 2028 to 2030, the regulated entities holding a permit at the start of the system in 2025 should report their associated historical emissions for 2024.
- (89) Transparency as regards carbon costs and the extent to which they are passed on to consumers is of key importance for  enabling  swift  and  cost-efficient  emission  reductions  in  all  sectors  of  the  economy.  This  is  of  particular importance  in  an  emissions  trading  system  which  is  based  on  upstream  obligations.  The  new  emissions  trading system is meant to incentivise regulated entities to reduce the carbon content of the fuels, and such entities should not  make undue profits by passing on more carbon costs to consumers than they incur. While full auctioning of emissions  allowances  under  the  emissions  trading  system  for  the  buildings,  road  transport  and  additional  sectors already limits the occurrence of such undue profits, the Commission should monitor the extent to which regulated entities pass on carbon costs, so that windfall profits are avoided. In relation to Chapter IVa, the Commission should report annually, where possible by type of fuel, on the average level of the carbon costs which have been passed on to consumers in the Union.
- (90) It is appropriate to introduce measures to address the potential risk of excessive price increases, which, if particularly high at the start of the new emissions trading system, may undermine the readiness of households and individuals to invest in reducing their greenhouse gas emissions. Those measures should complement the safeguards provided by the market stability reserve and that became operational in 2019. While the market will continue to determine the carbon price, safeguard measures will be triggered by a rules-based automatic mechanism, whereby allowances will be  released  from  the  market  stability  reserve  only  if  one  or  more  concrete  triggering  conditions  based  on  the increase in the average allowance price are met. This additional mechanism should also be highly reactive, in order to  address  excessive  volatility  due  to  factors  other  than  changed  market  fundamentals.  The  measures  should  be adapted  to  different  levels  of  excessive  price  increase,  which  will  result  in  different  degrees  of  intervention.  The triggering conditions should be closely monitored by the Commission and the measures should be adopted by the Commission  as  a  matter  of  urgency  when  those  conditions  are  met.  This  should  be  without  prejudice  to  any accompanying measures that Member States might adopt to address adverse social impacts.

EN

- (91) In  order  to  increase  certainty  for  citizens  that  the  carbon  price  in  the  initial  years  of  the  new  emissions  trading system does not go above EUR 45, it is appropriate to include  an additional  price  stability  mechanism  to release allowances  from  the  market  stability  reserve  in  the  event  the  carbon  price  exceeds  that  level.  In  principle,  the measure should apply once during a period of 12 months. However, it should also be able to apply again during the same period of 12 months where the Commission, assisted by the Climate Change Committee, considers that the evolution  of  the  price  justifies  another  release  of  allowances.  In  view  of  the  aim  of  this  mechanism  to  ensure stability in the initial years of the new emissions trading system, the Commission should assess its functioning and whether it should be continued after 2029.
- (92) As an additional safeguard mechanism ahead of the start of emissions trading in the buildings, road transport and additional sectors, it should be possible to delay the application of the cap and the surrendering obligations where gas  or  oil  wholesale  prices  are  exceptionally  high  compared  to  historical  trends.  The  mechanism  should  be automatic, meaning that the application of the cap and the surrendering obligations is to be delayed by one year if concrete  energy  price  triggers  are  met.  The  reference  prices  should  be  determined  on  the  basis  of  benchmark contracts  in  the  gas  and  oil  wholesale  markets  which  are  immediately  available  and  the  most  relevant  for  final consumers.  Separate  trigger  conditions  for  gas  and  oil  prices  should  be  envisaged,  as  their  price  developments follow different historical trends. In order to ensure market certainty, the Commission should provide clarity on the application of the delay sufficiently in advance, through a notice in the Official Journal of the European Union .
- (93) The application of emissions trading in the buildings, road transport and additional sectors should be monitored by the  Commission,  including  the  degree  of  price  convergence  with  the  existing  EU  ETS,  and,  if  necessary,  a  review should be proposed to the European Parliament and to the Council to improve the effectiveness, administration and practical application of emissions trading for those sectors on the basis of acquired knowledge as well as increased price  convergence.  The  Commission  should  be  required  to  submit  the  first  report  on  those  matters  by  1  January 2028.
- (94) In order to ensure uniform  conditions for the implementation  of  Article 3ga(2), Article 3gf(2) and  (4), Article 10b(4), Article 12(3-d) and (3-c), Article 14(1), Article 30f(3) and (5) and Article 30h(7) of Directive 2003/87/EC, implementing powers should be conferred on the Commission. To ensure synergies with the existing regulatory framework, the conferral of implementing powers in Articles 14 and 15 of that Directive should be extended to cover the buildings, road transport and additional sectors. Those implementing powers, except the implementing powers in relation to Article 3gf(2) and Article 12(3-d) and (3-c) of Directive 2003/87/EC, should be exercised in accordance with Regulation (EU) No 182/2011 of the European Parliament and of the Council ( 30 ).
- (95) In  order  to  achieve  the  objectives  laid  down  in  this  Directive  and  other  Union  legislation,  particularly  those  in Regulation  (EU)  2021/1119,  the  Union  and  its  Member  States  should  make  use  of  the  latest  scientific  evidence while implementing policies. Therefore, when the European Scientific Advisory Board on Climate Change provides scientific advice and issues reports regarding the EU ETS, the Commission should take such advice and reports into account, in particular, as regards the need for additional Union policies and measures to ensure compliance with the objectives  and  targets  of  Regulation  (EU)  2021/1119,  and  additional  Union  policies  and  measures  in  view  of  the ambition and environmental integrity of global market-based measures for aviation and maritime transport.
- (96) To acknowledge the contribution of EU ETS revenues to the climate transition, an EU ETS label should be introduced. Among other  measures to ensure  the visibility of  funding  from  the  EU  ETS,  Member  States  and  the  Commission should ensure that projects and activities supported through the Modernisation Fund and the Innovation Fund are clearly indicated as coming from EU ETS revenues by displaying an appropriate label.

( 30 ) Regulation (EU) No 182/2011 of the European Parliament and of the Council of 16 February 2011 laying down the rules and general principles  concerning  mechanisms  for  control  by  Member  States  of  the  Commission's  exercise  of  implementing  powers  (OJ  L  55, 28.2.2011, p. 13).

EN

- (97) With a view to achieving the  climate-neutrality objective  set out  in  Article  2(1)  of  Regulation  (EU)  2021/1119,  a Union-wide climate target for 2040 should be set, based on a legislative proposal to amend that Regulation. The EU ETS should be reviewed to align it with the Union 2040 climate target. As a result, by July 2026 the Commission should report on several aspects of the EU ETS to the European Parliament and to the Council, accompanying the report, where appropriate, by a legislative proposal and impact assessment. In line with Regulation (EU)  2021/1119, priority  should be given to direct emission  reductions,  which  will  have to be  complemented  by increased carbon removals in order to achieve climate neutrality. Therefore, among other aspects, by July 2026 the Commission should  report  to  the  European  Parliament  and  to  the  Council  on  how  emissions  removed  from  the atmosphere and safely and permanently stored, for example through direct air capture, could potentially be covered by emissions  trading,  without  offsetting  necessary  emission  reductions.  Until  all  stages  of  the  life  of  a  product  in which captured carbon is used are subject to carbon pricing, in particular at the stage of waste incineration, reliance on  accounting  for  emissions  at  the  point  of  their  release  from  products  into  the  atmosphere  would  result  in emissions being undercounted.

In  order  to  regulate  the  capture  of  carbon  in  a  way  that  reduces  net  emissions  and  ensures  that  all  emissions  are accounted for and that double counting is avoided, while generating economic incentives, the Commission should assess,  by  July  2026,  whether  all  greenhouse  gas  emissions  covered  by  Directive  2003/87/EC  are  effectively accounted for, and whether double counting is effectively avoided. In particular, it should assess the accounting for the greenhouse gas emissions which are considered to have been captured and utilised in a product in a way other than that referred to in Article 12(3b), and take into account the downstream stages, including disposal and waste incineration.  Finally,  the  Commission  should  also  report  to  the  European  Parliament  and  to  the  Council  on  the feasibility of lowering  the 20  MW  total  rated  thermal  input  thresholds  for the activities in Annex  I  to Directive 2003/87/EC, taking into account the environmental benefits and administrative burden.

- (98) By July 2026, the Commission should also assess and report to the European Parliament and to the Council on the feasibility  of  including  municipal  waste  incineration  installations  in  the  EU  ETS,  including  with  a  view  to  their inclusion from 2028, and provide an assessment of the potential need for an option for a Member State to opt out until  the  end  of  2030,  taking  into  account  the  importance  of  all  sectors  contributing  to  emission  reductions. Inclusion of municipal waste incineration installations in the EU ETS would contribute to the circular economy by encouraging recycling, reuse and repair of products, while also contributing to economy-wide decarbonisation. The inclusion  of  municipal  waste  incineration  installations  would  reinforce  incentives  for  sustainable  management  of waste in line with the waste hierarchy and would create a level playing field between the regions that have included municipal waste incineration under the scope of the EU ETS.

To avoid diversion of waste from municipal waste incineration installations towards landfills in the Union, which create  methane emissions, and to avoid exports of waste to third countries, with a potentially negative impact on the  environment,  in  its  report  the  Commission  should  take into account  the  potential  diversion  of  waste towards disposal  by  landfilling  in  the  Union  and  waste  exports  to  third  countries.  The  Commission  should  also  take  into account the effects on the internal market, potential distortions of competition, environmental integrity, alignment with the objectives of Directive 2008/98/EC of the European Parliament and of the Council ( 31 ) and robustness and accuracy  with  respect  to  the  monitoring  and  calculation  of  emissions.  Considering  the  methane  emissions  from landfilling  and  to  avoid  creating  an  uneven  playing  field,  the  Commission  should  also  assess  the  possibility  of including  other  waste  management  processes,  such  as  landfilling,  fermentation,  composting  and  mechanicalbiological  treatment,  in  the  EU  ETS,  when  assessing  the  feasibility  of  including  municipal  waste  incineration installations.

- (99) In order to adopt non-legislative acts of general application to supplement or amend certain non-essential elements of  a  legislative  act,  the  power  to  adopt  acts  in  accordance  with  Article  290  TFEU  should  be  delegated  to  the Commission in respect of the timing, administration and other aspects of auctioning, the rules on the application of conditionality,  the  rules  on  the  operation  of  the  Innovation  Fund,  the  rules  on  the  operation  of  the  competitive bidding  mechanism  in  relation  to  CDs  and  CCDs,  the  requirements  for  considering  that  greenhouse  gases  have become permanently chemically bound in a product and the extension of  the  activity  referred  to in  Annex  III  to Directive 2003/87/EC to other sectors. Moreover, to ensure synergies with the existing regulatory  framework, the delegation  in  Article  10(4)  of  Directive  2003/87/EC  concerning  the  timing,  administration  and  other  aspects  of

( 31 ) Directive 2008/98/EC of the European Parliament and of the Council of 19 November 2008 on waste and repealing certain Directives (OJ L 312, 22.11.2008, p. 3).

EN

auctioning  should  be  extended  to  cover  the  buildings,  road  transport  and  additional  sectors.  It  is  of  particular importance  that  the  Commission  carry  out  appropriate  consultations  during  its  preparatory  work,  including  at expert level, and that those consultations be conducted in accordance with the principles laid down in the Interinsti­ tutional Agreement of 13 April 2016 on Better Law-Making ( 32 ).  In  particular,  to ensure  equal participation in the preparation of delegated acts, the European Parliament and the Council receive all documents at the same time as Member  States'  experts,  and  their  experts  systematically  have  access  to  meetings  of  Commission  expert  groups dealing with the preparation of delegated acts.

- (100) The provisions relating to the existing EU ETS and its extension to maritime transport should apply from 2024 in line  with  the  need  for  urgent  climate  action  and  for  all  sectors  to  contribute  to  emission  reductions  in  a  costeffective  manner.  Consequently,  Member  States  should  transpose  the  provisions  relating  to  those  sectors  by 31 December 2023. However, the deadline for transposing the provisions relating to the emissions trading system for  the  buildings,  road  transport  and  additional  sectors  should  be  30  June  2024,  as  the  rules  on  monitoring, reporting, verification and permitting for  those sectors apply from 1 January 2025, and require sufficient time for orderly  implementation.  As  an  exception,  to  guarantee  transparency  and  robust  reporting,  Member  States  should transpose  the  obligation  to  report  on  historical  emissions  for  those  sectors  by  31  December  2023,  as  that obligation  relates  to  the  emissions  in  the  year  2024.  In  accordance  with  the  Joint  Political  Declaration  of 28  September  2011 of  Member  States  and  the  Commission  on  explanatory  documents ( 33 ),  Member  States  have undertaken  to  accompany,  in  justified  cases,  the  notification  of  their  transposition  measures  with  one  or  more documents  explaining  the  relationship  between  the  components  of  a  directive  and  the  corresponding  parts  of national transposition instruments. With regard to this Directive, the legislator considers the transmission of such documents to be justified.
- (101) A well-functioning, reformed EU ETS comprising an instrument to stabilise the market is a key means for the Union to achieve the economy-wide net greenhouse gas emission reduction target for 2030, the Union's climate-neutrality objective by  2050  at  the  latest, and  the  aim  of  achieving  negative emissions  thereafter  as laid down  in Regulation (EU) 2021/1119, as well as the objectives of the Paris Agreement. The market stability reserve seeks to address the imbalance between  supply and demand  of  allowances in the market. Article 3 of Decision (EU)  2015/1814  provides  that  the  reserve  is  to  be  reviewed  three  years  after  it  becomes  operational,  paying particular attention to the percentage figure for the determination of the number of allowances to be placed in the market stability reserve, the threshold for the total number of allowances in circulation (TNAC) that determines the intake  of  allowances,  and  the  number  of  allowances  to  be  released  from  the  reserve.  The  current  threshold determining the placing of allowances in the market stability reserve was established in 2018, with the last review of  the  EU  ETS,  while  the  linear  reduction  factor  is  being  increased  with  this  Directive.  Therefore,  as  part  of  the regular review of the functioning of the market stability reserve, the Commission should also assess the need for a potential adjustment of that threshold, in line with the linear factor referred to in Article 9 of Directive 2003/87/EC.
- (102) Considering the need to deliver a stronger investment signal to reduce emissions in a cost-efficient manner and with a view to strengthening the EU ETS, Decision (EU) 2015/1814 should be amended so as to increase the percentage rate for determining the number of allowances to be placed each year in the market stability reserve. In addition, for lower  levels  of  the  TNAC,  the  intake  should  be  equal  to  the  difference  between  the  TNAC  and  the  threshold  that determines the intake of allowances. This would prevent the considerable uncertainty in the auction volumes that results when the TNAC is close to the threshold, and at the same time ensure that the surplus reaches the volume bandwidth within which the carbon market is deemed to operate in a balanced manner.
- (103) Furthermore,  in  order  to  ensure  that  the  level  of  allowances  that  remains  in  the  market  stability  reserve  after  the invalidation  is  predictable,  the  invalidation  of  allowances  in  the  reserve  should  no  longer  depend  on  the  auction volumes of the previous year. The number of allowances in the reserve should, therefore, be fixed at a level of 400 million allowances, which corresponds to the lower threshold for the value of the TNAC.

( 32 ) OJ L 123, 12.5.2016, p. 1.

( 33 ) OJ C 369, 17.12.2011, p. 14.

EN

16.5.2023

- (104) The analysis of the impact assessment accompanying the proposal for this Directive has also shown that net demand from aviation should be included in the TNAC. In addition, since aviation allowances can be used in the same way as general allowances, including aviation in the reserve would make it a more accurate, and thus a better, tool to ensure the stability of the market. The calculation of the TNAC should include aviation emissions and allowances issued in respect of aviation as of the year following the entry into force of this Directive.
- (105) To clarify the calculation of the TNAC, Decision (EU) 2015/1814 should specify that only allowances issued and not put in the market stability reserve are included in the supply of allowances. Moreover, the formula should no longer subtract the number of allowances in the market stability reserve from the supply of allowances. This change would have no material impact on the result of the calculation of the TNAC, including on the past calculations of the TNAC or on the reserve.
- (106) In order to mitigate the risk of supply and demand imbalances associated with the start of emissions trading for the buildings,  road  transport  and  additional  sectors,  as  well  as  to  render  it  more  resistant  to  market  shocks,  the  rulebased  mechanism  of  the  market  stability  reserve  should  be  applied  to  those  sectors.  For  that  reserve  to  be operational  from  the  start  of  the  system,  it  should  be  established  with  an  initial  endowment  of  600  million allowances for emissions trading in the buildings, road transport and additional sectors. The initial lower and upper thresholds, which trigger the release or intake of allowances from the reserve, should be subject to a general review clause. Other elements such as the publication of the TNAC or the quantity of allowances released or placed in the reserve should follow the rules of the reserve for other sectors.
- (107) Since the objectives of this Directive, namely to promote reductions of greenhouse gas emissions in a cost-effective and  economically efficient  way  in  a  manner  commensurate  with  the  economy-wide  net  greenhouse  gas  emission reduction  target  for  2030  through  an  extended  and  amended  Union  wide  market-based  mechanism,  cannot  be sufficiently  achieved  by  the  Member  States  but  can  rather,  by  reason  of  its  scale  and  effects,  be  better  achieved  at Union level, the Union may adopt measures, in accordance with the principle of subsidiarity as set out in Article 5 of the Treaty on European Union. In accordance with the principle of proportionality as set out in that Article, this Directive does not go beyond what is necessary in order to achieve those objectives.
- (108) Directive 2003/87/EC and Decision (EU) 2015/1814 should therefore be amended accordingly,

HAVE ADOPTED THIS DIRECTIVE:

Article 1

## Amendments to Directive 2003/87/EC

Directive 2003/87/EC is amended as follows:

- (1) in Article 1, the second paragraph is replaced by the following:

'This Directive also provides for the reductions of greenhouse gas emissions to be increased so as to contribute to the levels of reductions that are considered scientifically necessary to avoid dangerous climate change. It contributes to the  achievement  of  the  Union's  climate-neutrality  objective  and  its  climate  targets  as  laid  down  in  Regulation (EU)  2021/1119  of  the  European  Parliament  and  of  the  Council  (*)  and  thereby  to  the  objectives  of  the  Paris Agreement (**).

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation (EU)  2021/1119  of  the  European  Parliament  and  of  the  Council  of  30  June  2021  establishing  the framework for achieving climate neutrality and amending Regulations (EC) No 401/2009 and (EU) 2018/1999 ('European Climate Law') (OJ L 243, 9.7.2021, p. 1).
- (**) OJ L 282, 19.10.2016, p. 4.';

EN

- (2) in Article 2, paragraphs 1 and 2 are replaced by the following:
- '1. This Directive shall apply to the activities listed in Annexes I and III, and to the greenhouse gases listed in Annex II.  Where an installation that is included within the scope of  the EU ETS due to the operation of combustion units with  a  total  rated  thermal  input  exceeding  20  MW  changes  its  production  processes  to  reduce  its  greenhouse  gas emissions and no longer  meets that threshold, the Member State in which that installation is situated shall provide the operator with the options of remaining within the scope of the EU ETS until the end of the current and next fiveyear period referred to in Article 11(1), second subparagraph, following the change to its production processes. The operator of that installation may decide that the installation is to remain within the scope of the EU ETS until the end of  the  current  five-year  period  only  or  also  of  the  next  five-year  period,  following  the  change  to  its  production processes.  The  Member State concerned shall notify the Commission of changes compared to the list submitted to the Commission pursuant to Article 11(1).
- 2. This  Directive  shall  apply  without  prejudice  to  any  requirements  pursuant  to  Directive  2010/75/EU  of  the European Parliament and of the Council (*).

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Directive  2010/75/EU  of  the  European  Parliament  and  of  the  Council  of  24  November  2010  on  industrial emissions (integrated pollution prevention and control) (OJ L 334, 17.12.2010, p. 17).';
- (3) Article 3 is amended as follows:
- (a) point (b) is replaced by the following:
- '(b) 'emissions'  means  the  release  of  greenhouse  gases  from  sources  in  an  installation  or  the  release  from  an aircraft  performing  an  aviation  activity  listed  in  Annex  I  or  from  ships  performing  a  maritime  transport activity listed in Annex I of the gases specified in respect of that activity, or the release of greenhouse gases corresponding to the activity referred to in Annex III;';
- (b) point (d) is replaced by the following:
- '(d) 'greenhouse gas emissions permit' means the permit issued in accordance with Articles 5, 6 and 30b;';
- (c) point (u) is deleted;
- (d) the following points are added:
- '(w) 'shipping company' means the shipowner or any other organisation or person, such as the manager or the bareboat  charterer,  that  has  assumed  the  responsibility  for  the  operation  of  the  ship  from  the  shipowner and that, on assuming such responsibility, has agreed to take over all the duties and responsibilities imposed by the International Management Code for the Safe Operation of Ships and for Pollution Prevention, set out in Annex I to Regulation (EC) No 336/2006 of the European Parliament and of the Council (*);
- (x) 'voyage' means a voyage as defined in Article 3, point (c), of Regulation (EU) 2015/757 of  the European Parliament and of the Council (**);
- (y) 'administering authority in respect of a shipping company'  means  the authority responsible for administering the EU ETS in respect of a shipping company in accordance with Article 3gf;
- (z) 'port  of  call'  means  the  port  where  a  ship  stops  to  load  or  unload  cargo  or  to  embark  or  disembark passengers,  or  the  port  where  an  offshore  ship  stops  to  relieve  the  crew;  stops  for  the  sole  purposes  of refuelling, obtaining supplies, relieving the crew of a ship other than an offshore ship, going into dry-dock or making repairs to the ship, its equipment, or both, stops in port because the ship is in need of assistance or  in  distress,  ship-to-ship  transfers  carried  out  outside  ports,  stops  for  the  sole  purpose  of  taking  shelter from adverse weather or rendered necessary by search and rescue activities, and stops of containerships in a neighbouring container transhipment port listed in the implementing act adopted pursuant to Article 3ga(2) are excluded;

EN

16.5.2023

- (aa) 'cruise  passenger  ship'  means  a  passenger  ship  that  has  no  cargo  deck  and  is  designed  exclusively  for commercial transportation of passengers in overnight accommodation on a sea voyage;
- (ab) 'contract  for  difference'  or  'CD'  means  a  contract  between  the  Commission  and  the  producer,  selected through a competitive bidding mechanism such as an auction, of a low- or zero-carbon product, and under which the producer is provided with support from the Innovation Fund covering the difference between the winning price, also known as the strike price, on the one hand, and a reference price derived from the price of  the  low-  or  zero-carbon product  produced,  the  market price  of a close  substitute,  or  a  combination  of those two prices, on the other hand;
- (ac) 'carbon  contract  for  difference'  or  'CCD'  means  a  contract  between  the  Commission  and  the  producer, selected through a competitive bidding mechanism such as an auction, of a low- or zero-carbon product, and under which the producer is provided with support from the Innovation Fund covering the difference between the winning price, also known as the strike price, on the one hand, and a reference price derived from the average price of allowances, on the other hand;
- (ad) 'fixed premium contract' means a contract between the Commission and the producer, selected through a competitive bidding mechanism such as an auction, of a low- or zero-carbon product, and under which the producer is provided with support in the form of a fixed amount per unit of the product produced;
- (ae) 'regulated entity'  for  the  purposes  of  Chapter  IVa  means  any  natural  or  legal  person,  except  for  any  final consumer of the fuels, that engages in the activity referred to in Annex III and that falls within one of the following categories:
- (i) where the fuel passes through a tax warehouse as defined in Article 3, point (11), of Council Directive (EU)  2020/262  (***),  the  authorised  warehousekeeper  as  defined  in  Article  3,  point  (1),  of  that Directive,  liable  to  pay  the  excise  duty  which  has  become  chargeable  pursuant  to  Article  7  of  that Directive;
- (ii) if  point  (i)  of  this  point  is  not  applicable,  any  other  person  liable  to  pay  the  excise  duty  which  has become  chargeable  pursuant to Article 7 of Directive (EU) 2020/262  or  Article 21(5), first subparagraph, of Council Directive 2003/96/EC (****) in respect of the fuels covered by Chapter IVa of this Directive;
- (iii) if  points  (i)  and  (ii)  of  this  point  are  not  applicable,  any other  person  that  has  to  be  registered  by  the relevant  competent authorities  of  the  Member  State  for  the  purpose  of  being liable  to  pay  the  excise duty, including any person exempt from paying the excise duty, as referred to in Article 21(5), fourth subparagraph, of Directive 2003/96/EC;
- (iv) if  points  (i),  (ii)  and  (iii)  are  not  applicable,  or  if  several  persons  are  jointly  and  severally  liable  for payment of the same excise duty, any other person designated by a Member State;
- (af) 'fuel' for the purposes of Chapter IVa of this Directive means any energy product referred to in Article 2(1) of  Directive 2003/96/EC, including the fuels listed in Table A and Table C of Annex I to that Directive, as well as any other product intended for use, offered for sale or used as motor fuel or heating fuel as specified in Article 2(3) of that Directive, including for the production of electricity;
- (ag) 'release for consumption' for the purposes of Chapter IVa of this Directive means release for consumption as defined in Article 6(3) of Directive (EU) 2020/262;
- (ah) 'TTF gas price' for  the  purposes of Chapter IVa means the price of  the gas futures month-ahead contract traded at the Title Transfer Facility (TTF) Virtual Trading Point, operated by Gasunie Transport Services B.V.;

EN

- (ai) 'Brent crude oil price' for the purposes of Chapter IVa means the futures month-ahead price for crude oil, used as a benchmark price for the purchase of oil.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation (EC) No 336/2006 of the European Parliament and of the Council of 15 February 2006 on the implementation  of  the  International  Safety  Management  Code  within  the  Community  and  repealing Council Regulation (EC) No 3051/95 (OJ L 64, 4.3.2006, p. 1).
- (**) Regulation  (EU)  2015/757  of  the  European  Parliament  and  of  the  Council  of  29  April  2015  on  the monitoring,  reporting  and  verification  of  carbon  dioxide  emissions  from  maritime  transport,  and amending Directive 2009/16/EC (OJ L 123, 19.5.2015, p. 55).
- (***) Council Directive (EU) 2020/262 of 19 December 2019 laying down the general arrangements for excise duty (OJ L 58, 27.2.2020, p. 4).
- (****) Council  Directive  2003/96/EC  of  27  October  2003  restructuring  the  Community  framework  for  the taxation of energy products and electricity (OJ L 283, 31.10.2003, p. 51).';
- (4) the title of Chapter II is replaced by the following:

' Aviation and Maritime Transport';

- (5) Article 3a is replaced by the following:

' Article 3a

## Scope

Articles  3b  to  3g  shall  apply  to  the  allocation  and  issue  of  allowances  in  respect  of  the  aviation  activities  listed  in Annex I. Articles 3ga to 3gg shall apply in respect of the maritime transport activities listed in Annex I.';

- (6) Article 3g is replaced by the following:

' Article 3g

## Monitoring and reporting plans

The administering Member State shall ensure that each aircraft operator submits to the competent authority in that Member  State  a  monitoring  plan  setting  out  measures  to  monitor  and  report  emissions  and  that  such  plans  are approved by the competent authority in accordance with the implementing acts referred to in Article 14.';

- (7) the following Articles are inserted:

' Article 3ga

## Scope of application to maritime transport activities

- 1. The allocation  of  allowances  and  the  application  of  surrender  requirements  in  respect  of  maritime  transport activities  shall  apply  in  respect  of  fifty  percent  (50  %)  of  the  emissions  from  ships  performing  voyages  departing from a port of call under the jurisdiction of a Member State and arriving at a port of call outside the jurisdiction of a Member State,  fifty  percent  (50  %)  of  the  emissions  from  ships  performing  voyages  departing  from  a  port  of  call outside the jurisdiction of a Member State and arriving at a port of call under the jurisdiction of a Member State, one hundred  percent  (100  %)  of  emissions  from  ships  performing  voyages  departing  from  a  port  of  call  under  the jurisdiction  of  a  Member  State  and  arriving  at  a  port  of  call  under  the  jurisdiction  of  a  Member  State,  and  one hundred percent (100 %) of emissions from ships within a port of call under the jurisdiction of a Member State.
- 2. The Commission shall, by 31 December 2023, by means of implementing acts establish a list of neighbouring container transhipment ports and update that list by 31 December every two years thereafter.

Those  implementing  acts  shall  list  a  port  as  a  neighbouring  container  transhipment  port  where  the  share  of transhipment of containers, measured in twenty-foot equivalent units, exceeds 65 % of the total container  traffic of that  port  during  the  most  recent  twelve-month  period  for  which  relevant  data  are  available  and  where  that  port  is located outside the Union but less than 300 nautical miles from a port under the jurisdiction of a Member State. For the purposes of this paragraph, containers shall be considered to be transhipped when they are unloaded from a ship

EN

to the port for the sole purpose of being loaded onto another ship. The list established by the Commission pursuant to the first subparagraph shall not include ports located in a third country for which that third country effectively applies measures equivalent to this Directive.

Those implementing acts shall be adopted in accordance with the examination procedure referred to in Article 22a(2).

- 3. Articles  9,  9a  and  10  shall  apply  to  maritime  transport  activities  in  the  same  manner  as  they  apply  to  other activities covered by the EU ETS with the following exception with regard to the application of Article 10.

Until  31  December  2030,  a  share  of  allowances  shall  be  attributed  to  Member  States  with  a  ratio  of  shipping companies  that  would  have  been  under  their  responsibility  pursuant  to  Article  3gf  compared  to  their  respective population in 2020 and based on data available for  the period from 2018 to 2020, above 15 shipping companies per million inhabitants. The quantity of allowances shall correspond to 3,5 % of the additional quantity of allowances due to the increase in the cap for maritime transport referred to in Article 9, third paragraph, in the relevant year. For the years 2024 and 2025, the quantity of allowances shall in addition be multiplied by the percentages applicable to the  relevant  year  pursuant  to  Article  3gb,  first  paragraph,  points  (a)  and  (b).  The  revenue  generated  from  the auctioning  of that share  of  allowances  should  be  used  for the purposes  referred  to  in  Article 10(3), first subparagraph, point (g), with regard to the maritime sector, and points (f) and (i). 50 % of the quantity of allowances shall  be  distributed  among  the  relevant  Member  States  based  on  the  share  of  shipping  companies  under  their responsibility and the remainder distributed in equal shares between them.

Article 3gb

## Phase-in of requirements for maritime transport

Shipping companies shall be liable to surrender allowances according to the following schedule:

- (a) 40 % of verified emissions reported for 2024 that would be subject to surrender requirements in accordance with Article 12;
- (b) 70 % of verified emissions reported for 2025 that would be subject to surrender requirements in accordance with Article 12;
- (c) 100 % of verified emissions reported for 2026 and each year thereafter in accordance with Article 12.

Where fewer allowances are surrendered compared to the verified emissions from maritime transport for  the years 2024 and 2025, once the difference between verified emissions and allowances surrendered has been established in respect  of  each  year,  an  amount  of  allowances  corresponding  to  that  difference  shall  be  cancelled  rather  than auctioned pursuant to Article 10.

Article 3gc

## Provisions for transfer of the costs of the EU ETS from the shipping company to another entity

Member States shall take the necessary measures to ensure that when the ultimate responsibility for the purchase of the fuel, or the operation of the ship, or both, is assumed by an entity other than the shipping company pursuant to a contractual arrangement, the shipping company is entitled to reimbursement from that entity for the costs arising from the surrender of allowances.

'Operation of the ship' for the purposes of this Article means determining the cargo carried or the route and the speed of the ship. The shipping company shall remain the entity responsible for surrendering allowances as required under Articles  3gb  and  12  and  for  overall  compliance  with  the  provisions  of  national  law  transposing  this  Directive. Member  States  shall  ensure  that  shipping  companies  under  their  responsibility  comply  with  the  obligations  to surrender allowances under Articles 3gb and 12, notwithstanding the entitlement of such shipping companies to be reimbursed by the commercial operators for the costs arising from the surrender.

EN

Article 3gd

## Monitoring and reporting of emissions from maritime transport

In  respect  of  emissions  from  maritime  transport  activities  listed  in  Annex  I  to  this  Directive,  the  administering authority in respect of a shipping company shall ensure that a shipping company under its responsibility monitors and  reports  the  relevant  parameters  during  a  reporting  period,  and  submits  to  it  aggregated  emissions  data  at company level in accordance with Chapter II of Regulation (EU) 2015/757.

Article 3ge

## Verification and accreditation rules for emissions from maritime transport

The administering authority in respect of a shipping company shall ensure that the reporting of aggregated emissions data at shipping company level submitted by a shipping company pursuant to Article 3gd of this Directive is verified in accordance with the verification and accreditation rules set out in Chapter III of Regulation (EU) 2015/757.

Article 3gf

## Administering authority in respect of a shipping company

- 1. The administering authority in respect of a shipping company shall be:
- (a) in the case of a shipping company registered in a Member State, the Member State in which the shipping company is registered;
- (b) in  the  case  of a  shipping company that is not registered in a Member State, the Member State with the greatest estimated  number  of  port  calls  from  voyages  performed  by  that  shipping  company  in  the  preceding  four monitoring years and falling within the scope set out in Article 3ga;
- (c) in the case of a shipping company that is not registered in a Member State and that did not carry out any voyage falling within the scope set out in Article 3ga in the preceding four monitoring years, the Member State where a ship of the shipping company has started or ended its first voyage falling within the scope set out in that Article.
- 2. Based on the best available information, the Commission shall establish by means of implementing acts:
- (a) before  1  February  2024,  a  list  of  shipping  companies  which  performed  a  maritime  transport  activity  listed  in Annex I that fell within the scope set out in Article 3ga on or  with effect from 1 January 2024, specifying the administering authority in respect of a shipping company in accordance with paragraph 1 of this Article;
- (b) before  1  February  2026 and  every  two  years  thereafter,  an  updated  list  to  reattribute  shipping  companies registered  in  a  Member  State  to  another  administering  authority  in  respect  of  a  shipping  company  if  they changed  the  Member  State  of  registration  within  the  Union  in  accordance  with  paragraph  1,  point  (a),  of  this Article or to include shipping companies which have subsequently performed a maritime transport activity listed in  Annex  I  that  fell  within  the  scope  set  out  in  Article  3ga,  in  accordance  with  paragraph  1,  point  (c),  of  this Article; and
- (c) before 1 February 2028 and every four years thereafter, an updated list to reattribute shipping companies that are not  registered  in  a  Member  State  to  another  administering  authority  in  respect  of  a  shipping  company  in accordance with paragraph 1, point (b), of this Article.
- 3. An administering authority in respect of a shipping company that, according to the list established pursuant to paragraph 2, is responsible for a shipping company shall retain that responsibility regardless of subsequent changes in the shipping company's activities or registration until those changes are reflected in an updated list.
- 4. The  Commission  shall  adopt  implementing  acts  to  establish  detailed  rules  relating  to  the  administration  of shipping  companies  by  administering  authorities  in  respect  of  a  shipping  company  under  this  Directive.  Those implementing acts shall be adopted in accordance with the examination procedure referred to in Article 22a(2).

EN

Article 3gg

## Reporting and review

- 1. In  the  event  of  the  adoption  by  the  International  Maritime  Organization  (IMO)  of  a  global  market-based measure to reduce greenhouse gas emissions from maritime transport, the Commission shall review this Directive in light of that adopted measure.

To that end, the Commission shall submit a report to the European Parliament and to the Council within 18 months of  the  adoption  of  such  a  global  market-based  measure  and  before  it  becomes  operational.  In  that  report,  the Commission shall examine the global market-based measure as regards:

- (a) its ambition in light of the objectives of the Paris Agreement;
- (b) its  overall  environmental  integrity,  including  in  comparison  with  the  provisions  of  this  Directive  covering maritime transport; and
- (c) any issue related to the coherence between the EU ETS and that measure.

Where  appropriate,  the  Commission  may  accompany  the  report  referred  to  in  the  second  subparagraph  of  this paragraph with a legislative  proposal  to  amend  this  Directive  in  a  manner  that  is  consistent  with  the  Union  2030 climate  target  and  the  climate-neutrality  objective  set  out  in  Regulation  (EU)  2021/1119,  and  with  the  aim  of preserving  the  environmental  integrity  and  effectiveness  of  Union  climate  action,  in  order  to  ensure  coherence between  the  implementation  of  the  global  market-based  measure  and  the  EU  ETS,  while  avoiding  any  significant double burden.

- 2. In  the  event  that  the  IMO  does  not  adopt  by  2028  a  global  market-based  measure  to  reduce  greenhouse  gas emissions  from  maritime  transport  in  line  with  the  objectives  of  the  Paris  Agreement  and  at  least  to  a  level comparable  to  that  resulting  from  the  Union  measures  taken  under  this  Directive,  the  Commission  shall  submit  a report to the European Parliament and to the Council in which it shall examine the need to apply the allocation of allowances  and  surrender  requirements  in  respect  of  more  than  fifty  percent  (50  %)  of  the  emissions  from  ships performing voyages between a port of call  under  the jurisdiction  of a  Member  State  and  a  port of  call  outside  the jurisdiction of a Member State, in light of the objectives of the Paris Agreement. In that report, the Commission shall, in  particular,  consider  progress  at  IMO  level  and  examine  whether  any  third  country  has  a  market-based  measure equivalent to this Directive and assess the risk of an increase in evasive practices, including through a shift to other modes of transport or a shift of port hubs to ports outside the Union.

Where appropriate, the report referred to in the first subparagraph shall be accompanied by a legislative proposal to amend this Directive.

- 3. The  Commission  shall  monitor  the  implementation  of  this  Chapter  in  relation  to  maritime  transport,  in particular  to  detect  evasive  behaviour  in  order  to  prevent  such  behaviour  at  an  early  stage,  including  giving consideration  to  outermost  regions,  and  report  biennially  from  2024  on  the  implementation  of  this  Chapter  in relation to maritime transport and possible trends regarding shipping companies seeking to evade the requirements of  this Directive. The Commission shall also monitor impacts regarding, inter alia, possible transport cost increases, market  distortions  and  changes  in  port  traffic,  such  as  port  evasion  and  shifts  of  transhipment  hubs,  the  overall competitiveness of  the maritime sector  in  the Member States, and in particular  impacts on those shipping services that constitute essential services of  territorial continuity. If appropriate, the Commission shall propose measures to ensure  the  effective  implementation  of  this  Chapter  in  relation  to  maritime  transport,  in  particular  measures  to address trends regarding shipping companies seeking to evade the requirements of this Directive.
- 4. No  later than  30  September  2028,  the  Commission  shall  assess  the  appropriateness  of  extending  the application  of  Article  3ga(3),  second  subparagraph,  beyond  31  December  2030 and,  if  appropriate,  submit  a legislative proposal to that effect.
- 5. No later than 31 December 2026, the Commission shall present a report to the European Parliament and to the Council in which it shall examine the feasibility and economic, environmental and social impacts of the inclusion in this Directive of emissions from ships, including offshore ships, below 5 000 gross tonnage but not below 400 gross tonnage,  building,  in  particular,  on  the  analysis  accompanying  the  review  of  Regulation  (EU)  2015/757  due  by 31 December 2024.

EN

That report shall also consider the interlinkages between this Directive and Regulation (EU) 2015/757 and draw on the  experience  gained  from  the  application  thereof.  In  that  report,  the  Commission  shall  also  examine  how  this Directive  can  best  account  for  the  uptake  of  renewable  and  low-carbon  maritime  fuels  on  a  lifecycle  basis.  If appropriate, the report may be accompanied by legislative proposals.';

- (8) Article 3h is replaced by the following:

' Article 3h

## Scope

The  provisions  of  this  Chapter  shall  apply  to  greenhouse  gas  emissions  permits  and  the  allocation  and  issue  of allowances in respect of activities listed in Annex I other than aviation activities and maritime transport activities.';

- (9) in Article 6(2), point (e) is replaced by the following:
- '(e) an  obligation  to  surrender  allowances  equal  to  the  total  emissions  of  the  installation  in  each  calendar  year,  as verified in accordance with Article 15, by the deadline laid down in Article 12(3).';
- (10) Article 8 is replaced by the following:

' Article 8

## Coordination with Directive 2010/75/EU

Member  States  shall  take  the  necessary  measures  to  ensure  that,  where  installations  carry  out  activities  that  are included  in  Annex  I  to  Directive  2010/75/EU,  the  conditions  and  procedure  for  the  issue  of  a  greenhouse  gas emissions  permit  are  coordinated  with  those  for  the  issue  of  a  permit  provided  for  in  that  Directive.  The requirements laid down in Articles 5, 6 and 7 of this Directive may be integrated into the procedures provided for in Directive 2010/75/EU.

The Commission shall review the effectiveness of synergies with Directive 2010/75/EU. Environmental and climaterelevant permits shall be coordinated to ensure efficient and speedier execution of measures needed to comply with Union climate and energy objectives. The Commission may submit a report to the European Parliament and to the Council in the context of any future review of this Directive.';

- (11) in Article 9, the following paragraphs are added:

'In  2024, the Union-wide quantity of allowances shall be decreased by 90 million allowances. In 2026, the Unionwide  quantity  of  allowances  shall  be  decreased  by  27  million  allowances.  In  2024,  the  Union-wide  quantity  of allowances  shall  be  increased  by  78,4  million  allowances  for  maritime  transport.  The  linear  factor  shall  be  4,3  % from 2024 to 2027 and 4,4 % from 2028. The linear factor shall also apply to the allowances corresponding to the average  emissions  from  maritime  transport  reported  in  accordance  with  Regulation  (EU)  2015/757  for  2018 and 2019 that are addressed in Article 3ga of this Directive. The Commission shall publish the Union-wide quantity of allowances by 6 September 2023.

From 1 January 2026 and 1 January 2027 respectively, the quantity of allowances shall be  increased  to take into account the coverage of greenhouse gas emissions other than CO 2 emissions from maritime transport activities and the  coverage  of  emissions  of offshore  ships,  based  on  their  emissions  for  the  most  recent  year  for  which  data  are available.  Notwithstanding  Article  10(1),  the  allowances  resulting  from  that  increase  shall  be  made  available  to support innovation in accordance with Article 10a(8).';

- (12) Article 10 is amended as follows:
- (a) in paragraph 1, the third subparagraph is replaced by the following:

'2 % of the total quantity of allowances between 2021 and 2030 shall be auctioned to establish a fund to improve energy efficiency and modernise the energy systems of certain Member States (the 'beneficiary Member States') as set  out  in  Article  10d  (the  'Modernisation  Fund').  The  beneficiary  Member  States  for  that  amount  of  allowances shall be the Member States with a GDP per capita at market prices below 60 % of the Union average in 2013. The funds corresponding to that amount of allowances shall be distributed in accordance with Part A of Annex IIb.

EN

16.5.2023

In  addition,  2,5  %  of  the  total  quantity  of  allowances  between  2024  and  2030  shall  be  auctioned  for  the Modernisation Fund. The beneficiary Member States for that amount of allowances shall be the Member States with a  GDP  per  capita  at  market  prices  below  75  %  of  the  Union  average  during  the  period  from  2016  to  2018.  The funds corresponding to that amount of allowances shall be distributed in accordance with Part B of Annex IIb.';

- (b) in paragraph 3, first subparagraph, the introductory part is replaced by the following:
- '3. Member States shall determine the use of revenues generated from the auctioning of allowances referred to in  paragraph  2  of  this  Article,  except  for  the  revenues  established  as  own  resources  in  accordance  with Article  311,  third  paragraph,  TFEU  and  entered  in  the  Union  budget.  Member  States  shall  use  those  revenues, with  the  exception  of the revenues  used  for the compensation  of  indirect  carbon  costs  referred  to  in Article  10a(6)  of  this  Directive,  or  the  equivalent  in  financial  value  of  those  revenues,  for  one  or  more  of  the following:';
- (c) in paragraph 3, first subparagraph, points (b) to (f) are replaced by the following:
- '(b) to develop renewable energies and grids for electricity transmission to meet the commitment of the Union to renewable energies and the Union targets on interconnectivity, as well as to develop other technologies that contribute  to  the  transition  to  a  safe  and  sustainable  low-carbon  economy,  and  to  help  to  meet  the commitment  of  the  Union  to  increase  energy  efficiency,  at  the  levels  agreed  in  relevant  legislative  acts, including the production of electricity from renewables self-consumers and renewable energy communities;
- (c) measures to avoid deforestation  and  support  the  protection  and  restoration  of  peatland,  forests  and  other land-based  ecosystems  or  marine-based  ecosystems,  including  measures  that  contribute  to  the  protection, restoration  and  better  management  thereof,  in  particular  as  regards  marine-protected  areas,  and  increase biodiversity-friendly afforestation and reforestation, including in developing countries that have ratified the Paris Agreement, and measures to transfer technologies and to facilitate adaptation to the adverse effects of climate change in those countries;
- (d) forestry and soil sequestration in the Union;
- (e) the  environmentally  safe  capture  and  geological  storage  of  CO ,  in  particular  from  solid  fossil  fuel  power 2 stations  and  a  range  of  industrial  sectors  and  subsectors,  including  in  third  countries,  and  innovative technological carbon removal methods, such as direct air capture and storage;
- (f) to invest in and accelerate the shift to forms of transport which contribute significantly to the decarbonisation  of  the  sector,  including  the  development  of  climate-friendly  passenger  and  freight  rail transport  and  bus  services  and  technologies,  measures  to  decarbonise  the  maritime  sector,  including  the improvement  of  the  energy  efficiency  of  ships,  ports,  innovative  technologies  and  infrastructure,  and sustainable alternative fuels, such as hydrogen and ammonia that are produced from renewables, and zeroemission  propulsion  technologies,  and  to  finance  measures  to  support  the  decarbonisation  of  airports  in accordance  with  a  Regulation  of  the  European  Parliament  and  of  the  Council  on  the  deployment  of alternative fuels infrastructure, and repealing Directive 2014/94/EU of  the European Parliament and of the Council, and a Regulation of  the European Parliament and of the Council on ensuring a level playing field for sustainable air transport;';
- (d) in paragraph 3, first subparagraph, point (h) is replaced by the following:
- '(h) measures intended to improve energy efficiency, district heating systems and insulation, to support efficient and renewable heating and cooling systems, or to support the deep and staged deep renovation of buildings in  accordance with Directive 2010/31/EU of the European Parliament and of the Council (*), starting with the renovation of the worst-performing buildings;

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Directive  2010/31/EU  of  the  European  Parliament  and  of  the  Council  of  19  May  2010  on  the  energy performance of buildings (OJ L 153, 18.6.2010, p. 13).';

EN

- (e) in paragraph 3, first subparagraph, the following points are inserted:
- '(ha) to provide financial support to address social aspects in lower- and middle-income households, including by reducing distortive taxes, and targeted reductions of duties and charges for renewable electricity;
- (hb) to finance national climate dividend schemes with a proven positive environmental impact as documented in the annual report referred to in Article 19(2) of Regulation (EU) 2018/1999 of the European Parliament and of the Council (*).

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation  (EU)  2018/1999  of  the  European  Parliament  and  of  the  Council  of  11  December  2018  on  the Governance  of  the  Energy  Union  and  Climate  Action,  amending  Regulations  (EC)  No  663/2009  and  (EC) No 715/2009 of the European Parliament and of the Council, Directives 94/22/EC, 98/70/EC, 2009/31/EC, 2009/73/EC,  2010/31/EU,  2012/27/EU  and  2013/30/EU  of  the  European  Parliament  and  of  the  Council, Council  Directives  2009/119/EC  and  (EU)  2015/652  and  repealing  Regulation  (EU)  No  525/2013  of  the European Parliament and of the Council (OJ L 328, 21.12.2018, p. 1).';
- (f) in paragraph 3, first subparagraph, point (k) is replaced by the following:
- '(k) to promote skill formation and reallocation of labour in order to contribute to a just transition to a climateneutral economy, in particular in regions most affected by the transition of jobs, in close coordination with the social partners, and to invest in upskilling and reskilling of workers potentially affected by the transition, including workers in maritime transport;
- (l) to address any residual risk of carbon leakage in the sectors covered by Annex I to Regulation (EU) 2023/956 of the European  Parliament  and  of  the  Council  (*),  supporting  the  transition  and  promoting  their decarbonisation in accordance with State aid rules.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation  (EU)  2023/956  of  the  European  Parliament  and  of  the  Council  of  10  May  2023  establishing  a carbon border adjustment mechanism (OJ L 130, 16.5.2023, p. 52).';
- (g) in paragraph 3, the following subparagraph is inserted after the first subparagraph:
- 'When determining the use of revenues generated from the auctioning of the allowances, Member States shall take into account the need to continue scaling up international climate finance in vulnerable third countries referred to in the first subparagraph, point (j).';
- (h) in paragraph 3, the second subparagraph is replaced by the following:
- 'Member  States  shall  be  deemed  to  have  fulfilled  the  provisions  of  this  paragraph  if  they  have  in  place  and implement  fiscal  or  financial  support  policies,  including  in  particular  in  developing  countries,  or  domestic regulatory policies, which  leverage financial support, established for the purposes set out in the first subparagraph and which have a value equivalent to the revenues referred to in the first subparagraph.';
- (i) in paragraph 3, the third subparagraph is replaced by the following:

'Member  States  shall  inform  the  Commission  as  to  the  use  of  revenues  and  the  actions  taken  pursuant  to  this paragraph  in  their  reports  submitted  under  Article  19(2)  of  Regulation  (EU)  2018/1999,  specifying,  where relevant and as appropriate, which revenues are used and the actions that are taken to implement their integrated national  energy  and  climate  plans  submitted  in  accordance  with  that  Regulation,  and  their  territorial  just transition  plans  prepared  in  accordance  with  Article  11  of  Regulation  (EU)  2021/1056  of  the  European Parliament and of the Council (*).

The  reporting  shall  be  sufficiently  detailed  to  enable  the  Commission  to  assess  the  Member  States'  compliance with the first subparagraph.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation (EU) 2021/1056 of the European Parliament and of the Council of 24 June 2021 establishing the Just Transition Fund (OJ L 231, 30.6.2021, p. 1).';

EN

- (j) in paragraph 4, the first subparagraph is replaced by the following:
- 'The  Commission  is  empowered  to  adopt  delegated  acts  in  accordance  with  Article  23  of  this  Directive  to supplement  this  Directive  concerning  the  timing,  administration  and  other  aspects  of  auctioning,  including modalities  for  auctioning  which  are  necessary  for  the  transfer  of  a  share  of  revenues  to  the  Union  budget  as external assigned revenue in accordance with Article 30d(4) of this Directive or as own resources in accordance with  Article  311,  third  paragraph,  TFEU,  in  order  to  ensure  that  it  is  conducted  in  an  open,  transparent, harmonised and non-discriminatory manner. To that end, the process shall be predictable, in particular as regards the timing and sequencing of auctions and the estimated amount of allowances to be made available.';
- (k) paragraph 5 is replaced by the following:
- '5. The Commission shall monitor the functioning of the European carbon market. Each year, it shall submit a report  to  the  European  Parliament  and  to  the  Council  on  the  functioning  of  the  carbon  market  and  on  other relevant  climate  and  energy  policies,  including  the  operation  of  the  auctions,  liquidity  and  the  volumes  traded, and  summarising  the  information  provided  by  the  European  Securities  and  Markets  Authority  (ESMA)  in accordance  with  paragraph  6  of  this  Article  and  the  information  provided  by  Member  States  on  the  financial measures referred to in Article 10a(6). If necessary, Member States shall ensure that any relevant information is submitted to the Commission at least two months before the Commission adopts the report.';
- (l) the following paragraph is added:
- '6. ESMA shall regularly monitor the integrity and transparency of the European carbon market, in particular with  regard  to  market  volatility  and  price  evolution,  the  operation  of  the  auctions,  trading  operations  on  the market  for  emission  allowances  and  derivatives  thereof,  including  over-the-counter  trading,  liquidity  and  the volumes traded, and the categories and trading behaviour of market participants, including positions of financial intermediaries.  ESMA  shall  include  the  relevant  findings  and,  where  necessary,  make  recommendations  in  its assessments to the European Parliament, to the Council, to the Commission and to the European Systemic Risk Board in accordance with Article 32(3) of Regulation (EU) No 1095/2010 of the European Parliament and of the Council (*). For the purposes of the tasks referred to in the first sentence of this paragraph, ESMA and the relevant competent  authorities  shall  cooperate  and  exchange  detailed  information  on  all  types  of  transactions  in accordance with Article 25 of Regulation (EU) No 596/2014 of the European Parliament and of the Council (**).

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation  (EU)  No  1095/2010  of  the  European  Parliament  and  of  the  Council  of  24  November  2010 establishing  a  European  Supervisory  Authority  (European  Securities  and  Markets  Authority),  amending Decision No 716/2009/EC and repealing Commission Decision 2009/77/EC (OJ L 331, 15.12.2010, p. 84).
- (**) Regulation (EU) No 596/2014 of the European Parliament and of the Council of 16 April 2014 on market abuse (market abuse regulation) and repealing Directive 2003/6/EC of the European Parliament and of the Council  and  Commission Directives  2003/124/EC,  2003/125/EC and 2004/72/EC (OJ L 173, 12.6.2014, p. 1).';
- (13) Article 10a is amended as follows:
- (a) paragraph 1 is amended as follows:
- (i) the following subparagraphs are inserted after the second subparagraph:
- 'If  an installation is covered by the obligation to conduct an energy audit or to implement a certified energy management  system  under  Article  8  of  Directive  2012/27/EU  of  the  European  Parliament  and  of  the Council (*) and if the recommendations of the audit report or of the certified energy management system are not implemented, unless the pay-back time for the relevant investments exceeds three years or unless the costs of those investments are disproportionate, then the amount of free allocation shall be reduced by 20 %. The amount of  free  allocation  shall  not  be  reduced  if  an  operator  demonstrates  that  it  has  implemented  other measures which lead to greenhouse gas emission reductions equivalent to those recommended by the audit report or by the certified energy management system for the installation concerned.

The Commission shall supplement this Directive by providing, in the delegated acts adopted pursuant to this paragraph  and  without  prejudice  to  the  rules  applicable  under  Directive  2012/27/EU,  for  administratively simple harmonised rules for the application of the third subparagraph of this paragraph that ensure that the application  of  the  conditionality  does  not  jeopardise  a  level  playing  field,  environmental  integrity  or  equal treatment  between  installations  across  the  Union.  Those  harmonised  rules  shall  in  particular  provide  for timelines, for criteria for the recognition of implemented energy efficiency measures as well as for alternative measures  reducing  greenhouse  gas  emissions,  using  the  procedure  for  national  implementing  measures  in accordance with Article 11(1) of this Directive.

In  addition  to the  requirements  set out  in the  third subparagraph of  this paragraph, the reduction by 20 % referred  to  in  that  subparagraph  shall  be  applied  where,  by  1  May  2024,  operators  of  installations  whose greenhouse gas emission levels are higher than the 80th percentile of emission levels for the relevant product benchmarks  have  not  established  a  climate-neutrality  plan  for  each  of  those  installations  for  its  activities covered by this Directive. That plan shall contain the elements specified in Article 10b(4) and be established in  accordance  with  the  implementing acts  provided for  in  that  Article.  Article  10b(4)  shall  be  read  as  only referring to the installation level. The achievement of the targets and milestones referred to in Article 10b(4), third subparagraph, point (b), shall be verified in respect of the period until 31 December 2025 and in respect of  each  period  ending  31  December  of  each  fifth  year  thereafter,  in  accordance  with  the  verification  and accreditation  procedures  provided  for  in  Article  15.  No  free  allowances  beyond  80  %  shall  be  allocated  if achievement of  the  intermediate  targets and  milestones has  not been verified  in  respect of  the  period  until the end of 2025 or in respect of the period from 2026 to 2030.

Allowances that are not allocated due to a reduction of free allocation in accordance with the third and fifth subparagraphs  of  this  paragraph  shall  be  used  to  exempt  installations  from  the  adjustment  in  accordance with paragraph 5 of this Article. Where any such allowances remain, 50 % of those allowances shall be made available  to  support  innovation  in  accordance  with  paragraph  8  of  this  Article.  The  other  50  %  of  those allowances shall be auctioned in accordance with Article 10(1) of  this Directive and Member States should use the respective revenues to address any residual risk of carbon leakage in the sectors covered by Annex I to Regulation (EU) 2023/956, supporting the transition and promoting their decarbonisation in accordance with State aid rules.

No free  allocation  shall  be  given  to  installations  in  sectors  or  subsectors  to  the  extent  they  are  covered  by other  measures  to  address  the  risk  of  carbon  leakage  as  established  by  Regulation  (EU)  2023/956.  The measures referred to in the first subparagraph of this paragraph shall be adjusted accordingly.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Directive  2012/27/EU  of  the  European  Parliament  and  of  the  Council  of  25  October  2012  on  energy efficiency,  amending  Directives  2009/125/EC  and  2010/30/EU  and  repealing  Directives  2004/8/EC and 2006/32/EC (OJ L 315, 14.11.2012, p. 1).';
- (ii) the third subparagraph is replaced by the following:

'For  each  sector  and  subsector,  in  principle,  the  benchmark  shall  be  calculated  for  products  rather  than  for inputs, in  order  to maximise greenhouse gas emission reductions and energy efficiency savings throughout each production process of the sector or the subsector concerned. In order to provide further incentives for reducing  greenhouse  gas  emissions  and  improving energy  efficiency  and  to  ensure  a  level  playing  field  for installations  using  new  technologies  that  partly  reduce  or  fully  eliminate  greenhouse  gas  emissions,  and installations  using  existing  technologies,  the  determined  Union-wide  ex-ante  benchmarks  shall  be  reviewed in  relation  to  their  application  in  the  period  from  2026  to  2030,  with  a  view  to  potentially  modifying  the definitions  and  system  boundaries  of  existing  product  benchmarks,  considering  as  guiding  principles  the circular  use-potential of materials and that the benchmarks should be independent of the feedstock and the type of production process, where the production processes have the same purpose. The Commission shall endeavour to adopt the implementing acts for the purpose of determining the revised benchmark values for free allocation in accordance with paragraph 2, third subparagraph, as soon as possible and before the start of the period from 2026 to 2030.';

EN

- (b) the following paragraph is inserted:
- '1a. Subject to the application of Regulation (EU) 2023/956, no free allocation shall be given in relation to the production of goods listed in Annex I to that Regulation.

By way of derogation from the first subparagraph of this paragraph, for the first years of application of Regulation (EU) 2023/956, the production of goods listed in Annex I to that Regulation shall benefit from free allocation in reduced amounts. A factor reducing the free allocation for the production of those goods shall be applied (CBAM factor). The CBAM factor shall be equal to 100 % for the period between the entry into force of that Regulation and the end of 2025 and, subject to the application of provisions referred to in Article 36(2), point (b), of that Regulation, shall be equal to 97,5 % in 2026, 95 % in 2027, 90 % in 2028, 77,5 % in 2029, 51,5 % in 2030, 39 % in 2031, 26,5 % in 2032 and 14 % in 2033. From 2034, no CBAM factor shall apply.

The reduction of free allocation shall be calculated annually as the average share of the demand for free allocation for the production of goods listed in Annex I to Regulation (EU) 2023/956 compared to the calculated total free allocation demand for all installations, for  the relevant period referred to in Article 11(1) of  this Directive. The CBAM factor shall be applied in this calculation.

Allowances  resulting  from  the  reduction  of  free  allocation  shall  be  made  available  to  support  innovation  in accordance with paragraph 8.

By 31 December 2024 and as part of its annual report to the European Parliament and to the Council pursuant to Article 10(5) of  this Directive, the Commission shall assess the carbon leakage risk for goods subject to CBAM and  produced  in  the  Union  for  export  to  third  countries  which  do  not  apply  the  EU  ETS  or  a  similar  carbon pricing mechanism. The report shall in particular assess the carbon leakage risk in sectors to which CBAM will apply,  in  particular  the  role  and  accelerated  uptake  of  hydrogen,  and  the  developments  as  regards  trade  flows and  the  embedded  emissions  of  goods  produced  by  those  sectors  on  the  global  market.  Where  the  report concludes that there is a carbon leakage risk for goods produced in the Union for export to third countries which do not apply the EU ETS or an equivalent carbon pricing mechanism, the Commission shall, where appropriate, submit a legislative proposal to address that carbon leakage risk in a manner that is compliant with the rules of the  World Trade Organization, including Article XX of  the General Agreement on Tariffs and Trade 1994, and takes into account the decarbonisation of installations in the Union.';

- (c) paragraph 2 is amended as follows:
- (i) in the third subparagraph, point (c) is replaced by the following:
- '(c) For the period from 2026 to 2030, the benchmark values shall be determined in the same manner as set out in points (a) and (d) of this subparagraph, taking into account point (e) of this subparagraph, on the basis of information submitted pursuant to Article 11 for the years 2021 and 2022 and on the basis of applying the annual reduction rate in respect of each year between 2008 and 2028.';
- (ii) in the third subparagraph, the following points are added:
- '(d) Where the annual reduction rate exceeds 2,5 % or is below 0,3 %, the benchmark values for the period from 2026 to 2030 shall be the benchmark values applicable in the period from 2013 to 2020 reduced by whichever of those two percentage rates is relevant, in respect of each year between 2008 and 2028.
- (e) For the period from 2026 to 2030, the annual reduction rate for the product benchmark for hot metal shall  not  be  affected  by  the  change  of  benchmark  definitions  and  system  boundaries  applicable pursuant to paragraph 1, eighth subparagraph.';
- (iii) the fourth subparagraph is replaced by the following:

'By  way of  derogation  regarding  the  benchmark  values  for  aromatics  and  syngas,  those  benchmark  values shall  be  adjusted  by  the  same  percentage  as  the  refineries  benchmarks  in  order  to preserve  a  level  playing field for producers of those products.';

- (d) paragraphs 3 and 4 are deleted;

EN

- (e) paragraph 5 is replaced by the following:
- '5. In  order  to  respect  the  auctioning  share  set  out  in  Article  10,  for  every  year  in  which  the  sum  of  free allocations  does  not  reach  the  maximum  amount that  respects  the  auctioning  share,  the  remaining allowances up to that amount shall be used to prevent or limit reduction of free allocations to respect the auctioning share in later years. Where,  nonetheless,  the  maximum  amount  is  reached,  free  allocations  shall  be  adjusted accordingly. Any such adjustment shall be done in a uniform manner. However, installations whose greenhouse gas emission levels are below the average of the 10 % most efficient installations in a sector or subsector in the Union  for  the  relevant  benchmarks  in  a  year  when  the  adjustment  applies  shall  be  exempted  from  that adjustment.';
- (f) in paragraph 6, the first subparagraph is replaced by the following:
- 'Member States should adopt financial measures in accordance with the second and fourth subparagraphs of this paragraph  in  favour  of  sectors  or  subsectors  which  are  exposed  to  a  genuine  risk  of  carbon  leakage  due  to significant  indirect  costs  that  are  actually  incurred  from  greenhouse  gas  emission  costs  passed  on  in  electricity prices, provided that such financial measures are in accordance with State aid rules, and in particular do not cause undue distortions of competition in the internal market. The financial measures adopted should not compensate indirect costs covered by free allocation in accordance with the benchmarks established pursuant to paragraph 1 of  this  Article.  Where  a  Member  State  spends  an  amount  higher  than  the  equivalent  of  25  %  of  the  auction revenues  referred  to  in  Article  10(3)  for  the  year  in  which  the  indirect  costs  were  incurred,  it  shall  set  out  the reasons for exceeding that amount.';
- (g) in paragraph 7, the second subparagraph is replaced by the following:

'From  2021,  allowances  that,  pursuant  to  paragraphs  19,  20  and  22,  are  not  allocated  to  installations  shall  be added  to  the  amount  of  allowances  set  aside  in  accordance  with  the  first  subparagraph,  first  sentence,  of  this paragraph.';

- (h) paragraph 8 is replaced by the following:
- '8. 345  million  allowances  from  the  quantity  which  could  otherwise  be  allocated  for  free  pursuant  to  this Article, and 80 million allowances from the quantity which could otherwise be auctioned pursuant to Article 10, as well as the allowances resulting from the reduction of free allocation referred to in paragraph 1a of this Article, shall be made available to a fund (the 'Innovation Fund') with the objective of supporting innovation in low- and zero-carbon  techniques,  processes  and  technologies  that  contribute  significantly  to  the  decarbonisation  of  the sectors  covered  by  this  Directive  and  contribute  to  zero  pollution  and  circularity objectives,  including  projects aimed at scaling  up  such techniques,  processes  and  technologies  with  a view  to their  broad  roll-out  across  the Union. Such projects  shall  possess  significant  greenhouse  gas  emissions  abatement  potential  and  contribute  to energy and resource savings in line with the Union's climate and energy targets for 2030.

The Commission shall frontload Innovation Fund allowances to ensure that an adequate amount of resources is available to foster innovation, including for scaling up.

Allowances that are not issued to aircraft operators due to them ceasing operations and which are not necessary to cover any shortfall in surrenders by those operators shall also be used for innovation support as referred to in the first subparagraph.

Moreover,  5  million  allowances  from  the  quantity  referred  to  in  Article  3c(5)  and  (7)  relating  to  aviation allocations  for  2026  shall  be  made  available  for  innovation  support  as  referred  to  in  the  first  subparagraph  of this paragraph.

In addition, 50 million unallocated allowances from the market stability reserve shall supplement any remaining revenues  from  the  300  million  allowances  available  in  the  period  from  2013  to  2020  under  Commission Decision  2010/670/EU  (*),  and  shall  be  used  in  a  timely  manner  for  innovation  support  as  referred  to  in  the first subparagraph of this paragraph.

The  Innovation  Fund  shall  cover  the  sectors  listed  in  Annexes  I  and  III,  as  well  as  products  and  processes substituting carbon intensive ones produced or used in sectors listed in Annex I, including innovative renewable energy  and  energy  storage  technologies  and  environmentally  safe  carbon  capture  and  utilisation  (CCU)  that contributes substantially to mitigating climate change, in particular for unavoidable process emissions, and shall help stimulate the construction and operation of projects aimed at the environmentally safe capture, transport and  geological  storage  (CCS)  of  CO ,  in  particular  for  unavoidable  industrial  process  emissions,  and  the  direct 2

EN

capture  of  CO 2 from  the  atmosphere  with  safe,  sustainable  and  permanent  storage  (DACS),  in  geographically balanced locations. The Innovation Fund may  also support breakthrough innovative technologies and infrastructure,  including  production  of  low-  and  zero-carbon  fuels,  to  decarbonise  the  maritime,  aviation,  rail and road transport sectors, including collective forms of transport such as public transport and coach services.

For aviation, it may also support electrification and actions to reduce the overall climate impacts of aviation.

The  Commission  shall  give  special  attention  to  projects  in  sectors  covered  by  Regulation  (EU)  2023/956  to support innovation in low-carbon technologies, CCU, CCS, renewable energy and energy storage, in a way that contributes to mitigating climate change with the aim of awarding, over the period from 2021 to 2030, projects in those sectors a significant share of the equivalence in financial value of the allowances referred to in paragraph 1a,  fourth  subparagraph,  of  this  Article.  In  addition,  the  Commission  may  launch,  before  2027,  calls  for proposals dedicated to the sectors covered by that Regulation.

The Commission shall also give special attention to projects contributing to the decarbonisation of the maritime sector  and  shall  include  topics  dedicated  to  that  purpose  in  the  Innovation  Fund  calls  for  proposals,  where appropriate,  including  to  electrify  maritime  transport,  and  to  address  its  full  climate  impact,  including  black carbon  emissions.  Such  calls  for  proposals  shall  also,  in  the  criteria  used  for  the  selection  of  projects,  take particular  account  of  the  potential  for  increasing  biodiversity  protection  and  for  reducing  noise  and  water pollution from projects and investments.

The Innovation Fund may in accordance with paragraph 8a support projects through competitive bidding, such as  CDs,  CCDs or  fixed premium contracts to support decarbonisation technologies for  which the carbon price might not be a sufficient incentive.

The Commission shall seek synergies between the Innovation Fund and Horizon Europe, in particular in relation to European partnerships, and shall, where relevant, seek synergies between the Innovation Fund and other Union programmes.

Projects in the territory of all Member States, including small-scale and medium-scale projects, shall be eligible, and, for maritime activities, projects with clear added value for the Union shall be eligible. Technologies receiving support shall be innovative and not yet commercially viable at a similar scale without support, but shall represent breakthrough solutions or be sufficiently mature for application on a pre-commercial scale.

The Commission shall ensure that the allowances destined for the Innovation Fund are auctioned in accordance with  the  principles  and  modalities  referred  to  in  Article  10(4)  of  this  Directive.  Proceeds  from  the  auctioning shall constitute external assigned revenue in accordance with Article 21(5) of Regulation (EU, Euratom) 2018/1046 of  the  European  Parliament  and  of  the  Council  (**).  Budgetary  commitments  for  actions  extending  over  more than one financial year may be broken down into annual instalments over several years.

The Commission shall, on request, provide technical assistance to Member States with low effective participation in projects under the Innovation Fund for the purpose of increasing the capacities of the requesting Member State to support the efforts of project proponents in their respective territories to submit applications for funding from the  Innovation  Fund,  in  order  to  improve  the  effective  geographical  participation  in  the  Innovation  Fund  and increase the overall quality of submitted  projects. The  Commission  shall  pursue  effective,  quality-based geographical  coverage  in  relation  to  funding  from  the  Innovation  Fund  across  the  Union  and  shall  ensure comprehensive monitoring of progress and appropriate follow-up in that respect.

Subject to the agreement of applicants, following the closure of a call for proposals, the Commission shall inform Member States of  the applications for  funding  of projects in  their  respective  territories  and  shall  provide  them with detailed information concerning those applications in order to facilitate Member States' coordination of the support  for  projects.  In  addition,  the  Commission  shall  inform  Member  States  about  the  list  of  pre-selected projects prior to the award of the support.

Projects  shall  be  selected  by  means  of  a  transparent  selection  procedure,  in  a  technology-neutral  manner  in accordance with the objectives of the Innovation Fund as set out in the first subparagraph of this paragraph and on  the  basis  of  objective  and  transparent  criteria,  taking  into  account  the  extent  to  which  projects  provide  a

significant  contribution to the  Union's  climate  and energy  targets while  contributing  to the  zero  pollution  and circularity objectives in accordance with the first subparagraph of this paragraph, and, where relevant, the extent to  which  projects  contribute  to  achieving  emission  reductions  well  below  the  benchmarks  referred  to  in paragraph  2.  Projects  shall  have  the  potential  for  widespread  application  or  to  significantly  lower  the  costs  of transitioning towards a climate-neutral economy in the sectors concerned. Priority shall be given to innovative technologies  and  processes  addressing  multiple  environmental  impacts.  Projects  involving  CCU  shall  deliver  a net  reduction  in  emissions  and  ensure  avoidance  or  permanent  storage  of  CO .  In  the  case  of  grants  provided 2 through calls for  proposals, up to 60 % of  the relevant costs of projects may be supported, out of which up to 40 % need not be dependent on verified avoidance of greenhouse gas emissions, provided that pre-determined milestones, taking into account the technology deployed, are attained. In the case of support provided through competitive bidding and in the case of technical assistance support, up to 100 % of the relevant costs of projects may  be  supported.  The  potential  for  emission  reductions  in  multiple  sectors  offered  by  combined  projects, including in nearby areas, shall be taken into account in the criteria used for the selection of projects.

Projects funded by the Innovation Fund shall be required to share knowledge with other relevant projects as well as with Union-based researchers having a legitimate interest. The terms of knowledge sharing shall be defined by the Commission in calls for proposals.

The calls for proposals shall be open and transparent. In preparing the calls for proposals, the Commission shall strive to ensure that all sectors are duly covered. The Commission shall take measures to ensure that the calls are communicated as widely as possible, and especially to small and medium-sized enterprises.

The  Commission  is  empowered  to  adopt  delegated  acts  in  accordance  with  Article  23  to  supplement  this Directive  concerning  rules  on  the  operation  of  the  Innovation  Fund,  including  the  selection  procedure  and criteria, and the eligible sectors and technological requirements for the different types of support.

No project shall receive support via the mechanism under this paragraph that exceeds 15 % of the total number of allowances available for this purpose. Those allowances shall be taken into account under paragraph 7.

By 31 December 2023 and every year thereafter, the Commission shall report to the Climate Change Committee referred  to  in  Article  22a(1)  of  this  Directive,  on  the  implementation  of  the  Innovation  Fund,  providing  an analysis  of  projects  awarded  funding,  by  sector  and  by  Member  State,  and  the  expected  contribution  of  those projects towards the objective of climate neutrality in the Union as set out in Regulation (EU) 2021/1119. The Commission shall provide the report to the European Parliament and to the Council and shall make that report public.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Commission  Decision  2010/670/EU  of  3  November  2010  laying  down  criteria  and  measures  for  the financing of commercial demonstration projects that aim at the environmentally safe capture and geological storage  of  CO 2 as  well  as  demonstration  projects  of  innovative  renewable  energy  technologies  under  the scheme for greenhouse gas emission allowance trading within the Community established by Directive 2003/87/EC of the European Parliament and of the Council (OJ L 290, 6.11.2010, p. 39).
- (**) Regulation (EU, Euratom) 2018/1046 of the European Parliament and of the Council of 18 July 2018 on the financial  rules  applicable  to  the  general  budget  of  the  Union,  amending  Regulations  (EU)  No  1296/2013, (EU) No 1301/2013, (EU) No 1303/2013, (EU) No 1304/2013, (EU) No 1309/2013, (EU) No 1316/2013, (EU)  No  223/2014,  (EU)  No  283/2014,  and  Decision  No  541/2014/EU  and  repealing  Regulation  (EU, Euratom) No 966/2012 (OJ L 193, 30.7.2018, p. 1).';

## (i) the following paragraphs are inserted:

'8a. For CDs and CCDs awarded upon conclusion of a competitive bidding mechanism, appropriate coverage through  budgetary  commitments  resulting  from  the  proceeds  of  auctioning  of  allowances  available  in  the Innovation  Fund  shall  be  provided  and  those  budgetary  commitments  may  be  broken  down  into  annual instalments over several years. For  the first two rounds of  the competitive bidding mechanism, coverage of the financial liability related to CDs and CCDs shall be fully ensured with appropriations resulting from the proceeds of auctioning of allowances allocated to the Innovation Fund pursuant to paragraph 8.

On the basis of a qualitative and quantitative assessment by the Commission of the financial risks arising from the implementation of CDs and CCDs, to be made after  the conclusion of  the first two rounds of  the competitive bidding  mechanism  and  each  time  it  is  necessary  thereafter  in  accordance  with  the  principle  of  prudence, whereby assets and profits are not to be overestimated and liabilities and losses are not to be underestimated, the Commission may, in accordance with the empowerment in the eighth subparagraph, decide to cover only part of the financial liability related to CDs and CCDs through the means referred to in the first subparagraph and the remaining part through other means. The Commission shall aim to limit the use of other means of coverage.

Where  the  assessment  leads  to  the  conclusion  that  other  means  of  coverage  are  necessary  to  realise  the  full potential  of  the  CDs  and  CCDs,  the  Commission  shall  aim  for  a  balanced  mix of other  means  of  coverage.  By way  of  derogation  from  Article  210(1)  of  Regulation  (EU,  Euratom)  2018/1046,  the  Commission  shall determine  the  extent  of  the  use  of  other  means  of  coverage  pursuant  to  the  delegated  act  provided  for  in  the eighth subparagraph of this paragraph.

The  remaining  financial  liability  shall  be  sufficiently  covered,  having  regard  to  the  principles  of  Title  X  of Regulation  (EU,  Euratom)  2018/1046,  if  necessary,  adapted  to  the  specificities  of  CDs  and  CCDs,  by  way  of derogation from Article 209(2), points (d) and (h), Article 210(1), Article 211(1), (2), (4) and (6), Articles 212, 213 and 214, Article 218(1) and Article  219(3)  and (6)  of  that  Regulation.  Where  applicable,  other  means  of coverage, the provisioning rate and the necessary derogations shall be established in a delegated act provided for in the eighth subparagraph of this paragraph.

The Commission shall not use more than 30 % of the proceeds of the auctioning of allowances allocated to the Innovation Fund pursuant to paragraph 8 for provisioning for CDs and CCDs.

The provisioning rate shall be no lower  than 50 % of the total financial liability borne by the Union budget for CDs and CCDs. When establishing the provisioning rate, the Commission shall take into account elements that may reduce the financial risks for the Union budget, beyond the appropriations available in the Innovation Fund, such  as  possible  sharing  of  liability  with  Member  States  on  a  voluntary  basis,  or  a  possible  re-insurance mechanism from the private sector. The Commission shall review the provisioning rate at least every three years from the date of application of the delegated act establishing it for the first time.

In  order  to  avoid  speculative  applications,  access  to  competitive  bidding  may  be  made  conditional  on  the payment by applicants of a deposit to be forfeited in the event of non-fulfilment of the contract. Such forfeited deposits  shall  be  used  for  the  Innovation  Fund  as  external  assigned  revenue  pursuant  to  Article  21(5)  of Regulation  (EU,  Euratom)  2018/1046.  Any  contribution  paid  to  the  granting  authority  by  a  beneficiary  in accordance with the terms of the CD or CCD where the reference price is higher than the strike price ('reflows') shall be used for the Innovation Fund as external assigned revenue pursuant to Article 21(5) of that Regulation.

The  Commission  is  empowered  to  adopt  delegated  acts  in  accordance  with  Article  23  of  this  Directive  to supplement  this  Directive  in  order  to  provide  for  and  detail  other  means  of  coverage,  if  any,  and,  where applicable, the provisioning rate and the necessary additional derogations from Title X of Regulation (EU, Euratom) 2018/1046 as set out in the fourth subparagraph of this paragraph, and the rules on the operation of the competitive bidding mechanism, in particular in relation to deposits and reflows.

The  Commission  is  empowered  to  adopt  delegated  acts  in  accordance  with  Article  23  to  amend  the  fifth subparagraph of this paragraph by raising the limit of 30 % referred to in that subparagraph by no more than a total of 20 percentage points where necessary to respond to a demand for CDs and CCDs, taking into account the  experience  of  the  first  rounds  of  the  competitive  bidding  mechanism  and  considering  the  need  to  find  an appropriate balance in the support from the Innovation Fund between grants and such contracts.

Financial support from the Innovation Fund shall be proportionate to the policy objectives set out in this Article and shall not lead to undue distortions of the internal market. To this end, support shall only be granted to cover additional costs or investment risks that cannot be borne by investors under normal market conditions.

- 8b. 40  million  allowances  from  the  quantity  which  could  otherwise  be  allocated  for  free  pursuant  to  this Article, and 10 million allowances from the quantity which could otherwise be auctioned pursuant to Article 10 of this Directive shall be made available for the Social Climate Fund established by Regulation (EU) 2023/955 of the  European Parliament and of  the Council (*). The Commission shall ensure that the allowances destined for the  Social  Climate  Fund  are  auctioned  in  2025  in  accordance  with  the  principles  and  modalities  referred  to  in Article 10(4) of this Directive and the delegated act adopted in accordance with that Article. The revenues from that auctioning shall constitute external assigned revenue in accordance with Article 21(5) of Regulation  (EU,  Euratom)  2018/1046,  and  shall  be  used  in  accordance  with  the  rules  applicable  to  the  Social Climate Fund.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation  (EU)  2023/955  of  the  European  Parliament  and  of  the  Council  of  10  May  2023  establishing  a Social Climate Fund and amending Regulation (EU) 2021/1060 (OJ L 130, 16.5.2023, p. 1).';
- (j) paragraph 19 is replaced by the following:
- '19. No free allocation shall be given to an installation that has ceased operating. Installations for  which the greenhouse gas emissions permit has expired or has been withdrawn and installations for which the operation or resumption of operation is technically impossible shall be considered to have ceased operations.';
- (k) the following paragraph is added:
- '22. Where corrections to free  allocations  granted  pursuant  to  Article  11(2)  are  necessary,  such  corrections shall  be  carried  out  with  allowances  from,  or  by  adding  allowances  to,  the  amount  of  allowances  set  aside  in accordance with paragraph 7 of this Article.';
- (14) in Article 10b(4), the following subparagraphs are added:

'In a Member State where, on average in the years from 2014 to 2018, its share of emissions from district heating of the Union total of such emissions, divided by that Member State's share of GDP of the Union's total GDP, is greater than five, an additional free allocation of 30 % of the quantity determined pursuant to Article 10a shall be given to district  heating for  the period from 2026 to 2030, provided that an investment volume equivalent to the value of that additional free allocation is invested to significantly reduce emissions before 2030 in accordance with climateneutrality plans referred to in the third subparagraph of this paragraph and that the achievement of the targets and milestones referred to in point (b) of  that subparagraph is confirmed by the verification carried out in accordance with the fourth subparagraph of this paragraph.

By 1 May 2024, operators of district heating shall establish a climate-neutrality plan for  the installations for which they apply for additional free allocation in accordance with the second subparagraph of  this paragraph. That plan shall  be  consistent  with  the  climate-neutrality objective  set  out  in  Article  2(1)  of  Regulation  (EU)  2021/1119  and shall set out:

- (a) measures and investments to reach climate neutrality by 2050 at installation or company level, excluding the use of carbon offset credits;
- (b) intermediate targets and milestones to measure, by 31 December 2025 and by 31 December of each fifth year thereafter, progress made towards reaching climate neutrality as set out in point (a) of this subparagraph;
- (c) an estimate of the impact of each of the measures and investments referred to in point (a) of this subparagraph as regards the reduction of greenhouse gas emissions.

EN

The achievement of the targets and milestones referred to in the third subparagraph, point (b), of this paragraph, shall be verified in respect of the period until 31 December 2025 and in respect of each period ending 31 December of each  fifth  year thereafter, in accordance  with  the  verification  and  accreditation  procedures  provided  for  in Article  15.  No  free  allowances beyond the amount referred to in the first  subparagraph of  this paragraph shall be allocated if the achievement of the intermediate targets and milestones has not been verified in respect of the period until the end of 2025 or in respect of the period from 2026 to 2030.

The Commission shall adopt implementing acts to specify the minimal content of the information referred to in the third subparagraph, points (a), (b) and (c), of this paragraph, and the format of the climate-neutrality plans referred to in  that  subparagraph  and  in  Article  10a(1),  fifth  subparagraph.  The  Commission  shall  seek  synergies  with  similar plans as provided for in Union law. Those implementing acts shall be adopted in accordance with the examination procedure referred to in Article 22a(2).';

- (15) in Article 10c, paragraph 7 is replaced by the following:
- '7. Member States shall require benefiting electricity generating installations and network operators to report, by 28  February  of  each  year,  on  the  implementation  of  their  selected  investments,  including  the  balance  of  free allocation and investment expenditure incurred and the types of investments supported. Member States shall report on this to the Commission, and the Commission shall make such reports public.';
- (16) the following article is inserted:

' Article 10ca

## Earlier deadline for transitional free allocation for the modernisation of the energy sector

By way of derogation from Article 10c, the Member States concerned may only give transitional free allocation to installations  in  accordance  with  that  Article  for  investments  carried  out  until  31  December  2024.  Any  allowances available to the Member States concerned in accordance with Article 10c for the period from 2021 to 2030 that are not used for such investments shall, in the proportion determined by the respective Member State:

- (a) be  added  to  the  total  quantity  of  allowances  that  the  Member  State  concerned  is  to  auction  pursuant  to Article 10(2); or
- (b) be used to support investments within the framework of the Modernisation Fund referred to in Article 10d, in accordance with the rules applicable to the revenue from allowances referred to in Article 10d(4).

By 15 May 2024, the Member State concerned shall notify the Commission of the respective amounts of allowances to be used under Article 10(2), first subparagraph, point (a), and, by way of derogation from Article 10d(4), second sentence, under Article 10d.';

- (17) Article 10d is amended as follows:
- (a) paragraph 1 is replaced by the following:
- '1. A  fund  to  support  investments  proposed  by  the  beneficiary  Member  States,  including  the  financing  of small-scale investment projects, to modernise energy systems and improve energy efficiency shall be established for  the  period  from  2021  to  2030  (the  'Modernisation  Fund').  The  Modernisation  Fund  shall  be  financed through the auctioning of allowances as set out in Article 10, for the beneficiary Member States set out therein.

The  investments  supported  shall  be  consistent  with  the  aims  of  this  Directive,  as  well  as  the  objectives  of  the communication of the Commission of 11 December 2019 on 'The European Green Deal' and Regulation (EU) 2021/1119 and the long-term objectives as expressed in the Paris Agreement. The beneficiary Member  States  may,  where  appropriate,  use  the  resources  of  the  Modernisation  Fund  to  finance  investments involving  the  adjacent  Union  border  regions.  No  support  from  the  Modernisation  Fund  shall  be  provided  to energy  generation  facilities  that  use  fossil  fuels.  However,  revenue  from  allowances  covered  by  a  notification pursuant to paragraph 4 of this Article may be used for investments involving gaseous fossil fuels.

Furthermore,  revenue  from  allowances  referred  to  in  Article  10(1),  third  subparagraph,  of  this  Directive  may, where  the  activity  qualifies  as  environmentally  sustainable  under  Regulation  (EU)  2020/852  of  the  European Parliament  and  of  the  Council  (*)  and  is  duly  justified  for  reasons  of  ensuring  energy  security,  be  used  for investments  involving  gaseous  fossil  fuels  provided  that,  for  energy  generation,  the  allowances  are  auctioned before 31 December 2027 and, for investments involving downstream uses of gas, the allowances are auctioned before 31 December 2028.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation  (EU)  2020/852  of  the  European  Parliament  and  of  the  Council  of  18  June  2020  on  the establishment of a framework to facilitate sustainable investment, and amending Regulation (EU) 2019/2088 (OJ L 198, 22.6.2020, p. 13).';

## (b) paragraph 2 is replaced by the following:

- '2. At least  80  %  of  the  revenue  from  allowances referred  to in  Article  10(1),  third  subparagraph,  and  from allowances covered by a notification pursuant to paragraph 4 of  this  Article,  and at  least  90  %  of  the  revenue from allowances referred to in Article  10(1),  fourth  subparagraph, shall  be  used  to support  investments in  the following:
- (a) the generation and use of electricity from renewable sources, including renewable hydrogen;
- (b) heating and cooling from renewable sources;
- (c) the  reduction  of  overall  energy  use  through  energy  efficiency,  including  in  industry,  transport,  buildings, agriculture and waste;
- (d) energy  storage  and  the  modernisation  of  energy  networks,  including  demand-side  management,  district heating pipelines, grids for electricity transmission, the increase of interconnections between Member States and infrastructure for zero-emission mobility;
- (e) support for low-income households, including in rural and remote areas, to address energy poverty and to modernise their heating systems; and
- (f) a  just  transition  in  carbon-dependent  regions  in  the  beneficiary  Member  States,  so  as  to  support  the redeployment,  reskilling  and  up-skilling  of  workers,  education,  job-seeking  initiatives  and  start-ups,  in dialogue  with  civil  society  and  social  partners,  in  a  manner  that  is  consistent  with  and  contributes  to  the relevant  actions  included  by  the  Member  States  in  their  territorial  just  transition  plans  in  accordance  with Article 8(2), first subparagraph, point (k), of Regulation (EU) 2021/1056, where relevant.';

## (c) paragraph 11 is replaced by the following:

- '11. The investment committee shall report annually to the Commission on experience with the evaluation of investments, in particular  in terms of emission reductions and abatement costs. By 31 December 2024, taking into consideration the findings of the investment committee, the Commission shall review the areas for projects referred to in paragraph 2 and the basis on which the investment committee makes its recommendations.

The investment committee shall arrange for the publication of the annual report. The Commission shall provide the annual report to the European Parliament and to the Council.';

- (18) the following article is inserted:

' Article 10f

## 'Do no significant harm' principle

From 1 January 2025, the beneficiary Member States and the Commission shall use the revenues generated from the auctioning  of  allowances  destined  for  the  Innovation  Fund  pursuant  to  Article  10a(8)  of  this  Directive,  and  of  the allowances referred to in Article 10(1), third and fourth subparagraphs, of this Directive in accordance with the 'do no significant harm' criteria set out in Article 17 of Regulation (EU) 2020/852, where such revenues are used for an economic  activity  for  which  technical  screening  criteria  for  determining  whether  an  economic  activity  causes significant  harm  to  one  or  more  of  the  relevant  environmental  objectives  have  been  established  pursuant  to Article 10(3), point (b), of that Regulation.';

EN

16.5.2023

- (19) in Article 11(2), the date '28 February' is replaced by '30 June';
- (20) the title of Chapter IV is replaced by the following:

'Provisions Applying to Aviation, Maritime Transport and Stationary Installations';

- (21) Article 12 is amended as follows:
- (a) paragraph 2 is replaced by the following:
- '2. Member States shall ensure that allowances issued by a competent authority of another Member State are recognised for  the purpose of meeting an operator's, an aircraft operator's or a shipping company's obligations under paragraph 3.';
- (b) paragraph 2a is deleted;
- (c) paragraph 3 is replaced by the following:
- '3. The Member States,  administering  Member  States  and  administering  authorities  in  respect  of  a  shipping company shall ensure that, by 30 September each year:
- (a) the operator of each installation surrenders a number of allowances that is equal to the total emissions from that installation during the preceding calendar year, as verified in accordance with Article 15;
- (b) each  aircraft  operator  surrenders  a  number  of  allowances  that  is  equal  to  its  total  emissions  during  the preceding calendar year, as verified in accordance with Article 15;
- (c) each  shipping  company  surrenders  a  number  of  allowances  that  is  equal  to  its  total  emissions  during  the preceding calendar year, as verified in accordance with Article 3ge.

Member  States,  administering  Member  States  and  administering  authorities  in  respect  of  a  shipping  company shall ensure that allowances surrendered in accordance with the first subparagraph are subsequently cancelled.';

- (d) the following paragraphs are inserted after paragraph 3:
- '3-e. By way of derogation from paragraph 3, first subparagraph, point (c), shipping companies may surrender 5  %  fewer  allowances  than  their  verified  emissions  released  until  31  December  2030 from  ice-class  ships, provided  that  such  ships  have  the  ice  class  IA  or  IA  Super  or  an  equivalent  ice  class,  established  based  on HELCOM Recommendation 25/7.

Where fewer allowances are surrendered compared to the verified emissions, once the difference between verified emissions  and  allowances  surrendered  has  been  established  in  respect  of  each  year,  an  amount  of  allowances corresponding to that difference shall be cancelled rather than auctioned pursuant to Article 10.

- 3-d. By way of derogation from paragraph 3, first subparagraph, point (c), of this Article and Article 16, the Commission  shall,  at  the  request  of  a  Member  State,  provide  by  means  of  an  implementing  act  that  Member States  are  to  consider  the  requirements  set  out  in  those  provisions  to  be  satisfied  and  that  they  are  to  take  no action  against  shipping  companies  in  respect  of  emissions  released  until  31  December  2030 from  voyages performed  by  passenger  ships,  other  than  cruise  passenger  ships,  and  by  ro-pax  ships,  between  a  port  of  an island  under  the  jurisdiction  of  that  requesting  Member  State,  with  no  road  or  rail  link  with  the  mainland  and with a population of fewer than 200 000 permanent residents according to the latest best data available in 2022, and a port under the jurisdiction of that same Member State, and from the activities, within a port, of such ships in relation to such voyages.

The Commission shall publish a list of the islands referred to in the first subparagraph and the ports concerned and keep that list up to date.

- 3-c. By way of derogation from paragraph 3, first subparagraph, point (c), of this Article and Article 16, the Commission shall, at the joint request of two Member States, one of which having no land border with another Member State and the other Member State being the geographically closest Member State to the Member State without  such a  land  border,  provide  by  means  of  an  implementing  act  that  Member  States  are  to  consider  the requirements  set  out  in  those  provisions  to  be  satisfied  and  that  they  are  to  take  no  action  against  shipping

EN

companies in respect of emissions  released  until  31  December  2030 from voyages performed  by passenger  or ro-pax  ships  in  the  framework  of  a  transnational  public  service  contract  or  a  transnational  public  service obligation, set out in the joint request, connecting the two Member States, and from the activities, within a port, of such ships in relation to such voyages.

- 3-b. An obligation to surrender allowances shall not arise in respect of emissions released until 31 December 2030 from voyages between a port located in an outermost region of a Member State and a port located in the same Member State, including voyages between ports within an outermost region and voyages between ports in the outermost regions of the same Member State, and from the activities, within a port, of such ships in relation to such voyages.';
- (e) paragraph 3-a is replaced by the following:
- '3-a. Where necessary, and for as long as is necessary, in order to protect the environmental integrity of the EU ETS,  operators,  aircraft  operators,  and  shipping  companies  in  the  EU  ETS  shall  be  prohibited  from  using allowances  that  are  issued  by  a  Member  State  in  respect  of  which  there  are  obligations  lapsing  for  operators, aircraft  operators,  and  shipping  companies.  The  delegated  acts  referred  to  in  Article  19(3)  shall  include  the measures necessary in the cases referred to in this paragraph.';
- (f) the following paragraph is inserted:
- '3b. An obligation to surrender allowances shall not arise in respect of emissions of greenhouse gases which are considered to have been captured and utilised in such a way that they have become permanently chemically bound in a product so that they do not enter  the atmosphere under normal use, including any normal activity taking place after the end of the life of the product.
- The  Commission  shall  adopt  delegated  acts  in  accordance  with  Article  23  to  supplement  this  Directive concerning the requirements for considering that greenhouse gases have become permanently chemically bound as referred to in the first subparagraph of this paragraph.';
- (g) paragraph 4 is replaced by the following:
- '4. Member States  shall  take  the  necessary  steps  to  ensure  that  allowances  are  cancelled  at  any  time  at  the request of the person holding them. In the event of closure of electricity generation capacity in their territory due to  additional  national  measures,  Member  States  may  cancel  allowances,  and  are  strongly  encouraged  to  do  so, from  the  total  quantity  of  allowances  to  be  auctioned  by  them  referred  to  in  Article  10(2)  up  to  an  amount corresponding  to  the  average  verified  emissions  of  the  installation  concerned  over  a  period  of  five  years preceding the closure. The Member State concerned shall inform the Commission of such intended cancellation, or of the reasons for not cancelling, in accordance with the delegated acts adopted pursuant to Article 10(4).';
- (22) in Article 14(1), the first subparagraph is replaced by the following:

'The  Commission  shall  adopt  implementing  acts  concerning  the  detailed  arrangements  for  the  monitoring  and reporting of emissions and, where relevant, activity data, from the activities listed in Annex I to this Directive, and non-CO2  aviation effects on routes for  which emissions are reported under  this Directive, which shall be based on the  principles  for  monitoring  and  reporting  set  out  in  Annex  IV  to  this  Directive  and  the  requirements  set  out  in paragraphs 2 and 5 of this Article. Those implementing acts shall also specify the global warming potential of each greenhouse gas and take into account up-to-date scientific knowledge on the effects of non-CO 2 aviation emissions in the requirements for monitoring and reporting of emissions and their effects, including non-CO 2 aviation effects. Those implementing acts shall provide for the application of the sustainability and greenhouse gas emission-saving criteria  for  the  use  of  biomass  established  by  Directive  (EU)  2018/2001,  with  any  necessary  adjustments  for application under  this Directive, in order for such biomass to be zero-rated. They shall specify how to account for storage  of  emissions  from  a  mix of  zero-rated  sources  and  sources  that  are  not  zero-rated.  They  shall  also  specify how to account for emissions from renewable fuels of non-biological origin and recycled carbon fuels, ensuring that such emissions are accounted for and that double counting is avoided.';

EN

16.5.2023

- (23) Article 16 is amended as follows:
- (a) paragraph 2 is replaced by the following:
- '2. Member  States  shall  ensure  the  publication  of  the  names  of  operators,  aircraft  operators  and  shipping companies that are in breach of requirements to surrender sufficient allowances under this Directive.';
- (b) in paragraph 3, the date '30 April' is replaced by '30 September';
- (c) the following paragraph is inserted:
- '3a. The penalties set out in paragraph 3 shall also apply in respect of shipping companies.';
- (d) the following paragraph is inserted:
- '11a. In the case of a shipping company that has failed to comply with the surrender obligations for  two or more consecutive reporting periods, and where other enforcement measures have failed to ensure compliance, the  competent  authority  of  the  Member  State  of  the  port  of  entry  may,  after  giving  the  opportunity  to  the shipping company concerned to submit its observations, issue an expulsion order, which shall be notified to the Commission,  the  European  Maritime  Safety  Agency  (EMSA),  the  other  Member  States  and  the  flag  State concerned. As a result of the issuing of such an expulsion order, every Member State, with the exception of the Member State whose flag the ship is flying, shall refuse entry of the ships under the responsibility of the shipping company  concerned  into  any  of  its  ports  until  the  shipping  company  fulfils  its  surrender  obligations  in accordance with Article 12. Where the ship flies the flag of a Member State and enters or is found in one of its ports,  the  Member  State  concerned  shall,  after  giving  the  opportunity  to  the  shipping  company  concerned  to submit its observations, detain the ship until the shipping company fulfils its surrender obligations.

Where a ship of a shipping company as referred to in the first subparagraph is found in one of the ports of the Member State whose flag the ship is flying, the Member State concerned may, after giving the opportunity to the shipping  company  concerned  to  submit  its  observations,  issue  a  flag  State  detention  order  until  the  shipping company fulfils  its  surrender  obligations.  It  shall  inform  the  Commission,  EMSA  and  the  other  Member  States thereof.  As  a  result  of  the  issuing  of  such  a  flag  State  detention  order,  every  Member  State  shall  take  the  same measures  as  are  required  to  be  taken  following  the  issuing  of  an  expulsion  order  in  accordance  with  the  first subparagraph, second sentence.

This  paragraph  shall  be  without  prejudice  to  international  maritime  rules  applicable  in  the  case  of  ships  in distress.';

- (24) Article 18b is replaced by the following:

' Article 18b

## Assistance from the Commission, EMSA and other relevant organisations

- 1. For the purposes of carrying out its obligations under Article 3c(4) and Articles 3g, 3gd, 3ge, 3gf, 3gg and 18a, the  Commission,  the  administering  Member  State  and  administering  authorities  in  respect  of  a  shipping  company may request the assistance of EMSA or another relevant organisation and may conclude to that effect any appropriate agreements with those organisations.
- 2. The Commission, assisted by EMSA, shall endeavour to develop appropriate tools and guidance to facilitate and coordinate verification and enforcement activities related to the application of this Directive to maritime transport. As far  as  practicable,  such  guidance  and  tools  shall  be  made  available  to  the  Member  States  and  the  verifiers  for information-sharing purposes and in order to better ensure robust enforcement of the national measures transposing this Directive.';

EN

- (25) Article 23 is amended as follows:
- (a) paragraphs 2 and 3 are replaced by the following:
- '2. The power to adopt delegated acts referred to in Article 3c(6), Article 3d(3), Article 10(4), Article 10a(1), (8) and (8a), Article 10b(5), Article 12(3b), Article 19(3), Article 22, Article 24(3), Article 24a(1), Article 25a(1), Article 28c and Article 30j(1) shall be conferred on the Commission for an indeterminate period of time from 8 April 2018.
- 3. The delegation of power referred to in Article 3c(6), Article 3d(3), Article 10(4), Article 10a(1), (8) and (8a), Article 10b(5), Article 12(3b), Article 19(3), Article 22, Article 24(3), Article 24a(1), Article 25a(1), Article 28c and  Article  30j(1)  may  be  revoked  at  any  time  by  the  European  Parliament  or  by  the  Council.  A  decision  to revoke  shall  put  an  end  to  the  delegation  of  the  power  specified  in  that  decision.  It  shall  take  effect  the  day following the publication of  the decision in the Official  Journal  of  the  European  Union or  at  a  later  date  specified therein. It shall not affect the validity of any delegated acts already in force.';
- (b) paragraph 6 is replaced by the following:
- '6. A delegated act adopted pursuant to Article 3c(6), Article 3d(3), Article 10(4), Article 10a(1), (8) or (8a), Article 10b(5), Article 12(3b), Article 19(3), Article 22, Article 24(3), Article 24a(1), Article 25a(1), Article 28c or Article 30j(1) shall enter into force only if no objection has been expressed either by the European Parliament or by the Council within a period of two months of notification of that act to the European Parliament and to the Council or if, before the expiry of that period, the European Parliament and the Council have both informed the Commission  that  they  will  not  object.  That  period  shall  be  extended  by  two  months  at  the  initiative  of  the European Parliament or of the Council.';
- (26) Article 29 is replaced by the following:

' Article 29

## Report to ensure the better functioning of the carbon market

If  the  regular  reports  on  the  carbon  market  referred  to  in  Article  10(5)  and  (6)  contain  evidence  that  the  carbon market  is  not  functioning  properly,  the  Commission  shall  within  a  period  of  three  months  submit  a  report  to  the European  Parliament  and  to  the  Council.  The  report  may  be  accompanied,  where  appropriate,  by  legislative proposals  aiming  at  increasing  the  transparency  and  integrity  of  the  carbon  market,  including  related  derivative markets, and addressing the corrective measures to improve its functioning, as well as to enhance the prevention and detection of market abuse activities.';

- (27) Article 29a is replaced by the following:

' Article 29a

## Measures in the event of excessive price fluctuations

- 1. If  the  average  allowance  price  for  the  six  preceding  calendar  months  is  more  than  2,4  times  the  average allowance price for the preceding two-year reference period, 75 million allowances shall be released from the market stability reserve in accordance with Article 1(7) of Decision (EU) 2015/1814.

The allowance price referred to in the first subparagraph of this paragraph shall, for allowances covered by Chapters II and III, be the price of auctions carried out in accordance with the delegated acts adopted pursuant to Article 10(4).

The preceding two-year reference period referred to in the first subparagraph shall be the two-year period that ends before the first month of the period of six calendar months referred to in that subparagraph.

Where  the  condition  in  the  first  subparagraph  of  this  paragraph  is  met  and  paragraph  2  is  not  applicable,  the Commission shall publish a notice to that effect  in  the Official  Journal  of  the  European  Union indicating  the  date  on which the condition was fulfilled.

EN

The Commission shall publish within the first three working days of each month the average allowance price for the preceding six calendar  months  and  the  average  allowance  price  for  the  preceding  two-year  reference  period.  If  the condition  referred  to  in  the  first  subparagraph  is  not  met,  the  Commission  shall  also  publish  the  level  that  the average  allowance  price  would  have  to  reach  in  the  next  month  in  order  to  meet  the  condition  referred  to  in  that subparagraph.

- 2. When the condition for  release  of  allowances  from  the  market  stability  reserve  pursuant  to  paragraph  1  has been met, the condition referred to in that paragraph shall not be considered to have been met again until at least twelve months after the end of the previous release.
- 3. The detailed arrangements for the application of the measures referred to in paragraphs 1 and 2 of this Article shall be laid down in the delegated acts referred to in Article 10(4).';
- (28) Article 30 is amended as follows:
- (a) paragraph 1 is replaced by the following:
- '1. This Directive shall be kept under review in the light of international developments and efforts undertaken to achieve the long-term objectives of the Paris Agreement, and of any relevant commitments resulting from the Conferences of the Parties to the United Nations Framework Convention on Climate Change.';
- (b) paragraph 2 is replaced by the following:
- '2. The measures to support certain energy-intensive industries that may be subject to carbon leakage referred to in Articles 10a and 10b of this Directive shall also be kept under review in the light of climate policy measures in other major economies. In this context, the Commission shall also consider whether measures in relation to the compensation of indirect costs should be further harmonised. The measures applicable to CBAM sectors shall be kept under review in light of the application of Regulation (EU) 2023/956. Before 1 January 2028, and every two years thereafter, as part of its reports to the European Parliament and to the Council pursuant to Article 30(6) of that  Regulation,  the  Commission  shall  assess  the  impact  of  CBAM  on  the  risk  of  carbon  leakage,  including  in relation to exports.

The report shall assess the need for taking additional measures, including legislative measures, to address carbon leakage risks. The report shall, where appropriate, be accompanied by a legislative proposal.';

- (c) paragraph 3 is replaced by the following:
- '3. The Commission shall report to the European Parliament and to the Council in the context of each global stocktake agreed under  the Paris Agreement, in particular  with regard to the need for additional Union policies and measures in view of necessary greenhouse gas reductions by the Union and its Member States, including in relation  to the  linear  factor  referred  to in  Article  9  of  this  Directive.  The  Commission  may,  where  appropriate, submit legislative proposals to the European Parliament and to the Council to amend this Directive, in particular in  order  to  ensure  compliance  with  the  climate-neutrality  objective  laid  down  in  Article  2(1)  of  Regulation (EU)  2021/1119  and  the  Union  climate  targets  laid  down  in  Article  4  of  that  Regulation.  When  making  its legislative  proposals,  the  Commission  shall,  to  that  end,  consider,  inter  alia,  the  projected  indicative  Union greenhouse gas budget for the period from 2030 to 2050 as referred to in Article 4(4) of that Regulation.';
- (d) the following paragraphs are added:
- '5. By  31  July  2026,  the  Commission  shall  report  to  the  European  Parliament  and  to  the  Council  on  the following matters, accompanied, where appropriate, by a legislative proposal and impact assessment:
- (a) how negative emissions resulting from greenhouse gases that are removed from the atmosphere and safely and  permanently  stored  could  be  accounted  for  and  how  those  negative  emissions  could  be  covered  by emissions trading, if appropriate, including a clear scope and strict criteria for such coverage, and safeguards to ensure that such removals do not offset necessary emission reductions in accordance with Union climate targets laid down in Regulation (EU) 2021/1119;
- (b) the feasibility of  lowering the 20 MW total rated thermal input thresholds for the activities in Annex I from 2031;

EN

- (c) whether  all  greenhouse  gas  emissions  covered  by  this  Directive  are  effectively  accounted  for,  and  whether double  counting  is  effectively  avoided;  in  particular,  it  shall  assess  the  accounting  of  the  greenhouse  gas emissions which are considered to have been captured and utilised in a product in a manner other than that referred to in Article 12(3b).
- 6. When reviewing this Directive, in accordance with paragraphs 1, 2 and 3 of this Article, the Commission shall analyse how linkages between the EU ETS and other carbon markets can be established without impeding the  achievement  of  the  climate-neutrality  objective  and  the  Union  climate  targets  laid  down  in  Regulation (EU) 2021/1119.
- 7. By 31 July 2026, the Commission shall present a report to the European Parliament and to the Council in which  it  shall  assess  the  feasibility  of  including  municipal  waste  incineration  installations  in  the  EU  ETS, including with a view to their inclusion from 2028 and with an assessment of the potential need for an option for a Member State to opt out until 31 December 2030. In that regard, the Commission shall take into account the  importance  of  all  sectors  contributing  to  emission  reductions  and  potential  diversion  of  waste  towards disposal by landfilling in the Union and waste exports to third countries. The Commission shall in addition take into  account  relevant  criteria  such  as  the  effects  on  the  internal  market,  potential  distortions  of  competition, environmental integrity, alignment with the objectives of Directive 2008/98/EC of the European Parliament and of  the Council (*) and robustness and accuracy with regard to the monitoring and calculation of emissions. The Commission  shall,  where  appropriate  and  without  prejudice  to  Article  4  of  that  Directive,  accompany  that report  with  a  legislative  proposal  to  apply  the  provisions  of  this  Chapter  to  greenhouse  gas  emissions  permits and the allocation and issue of additional allowances in respect of municipal waste incineration installations, and to prevent potential diversion of waste.

In the report referred to in the first subparagraph, the Commission shall also assess the possibility of including in the  EU  ETS  other  waste  management  processes,  in particular  landfills  which  create  methane  and  nitrous  oxide emissions in the Union. The Commission may, where appropriate, also accompany that report with a legislative proposal to include such other waste management processes in the EU ETS.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Directive 2008/98/EC of the European Parliament and of the Council of 19 November 2008 on waste and repealing certain Directives (OJ L 312, 22.11.2008, p. 3).';
- (29) the following Chapter is inserted after Article 30:

'Chapter IVa

Emissions Trading System for Buildings, Road Transport and additional Sectors

Article 30a

## Scope

The provisions of this Chapter shall apply to emissions, greenhouse gas emissions permits, the issue and surrender of allowances, monitoring, reporting and verification in respect of the activity referred to in Annex III. This Chapter shall not apply to any emissions covered by Chapters II and III.

Article 30b

## Greenhouse gas emissions permits

- 1. Member States shall ensure that, from 1 January 2025, no regulated entity carries out the activity referred to in Annex III unless that regulated entity holds a permit issued by a competent authority in accordance with paragraphs 2 and 3 of this Article.
- 2. An application to the competent authority by the regulated entity pursuant to paragraph 1 of this Article for a greenhouse gas emissions permit under this Chapter shall include, at least, a description of:
- (a) the regulated entity;

EN

- (b) the  type  of  fuels  it  releases  for  consumption  and  which  are  used  for  combustion  in  the  sectors  referred  to  in Annex III and the means through which it releases those fuels for consumption;
- (c) the end use or end uses of the fuels released for consumption for the activity referred to in Annex III;
- (d) the measures planned to monitor and report emissions, in accordance with the implementing acts referred to in Articles 14 and 30f;
- (e) a non-technical summary of the information referred to in points (a) to (d) of this paragraph.
- 3. The competent authority shall issue a greenhouse gas emissions permit granting authorisation to the regulated entity referred to in paragraph 1 of this Article for the activity referred to in Annex III, if it is satisfied that the entity is  capable of monitoring and reporting emissions corresponding to the quantities of fuels released for consumption pursuant to Annex III.
- 4. Greenhouse gas emissions permits shall contain, at least, the following:
- (a) the name and address of the regulated entity;
- (b) a description of the means by which the regulated entity releases the fuels for consumption in the sectors covered by this Chapter;
- (c) a list of the fuels the regulated entity releases for consumption in the sectors covered by this Chapter;
- (d) a monitoring plan that fulfils the requirements established by the implementing acts referred to in Article 14;
- (e) reporting requirements established by the implementing acts referred to in Article 14;
- (f) an obligation to surrender allowances issued under this Chapter, equal to the total emissions in each calendar year, as verified in accordance with Article 15, by the deadline laid down in Article 30e(2).
- 5. Member  States  may  allow  the  regulated  entities  to  update  monitoring  plans  without  changing  the  permit. Regulated entities shall submit any updated monitoring plans to the competent authority for approval.
- 6. The regulated entity shall inform the competent authority of any planned changes to the nature of its activity or to  the  fuels  it  releases  for  consumption,  which  may  require  updating  the  greenhouse  gas  emissions  permit.  Where appropriate, the competent authority shall update the permit in accordance with the implementing acts referred to in Article  14.  Where  there  is  a  change  in  the  identity  of  the  regulated  entity  covered  by  this  Chapter,  the  competent authority shall update the permit to include the name and address of the new regulated entity.

Article 30c

## Union-wide quantity of allowances

- 1. The Union-wide quantity of allowances issued under this Chapter each year from 2027 shall decrease in a linear manner beginning in 2024. The 2024 value shall be defined as the 2024 emission limits, calculated on the basis of the reference emissions under Article 4(2) of Regulation (EU) 2018/842 of the European Parliament and of the Council (*) for the sectors covered by this Chapter and applying the linear reduction trajectory for all emissions within the scope of  that  Regulation.  The  quantity  shall  decrease  each  year  after  2024  by  a  linear  reduction  factor  of  5,10  %.  By 1 January 2025, the Commission shall publish the Union-wide quantity of allowances for the year 2027.
- 2. The Union-wide quantity of allowances issued under this Chapter each year from 2028 shall decrease in a linear manner beginning from 2025 on the basis of the average emissions reported under this Chapter for the years 2024 to 2026. The quantity of allowances shall decrease by a linear reduction factor of 5,38 %, except if the conditions set out in  point  1  of  Annex  IIIa  apply,  in  which  case  the  quantity  shall  decrease  by  a  linear  reduction  factor  adjusted  in accordance  with  the  rules  set  out  in  point  2  of  Annex  IIIa.  By  30  June  2027,  the  Commission  shall  publish  the Union-wide quantity of allowances for 2028 and, if required, the adjusted linear reduction factor.

EN

- 3. The Union-wide quantity of allowances issued under this Chapter shall be adjusted for each year from 2028 to compensate for the quantity of allowances surrendered in cases where it was not possible to avoid double counting of emissions or where allowances have been surrendered for emissions not covered by this Chapter as referred to in Article  30f(5).  The  adjustment  shall  correspond  to  the  total  amount  of  allowances  covered  by  this  Chapter  which were compensated for in the relevant reporting year pursuant to the implementing acts referred to in Article 30f(5), second subparagraph.
- 4. A Member State that, pursuant to Article 30j, unilaterally extends the activity referred to in Annex III to sectors that are not listed in that Annex shall ensure that the regulated entities concerned submit, by 30 April of the relevant year,  to  the  relevant  competent  authority  a  duly  substantiated  report  in  accordance  with  Article  30f.  If  the  data submitted  are  duly  substantiated,  the  competent  authority  shall  notify  the  Commission  thereof  by  30  June  of  the relevant year. The quantity of allowances to be issued under paragraph 1 of this Article shall be adjusted taking into account the duly substantiated reports submitted by the regulated entities.

Article 30d

## Auctioning of allowances for the activity referred to in Annex III

- 1. From 2027, allowances covered by this Chapter shall be auctioned, unless they are placed in the market stability reserve established by Decision (EU) 2015/1814. The allowances covered by this Chapter shall be auctioned separately from the allowances covered by Chapters II and III of this Directive.
- 2. The  auctioning  of  the  allowances  under  this  Chapter  shall  start  in  2027  with  an  amount  corresponding  to 130 % of the auction volumes for 2027 established on the basis of the Union-wide quantity of allowances for  that year  and  the  respective  auction  shares  and  volumes  pursuant  to  paragraphs  3  to  6  of  this  Article.  The  additional 30  %  to  be  auctioned  shall  only  be  used  for  surrendering  allowances  pursuant  to  Article  30e(2)  and  may  be auctioned until 31 May 2028. The additional 30% shall be deducted from the auction volumes for the period from 2029  to  2031.  The  conditions  for  the  auctions  provided  for  in  this  paragraph  shall  be  set  in  accordance  with paragraph 7 of this Article and Article 10(4).

In 2027, 600 million allowances covered by this Chapter shall be created as holdings in the market stability reserve pursuant to Article 1a(3) of Decision (EU) 2015/1814.

- 3. 150 million allowances issued under this Chapter shall be auctioned and all revenues from those auctions made available for the Social Climate Fund established by Regulation (EU) 2023/955 until 2032.
- 4. From  the  remaining  amount  of  allowances  and  in  order  to  generate,  together  with  the  revenue  from  the allowances  referred  to  in  paragraph  3  of  this  Article  and  Article  10a(8b)  of  this  Directive,  a  maximum  amount  of EUR 65 000 000 000, the Commission shall ensure that an additional amount of allowances covered by this Chapter is  auctioned  and  the  revenues  from  those  auctions  are  made  available  for  the  Social  Climate  Fund  established  by Regulation (EU) 2023/955 until 2032.

The Commission shall ensure that the allowances destined for the Social Climate Fund referred to in paragraph 3 of this  Article  and  in  this  paragraph  are  auctioned  in  accordance  with  the  principles  and  modalities  referred  to  in Article 10(4) and the delegated acts adopted pursuant to that Article.

The revenues from the auctioning of the allowances referred to in paragraph 3 of this Article and in this paragraph shall constitute external assigned revenue in accordance with Article 21(5) of Regulation (EU, Euratom) 2018/1046, and shall be used in accordance with the rules applicable to the Social Climate Fund.

The  annual  amount  allocated  to  the  Social  Climate  Fund  in  accordance  with  Article  10a(8b),  paragraph  3  of  this Article and this paragraph shall not exceed:

- (a) for 2026, EUR 4 000 000 000;
- (b) for 2027, EUR 10 900 000 000;

EN

- (c) for 2028, EUR 10 500 000 000;
- (d) for 2029, EUR 10 300 000 000;
- (e) for 2030, EUR 10 100 000 000;
- (f) for 2031, EUR 9 800 000 000;
- (g) for 2032, EUR 9 400 000 000.

Where the emissions trading system established in accordance with this Chapter is postponed until 2028 pursuant to Article  30k,  the  maximum  amount  to  be  made  available  to  the  Social  Climate  Fund  in  accordance  with  the  first subparagraph of  this paragraph shall be EUR 54 600 000 000. In such a case, the annual amounts allocated to the Social  Climate  Fund  shall  not  exceed  cumulatively  for  the  years  2026  and  2027,  EUR  4 000 000 000,  and  for  the period from 1 January 2028 until 31 December 2032, the relevant annual amount shall not exceed:

- (a) for 2028, EUR 11 400 000 000;
- (b) for 2029, EUR 10 300 000 000;
- (c) for 2030, EUR 10 100 000 000;
- (d) for 2031, EUR 9 800 000 000;
- (e) for 2032, EUR 9 000 000 000.

Where  revenue  generated  from  the  auctioning  referred  to  in  paragraph  5  of  this  Article  is  established  as  an  own resource in accordance with Article 311, third paragraph, TFEU, Article 10a(8b) of this Directive, paragraph 3 of this Article and this paragraph shall not be applicable.

- 5. The total quantity of allowances covered by this Chapter, after deducting the quantities set out in paragraphs 3 and  4  of  this  Article,  shall  be  auctioned  by  the  Member  States  and  distributed  amongst  them  in  shares  that  are identical  to  the  share  of  reference  emissions  under  Article  4(2)  of  Regulation  (EU)  2018/842  for  the  categories  of emission  sources  referred  to  in  the  second  paragraph,  points  (b),  (c)  and  (d),  of  Annex  III  to  this  Directive  for  the average of the period from 2016 to 2018 of the Member State concerned, as comprehensively reviewed pursuant to Article 4(3) of that Regulation.
- 6. Member States shall determine the use of revenues generated from the auctioning of allowances referred to in paragraph  5  of  this  Article,  except  for  the  revenues  constituting  external  assigned  revenue  in  accordance  with paragraph  4  of  this  Article  or  the  revenues  established  as  own  resources  in  accordance  with  Article  311,  third paragraph,  TFEU  and  entered  in  the  Union  budget.  Member  States  shall  use  their  revenues  or  the  equivalent  in financial value of those revenues for one or more of the purposes referred to in Article 10(3) of this Directive, giving priority to activities that can contribute to addressing social aspects of the emissions trading under this Chapter, or for one or more of the following:
- (a) measures intended to contribute to the decarbonisation of heating and cooling of buildings or to the reduction of the energy needs of buildings, including the integration of renewable energies and related measures in accordance with  Article  7(11)  and  Articles  12  and  20  of  Directive  2012/27/EU,  as  well  as  measures  to  provide  financial support for low-income households in worst-performing buildings;
- (b) measures  intended  to  accelerate  the  uptake  of  zero-emission  vehicles  or  to  provide  financial  support  for  the deployment  of  fully  interoperable refuelling and  recharging  infrastructure for zero-emission  vehicles, or measures to encourage a shift to public transport and improve multimodality, or to provide financial support in order to address social aspects concerning low- and middle-income transport users;
- (c) to finance their Social Climate Plan in accordance with Article 15 of Regulation (EU) 2023/955;
- (d) to provide financial compensation to the final consumers of fuels in cases where it has not been possible to avoid double  counting  of  emissions  or  where  allowances  have  been  surrendered  for  emissions  not  covered  by  this Chapter as referred to in Article 30f(5).

EN

Member  States  shall  be  deemed  to  have  fulfilled  the  provisions  of  this  paragraph  if  they  have  in  place  and implement fiscal or financial support policies or regulatory policies which leverage financial support, established for  the  purposes  set  out  in  the  first  subparagraph  of  this  paragraph,  and  which  have  a  value  equivalent  to  the revenues referred to in that subparagraph generated from the auctioning of allowances referred to in this Chapter.

Member States  shall  inform  the  Commission  as  to  the  use  of  revenues  and  the  actions  taken  pursuant  to  this paragraph by including this information in their reports submitted under Regulation (EU) 2018/1999.

- 7. Article 10(4) and (5) shall apply to the allowances issued under this Chapter.

Article 30e

## Transfer, surrender and cancellation of allowances

- 1. Article  12  shall  apply  to  the  emissions,  regulated  entities  and  allowances  covered  by  this  Chapter,  with  the exception of paragraphs 3 and 3a, paragraph 4, second and third sentence, and paragraph 5 of that Article. For that purpose:
- (a) any reference to emissions shall be read as if it were a reference to the emissions covered by this Chapter;
- (b) any reference to operators of installations shall be read as if it were a reference to the regulated entities covered by this Chapter;
- (c) any reference to allowances shall be read as if it were a reference to the allowances covered by this Chapter.
- 2. From 1 January 2028, Member States shall ensure that, by 31 May each year, the regulated entity surrenders an amount of allowances covered by this Chapter that is equal to the regulated entity's total emissions, corresponding to the quantity of fuels released for consumption pursuant to Annex III, during the preceding calendar year as verified in accordance with Articles 15 and 30f, and that those allowances are subsequently cancelled.
- 3. Until  31  December  2030,  by  way  of  derogation  from  paragraphs  1  and  2  of  this  Article,  where  a  regulated entity established  in  a  given  Member  State  is  subject  to  a  national  carbon  tax  in  force  for  the  years  2027  to  2030, covering the activity referred to in Annex III, the competent authority of  the Member State concerned may exempt that  regulated  entity  from  the  obligation  to  surrender  allowances  under  paragraph  2  of  this  Article  for  a  given reference year, provided that:
- (a) the Member State concerned notifies the Commission of that national carbon tax by 31 December 2023, and the national law setting the tax rates applicable for the years 2027 to 2030 has, by that date, entered into force; the Member State concerned shall notify the Commission of any subsequent change to the national carbon tax;
- (b) for  the reference year, the national carbon tax of the Member State concerned effectively paid by that regulated entity  is  higher  than  the  average  auction  clearing  price  of  the  emissions  trading  system  established  under  this Chapter;
- (c) the regulated entity fully complies with the obligations under Article 30b on greenhouse emissions permits and Article 30f on monitoring, reporting and verification of its emissions;
- (d) the  Member  State  concerned  notifies  the  Commission  of  the  application  of  any  such  exemption  and  the corresponding amount of allowances to be cancelled in accordance with point (g) of this subparagraph and the delegated acts adopted pursuant to Article 10(4), by 31 May of the year after the reference year;
- (e) the Commission does not raise an objection to the application of the derogation on the ground that the measure notified is not in conformity with the conditions set out in this paragraph, within three months of a notification under point (a) of this subparagraph or  within one month of the notification for  the relevant year  under  point (d) of this subparagraph;

EN

- (f) the  Member  State  concerned  does  not  auction  the  amount  of  allowances  referred  to  in  Article  30d(5)  for  a particular  reference year  until  the  amount of allowances  to be  cancelled  under  this  paragraph is  determined  in accordance  with  point  (g)  of  this  subparagraph;  the  Member  State  concerned  shall  not  auction  any  of  the additional amount of allowances pursuant to Article 30d(2), first subparagraph;
- (g) the  Member  State  concerned  cancels  an  amount  of  allowances  from  the  total  quantity  of  allowances  to  be auctioned by it,  referred  to in  Article  30d(5),  for  the  reference year,  which is  equal  to the  verified  emissions  of that regulated entity under  this Chapter for  the reference year; where the amount of allowances that remains to be auctioned in the reference year following application of point (f) of this subparagraph is below the amount of allowances  to  be  cancelled  under  this  paragraph,  the  Member  State  concerned  shall  ensure  that  it  cancels  the amount of allowances corresponding to the difference by the end of the year after the reference year; and
- (h) the Member State concerned commits, at the time of the first notification under point (a) of this subparagraph, to using  for  one  or  more  of  the  measures  listed  or  referred  to  in  Article  30d(6),  first  subparagraph,  an  amount equivalent  to  the  revenues  to  which  Article  30d(6)  would  have  applied  in  the  absence  of  this  derogation; Article 30d(6),  second  and  third  subparagraphs,  shall  apply  and  the  Commission  shall  ensure  that  the information received pursuant thereto is in conformity with the commitment made under this point.
- The  amount of  allowances  to  be  cancelled  under  the  first  subparagraph,  point  (g),  of  this  paragraph  shall  not affect the external assigned revenue established pursuant to Article 30d(4) of this Directive or, where it has been established pursuant to Article 311, third paragraph, TFEU, the own resources of the Union budget pursuant to Council Decision (EU, Euratom) 2020/2053 (**) from the revenues generated from auctioning of allowances in accordance with Article 30d of this Directive.
- 4. Hospitals which are not covered by Chapter III may be provided with financial compensation for the cost passed on to them due to the surrender of allowances under  this Chapter. For  that purpose, the provisions of this Chapter applicable to cases of double counting shall apply mutatis mutandis .

Article 30f

## Monitoring, reporting, verification of emissions and accreditation

- 1. Articles 14 and 15 shall apply to the emissions, regulated entities and allowances covered by this Chapter. For that purpose:
- (a) any reference to emissions shall be read as if it were a reference to the emissions covered by this Chapter;
- (b) any reference to an activity listed in Annex I shall be read as if  it were a reference to the activity  referred to in Annex III;
- (c) any reference to operators shall be read as if it were a reference to the regulated entities covered by this Chapter;
- (d) any reference to allowances shall be read as if it were a reference to the allowances covered by this Chapter;
- (e) the reference to the date in Article 15 shall be read as if it were a reference to 30 April.
- 2. Member States shall ensure that each regulated entity monitors for each calendar year from 2025 the emissions corresponding to the quantities of fuels released for consumption pursuant to Annex III. They shall also ensure that each regulated entity reports those emissions to the competent authority in the following year, starting in 2026, in accordance with the implementing acts referred to in Article 14(1).
- 3. From 1 January 2028, Member States shall ensure that, by 30 April each year until 2030, each regulated entity reports  the  average  share  of  costs  related  to  the  surrender  of  allowances  under  this  Chapter  which  it  passed  on  to consumers for the preceding year. The Commission shall adopt implementing acts concerning the requirements and templates for those reports. Those implementing acts shall be adopted in accordance with the examination procedure referred to in Article 22a(2). The Commission shall assess the submitted reports and annually report its findings to the European Parliament and to the Council. Where the Commission finds that improper practices exist with regard to the passing  on  of  carbon  costs,  the  report  may  be  accompanied,  where  appropriate,  by  legislative  proposals  aimed  at addressing such improper practices.

EN

- 4. Member  States  shall  ensure  that  each  regulated  entity  holding  a  permit  in  accordance  with  Article  30b  on 1 January 2025 reports its historical emissions for the year 2024 by 30 April 2025.
- 5. Member States shall ensure that the regulated entities are able to identify and document reliably and accurately, per type of fuel, the precise quantities of fuel released for consumption which are used for combustion in the sectors referred to in Annex III, and the final use of the fuels released for consumption by the regulated entities. The Member States shall take appropriate measures to limit the risk of double counting of emissions covered under  this Chapter and  the  emissions  under  Chapters  II  and  III,  as  well  as  the  risk  of  allowances  being  surrendered  for  emissions  not covered by this Chapter.

The  Commission  shall  adopt  implementing  acts  concerning  the  detailed  rules  for  avoiding  double  counting  and allowances  being  surrendered  for  emissions  not  covered  by  this  Chapter,  as  well  as  for  providing  financial compensation  to  the  final  consumers  of  the  fuels  in  cases  where  such  double  counting  or  surrender  cannot  be avoided.  Those  implementing  acts  shall  be  adopted  in  accordance  with  the  examination  procedure  referred  to  in Article 22a(2). The calculation of the financial compensation for  the final consumers of the fuels shall be based on the average price of allowances in the auctions carried out in accordance with the delegated acts adopted pursuant to Article 10(4) in the relevant reporting year.

- 6. The principles for monitoring and reporting of emissions covered by this Chapter are set out in Part C of Annex IV.
- 7. The criteria for the verification of emissions covered by this Chapter are set out in Part C of Annex V.
- 8. Member  States  may  allow  simplified  monitoring,  reporting  and  verification  measures  for  regulated  entities whose annual emissions corresponding to the quantities of fuels released for consumption are less than 1 000 tonnes of CO2 equivalent, in accordance with the implementing acts referred to in Article 14(1).

Article 30g

## Administration

Articles 13 and 15a, Article 16(1), (2), (3), (4) and (12), and Articles 17, 18, 19, 20, 21, 22, 22a, 23 and 29 shall apply to the emissions, regulated entities and allowances covered by this Chapter. For that purpose:

- (a) any reference to emissions shall be read as if it were a reference to emissions covered by this Chapter;
- (b) any reference to operators shall be read as if it were a reference to regulated entities covered by this Chapter;
- (c) any reference to allowances shall be read as if it were a reference to the allowances covered by this Chapter.

Article 30h

## Measures in the event of an excessive price increase

- 1. Where, for more than three consecutive months, the average price of allowances in the auctions carried out in accordance with the delegated acts adopted pursuant to Article 10(4) of this Directive is more than twice the average price of allowances during the six preceding consecutive months in the auctions for  the allowances covered by this Chapter,  50  million  allowances  covered  by  this  Chapter  shall  be  released  from  the  market  stability  reserve  in accordance with Article 1a(7) of Decision (EU) 2015/1814.

For the years 2027 and 2028, the condition referred to in the first subparagraph shall be met where, for more than three  consecutive  months,  the  average  price  of  allowances  is  more  than  1,5  times  the  average  price  of  allowances during the reference period of the six preceding consecutive months.

- 2. Where the average price of allowances referred to in paragraph 1 of this Article exceeds a price of EUR 45 for a period of two consecutive months, 20 million allowances covered by this Chapter shall be released from the market stability  reserve  in  accordance  with  Article  1a(7)  of  Decision  (EU)  2015/1814.  Indexation  based  on  the  European index of consumer prices for 2020 shall apply. Allowances shall be released through the mechanism provided for in this paragraph up to 31 December 2029.

EN

- 3. Where the average price of allowances referred to in paragraph 1 of this Article is more than three times the average  price  of  allowances  during  the  six  preceding  consecutive  months,  150  million  allowances  covered  by  this Chapter shall be released from  the market stability reserve in accordance with Article 1a(7) of Decision (EU) 2015/1814.
- 4. Where the condition referred to in paragraph 2 has been met on the same day as the condition referred to in paragraph 1 or 3, additional allowances shall be released only pursuant to paragraph 1 or 3.
- 5. Before  31  December  2029,  the  Commission  shall  present  a  report  to  the  European  Parliament  and  to  the Council  in  which  it  assesses  whether  the  mechanism  referred  to  in  paragraph  2  has  been  effective  and  whether  it should be continued. The Commission shall, where appropriate, accompany that report with a legislative proposal to the European Parliament and to the Council to amend this Directive to adjust that mechanism.
- 6. Where one or more of the conditions referred to in paragraph 1, 2 or 3 have been met and resulted in a release of allowances, additional allowances shall not be released pursuant to this Article earlier than 12 months thereafter.
- 7. Where,  within  the  second  half  of  the  period  of  12  months  referred  to  in  paragraph  6  of  this  Article,  the condition  referred  to  in  paragraph  2  of  this  Article  has  been  met  again,  the  Commission  shall,  assisted  by  the Committee established by Article 44 of Regulation (EU) 2018/1999, assess the effectiveness of the measure and may by means of an implementing act decide that paragraph 6 of this Article is not to apply. That implementing act shall be adopted in accordance with the examination procedure referred to in Article 22a(2) of this Directive.
- 8. Where one or more of the conditions referred to in paragraph 1, 2 or 3 have been met and paragraph 6 is not applicable, the Commission shall promptly publish a notice in the Official  Journal  of  the  European  Union concerning the date on which that or those conditions were met.
- 9. Member States that are subject to the obligation to provide a corrective action plan in accordance with Article 8 of Regulation (EU) 2018/842 shall take due account of the effects of a release of additional allowances pursuant to paragraph 2 of this Article during the previous two years when considering additional actions to be implemented as referred to in Article 8(1), first  subparagraph, point (c), of  that Regulation in order  to meet their obligations under that Regulation.

Article 30i

## Review of this Chapter

- By  1  January  2028,  the  Commission  shall  report  to  the  European  Parliament  and  to  the  Council  on  the implementation  of  the  provisions  of  this  Chapter  with  regard  to  their  effectiveness,  administration  and  practical application,  including  on  the  application  of  the  rules  under  Decision  (EU)  2015/1814.  Where  appropriate,  the Commission shall accompany that report with a legislative proposal to amend this Chapter. By 31 October 2031, the Commission shall assess the feasibility of integrating the sectors covered by Annex III to this Directive into the EU ETS covering the sectors listed in Annex I to this Directive.

Article 30j

## Procedures for  unilateral extension of  the activity referred to in Annex III to other sectors not subject to Chapters II and III

- 1. From 2027, Member States may extend the activity referred to in Annex III to sectors that are not listed in that Annex and thereby apply emissions trading in accordance with this Chapter in such sectors, taking into account all relevant criteria, in particular the effects on  the internal market, potential distortions of competition, the environmental integrity of the emissions trading system established pursuant to this Chapter and the reliability of the planned  monitoring  and  reporting  system,  provided  that  the  extension  of  the  activity  referred  to  in  that  Annex  is approved by the Commission.

EN

The Commission is empowered to adopt delegated acts in accordance with Article 23 to supplement this Directive concerning the approval of an extension as referred to in the first subparagraph of this paragraph, authorisation for the  issue  of  additional  allowances  and  authorisation  of  other  Member  States  to  extend  the  activity  referred  to  in Annex  III.  The  Commission  may  also,  when  adopting  such  delegated  acts,  supplement  the  extension  with  further rules  governing  measures  to  address  possible  instances  of  double  counting,  including  for  the  issue  of  additional allowances  to  compensate  for  allowances  surrendered  for  use  of  fuels  in  activities  listed  in  Annex  I.  Any  financial measures by Member States in favour of companies in sectors and subsectors which are exposed to a genuine risk of carbon leakage, due to significant indirect costs that are incurred from greenhouse gas emission costs passed on in fuel  prices  due  to  the  unilateral  extension,  shall  be  in  accordance  with  State  aid  rules,  and  shall  not  cause  undue distortions of competition in the internal market.

- 2. Additional allowances issued pursuant to an authorisation under this Article shall be auctioned in line with the requirements  laid  down  in  Article  30d.  Notwithstanding  Article  30d(1)  to  (6),  Member  States  having  unilaterally extended  the  activity  referred  to  in  Annex  III  in  accordance  with  this  Article  shall  determine  the  use  of  revenues generated from the auctioning of those additional allowances.

Article 30k

Postponement of emissions  trading  for  buildings,  road  transport  and  additional  sectors  until  2028  in  the event of exceptionally high energy prices

- 1. By 15 July 2026, the Commission shall publish a notice in the Official Journal of the European Union concerning whether one or both of the following conditions have been met:
- (a) the average TTF gas price for the six calendar months ending 30 June 2026 was higher than the average TTF gas price in February and March 2022;
- (b) the  average  Brent  crude  oil  price  for  the  six  calendar  months  ending  30  June  2026 was  more  than  twice  the average Brent crude oil price during the five preceding years; the five-year reference period shall be the five-year period that ends before the first month of the period of six calendar months.
- 2. Where one or both of the conditions referred to in paragraph 1 are met, the following rules shall apply:
- (a) by  way  of  derogation  from  Article  30c(1),  the  first  year  for  which  the  Union-wide  quantity  of  allowances  is established shall be 2028 and, by way of derogation from Article 30c(3), the first year for which the Union-wide quantity of allowances is adjusted shall be 2029;
- (b) by way of derogation from Article 30d(1) and (2), the start of auctioning of allowances under this Chapter shall be postponed to 2028;
- (c) by way of derogation from Article 30d(2), the additional amount of allowances for the first year of auctions shall be deducted from the auction volumes for the period from 2030 to 2032 and the initial holdings in the market stability reserve shall be created in 2028;
- (d) by way of derogation from Article 30e(2), the deadline for initial surrendering of allowances shall be put back to 31 May 2029 for total emissions in the year 2028;
- (e) by way of derogation from Article 30i, the deadline for the Commission to report to the European Parliament and to the Council shall be put back to 1 January 2029.

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation (EU) 2018/842 of the European Parliament and of the Council of 30 May 2018 on binding annual greenhouse  gas  emission  reductions  by  Member  States  from  2021  to  2030  contributing  to  climate  action  to meet commitments under the Paris Agreement and amending Regulation (EU) No 525/2013 (OJ L 156, 19.6.2018, p. 26).
- (**) Council  Decision  (EU,  Euratom)  2020/2053  of  14  December  2020  on  the  system  of  own  resources  of  the European Union and repealing Decision 2014/335/EU, Euratom (OJ L 424, 15.12.2020, p. 1).';

EN

16.5.2023

- (30) the following Chapter is inserted:

'Chapter IVb

Scientific Advice and Visibility of Funding

Article 30l

## Scientific advice

The European Scientific Advisory Board on Climate Change (the 'Advisory Board') established under Article 10a of Regulation (EC) No 401/2009 of the European Parliament and of the Council (*) may, on its own initiative, provide scientific  advice  and  issue  reports  regarding  this  Directive.  The  Commission  shall  take  into  account  the  relevant advice and reports of the Advisory Board, in particular as regards:

- (a) the need for additional Union policies and measures to ensure compliance with the objectives and targets referred to in Article 30(3) of this Directive;
- (b) the need for additional Union policies and measures in view of agreements on global measures within ICAO to reduce  the  climate  impact  of  aviation,  and  of  the  ambition  and  environmental  integrity  of  the  global  marketbased measure of the IMO referred to in Article 3gg of this Directive.

Article 30m

## Information, communication and publicity

- 1. The  Commission  shall  ensure  the  visibility  of  funding  from  EU  ETS  auctioning  revenues  referred  to  in Article 10a(8) by:
- (a) ensuring that the beneficiaries of such funding acknowledge the origin of those funds and ensure the visibility of the Union funding, in particular when promoting the projects and their results, by providing coherent, effective and proportionate targeted information to multiple audiences, including the media and the public; and
- (b) ensuring that the recipients of such funding use an appropriate label that reads '(co-)funded by the EU Emissions Trading System (the Innovation Fund)', as well as the emblem of  the Union and the amount of funding; where the  use  of  that  label  is  not  feasible,  the  Innovation  Fund  shall  be  mentioned  in  all  communication  activities, including on notice boards at strategic places visible to the public.
- The  Commission  shall  in  the  delegated  act  referred  to  in  Article  10a(8)  set  out  the  necessary  requirements  to ensure the visibility of funding from the Innovation Fund, including a requirement to mention that Fund.
- 2. Member States shall ensure the visibility of funding from EU ETS auctioning revenues referred to in Article 10d corresponding to what is referred to in paragraph 1, first subparagraph, points (a) and (b), of this Article, including through a requirement to mention the Modernisation Fund.
- 3. Taking into account national circumstances, the Member States shall endeavour  to ensure the visibility of the source of  the funding of actions or  projects funded from the EU ETS auctioning revenues of which they determine the use in accordance with Article 3d(4), Article 10(3) and Article 30d(6).

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Regulation (EC) No 401/2009 of the European Parliament and of the Council of 23 April 2009 on the European Environment  Agency  and  the  European  Environment  Information  and  Observation  Network  (OJ  L  126, 21.5.2009, p. 13).';
- (31) Annexes  I,  IIb,  IV and  V  to  Directive  2003/87/EC  are  amended  in  accordance  with  Annex  I  to  this  Directive,  and Annexes III and IIIa are inserted in Directive 2003/87/EC as set out in Annex I to this Directive.

EN

L  130/192

## Article 2

## Amendments to Decision (EU) 2015/1814

Decision (EU) 2015/1814 is amended as follows:

- (1) Article 1 is amended as follows:
- (a) paragraph 4 is replaced by the following:
- '4. The  Commission  shall  publish  the  total  number  of  allowances  in  circulation  each  year  by  1  June  of  the subsequent year. The total number of allowances in circulation in a given year shall be the cumulative number of allowances issued in respect of installations and shipping companies and not placed in the reserve in the period since  1  January  2008,  including  the  number  of  allowances  that  were  issued  pursuant  to  Article  13(2)  of Directive  2003/87/EC,  in  the  version  in  force  on  18  March  2018,  in  that  period  and  entitlements  to  use international credits exercised by installations under the EU ETS, up to 31 December of that given year, minus the cumulative  tonnes  of  verified  emissions  from  installations  and  shipping  companies  under  the  EU  ETS  between 1  January  2008 and  31  December of  that  same  given  year,  and  any  allowances  cancelled  in  accordance  with Article  12(4)  of  Directive  2003/87/EC.  No  account  shall  be  taken  of  emissions  during  the  three-year  period starting  in  2005  and  ending  in  2007  and  allowances  issued  in  respect  of  those  emissions.  The  first  publication shall take place by 15 May 2017.';
- (b) the following paragraph is inserted:
- '4a. As  from  2024,  the  calculation  of  the  total  number  of  allowances  in  circulation  in  any  given  year  shall include the cumulative number of allowances issued in respect of aviation and the cumulative tonnes of verified emissions  from  aviation  under  the  EU  ETS,  excluding  emissions  from  flights  on  routes  covered  by  offsetting calculated pursuant to Article 12(6) of Directive 2003/87/EC, between 1 January 2024 and 31 December of that same given year.

The allowances cancelled pursuant to Article 3gb of Directive  2003/87/EC shall be considered as issued for  the purposes of the calculation of the total number of allowances in circulation.';

- (c) paragraphs 5 and 5a are replaced by the following:
- '5. In any given year, if the total number of allowances in circulation is between 833 million and 1 096 million, a number of allowances equal to the difference between the total number of allowances in circulation, as set out in the most recent publication as referred to in paragraph 4 of this Article, and 833 million shall be deducted from the quantity of allowances to be auctioned by the Member States under Article 10(2) of Directive 2003/87/EC and shall be placed in the reserve over a period of 12 months beginning on 1 September of that year. If the total number of allowances in circulation is above 1 096 million allowances, the number of allowances to be deducted from the quantity of allowances to be auctioned by the Member States under Article 10(2) of Directive 2003/87/EC and to be placed in the reserve over a period of 12 months beginning on 1 September of that year shall be equal to 12 % of  the  total  number  of  allowances  in  circulation.  By  way  of  derogation  from  the  second  sentence  of  this subparagraph, until 31 December 2030, the percentage referred to in that sentence shall be doubled.

Without prejudice to the total number of allowances to be deducted pursuant to this paragraph, until 31 December 2030, allowances referred to in Article 10(2), first subparagraph, point (b), of Directive 2003/87/EC shall not be taken into account when determining Member States' shares contributing to that total amount.

- 5a. Unless otherwise decided in the first review carried out in accordance with Article 3, from 2023 allowances held in the reserve above 400 million allowances shall no longer be valid.';

## (d) paragraph 7 replaced by the following:

- '7. In  any  given  year,  if  paragraph  6  of  this  Article  is  not  applicable  and  the  condition  in  Article  29a(1)  of Directive  2003/87/EC  has  been  met,  75  million  allowances  shall  be  released  from  the  reserve  and  added  to  the quantity of allowances to be auctioned by the Member States under Article 10(2) of  that Directive. Where fewer than 75 million allowances are in the reserve, all allowances in the reserve shall be released under this paragraph. Where  the  condition  in  Article  29a(1)  of  that  Directive  is  met,  the  volumes  to  be  released  from  the  reserve  in

EN

accordance with that Article shall be evenly distributed during a period of three months, starting no later than two months from the date when the condition in Article 29a(1) of that Directive is met as notified by the Commission in accordance with the fourth subparagraph thereof.';

- (2) the following Article is inserted:

' Article 1a

## Operation of the market stability reserve for the buildings, road transport and additional sectors

- 1. Allowances  covered  by  Chapter  IVa  of  Directive  2003/87/EC  shall  be  placed  in  and  released  from  a  separate section  of  the  reserve  established  pursuant  to Article  1  of  this  Decision,  in  accordance  with  the  rules  set  out  in  this Article.
- 2. The placing of allowances in the reserve under this Article shall operate from 1 September 2028. The allowances covered by Chapter IVa of Directive 2003/87/EC shall be placed in, held in, and released from the reserve separately from the allowances covered by Article 1 of this Decision.
- 3. In 2027, the section referred to in paragraph 1 of this Article shall be created in accordance with Article 30d(2), second subparagraph, of Directive 2003/87/EC. From 1 January 2031, the allowances referred to in that subparagraph that have not been released from the reserve shall no longer be valid.
- 4. The  Commission  shall  publish  the  total  number  of  allowances  in  circulation  covered  by  Chapter  IVa  of Directive  2003/87/EC  each  year,  by  1  June  of  the  subsequent  year,  separately  from  the  number  of  allowances  in circulation  under  Article  1(4)  of  this  Decision.  The  total  number  of  allowances  in  circulation  under  this  Article  in  a given year shall be the cumulative number of allowances covered by that Chapter issued in the period since 1 January 2027, minus the cumulative tonnes of verified emissions covered by that Chapter for  the period between 1 January 2027 and 31 December of that same given year and any allowances covered by that Chapter cancelled in accordance with Article 12(4) of Directive 2003/87/EC. The first publication shall take place by 1 June 2028.
- 5. In  any  given year,  if  the  total  number  of allowances  in  circulation,  as  set out  in  the  most  recent  publication  as referred to in paragraph 4 of this Article, is above 440 million allowances, 100 million allowances shall be deducted from  the quantity  of allowances covered  by  Chapter  IVa of Directive 2003/87/EC  to  be  auctioned  by  the Member  States  under  Article  30d  of  that  Directive  and  shall  be  placed  in  the  reserve  over  a  period  of  12  months beginning on 1 September of that year.
- 6. In  any  given  year,  if  the  total  number  of  allowances  in  circulation  is  lower  than  210  million,  100  million allowances  covered  by  Chapter  IVa  of  Directive  2003/87/EC  shall  be  released  from  the  reserve  and  added  to  the quantity  of  allowances  covered  by  that  Chapter  to  be  auctioned  by  the  Member  States  under  Article  30d  of  that Directive. Where fewer  than 100 million allowances are in the reserve, all allowances in the reserve shall be released under this paragraph.
- 7. The volumes to be released from the reserve in accordance with Article 30h of Directive 2003/87/EC shall be added to the quantity of allowances covered by Chapter IVa of  that Directive to be  auctioned  by the Member  States under  Article  30d  of  that  Directive.  The  volumes  to  be  released  from  the  reserve  shall  be  evenly  distributed  over  a period of three months, starting no later than two months after the date on which the conditions were met according to the  publication  in  that  regard  in  the Official Journal of the European  Union pursuant  to  Article  30h(8)  of Directive 2003/87/EC.
- 8. Article 1(8) and  Article 3 of this Decision  shall apply  to the allowances  covered  by  Chapter  IVa  of Directive 2003/87/EC.
- 9. By way of derogation from paragraphs 2, 3 and 4 of this Article, where one or both of the conditions referred to in Article 30k(1) of Directive 2003/87/EC are met, the placing of allowances in the reserve referred to in paragraph 2 of this Article shall operate from 1 September 2029 and the dates referred to in paragraphs 3 and 4 of this Article shall be put back by one year.';

EN

- (3) Article 3 is replaced by the following:

' Article 3

## Review

The Commission shall monitor the functioning of the reserve in the context of the report provided for in Article 10(5) of Directive 2003/87/EC. That report should consider relevant effects on competitiveness, in particular in the industrial sector,  including  in  relation  to  GDP,  employment  and  investment  indicators.  Within  three  years  of  the  start  of  the operation of the reserve and at five-year intervals thereafter, the Commission shall, on the basis of an analysis of the orderly  functioning  of  the  European  carbon  market,  review  the  reserve  and  submit  a  legislative  proposal,  where appropriate,  to  the  European  Parliament  and  to  the  Council.  Each  review  shall  pay  particular  attention  to  the percentage  figure  for  the  determination  of  the  number  of  allowances  to  be  placed  in  the  reserve  pursuant  to Article  1(5)  of  this  Decision,  the  numerical  value  of  the  threshold  for  the  total  number  of allowances  in  circulation, including with a view to a potential adjustment of that threshold in line with the linear factor referred to in Article 9 of Directive 2003/87/EC, as well as the number of allowances to be released from the reserve pursuant to Article 1(6) or (7) of  this  Decision.  In  its  review,  the  Commission shall  also  look  into  the impact of  the reserve  on growth, jobs, and the Union's industrial competitiveness and on the risk of carbon leakage.'.

## Article 3

## Transposition

- 1. Member States shall bring into force the laws, regulations and  administrative provisions necessary to comply with Article 1 of this Directive by 31 December 2023. They shall apply those measures from 1 January 2024.

However, Member States shall bring into force the laws, regulations and administrative provisions necessary to comply with the following articles by 30 June 2024:

- (a) Article 1, point (3), points (ae) to (ai), of this Directive;
- (b) Article 1, point (29), of this Directive with the exception of Article 30f(4) of Directive 2003/87/EC as inserted by that point; and
- (c) Article 1, point (31), of this Directive regarding Annexes III and IIIa to Directive 2003/87/EC as inserted by that point.

They  shall  immediately  inform  the  Commission  of  the  measures  adopted  in  accordance  with  the  first  and  second subparagraphs.

When Member States adopt those measures, they shall contain a reference to this Directive or shall be accompanied by such reference  on  the  occasion  of  their  official  publication.  The  methods  of  making  such  reference  shall  be  laid  down  by Member States.

- 2. Member States shall communicate to the Commission the text of the main measures of national law which they adopt in the field covered by this Directive.

## Article 4

## Transitional provisions

When  complying  with  their  obligation  set  out  in  Article  3(1)  of  this  Directive,  Member  States  shall  ensure  that  their national legislation transposing Article 3, point (u), Article 10a(3) and (4), Article 10c(7) and Annex I, points 1 and 3, of Directive  2003/87/EC, in  its  version  applicable  on  4  June  2023,  continue  to  apply  until  31  December  2025.  By  way of derogation  from  Article  3(1),  first  subparagraph,  last  sentence,  they  shall  apply  their  national  measures  transposing amendments to those provisions from 1 January 2026.

<!-- image -->

EN

16.5.2023

## Article 5

## Entry into force and application

This  Directive  shall  enter  into  force  on  the  twentieth  day  following  that  of  its  publication  in  the Official  Journal  of  the European Union .

Article 2 shall apply from 1 January 2024.

Article 6

## Addressees

This Directive is addressed to the Member States.

Done at Strasbourg, 10 May 2023.

For the European Parliament The President R. METSOLA

For the Council The President J. ROSWALL

EN

L  130/196

## ANNEX

- (1) Annex I to Directive 2003/87/EC is amended as follows:

(a) point 1 is replaced by the following:

'1. Installations or parts of installations used for research, development and testing of new products and processes are not covered by this Directive. Installations where during the preceding relevant five-year period referred to in  Article  11(1),  second  subparagraph,  emissions  from  the  combustion  of  biomass  that  complies  with  the criteria  set  out  pursuant  to  Article  14  contribute  on  average  to  more  than  95  %  of  the  total  average greenhouse gas emissions are not covered by this Directive.';

(b) point 3 is replaced by the following:

'3. When the total rated thermal input of an installation is calculated in order to decide upon its inclusion in the EU ETS, the rated thermal inputs of all technical units which are part of it, in which fuels are combusted within the installation, shall be added together. Those units may include all types of boilers, burners, turbines, heaters, furnaces,  incinerators,  calciners,  kilns,  ovens,  dryers,  engines,  fuel  cells,  chemical  looping  combustion  units, flares, and thermal or catalytic post-combustion units. Units with a rated thermal input under 3 MW shall not be taken into account for the purposes of this calculation.';

(c) the table is amended as follows:

(i) the first row is replaced by the following:

'Combustion of fuels in installations with a total rated thermal input exceeding 20 MW (except in installations for the incineration of hazardous or municipal waste)

From 1 January 2024, combustion of fuels in installations for the incineration of municipal waste with a total rated thermal input exceeding 20 MW, for the purposes of Articles 14 and 15.

Carbon dioxide'

(ii) the second row is replaced by the following:

'Refining of oil, where combustion units with a total rated thermal input exceeding 20 MW are operated

Carbon dioxide'

(iii) the fifth row is replaced by the following:

'Production of iron or steel (primary or secondary fusion) including continuous casting, with a capacity exceeding 2,5 tonnes per hour

Carbon dioxide'

(iv) the seventh row is replaced by the following:

'Production of primary aluminium or alumina

Carbon dioxide and perfluorocarbons'

(v) the fifteenth row is replaced by the following:

'Drying or calcination of gypsum or production of plaster boards and other gypsum products, with a production capacity of calcined gypsum or dried secondary gypsum exceeding a total of 20 tonnes per day

Carbon dioxide'

EN

16.5.2023

(vi) the eighteenth row is replaced by the following:

'Production of carbon black involving the carbonisation of organic substances such as oils, tars, cracker and distillation residues with a production capacity exceeding 50 tonnes per day

Carbon dioxide'

(vii) the twenty-fourth row is replaced by the following:

'Production of hydrogen (H ) and synthesis gas with a production capacity exceeding 2 5 tonnes per day

Carbon dioxide'

(viii) the twenty-seventh row is replaced by the following:

'Transport of greenhouse gases for geological storage in a storage site permitted under Directive 2009/31/EC, with the exclusion of those emissions covered by another activity under this Directive

Carbon dioxide'

(ix) the following row is added after the last new row, with a separation line in between:

'Maritime transport

Maritime transport activities covered by Regulation (EU) 2015/757 with the exception of the maritime transport activities covered by Article 2(1a) and, until 31 December 2026, Article 2(1b) of that Regulation

Carbon dioxide From 1 January 2026, methane and nitrous oxide'

(2) Annex IIb to Directive 2003/87/EC is replaced by the following:

' ANNEX IIb

PART A

DISTRIBUTION OF FUNDS FROM THE MODERNISATION FUND CORRESPONDING TO ARTICLE 10(1), THIRD SUBPARAGRAPH

Share

Bulgaria

5,84 %

Czechia

15,59 %

Estonia

2,78 %

Croatia

3,14 %

Latvia

1,44 %

Lithuania

2,57 %

Hungary

7,12 %

Poland

43,41 %

Romania

11,98 %

Slovakia

6,13 %

EN

## PART B

DISTRIBUTION OF FUNDS FROM THE MODERNISATION FUND CORRESPONDING TO ARTICLE 10(1), FOURTH SUBPARAGRAPH

|           | Share   |
|-----------|---------|
| Bulgaria  | 4,9 %   |
| Czechia   | 12,6 %  |
| Estonia   | 2,1 %   |
| Greece    | 10,1 %  |
| Croatia   | 2,3 %   |
| Latvia    | 1,0 %   |
| Lithuania | 1,9 %   |
| Hungary   | 5,8 %   |
| Poland    | 34,2 %  |
| Portugal  | 8,6 %   |
| Romania   | 9,7 %   |
| Slovakia  | 4,8 %   |
| Slovenia  | 2,0 %'; |

- (3) The following Annexes are inserted as Annexes III and IIIa to Directive 2003/87/EC:

## ' ANNEX III

## ACTIVITY COVERED BY CHAPTER IVa

| Activity                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | Greenhouse gases   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------|
| Release for consumption of fuels which are used for combustion in the buildings, road transport and additional sectors. This activity shall not include: (a) the release for consumption of fuels used in the activities listed in Annex I, except if used for combustion in the activities of transport of greenhouse gases for geological storage as set out in the table, row twenty seven, of that Annex or if used for combustion in installations excluded under Article 27a; (b) the release for consumption of fuels for which the emission factor is zero; (c) the release for consumption of hazardous or municipal waste used as fuel. The buildings and road transport sectors shall correspond to the following sources of emissions, defined in the 2006 IPCC Guidelines for National Greenhouse Gas Inventories, with the necessary modifications to those definitions as follows: | Carbon dioxide     |
| Plants (source category code 1A1a iii), insofar as they produce heat for categories under points (c) and (d) of this paragraph, either directly or through district heating networks; (b) Road Transportation (source category code 1A3b), excluding the use of agricultural vehicles on paved roads; (c) Commercial / Institutional (source category code 1A4a); (d) Residential (source category code 1A4b).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |                    |

EN

| Activity                                                                                                                                                                                                                                                                                                                                                                   | Greenhouse gases   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------|
| Additional sectors shall correspond to the following sources of emissions, defined in the 2006 IPCC Guidelines for National Greenhouse Gas Inventories: (a) Energy Industries (source category code 1A1), excluding the categories defined under the second paragraph, point (a), of this Annex; (b) Manufacturing Industries and Construction (source category code 1A2). |                    |

ANNEX IIIa

## ADJUSTMENT OF LINEAR REDUCTION FACTOR IN ACCORDANCE WITH ARTICLE 30c(2)

- 1. If  the  average  emissions  reported  under  Chapter  IVa  for  the  years  2024  to  2026  are  more  than  2  %  higher compared to the value of  the 2025 quantity defined in accordance with Article 30c(1), and if  those differences are  not  due  to  the  difference  of  less  than  5  %  between  the  emissions  reported  under  Chapter  IVa  and  the inventory data of 2025 Union greenhouse gas emissions from UNFCCC source categories for the sectors covered under Chapter IVa, the linear reduction factor shall be calculated by adjusting the linear reduction factor referred to in Article 30c(1).
- 2. The adjusted linear reduction factor in accordance with point 1 shall be determined as follows:
- LRFadj = 100%* [MRV[2024-2026] - (ESR[2024] - 6* LRF[ 2024 ]* ESR[2024] )]/ (5* MRV [2024-2026] ), where,
- LRFadj is the adjusted linear reduction factor;

MRV[2024-2026] is the average of verified emissions under Chapter IVa for the years 2024 to 2026;

ESR[2024] is  the  value  of  2024  emissions  defined  in  accordance  with  Article  30c(1)  for  the  sectors  covered  under Chapter IVa;

- LRF[2024 ] is the linear reduction factor referred to in Article 30c(1).';
- (4) Annex IV to Directive 2003/87/EC is amended as follows:
- (a) in Part A, the section 'Calculation' is amended as follows:
- (i) in  the  third  paragraph,  the  last  sentence  'The  emission  factor  for  biomass  shall  be  zero.'  is  replaced  by  the following:

'The emission factor for biomass that complies with the sustainability criteria and greenhouse gas emission-saving criteria  for  the  use  of  biomass  established  by  Directive  (EU)  2018/2001,  with  any  necessary  adjustments  for application under this Directive, as set out in the implementing acts referred to in Article 14 of this Directive, shall be zero.';

- (ii) the fifth paragraph is replaced by the following:

'Default  oxidation  factors  developed  pursuant  to  Directive  2010/75/EU  shall  be  used,  unless  the  operator  can demonstrate that activity-specific factors are more accurate.';

- (b) in Part B, section 'Monitoring of carbon dioxide emissions', fourth paragraph, the last sentence 'The emission factor for biomass shall be zero.' is replaced by the following:
- 'The emission factor for biomass that complies with the sustainability criteria and greenhouse gas emission-saving criteria  for  the  use  of  biomass  established  by  Directive  (EU)  2018/2001,  with  any  necessary  adjustments  for application under this Directive, as set out in the implementing acts referred to in Article 14 of this Directive, shall be zero.';

EN

- (c) the following part is added:

## 'PART C

## Monitoring and reporting of emissions corresponding to the activity referred to in Annex III

Monitoring of emissions

Emissions shall be monitored by calculation.

Calculation

Emissions shall be calculated using the following formula:

Fuel released for consumption × emission factor

Fuel released for consumption shall include the quantity of fuel released for consumption by the regulated entity.

Default  IPCC  emission  factors,  taken  from  the  2006  IPCC  Inventory  Guidelines  or  subsequent  updates  of  those Guidelines,  shall  be  used  unless  fuel-specific  emission  factors  identified  by  independent  accredited  laboratories using accepted analytical methods are more accurate.

A separate calculation shall be made for each regulated entity, and for each fuel.

Reporting of emissions

Each regulated entity shall include the following information in its report:

- A. Data identifying the regulated entity, including:
- -  name of the regulated entity;
- -  its address, including postcode and country;
- -  type  of  the  fuels  it  releases  for  consumption  and  its  activities  through  which  it  releases  the  fuels  for consumption, including the technology used;
- -  address, telephone, fax and email details for a contact person; and
- -  name of the owner of the regulated entity, and of any parent company.
- B. For each type of fuel released for consumption and which is used for combustion in the sectors referred to in Annex III, for which emissions are calculated:
- -  quantity of fuel released for consumption;
- -  emission factors;
- -  total emissions;
- -  end use(s) of the fuel released for consumption; and
- -  uncertainty.

Member  States  shall  take  measures  to  coordinate  reporting  requirements  with  any  existing  reporting requirements in order to minimise the reporting burden on businesses.';

- (5) In Annex V to Directive 2003/87/EC, the following part is added:

## 'PART C

## Verification of emissions corresponding to the activity referred to in Annex III

General Principles

- 1. Emissions corresponding to the activity referred to in Annex III shall be subject to verification.
- 2. The  verification  process  shall  include  consideration  of  the  report  pursuant  to  Article  14(3)  and  of  monitoring during the preceding year. It shall address the reliability, credibility and accuracy of monitoring systems and the reported data and information relating to emissions, and in particular:
- (a) the reported fuels released for consumption and related calculations;

<!-- image -->

- (b) the choice and the employment of emission factors;
- (c) the calculations leading to the determination of the overall emissions.
- 3. Reported emissions may only be validated if reliable and credible data and information allow the emissions to be determined with a high degree of certainty. A high degree of certainty requires the regulated entity to show that:
- (a) the reported data are free of inconsistencies;
- (b) the collection of the data has been carried out in accordance with the applicable scientific standards; and
- (c) the relevant records of the regulated entity are complete and consistent.
- 4. The verifier shall be given access to all sites and information in relation to the subject of the verification.
- 5. The verifier shall take into account whether  the regulated entity is registered under  the Union eco-management and audit scheme (EMAS).
- Methodology
- Strategic analysis
- 6. The verification shall be based on a strategic analysis of all the quantities of fuels released for consumption by the regulated  entity.  This  requires  the  verifier  to  have  an  overview  of  all  the  activities  through  which  the  regulated entity is releasing the fuels for consumption and their significance for emissions.
- Process analysis
- 7. The verification of the data and information submitted shall, where appropriate, be carried out on the site of the regulated entity. The verifier shall use spot-checks to determine the reliability of the reported data and information. Risk analysis
- 8. The  verifier  shall  submit  all  the  means  through  which  the  fuels  are  released  for  consumption  by  the  regulated entity to an evaluation with regard to the reliability of the data on the overall emissions of the regulated entity.
- 9. On the basis of  this analysis the verifier shall explicitly identify  any element with a high risk of error and other aspects of the monitoring and reporting procedure which are likely to contribute to errors in the determination of the overall emissions. This especially involves the calculations necessary to determine the level of the emissions from  individual  sources.  Particular  attention  shall  be  given  to  those  elements  with  a  high  risk  of  error  and  the abovementioned aspects of the monitoring procedure.
- 10. The verifier shall take into consideration any effective risk control methods applied by the regulated entity with a view to minimising the degree of uncertainty.
- Report
- 11. The verifier shall prepare a report on the validation process stating whether the report pursuant to Article 14(3) is satisfactory.  This  report  shall  specify  all  issues  relevant  to  the  work  carried  out.  A  statement  that  the  report pursuant to Article 14(3) is satisfactory may be made if, in the opinion of the verifier, the total emissions are not materially misstated.
- Minimum competency requirement for the verifier
- 12. The verifier shall  be  independent of  the regulated entity,  carry out his or  her activities  in  a sound  and  objective professional manner, and understand:
- (a) the  provisions  of  this  Directive,  as  well  as  relevant  standards  and  guidance  adopted  by  the  Commission pursuant to Article 14(1);

EN

L  130/202

- (b) the legislative, regulatory, and administrative requirements relevant to the activities being verified; and
- (c) the generation of all information related to all the means through which the fuels are released for consumption by  the  regulated  entity,  in  particular,  relating  to  the  collection,  measurement,  calculation  and  reporting  of data.'.