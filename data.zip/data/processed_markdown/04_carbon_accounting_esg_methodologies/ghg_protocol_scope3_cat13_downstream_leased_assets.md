---
document_id: ghg_scope3_ch13_downstream_leased_assets
title: "Scope 3 Guidance - Category 13: Downstream Leased Assets"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol"
year: 2013
original_file: "ghg_protocol_scope3_cat13_downstream_leased_assets.pdf"
tables_detected: 3
converted_with: "Docling v2.32 (TableFormer)"
---

13

## Category 13: Downstream Leased Assets

## Category description

T reporting company (acting as lessor) and leased to other entities in the reporting his category includes emissions from the operation of assets that are owned by the year that are not already included in scope 1 or scope 2. This category is applicable to lessors (i.e., companies that receive payments from lessees). Companies that operate leased assets (i.e., lessees) should refer to category 8 (Upstream leased assets).

Leased assets may be included in a company's scope 1 or scope 2 inventory depending on the type of lease and the consolidation approach the company uses to define its organizational boundaries. (See section 5.2 of the Scope 3 Standard for more information.) If the reporting company leases an asset for only part of the reporting year, the reporting company should account for emissions from the portion of the year that the asset was leased. See Appendix A of the Scope 3 Standard for more information on accounting for emissions from leased assets.

In some cases, companies may not find value in distinguishing between products sold to customers (accounted for in category 11) and products leased to customers (accounted for in category 13). A company may account for products leased to customers in the same way it accounts for products sold to customers (i.e., by accounting for the total expected lifetime emissions from all relevant products leased to other entities in the reporting year). Companies should report emissions from leased products in category 11 (Use of sold products), rather than category 13 (Downstream leased assets) and avoid double counting between categories.

A reporting company's scope 3 emissions from downstream leased assets include the scope 1 and scope 2 emissions of lessees (depending on the lessee's consolidation approach).

## Calculating emissions from leased assets

Downstream leased assets differ from upstream leased assets in that the leased assets are owned by the reporting company. The availability and access to information depends on the type of asset leased. For example, a company that leases vehicles may need to request fuel or mileage data from lessees in order to calculate emissions.

The calculation methods for upstream and downstream leased assets do not differ. For guidance on calculating emissions from category 13 (Downstream leased assets), refer to the guidance for category 8 (Upstream leased assets).

Companies requesting scope 1 and scope 2 data from lessees using the asset-specific method in category 8 (Upstream leased assets) may need to request additional information from the lessee in order to properly allocate emissions to the reporting company's leased assets. The lessee's scope 1 and scope 2 emissions data maybe aggregated, as with buildings without sub-metering. The reporting company may need to allocate these emissions in order to calculate emissions from this category. For guidance on collecting data and allocating emissions, refer to chapter 7 and chapter 8 of the Scope 3 Standard.

## Example [13.1] Calculating the emissions from downstream leased assets

missions associated with factory 1, it must allocate total emissions from both factories. It chooses to allocate based on Company C (lessor) leases out a factory (factory 1) to Company D. Company D (lessee) knows its aggregated corporate scope 1 and scope 2 emissions of both factory 1 and a separate unit it operates, Factory 2. For company C to determine e physical allocation (i.e., floor space). The floor space of factory 1 is 5,000 m 2  and factory 2 is 10,000 m 2 .

The data is summarized in the table below:

|           | Combined scope 1 and scope 2 emissions (kg CO 2 e)   | Floor space (m 2 )   |
|-----------|------------------------------------------------------|----------------------|
| Factory 1 | 9,000                                                | 5,000                |
| Factory 2 |                                                      | 10,000               |

Note: The activity data and emissions factors are illustrative only, and do not refer to actual data

## The emissions of company C's (lessor) downstream leased asset is calculated as follows:

∑ scope 1 and scope 2 emissions of lessee (kg CO2e)

×

- physical area of the leased asset (e.g., area, volume)

total physical area of lessor assets (e.g., area, volume)

= 9,000 × (5,000 / 15,000) = 3,000 kg CO e 2