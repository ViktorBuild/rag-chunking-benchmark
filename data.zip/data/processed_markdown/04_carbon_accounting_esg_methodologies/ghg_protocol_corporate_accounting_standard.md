---
document_id: ghg_corporate_standard
title: "A Corporate Accounting and Reporting Standard (Revised Edition)"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "GHG Protocol / WRI / WBCSD"
year: 2015
original_file: "ghg_protocol_corporate_accounting_standard.pdf"
tables_detected: 53
converted_with: "Docling v2.32 (TableFormer)"
---

## The Greenhouse Gas Protocol

<!-- image -->

A Corporate Accounting and Reporting Standard

R E V I S E D   E D I T I O N

<!-- image -->

<!-- image -->

## GHG Protocol Initiative Team

Janet Ranganathan

World Resources Institute

Laurent Corbier

World Business Council for Sustainable Development

Pankaj Bhatia

World Resources Institute

Simon Schmitz

World Business Council for Sustainable Development

Peter Gage

World Resources Institute

Kjell Oren

World Business Council for Sustainable Development

## Revision Working Group

Brian Dawson &amp; Matt Spannagle

Australian Greenhouse Office

Mike McMahon

BP

Pierre Boileau

Environment Canada

Rob Frederick

Ford Motor Company

Bruno Vanderborght

Holcim

Fraser Thomson

International Aluminum Institute

Koichi Kitamura

Kansai Electric Power Company

Chi Mun Woo &amp; Naseem Pankhida

KPMG

Reid Miner

National Council for Air and Stream Improvement

Laurent Segalen

PricewaterhouseCoopers

Jasper Koch

Shell Global Solutions International B.V.

Somnath Bhattacharjee

The Energy Research Institute

Cynthia Cummis

US Environmental Protection Agency

Clare Breidenich

UNFCCC

Rebecca Eaton

World Wildlife Fund

## Core Advisors

Michael Gillenwater

Independent Expert

Melanie Eddis

KPMG

Marie Marache

PricewaterhouseCoopers

Roberto Acosta

UNFCCC

Vincent Camobreco

US Environmental Protection Agency

Elizabeth Cook

World Resources Institute

## Table of Contents

| Introduction   | The Greenhouse Gas Protocol Initiative             |                 |                 |   2 |
|----------------|----------------------------------------------------|-----------------|-----------------|-----|
| Chapter 1      | GHG Accounting and Reporting Principles            | S T A N D A R D | G U I D A N C E |   6 |
| Chapter 2      | Business Goals and Inventory Design                | G U I D A N C E |                 |  10 |
| Chapter 3      | Setting Organizational Boundaries                  | S T A N D A R D | G U I D A N C E |  16 |
| Chapter 4      | Setting Operational Boundaries                     | S T A N D A R D | G U I D A N C E |  24 |
| Chapter 5      | Tracking Emissions Over Time                       | S T A N D A R D | G U I D A N C E |  34 |
| Chapter 6      | Identifying and Calculating GHG Emissions          | G U I D A N C E |                 |  40 |
| Chapter 7      | Managing Inventory Quality                         | G U I D A N C E |                 |  48 |
| Chapter 8      | Accounting for GHG Reductions                      | G U I D A N C E |                 |  58 |
| Chapter 9      | Reporting GHG Emissions                            | S T A N D A R D | G U I D A N C E |  62 |
| Chapter 10     | Verification of GHG Emissions                      | G U I D A N C E |                 |  68 |
| Chapter 11     | Setting GHG Targets                                | G U I D A N C E |                 |  74 |
| Appendix A     | Accounting for Indirect Emissions from Electricity |                 |                 |  86 |
| Appendix B     | Accounting for Sequestered Atmospheric Carbon      |                 |                 |  88 |
| Appendix C     | Overview of GHG Programs                           |                 |                 |  90 |
| Appendix D     | Industry Sectors and Scopes                        |                 |                 |  92 |
| Acronyms       |                                                    |                 |                 |  95 |
| Glossary       |                                                    |                 |                 |  96 |
| References     |                                                    |                 |                 | 103 |
| Contributors   |                                                    |                 |                 | 104 |

<!-- image -->

## Introduction

<!-- image -->

he  Greenhouse  Gas  Protocol  Initiative  is  a  multi-stakeholder  partnership  of businesses, non-governmental organizations (NGOs), governments, and others convened by the World Resources Institute (WRI), a U.S.-based environmental NGO,  and  the  World  Business  Council  for  Sustainable  Development  (WBCSD),  a Geneva-based  coalition  of  170  international  companies.  Launched  in  1998,  the Initiative's  mission  is  to  develop  internationally  accepted  greenhouse  gas  (GHG) accounting and reporting standards for business and to promote their broad adoption. T

The GHG Protocol Initiative comprises two separate but linked standards:

- · GHG Protocol Corporate Accounting and Reporting Standard (this document, which provides a step-by-step guide for companies to use in quantifying and reporting their GHG emissions)
- · GHG Protocol Project Quantification Standard (forthcoming; a guide for quantifying reductions from GHG mitigation projects)

The first edition of the GHG Protocol Corporate Accounting and Reporting Standard (GHG Protocol Corporate Standard), published in September 2001, enjoyed broad adoption and acceptance around the globe by businesses, NGOs, and governments. Many industry, NGO, and government GHG programs 1 used the standard as a basis for their accounting and reporting systems. Industry groups, such as the International Aluminum Institute, the International Council of Forest and Paper Associations, and the WBCSD Cement Sustainability Initiative, partnered with the GHG Protocol Initiative to develop complementary industry-specific calculation tools. Widespread adoption of the standard can be attributed to the inclusion of many stakeholders in its development and to the fact that it is robust, practical, and builds on the experience and expertise of numerous experts and practitioners.

This revised edition of the GHG Protocol Corporate Standard is the culmination of a two-year multi-stakeholder dialogue, designed to build on experience gained from using the first edition. It includes additional guidance, case studies, appendices, and a new chapter on setting a GHG target. For the most part, however, the first edition of the Corporate Standard has stood the test of time, and the changes in this revised edition will not affect the results of most GHG inventories.

This GHG Protocol Corporate Standard provides standards and guidance for companies and other types of organizations 2 preparing a GHG emissions inventory. It covers the accounting and reporting of the six greenhouse gases covered by the Kyoto Protocol - carbon dioxide (CO ), methane (CH ), nitrous oxide 2 4 (N O), hydrofluorocarbons (HFCs), perfluorocarbons (PFCs), 2 and sulphur hexafluoride (SF ). The standard and guidance were 6 designed with the following objectives in mind:

- · To help companies prepare a GHG inventory that represents a true and fair account of their emissions, through the use of standardized approaches and principles
- • To simplify and reduce the costs of compiling a GHG inventory
- · To provide business with information that can be used to build an effective strategy to manage and reduce GHG emissions
- · To provide information that facilitates participation in voluntary and mandatory GHG programs
- · To increase consistency and transparency in GHG accounting and reporting among various companies and GHG programs.

Both business and other stakeholders benefit from converging on a common standard. For business, it reduces costs if their GHG inventory is capable of meeting different internal and external information requirements. For others, it improves the consistency, transparency, and understandability of reported information, making it easier to track and compare progress over time.

## The business value of a GHG inventory

Global warming and climate change have come to the fore as a key sustainable development issue. Many governments are taking steps to reduce GHG emissions through national policies that include the introduction of emissions trading programs, voluntary programs, carbon or energy taxes, and regulations and standards on energy efficiency and emissions. As a result, companies must be able to understand and manage their GHG risks if they are to ensure long-term success in a competitive business environment, and to be prepared for future national or regional climate policies.

A well-designed and maintained corporate GHG inventory can serve several business goals, including:

- • Managing GHG risks and identifying reduction opportunities
- • Public reporting and participation in voluntary GHG programs
- • Participating in mandatory reporting programs
- • Participating in GHG markets
- • Recognition for early voluntary action.

## Who should use this standard?

This standard is written primarily from the perspective of a business developing a GHG inventory. However, it applies equally to other types of organizations with operations that give rise to GHG emissions, e.g., NGOs, government agencies, and universities. 3 It should not be used to quantify the reductions associated with GHG mitigation projects for use as offsets or credits-the forthcoming GHG Protocol Project Quantification Standard will provide standards and guidance for this purpose.

Policy makers and architects of GHG programs can also use relevant parts of this standard as a basis for their own accounting and reporting requirements.

<!-- image -->

## Relationship to other GHG programs

It is important to distinguish between the GHG Protocol Initiative and other GHG programs. The GHG Protocol Corporate Standard focuses only on the accounting and reporting of emissions. It does not require emissions information to be reported to WRI or WBCSD. In addition, while this standard is designed to develop a verifiable inventory, it does not provide a standard for how the verification process should be conducted.

The GHG Protocol Corporate Standard has been designed to be program or policy neutral. However, many existing GHG programs use it for their own accounting and reporting requirements and it is compatible with most of them, including:

- · Voluntary GHG reduction programs, e.g., the World Wildlife Fund (WWF) Climate Savers, the U.S. Environmental Protection Agency (EPA) Climate Leaders, the Climate Neutral Network, and the Business Leaders Initiative on Climate Change (BLICC)
- · GHG registries, e.g., California Climate Action Registry (CCAR), World Economic Forum Global GHG Registry
- · National and regional industry initiatives, e.g., New Zealand Business Council for Sustainable Development, Taiwan Business Council for Sustainable Development, Association des entreprises pour la réduction des gaz à effet de serre (AERES)
- · GHG trading programs, 4 e.g., UK Emissions Trading Scheme (UK ETS), Chicago Climate Exchange (CCX), and the European Union Greenhouse Gas Emissions Allowance Trading Scheme (EU ETS)
- · Sector-specific protocols developed by a number of industry associations, e.g., International Aluminum Institute, International Council of Forest and Paper Associations, International Iron and Steel Institute, the WBCSD Cement Sustainability Initiative, and the International Petroleum Industry Environmental Conservation Association (IPIECA).

Since GHG programs often have specific accounting and reporting requirements, companies should always check with any relevant programs for any additional requirements before developing their inventory.

## GHG calculation tools

To complement the standard and guidance provided here, a number of cross-sector and sector-specific calculation tools are available on the GHG Protocol Initiative website (www.ghgprotocol.org), including a guide for small office-based organizations (see chapter 6 for full list). These tools provide stepby-step guidance and electronic worksheets to help users calculate GHG emissions from specific sources or industries. The tools are consistent with those proposed by the Intergovernmental Panel on Climate Change (IPCC) for compilation of emissions at the national level (IPCC, 1996). They have been refined to be user-friendly for non-technical company staff and to increase the accuracy of emissions data at a company level. Thanks to help from many companies, organizations, and individual experts through an intensive review of the tools, they are believed to represent current 'best practice.'

## Reporting in accordance with the GHG Protocol Corporate Standard

The GHG Protocol Initiative encourages the use of the GHG Protocol Corporate Standard by all companies regardless of their experience in preparing a GHG inventory. The term 'shall' is used in the chapters containing standards to clarify what is required to prepare and report a GHG inventory in accordance with the GHG Protocol Corporate Standard. This is intended to improve the consistency with which the standard is applied and the resulting information that is publicly reported, without departing from the initial intent of the first edition. It also has the advantage of providing a verifiable standard for companies interested in taking this additional step.

## Overview of main changes to the first edition

This revised edition contains additional guidance, case studies, and annexes. A new guidance chapter on setting GHG targets has been added in response to many requests from companies that, having developed an inventory, wanted to take the next step of setting a target. Appendices have been added on accounting for indirect emissions from electricity and on accounting for sequestered atmospheric carbon.

## Changes to specific chapters include:

• CHAPTER 1:

Minor rewording of principles.

• CHAPTER 2:

Goal-related information on operational bound- aries has been updated and consolidated.

• CHAPTER 3:

Although still encouraged to account for emissions using both the equity and control approaches, companies may now report using one approach. This change reflects the fact that not all companies need both types of infor- mation to achieve their business goals. New guidance has been provided on establishing control. The minimum equity threshold for reporting purposes has been removed to enable emissions to be reported when significant.

• CHAPTER 4: for resale-these are now included in scope 3. electricity transmission and distribution losses.

The definition of scope 2 has been revised to exclude emissions from electricity purchased This prevents two or more companies from double counting the same emissions in the same scope. New guidance has been added on accounting for GHG emissions associated with Additional guidance provided on Scope 3 categories and leasing.

• CHAPTER 5:

The recommendation of pro-rata adjustments was deleted to avoid the need for two adjust- ments. More guidance has been added on adjusting base year emissions for changes in calculation methodologies.

• CHAPTER 6:

The guidance on choosing emission factors has been improved.

• CHAPTER 7:

The guidance on establishing an inventory quality management system and on the applica- tions and limitations of uncertainty assessment has been expanded.

• CHAPTER 8: Guidance has been added on accounting for and reporting project reductions and offsets in order to clarify the relationship between the GHG Protocol Corporate and Project Standards .

• CHAPTER 9: The required and optional reporting categories

have been clarified.

• CHAPTER 10:

Guidance on the concepts of materiality and material discrepancy has been expanded.

• CHAPTER 11:

New chapter added on steps in setting a target and tracking and reporting progress.

## Frequently asked questions…

Below is a list of frequently asked questions, with directions to the relevant chapters.

• What should I consider when setting out to account for and report emissions?

CHAPTER 2

• How do I deal with complex company structures and shared ownership?

CHAPTER 3

• What is the difference between direct and indirect emissions and what is their relevance?

CHAPTER 4

• Which indirect emissions should I report?

CHAPTER 4

• How do I account for and report outsourced and leased operations?

CHAPTER 4

• What is a base year and why do I need one?

CHAPTER 5

• My emissions change with acquisitions and divestitures. How do I account for these?

CHAPTER 5

• How do I identify my company's emission sources?

CHAPTER 6

• What kinds of tools are there to help me calculate  emissions?

CHAPTER 6

• What data collection activities and data management issues do my facilities have to deal with?

CHAPTER 6

• What determines the quality and credibility of my emissions information?

CHAPTER 7

• How should I account for and report GHG offsets that I sell or purchase?

CHAPTER 8

• What information should be included in a GHG public emissions report?

CHAPTER 9

• What data must be available to obtain external verification of the inventory data?

CHAPTER 10

• What is involved in setting an emissions target and how do I report performance in relation to my target?

CHAPTER 11

## NOTES

- 1 GHG program is a generic term used to refer to any voluntary or mandatory international, national, sub-national government or non-governmental authority that registers, certifies, or regulates GHG emissions or removals.
- 2 Throughout the rest of this document, the term 'company' or 'business' is used as shorthand for companies, businesses and other types of organizations.
- 3 For example, WRI uses the GHG Protocol Corporate Standard to publicly report its own emissions on an annual basis and to participate in the Chicago Climate Exchange.
- 4 Trading programs that operate at the level of facilities primarily use the GHG Protocol Initiative calculation tools.

## GHG Accounting and Reporting Principles

<!-- image -->

s  with  financial  accounting  and  reporting,  generally  accepted  GHG accounting  principles  are  intended  to  underpin  and  guide  GHG accounting and reporting to ensure that the reported information represents a faithful, true, and fair account of a company's GHG emissions. A

S

G

T

U

A

I

N

D

D

A

A

N

R

C

D

E

RELEVANCE

COMPLETENESS

CONSISTENCY

T R A N S P A R E N C Y

ACCURACY

GHG accounting and reporting practices are evolving and are new to many businesses; however, the principles listed below are derived in part from generally accepted financial accounting and reporting principles. They also reflect the outcome of a collaborative process involving stakeholders from a wide range of technical, environmental, and accounting disciplines.

GHG accounting and reporting shall be based on the following principles:

Ensure the GHG inventory appropriately reflects the GHG emissions of the company and serves the decision-making needs of users - both internal and external to the company.

Account for and report on all GHG emission sources and activities within the chosen inventory boundary. Disclose and justify any specific exclusions.

Use consistent methodologies to allow for meaningful comparisons of emissions over time. Transparently document any changes to the data, inventory boundary, methods, or any other relevant factors in the time series.

Address all relevant issues in a factual and coherent manner, based on a clear audit trail. Disclose any relevant assumptions and make appropriate references to the accounting and calculation methodologies and data sources used.

Ensure that the quantification of GHG emissions is systematically neither over nor under actual emissions, as far as can be judged, and that uncertainties are reduced as far as practicable. Achieve sufficient accuracy to enable users to make decisions with reasonable assurance as to the integrity of the reported information.

<!-- image -->

## GHG Accounting and Reporting Principles

hese principles are intended to underpin all aspects of GHG accounting and reporting. Their application will ensure that the GHG inventory constitutes a true and fair representation of the company's GHG emissions. Their primary function is to guide the implementation of the GHG Protocol Corporate Standard , particularly when the application of the standards to specific issues or situations is ambiguous. T

bias in estimates (i.e., an underestimate). Although it appears useful in theory, the practical implementation of such a threshold is not compatible with the completeness principle of the GHG Protocol Corporate Standard . In order to utilize a materiality specification, the emissions from a particular source or activity would have to be quantified to ensure they were under the threshold. However, once emissions are quantified, most of the benefit of having a threshold is lost.

## Relevance

For an organization's GHG report to be relevant means that it contains the information that users-both internal and external to the company-need for their decision making. An important aspect of relevance is the selection of an appropriate inventory boundary that reflects the substance and economic reality of the company's business relationships, not merely its legal form. The choice of the inventory boundary is dependent on the characteristics of the company, the intended purpose of information, and the needs of the users. When choosing the inventory boundary, a number of factors should be considered, such as:

- GLYPH&lt;127&gt; Organizational structures: control (operational and financial), ownership, legal agreements, joint ventures, etc.
- GLYPH&lt;127&gt; Operational boundaries: on-site and off-site activities, processes, services, and impacts
- GLYPH&lt;127&gt; Business context: nature of activities, geographic locations, industry sector(s), purposes of information, and users of information

More information on defining an appropriate inventory boundary is provided in chapters 2, 3, and 4.

## Completeness

All relevant emissions sources within the chosen inventory boundary need to be accounted for so that a comprehensive and meaningful inventory is compiled. In practice, a lack of data or the cost of gathering data may be a limiting factor. Sometimes it is tempting to define a minimum emissions accounting threshold (often referred to as a materiality threshold) stating that a source not exceeding a certain size can be omitted from the inventory. Technically, such a threshold is simply a predefined and accepted negative

A threshold is often used to determine whether an error or omission is a material discrepancy or not. This is not the same as a de minimis for defining a complete inventory. Instead companies need to make a good faith effort to provide a complete, accurate, and consistent accounting of their GHG emissions. For cases where emissions have not been estimated, or estimated at an insufficient level of quality, it is important that this is transparently documented and justified. Verifiers can determine the potential impact and relevance of the exclusion, or lack of quality, on the overall inventory report.

More information on completeness is provided in chapters 7 and 10.

## Consistency

Users of GHG information will want to track and compare GHG emissions information over time in order to identify trends and to assess the performance of the reporting company. The consistent application of accounting approaches, inventory boundary, and calculation methodologies is essential to producing comparable GHG emissions data over time. The GHG information for all operations within an organization's inventory boundary needs to be compiled in a manner that ensures that the aggregate information is internally consistent and comparable over time. If there are changes in the inventory boundary, methods, data or any other factors affecting emission estimates, they need to be transparently documented and justified.

More information on consistency is provided in chapters 5 and 9.

## Volkswagen:

## Maintaining completeness over time

Volkswagen  is  a  global  auto  manufacturer  and  the  largest automaker  in  Europe.  While  working  on  its  GHG  inventory, Volkswagen realized that the structure of its emission sources had undergone  considerable  changes  over  the  last  seven  years. Emissions from production processes, which were considered to be irrelevant  at  a  corporate  level  in  1996,  today  constitute  almost 20  percent  of  aggregated  GHG  emissions  at  the  relevant  plant sites.  Examples  of  growing  emissions  sources  are  new  sites  for engine  testing  or  the  investment  into  magnesium  die-casting equipment at certain production sites. This example shows that emissions sources have to be regularly re-assessed to maintain a complete inventory over time.

## Transparency

Transparency relates to the degree to which information on the processes, procedures, assumptions, and limitations of the GHG inventory are disclosed in a clear, factual, neutral, and understandable manner based on clear documentation and archives (i.e., an audit trail). Information needs to be recorded, compiled, and analyzed in a way that enables internal reviewers and external verifiers to attest to its credibility. Specific exclusions or inclusions need to be clearly identified and justified, assumptions disclosed, and appropriate references provided for the methodologies applied and the data sources used. The information should be sufficient to enable a third party to derive the same results if provided with the same source data. A 'transparent' report will provide a clear understanding of the issues in the context of the reporting company and a meaningful assessment of performance. An independent external verification is a good way of ensuring transparency and determining that an appropriate audit trail has been established and documentation provided.

More information on transparency is provided in chapters 9 and 10.

## Accuracy

Data should be sufficiently precise to enable intended users to make decisions with reasonable assurance that the reported information is credible. GHG measurements, estimates, or calculations should be systemically neither over nor under the actual emissions value, as far as can be judged, and that uncertainties are reduced as far as practicable. The quantification process should be conducted in a manner that minimizes uncertainty. Reporting on measures taken to ensure accuracy in the accounting of emissions can help promote credibility while enhancing transparency.

More information on accuracy is provided in chapter 7.

## The Body Shop: Solving the trade-off between accuracy and completeness

As an international, values-driven retailer of skin, hair, body care, and make-up products, the Body Shop operates nearly 2,000 locations,  serving  51  countries  in  29  languages.  Achieving  both accuracy and completeness in the GHG inventory process for such a large, disaggregated organization, is a challenge. Unavailable data  and  costly  measurement  processes  present  significant obstacles to improving emission data accuracy. For example, it is difficult  to  disaggregate  energy  consumption  information  for shops located within shopping centers. Estimates for these shops are  often  inaccurate,  but  excluding  sources  due  to  inaccuracy creates an incomplete inventory.

The Body Shop, with help from the Business Leaders Initiative on Climate Change (BLICC) program, approached this problem with a  two-tiered  solution.  First,  stores  were  encouraged  to  actively pursue direct consumption data through disaggregated data or direct monitoring. Second, if unable to obtain direct consumption data,  stores  were  given  standardized  guidelines  for  estimating emissions based on factors such as square footage, equipment type, and usage hours. This system replaced the prior fragmentary approach,  provided  greater  accuracy,  and  provided  a  more complete account of emissions by including facilities that previously were unable to calculate emissions. If such limitations in the measurement processes are made transparent, users of the information will understand the basis of the data and the trade off that has taken place.

2

## Business Goals and Inventory Design

<!-- image -->

mproving your understanding of your company's GHG emissions by compiling a GHG inventory makes good business sense. Companies frequently cite the following five business goals as reasons for compiling a GHG inventory: I

- GLYPH&lt;127&gt; Managing GHG risks and identifying reduction opportunities
- GLYPH&lt;127&gt; Public reporting and participation in voluntary GHG programs
- GLYPH&lt;127&gt; Participating in mandatory reporting programs
- GLYPH&lt;127&gt; Participating in GHG markets
- GLYPH&lt;127&gt; Recognition for early voluntary action

Companies generally want their GHG inventory to be capable of serving multiple goals. It therefore makes sense to design the process from the outset to provide information for a variety of different users and uses-both current and future. The GHG Protocol Corporate Standard has been designed as a comprehensive GHG accounting and reporting framework to provide the information building blocks capable of serving most business goals (see Box 1). Thus the inventory data collected according to the GHG Protocol Corporate Standard can be aggregated and disaggregated for various organizational and operational boundaries and for different business geographic scales (state, country, Annex 1 countries, non-Annex 1 countries, facility, business unit, company, etc.).

## BOX 1. Business goals served by GHG inventories

## Managing GHG risks and identifying reduction opportunities

- GLYPH&lt;127&gt; Identifying risks associated with GHG constraints in the future
- GLYPH&lt;127&gt; Identifying cost effective reduction opportunities
- GLYPH&lt;127&gt; Setting GHG targets, measuring and reporting progress

## Public reporting and participation in voluntary GHG programs

- GLYPH&lt;127&gt; Voluntary stakeholder reporting of GHG emissions and progress towards GHG targets
- GLYPH&lt;127&gt; Reporting to government and NGO reporting programs, including GHG registries
- GLYPH&lt;127&gt; Eco-labelling and GHG certification

## Participating in mandatory reporting programs

- GLYPH&lt;127&gt; Participating in government reporting programs at the national, regional, or local level

## Participating in GHG markets

- GLYPH&lt;127&gt; Supporting internal GHG trading programs
- GLYPH&lt;127&gt; Participating in external cap and trade allowance trading programs
- GLYPH&lt;127&gt; Calculating carbon/GHG taxes

## Recognition for early voluntary action

- GLYPH&lt;127&gt; Providing information to support 'baseline protection' and/or credit for early action

Appendix C provides an overview of various GHG programs-many of which are based on the GHG Protocol Corporate Standard . The guidance sections of chapters 3 and 4 provide additional information on how to design an inventory for different goals and uses.

## Managing GHG risks and identifying reduction opportunities

Compiling a comprehensive GHG inventory improves a company's understanding of its emissions profile and any potential GHG liability or 'exposure.' A company's GHG exposure is increasingly becoming a management issue in light of heightened scrutiny by the insurance industry, shareholders, and the emergence of environmental regulations/policies designed to reduce GHG emissions.

In the context of future GHG regulations, significant GHG emissions in a company's value chain may result in increased costs (upstream) or reduced sales (downstream), even if the company itself is not directly subject to regulations. Thus investors may view significant indirect emissions upstream or downstream of a company's operations as potential liabilities that need to be managed and reduced. A limited focus on direct emissions from a company's own operations may miss major GHG risks and opportunities, while leading to a misinterpretation of the company's actual GHG exposure.

On a more positive note, what gets measured gets managed. Accounting for emissions can help identify the most effective reduction opportunities. This can drive increased materials and energy efficiency as well as the development of new products and services that reduce the GHG impacts of customers or suppliers. This in turn can reduce production costs and help differentiate the company in an increasingly environmentally conscious marketplace. Conducting a rigorous GHG inventory is also a prerequisite for setting an internal or public GHG target and for subsequently measuring and reporting progress.

## IBM: The role of renewable energy in reducing GHG emissions

Indirect  emissions  associated  with  the  consumption  of  purchased electricity are a required element of any company's accounting and reporting  under  the GHG  Protocol  Corporate  Standard . Because purchased electricity is a major source of GHG emissions for companies,  it  presents  a  significant  reduction  opportunity.  IBM,  a  major information technology company and a member of the WRI's Green Power Market Development Group, has systematically accounted for these indirect emissions and thus identified the significant potential to reduce them. The company has implemented a variety of strategies that would reduce either their demand for purchased energy or the GHG intensity  of  that  purchased  energy.  One  strategy  has  been  to pursue the renewable energy market to reduce the GHG intensity of its purchased electricity.

IBM  succeeded  in  reducing  its  GHG  emissions  at  its  facility  in Austin, Texas, even as energy use stayed relatively constant, through a contract for renewable electricity with the local utility company, Austin Energy. Starting in 2001, this five-year contract is for 5.25 million  kWhs  of  wind-power  per  year.  This  zero  emission  power lowered the facility's inventory by more than 4,100 tonnes of CO 2 compared  to  the  previous  year  and  represents  nearly  5%  of  the facility's total electricity consumption. Company-wide, IBM's 2002 total  renewable energy procurement was 66.2 million kWh, which represented  1.3%  of  its  electricity  consumption  worldwide  and 31,550 tonnes of CO compared to the previous year. Worldwide, IBM 2 purchased a variety of sources of renewable energy including wind, biomass and solar.

By accounting for these indirect emissions and looking for associated  reduction  opportunities,  IBM  has  successfully  reduced  an important source of its overall GHG emissions.

## Public reporting and participation in voluntary GHG programs

As concerns over climate change grow, NGOs, investors, and other stakeholders are increasingly calling for greater corporate disclosure of GHG information. They are interested in the actions companies are taking and in how the companies are positioned relative to their competitors in the face of emerging regulations. In response, a growing number of companies are preparing stakeholder reports containing information on GHG emissions. These may be stand-alone reports on GHG emissions or broader environmental or sustainability reports. For example, companies preparing sustainability reports using the Global Reporting Initiative guidelines should include information on GHG emissions in accordance with the GHG Protocol Corporate Standard (GRI, 2002). Public reporting can also strengthen relationships with other stakeholders. For instance, companies can improve their standing with customers and with the public by being recognized for participating in voluntary GHG programs.

Some countries and states have established GHG registries where companies can report GHG emissions in a public database. Registries may be administered by governments (e.g., U.S. Department of Energy 1605b Voluntary Reporting Program), NGOs (e.g., California Climate Action Registry), or industry groups (e.g., World Economic Forum Global GHG Registry). Many GHG programs also provide help to companies setting voluntary GHG targets.

Most voluntary GHG programs permit or require the reporting of direct emissions from operations (including all six GHGs), as well as indirect GHG emissions from purchased electricity. A GHG inventory prepared in accordance with the GHG Protocol Corporate Standard will usually be compatible with most requirements (Appendix C provides an overview of the reporting requirements of some GHG programs). However, since the accounting guidelines of many voluntary programs are periodically updated, companies planning to participate are advised to contact the program administrator to check the current requirements.

<!-- image -->

## Participating in mandatory reporting programs

## Participating in GHG markets

Some governments require GHG emitters to report their emissions annually. These typically focus on direct emissions from operations at operated or controlled facilities in specific geographic jurisdictions. In Europe, facilities falling under the requirements of the Integrated Pollution Prevention and Control (IPPC) Directive must report emissions exceeding a specified threshold for each of the six GHGs. The reported emissions are included in a European Pollutant Emissions Register (EPER), a publicly accessible internet-based database that permits comparisons of emissions from individual facilities or industrial sectors in different countries (EC-DGE, 2000). In Ontario, Ontario Regulation 127 requires the reporting of GHG emissions (Ontario MOE, 2001).

Market-based approaches to reducing GHG emissions are emerging in some parts of the world. In most places, they take the form of emissions trading programs, although there are a number of other approaches adopted by countries, such as the taxation approach used in Norway. Trading programs can be implemented on a mandatory (e.g., the forthcoming EU ETS) or voluntary basis (e.g., CCX).

Although trading programs, which determine compliance by comparing emissions with an emissions reduction target or cap, typically require accounting only for direct emissions, there are exceptions. The UK ETS, for example, requires direct entry participants to account for GHG emissions from the generation of purchased electricity (DEFRA, 2003). The CCX allows its members the option of counting indirect emissions associated with electricity purchases as a supplemental reduction commitment. Other types of indirect emissions can be more difficult to verify and may present challenges in terms of avoiding double counting. To facilitate independent verification, emissions trading

may require participating companies to establish an audit trail for GHG information (see chapter 10).

GHG trading programs are likely to impose additional layers of accounting specificity relating to which approach is used for setting organizational boundaries; which GHGs and sources are addressed; how base years are established; the type of calculation methodology used; the choice of emission factors; and the monitoring and verification approaches employed. The broad participation and best practices incorporated into the GHG Protocol Corporate Standard are likely to inform the accounting requirements of emerging programs, and have indeed done so in the past.

## Recognition for early voluntary action

A credible inventory may help ensure that a corporation's early, voluntary emissions reductions are recognized in future regulatory programs. To illustrate, suppose that in 2000 a company started reducing its GHG emissions by shifting its on-site powerhouse boiler fuel from coal to landfill gas. If a mandatory GHG reduction program is later established in 2005 and it sets 2003 as the base against which reductions are to be measured, the program might not allow the emissions reductions achieved by the green power project prior to 2003 to count toward its target.

However, if a company's voluntary emissions reductions have been accounted for and registered, they are more likely to be recognized and taken into account when regulations requiring reductions go into effect. For instance, the state of California has stated that it will use its best efforts to ensure that organizations that register certified emission results with the California Climate Action Registry receive appropriate consideration under any future international, federal, or state regulatory program relating to GHG emissions.

## Tata Steel: Development of institutional capacity in GHG accounting and reporting

For Tata Steel, Asia's first and India's largest integrated private sector steel company, reducing its GHG emissions through energy efficiency  is  a  key  element  of  its  primary  business  goal:  the acceptability of its product in international markets. Each year, in pursuit of this goal, the company launches several energy efficiency projects and introduces less-GHG-intensive processes. The company  is  also  actively  pursuing  GHG  trading  markets  as  a means of further improving its GHG performance. To succeed in these efforts and be eligible for emerging trading schemes, Tata Steel  must  have  an  accurate  GHG  inventory  that  includes  all processes  and  activities,  allows  for  meaningful  benchmarking, measures improvements, and promotes credible reporting.

Tata Steel has developed the capacity to measure its progress in reducing GHG emissions. Tata Steel's managers have access to on-line information on energy usage, material usage, waste and byproduct  generation,  and  other  material  streams.  Using  this data and the GHG Protocol calculation tools, Tata Steel generates two  key  long-term,  strategic  performance  indicators:  specific energy consumption (Giga calorie / tonne of crude steel) and GHG intensity  (tonne  of  CO equivalent /  tonne  of  crude  steel).  These 2 indicators are key sustainability metrics in the steel sector worldwide, and help ensure market acceptability and competitiveness. Since the company adopted the GHG Protocol Corporate Standard , tracking performance has become more structured and streamlined. This system allows Tata Steel quick and easy access to its GHG  inventory  and  helps  the  company  maximize  process  and material flow efficiencies.

## Ford Motor Company: Experiences using the GHG Protocol Corporate Standard

When Ford Motor Company, a global automaker, embarked on an effort  to  understand and reduce its GHG impacts, it wanted to track  emissions  with  enough  accuracy  and  detail  to  manage them effectively. An internal cross-functional GHG inventory team was formed to accomplish this goal. Although the company was already  reporting  basic  energy  and  carbon  dioxide  data  at  the corporate  level,  a  more  detailed  understanding  of  these  emissions  was  essential  to  set  and  measure  progress  against performance  targets  and  evaluate  potential  participation  in external trading schemes.

For several weeks, the team worked on creating a more comprehensive inventory for stationary combustion sources, and quickly found a pattern emerging. All too often team members left meetings with as many questions as answers, and the same questions kept  coming  up  from  one  week  to  the  next.  How  should  they draw  boundaries?  How  do  they  account  for  acquisitions  and divestitures?  What  emission  factors  should  be  used?  And perhaps  most  importantly,  how  could  their  methodology  be deemed credible with stakeholders? Although the team had no shortage of opinions, there also seemed to be no clearly right or wrong answers.

The GHG  Protocol  Corporate  Standard helped  answer  many  of these  questions  and  the  Ford  Motor  Company  now  has  a  more robust GHG inventory that can be continually improved to fulfill its rapidly emerging GHG management needs. Since adopting the GHG  Protocol  Corporate  Standard , Ford  has  expanded  the coverage of its public reporting to all of its brands globally; it now includes direct emissions from sources it owns or controls and indirect  emissions  resulting  from  the  generation  of  purchased electricity, heat, or steam. In addition, Ford is a founding member of the Chicago Climate Exchange, which uses some of the GHG Protocol calculation tools for emissions reporting purposes.

<!-- image -->

## Setting Organizational Boundaries

<!-- image -->

usiness  operations  vary  in  their  legal  and  organizational  structures; they include wholly owned operations, incorporated and non-incorporated joint ventures, subsidiaries, and others. For the purposes of financial accounting, they are treated according to established rules that depend on the structure of the organization and the relationships among the parties involved. In setting organizational  boundaries,  a  company  selects  an  approach  for  consolidating  GHG emissions and then consistently applies the selected approach to define those businesses  and  operations  that  constitute  the  company  for  the  purpose  of accounting and reporting GHG emissions. B

<!-- image -->

For corporate reporting, two distinct approaches can be used to consolidate GHG emissions: the equity share and the control approaches. Companies shall account for and report their consolidated GHG data according to either the equity share or control approach as presented below. If the reporting company wholly owns all its operations, its organizational boundary will be the same whichever approach is used. 1 For companies with joint operations, the organizational boundary and the resulting emissions may differ depending on the approach used. In both wholly owned and joint operations, the choice of approach may change how emissions are categorized when operational boundaries are set (see chapter 4).

## Equity share approach

Under the equity share approach, a company accounts for GHG emissions from operations according to its share of equity in the operation. The equity share reflects economic interest, which is the extent of rights a company has to the risks and rewards flowing from an operation. Typically, the share of economic risks and rewards in an operation is aligned with the company's percentage ownership of that operation, and equity share will normally be the same as the ownership percentage. Where this is not the case, the economic substance of the relationship the company has with the operation always overrides the legal ownership form to ensure that equity share reflects the percentage of economic interest. The principle of economic substance taking precedent over legal form is consistent with international financial reporting standards. The staff preparing the inventory may therefore need to consult with the company's accounting or legal staff to ensure that the appropriate equity share percentage is applied for each joint operation (see Table 1 for definitions of financial accounting categories).

<!-- image -->

## Control approach

Under the control approach, a company accounts for 100 percent of the GHG emissions from operations over which it has control. It does not account for GHG emissions from operations in which it owns an interest but has no control. Control can be defined in either financial or operational terms. When using the control approach to consolidate GHG emissions, companies shall choose between either the operational control or financial control criteria.

In most cases, whether an operation is controlled by the company or not does not vary based on whether the financial control or operational control criterion is used. A notable exception is the oil and gas industry, which often has complex ownership / operatorship structures. Thus, the choice of control criterion in the oil and gas industry can have substantial consequences for a company's GHG inventory. In making this choice, companies should take into account how GHG emissions accounting and reporting can best be geared to the requirements of emissions reporting and trading schemes, how it can be aligned with financial and environmental reporting, and which criterion best reflects the company's actual power of control.

- GLYPH&lt;127&gt; Financial Control. The company has financial control over the operation if the former has the ability to direct the financial and operating policies of the latter with a view to gaining economic benefits from its activities. 2 For example, financial control usually exists if the company has the right to the majority of benefits of the operation, however these rights are conveyed. Similarly, a company is considered to financially control an operation if it retains the majority risks and rewards of ownership of the operation's assets.

Under this criterion, the economic substance of the relationship between the company and the operation takes precedence over the legal ownership status, so that the company may have financial control over the operation even if it has less than a 50 percent interest in that operation. In assessing the economic substance of the relationship, the impact of potential voting rights, including both those held by the company and those held by other parties, is also taken into account. This criterion is consistent with international financial accounting standards; therefore, a company has financial control over an operation for GHG accounting purposes if the operation is considered as a group company or subsidiary for the purpose of financial

- consolidation, i.e., if the operation is fully consolidated in financial accounts. If this criterion is chosen to determine control, emissions from joint ventures where partners have joint financial control are accounted for based on the equity share approach (see Table 1 for definitions of financial accounting categories).
- GLYPH&lt;127&gt; Operational Control. A company has operational control over an operation if the former or one of its subsidiaries (see Table 1 for definitions of financial accounting categories) has the full authority to introduce and implement its operating policies at the operation. This criterion is consistent with the current accounting and reporting practice of many companies that report on emissions from facilities, which they operate (i.e., for which they hold the operating license). It is expected that except in very rare circumstances, if the company or one of its subsidiaries is the operator of a facility, it will have the full authority to introduce and implement its operating policies and thus has operational control.

Under the operational control approach, a company accounts for 100% of emissions from operations over which it or one of its subsidiaries has operational control.

It should be emphasized that having operational control does not mean that a company necessarily has authority to make all decisions concerning an operation. For example, big capital investments will likely require the approval of all the partners that have joint financial control. Operational control does mean that a company has the authority to introduce and implement its operating policies.

More information on the relevance and application of the operational control criterion is provided in petroleum industry guidelines for reporting GHG emissions (IPIECA, 2003).

Sometimes a company can have joint financial control over an operation, but not operational control. In such cases, the company would need to look at the contractual arrangements to determine whether any one of the partners has the authority to introduce and implement its operating policies at the operation and thus has the responsibility to report emissions under operational control. If the operation itself will introduce and implement its own operating policies, the partners with joint financial control over the operation will not report any emissions under operational control.

Table 2 in the guidance section of this chapter illustrates the selection of a consolidation approach at the corporate level and the identification of which joint operations will be in the organizational boundary depending on the choice of the consolidation approach.

## Consolidation at multiple levels

The consolidation of GHG emissions data will only result in consistent data if all levels of the organization follow the same consolidation policy. In the first step, the management of the parent company has to decide on a consolidation approach (i.e., either the equity share or the financial or operational control approach). Once a corporate consolidation policy has been selected, it shall be applied to all levels of the organization.

## State-ownership

The rules provided in this chapter shall also be applied to account for GHG emissions from industry joint operations that involve state ownership or a mix of private/   state ownership.

## BP: Reporting on the basis of equity share

BP  reports  GHG  emissions  on  an  equity  share  basis,  including those operations where BP has an interest, but where BP is not the operator. In determining the extent of the equity share reporting boundary  BP  seeks  to  achieve  close  alignment  with  financial accounting procedures. BP's equity share boundary includes all operations undertaken by BP and its subsidiaries, joint ventures and associated undertakings as determined by their treatment in the  financial  accounts.  Fixed  asset  investments,  i.e.,  where  BP has limited influence, are not included.

GHG emissions from facilities in which BP has an equity share are estimated according to the requirements of the BP Group Reporting Guidelines for Environmental Performance (BP 2000). In  those  facilities  where  BP  has  an  equity  share  but  is  not  the operator, GHG emissions data may be obtained directly from the operating company using a methodology consistent with the BP Guidelines, or is calculated by BP using activity data provided by the operator.

BP  reports  its  equity  share  GHG  emissions  every  year.  Since 2000, independent external auditors have expressed the opinion that the reported total has been found to be free from material misstatement when audited against the BP Guidelines.

## TABLE 1. Financial accounting categories

| A C C O U N T I N G C AT E G O RY                                                                       | F I N A N C I A L A C C O U N T I N G D E F I N I T I O N                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | ACCOUNTING FOR GHG EMISSIONS ACCORDING TO GHG PROTOCOL CORPORATE STANDARD   | ACCOUNTING FOR GHG EMISSIONS ACCORDING TO GHG PROTOCOL CORPORATE STANDARD   |
|---------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------|-----------------------------------------------------------------------------|
|                                                                                                         |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | BASED ON EQUITY SHARE                                                       | BASED ON FINANCIAL CONTROL                                                  |
| Group companies / subsidiaries                                                                          | The parent company has the ability to direct the financial and operating policies of the company with a view to gaining economic benefits from its activities. Normally, this category also includes incorporated and non-incorporated joint ventures and partnerships over which the parent company has financial control. Group companies/subsidiaries are fully consolidated, which implies that 100 percent of the subsidiary's income, expenses, assets, and liabilities are taken into the parent company's profit and loss account and balance sheet, respec- tively. Where the parent's interest does not equal 100 percent, the consolidated profit and loss account and balance sheet shows a deduction for the profits and net assets belonging to minority owners. | Equity share of GHG emissions                                               | 100% of GHG emissions                                                       |
| Associated / affiliated companies                                                                       | The parent company has significant influence over the operating and financial policies of the company, but does not have finan- cial control. Normally, this category also includes incorporated and non-incorporated joint ventures and partnerships over which the parent company has significant influence, but not financial control. Financial accounting applies the equity share method to associated/affiliated companies, which recognizes the parent company's share of the associate's profits and net assets.                                                                                                                                                                                                                                                      | Equity share of GHG emissions                                               | 0% of GHG emissions                                                         |
| Non-incorporated joint ventures / partnerships / operations where partners have joint financial control | Joint ventures/partnerships/operations are proportionally consolidated, i.e., each partner accounts for their propor- tionate interest of the joint venture's income, expenses, assets, and liabilities.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Equity share of GHG emissions                                               | Equity share of GHG emissions                                               |
| Fixed asset investments                                                                                 | The parent company has neither significant influence nor financial control. This category also includes incorporated and non- incorporated joint ventures and partnerships over which the parent company has neither significant influence nor financial control. Financial accounting applies the cost/dividend method to fixed asset investments. This implies that only dividends received are recognized as income and the investment is carried at cost.                                                                                                                                                                                                                                                                                                                  | 0%                                                                          | 0%                                                                          |
| Franchises                                                                                              | Franchises are separate legal entities. In most cases, the fran- chiser will not have equity rights or control over the franchise. Therefore, franchises should not be included in consolidation of GHG emissions data. However, if the franchiser does have equity rights or operational/financial control, then the same rules for consolidation under the equity or control approaches apply.                                                                                                                                                                                                                                                                                                                                                                               | Equity share of GHG emissions                                               | 100% of GHG emissions                                                       |

NOTE: Table 1 is based on a comparison of UK, US, Netherlands and International Financial Reporting Standards (KPMG, 2000).

hen planning the consolidation of GHG data, it is important to distinguish between GHG accounting and GHG reporting. GHG accounting concerns the recognition and consolidation of GHG emissions from operations in which a parent company holds an interest (either control or equity) and linking the data to specific operations, sites, geographic locations, business processes, and owners. GHG reporting, on the other hand, concerns the presentation of GHG data in formats tailored to the needs of various reporting uses and users. W

Most companies have several goals for GHG reporting, e.g., official government reporting requirements, emissions trading programs, or public reporting (see chapter 2). In developing a GHG accounting system, a fundamental consideration is to ensure that the system is capable of meeting a range of reporting requirements. Ensuring that data are collected and recorded at a sufficiently disaggregated level, and capable of being consolidated in various forms, will provide companies with maximum flexibility to meet a range of reporting requirements.

## Double counting

When two or more companies hold interests in the same joint operation and use different consolidation approaches (e.g., Company A follows the equity share approach while Company B uses the financial control approach), emissions from that joint operation could be double counted. This may not matter for voluntary corporate public reporting as long as there is adequate disclosure from the company on its consolidation approach. However, double counting of emissions needs to be avoided in trading schemes and certain mandatory government reporting programs.

## Reporting goals and level of consolidation

Reporting requirements for GHG data exist at various levels, from a specific local facility level to a more aggregated corporate level. Examples of drivers for various levels of reporting include:

- GLYPH&lt;127&gt; Official government reporting programs or certain emissions trading programs may require GHG data to be reported at a facility level. In these cases, consolidation of GHG data at a corporate level is not relevant
- GLYPH&lt;127&gt; Government reporting and trading programs may require that data be consolidated within certain geographic and operational boundaries (e.g., the U.K. Emissions Trading Scheme)
- GLYPH&lt;127&gt; To demonstrate the company's account to wider stakeholders, companies may engage in voluntary public reporting, consolidating GHG data at a corporate level in order to show the GHG emissions of their entire business activities.

## Contracts that cover GHG emissions

To clarify ownership (rights) and responsibility (obligations) issues, companies involved in joint operations may draw up contracts that specify how the ownership of emissions or the responsibility for managing emissions and associated risk is distributed between the parties. Where such arrangements exist, companies may optionally provide a description of the contractual arrangement and include information on allocation of CO 2 related risks and obligations (see Chapter 9).

## Using the equity share or control approach

Different inventory reporting goals may require different data sets. Thus companies may need to account for their GHG emissions using both the equity share and the control approaches. The GHG Protocol Corporate Standard makes no recommendation as to whether voluntary public GHG emissions reporting should be based on the equity share or any of the two control approaches, but encourages companies to account for their emissions applying the equity share and a control approach separately. Companies need to decide on the approach best suited to their business activities and GHG accounting and reporting requirements. Examples of how these may drive the choice of approach include the following:

- GLYPH&lt;127&gt; Reflection of commercial reality. It can be argued that a company that derives an economic profit from a certain activity should take ownership for any GHG emissions generated by the activity. This is achieved by using the equity share approach, since this approach assigns ownership for GHG emissions on the basis of economic interest in a business activity. The control approaches do not always reflect the full GHG emissions portfolio of a company's business activities, but have the advantage that a company takes full ownership of all GHG emissions that it can directly influence and reduce.

- GLYPH&lt;127&gt; Government reporting and emissions trading programs. Government regulatory programs will always need to monitor and enforce compliance. Since compliance responsibility generally falls to the operator (not equity holders or the group company that has financial control), governments will usually require reporting on the basis of operational control, either through a facility level-based system or involving the consolidation of data within certain geographical boundaries (e.g. the EU ETS will allocate emission permits to the operators of certain installations).
- GLYPH&lt;127&gt; Liability and risk management. While reporting and compliance with regulations will most likely continue to be based directly on operational control, the ultimate financial liability will often rest with the group company that holds an equity share in the operation or has financial control over it. Hence, for assessing risk, GHG reporting on the basis of the equity share and financial control approaches provides a more complete picture. The equity share approach is likely to result in the most comprehensive coverage of liability and risks. In the future, companies might incur liabilities for GHG emissions produced by joint operations in which they have an interest, but over which they do not have financial control. For example, a company that is an equity shareholder in an operation but has no financial control over it might face demands by the companies with a controlling share to cover its requisite share of GHG compliance costs.
- GLYPH&lt;127&gt; Alignment with financial accounting. Future financial accounting standards may treat GHG emissions as liabilities and emissions allowances / credits as assets. To assess the assets and liabilities a company creates by its joint operations, the same consolidation rules that are used in financial accounting should be applied in GHG accounting. The equity share and financial control approaches result in closer alignment between GHG accounting and financial accounting.
- GLYPH&lt;127&gt; Management information and performance tracking. For the purpose of performance tracking, the control approaches seem to be more appropriate since managers can only be held accountable for activities under their control.
- GLYPH&lt;127&gt; Cost of administration and data access. The equity share approach can result in higher administrative costs than the control approach, since it can be difficult and time consuming to collect GHG emissions data from joint operations not under the control of the reporting company. Companies are likely to have better access to operational data and therefore greater ability to ensure that it meets minimum quality standards when reporting on the basis of control.
- GLYPH&lt;127&gt; Completeness of reporting. Companies might find it difficult to demonstrate completeness of reporting when the operational control criterion is adopted, since there are unlikely to be any matching records or lists of financial assets to verify the operations that are included in the organizational boundary.

## Royal Dutch/Shell: Reporting on the basis of operational control

In the oil and gas industry, ownership and control structures are often  complex.  A  group  may  own  less  than  50  percent  of  a venture's  equity  capital  but  have  operational  control  over  the venture. On the other hand, in some situations, a group may hold a majority interest in a venture without being able to exert operational control, for example, when a minority partner has a veto vote at the board level. Because of these complex ownership and control  structures,  Royal  Dutch/Shell,  a  global  group of  energy and petrochemical companies, has chosen to report its GHG emissions on the basis of operational control. By reporting 100 percent of GHG emissions from all ventures under its operational control, irrespective  of  its  share  in  the  ventures'  equity  capital,  Royal Dutch/Shell can ensure that GHG emissions reporting is in line with  its  operational  policy  including  its  Health,  Safety  and Environmental Performance Monitoring and Reporting Guidelines. Using the operational control approach, the group generates data that is consistent, reliable, and meets its quality standards.

## Setting Organizational Boundaries

FIGURE 1.  Defining the organizational boundary of Holland Industries

<!-- image -->

## AN ILLUSTRATION:

## T H E   E Q U I T Y   S H A R E   A N D   C O N T R O L   A P P R O A C H E S

Holland Industries is a chemicals group comprising a number of companies/joint ventures active in the production and marketing of chemicals. Table 2 outlines the organizational structure of Holland Industries and shows how GHG emissions from the various wholly owned and joint operations are accounted for under both the equity share and control approaches.

In setting its organizational boundary, Holland Industries first decides whether to use the equity or control approach for consolidating GHG data at the corporate level. It then determines which operations at the corporate level meet its selected consolidation approach. Based on the selected consolidation approach, the consolidation process is repeated for each lower operational level. In this process, GHG emissions are first apportioned at the lower operational level (subsidiaries, associate, joint ventures, etc.) before they are consolidated at the corporate level. Figure 1 presents the organizational boundary of Holland Industries based on the equity share and control approaches.

## TABLE 2. Holland Industries - organizational structure and GHG emissions accounting

| WHOLLY OWNED AND JOINT OPERATIONS   | LEGAL STRUCTURE AND PARTNERS                                                                            | ECONOMIC INTEREST HELD BY HOLLAND INDUSTRIES   | CONTROL OF OPERATING POLICIES   | TREATMENT IN HOLLAND INDUSTRIES' FINANCIAL ACCOUNTS (SEE TABLE 1)                                                                                | EMISSIONS ACCOUNTED FOR AND REPORTED BY HOLLAND INDUSTRIES   | EMISSIONS ACCOUNTED FOR AND REPORTED BY HOLLAND INDUSTRIES        |
|-------------------------------------|---------------------------------------------------------------------------------------------------------|------------------------------------------------|---------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------|-------------------------------------------------------------------|
| OF HOLLAND                          |                                                                                                         |                                                |                                 |                                                                                                                                                  | EQUITY SHARE APPROACH                                        | CONTROL APPROACH                                                  |
| Holland Switzerland                 | Incorporated company                                                                                    | 100%                                           | Holland Industries              | Wholly owned subsidiary                                                                                                                          | 100%                                                         | 100% for operational control 100% for financial control           |
| Holland America                     | Incorporated company                                                                                    | 83%                                            | Holland Industries              | Subsidiary                                                                                                                                       | 83%                                                          | 100% for operational control 100% for financial control           |
| BGB                                 | Joint venture, partners have joint financial control other partner Rearden                              | 50% by Holland America                         | Rearden                         | via Holland America                                                                                                                              | 41.5% (83% x 50%)                                            | 0% for operational control 50% for financial control (50% x 100%) |
| IRW                                 | Subsidiary of Holland America                                                                           | 75% by Holland America                         | Holland America                 | via Holland America                                                                                                                              | 62.25% (83% x 75%)                                           | 100% for operational control 100% for financial control           |
| Kahuna Chemicals                    | Non-incorporated joint venture; partners have joint financial control; two other partners: ICT and BCSF | 33.3%                                          | Holland Industries              | Proportionally consolidated joint venture                                                                                                        | 33.3%                                                        | 100% for operational control 33.3% for financial control          |
| QuickFix                            | Incorporated joint venture, other partner Majox                                                         | 43%                                            | Holland Industries              | Subsidiary (Holland Industries has financial control since it treats Quick Fix as a subsidiary in its financial accounts)                        | 43%                                                          | 100% for operational control 100% for financial control           |
| Nallo                               | Incorporated joint venture, other partner Nagua Co.                                                     | 56%                                            | Nallo                           | Associated company (Holland Industries does not have financial control since it treats Nallo as an Associated company in its financial accounts) | 56%                                                          | 0% for operational control 0% for financial control               |
| Syntal                              | Incorporated company, subsidiary of Erewhon Co.                                                         | 1%                                             | Erewhon Co.                     | Fixed asset investment                                                                                                                           | 0%                                                           | 0% for operational control 0% for financial control               |

In this example, Holland America (not Holland Industries) holds a 50 percent interest in BGB and a 75 percent interest in IRW. If the activities of Holland Industries itself produce GHG emissions (e.g., emissions associated with electricity use at the head office), then these emissions should also be included in the consolidation at 100 percent.

## NOTES

- 1 The term 'operations' is used here as a generic term to denote any kind of business activity, irrespective of its organizational, governance, or legal structures.
- 2 Financial accounting standards use the generic term 'control' for what is denoted as 'financial control' in this chapter.

## Setting Operational Boundaries

<!-- image -->

fter a company has determined its organizational boundaries in terms of the operations that it owns or controls, it then sets its operational boundaries.  This  involves  identifying  emissions  associated  with  its  operations, categorizing  them  as  direct  and  indirect  emissions,  and  choosing  the  scope  of accounting and reporting for indirect emissions. A

S

G

T

U

A

I

N

D

D

A

A

N

R

C

D

E

For effective and innovative GHG management, setting operational boundaries that are comprehensive with respect to direct and indirect emissions will help a company better manage the full spectrum of GHG risks and opportunities that exist along its value chain.

Direct GHG emissions are emissions from sources that are owned or controlled by the company. 1

Indirect GHG emissions are emissions that are a consequence of the activities of the company but occur at sources owned or controlled by another company.

What is classified as direct and indirect emissions is dependent on the consolidation approach (equity share or control) selected for setting the organizational boundary (see chapter 3). Figure 2 below shows the relationship between the organizational and operational boundaries of a company.

## Introducing the concept of ' scope'

To help delineate direct and indirect emission sources, improve transparency, and provide utility for different types of organizations and different types of climate policies and business goals, three 'scopes' (scope 1, scope 2, and scope 3) are defined for GHG accounting and reporting purposes. Scopes 1 and 2 are carefully defined in this standard to ensure that two or more companies will not account for emissions in the same scope. This makes the scopes amenable for use in GHG programs where double counting matters.

## Scope 1: Direct GHG emissions

Direct GHG emissions occur from sources that are owned or controlled by the company, for example, emissions from combustion in owned or controlled boilers, furnaces, vehicles, etc.; emissions from chemical production in owned or controlled process equipment.

Direct CO 2 emissions from the combustion of biomass shall not be included in scope 1 but reported separately (see chapter 9).

GHG emissions not covered by the Kyoto Protocol, e.g. CFCs, NOx, etc. shall not be included in scope 1 but may be reported separately (see chapter 9).

## Scope 2: Electricity indirect GHG emissions

Scope 2 accounts for GHG emissions from the generation of purchased electricity 2 consumed by the company. Purchased electricity is defined as electricity that is purchased or otherwise brought into the organizational boundary of the company. Scope 2 emissions physically occur at the facility where electricity is generated.

## Scope 3: Other indirect GHG emissions

Companies shall separately account for and report on scopes 1 and 2 at a minimum.

Scope 3 is an optional reporting category that allows for the treatment of all other indirect emissions. Scope 3 emissions are a consequence of the activities of the company, but occur from sources not owned or controlled by the company. Some examples of scope 3 activities are extraction and production of purchased materials; transportation of purchased fuels; and use of sold products and services.

FIGURE 2. Organizational and operational boundaries of a company

<!-- image -->

n operational boundary defines the scope of direct and indirect emissions for operations that fall within a company's established organizational boundary. The operational boundary (scope 1, scope 2, scope 3) is decided at the corporate level after setting the organizational boundary. The selected operational boundary is then uniformly applied to identify and categorize direct and indirect emissions at each operational level (see Box 2). The established organizational and operational boundaries together constitute a company's inventory boundary. A

## BOX 2. Organizational and operational boundaries

Organization X is a parent company that has full ownership and financial  control  of  operations  A  and  B,  but  only  a  30%  nonoperated interest and no financial control in operation C.

Setting  Organizational  Boundary: X  would  decide  whether  to account for GHG emissions by equity share or financial control. If the choice is equity share, X would include A and B, as well as 30% of  C's  emissions.  If  the  approach  chosen  is  financial  control,  X would count only A and B's emissions as relevant and subject to consolidation.  Once  this  has  been  decided,  the  organizational boundary has been defined.

Setting Operational Boundary: Once the organizational boundary is set, X then needs to decide, on the basis of its business goals, whether  to  account  only  for  scope  1  and  scope  2,  or  whether  to include relevant scope 3 categories for its operations.

## Accounting and reporting on scopes

Companies account for and report emissions from scope 1 and 2 separately. Companies may further subdivide emissions data within scopes where this aids transparency or facilitates comparability over time. For example, they may subdivide data by business unit/facility, country, source type (stationary combustion, process, fugitive, etc.), and activity type (production of electricity, consumption of electricity, generation or purchased electricity that is sold to end users, etc.).

In addition to the six Kyoto gases, companies may also provide emissions data for other GHGs (e.g., Montreal Protocol gases) to give context to changes in emission levels of Kyoto Protocol gases. Switching from a CFC to HFC, for example, will increase emissions of Kyoto Protocol gases. Information on emissions of GHGs other than the six Kyoto gases may be reported separately from the scopes in a GHG public report.

Together the three scopes provide a comprehensive accounting framework for managing and reducing direct and indirect emissions. Figure 3 provides an overview of the relationship between the scopes and the activities that generate direct and indirect emissions along a company's value chain.

Operations A, B and C (if the equity approach is selected) account for the GHG emissions in the scopes chosen by X, i.e., they apply the corporate policy in drawing up their operational boundaries.

A company can benefit from efficiency gains throughout the value chain. Even without any policy drivers, accounting for GHG emissions along the value chain may reveal potential for greater efficiency and lower costs (e.g., the use of fly ash as a clinker substitute in the manufacture of cement that reduces downstream emissions from processing of waste fly ash, and upstream

FIGURE 3. Overview of scopes and emissions across a value chain

<!-- image -->

emissions from producing clinker). Even if such 'winwin' options are not available, indirect emissions reductions may still be more cost effective to accomplish than scope 1 reductions. Thus accounting for indirect emissions can help identify where to allocate limited resources in a way that maximizes GHG reduction and return on investment.

Appendix D lists GHG sources and activities along the value chain by scopes for various industry sectors.

## Scope 1: Direct GHG emissions

Companies report GHG emissions from sources they own or control as scope 1. Direct GHG emissions are principally the result of the following types of activities undertaken by the company:

- GLYPH&lt;127&gt; Generation of electricity, heat, or steam. These emissions result from combustion of fuels in stationary sources, e.g., boilers, furnaces, turbines
- GLYPH&lt;127&gt; Physical or chemical processing. 3 Most of these emissions result from manufacture or processing of chemicals and materials, e.g., cement, aluminum, adipic acid, ammonia manufacture, and waste processing
- GLYPH&lt;127&gt; Transportation of materials, products, waste, and employees. These emissions result from the combustion of fuels in company owned/controlled mobile combustion sources (e.g., trucks, trains, ships, airplanes, buses, and cars)
- GLYPH&lt;127&gt; Fugitive emissions. These emissions result from intentional or unintentional releases, e.g., equipment leaks from joints, seals, packing, and gaskets; methane emissions from coal mines and venting; hydrofluorocarbon (HFC) emissions during the use of refrigeration and air conditioning equipment; and methane leakages from gas transport.

## SALE OF OWN-GENERATED ELECTRICITY

Emissions associated with the sale of own-generated electricity to another company are not deducted/netted from scope 1. This treatment of sold electricity is consistent with how other sold GHG intensive products are accounted, e.g., emissions from the production of sold clinker by a cement company or the production of scrap steel by an iron and steel company are not subtracted from their scope 1 emissions. Emissions associated with the sale/transfer of own-generated electricity may be reported in optional information (see chapter 9).

## Scope 2: Electricity indirect GHG emissions

Companies report the emissions from the generation of purchased electricity that is consumed in its owned or controlled equipment or operations as scope 2. Scope 2 emissions are a special category of indirect emissions. For many companies, purchased electricity represents one of the largest sources of GHG emissions and the most significant opportunity to reduce these emissions. Accounting for scope 2 emissions allows companies to assess the risks and opportunities associated with changing electricity and GHG emissions costs. Another important reason for companies to track these emissions is that the information may be needed for some GHG programs.

Companies can reduce their use of electricity by investing in energy efficient technologies and energy conservation. Additionally, emerging green power markets 4 provide opportunities for some companies to switch to less GHG intensive sources of electricity. Companies can also install an efficient on site co-generation plant, particularly if it replaces the purchase of more GHG intensive electricity from the grid or electricity supplier. Reporting of scope 2 emissions allows transparent accounting of GHG emissions and reductions associated with such opportunities.

## I N D I R E C T   E M I S S I O N S

## ASSOCIATED WITH TRANSMISSION AND DISTRIBUTION

Electric utility companies often purchase electricity from independent power generators or the grid and resell it to end-consumers through a transmission and distribution (T&amp;D) system. 5 A portion of the electricity purchased by a utility company is consumed (T&amp;D loss) during its transmission and distribution to end-consumers (see Box 3).

Consistent with the scope 2 definition, emissions from the generation of purchased electricity that is consumed during transmission and distribution are reported in scope 2 by the company that owns or controls the T&amp;D operation. End consumers of the purchased electricity do not report indirect emissions associated with T&amp;D losses in scope 2 because they do not own or control the T&amp;D operation where the electricity is consumed (T&amp;D loss).

<!-- image -->

U

I

D

A

N

C

E

## Setting Operational Boundaries

This approach ensures that there is no double counting within scope 2 since only the T&amp;D utility company will account for indirect emissions associated with T&amp;D losses in scope 2. Another advantage of this approach is that it adds simplicity to the reporting of scope 2 emissions by allowing the use of commonly available emission factors that in most cases do not include T&amp;D losses. End consumers may, however, report their indirect emissions associated with T&amp;D losses in scope 3 under the category 'generation of electricity consumed in a T&amp;D system.' Appendix A provides more guidance on accounting for emissions associated with T&amp;D losses.

## OTHER ELECTRICITY-RELATED INDIRECT EMISSIONS

Indirect emissions from activities upstream of a company's electricity provider (e.g., exploration, drilling, flaring, transportation) are reported under scope 3. Emissions from the generation of electricity that has been purchased for resale to end-users are reported in scope 3 under the category 'generation of electricity that is purchased and then resold to end users.' Emissions from the generation of purchased electricity for resale to nonend-users (e.g., electricity traders) may be reported separately from scope 3 in 'optional information.'

The following two examples illustrate how GHG emissions are accounted for from the generation, sale, and purchase of electricity.

## Seattle City Light: Accounting for the purchase of electricity sold to end users

Seattle City Light (SCL), Seattle's municipal utility company, sells electricity to its end-use customers that is either produced at its own hydropower facilities, purchased through long-term contracts, or purchased on the short-term market. SCL used the first edition of the GHG Protocol Corporate Standard to estimate its year 2000 and year 2002 GHG emissions, and emissions associated with generation of net purchased electricity sold to end-users was an important component of that inventory. SCL tracks and reports the amount of electricity sold to end-users on a monthly and annual basis.

SCL calculates net purchases from the market (brokers and other utility companies) by subtracting sales to the market from purchases  from  the  market,  measured  in  MWh.  This  allows  a complete accounting of all emissions impacts from its entire operation, including interactions with the market and end-users. On an annual basis, SCL produces more electricity than there is end-use

Example one (Figure 4): Company A is an independent power generator that owns a power generation plant. The power plant produces 100 MWh of electricity and releases 20 tonnes of emissions per year. Company B is an electricity trader and has a supply contract with company A to purchase all its electricity. Company B resells the purchased electricity (100 MWh) to company C, a utility company that owns / controls the T&amp;D system. Company C consumes 5 MWh of electricity in its T&amp;D system and sells the remaining 95 MWh to company D. Company D is an end user who consumes the purchased electricity (95 MWh) in its own operations. Company A reports its direct emissions from power generation under scope 1. Company B reports emissions from the purchased electricity sold to a non-end-user as optional information separately from scope 3. Company C reports the indirect emissions from the generation of the part of the purchased electricity that is sold to the end-user under scope 3 and the part of the purchased electricity that it consumes in its T&amp;D system under scope 2. Enduser D reports the indirect emissions associated with its own consumption of purchased electricity under scope 2 and can optionally report emissions associated with upstream T&amp;D losses in scope 3. Figure 4 shows the accounting of emissions associated with these transactions.

Example two: Company D installs a co-generation unit and sells surplus electricity to a neighboring company E for its consumption. Company D reports all direct emissions from the co-generation unit under scope 1. Indirect emissions from the generation of electricity for export to E are reported by D under optional information separately demand, but the production does not match load in all months. So SCL accounts for both purchases from the market and sales into the market. SCL also includes the scope 3 upstream emissions from natural  gas  production  and  delivery,  operation  of  SCL  facilities, vehicle fuel use, and airline travel.

SCL believes that sales to end-users are a critical part of the emissions profile for an electric utility company. Utility companies need to  provide  information on their emissions profile to educate endusers and adequately represent the impact of their business, the providing  of  electricity.  End-use  customers  need  to  rely  on  their utility company to provide electricity, and except in some instances (green power programs), do not have a choice in where their electricity  is  purchased.  SCL  meets  a  customer  need  by  providing emissions information to customers who are doing their own emissions inventory.

from scope 3. Company E reports indirect emissions associated with the consumption of electricity purchased from the company D's co-generation unit under scope 2.

For more guidance, see Appendix A on accounting for indirect emissions from purchased electricity.

## Scope 3: Other indirect GHG emissions

Scope 3 is optional, but it provides an opportunity to be innovative in GHG management. Companies may want to focus on accounting for and reporting those activities that are relevant to their business and goals, and for which they have reliable information. Since companies have discretion over which categories they choose to report, scope 3 may not lend itself well to comparisons across companies. This section provides an indicative list of scope 3 categories and includes case studies on some of the categories.

Some of these activities will be included under scope 1 if the pertinent emission sources are owned or controlled by the company (e.g., if the transportation of products is done in vehicles owned or controlled by the company). To determine if an activity falls within scope 1 or scope 3, the company should refer to the selected consolidation approach (equity or control) used in setting its organizational boundaries.

- GLYPH&lt;127&gt; Extraction and production of purchased materials and fuels 6
- GLYPH&lt;127&gt; Transport-related activities
- GLYPH&lt;127&gt; Transportation of purchased materials or goods
- GLYPH&lt;127&gt; Transportation of purchased fuels
- GLYPH&lt;127&gt; Employee business travel
- GLYPH&lt;127&gt; Employees commuting to and from work
- GLYPH&lt;127&gt; Transportation of sold products
- GLYPH&lt;127&gt; Electricity-related activities not included in scope 2 (see Appendix A)
- GLYPH&lt;127&gt; Extraction, production, and transportation of fuels consumed in the generation of electricity (either purchased or own generated by the reporting company)
- GLYPH&lt;127&gt; Purchase of electricity that is sold to an end user (reported by utility company)
- GLYPH&lt;127&gt; Generation of electricity that is consumed in a T&amp;D system (reported by end-user)
- GLYPH&lt;127&gt; Leased assets, franchises, and outsourced activitiesemissions from such contractual arrangements are only classified as scope 3 if the selected consolidation approach (equity or control) does not apply to them. Clarification on the classification of leased assets should be obtained from the company accountant (see section on leases below).
- GLYPH&lt;127&gt; Use of sold products and services
- GLYPH&lt;127&gt; Waste disposal
- GLYPH&lt;127&gt; Disposal of waste generated in operations
- GLYPH&lt;127&gt; Disposal of waste generated in the production of purchased materials and fuels
- GLYPH&lt;127&gt; Disposal of sold products at the end of their life

## ACCOUNTING FOR SCOPE 3 EMISSIONS

Accounting for scope 3 emissions need not involve a full-blown GHG life cycle analysis of all products and operations. Usually it is valuable to focus on one or two major GHG-generating activities. Although it is difficult to provide generic guidance on which scope 3 emissions to include in an inventory, some general steps can be articulated:

- GLYPH&lt;127&gt; Transportation of waste

## FIGURE 4. GHG accounting from the sale and purchase of electricity

<!-- image -->

- 1. Describe the value chain. Because the assessment of scope 3 emissions does not require a full life cycle assessment, it is important, for the sake of transparency, to provide a general description of the value chain and the associated GHG sources. For this step, the scope 3 categories listed can be used as a checklist. Companies usually face choices on how many levels up- and downstream to include in scope 3. Consideration of the company's inventory or business goals and relevance of the various scope 3 categories will guide these choices.
- 2. Determine which scope 3 categories are relevant. Only some types of upstream or downstream emissions categories might be relevant to the company. They may be relevant for several reasons:
- GLYPH&lt;127&gt; They are large (or believed to be large) relative to the company's scope 1 and scope 2 emissions
- GLYPH&lt;127&gt; They contribute to the company's GHG risk exposure
- GLYPH&lt;127&gt; They are deemed critical by key stakeholders (e.g., feedback from customers, suppliers, investors, or civil society)
- GLYPH&lt;127&gt; There are potential emissions reductions that could be undertaken or influenced by the company.

The following examples may help decide which scope 3 categories are relevant to the company.

## DHL Nordic Express: The business case for accounting for outsourced transportation services

As a major transportation and logistics company in northern Europe, DHL Express Nordic serves large loads and special transport needs as well as world wide express package and document deliveries and offers  courier,  express,  parcel,  systemized  and  specialty  business services. Through participation in the Business Leaders Initiative on Climate Change, the company found that 98 percent of its emissions in  Sweden  originate  from  the  transport  of  goods  via  outsourced partner transportation firms. Each partner is required, as an element of the subcontract payment scheme, to enter data on vehicles used, distance traveled, fuel efficiency, and background data. This data is used to calculate total emissions via a tailored calculation tool for outsourced transportation which gives a detailed picture of its scope 3 emissions. Linking data to specific carriers allows the company to screen individual carriers for environmental performance and affect decisions based on each carrier's emissions performance, which is seen through scope 3 as DHL's own performance.

By including scope 3 and promoting GHG reductions throughout the value  chain,  DHL  Express  Nordic  increased  the  relevance  of  its emissions footprint, expanded opportunities for reducing its impacts and improved its ability to recognize cost saving opportunities.  Without  scope  3,  DHL  Express  Nordic  would  have  lacked much of the information needed to be able to understand and effectively manage its emissions.

- GLYPH&lt;127&gt; If fossil fuel or electricity is required to use the company's products, product use phase emissions may be a relevant category to report. This may be especially important if the company can influence product design attributes (e.g., energy efficiency) or customer behavior in ways that reduce GHG emissions during the use of the products.

| SCOPE   | EMISSIONS ( t CO   |
|---------|--------------------|
| Scope 1 | 7,265              |
| Scope 2 | 52                 |
| Scope 3 | 327,634            |
| Total   | 334,951            |

FIGURE 5. Accounting of emissions from leased assets

<!-- image -->

- GLYPH&lt;127&gt; Outsourced activities are often candidates for scope 3 emissions assessments. It may be particularly important to include these when a previously outsourced activity contributed significantly to a company's scope 1 or scope 2 emissions.
- GLYPH&lt;127&gt; If GHG-intensive materials represent a significant fraction of the weight or composition of a product used or manufactured (e.g., cement, aluminum), companies may want to examine whether there are opportunities to reduce their consumption of the product or to substitute less GHG-intensive materials.
- GLYPH&lt;127&gt; Large manufacturing companies may have significant emissions related to transporting purchased materials to centralized production facilities.
- GLYPH&lt;127&gt; Commodity and consumer product companies may want to account for GHGs from transporting raw materials, products, and waste.
- GLYPH&lt;127&gt; Service sector companies may want to report on emissions from employee business travel; this emissions source is not as likely to be significant for other kinds of companies (e.g., manufacturing companies).
- 3. Identify partners along the value chain. Identify any partners that contribute potentially significant amounts of GHGs along the value chain (e.g., customers/users, product designers/manufacturers, energy providers, etc.). This is important when trying to identify sources, obtain relevant data, and calculate emissions.
- 4. Quantify scope 3 emissions. While data availability and reliability may influence which scope 3 activities are included in the inventory, it is accepted that data accuracy may be lower. It may be more important to understand the relative magnitude of and possible changes to scope 3 activities. Emission estimates are acceptable as long as there is transparency with regard to the estimation approach, and the data used for the analysis are adequate to support the objectives of the inventory. Verification of scope 3 emissions will often be difficult and may only be considered if data is of reliable quality.

## IKEA: Customer transportation to and from its retail stores

IKEA,  an  international  home  furniture  and  furnishings  retailer, decided to include scope 3 emissions from customer travel when it  became  clear,  through  participation  in  the  Business  Leaders Initiative on Climate Change (BLICC) program, that these emissions  were  large  relative  its  scope  1  and  scope  2  emissions. Furthermore, these emissions are particularly relevant to IKEA's store  business model. Customer travel to its stores, often from long distances, is directly affected by IKEA's choice of store location and the warehouse shopping concept.

Customer  transportation  emission  calculations  were  based  on customer surveys at selected stores. Customers were asked for the  distance  they  traveled  to  the  store  (based  on  home  postal code), the number of customers in their car, the number of other stores they intended to visit at that shopping center that day, and whether  they  had  access  to  public  transportation  to  the  store. Extrapolating this data to all IKEA stores and multiplying distance by  average  vehicle  efficiencies  for  each  country,  the  company calculated that 66 percent of its emissions inventory was from scope 3 customer travel. Based on this information, IKEA will have significant influence over future scope 3 emissions by considering GHG  emissions  when  developing  public  transportation  options and home delivery services for its existing and new stores.

## Leased assets, outsourcing, and franchises

The selected consolidation approach (equity share or one of the control approaches) is also applied to account for and categorize direct and indirect GHG emissions from contractual arrangements such as leased assets, outsourcing, and franchises. If the selected equity or control approach does not apply, then the company may account for emissions from the leased assets, outsourcing, and franchises under scope 3. Specific guidance on leased assets is provided below:

- GLYPH&lt;127&gt; USING EQUITY SHARE OR FINANCIAL CONTROL: The lessee only accounts for emissions from leased assets that are treated as wholly owned assets in financial accounting and are recorded as such on the balance sheet (i.e., finance or capital leases).

## Setting Operational Boundaries

- GLYPH&lt;127&gt; USING OPERATIONAL CONTROL: The lessee only accounts for emissions from leased assets that it operates (i.e., if the operational control criterion applies).

Guidance on which leased assets are operating and which are finance leases should be obtained from the company accountant. In general, in a finance lease, an organization assumes all rewards and risks from the leased asset, and the asset is treated as wholly owned and is recorded as such on the balance sheet. All leased assets that do not meet those criteria are operating leases. Figure 5 illustrates the application of consolidation criteria to account for emissions from leased assets.

## Double counting

Concern is often expressed that accounting for indirect emissions will lead to double counting when two different companies include the same emissions in their respective inventories. Whether or not double counting occurs depends on how consistently companies with shared ownership or trading program administrators choose the same approach (equity or control) to set the organizational boundaries. Whether or not double counting matters, depends on how the reported information is used.

Double counting needs to be avoided when compiling national (country) inventories under the Kyoto Protocol, but these are usually compiled via a top-down exercise using national economic data, rather than aggregation of bottom-up company data. Compliance regimes are more likely to focus on the 'point of release' of emissions (i.e., direct emissions) and/or indirect emissions from use of electricity. For GHG risk management and voluntary reporting, double counting is less important.

## World Resources Institute:

## Innovations in estimating employee commuting emissions

The World Resources Institute has a long-standing commitment to reduce its annual GHG emissions to net zero through a combination of  internal  reduction  efforts  and  external  offset  purchases.  WRI's emissions  inventory  includes  scope  2  indirect  emissions  associated with the consumption of purchased electricity and scope 3 indirect emissions associated with business air travel, employee commuting, and paper use. WRI has no scope 1 direct emissions.

benefit was that employees felt a certain amount of pride at having contributed to the inventory development process. The experience also provided a positive internal communications opportunity.

Collecting employee commuting activity data from WRI's 140 staff can be challenging. The method used is to survey employees once each year about their average commuting habits. In the first two years of the initiative, WRI used an Excel spreadsheet accessible to all employees on a shared internal network, but only achieved a  48  percent  participation  rate.  A  simplified,  web-based  survey that downloaded  into  a  spreadsheet  improved  participation  to 65 percent in the third year. Using feedback on the survey design, WRI further simplified and refined survey questions, improved user friendliness, and reduced the time needed to complete the survey to less than a minute. Employee participation rate rose to 88 percent.

Designing a survey that was easily navigable and had clearly articulated  questions  significantly  improved  the  completeness  and accuracy  of  the  employee  commuting  activity  data.  An  added

WRI has developed a guide consistent with GHG Protocol Corporate Standard to  help  office-based  organizations  understand  how  to track and manage their emissions. Working 9 to 5 on Climate Change: An Office Guide is accompanied by a suite of calculation tools, including  one  for  using  a  survey  method  to  estimate  employee commuting emissions. The Guide and tools can be downloaded from the GHG Protocol Initiative website (www.ghgprotocol.org).

Transportation-related  emissions  are  the  fastest  growing  GHG emissions category in the United States. This includes commercial, business, and personal travel as well as commuting. By accounting for commuting  emissions, companies  may  find that several practical opportunities exist for reducing them. For example, when WRI moved to new office space, it selected a building located close to public transportation, reducing the need for employees to drive to work. In its lease, WRI also negotiated access to a locked bike room  for  those  employees  who  cycle  to  work.  Finally,  telework programs significantly reduce commuting emissions by avoiding or decreasing the need to travel.

For participating in GHG markets or obtaining GHG credits, it would be unacceptable for two organizations to claim ownership of the same emissions commodity and it is therefore necessary to make sufficient provisions to ensure that this does not occur between participating companies (see chapter 11).

## SCOPES AND DOUBLE COUNTING

The GHG Protocol Corporate Standard is designed to prevent double counting of emissions between different companies within scope 1 and 2. For example, the scope 1 emissions of company A (generator of electricity) can be counted as the scope 2 emissions of company B (end-user of electricity) but company A's scope 1 emissions cannot be counted as scope 1 emissions by company C (a partner organization of company A) as long as company A and company C consistently apply the same control or equity share approach when consolidating emissions.

Similarly, the definition of scope 2 does not allow double counting of emissions within scope 2, i.e., two different companies cannot both count scope 2 emissions from the purchase of the same electricity. Avoiding this type of double counting within scope 2 emissions makes it a useful accounting category for GHG trading programs that regulate end users of electricity.

When used in external initiatives such as GHG trading, the robustness of the scope 1 and 2 definitions combined with the consistent application of either the control or equity share approach for defining organizational boundaries allows only one company to exercise ownership of scope 1 or scope 2 emissions.

<!-- image -->

## ABB: Calculating product use phase emissions associated with electrical appliances

ABB,  an  energy  and  automation  technology  company  based  in Switzerland,  produces  a  variety  of  appliances  and  equipment, such as circuit breakers and electrical drives, for industrial applications. ABB has a stated goal to issue Environmental Product Declarations (EPDs) for all its core products based on life cycle assessment.  As  a  part  of  its  committment,  ABB  reports  both manufacturing  and  product  use  phase  GHG  emissions  for  a variety of its products using a standardized calculation method and set of assumptions. For example, product use phase calculations for ABB's 4 kW DriveIT Low Voltage AC drive are based on a 15-year expected lifetime and an average of 5,000 annual operating  hours.  This  activity  data  is  multiplied  by  the  average electricity  emission  factor  for  OECD  countries  to  produce  total lifetime product use emissions.

Compared  with  manufacturing  emissions,  product  use  phase emissions account for about 99 percent of total life cycle emissions for this type of drive. The magnitude of these emissions and ABB's control of the design and performance of this equipment clearly give the company significant leverage on its customers' emissions by improving product efficiency or helping customers design  better  overall  systems  in  which  ABB's  products  are involved.  By  clearly  defining  and  quantifying  significant  value chain emissions, ABB has gained insight into and influence over its emissions footprint.

## NOTES

- 1 The terms 'direct' and 'indirect' as used in this document should not be confused with their use in national GHG inventories where 'direct' refers to the six Kyoto gases and 'indirect' refers to the precursors NOx, NMVOC, and CO.
- 2 The term 'electricity' is used in this chapter as shorthand for electricity, steam, and heating/cooling.
- 3 For some integrated manufacturing processes, such as ammonia manufacture, it may not be possible to distinguish between GHG emissions from the process and those from the production of electricity, heat, or steam.
- 4 Green power includes renewable energy sources and specific clean energy technologies that reduce GHG emissions relative to other sources of energy that supply the electric grid, e.g., solar photovoltaic panels, geothermal energy, landfill gas, and wind turbines.
- 5 A T&amp;D system includes T&amp;D lines and other T&amp;D equipment (e.g., transformers).
- 6 'Purchased materials and fuels' is defined as material or fuel that is purchased or otherwise brought into the organizational boundary of the company.

## Tracking Emissions Over Time

<!-- image -->

ompanies  often  undergo  significant  structural  changes  such  as acquisitions, divestments, and mergers. These changes will alter a company's historical emission profile, making meaningful comparisons over time difficult. In order to maintain consistency over time, or in other words, to  keep  comparing  'like  with  like',  historic  emission  data  will  have  to be recalculated. C

S

G

T

U

A

I

N

D

D

A

A

N

R

C

D

E

Companies may need to track emissions over time in response to a variety of business goals, including:

- GLYPH&lt;127&gt; Public reporting
- GLYPH&lt;127&gt; Establishing GHG targets
- GLYPH&lt;127&gt; Managing risks and opportunities
- GLYPH&lt;127&gt; Addressing the needs of investors and other stakeholders

A meaningful and consistent comparison of emissions over time requires that companies set a performance datum with which to compare current emissions. This performance datum is referred to as the base year 1 emissions. For consistent tracking of emissions over time, the base year emissions may need to be recalculated as companies undergo significant structural changes such as acquisitions, divestments, and mergers.

The first step in tracking emissions, however, is the selection of a base year.

## Choosing a base year

Companies shall choose and report a base year for which verifiable emissions data are available and specify their reasons for choosing that particular year.

Most companies select a single year as their base year. However, it is also possible to choose an average of annual emissions over several consecutive years. For example, the U.K. ETS specifies an average of 1998-2000 emissions as the reference point for tracking reductions. A multi-year average may help smooth out unusual fluctuations in GHG emissions that would make a single year's data unrepresentative of the company's typical emissions profile.

The inventory base year can also be used as a basis for setting and tracking progress towards a GHG target in which case it is referred to as a target base year (see chapter 11).

## Recalculating base year emissions

Companies shall develop a base year emissions recalculation policy, and clearly articulate the basis and context for any recalculations. If applicable, the policy shall state any 'significance threshold' applied for deciding on historic emissions recalculation. 'Significance threshold' is a qualitative and/or quantitative criterion used to define any significant change to the data, inventory boundary, methods, or any other relevant factors. It is the responsibility of the company to determine the 'significance threshold' that triggers base year emissions recalculation and to disclose it. It is the responsibility of the verifier to confirm the company's adherence to its threshold policy. The following cases shall trigger recalculation of base year emissions:

- GLYPH&lt;127&gt; Structural changes in the reporting organization that have a significant impact on the company's base year emissions. A structural change involves the transfer of ownership or control of emissions-generating activities or operations from one company to another. While a single structural change might not have a significant impact on the base year emissions, the cumulative effect of a number of minor structural changes can result in a significant impact. Structural changes include:
- GLYPH&lt;127&gt; Mergers, acquisitions, and divestments
- GLYPH&lt;127&gt; Outsourcing and insourcing of emitting activities
- GLYPH&lt;127&gt; Changes in calculation methodology or improvements in the accuracy of emission factors or activity data that result in a significant impact on the base year emissions data
- GLYPH&lt;127&gt; Discovery of significant errors, or a number of cumulative errors, that are collectively significant.

In summary, base year emissions shall be retroactively recalculated to reflect changes in the company that would otherwise compromise the consistency and relevance of the reported GHG emissions information. Once a company has determined its policy on how it will recalculate base year emissions, it shall apply this policy in a consistent manner. For example, it shall recalculate for both GHG emissions increases and decreases.

election and recalculation of a base year should relate to the business goals and the particular context of the company: S

- GLYPH&lt;127&gt; For the purpose of reporting progress towards voluntary public GHG targets, companies may follow the standards and guidance in this chapter
- GLYPH&lt;127&gt; A company subject to an external GHG program may face external rules governing the choice and recalculation of base year emissions
- GLYPH&lt;127&gt; For internal management goals, the company may follow the rules and guidelines recommended in this document, or it may develop its own approach, which should be followed consistently.

## Choosing a base year

Companies should choose as a base year the earliest relevant point in time for which they have reliable data. Some organizations have adopted 1990 as a base year in order to be consistent with the Kyoto Protocol. However, obtaining reliable and verifiable data for historical base years such as 1990 can be very challenging.

If a company continues to grow through acquisitions, it may adopt a policy that shifts or 'rolls' the base year forward by a number of years at regular intervals. Chapter 11 contains a description of such a 'rolling base year,' including a comparison with the fixed base year approach described in this chapter. A fixed base year has the advantage of allowing emissions data to be compared on a like-with-like basis over a longer time period than a rolling base year approach. Most emissions trading and registry programs require a fixed base year policy to be implemented.

FIGURE 6. Base year emissions recalculation for an acquisition

<!-- image -->

Production

Acquires C

Company Gamma consists of two business units (A and B). In its base year (year one), each business unit emits 25 tonnes CO . In year two, 2 the company undergoes 'organic growth,' leading to an increase in emissions to 30 tonnes CO 2 per business unit, i.e., 60 tonnes CO 2 in total. The base year emissions are not recalculated in this case. At the beginning of year three, the company acquires production facility C from another company. The annual emissions of facility C in year one were 15 tonnes CO , and 20 tonnes CO 2 2 in years two and three. The total emission of company Gamma in year three, including facility C, are therefore 80 tonnes CO . To maintain consistency over time, the 2 company recalculates its base year emissions to take into account the acquisition of facility C. The base year emissions increase by 15  tonnes  CO -the  quantity  of  emissions  produced  by  facility  C  in  Gamma's  base  year.  The  recalculated  base  year  emissions  are 2 65 tonnes CO . Gamma also (optionally) reports 80 tonnes CO 2 2 as the recalculated emissions for year two.

FIGURE 7. Base year emissions recalculation for a divestment

<!-- image -->

Company Beta consists of three business units (A, B, and C). Each business unit emits 25 tonnes CO 2 and the total emissions for the company are 75 tonnes CO 2 in the base year (year one). In year two, the output of the company grows, leading to an increase in emissions to 30 tonnes CO 2 per business unit, i.e., 90 tonnes CO 2 in total. At the beginning of year three, Beta divests business unit C and its annual emissions are now 60 tonnes, representing an apparent reduction of 15 tonnes relative to the base year emissions. However, to maintain consistency over time, the company recalculates its base year emissions to take into account the divestment of business unit C. The base year emissions are lowered by 25 tonnes CO -the quantity of emissions produced by the business unit C in the base year. The recalcu2 lated base year emissions are 50 tonnes CO , and the emissions of company Beta are seen to have risen by 10 tonnes CO 2 2 over the three years. Beta (optionally) reports 60 tonnes CO 2 as the recalculated emissions for year two.

## Significance thresholds for recalculations

Whether base year emissions are recalculated depends on the significance of the changes. The determination of a significant change may require taking into account the cumulative effect on base year emissions of a number of small acquisitions or divestments. The GHG Protocol Corporate Standard makes no specific recommendations as to what constitutes 'significant.' However, some GHG programs do specify numerical significance thresholds, e.g., the California Climate Action Registry, where the change threshold is 10 percent of the base year emissions, determined on a cumulative basis from the time the base year is established.

## Base year emissions recalculation for structural changes

Structural changes trigger recalculation because they merely transfer emissions from one company to another without any change of emissions released to the atmos- phere, for example, an acquisition or divestment only transfers existing GHG emissions from one company's inventory to another.

Figures 6 and 7 illustrate the effect of structural changes and the application of this standard on recalculation of base year emissions.

## Timing of recalculations for structural changes

When significant structural changes occur during the middle of the year, the base year emissions should be recalculated for the entire year, rather than only for the remainder of the reporting period after the structural change occurred. This avoids having to recalculate base year emissions again in the succeeding year. Similarly, current year emissions should be recalculated for the entire year to maintain consistency with the base year recalculation. If it is not possible to make a recalculation in the year of the structural change (e.g., due to

U

I

D

A

N

C

E

lack of data for an acquired company), the recalculation may be carried out in the following year. 2

## Recalculations for changes in calculation methodology or improvements in data accuracy

A company might report the same sources of GHG emissions as in previous years, but measure or calculate them differently. For example, a company might have used a national electric power generation emissions factor to estimate scope 2 emissions in year one of reporting. In later years, it may obtain more accurate utility-specific emission factors (for the current as well as past years) that better reflect the GHG emissions associated with the electricity that it has purchased. If the differences in emissions resulting from such a change are significant, historic data is recalculated applying the new data and/or methodology.

Sometimes the more accurate data input may not reasonably be applied to all past years or new data points may not be available for past years. The company may then have to backcast these data points, or the change in data source may simply be acknowledged without recalculation. This acknowledgement should be made in the report each year in order to enhance transparency; otherwise, new users of the report in the two or three years after the change may make incorrect assumptions about the performance of the company.

Any changes in emission factor or activity data that reflect real changes in emissions (i.e., changes in fuel type or technology) do not trigger a recalculation.

## Optional reporting for recalculations

Optional information that companies may report on recalculations includes:

- GLYPH&lt;127&gt; The recalculated GHG emissions data for all years between the base year and the reporting year
- GLYPH&lt;127&gt; All actual emissions as reported in respective years in the past, i.e., the figures that have not been recalculated. Reporting the original figures in addition to the recalculated figures contributes to transparency since it illustrates the evolution of the company's structure over time.

## No base year emissions recalculations for facilities that did not exist in the base year

Base year emissions are not recalculated if the company makes an acquisition of (or insources) operations that did not exist in its base year. There may only be a recalculation of historic data back to the year in which the acquired company came into existence. The same applies to cases where the company makes a divestment of (or outsources) operations that did not exist in the base year.

Figure 8 illustrates a situation where no recalculation of base year emissions is required, since the acquired facility came into existence after the base year was set.

## No recalculation for ' outsourcing/insourcing' if reported under scope 2 and/or scope 3

Structural changes due to 'outsourcing' or 'insourcing' do not trigger base year emissions recalculation if the company is reporting its indirect emissions from relevant outsourced or insourced activities. For example, outsourcing production of electricity, heat, or steam does not trigger base year emissions recalculation, since the GHG Protocol Corporate Standard requires scope 2 reporting. However, outsourcing/insourcing that shifts significant emissions between scope 1 and scope 3 when scope 3 is not reported does trigger a base year emissions recalculation (e.g., when a company outsources the transportation of products).

In case a company decides to track emissions over time separately for different scopes, and has separate base years for each scope, base year emissions recalculation for outsourcing or insourcing is made.

## ENDESA: Recalculation of base year emissions because of structural changes

The GHG Protocol Corporate Standard requires setting a base year for comparing emissions over time. To be able to compare over time, the base year emissions must be recalculated if any structural changes occur  in  the  company.  In  a  deal  completed  January  2002,  the ENDESA Group, a power generation company based in Spain, sold its 87.5 percent holding in Viesgo, a part of its Spanish power generation business, to ENEL, an Italian power company. To account for this structural  change,  historical  emissions  from  the  six  power  plants included in the sale were no longer accounted for in the Endesa GHG inventory and therefore removed from its base year emissions. This recalculation  provides  ENDESA  with  a  complete  and  comparable picture of its historical emissions.

FIGURE 8. Acquisition of a facility that came into existence after the base year was set

<!-- image -->

Company Teta consists of two business units (A and B). In its base year (year one), the company emits 50 tonnes CO 2. In year two, the company undergoes organic growth, leading to an increase in emissions to 30 tonnes CO 2 per business unit, i.e., 60 tonnes CO 2 in total. The base year emissions are not recalculated in this case. At the beginning of year three, Teta acquires a production facility C from another company. Facility C came into existence in year two, its emissions being 15 tonnes CO 2 in year two and 20 tonnes CO 2 in year three. The total emissions of company Teta in year three, including facility C, are therefore 80 tonnes CO . In this acquisition case, the 2 base year emissions of company Teta do not change because the acquired facility C did not exist in year one when the base year of Teta was set. The base year emissions of Teta therefore remain at 50 tonnes CO . Teta (optionally) reports 75 tonnes as the recalculated figure 2 for year two emissions.

## No recalculation for organic growth or decline

Base year emissions and any historic data are not recalculated for organic growth or decline. Organic growth/decline refers to increases or decreases in production output, changes in product mix, and closures and openings of operating units that are owned or controlled by the company. The rationale for this is that organic growth or decline results in a change of emissions to the atmosphere and therefore needs to be counted as an increase or decrease in the company's emissions profile over time.

## NOTES

- 1 Terminology on this topic can be confusing. Base year emissions should be differentiated from the term 'baseline,' which is mostly used in the context of project-based accounting. The term base year focuses on a comparison of emissions over time, while a baseline is a hypothetical scenario for what GHG emissions would have been in the absence of a GHG reduction project or activity.
- 2 For more information on the timing of base year emissions recalculations, see the guidance document 'Base year recalculation methodologies for structural changes' on the GHG Protocol website (www.ghgprotocol.org).

<!-- image -->

G

U

I

D

A

N

C

E

<!-- image -->

## Identifying and Calculating GHG Emissions

<!-- image -->

nce the inventory boundary has been established, companies generally calculate GHG emissions using the following steps:

<!-- image -->

- 1. Identify GHG emissions sources

O

- 2. Select a GHG emissions calculation approach
- 3. Collect activity data and choose emission factors
- 4. Apply calculation tools
- 5. Roll-up GHG emissions data to corporate level.

This chapter describes these steps and the calculation tools developed by the GHG Protocol. The calculation tools are available on the GHG Protocol Initiative website at www.ghgprotocol.org.

To create an accurate account of their emissions, companies have found it useful to divide overall emissions into specific categories. This allows a company to use specifically developed methodologies to accurately calculate the emissions from each sector and source category.

## Identify GHG emissions sources

The first of the five steps in identifying and calculating a company's emissions as outlined in Figure 9 is to categorize the GHG sources within that company's boundaries. GHG emissions typically occur from the following source categories:

- GLYPH&lt;127&gt; Stationary combustion: combustion of fuels in stationary equipment such as boilers, furnaces, burners, turbines, heaters, incinerators, engines, flares, etc.
- GLYPH&lt;127&gt; Mobile combustion: combustion of fuels in transportation devices such as automobiles, trucks, buses, trains, airplanes, boats, ships, barges, vessels, etc.
- GLYPH&lt;127&gt; Process emissions: emissions from physical or chemical processes such as CO 2 from the calcination step in cement manufacturing, CO 2 from catalytic cracking in petrochemical processing, PFC emissions from aluminum smelting, etc.
- GLYPH&lt;127&gt; Fugitive emissions: intentional and unintentional releases such as equipment leaks from joints, seals, packing, gaskets, as well as fugitive emissions from coal piles, wastewater treatment, pits, cooling towers, gas processing facilities, etc.

Every business has processes, products, or services that generate direct and/or indirect emissions from one or more of the above broad source categories. The GHG Protocol calculation tools are organized based on these categories. Appendix D provides an overview of direct and indirect GHG emission sources organized by scopes and industry sectors that may be used as an initial guide to identify major GHG emission sources.

## I D E N T I F Y   S C O P E   1   E M I S S I O N S

As a first step, a company should undertake an exercise to identify its direct emission sources in each of the four source categories listed above. Process emissions are usually only relevant to certain industry sectors like oil and gas, aluminum, cement, etc. Manufacturing companies that generate process emis-

FIGURE 9.

## Steps in identifying and calculating GHG emissions

<!-- image -->

sions and own or control a power production facility will likely have direct emissions from all the main source categories. Office-based organizations may not have any direct GHG emissions except in cases where they own or operate a vehicle, combustion device, or refrigeration and air-conditioning equipment. Often companies are surprised to realize that significant emissions come from sources that are not initially obvious (see United Technologies case study).

## I D E N T I F Y   S C O P E   2   E M I S S I O N S

The next step is to identify indirect emission sources from the consumption of purchased electricity, heat, or steam. Almost all businesses generate indirect emissions due to the purchase of electricity for use in their processes or services.

## I D E N T I F Y   S C O P E   3   E M I S S I O N S

This optional step involves identification of other indirect emissions from a company's upstream and downstream activities as well as emissions associated with outsourced/contract manufacturing, leases, or franchises not included in scope 1 or scope 2.

The inclusion of scope 3 emissions allows businesses to expand their inventory boundary along their value chain and to identify all relevant GHG emissions. This provides a broad overview of various business linkages and possible opportunities for significant GHG emission reductions that may exist upstream or downstream of a company's immediate operations (see chapter 4 for an overview of activities that can generate GHG emissions along a company's value chain).

## Identifying and Calculating GHG Emissions

## Select a calculation approach

Direct measurement of GHG emissions by monitoring concentration and flow rate is not common. More often, emissions may be calculated based on a mass balance or stoichiometric basis specific to a facility or process. However, the most common approach for calculating GHG emissions is through the application of documented emission factors. These factors are calculated ratios relating GHG emissions to a proxy measure of activity at an emissions source. The IPCC guidelines (IPCC, 1996) refer to a hierarchy of calculation approaches and techniques ranging from the application of generic emission factors to direct monitoring.

## Collect activity data and choose emission factors

In many cases, particularly when direct monitoring is either unavailable or prohibitively expensive, accurate emission data can be calculated from fuel use data. Even small users usually know both the amount of fuel consumed and have access to data on the carbon content of the fuel through default carbon content coefficients or through more accurate periodic fuel sampling. Companies should use the most accurate calculation approach available to them and that is appropriate for their reporting context.

## United Technologies Corporation: More than meets the eye

In  1996,  United  Technologies  Corporation  (UTC),  a  global  aerospace and building systems technology corporation, appointed a team to set boundaries for the company's new Natural Resource Conservation, Energy and Water Use Reporting Program. The team focused  on  what  sources  of  energy  should  be  included  in  the program's  annual  report  of  energy  consumption.  The  team decided jet fuel needed to be reported in the annual report; jet fuel was used by a number of UTC divisions for engine and flight hardware testing and for test firing. Although the amount of jet fuel used  in  any  given  year  was  subject  to  wide  variation  due  to changing  test  schedules,  the  total  amount  consumed  in  an average  year  was  believed  to  be  large  and  potentially  small enough to be specifically excluded. However, jet fuel consumption reports proved that initial belief incorrect. Jet fuel has accounted for between 9 and 13 percent of the corporation's total annual use of energy since the program commenced. Had UTC not included the use of jet fuel in annual data collection efforts, a significant emissions source would have been overlooked.

For most small to medium-sized companies and for many larger companies, scope 1 GHG emissions will be calculated based on the purchased quantities of commercial fuels (such as natural gas and heating oil) using published emission factors. Scope 2 GHG emissions will primarily be calculated from metered electricity consumption and supplier-specific, local grid, or other published emission factors. Scope 3 GHG emissions will primarily be calculated from activity data such as fuel use or passenger miles and published or third-party emission factors. In most cases, if source- or facilityspecific emission factors are available, they are preferable to more generic or general emission factors.

Industrial companies may be faced with a wider range of approaches and methodologies. They should seek guidance from the sector-specific guidelines on the GHG Protocol website (if available) or from their industry associations (e.g., International Aluminum Institute, International Iron and Steel Institute, American Petroleum Institute, WBCSD Sustainable Cement Initiative, International Petroleum Industry Environmental Conservation Association).

## Apply calculation tools

This section provides an overview of the GHG calculation tools and guidance available on the GHG Protocol Initiative website (www.ghgprotocol.org). Use of these tools is encouraged as they have been peer reviewed by experts and industry leaders, are regularly updated, and are believed to be the best available. The tools, however, are optional. Companies may substitute their own GHG calculation methods, provided they are more accurate than or are at least consistent with the GHG Protocol Corporate Standards approaches.

There are two main categories of calculation tools:

- GLYPH&lt;127&gt; Cross-sector tools that can be applied to different sectors. These include stationary combustion, mobile combustion, HFC use in refrigeration and air conditioning, and measurement and estimation uncertainty.
- GLYPH&lt;127&gt; Sector-specific tools that are designed to calculate emissions in specific sectors such as aluminum, iron and steel, cement, oil and gas, pulp and paper, officebased organizations.

Most companies will need to use more than one calculation tool to cover all their GHG emission sources. For example, to calculate GHG emissions from an aluminum production facility, the company would use the calculation tools for aluminum production, stationary combustion (for any consumption of purchased electricity, generation of energy on-site, etc), mobile combustion (for transportation of materials and products by train, vehicles employed on-site, employee business travel, etc), and HFC use (for refrigeration, etc). See Table 3 for the full list of tools.

## STRUCTURE OF GHG PROTOCOL CALCULATION TOOLS

The guidance for each calculation tool includes the following sections:

- GLYPH&lt;127&gt; Overview: provides an overview of the purpose and content of the tool, the calculation method used in the tool, and a process description
- GLYPH&lt;127&gt; Choosing activity data and emission factors: provides sector-specific good practice guidance and references for default emission factors
- GLYPH&lt;127&gt; Calculation methods: describes different calculation methods depending on the availability of site-specific activity data and emission factors
- GLYPH&lt;127&gt; Quality control: provides good practice guidance

Each of the cross-sector and sector-specific calculation tools on the website share a common format and include step-by-step guidance on measuring and calculating emissions data. Each tool consists of a guidance section and automated worksheets with explanations on how to use them.

- GLYPH&lt;127&gt; Internal reporting and documentation: provides guidance on internal documentation to support emissions calculations.

## ChevronTexaco: The SANGEA TM accounting and reporting system

ChevronTexaco, a global energy company, has developed and implemented  energy  utilization  and  GHG  estimation  and  reporting software consistent with the GHG Protocol Corporate Standard . This software is available free of charge and makes it easier, more accurate, and less costly to institute a corporate-wide GHG accounting and reporting system in the oil and gas sector. Called the SANGEA ™ Energy  and  Greenhouse  Gas  Emissions  Estimating  System,  it  is currently in use at all ChevronTexaco facilities worldwide, comprising more than 70 reporting entities.

The  system  is  an  auditable,  Excel-and-Visual-Basic-based  tool  for estimating GHG emissions and energy utilization. It streamlines corporate-level data consolidation by allowing the inventory coordinator at each facility to configure a spreadsheet, enter monthly data, and send quarterly reports to a centralized database.

In practice, the SANGEA ™ system employs a variety of strategies to ensure  consistent  calculation  methods  and  ease  company-wide standardization:

- ·  Spreadsheet  configuration  and material  input  information  for specific facilities can be carried over from year to year. Inventory specialists can easily modify configurations as a facility changes (due to new construction, retirement of units, etc.).
- ·  Updates  are  efficient.  Methodologies  for  estimating  emissions, emission factors, and calculation equations are stored centrally in

the  software,  easing  updates  when  methodologies  or  default factors change. Updates to this central reference are automatically applied  to  the  existing configuration  and  input  data. Updates  will  mirror  the  timing  and  content  of  updates  to  the American Petroleum Institute Compendium of GHG emission estimating methodologies.

- ·  The system is auditable. The software requires detailed audit trail information  on  data  inputs  and  system  users.  There  is  documented accountability of who made any change to the system.
- ·  Using  one  system  saves  money.  Significant  cost  savings  are achieved by using the same system in all facilities, as compared to conventional, disparate systems.

ChevronTexaco's one-off investment in developing the SANGEA ™ system has already shown results: A rough cost estimate for ChevronTexaco's Richmond,  California,  refinery  indicates  savings  of  more  than  70 percent  over  a  five-year  period  compared  with  the  conventional approaches based on locally developed reporting systems. SANGEA ™ is expected  to  reduce  the  long  term  expenses  of  maintaining  a  legacy system and hiring independent consultants. Employing a combination of  the GHG  Protocol  Corporate  Standard s  and  SANGEA ™ calculation software  to  replace  a  diverse  and  confusing  set  of  accounting  and reporting templates yields significant efficiency and accuracy gains, and allows the company to more accurately manage GHG emissions and institute specific emissions improvements.

## Identifying and Calculating GHG Emissions

TABLE 3.  Overview of GHG calculation tools available on the GHG Protocol website

|                        | C A L C U L A T I O N T O O L S                          | M A I N F E A T U R E S .                                                                                                                                                                                                                                                                                         |
|------------------------|----------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| CROSS-SECTOR T OOLS    | Stationary Combustion                                    | GLYPH<127> Calculates direct and indirect CO 2 emissions from fuel combustion in stationary equipment GLYPH<127> Provides two options for allocating GHG emissions from a co-generation facility GLYPH<127> Provides default fuel and national average electricity emission factors                               |
| CROSS-SECTOR T OOLS    | Mobile Combustion                                        | GLYPH<127> Calculates direct and indirect CO 2 emissions from fuel combustion in mobile sources GLYPH<127> Provides calculations and emission factors for road, air, water, and rail transport                                                                                                                    |
| CROSS-SECTOR T OOLS    | HFC from Air Conditioning and Refrigeration Use          | GLYPH<127> Calculates direct HFC emissions during manufacture, use and disposal of refrigeration and air- conditioning equipment in commercial applications GLYPH<127> Provides three calculation methodologies: a sales-based approach, a life cycle stage based approach, and an emission factor based approach |
| CROSS-SECTOR T OOLS    | Measurement and Estimation Uncertainty for GHG Emissions | GLYPH<127> Introduces the fundamentals of uncertainty analysis and quantification GLYPH<127> Calculates statistical parameter uncertainties due to random errors related to calculation of GHG emissions GLYPH<127> Automates the aggregation steps involved in developing a basic uncertainty assessment for GHG |
| SECTOR-SPECIFIC T OOLS | Aluminum and other non- Ferrous Metals Production        | GLYPH<127> Calculates direct GHG emissions from aluminum production (CO 2 from anode oxidation, PFC emis- sions from the 'anode effect,' and SF 6 used in non-ferrous metals production as a cover gas)                                                                                                           |
| SECTOR-SPECIFIC T OOLS | Iron and Steel                                           | GLYPH<127> Calculates direct GHG emissions (CO 2 ) from oxidation of the reducing agent, from the calcination of the flux used in steel production, and from the removal of carbon from the iron ore and scrap steel used                                                                                         |
| SECTOR-SPECIFIC T OOLS | Nitric Acid Manufacture                                  | GLYPH<127> Calculates direct GHG emissions (N 2 O) from the production of nitric acid                                                                                                                                                                                                                             |
| SECTOR-SPECIFIC T OOLS | Ammonia Manufacture                                      | GLYPH<127> Calculates direct GHG emissions (CO 2 ) from ammonia production. This is for the removal of carbon from the feedstock stream only; combustion emissions are calculated with the stationary combustion module                                                                                           |
| SECTOR-SPECIFIC T OOLS | Adipic Acid Manufacture                                  | GLYPH<127> Calculates direct GHG emissions (N 2 O) from adipic acid production                                                                                                                                                                                                                                    |
| SECTOR-SPECIFIC T OOLS | Cement                                                   | GLYPH<127> Calculates direct CO 2 emissions from the calcination process in cement manufacturing (WBCSD tool also calculates combustion emissions) GLYPH<127> Provides two calculation methodologies: the cement-based approach and the clinker-based approach                                                    |
| SECTOR-SPECIFIC T OOLS | Lime                                                     | GLYPH<127> Calculates direct GHG emissions from lime manufacturing (CO 2 from the calcination process)                                                                                                                                                                                                            |
| SECTOR-SPECIFIC T OOLS | HFC-23 from HCFC-22 Production                           | GLYPH<127> Calculates direct HFC-23 emissions from production of HCFC-22                                                                                                                                                                                                                                          |
| SECTOR-SPECIFIC T OOLS | Pulp and Paper                                           | GLYPH<127> Calculates direct CO 2 , CH 4 , and N 2 O emissions from production of pulp and paper. This includes calculation of direct and indirect CO 2 emissions from combustion of fossil fuels, bio-fuels, and waste products in stationary equipment                                                          |
| SECTOR-SPECIFIC T OOLS | Semi-Conductor Wafer Production                          | GLYPH<127> Calculates PFC emission from the production of semi-conductor wafers                                                                                                                                                                                                                                   |
| SECTOR-SPECIFIC T OOLS | Guide for Small Office-Based Organizations               | GLYPH<127> Calculates direct CO 2 emissions from fuel use, indirect CO 2 emissions from electricity consumption, and other indirect CO 2 emissions from business travel and commuting                                                                                                                             |

In the automated worksheet section, it is only necessary to insert activity data into the worksheets and to select an appropriate emission factor or factors. Default emission factors are provided for the sectors covered, but it is also possible to insert customized emission factors that are more representative of the reporting company's operations. The emissions of each GHG (CO , CH , N O, etc.) 2 4 2 are calculated separately and then converted to CO 2 equivalents on the basis of their global warming potential.

Some tools, such as the iron and steel sector tool and the HFC cross-sector tool, take a tiered approach, offering a choice between a simple and a more advanced calculation methodology. The more advanced methods are expected to produce more accurate emissions estimates but usually require collection of more detailed data and a more thorough understanding of a company's technologies.

## Roll-up GHG emissions data to corporate level

To report a corporation's total GHG emissions, companies will usually need to gather and summarize data from multiple facilities, possibly in different countries and business divisions. It is important to plan this process carefully to minimize the reporting burden, reduce the risk of errors that might occur while compiling data, and ensure that all facilities are collecting information on an approved, consistent basis. Ideally, corporations will integrate GHG reporting with their existing reporting tools and processes, and take advantage of any relevant data already collected and reported by facilities to division or corporate offices, regulators or other stakeholders.

The tools and processes chosen to report data will depend upon the information and communication infrastructure already in place (i.e., how easy is it to include new data categories in corporate databases). It will also depend upon the amount of detail that corporate headquarters wishes to be reported from facilities. Data collection and management tools could include:

- GLYPH&lt;127&gt; Secure databases available over the company intranet or internet, for direct data entry by facilities
- GLYPH&lt;127&gt; Spreadsheet templates filled out and e-mailed to a corporate or division office, where data is processed further
- GLYPH&lt;127&gt; Paper reporting forms faxed to a corporate or division office where data is re-entered in a corporate database. However, this method may increase the likelihood of errors if there are not sufficient checks in place to ensure the accurate transfer of the data.

## BP: A standardized system for internal reporting of GHGs

BP, a global energy company, has been collecting GHG data from the different parts of its operations since 1997 and has consolidated its internal reporting processes into one central database system.  The  responsibility  for  reporting  environmental  emissions lies with about 320 individual BP facilities and business departments, which are termed 'reporting units.' All reporting units have to complete a standard Excel pro-forma spreadsheet every quarter, stating  actual  emissions  for  the  preceding  three  months  and updates to forecasts for the current year and the next two years. In addition,  reporting  units  are  asked  to  account  for  all  significant variances, including sustainable reductions. The reporting units all use the same BP GHG Reporting Guidelines 'Protocol' (BP, 2000) for quantifying their emissions of carbon dioxide and methane.

All  pro-forma  spreadsheets  are  e-mailed  automatically  by  the central database to the reporting units, and the completed e-mail returns are uploaded into the database by a corporate team, who check the quality of the incoming data. The data are then compiled, by the end of the month following each quarter end, to provide the total  emission  inventory  and  forecasts  for  analysis  against  BP's GHG target. Finally, the inventory is reviewed by a team of independent external auditors to provide assurance on the quality and accuracy of the data.

For internal reporting up to the corporate level, it is recommended that standardized reporting formats be used to ensure that data received from different business units and facilities is comparable, and that internal reporting rules are observed (see BP case study). Standardized formats can significantly reduce the risk of errors.

<!-- image -->

## Approaches for rolling up GHG emissions data to corporate level

There are two basic approaches for gathering data on GHG emissions from a corporation's facilities (Figure 10):

- GLYPH&lt;127&gt; Centralized: individual facilities report activity/fuel use data (such as quantity of fuel used) to the corporate level, where GHG emissions are calculated.
- GLYPH&lt;127&gt; Decentralized: individual facilities collect activity/fuel use data, directly calculate their GHG emissions using approved methods, and report this data to the corporate level.

## FIGURE 10. Approaches to gathering data

<!-- image -->

The difference between these two approaches is in where the emissions calculations occur (i.e., where activity data is multiplied by the appropriate emission factors) and in what type of quality management procedures must be put in place at each level of the corporation. Facility-level staff is generally responsible for initial data collection under both approaches.

Under both approaches, staff at corporate and lower levels of consolidation should take care to identify and exclude any scope 2 or 3 emissions that are also accounted for as scope 1 emissions by other facilities, business units, or companies included in the emissions inventory consolidation.

## CENTRALIZED APPROACH:

## I N D I V I D U A L   FA C I L I T I E S   R E P O R T   A C T I V I T Y / F U E L   U S E   D AT A

This approach may be particularly suitable for officebased organizations. Requesting that facilities report their activity/fuel use data may be the preferred option if:

- GLYPH&lt;127&gt; The staff at the corporate or division level can calculate emissions data in a straightforward manner on the basis of activity/fuel use data; and
- GLYPH&lt;127&gt; Emissions calculations are standard across a number of facilities.

## DECENTRALIZED APPROACH:

## I N D I V I D U A L   FA C I L I T I E S   C A L C U L AT E   G H G   E M I S S I O N S   D AT A

Asking facilities to calculate GHG emissions themselves will help to increase their awareness and understanding of the issue. However, it may also lead to resistance, increased training needs, an increase in calculation errors, and a greater need for auditing of calculations. Requesting that facilities calculate GHG emissions themselves may be the preferred option if:

- GLYPH&lt;127&gt; GHG emission calculations require detailed knowledge of the kind of equipment being used at facilities;
- GLYPH&lt;127&gt; GHG emission calculation methods vary across a number of facilities;
- GLYPH&lt;127&gt; Process emissions (in contrast to emissions from burning fossil fuels) make up an important share of total GHG emissions;
- GLYPH&lt;127&gt; Resources are available to train facility staff to conduct these calculations and to audit them;
- GLYPH&lt;127&gt; A user-friendly tool is available to simplify the calculation and reporting task for facility-level staff; or
- GLYPH&lt;127&gt; Local regulations require reporting of GHG emissions at a facility level.

The choice of collection approach depends on the needs and characteristics of the reporting company. For example, United Technologies Corporation uses the centralized approach, leaving the choice of emission factors and calculations to corporate staff, while BP uses the decentralized approach and follows up with audits to ensure calculations are correct, documented, and follow approved methods. To maximize accuracy and minimize reporting burdens, some companies use a combination of the two approaches. Complex facilities with process emissions calculate their emissions at the facility level, while facilities with uniform emissions from standard sources only report fuel use, electricity consumption, and travel activity. The corporate database or reporting tool then calculates total GHG emissions for each of these standard activities.

The two approaches are not mutually exclusive and should produce the same result. Thus companies desiring a consistency check on facility-level calculations can follow both approaches and compare the results. Even when facilities calculate their own GHG emissions, corporate staff may still wish to gather activity/fuel use data to double-check calculations and explore opportunities for emissions reductions. These

data should be available and transparent to staff at all corporate levels. Corporate staff should also verify that facility-reported data are based on well defined, consistent, and approved inventory boundaries, reporting periods, calculation methodologies, etc.

## Common guidance on reporting to corporate level

Reports from facility level to corporate or division offices should include all relevant information as specified in chapter 9. Some reporting categories are common to both the centralized and decentralized approaches and should be reported by facilities to their corporate offices. These include:

- GLYPH&lt;127&gt; A brief description of the emission sources
- GLYPH&lt;127&gt; A list and justification of specific exclusion or inclusion of sources
- GLYPH&lt;127&gt; Comparative information from previous years
- GLYPH&lt;127&gt; The reporting period covered
- GLYPH&lt;127&gt; Any trends evident in the data
- GLYPH&lt;127&gt; Progress towards any business targets
- GLYPH&lt;127&gt; A discussion of uncertainties in activity/fuel use or emissions data reported, their likely cause, and recommendations for how data can be improved
- GLYPH&lt;127&gt; A description of events and changes that have an impact on reported data (acquisitions, divestitures, closures, technology upgrades, changes of reporting boundaries or calculation methodologies applied, etc.).

## REPORTING FOR THE CENTRALIZED APPROACH

In addition to the activity/fuel use data and aforementioned common categories of reporting data, facilities following the centralized approach by reporting activity/fuel use data to the corporate level should also report the following:

- GLYPH&lt;127&gt; Activity data for freight and passenger transport activities (e.g., freight transport in tonne-kilometers)
- GLYPH&lt;127&gt; Activity data for process emissions (e.g., tonnes of fertilizer produced, tonnes of waste in landfills)
- GLYPH&lt;127&gt; Clear records of any calculations undertaken to derive activity/fuel use data
- GLYPH&lt;127&gt; Local emission factors necessary to translate fuel use and/or electricity consumption into CO 2 emissions.

<!-- image -->

## REPORTING FOR THE DECENTRALIZED APPROACH

In addition to the GHG emissions data and aforementioned common categories of reporting data, individual facilities following the decentralized approach by reporting calculated GHG emissions to the corporate level should also report the following:

- GLYPH&lt;127&gt; A description of GHG calculation methodologies and any changes made to those methodologies relative to previous reporting periods
- GLYPH&lt;127&gt; Ratio indicators (see chapter 9)
- GLYPH&lt;127&gt; Details on any data references used for the calculations, in particular information on emission factors used.

Clear records of calculations undertaken to derive emissions data should be kept for any future internal or external verification.

<!-- image -->

ompanies have different reasons for managing the quality of their GHG emissions inventory, ranging from identifying opportunities for improvement  to  stakeholder  demand  to  preparation  for  regulation.  The GHG Protocol Corporate Standard recognizes that these reasons are a function of a company's goals and its expectations for the future. A company's goals for and vision of the evolution of the GHG emissions issue should guide the design of its corporate inventory, the implementation of a quality management system, and the treatment of uncertainty within its inventory. C

A corporate GHG inventory program includes all institutional, managerial, and technical arrangements made for the collection of data, preparation of the inventory, and implementation of steps to manage the quality of the inventory. 1 The guidance in this chapter is intended to help companies develop and implement a quality management system for their inventory.

Given an uncertain future, high quality information will have greater value and more uses, while low quality information may have little or no value or use and may even incur penalties. For example, a company may currently be focusing on a voluntary GHG program but also want its inventory data to meet the anticipated requirements of a future when emissions may have monetary value. A quality management system is essential to ensuring that an inventory continues to meet the principles of the GHG Protocol Corporate Standard and anticipates the requirements of future GHG emissions programs.

Even if a company is not anticipating a future regulatory mechanism, internal and external stakeholders will demand high quality inventory information. Therefore, the implementation of some type of quality management system is important. However, the GHG Protocol Corporate Standard recognizes that companies do not have unlimited resources, and, unlike financial accounting, corporate GHG inventories involve a level of scientific and engineering complexity. Therefore, companies should develop their inventory program and quality management system as a cumulative effort in keeping with their resources, the broader evolution of policy, and their own corporate vision.

A quality management system provides a systematic process for preventing and correcting errors, and identifies areas where investments will likely lead to the greatest improvement in overall inventory quality. However, the primary objective of quality management is ensuring the credibility of a company's GHG inventory information. The first step towards achieving this objective is defining inventory quality.

## Defining inventory quality

The GHG Protocol Corporate Standard outlines five accounting principles that set an implicit standard for the faithful representation of a company's GHG emission through its technical, accounting, and reporting efforts (see chapter 1). Putting these principles into practice will result in a credible and unbiased treatment and presentation of issues and data. For a company to follow these principles, quality management needs to be an integral part of its corporate inventory program. The goal of a quality management system is to ensure that these principles are put into practice.

## KPMG:  The value of integrating GHG management with existing systems

KPMG, a global services company, found that a key factor in the derivation  of  reliable,  verifiable  GHG  data  is  the  integration  of GHG data management and reporting mechanisms with companies'  core  operational  management  and  assurance  processes. This is because:

- · It  is  more  efficient  to  widen  the  scope  of  existing  embedded management and assurance processes than to develop a separate function responsible for generating and reporting GHG information.
- · As  GHG  information  becomes  increasingly  monetized,  it  will attract the same attention as other key performance indicators of  businesses.  Therefore,  management  will  need  to  ensure adequate procedures are in place to report reliable data. These procedures can most effectively be implemented by functions within  the  organization  that  oversee  corporate  governance, internal audit, IT, and company reporting.

Another  factor  that  is  often  not  given  sufficient  emphasis  is training of personnel and communication of GHG objectives. Data generation  and  reporting  systems  are  only  as  reliable  as  the people  who  operate  them.  Many  well-designed  systems  fail because  the  precise  reporting  needs  of  the  company  are  not adequately  explained  to  the  people  who  have  to  interpret  a reporting standard and calculation tools. Given the complexity of accounting boundaries and an element of subjectivity that must accompany source inclusion and equity share, inconsistent interpretation  of  reporting  requirements  is  a  real  risk.  It  is  also important  that  those  responsible  for  supplying  input  data  are aware of its use. The only way to minimize this risk is through clear communication, adequate training and knowledge sharing.

## Managing Inventory Quality

## An inventory program framework

A practical framework is needed to help companies conceptualize and design a quality management system and to help plan for future improvements. This framework focuses on the following institutional, managerial, and technical components of an inventory (Figure 11):

METHODS: These are the technical aspects of inventory preparation. Companies should select or develop methodologies for estimating emissions that accurately represent the characteristics of their source categories. The GHG Protocol provides many default methods and calculation tools to help with this effort. The design of an inventory program and quality management system should provide for the selection, application, and updating of inventory methodologies as new research becomes available, changes are made to business operations, or the importance of inventory reporting is elevated.

DATA: This is the basic information on activity levels, emission factors, processes, and operations. Although methodologies need to be appropriately rigorous and detailed, data quality is more important. No methodology can compensate for poor quality input data. The design of a corporate inventory program should facilitate the collection of high quality inventory data and the maintenance and improvement of collection procedures.

I N V E N T O R Y   P R O C E S S E S   A N D   S Y S T E M S : These are the institutional, managerial, and technical procedures for preparing GHG inventories. They include the team and processes charged with the goal of producing a high quality inventory. To streamline GHG inventory quality management, these processes and systems may be integrated, where appropriate, with other corporate processes related to quality.

DOCUMENTATION: This is the record of methods, data, processes, systems, assumptions, and estimates used to prepare an inventory. It includes everything employees need to prepare and improve a company's inventory. Since estimating GHG emissions is inherently technical (involving engineering and science), high quality, transparent documentation is particularly important to credibility. If information is not credible, or fails to be effectively communicated to either internal or external stakeholders, it will not have value.

Companies should seek to ensure the quality of these components at every level of their inventory design.

## Implementing an inventory quality management system

A quality management system for a company's inventory program should address all four of the inventory components described above. To implement the system, a company should take the following steps:

- 1. Establish an inventory quality team. This team should be responsible for implementing a quality management system, and continually improving inventory quality. The team or manager should coordinate interactions between relevant business units, facilities and external entities such as government agency programs, research institutions, verifiers, or consulting firms.

FIGURE 11: Inventory quality management system

<!-- image -->

- 2. Develop a quality management plan. This plan describes the steps a company is taking to implement its quality management system, which should be incorporated into the design of its inventory program from the beginning, although further rigor and coverage of certain procedures may be phased in over multiple years. The plan should include procedures for all organizational levels and inventory development processes-from initial data collection to final reporting of accounts. For efficiency and comprehensiveness, companies should integrate (and extend as appropriate) existing quality systems to cover GHG management and reporting, such as any

## TABLE 4.  Generic quality management measures

## DATA GATHERING, INPUT, AND HANDLING ACTIVITIES

- GLYPH&lt;127&gt; Check a sample of input data for transcription errors
- GLYPH&lt;127&gt; Identify spreadsheet modifications that could provide additional controls or checks on quality
- GLYPH&lt;127&gt; Ensure that adequate version control procedures for electronic files have been implemented
- GLYPH&lt;127&gt; Others

## D A T A   D O C U M E N T A T I O N

- GLYPH&lt;127&gt; Confirm that bibliographical data references are included in spreadsheets for all primary data
- GLYPH&lt;127&gt; Check that copies of cited references have been archived
- GLYPH&lt;127&gt; Check that assumptions and criteria for selection of boundaries, base years, methods, activity data, emission factors, and other parameters are documented
- GLYPH&lt;127&gt; Check that changes in data or methodology are documented
- GLYPH&lt;127&gt; Others

## C A L C U L A T I N G   E M I S S I O N S   A N D   C H E C K I N G   C A L C U L A T I O N S

- GLYPH&lt;127&gt; Check whether emission units, parameters, and conversion factors are appropriately labeled
- GLYPH&lt;127&gt; Check if units are properly labeled and correctly carried through from beginning to end of calculations
- GLYPH&lt;127&gt; Check that conversion factors are correct
- GLYPH&lt;127&gt; Check the data processing steps (e.g., equations) in the spreadsheets
- GLYPH&lt;127&gt; Check that spreadsheet input data and calculated data are clearly differentiated
- GLYPH&lt;127&gt; Check a representative sample of calculations, by hand or electronically
- GLYPH&lt;127&gt; Check some calculations with abbreviated calculations (i.e., back of the envelope calculations)
- GLYPH&lt;127&gt; Check the aggregation of data across source categories, business units, etc.
- GLYPH&lt;127&gt; Check consistency of time series inputs and calculations
- GLYPH&lt;127&gt; Others

ISO procedures. To ensure accuracy, the bulk of the plan should focus on practical measures for implementing the quality management system, as described in steps three and four.

- 3. Perform generic quality checks. These apply to data and processes across the entire inventory, focusing on appropriately rigorous quality checks on data handling, documentation, and emission calculation activities (e.g., ensuring that correct unit conversions are used). Guidance on quality checking procedures is provided in the section on implementation below (see table 4).

U

I

D

A

N

C

E

- 4. Perform source-category-specific quality checks. This includes more rigorous investigations into the appropriate application of boundaries, recalculation procedures, and adherence to accounting and reporting principles for specific source categories, as well as the quality of the data input used (e.g., whether electricity bills or meter readings are the best source of consumption data) and a qualitative description of the major causes of uncertainty in the data. The information from these investigations can also be used to support a quantitative assessment of uncertainty. Guidance on these investigations is provided in the section on implementation below.
- 5. Review final inventory estimates and reports. After the inventory is completed, an internal technical review should focus on its engineering, scientific, and other technical aspects. Subsequently, an internal managerial review should focus on securing official corporate approval of and support for the inventory.  A third type of review involving experts external to the company's inventory program is addressed in chapter 10.
- 6. Institutionalize formal feedback loops. The results of the reviews in step five, as well as the results of every other component of a company's quality management system, should be fed back via formal feedback procedures to the person or team identified in step one. Errors should be corrected and improvements implemented based on this feedback.
- 7. Establish reporting, documentation, and archiving procedures. The system should contain record keeping procedures that specify what information will be documented for internal purposes, how that information should be archived, and what information is to be reported for external stakeholders. Like internal and external reviews, these record keeping procedures include formal feedback mechanisms.

A company's quality management system and overall inventory program should be treated as evolving, in keeping with a company's reasons for preparing an inventory. The plan should address the company's strategy for a multi-year implementation (i.e., recognize that inventories are a long-term effort), including steps to ensure that all quality control findings from previous years are adequately addressed.

## Practical measures for implementation

Although principles and broad program design guidelines are important, any guidance on quality management would be incomplete without a discussion of practical inventory quality measures. A company should implement these measures at multiple levels within the company, from the point of primary data collection to the final corporate inventory approval process. It is important to implement these measures at points in the inventory program where errors are mostly likely to occur, such as the initial data collection phase and during calculation and data aggregation. While corporate level inventory quality may initially be emphasized, it is important to ensure quality measures are implemented at all levels of disaggregation (e.g., facility, process, geographical, according to a particular scope, etc) to be better prepared for GHG markets or regulatory rules in the future.

Companies also need to ensure the quality of their historical emission estimates and trend data. They can achieve this by employing inventory quality measures to minimize biases that can arise from changes in the characteristics of the data or methods used to calculate historical emission estimates, and by following the standards and guidance of chapter 5.

The third step of a quality management system, as described above, is to implement generic quality checking measures. These measures apply to all source categories and all levels of inventory preparation. Table 4 provides a sample list of such measures.

The fourth step of a quality management system is source category-specific data quality investigations. The information gathered from these investigations can also be used for the quantitative and qualitative assessment of data uncertainty (see section on uncertainty). Addressed below are the types of source-specific quality measures that can be employed for emission factors, activity data, and emission estimates.

<!-- image -->

## EMISSION FACTORS AND OTHER PARAMETERS

For a particular source category, emissions calculations will generally rely on emission factors and other parameters (e.g., utilization factors, oxidation rates, methane conversion factors). 2 These factors and parameters may be published or default factors, based on companyspecific data, site-specific data, or direct emission or other measurements. For fuel consumption, published emission factors based on fuel energy content are generally more accurate than those based on mass or volume, except when mass or volume based factors have been measured at the company- or site-specific level. Quality investigations need to assess the representativeness and applicability of emission factors and other parameters to the specific characteristics of a company. Differences between measured and default values need to be qualitatively explained and justified based upon the company's operational characteristics.

## ACTIVITY DATA

The collection of high quality activity data will often be the most significant limitation for corporate GHG inventories. Therefore, establishing robust data collection procedures needs to be a priority in the design of any company's inventory program. The following are useful measures for ensuring the quality of activity data:

- GLYPH&lt;127&gt; Develop data collection procedures that allow the same data to be efficiently collected in future years.
- GLYPH&lt;127&gt; Convert fuel consumption data to energy units before applying carbon content emission factors, which may be better correlated to a fuel's energy content than its mass.
- GLYPH&lt;127&gt; Compare current year data with historical trends. If data do not exhibit relatively consistent changes from year to year then the causes for these patterns should be investigated (e.g., changes of over 10 percent from year to year may warrant further investigation).
- GLYPH&lt;127&gt; Compare activity data from multiple reference sources (e.g., government survey data or data compiled by trade associations) with corporate data when possible. Such checks can ensure that consistent data is being reported to all parties. Data can also be compared among facilities within a company.

## Interface: Integration of emissions and business data systems

Interface, Inc., is the world's largest manufacturer of carpet tiles and upholstery fabrics for commercial interiors. The company has established an environmental data system that mirrors its corporate financial data reporting. The Interface EcoMetrics system is designed to provide activity and material flow data from business units  in  a  number  of  countries  (the  United  States,  Canada, Australia, the United Kingdom, Thailand and throughout Europe) and provides metrics for measuring progress on environmental issues such as GHG emissions. Using company-wide accounting guidelines  and  standards,  energy  and  material  input  data  are reported to a central database each quarter and made available to  sustainability  personnel.  These  data  are  the  foundation  of Interface's annual inventory and enable data comparison over time in the pursuit of improved quality.

Basing  emissions  data  systems  on  financial  reporting  helps Interface improve its data quality. Just as financial data need to be  documented  and  defensible,  Interface's  emissions  data  are held  to  standards  that  promote  an  increasingly  transparent, accurate, and high-quality inventory. Integrating its financial and emissions  data  systems  has  made  Interface's  GHG  accounting and  reporting  more  useful  as  it  strives  to  be  a  'completely sustainable company' by 2020.

- GLYPH&lt;127&gt; Investigate activity data that is generated for purposes other than preparing a GHG inventory. In doing so, companies will need to check the applicability of this data to inventory purposes, including completeness, consistency with the source category definition, and consistency with the emission factors used. For example, data from different facilities may be examined for inconsistent measurement techniques, operating conditions, or technologies. Quality control measures (e.g., ISO) may have already been conducted during the data's original preparation. These measures can be integrated with the company's inventory quality management system.
- GLYPH&lt;127&gt; Check that base year recalculation procedures have been followed consistently and correctly (see chapter 5).
- GLYPH&lt;127&gt; Check that operational and organizational boundary decisions have been applied correctly and consistently to the collection of activity data (see chapters 3 and 4).

## Managing Inventory Quality

- GLYPH&lt;127&gt; Investigate whether biases or other characteristics that could affect data quality have been previously identified (e.g., by communicating with experts at a particular facility or elsewhere). For example, a bias could be the unintentional exclusion of operations at smaller facilities or data that do not correspond exactly with the company's organizational boundaries.
- GLYPH&lt;127&gt; Extend quality management measures to cover any additional data (sales, production, etc.) used to estimate emission intensities or other ratios.

## EMISSION ESTIMATES

Estimated emissions for a source category can be compared with historical data or other estimates to ensure they fall within a reasonable range. Potentially unreasonable estimates provide cause for checking emission factors or activity data and determining whether changes in methodology, market forces, or other events are sufficient reasons for the change. In situations where actual emission monitoring occurs (e.g., power plant CO 2 emissions), the data from monitors can be compared with calculated emissions using activity data and emission factors.

If any of the above emission factor, activity data, emission estimate, or other parameter checks indicate a problem, more detailed investigations into the accuracy of the data or appropriateness of the methods may be required. These more detailed investigations can also be utilized to better assess the quality of data. One potential measure of data quality is a quantitative and qualitative assessment of their uncertainty.

## Vauxhall Motors: The importance of accuracy checks

The  experience  of  the  U.K.  automotive  manufacturer  Vauxhal Motors  illustrates  the  importance  of  attention  to  detail  in setting up GHG information collection systems. The company wished  to  calculate  GHG  emissions  from  staff  air  travel. However,  when  determining  the  impact  of  flight  travel,  it  is important to make sure that the round trip distance is used when calculating emissions. Fortunately, Vauxhall's review of its  assumptions and calculation methodologies revealed this fact  and  avoided  reporting  emissions  that  were  50  percent lower than the actual value.

## Inventory quality and inventory uncertainty

Preparing a GHG inventory is inherently both an accounting and a scientific exercise. Most applications for company-level emissions and removal estimates require that these data be reported in a format similar to financial accounting data. In financial accounting, it is standard practice to report individual point estimates (i.e., single value versus a range of possible values). In contrast, the standard practice for most scientific studies of GHG and other emissions is to report quantitative data with estimated error bounds (i.e., uncertainty). Just like financial figures in a profit and loss or bank account statement, point estimates in a corporate emission inventory have obvious uses. However, how would or should the addition of some quantitative measure of uncertainty to an emission inventory be used?

In an ideal situation, in which a company had perfect quantitative information on the uncertainty of its emission estimates at all levels, the primary use of this information would almost certainly be comparative. Such comparisons might be made across companies, across business units, across source categories, or through time. In this situation, inventory estimates could even be rated or discounted based on their quality before they were used, with uncertainty being the objective quantitative metric for quality. Unfortunately, such objective uncertainty estimates rarely exist.

## T Y P E S   O F   U N C E R T A I N T I E S

Uncertainties associated with GHG inventories can be broadly categorized into scientific uncertainty and estimation uncertainty . Scientific uncertainty arises when the science of the actual emission and/or removal process is not completely understood. For example, many direct and indirect factors associated with global warming potential (GWP) values that are used to combine emission estimates for various GHGs involve significant scientific uncertainty. Analyzing and quantifying such scientific uncertainty is extremely problematic and is likely to be beyond the capacity of most company inventory programs.

Estimation uncertainty arises any time GHG emissions are quantified. Therefore all emissions or removal estimates are associated with estimation uncertainty. Estimation uncertainty can be further classified into two types: model uncertainty and parameter uncertainty. 3

Model uncertainty refers to the uncertainty associated with the mathematical equations (i.e., models) used to characterize the relationships between various parameters and emission processes. For example, model uncertainty may arise either due to the use of an incorrect mathematical model or inappropriate input into the model. As with scientific uncertainty, estimating model uncertainty is likely to be beyond most company's inventory efforts; however, some companies may wish to utilize their unique scientific and engineering expertise to evaluate the uncertainty in their emission estimation models.

Parameter uncertainty refers to the uncertainty associated with quantifying the parameters used as inputs (e.g., activity data and emission factors) into estimation models. Parameter uncertainties can be evaluated through statistical analysis, measurement equipment precision determinations, and expert judgment. Quantifying parameter uncertainties and then estimating source category uncertainties based on these parameter uncertainties will be the primary focus of companies that choose to investigate the uncertainty in their emission inventories.

## L I M I T A T I O N S   O F   U N C E R T A I N T Y   E S T I M A T E S

Given that only parameter uncertainties are within the feasible scope of most companies, uncertainty estimates for corporate GHG inventories will, of necessity, be imperfect. Complete and robust sample data will not always be available to assess the statistical uncertainty 4 in every parameter. For most parameters (e.g., liters of gasoline purchased or tonnes of limestone consumed), only a single data point may be available. In some cases, companies can utilize instrument precision or calibration information to inform their assessment of statistical uncertainty. However, to quantify some of the systematic uncertainties 5 associated with parameters and to supplement statistical

<!-- image -->

uncertainty estimates, companies will usually have to rely on expert judgment. 6 The problem with expert judgment, though, is that it is difficult to obtain in a comparable (i.e., unbiased) and consistent manner across parameters, source categories, or companies.

## Managing Inventory Quality

For these reasons, almost all comprehensive estimates of uncertainty for GHG inventories will be not only imperfect but also have a subjective component and, despite the most thorough efforts, are themselves considered highly uncertain. In most cases, uncertainty estimates cannot be interpreted as an objective measure of quality. Nor can they be used to compare the quality of emission estimates between source categories or companies.

Exceptions to this include the following cases in which it is assumed that either statistical or instrument precision data are available to objectively estimate each parameter's statistical uncertainty (i.e., expert judgment is not needed):

- GLYPH&lt;127&gt; When two operationally similar facilities use identical emission estimation methodologies, the differences in scientific or model uncertainties can, for the most part, be ignored. Then quantified estimates of statistical uncertainty can be treated as being comparable between facilities. This type of comparability is what is aimed for in some trading programs that prescribe specific monitoring, estimation, and measurement requirements. However, even in this situation, the degree of comparability depends on the flexibility that participants are given for estimating emissions, the homogeneity across facilities, as well as the level of enforcement and review of the methodologies used.
- GLYPH&lt;127&gt; Similarly, when a single facility uses the same estimation methodology each year, the systematic parameter uncertainties-in addition to scientific and model uncertainties-in a source's emission estimates for two years are, for the most part, identical. 7 Because the systematic parameter uncertainties then cancel out, the uncertainty in an emission trend (e.g., the difference between the estimates for two years) is generally less than the uncertainty in total emissions for a single year. In such a situation, quantified uncertainty estimates can be treated as being comparable over time and used to track relative changes in the quality of a facility's emission estimates for that source category. Such estimates of uncertainty in emission trends can also be used as a guide to setting a facility's emissions reduction target. Trend uncertainty estimates are likely to be less useful for setting broader (e.g., company-wide) targets (see chapter 11) because of the general problems with comparability between uncertainty estimates across gases, sources, and facilities.

Given these limitations, the role of qualitative and quantitative uncertainty assessments in developing GHG inventories include:

- GLYPH&lt;127&gt; Promoting a broader learning and quality feedback process.
- GLYPH&lt;127&gt; Supporting efforts to qualitatively understand and document the causes of uncertainty and help identify ways of improving inventory quality. For example, collecting the information needed to determine the statistical properties of activity data and emission factors forces one to ask hard questions and to carefully and systematically investigate data quality.
- GLYPH&lt;127&gt; Establishing lines of communication and feedback with data suppliers to identify specific opportunities to improve quality of the data and methods used.
- GLYPH&lt;127&gt; Providing valuable information to reviewers, verifiers, and managers for setting priorities for investments into improving data sources and methodologies.

The GHG Protocol Corporate Standard has developed a supplementary guidance document on uncertainty assessments ('Guidance on uncertainty assessment in GHG inventories and calculating statistical parameter uncertainty') along with an uncertainty calculation tool, both of which are available on the GHG Protocol website. The guidance document describes how to use the calculation tool in aggregating uncertainties. It also discusses in more depth different types of uncertainties, the limitations of quantitative uncertainty assessment, and how uncertainty estimates should be properly interpreted.

Additional guidance and information on assessing uncertainty-including optional approaches to developing quantitative uncertainty estimates and eliciting judgments from experts- can also be found in EPA's Emissions Inventory Improvement Program, Volume VI: Quality Assurance/Quality Control (1999) and in chapter 6 of the IPCC's Good Practice Guidance (2000a).

<!-- image -->

## NOTES

- 1 Although the term 'emissions inventory' is used throughout this chapter, the guidance equally applies to estimates of removals due to sink categories (e.g., forest carbon sequestration).
- 2 Some emission estimates may be derived using mass or energy balances, engineering calculations, or computer simulation models. In addition to investigating the input data to these models, companies should also consider whether the internal assumptions (including assumed parameters in the model) are appropriate to the nature of the company's operations.
- 3 Emissions estimated from direct emissions monitoring will generally only involve parameter uncertainty (e.g., equipment measurement error).
- 4 Statistical uncertainty results from natural variations (e.g., random human errors in the measurement process and fluctuations in measurement equipment). Statistical uncertainty can be detected through repeated experiments or sampling of data.
- 5 Systematic parameter uncertainty occurs if data are systematically biased. In other words, the average of the measured or estimated value is always less or greater than the true value. Biases arise, for example, because emission factors are constructed from non-representative samples, all relevant source activities or categories have not been identified, or incorrect or incomplete estimation methods or faulty measurement equipment have been used. Because the true value is unknown, such systematic biases cannot be detected through repeated experiments and, therefore, cannot be quantified through statistical analysis. However, it is possible to identify biases and, sometimes, to quantify them through data quality investigations and expert judgments.
- 6 The role of expert judgment can be twofold: First, it can provide the data necessary to estimate the parameter. Second, it can help (in combination with data quality investigations) identify, explain, and quantify both statistical and systematic uncertainties.
- 7 It should be recognized, however, that biases may not be constant from year to year but instead may exhibit a pattern over time (e.g., may be growing or falling). For example, a company that continues to disinvest in collecting high quality data may create a situation in which the biases in its data get worse each year. These types of data quality issues are extremely problematic because of the effect they can have on calculated emission trends. In such cases, systematic parameter uncertainties cannot be ignored.

## Accounting for GHG Reductions

<!-- image -->

s voluntary reporting, external GHG programs, and emission trading systems evolve, it is becoming more and more essential for companies to understand the implications of accounting for GHG emissions changes over time on the one hand, and, on the other hand, accounting for offsets or credits that result from GHG reduction projects. This chapter elaborates on the different issues associated with the term 'GHG reductions.' A

The GHG Protocol Corporate Standard focuses on accounting and reporting for GHG emissions at the company or organizational level. Reductions in corporate emissions are calculated by comparing changes in the company's actual emissions inventory over time relative to a base year. Focusing on overall corporate or organizational level emissions has the advantage of helping companies manage their aggregate GHG risks and opportunities more effectively. It also helps focus resources on activities that result in the most costeffective GHG reductions.

In contrast to corporate accounting, the forthcoming GHG Protocol Project Quantification Standard focuses on the quantification of GHG reductions from GHG mitigation projects that will be used as offsets. Offsets are discrete GHG reductions used to compensate for (i.e., offset) GHG emissions elsewhere, for example to meet a voluntary or mandatory GHG target or cap. Offsets are calculated relative to a baseline that represents a hypothetical scenario for what emissions would have been in the absence of the project.

## Corporate GHG reductions at facility or country level

From the perspective of the earth's atmosphere, it does not matter where GHG emissions or reductions occur. From the perspective of national and international policymakers addressing global warming, the location where GHG reductions are achieved is relevant, since policies usually focus on achieving reductions within specific countries or regions, as spelled out, for example, in the Kyoto Protocol. Thus companies with global operations will have to respond to an array of state, national, or regional regulations and requirements that address GHGs from operations or facilities within a specific geographic area.

The GHG Protocol Corporate Standard calculates GHG emissions using a bottom-up approach. This involves calculating emissions at the level of an individual source or facility and then rolling this up to the corporate level. Thus a company's overall emissions may decrease, even if increases occur at specific sources, facilities, or operations and vice-versa. This bottom-up approach enables companies to report GHG emissions information at different scales, e.g., by individual sources or facilities, or by a collection of facilities within a given country. Companies can meet an array of government requirements or voluntary commitments by comparing actual emissions over time for the relevant scale. On a corpo- rate-wide scale, this information can also be used when setting and reporting progress towards a corporate-wide GHG target (see chapter 11).

In order to track and explain changes in GHG emissions over time, companies may find it useful to provide information on the nature of these changes. For example, BP asks each of its reporting units to provide such information in an accounting movement format using the following categories (BP 2000):

- GLYPH&lt;127&gt; Acquisitions and divestments
- GLYPH&lt;127&gt; Closure
- GLYPH&lt;127&gt; Real reductions (e.g., efficiency improvements, material or fuel substitution)
- GLYPH&lt;127&gt; Change in production level
- GLYPH&lt;127&gt; Changes in estimation methodology
- GLYPH&lt;127&gt; Other

This type of information can be summarized at the corporate level to provide an overview of the company's performance over time.

## Reductions in indirect emissions

Reductions in indirect emissions (changes in scope 2 or 3 emissions over time) may not always capture the actual emissions reduction accurately. This is because there is not always a direct cause-effect relationship between the activity of the reporting company and the resulting GHG emissions. For example, a reduction in air travel would reduce a company's scope 3 emissions. This reduction is usually quantified based on an average emission factor of fuel use per passenger. However, how this reduction actually translates into a change in GHG emissions to the atmosphere would depend on a number of factors, including whether another person takes the 'empty seat' or whether this unused seat contributes to reduced air traffic over the longer term. Similarly, reductions in scope 2 emissions calculated with an average grid emissions factor may over- or underestimate the actual reduction depending on the nature of the grid.

Generally, as long as the accounting of indirect emissions over time recognizes activities that in aggregate change global emissions, any such concerns over accuracy should not inhibit companies from reporting their indirect emissions. In cases where accuracy is more important, it may be appropriate to undertake a more

detailed assessment of the actual reduction using a project quantification methodology.

## Project based reductions and offsets/credits

Project reductions that are to be used as offsets should be quantified using a project quantification method, such as the forthcoming GHG Protocol Project Quantification Standard, that addresses the following accounting issues:

## GLYPH&lt;127&gt; S E L E C T I O N   O F   A   B A S E L I N E   S C E N A R I O   A N D   E M I S S I O N .

- The baseline scenario represents what would have happened in the absence of the project. Baseline emissions are the hypothetical emissions associated with this scenario. The selection of a baseline scenario always involves uncertainty because it represents a hypothetical scenario for what would have happened without the project. The project reduction is calculated as the difference between the baseline and project emissions. This differs from the way corporate or organizational reductions are measured in this document, i.e., in relation to an actual historical base year.
- GLYPH&lt;127&gt; D E M O N S T R A T I O N   O F   A D D I T I O N A L I T Y. This relates to whether the project has resulted in emission reductions or removals in addition to what would have happened in the absence of the project. If the project reduction is used as an offset, the quantification procedure should address additionality and demonstrate that the project itself is not the baseline and that project emissions are less than baseline emissions. Additionality ensures the integrity of the fixed cap or target for which the offset is used. Each reduction unit from a project used as an offset allows the organization or facility with a cap or target one additional unit of emissions. If the project were going to happen anyway (i.e., is non-additional), global emissions will be higher by the number of reduction units issued to the project.
- GLYPH&lt;127&gt; I D E N T I F I C A T I O N   A N D   Q U A N T I F I C A T I O N   O F   R E L E V A N T SECONDARY EFFECTS. These are GHG emissions changes resulting from the project not captured by the primary effect(s). 1 Secondary effects are typically the small, unintended GHG consequences of a project and include leakage (changes in the availability or quantity of a product or service that results in changes in GHG emissions elsewhere) as well as changes in GHG emissions up- and downstream of the project. If relevant, secondary effects should be incorporated into the calculation of the project reduction.
- GLYPH&lt;127&gt; C O N S I D E R A T I O N   O F   R E V E R S I B I L I T Y. Some projects achieve reductions in atmospheric carbon dioxide levels by capturing, removing and/or storing carbon or GHGs in biological or non-biological sinks (e.g., forestry, land use management, underground reservoirs). These reductions may be temporary in that the removed carbon dioxide may be returned to the atmosphere at some point in the future through intentional activities or accidental occurrencessuch as harvesting of forestland or forest fires, etc. 2 The risk of reversibility should be assessed, together with any mitigation or compensation measures included in the project design.
- GLYPH&lt;127&gt; A V O I D A N C E   O F   D O U B L E   C O U N T I N G . To avoid double counting, the reductions giving rise to the offset must occur at sources or sinks not included in the target or cap for which the offset is used. Also, if the reductions occur at sources or sinks owned or controlled by someone other than the parties to the project (i.e., they are indirect), the ownership of the reduction should be clarified to avoid double counting.

Offsets may be converted into credits when used to meet an externally imposed target. Credits are convertible and transferable instruments usually bestowed by an external GHG program. They are typically generated from an activity such as an emissions reduction project and then used to meet a target in an otherwise closed system, such as a group of facilities with an absolute emissions cap placed across them. Although a credit is usually based on the underlying reduction calculation, the conversion of an offset into a credit is usually subject to strict rules, which may differ from program to program. For example, a Certified Emission Reduction (CER) is a credit issued by the Kyoto Protocol Clean Development Mechanism. Once issued, this credit can be traded and ultimately used to meet Kyoto Protocol targets. Experience from the 'precompliance' market in GHG credits highlights the importance of delineating project reductions that are to be used as offsets with a credible quantification method capable of providing verifiable data.

## Reporting project based reductions

It is important for companies to report their physical inventory emissions for their chosen inventory boundaries separately and independently of any GHG trades they undertake. GHG trades 3 should be reported in its public GHG report under optional information-either in relation to a target (see chapter 11) or corporate

inventory (see chapter 9). Appropriate information addressing the credibility of purchased or sold offsets or credits should be included.

When companies implement internal projects that reduce GHGs from their operations, the resulting reductions are usually captured in their inventory's boundaries. These reductions need not be reported separately unless they are sold, traded externally, or otherwise used as an offset or credit. However, some companies may be able to make changes to their own operations that result in GHG emissions changes at sources not included in their own inventory boundary, or not captured by comparing emissions changes over time. For example:

- GLYPH&lt;127&gt; Substituting fossil fuel with waste-derived fuel that might otherwise be used as landfill or incinerated without energy recovery. Such substitution may have no direct effect on (or may even increase) a company's own GHG emissions. However, it could result in emissions reductions elsewhere by another organization, e.g., through avoiding landfill gas and fossil fuel use.
- GLYPH&lt;127&gt; Installing an on-site power generation plant (e.g., a combined heat and power, or CHP , plant) that provides surplus electricity to other companies may increase a company's direct emissions, while displacing the consumption of grid electricity by the companies supplied. Any resulting emissions reductions at the plants where this electricity would have otherwise been produced will not be captured in the inventory of the company installing the on-site plant.
- GLYPH&lt;127&gt; Substituting purchased grid electricity with an on-site power generation plant (e.g., CHP) may increase a company's direct GHG emissions, while reducing the GHG emissions associated with the generation of grid electricity. Depending on the GHG intensity and the supply structure of the electricity grid, this reduction may be over- or underestimated when merely comparing scope 2 emissions over time, if the latter are quantified using an average grid emission factor.

<!-- image -->

## Alcoa: Taking advantage of renewable energy certificates

Alcoa,  a  global  manufacturer  of  aluminum,  is  implementing  a variety of strategies to reduce its GHG emissions. One approach has been to purchase renewable energy certificates, or RECs, to offset some of the company's GHG emissions. RECs, which represent the environmental benefits of renewable energy unbundled from the  actual  flow  of  electrons,  are  an  innovative  method  of providing renewable energy to individual customers. RECs represent the unbundled environmental benefits, such as avoided CO 2 emissions,  generated  by  producing  electricity  from  renewable rather  than  fossil  sources.  RECs  can  be  sold  bundled  with  the electricity (as green power) or separately to customers interested in supporting renewable energy.

Alcoa  found  that  RECs  offer  a  variety  of  advantages,  including direct access to the benefits of renewable energy for facilities that may  have  limited  renewable  energy  procurement  options.  In October 2003, Alcoa began purchasing RECs equivalent to 100% of the electricity used annually at four corporate offices in Tennessee, Pennsylvania, and New York. The RECs Alcoa is purchasing effectively mean that the four corporate centers are now operating on electricity generated by projects that produce electricity from landfill gas, avoiding the emission of more than 6.3 million kilograms (13.9  million  pounds)  of  carbon  dioxide  annually.  Alcoa  chose RECs in part because the supplier was able to provide RECs to all four  facilities  through  one  contract.  This  flexibility  lowered  the administrative cost of purchasing renewable energy for multiple facilities that are served by different utilities.

For  more  information  on  RECs,  see  the  Green  Power  Market Development  Group's  Corporate  Guide  to  Green  Power  Markets: Installment #5 (WRI, 2003).

These reductions may be separately quantified, for example using the GHG Protocol Project Quantification Standard, and reported in a company's public GHG report under optional information in the same way as GHG trades described above.

## NOTES

- 1 Primary  effects  are  the  specific  GHG  reducing  elements  or  activities (reducing GHG emissions, carbon storage, or enhancing GHG removals) that the project is intended to achieve.
- 2 This problem with the temporary nature of GHG reductions is sometimes referred to as the 'permanence' issue.
- 3 The term 'GHG trades' refers to all purchases or sales of allowances, offsets, and credits.

## Reporting GHG Emissions

<!-- image -->

credible GHG emissions report presents relevant information that is  complete, consistent, accurate and transparent. While it takes time to develop a rigorous and complete corporate inventory of GHG emissions, knowledge will improve with experience in calculating and reporting data. It is therefore recommended that a public GHG report: A

- GLYPH&lt;127&gt; Be based on the best data available at the time of publication, while being transparent about its limitations
- GLYPH&lt;127&gt; Communicate any material discrepancies identified in previous years
- GLYPH&lt;127&gt; Include  the  company's  gross  emissions  for  its  chosen  inventory  boundary separate from and independent of any GHG trades it might engage in.

<!-- image -->

Reported information shall be 'relevant, complete, consistent, transparent and accurate.' The GHG Protocol Corporate Standard requires reporting a minimum of scope 1 and scope 2 emissions.

## Required information

A public GHG emissions report that is in accordance with the GHG Protocol Corporate Standard shall include the following information:

## DESCRIPTION OF THE COMPANY AND INVENTORY BOUNDARY

- GLYPH&lt;127&gt; An outline of the organizational boundaries chosen, including the chosen consolidation approach.
- GLYPH&lt;127&gt; An outline of the operational boundaries chosen, and if scope 3 is included, a list specifying which types of activities are covered.
- GLYPH&lt;127&gt; The reporting period covered.

## I N F O R M AT I O N   O N   E M I S S I O N S

- GLYPH&lt;127&gt; Total scope 1 and 2 emissions independent of any GHG trades such as sales, purchases, transfers, or banking of allowances.
- GLYPH&lt;127&gt; Emissions data separately for each scope.
- GLYPH&lt;127&gt; Emissions data for all six GHGs separately (CO , CH , 2 4 NO, HFCs, PFCs, SF) in metric tonnes and in tonnes 2 6 of CO 2 equivalent.
- GLYPH&lt;127&gt; Year chosen as base year, and an emissions profile over time that is consistent with and clarifies the chosen policy for making base year emissions recalculations.
- GLYPH&lt;127&gt; Appropriate context for any significant emissions changes that trigger base year emissions recalculation (acquisitions/divestitures, outsourcing/insourcing, changes in reporting boundaries or calculation methodologies, etc.).
- GLYPH&lt;127&gt; Emissions data for direct CO 2 emissions from biologically sequestered carbon (e.g., CO 2 from burning biomass/biofuels), reported separately from the scopes.
- GLYPH&lt;127&gt; Methodologies used to calculate or measure emissions, providing a reference or link to any calculation tools used.
- GLYPH&lt;127&gt; Any specific exclusions of sources, facilities, and/ or operations.

## Optional information

A public GHG emissions report should include, when applicable, the following additional information:

## I N F O R M AT I O N   O N   E M I S S I O N S   A N D   P E R F O R M A N C E

- GLYPH&lt;127&gt; Emissions data from relevant scope 3 emissions activities for which reliable data can be obtained.
- GLYPH&lt;127&gt; Emissions data further subdivided, where this aids transparency, by business units/facilities, country, source types (stationary combustion, process, fugitive, etc.), and activity types (production of electricity, transportation, generation of purchased electricity that is sold to end users, etc.).
- GLYPH&lt;127&gt; Emissions attributable to own generation of electricity, heat, or steam that is sold or transferred to another organization (see chapter 4).
- GLYPH&lt;127&gt; Emissions attributable to the generation of electricity, heat or steam that is purchased for re-sale to non-end users (see chapter 4).
- GLYPH&lt;127&gt; A description of performance measured against internal and external benchmarks.
- GLYPH&lt;127&gt; Emissions from GHGs not covered by the Kyoto Protocol (e.g., CFCs, NO ,), reported separately x from scopes.
- GLYPH&lt;127&gt; Relevant ratio performance indicators (e.g. emissions per kilowatt-hour generated, tonne of material production, or sales).
- GLYPH&lt;127&gt; An outline of any GHG management/reduction programs or strategies.
- GLYPH&lt;127&gt; Information on any contractual provisions addressing GHG-related risks and obligations.
- GLYPH&lt;127&gt; An outline of any external assurance provided and a copy of any verification statement, if applicable, of the reported emissions data.

D

R

A

D

N

A

T

## Reporting GHG Emissions

- GLYPH&lt;127&gt; Information on the causes of emissions changes that did not trigger a base year emissions recalculation (e.g., process changes, efficiency improvements, plant closures).
- GLYPH&lt;127&gt; GHG emissions data for all years between the base year and the reporting year (including details of and reasons for recalculations, if appropriate)
- GLYPH&lt;127&gt; Information on the quality of the inventory (e.g., information on the causes and magnitude of uncertainties in emission estimates) and an outline of policies in place to improve inventory quality. (see chapter 7).
- GLYPH&lt;127&gt; Information on any GHG sequestration.
- GLYPH&lt;127&gt; A list of facilities included in the inventory.
- GLYPH&lt;127&gt; A contact person.

S

<!-- image -->

## I N F O R M AT I O N   O N   O F F S E T S

- GLYPH&lt;127&gt; Information on offsets that have been purchased or developed outside the inventory boundary, subdivided by GHG storage/removals and emissions reduction projects. Specify if the offsets are verified/certified (see chapter 8) and/or approved by an external GHG program (e.g., the Clean Development Mechanism, Joint Implementation).
- GLYPH&lt;127&gt; Information on reductions at sources inside the inventory boundary that have been sold/transferred as offsets to a third party. Specify if the reduction has been verified/certified and/or approved by an external GHG program (see chapter 8).

y following the GHG Protocol Corporate Standard reporting requirements, users adopt a comprehensive standard with the necessary detail and transparency for credible public reporting. The appropriate level of reporting of optional information categories can be determined by the objectives and intended audience for the report. For national or voluntary GHG programs, or for internal management purposes, reporting requirements may vary (Appendix C summarizes the requirements of various GHG programs). B

For public reporting, it is important to differentiate between a summary of a public report that is, for example, published on the Internet or in Sustainability/ Corporate Social Responsibility reporting (e.g., Global Reporting Initiative) and a full public report that contains all the necessary data as specified by the reporting standard spelled out in this volume. Not every circulated report must contain all information as specified by this standard, but a link or reference needs to be made to a publicly available full report where all information is available.

For some companies, providing emissions data for specific GHGs or facilities/business units, or reporting ratio indicators, may compromise business confidentiality. If this is the case, the data need not be publicly reported, but can be made available to those auditing the GHG emissions data, assuming confidentiality is secured.

Companies should strive to create a report that is as transparent, accurate, consistent and complete as possible. Structurally, this may be achieved by adopting the reporting categories of the standard (e.g., required description of the company and inventory boundary, required information on corporate emissions, optional information on emissions and performance, and optional information on offsets) as a basis of the report. Qualitatively, including a discussion of the reporting company's strategy and goals for GHG accounting, any particular challenges or tradeoffs faced, the context of decisions on boundaries and other accounting parameters, and an analysis of emissions trends may help provide a complete picture of the company's inventory efforts.

## Double Counting

Companies should take care to identify and exclude from reporting any scope 2 or scope 3 emissions that are also reported as scope 1 emissions by other facilities, business units, or companies included in the emissions inventory consolidation (see chapter 6).

## Use of ratio indicators

Two principal aspects of GHG performance are of interest to management and stakeholders. One concerns the overall GHG impact of a company-that is the absolute quantity of GHG emissions released to the atmosphere. The other concerns the company's GHG emissions normalized by some business metric that results in a ratio indicator. The GHG Protocol Corporate Standard requires reporting of absolute emissions; reporting of ratio indicators is optional.

Ratio indicators provide information on performance relative to a business type and can facilitate comparisons between similar products and processes over time. Companies may choose to report GHG ratio indicators in order to:

- GLYPH&lt;127&gt; Evaluate performance over time (e.g., relate figures from different years, identify trends in the data, and show performance in relation to targets and base years (see chapter 11).
- GLYPH&lt;127&gt; Establish a relationship between data from different categories. For example, a company may want to establish a relationship between the value that an action provides (e.g., price of a tonne of product) and its impact on society or on the environment (e.g., emissions from product manufacturing).
- GLYPH&lt;127&gt; Improve comparability between different sizes of business and operations by normalizing figures (e.g., by assessing the impact of different sized businesses on the same scale).

It is important to recognize that the inherent diversity of businesses and the circumstances of individual companies can result in misleading indicators. Apparently minor differences in process, product, or location can be significant in terms of environmental effect. Therefore, it is necessary to know the business context in order to be able to design and interpret ratio indicators correctly.

## Reporting GHG Emissions

Companies may develop ratios that make most sense for their business and are relevant to their decisionmaking needs. They may select ratios for external reporting that improve the understanding and clarify the interpretation of their performance for their stakeholders. It is important to provide some perspective on issues such as scale and limitations of indicators in a way that users understand the nature of the information provided. Companies should consider what ratio indicators best capture the benefits and impacts of their business, i.e., its operations, its products, and its effects on the marketplace and on the entire economy. Some examples of different ratio indicators are provided here.

## MidAmerican: Setting ratio indicators for a utility company

MidAmerican  Energy  Holdings  Company,  an  energy  company based in Iowa, wanted a method to track a power plant's GHG intensity, while also being able to roll individual plant results into a corporate 'generation portfolio' GHG intensity indicator. MidAmerican also wanted to be able to take into account the GHG benefits from planned renewable generation, as well as measure the impacts of other changes to its generation portfolio over time (e.g., unit retirements or new construction). The company adopted a GHG intensity indicator that specifically measures pounds of direct emissions over total megawatt hours generated (lbs/MWh).

To  measure  its  direct  emissions,  the  company  leverages  data currently  gathered  to  satisfy  existing  regulatory  requirements and, where gaps might exist, uses fuel calculations. For coalfired  units,  that  means  mainly  using  continuous  emissions monitoring  (CEM)  data  and  the  U.S.  Environmental  Protection Agency's  emission  factors  for  natural  gas-  and  fuel  oil-fired units. Using the GHG Protocol Corporate Standard , the company completes an annual emission inventory for each of its fossilfired plants, gathering together a) fuel volume and heat input data, b) megawatt production data, c) CEMs data, and d) fuel calculations using appropriate emission factors.

## PRODUCTIVITY/EFFICIENCY RATIOS.

Productivity/efficiency ratios express the value or achievement of a business divided by its GHG impact. Increasing efficiency ratios reflect a positive performance improvement. Examples of productivity/efficiency ratios include resource productivity (e.g., sales per GHG) and process eco-efficiency (e.g., production volume per amount of GHG).

For example, in 2001, using CEM data and fuel calculations, the company's Iowa utility business emitted roughly 23 million tonnes of CO , while generating approximately 21 million megawatt hours. 2 Its  2001  GHG  intensity  indicator  calculates  to  approximately 2,177 lbs/MWh of CO , reflecting the Iowa utility company's reliance 2 on traditional coal-fired generation.

By 2008, the Iowa utility company will have constructed a new 790 MW coal-fueled plant, a 540 MW combined-cycle natural gas plant, and a 310 MW wind-turbine farm and added them to its generation portfolio. The utility company's overall CO 2 emissions will increase, but so will its megawatt production. The combined emissions from the new coal- and gas-fired plants will be added to the GHG intensity indicator's numerator, while the megawatt production data from all three facilities will be added to the indicator's  denominator.  More  importantly,  and  the  ratio  indicator illustrates  this, over  time  MidAmerican's  GHG  intensity  will decline as more efficient generation is brought online and older power plants are used less or retired altogether.

I N T E N S I T Y   R A T I O S . Intensity ratios express GHG impact per unit of physical activity or unit of economic output.  A physical intensity ratio is suitable when aggregating or comparing across businesses that have similar products. An economic intensity ratio is suitable when aggregating or comparing across businesses that produce different products.  A declining intensity ratio reflects a positive performance improvement. Many companies historically tracked environmental performance with intensity ratios. Intensity ratios are often called 'normalized' environmental impact data. Examples of intensity ratios include product emission intensity (e.g., tonnes of CO 2 emissions per electricity generated); service intensity (e.g., GHG emissions per function or per service); and sales intensity (e.g., emissions per sales).

PERCENTAGES. A percentage indicator is a ratio between two similar issues (with the same physical unit in the numerator and the denominator). Examples of percentages that can be meaningful in performance reports include current GHG emissions expressed as a percentage of base year GHG emissions.

For further guidance on ratio indicators refer to CCAR, 2003; GRI, 2002; Verfaillie and Bidwell, 2000.

<!-- image -->

## 10 Verification of GHG Emissions

<!-- image -->

erification is an objective assessment of the accuracy and completeness of  reported  GHG  information  and  the  conformity  of  this  information  to pre-established GHG accounting and reporting principles. Although the practice of verifying corporate GHG inventories is still evolving the emergence of widely accepted standards, such as the GHG Protocol Corporate Standard and the forthcoming GHG Protocol Project Quantification Standard ,  should help GHG verification become more uniform, credible, and widely accepted. V

This chapter provides an overview of the key elements of a GHG verification process. It is relevant to companies who are developing GHG inventories and have planned for, or are considering, obtaining an independent verification of their results and systems. Furthermore, as the process of developing a verifiable inventory is largely the same as that for obtaining reliable and defensible data, this chapter is also relevant to all companies regardless of any intention to commission a GHG verification.

Verification involves an assessment of the risks of material discrepancies in reported data. Discrepancies relate to differences between reported data and data generated from the proper application of the relevant standards and methodologies. In practice, verification involves the prioritization of effort by the verifier towards the data and associated systems that have the greatest impact on overall data quality.

## Relevance of GHG principles

The primary aim of verification is to provide confidence to users that the reported information and associated statements represent a faithful, true, and fair account of a company's GHG emissions. Ensuring transparency and verifiability of the inventory data is crucial for verification. The more transparent, well controlled and well documented a company's emissions data and systems are, the more efficient it will be to verify. As outlined in chapter 1, there are a number of GHG accounting and reporting principles that need to be adhered to when compiling a GHG inventory. Adherence to these principles and the presence of a transparent, well-documented system (sometimes referred to as an audit trail) is the basis of a successful verification.

## Goals

Before commissioning an independent verification, a company should clearly define its goals and decide whether they are best met by an external verification. Common reasons for undertaking a verification include:

- GLYPH&lt;127&gt; Increased credibility of publicly reported emissions information and progress towards GHG targets, leading to enhanced stakeholder trust
- GLYPH&lt;127&gt; Increased senior management confidence in reported information on which to base investment and targetsetting decisions
- GLYPH&lt;127&gt; Improvement of internal accounting and reporting practices (e.g., calculation, recording and internal reporting systems, and the application of GHG accounting and reporting principles), and facilitating learning and knowledge transfer within the company
- GLYPH&lt;127&gt; Preparation for mandatory verification requirements of GHG programs.

## Internal assurance

While verification is often undertaken by an independent, external third party, this may not always be the case. Many companies interested in improving their GHG inventories may subject their information to internal verification by personnel who are independent of the GHG accounting and reporting process. Both internal and external verification should follow similar procedures and processes. For external stakeholders, external third part verification is likely to significantly increase the credibility of the GHG inventory. However, independent internal verifications can also provide valuable assurance over the reliability of information.

Internal verification can be a worthwhile learning experience for a company prior to commissioning an external verification by a third party. It can also provide external verifiers with useful information to begin their work.

## The concept of materiality

The concept of 'materiality' is essential to understanding the process of verification. Chapter 1 provides a useful interpretation of the relationship between the principle of completeness and the concept of materiality. Information is considered to be material if, by its inclusion or exclusion, it can be seen to influence any decisions or actions taken by users of it. A material discrepancy is an error (for example, from an oversight, omission or miscalculation) that results in a reported quantity or statement being significantly different to the true value or meaning. In order to express an opinion on data or information, a verifier would need to form a view on the materiality of all identified errors or uncertainties.

While the concept of materiality involves a value judgment, the point at which a discrepancy becomes material ( materiality threshold ) is usually pre-defined. As a rule of thumb, an error is considered to be materially misleading

if its value exceeds 5% of the total inventory for the part of the organization being verified.

The verifier needs to assess an error or omission in the full context within which information is presented. For example, if a 2% error prevents a company from achieving its corporate target then this would most likely be considered material. Understanding how verifiers apply a materiality threshold will enable companies to more readily establish whether the omissions of an individual source or activity from their inventory is likely to raise questions of materiality.

Materiality thresholds may also be outlined in the requirements of a specific GHG program or determined by a national verification standard, depending on who is requiring the verification and for what reasons. A materiality threshold provides guidance to verifiers on what may be an immaterial discrepancy so that they can concentrate their work on areas that are more likely to lead to materially misleading errors. A materiality threshold is not the same as de minimis emissions, or a permissible quantity of emissions that a company can leave out of its inventory.

## Assessing the risk of material discrepancy

Verifiers need to assess the risk of material discrepancy of each component of the GHG information collection and reporting process. This assessment is used to plan and direct the verification process. In assessing this risk, they will consider a number of factors, including:

- GLYPH&lt;127&gt; The structure of the organization and the approach used to assign responsibility for monitoring and reporting GHG emissions
- GLYPH&lt;127&gt; The approach and commitment of management to GHG monitoring and reporting
- GLYPH&lt;127&gt; Development and implementation of policies and processes for monitoring and reporting (including documented methods explaining how data is generated and evaluated)
- GLYPH&lt;127&gt; Processes used to check and review calculation methodologies
- GLYPH&lt;127&gt; Complexity and nature of operations
- GLYPH&lt;127&gt; Complexity of the computer information system used to process the information
- GLYPH&lt;127&gt; The state of calibration and maintenance of meters used, and the types of meters used
- GLYPH&lt;127&gt; Reliability and availability of input data
- GLYPH&lt;127&gt; Assumptions and estimations applied
- GLYPH&lt;127&gt; Aggregation of data from different sources
- GLYPH&lt;127&gt; Other assurance processes to which the systems and data are subjected (e.g., internal audit, external reviews and certifications).

## Establishing the verification parameters

The scope of an independent verification and the level of assurance it provides will be influenced by the company's goals and/or any specific jurisdictional requirements. It is possible to verify the entire GHG inventory or specific parts of it. Discrete parts may be specified in terms of geographic location, business units, facilities, and type of emissions. The verification process may also examine more general managerial issues, such as quality management procedures, managerial awareness, availability of resources, clearly defined responsibilities, segregation of duties, and internal review procedures.

The company and verifier should reach an agreement upfront on the scope, level and objective of the verification. This agreement (often referred to as the scope of work) will address issues such as which information is to be included in the verification (e.g., head office consolidation only or information from all sites), the level of scrutiny to which selected data will be subjected (e.g., desk top review or on-site review), and the intended use of the results of the verification). The materiality threshold is another item to be considered in the scope of work. It will be of key consideration for both the verifier and the company, and is linked to the objectives of the verification.

The scope of work is influenced by what the verifier actually finds once the verification commences and, as a result, the scope of work must remain sufficiently flexible to enable the verifier to adequately complete the verification.

A clearly defined scope of work is not only important to the company and verifier, but also for external stakeholders to be able to make informed and appropriate decisions. Verifiers will ensure that specific exclusions have not been made solely to improve the company's performance. To enhance transparency and credibility companies should make the scope of work publicly available.

## Site visits

Depending on the level of assurance required from verification, verifiers may need to visit a number of sites to enable them to obtain sufficient, appropriate evidence over the completeness, accuracy and reliability of reported information. The sites visited should be representative of the organization as a whole. The selection of sites to be visited will be based on consideration of a number of factors, including:

- GLYPH&lt;127&gt; Nature of the operations and GHG sources at each site
- GLYPH&lt;127&gt; Complexity of the emissions data collection and calculation process
- GLYPH&lt;127&gt; Percentage contribution to total GHG emissions from each site
- GLYPH&lt;127&gt; The risk that the data from sites will be materially misstated
- GLYPH&lt;127&gt; Competencies and training of key personnel
- GLYPH&lt;127&gt; Results of previous reviews, verifications, and uncertainty analyses.

## PricewaterhouseCoopers: GHG inventory verificationlessons from the field

PricewaterhouseCoopers  (PwC),  a  global  services  company,  has been conducting GHG emissions verifications for the past 10 years in various sectors, including energy, chemicals, metals, semiconductors, and pulp and paper. PwC's verification process involves two key steps:

- 1. An  evaluation  of  whether  the  GHG  accounting  and  reporting methodology (e.g., GHG Protocol Corporate Standard ) has been correctly implemented
- 2. Identification of any material discrepancies.

The GHG Protocol Corporate Standard has been crucial in helping PwC to design an effective GHG verification methodology. Since the publication of the first edition, PwC has witnessed rapid improvements  in  the  quality  and  verifiability  of  GHG  data  reported.  In particular  the  quantification  on  non-CO 2 GHGs  and  combustion emissions  has  dramatically  improved.  Cement  sector  emissions verification  has  been  made  easier  by  the  release  of  the  WBCSD cement sector tool. GHG emissions from purchased electricity are

## Timing of the verification

The engagement of a verifier can occur at various points during the GHG preparation and reporting process. Some companies may establish a semi-permanent internal verification team to ensure that GHG data standards are being met and improved on an on-going basis.

Verification that occurs during a reporting period allows for any reporting deficiencies or data issues to be addressed before the final report is prepared. This may be particularly useful for companies preparing high profile public reports. However, some GHG programs may require, often on a random selection basis, an independent verification of the GHG inventory following the submission of a report (e.g., World Economic Forum Global GHG Registry, Greenhouse Challenge program in Australia, EU ETS). In both cases the verification cannot be closed out until the final data for the period has been submitted.

also easy to verify since most companies have reliable data on MWh consumed and emission factors are publicly available.

However, experience has shown that for most companies, GHG data for 1990 is too unreliable to provide a verifiable base year for the purposes of tracking emissions over time or setting a GHG target. Challenges also remain in auditing GHG emissions embedded in waste fuels, co-generation, passenger travel, and shipping.

Over  the  past  3  years  PwC  has  noticed  a  gradual  evolution  of GHG verification practices from 'customized' and 'voluntary' to 'standardized'  and  'mandatory.'  The  California  Climate  Action Registry,  World  Economic  Forum  Global  GHG  Registry  and  the forthcoming EU ETS (covering 12,000 industrial sites in Europe) require some form of emissions verification. In the EU ETS GHG verifiers will likely have to be accredited by a national body. GHG verifier accreditation processes have already been established in the UK for its domestic trading scheme, and in California for registering emissions in the CCAR.

## Selecting a verifier

Some factors to consider when selecting a verifier include their:

- GLYPH&lt;127&gt; previous experience and competence in undertaking GHG verifications
- GLYPH&lt;127&gt; understanding of GHG issues including calculation methodologies
- GLYPH&lt;127&gt; understanding of the company's operations and industry
- GLYPH&lt;127&gt; objectivity, credibility, and independence.

It is important to recognize that the knowledge and qualifications of the individual(s) conducting the verification can be more important than those of the organization(s) they come from. Companies should select organizations based on the knowledge and qualifications of their actual verifiers and ensure that the lead verifier assigned to them is appropriately experienced. Effective verification of GHG inventories often requires a mix of specialized skills, not only at a technical level (e.g., engineering experience, industry specialists) but also at a business level (e.g., verification and industry specialists).

## Preparing for a GHG verification

The internal processes described in chapter 7 are likely to be similar to those followed by an independent verifier. Therefore, the materials that the verifiers need are similar. Information required by an external verifier is likely to include the following:

- GLYPH&lt;127&gt; Information about the company's main activities and GHG emissions (types of GHG produced, description of activity that causes GHG emissions)
- GLYPH&lt;127&gt; Information about the company/groups/organization (list of subsidiaries and their geographic location, ownership structure, financial entities within the organization)
- GLYPH&lt;127&gt; Details of any changes to the company's organizational boundaries or processes during the period, including justification for the effects of these changes on emissions data
- GLYPH&lt;127&gt; Details of joint venture agreements, outsourcing and contractor agreements, production sharing agreements, emissions rights and other legal or contractual documents that determine the organizational and operational boundaries
- GLYPH&lt;127&gt; Documented procedures for identifying sources of emissions within the organizational and operational boundaries
- GLYPH&lt;127&gt; Information on other assurance processes to which the systems and data are subjected (e.g. internal audit, external reviews and certifications)
- GLYPH&lt;127&gt; Data used for calculating GHG emissions. This might, for example, include:
- GLYPH&lt;127&gt; Energy consumption data (invoices, delivery notes, weigh-bridge tickets, meter readings:  electricity, gas pipes, steam, and hot water, etc.)
- GLYPH&lt;127&gt; Production data (tonnes of material produced, kWh of electricity produced, etc.)
- GLYPH&lt;127&gt; Raw material consumption data for mass balance calculations (invoices, delivery notes, weighbridge tickets, etc.)
- GLYPH&lt;127&gt; Emission factors (laboratory analysis etc.).
- GLYPH&lt;127&gt; Description of how GHG emissions data have been calculated:
- GLYPH&lt;127&gt; Emission factors and other parameters used and their justification
- GLYPH&lt;127&gt; Assumptions on which estimations are based
- GLYPH&lt;127&gt; Information on the measurement accuracy of meters and weigh-bridges (e.g., calibration records), and other measurement techniques
- GLYPH&lt;127&gt; Equity share allocations and their alignment with financial reporting
- GLYPH&lt;127&gt; Documentation on what, if any, GHG sources or activities are excluded due to, for example, technical or cost reasons.
- GLYPH&lt;127&gt; Information gathering process:
- GLYPH&lt;127&gt; Description of the procedures and systems used to collect, document and process GHG emissions data at the facility and corporate level
- GLYPH&lt;127&gt; Description of quality control procedures applied (internal audits, comparison with last year's data, recalculation by second person, etc.).

- GLYPH&lt;127&gt; Other information:
- GLYPH&lt;127&gt; Selected consolidation approach as defined in chapter 3
- GLYPH&lt;127&gt; list of (and access to) persons responsible for collecting GHG emissions data at each site and at the corporate level (name, title, e-mail, and telephone numbers)
- GLYPH&lt;127&gt; information on uncertainties, qualitative and if available, quantitative.

Appropriate documentation needs to be available to support the GHG inventory being subjected to external verification. Statements made by management for which there is no available supporting documentation cannot be verified. Where a reporting company has not yet implemented systems for routinely accounting and recording GHG emissions data, an external verification will be difficult and may result in the verifier being unable to issue an opinion. Under these circumstances, the verifiers may make recommendations on how current data collection and collation process should be improved so that an opinion can be obtained in future years.

Companies are responsible for ensuring the existence, quality and retention of documentation so as to create an audit trail of how the inventory was compiled. If a company issues a specific base year against which it assesses its GHG performance, it should retain all relevant historical records to support the base year data. These issues should be born in mind when designing and implementing GHG data processes and procedures.

## Using the verification findings

Before the verifiers will verify that an inventory has met the relevant quality standard, they may require the company to adjust any material errors that they identified during the course of the verification. If the verifiers and the company cannot come to an agreement regarding adjustments, then the verifier may not be able to provide the company with an unqualified opinion. All material errors (individually or in aggregate) need to be amended prior to the final verification sign off.

As well as issuing an opinion on whether the reported information is free from material discrepancy, the verifiers may, depending on the agreed scope of work, also issue a verification report containing a number of recommendations for future improvements. The process of verification should be viewed as a valuable input to the process of continual improvement. Whether verification is undertaken for the purposes of internal review, public reporting or to certify compliance with a particular GHG program, it will likely contain useful information and guidance on how to improve and enhance a company's GHG accounting and reporting system.

Similar to the process of selecting a verifier, those selected to be responsible for assessing and implementing responses to the verification findings should also have the appropriate skills and understanding of GHG accounting and reporting issues.

<!-- image -->

## 11 Setting a GHG Target

<!-- image -->

etting targets is a routine business practice that helps ensure that an issue is kept on senior management's 'radar screen' and factored into relevant decisions about what products and services to provide and what materials and technologies to use. Often, a corporate GHG emission reduction target is the logical follow-up to developing a GHG inventory. S

This chapter provides guidance on the process of setting and reporting on a corporate GHG target. Although the chapter focuses on emissions, many of the considerations equally apply to GHG sequestration (see Appendix B). It is not the purpose of this chapter to prescribe what a company's target should be, rather the focus is on the steps involved, the choices to be made, and the implications of those choices.

## Why Set a GHG Target?

Any robust business strategy requires setting targets for revenues, sales, and other core business indicators, as well as tracking performance against those targets. Likewise, effective GHG management involves setting a GHG target. As companies develop strategies to reduce the GHG emissions of their products and operations, corporate-wide GHG targets are often key elements of these efforts, even if some parts of the company are or will be subject to mandatory GHG limits. Common drivers for setting a GHG target include:

## GLYPH&lt;127&gt; MINIMIZING AND MANAGING GHG RISKS

While developing a GHG inventory is an important step towards identifying GHG risks and opportunities, a GHG target is a planning tool that can actually drive GHG reductions. A GHG target will help raise internal awareness about the risks and opportunities presented by climate change and ensure the issue is on the business agenda. This can serve to minimize and more effectively manage the business risks associated with climate change.

## GLYPH&lt;127&gt; ACHIEVING COST SAVINGS

## AND STIMULATING INNOVATION

Implementing a GHG target can result in cost savings by driving improvements in process innovation and resource efficiency. Targets that apply to products can drive R&amp;D, which in turn creates products and services that can increase market share and reduce emissions associated with the use of products.

## GLYPH&lt;127&gt; PREPARING FOR FUTURE REGULATIONS

Internal accountability and incentive mechanisms that are established to support a target's implementation can also equip companies to respond more effectively to future GHG regulations. For example, some companies have found that experimenting with internal GHG trading programs has allowed them to better understand the possible impacts of future trading programs on the company.

## FIGURE 12. Steps in setting a GHG target

<!-- image -->

G

U

I

D

A

N

C

E

## GLYPH&lt;127&gt; DEMONSTRATING LEADERSHIP AND CORPORATE RESPONSIBILITY

With the emergence of GHG regulations in many parts of the world, as well as growing concern about the effects of climate change, a commitment such as setting a public corporate GHG target demonstrates leadership and corporate responsibility. This can improve a company's standing with customers, employees, investors, business partners, and the public, and enhance brand reputation.

## GLYPH&lt;127&gt; PARTICIPATING IN VOLUNTARY PROGRAMS

A growing number of voluntary GHG programs are emerging to encourage and assist companies in setting, implementing, and tracking progress toward GHG targets. Participation in voluntary programs can result in public recognition, may facilitate recognition of early action by future regulations, and enhance a company's  GHG accounting and reporting capacity and understanding.

## Steps in Setting a Target

Setting a GHG target involves making choices among various strategies for defining and achieving a GHG reduction. The business goals, any relevant policy context, and stakeholder discussions should inform these choices.

The following sections outline the ten steps involved. Although presented sequentially, in practice target setting involves cycling back and forth between the steps. It is assumed that the company has developed a GHG inventory before implementing these steps. Figure 12 summarizes the steps.

## 1. Obtain senior management commitment

As with any corporate wide target, senior management buy-in and commitment particularly at the board/CEO level is a prerequisite for a successful GHG reduction program. Implementing a reduction target is likely to necessitate changes in behavior and decision-making throughout the organization. It also requires establishing an internal accountability and incentive system and providing adequate resources to achieve the target. This will be difficult, if not impossible, without senior management commitment.

## BOX 4. Comparing absolute and intensity targets

ABSOLUTE  TARGETS reduce  absolute  emissions  over  time (Example: reduce CO 2 by 25 percent below 1994 levels by 2010)

## Advantages

- · Designed to achieve a reduction in a specified quantity of GHGs emitted to the atmosphere
- · Environmentally robust as it entails a commitment to reduce GHGs by a specified amount
- · Transparently  addresses  potential  stakeholder  concerns  about the need to manage absolute emissions

## Disadvantages

- · Target base year recalculations for significant structural changes to the organization add complexity to tracking progress over time
- • Does not allow comparisons of GHG intensity/efficiency
- · Recognizes a company for reducing GHGs by decreasing production or output (organic decline, see chapter 5)
- · May be difficult to achieve if the company grows unexpectedly and growth is linked to GHG emissions

I N T E N S I T Y   T A R G E T S reduce the ratio of emissions relative to a business metric over time (Example:  reduce CO 2 by 12 percent per tonne of clinker between 2000 and 2008)

## Advantages

- · Reflects GHG performance improvements independent of organic growth or decline
- · Target  base  year  recalculations  for  structural  changes  are usually not required (see step 4)
- • May increase the comparability of GHG performance among companies

## Disadvantages

- · No guarantee that GHG emissions to the atmosphere will be reduced-absolute emissions may rise even if intensity goes down and output increases
- · Companies with diverse operations may find it difficult to define a single common business metric
- · If a monetary variable is used for the business metric, such as dollar of revenue or sales, it must be recalculated for changes in product  prices  and  product  mix,  as  well  as  inflation,  adding complexity to the tracking process

## Royal Dutch/Shell: The target cascade

The Royal Dutch/Shell Group, a global energy corporation, discovered when implementing its voluntary GHG reduction target that one of the biggest challenges was to cascade the target down to the actions of all employees who influence target performance. It was concluded that successful implementation required different targets at different levels of the company. This is because each of the components that underlie absolute GHG emissions is influenced by decision-making at various management levels (from the corporate level down to individual businesses and facilities).

Absolute GHG emissions at a plant (tonnes of CO -e.)  =  Function (MP x  BPE x PE) 2

- MP Quantity of product manufactured by a facility. This is fundamental to the need to grow and is therefore controlled at corporate level. GHG emissions are typically not managed by limiting this component.
- BPE Best process energy use per tonne. The optimal (or theoretical) energy consumed (translates to emissions) by a particular design of plant. The type of plant built is a business-level decision. Significant capital decisions may be involved in building a new plant incorporating new technology. For existing plants, BPE is improved by significant design change and retrofitting. This could also involve large capital expenditure.
- PE Plant efficiency index. An index that indicates how the plant is actually performing relative to BPE. PE is a result of day-to-day decisions taken by plant operators and technicians. It is improved also by the Shell Global Solutions Energise TM programme, which typically requires low capital expenditure to implement.

Royal Dutch/Shell found that while this model is probably an oversimplification when it comes to exploration and production facilities, it is suitable for manufacturing facilities (e.g., refineries and chemical plants). It illustrates that an absolute target could only be set at the corporate level, while lower levels require intensity or efficiency targets.

| T YPE OF TARGET           | T YPE OF TARGET              | T YPE OF TARGET              |
|---------------------------|------------------------------|------------------------------|
| Reduce absolute emissions | Reduce absolute emissions    | Reduce absolute emissions    |
|                           | MP: not normally constrained | MP: not normally constrained |
|                           | Reduce GHG intensity         | Reduce GHG intensity         |
|                           |                              | Improve BPE (efficiency)     |
|                           |                              |                              |
|                           |                              | Improve PE (efficiency)      |

## 2.  Decide on the target type

There are two broad types of GHG targets: absolute and intensity-based. An absolute target is usually expressed in terms of a reduction over time in a specified quantity of GHG emissions to the atmosphere, the unit typically being tonnes of CO 2 -e. An intensity target is usually expressed as a reduction in the ratio of GHG emissions relative to another business metric. 1 The comparative metric should be carefully selected. It can be the output of the company (e.g. tonne CO 2 -e per tonne product, per kWh, per tonne mileage) or some other metric such as sales, revenues or office space. To facilitate transparency, companies using an intensity target should also report the absolute emissions from sources covered by the target.

Box 4 summarizes the advantages and disadvantages of each type of target. Some companies have both an absolute and an intensity target. Box 5 provides examples of corporate GHG targets. The Royal Dutch/Shell case study illustrates how a corporate wide absolute target can be implemented by formulating a combination of intensity targets at lower levels of decision-making within the company.

## 3.  Decide on the target boundary

The target boundary defines which GHGs, geographic operations, sources, and activities are covered by the target. The target and inventory boundary can be identical, or

## Setting a GHG Target

the target may address a specified subset of the sources included in the company inventory. The quality of the GHG inventory should be a key factor informing this choice. The questions to be addressed in this step include the following:

- GLYPH&lt;127&gt; WHICH GHGS? Targets usually include one or more of the six major GHGs covered by the Kyoto Protocol. For companies with significant non-CO 2 GHG sources it usually makes sense to include these to increase the range of reduction opportunities. However, practical monitoring limitations may apply to smaller sources.
- GLYPH&lt;127&gt; WHICH GEOGRAPHICAL OPERATIONS? Only country or regional operations with reliable GHG inventory data should be included in the target. For companies with global operations, it makes sense to limit the target's geographical scope until a robust and reliable inventory has been developed for all operations. Companies that participate in GHG programs involving trading 2 will need to decide whether or not to include the emissions sources covered in the trading program in their corporate target. If common sources are included, i.e., if there is overlap in sources covered between the corporate target and the trading program, companies should consider how they will address any double counting resulting from the trading of GHG reductions in the trading program (see step 8).
- GLYPH&lt;127&gt; WHICH DIRECT AND INDIRECT EMISSION SOURCES? Including indirect GHG emissions in a target will facilitate more cost-effective reductions by increasing the reduction opportunities available. However, indirect emissions are generally harder to measure accurately and verify than direct emissions although some categories, such as scope 2 emissions from purchased electricity, may be amenable to accurate measurement and verification. Including indirect emissions can raise issues with regard to ownership and double counting of reductions, as indirect emissions are by definition someone else's direct emissions (see step 8).
- GLYPH&lt;127&gt; SEPARATE TARGETS FOR DIFFERENT TYPES OF BUSINESSES? For companies with diverse operations it may make more sense to define separate GHG targets for different core businesses, especially when using an intensity target, where the most meaningful business metric for defining the target varies across business units (e.g., GHGs per tonne of cement produced or barrel of oil refined).

## BOX 5. Selected corporate GHG targets

## ABSOLUTE TARGETS

- · ABB Reduce GHGs by 1 percent each year from 1998 through 2005
- · Alcoa Reduce GHGs by 25 percent from 1990 levels by 2010, and 50 percent from 1990 levels over same period, if inert anode technology succeeds
- · BP Hold net GHGs stable at 1990 levels through 2012
- · Dupont Reduce GHGs by 65 percent from 1990 levels by 2010
- · Entergy Stabilize CO 2 from U.S. generating facilities at 2000 levels through 2005
- · Ford Reduce CO 2 by 4 percent over 2003-2006 timeframe based upon average 1998-2001 baseline as part of Chicago Climate Exchange
- · Intel Reduce PFCs by 10 percent from 1995 levels by 2010
- · Johnson &amp; Johnson Reduce GHGs by 7 percent from 1990 levels by 2010, with interim goal of 4 percent below 1990 levels by 2005
- · Polaroid Reduce CO 2 emissions 20 percent below its 1994 emissions by year-end 2005; 25 percent by 2010
- · Royal Dutch/Shell Manage GHG emissions so that they are still 5 percent or more below the 1990 baseline by 2010, even while growing the business
- · Transalta Reduce GHGs to 1990 levels by 2000. Achieve zero net GHGs from Canadian operations by 2024

## I N T E N S I T Y   T A R G E T S

- · Holcim Ltd. Reduce by the year 2010 the Group average specific 3 net CO 2 emissions by 20 percent from the reference year 1990
- · Kansai Electric Power Company Reduce CO 2 emissions per kWh sold in fiscal 2010 to approx. 0.34 kg-CO /kWh 2
- · Miller Brewing Company Reduce GHGs by 18 percent per barrel of production from 2001 to 2006
- · National Renewable Energy Laboratory Reduce GHGs by 10 percent per square foot from 2000 to 2005

## COMBINED ABSOLUTE &amp; INTENSITY TARGETS

- · SC Johnson GHG emissions intensity reduction of 23 percent by 2005, which represents an absolute or actual GHG reduction of 8 percent
- · Lafarge Reduce absolute gross CO 2 emissions in Annex I countries 10 percent below 1990 levels by the year 2010. Reduce worldwide average specific net CO 2 emissions 20 percent below 1990 levels by the year 2010 3

## 4. Choose the target base year

For a target to be credible, it has to be transparent how target emissions are defined in relation to past emissions. Two general approaches are available: a fixed target base year or a rolling target base year.

considerations as described for multi-year average base years in chapter 5 apply.

- GLYPH&lt;127&gt; USING A FIXED TARGET BASE YEAR. Most GHG targets are defined as a percentage reduction in emissions below a fixed target base year (e.g., reduce CO 2 emissions 25 percent below 1994 levels by 2010). Chapter 5 describes how companies should track emissions in their inventory over time in reference to a fixed base year. Although it is possible to use different years for the inventory base year and the target base year, to streamline the inventory and target reporting process, it usually makes sense to use the same year for both. As with the inventory base year, it is important to ensure that the emissions data for the target base year are reliable and verifiable. It is possible to use a multi-year average target base year. The same

Chapter 5 provides standards on when and how to recalculate base year emissions in order to ensure like-with-like comparisons over time when structural changes (e.g., acquisitions/divestitures) or changes in measurement and calculation methodologies alter the emissions profile over time. In most cases, this will also be an appropriate approach for recalculating data for a fixed target base year.

- GLYPH&lt;127&gt; USING A ROLLING TARGET BASE YEAR. Companies may consider using a rolling target base year if obtaining and maintaining reliable and verifiable data for a fixed target base year is likely to be challenging (for example, due to frequent acquisitions). With a rolling target base year, the base year rolls forward at regular time intervals, usually one year, so that emissions are always compared against the previous year. 4 However, emission reductions can still be collectively

TABLE 5. Comparing targets with rolling and fixed base years

|                                                                                                                  | FIXED TARGET BASE YEAR                                                                                                                                                                             | ROLLING TARGET BASE YEAR                                                                                                                                                                              |
|------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| How might the target be stated?                                                                                  | A target might take the form 'we will emit X% less in year B than in year A'                                                                                                                       | A target might take the form of 'over the next X years we will reduce emissions every year by Y% compared to the previous year' 5                                                                     |
| What is the target base year?                                                                                    | A fixed reference year in the past                                                                                                                                                                 | The previous year                                                                                                                                                                                     |
| How far back is like-with-like comparison possible?                                                              | The time series of absolute emissions will compare like with like                                                                                                                                  | If there have been significant structural changes the time series of absolute emissions will not compare like with like over more than two years at a time                                            |
| What is the basis for comparing emissions between the target base year and completion year? (see also Figure 14) | The comparison over time is based on what is owned/controlled by the company in the target completion year.                                                                                        | The comparison over time is based on what was owned/controlled by the company in the years the information was reported 6                                                                             |
| How far back are recalculations made?                                                                            | Emissions are recalculated for all years back to the fixed target base year                                                                                                                        | Emissions are recalculated only for the year prior to the structural change, or ex-post for the year of the structural change which then becomes the base year.                                       |
| How reliable are the target base year emissions?                                                                 | If a company with a target acquires a company that did not have reliable GHG data in the target base year; back- casting of emissions becomes necessary, reducing the reliability of the base year | Data from an acquired company's GHG emissions are only necessary for the year before the acquisi- tion (or even only from the acquisition onwards), reducing or eliminating the need for back-casting |
| When are recalculations made?                                                                                    | The circumstances which trigger recalculations for structural changes etc. (see chapter 5) are the same under both approaches                                                                      | The circumstances which trigger recalculations for structural changes etc. (see chapter 5) are the same under both approaches                                                                         |

## Setting a GHG Target

stated over several years. An example would be 'from 2001 through 2012, emissions will be reduced by one percent every year, compared to the previous year.' When structural or methodological changes occur, recalculations only need to be made to the previous year. 7 As a result, like-with-like comparisons of emissions in the 'target starting year' (2001 in the example) and 'target completion year' (2012) cannot be made because emissions are not recalculated for all years back to the target starting year.

The definition of what triggers a base-year emissions recalculation is the same as under the fixed base year approach. The difference lies in how far back emissions are recalculated. Table 5 compares targets using the rolling and fixed base year approaches while Figure 14 illustrates one of the key differences.

## RECALCULATIONS UNDER INTENSITY TARGETS

While the standard in chapter 5 applies to absolute inventory emissions of companies using intensity targets, recalculations for structural changes for the purposes of the target are not usually needed unless the structural change results in a significant change in the GHG intensity. However, if recalculations for structural changes are made for the purposes of the target, they should be made for both the absolute emissions and the business metric. If the target business metric becomes irrelevant through a structural change, a reformulation of the target might be needed (e.g., when a company refocuses on a different industry but had used an industry-specific business metric before).

## 5.  Define the target completion date

The target completion date determines whether the target is relatively short- or long-term. Long-term targets (e.g., with a completion year ten years from the time the target is set) facilitate long-term planning for large capital investments with GHG benefits. However, they might encourage later phase-outs of less efficient equipment. Generally, long-term targets depend on uncertain future developments, which can have opportunities as well as risks, which is illustrated in Figure 13. A five-year target period may be more practical for organizations with shorter planning cycles.

## 6. Define the length of the commitment period

The target commitment period is the period of time during which emissions performance is actually measured against the target. It ends with the target completion date. Many companies use single-year commitment periods, whereas the Kyoto Protocol, for example, specifies a multi-year 'first commitment period' of five years (2008 -2012). The length of the target commitment period is an important factor in determining a company's level of commitment. Generally, the longer the target commitment period, the longer the period during which emissions performance counts towards the target.

## GLYPH&lt;127&gt; EXAMPLE OF A SINGLE YEAR COMMITMENT PERIOD.

Company Beta has a target of reducing emissions by 10 percent compared to its target base year 2000, by the commitment year 2010. For Beta to meet its target, it is sufficient for its emissions to be, in the year 2010, no more than 90 percent of year 2000 emissions.

- GLYPH&lt;127&gt; EXAMPLE OF A MULTI-YEAR COMMITMENT PERIOD. by 10 percent, compared to its target base year 2000, by the commitment period 2008-2012. For Gamma

Company Gamma has a target of reducing emissions to meet its target, its sum total emissions from 2008-2012 must not exceed 90 percent of year 2000 emissions times five (number of years in the

## FIGURE 13. Defining the target completion date

<!-- image -->

FIGURE 14.  Comparing a stabilization target under the fixed and rolling target base year approach

<!-- image -->

A stabilization target is one that aims to keep emissions constant over time. In this example, company A acquires company B, which has experienced organic GHG growth since the target base year (or 'starting' year). Under the rolling approach, emissions growth in the acquired company (B) from year 1 to year 2 does not appear as an emissions increase in relation to the target of the acquiring company (A). Thus company A would meet its stabilization target when using the rolling approach but not when using the fixed approach. In parallel to the example in chapter 5, past GHG growth or decline in divested facilities (GHG changes before the divestment) would affect the target performance under the rolling approach, while it would not be counted under the fixed approach.

commitment period). In other words, its average emissions over those five years must not exceed 90 percent of year 2000 emissions.

FIGURE 15. Short vs. long commitment periods

Target commitment periods longer than one year can be used to mitigate the risk of unpredictable events in one particular year influencing performance against the target. Figure 15 shows that the length of the target commitment period determines how many emissions are actually relevant for target performance.

For a target using a rolling base year, the commitment period applies throughout: emission performance is continuously being measured against the target every year from when the target is set until the target completion date.

## 7. Decide on the use of GHG offsets or credits 8

A GHG target can be met entirely from internal reductions at sources included in the target boundary or through additionally using offsets that are generated from GHG reduction projects that reduce emissions at sources (or enhance sinks) external to the target boundary. 9 The use of offsets may be appropriate when

<!-- image -->

## Setting a GHG Target

the cost of internal reductions is high, opportunities for reductions limited, or the company is unable to meet its target because of unexpected circumstances. When reporting on the target, it should be specified whether offsets are used and how much of the target reduction was achieved using them.

## CREDIBILITY OF OFFSETS AND TRANSPARENCY

There are currently no generally accepted methodologies for quantifying GHG offsets. The uncertainties that surround GHG project accounting make it difficult to establish that an offset is equivalent in magnitude to the internal emissions it is offsetting. 10 This is why companies should always report their own internal emissions in separate accounts from offsets used to meet the target, rather than providing a net figure (see step 10). It is also important to carefully assess the credibility of offsets used to meet a target and to specify the origin and nature of the offsets when reporting. Information needed includes:

- GLYPH&lt;127&gt; the type of project
- GLYPH&lt;127&gt; geographic and organizational origin
- GLYPH&lt;127&gt; how offsets have been quantified
- GLYPH&lt;127&gt; whether they have been recognized by external programs (CDM, JI, etc.)

One important way to ensure the credibility of offsets is to demonstrate that the quantification methodology adequately addresses all of the key project accounting challenges in chapter 8. Taking these challenges into account, the forthcoming GHG Protocol Project Quantification Standard aims to improve the consistency, credibility, and rigor of project accounting.

Additionally, it is important to check that offsets have not also been counted towards another organization's GHG target. This might involve a contract between the buyer and seller that transfers ownership of the offset. Step 8 provides more information on accounting for GHG trades in relation to a corporate target, including establishing a policy on double counting.

## OFFSETS AND INTENSITY TARGETS

When using offsets under intensity targets, all the above considerations apply. In order to determine compliance with the target, the offsets can be subtracted from the figure used for absolute emissions (the numerator); the resulting difference is then divided by the corresponding metric. It is important, however, that absolute emissions are still reported separately both from offsets and the business metric (see step 9 below).

## 8. Establish a target double counting policy

This step addresses double counting of GHG reductions and offsets, as well as allowances issued by external trading programs. It applies only to companies that engage in trading (sale or purchase) of GHG offsets or whose corporate target boundaries interface with other companies' targets or external programs.

Given that there is currently no consensus on how such double counting issues should be addressed, companies should develop their own 'Target Double Counting Policy.' This should specify how reductions and trades related to other targets and programs will be reconciled with their corporate target, and accordingly which types of double counting situations are regarded as relevant. Listed here are some examples of double counting that might need to be addressed in the policy.

- GLYPH&lt;127&gt; DOUBLE COUNTING OF OFFSETS. This can occur when a GHG offset is counted towards the target by both the selling and purchasing organizations. For example, company A undertakes an internal reduction project that reduces GHGs at sources included in its own target. Company A then sells this project reduction to company B to use as an offset towards its target, while still counting it toward its own target. In this case, reductions are counted by two different organizations against targets that cover different emissions sources. Trading programs address this by using registries that allocate a serial number to all traded offsets or credits and ensuring the serial numbers are retired once they are used. In the absence of registries this could be addressed by a contract between seller and buyer.

## GLYPH&lt;127&gt; D O U B L E   C O U N T I N G   D U E   T O   T A R G E T   O V E R L A P. 11 by an external program or another company's target.

This can occur when sources included under a company's corporate target are also subject to limits Two examples:

- GLYPH&lt;127&gt; Company A has a corporate target that includes GHG sources that are also regulated under a trading program. In this case, reductions at the common sources are used by company A to meet both its corporate target and the trading program target.

- GLYPH&lt;127&gt; Company B has a corporate target to reduce its direct emissions from the generation of electricity. 12 Company C who purchases electricity directly from company B also has a corporate target that includes indirect emissions from the purchase of electricity (scope 2). Company C undertakes energy efficiency measures to reduce its indirect emissions from the use of the electricity. These will usually show up as reductions in both companies' targets. 13

These two examples illustrate that double counting is inherent when the GHG sources where the reductions occur are included in more than one target of the same or different organizations. Without limiting the scope of targets it may be difficult to avoid this type of double counting and it probably does not matter if the double counting is restricted to the organizations sharing the same sources in their targets (i.e., when the two targets overlap).

## GLYPH&lt;127&gt; DOUBLE COUNTING OF ALLOWANCES TRADED IN

- EXTERNAL PROGRAMS. This occurs when a corporate target overlaps with an external trading program and allowances that cover the common sources are sold in the trading program for use by another organization and reconciled with the regulatory target, but not reconciled with the corporate target. This example differs from the previous example in that double counting occurs across two targets that are not overlapping (i.e., they do not cover the same sources). This type of double counting could be avoided if the company selling the allowances reconciles the trade with its corporate target (see Holcim case study). Whatever the company decides to do in this situation, in order to maintain credibility, it should address buying and selling of allowances in trading programs in a consistent way. For example, if it decides not to reconcile allowances that it sells in a trading program with its corporate target, it should also not count any allowances of the same type that it purchases to meet its corporate target.

Ideally a company should try to avoid double counting in its corporate target if this undermines the environmental integrity of the target. Also, any prevented double counting between two organizations provides an additional incentive for one of these companies to further reduce emissions. However, in practice the avoidance of double counting can be quite challenging, particularly for companies subject to multiple external programs and when indirect GHG emissions are included in the target. Companies should therefore be transparent about their

<!-- image -->

double counting policy and state any reasons for choosing not to address some double counting situations.

The Holcim case study describes how one company has chosen to track performance towards its target and address double counting issues.

## 9. Decide on the target level

The decision on setting the target level should be informed by all the previous steps. Other considerations to take into account include:

- GLYPH&lt;127&gt; Understanding the key drivers affecting GHG emissions by examining the relationship between GHG emissions and other business metrics, such as production, square footage of manufacturing space, number of employees, sales, revenue, etc.
- GLYPH&lt;127&gt; Developing different reduction strategies based on the major reduction opportunities available and examining their effects on total GHG emissions. Investigate how emissions projections change with different mitigation strategies.
- GLYPH&lt;127&gt; Looking at the future of the company as it relates to GHG emissions.
- GLYPH&lt;127&gt; Factoring in relevant growth factors such as production plans, revenue or sales targets, and Return on Investment (ROI) of other criteria that drive investment strategy.

## Setting a GHG Target

## Holcim: Using a GHG balance sheet to track performance towards the target

Holcim, a global cement producer, tracks its performance in relation to its voluntary corporate target using a GHG balance sheet. This balance sheet shows, for each commitment period and for  each  country  business,  on  one  side  the  actual  GHG emissions  and  on  the  other  side  the  GHG  'assets'  and 'instruments.' These assets and instruments consist of the voluntary  GHG  target  itself  (the  'voluntary  cap';  in  other words, the allowances that Holcim provides for itself), a regulatory  target  ('cap')  if  applicable,  plus  the  CDM  credits purchased  (added)  or  sold  (subtracted),  and  any  regulatory emissions  trading  allowances  purchased  (added)  or  sold (subtracted). Thus if any country business sells CDM credits (generated at sources inside the voluntary target boundary), it is ensured that only the buying organization counts the credit (see first example of double counting in step 8).

target. Those companies whose voluntary cap overlaps with a regulatory  cap  (e.g.,  in  Europe)  must  also  demonstrate  a neutral  or  positive  balance  towards  the  regulatory  cap.  GHG reductions in Europe are thus reported towards both targets (see second example of double counting in step 8).

At the end of the commitment period, every country business must demonstrate a neutral or positive balance towards Holcim's

Both sides of the country business balance sheets are consolidated to group level. Credits and allowances traded within the group simply cancel out in the asset column of the consolidated  corporate  level  GHG  balance  sheet.  Any  credits  or allowances  traded  externally  are  reconciled  with  both  the voluntary and regulatory caps at the bottom line of the asset column  of  the  balance  sheet.  This  ensures  that  any  sold allowance  is  only  counted  by  the  buying  organization  (when Holcim's  target  and  that  of  the  buying  organization  do  not overlap). A purchased allowance or credit is counted towards both the voluntary and regulatory targets of the European business (these two targets overlap).

| GHG balance sheet (All values in tonnes CO 2 -e/year)   | GHG balance sheet (All values in tonnes CO 2 -e/year)   |
|---------------------------------------------------------|---------------------------------------------------------|
| GHG ASSETS & I NSTRUMENTS                               | GHG EMISSIONS                                           |
| Holcim (country A in Europe)                            | Holcim (country A in Europe)                            |
| Voluntary cap (direct emissions)                        | Emissions, direct, indirect + biomass                   |
| Regulatory cap (direct emissions)                       |                                                         |
| Reg. allowances purchased (+) or sold (-)               |                                                         |
| CDM credits purchased (+) or sold (-)                   |                                                         |
| Sum of voluntary cap, reg. allowances & credits         | Sum of direct emissions                                 |
| Sum of regulatory cap, reg. allowances & credits        | Sum of direct emissions, according to EU ETS            |
| Holcim (country X in Latin America)                     | Holcim (country X in Latin America)                     |
| Voluntary cap                                           | Emissions, direct, indirect + biomass                   |
| CDM credits purchased (+) or sold (-)                   |                                                         |
| Sum of voluntary cap & credits                          | Sum of direct emissions                                 |
| Holcim Group                                            | Holcim Group                                            |
| Sum of voluntary cap, reg. allowances & credits         | Sum of direct emissions                                 |

- GLYPH&lt;127&gt; Considering whether there are any existing environmental or energy plans, capital investments, product/service changes, or targets that will affect GHG emissions. Are there plans already in place for fuel switching, on site power generation, and/or renewable energy investments that affect the future GHG trajectory?
- GLYPH&lt;127&gt; Benchmarking GHG emissions with similar organizations. Generally, organizations that have not previously invested in energy and other GHG reductions should be capable of meeting more aggressive reduction levels because they would have more cost-effective reduction opportunities.

## 10. Track and report progress

Once the target has been set, it is necessary to track performance against it in order to check compliance, and also-in order to maintain credibility-to report emissions and any external reductions in a consistent, complete and transparent manner.

- GLYPH&lt;127&gt; CARRY OUT REGULAR PERFORMANCE CHECKS. In order to track performance against a target, it is important to link the target to the annual GHG inventory process and make regular checks of emissions in relation to the target. Some companies use interim targets for this purpose (a target using a rolling target base year automatically includes interim targets every year).

## NOTES

- 1 Some companies may formulate GHG efficiency targets by formulating this ratio the other way around.
- 2 Examples include the U.K. ETS, the CCX, and the EU ETS.
- 3 Holcim's and Lafarge's target have been formulated using the terminology of the WBCSD Cement CO 2 Protocol (WBCSD, 2001), which uses'specific' to denote emissions per tonne of cement produced.
- 4 It is possible to use an interval other than one year. However, the longer the interval at which the base year rolls forward, the more this approach becomes like a fixed target base year. This discussion is based on a rolling target base year that moves forward at annual intervals.
- 5 Note that simply adding the yearly emissions changes under the rolling base year yields a different result from the comparison over time made with a fixed base year, even without structural changes. In absolute terms, an X% reduction every year over 5 years (compared to the previous year) is not the same as an (X times 5) reduction in year 5 compared to year 1.
- 6 Depending on which recalculation methodology is used when applying the rolling base year, the comparison over time can include emissions that occurred when the company did not own or control the emission sources. However, the inclusion of this type of information is minimized. See also the guidance document 'Base year recalculation methodologies for structural changes' on the GHG Protocol website (www.ghgprotocol.org).
- GLYPH&lt;127&gt; REPORT INFORMATION IN RELATION TO THE TARGET.

Companies should include the following information when setting and reporting progress in relation to a target:

- 1. Description of the target
- GLYPH&lt;127&gt; Provide an outline of the target boundaries chosen
- GLYPH&lt;127&gt; Specify target type, target base year, target completion date, and length of commitment period
- GLYPH&lt;127&gt; Specify whether offsets can be used to meet the target; if yes, specify the type and amount
- GLYPH&lt;127&gt; Describe the target double counting policy
- GLYPH&lt;127&gt; Specify target level.
- 2. Information on emissions and performance in relation to the target
- GLYPH&lt;127&gt; Report emissions from sources inside the target boundary separately from any GHG trades
- GLYPH&lt;127&gt; If using an intensity target, report absolute emissions from within the target boundary separately, both from any GHG trades and the business metric
- GLYPH&lt;127&gt; Report GHG trades that are relevant to compliance with the target (including how many offsets were used to meet the target)
- GLYPH&lt;127&gt; Report any internal project reductions sold or transferred to another organization for use as an offset
- GLYPH&lt;127&gt; Report overall performance in relation to the target.
- 7 For further details on different recalculation methodologies, see the guidance document 'Base year recalculation methodologies for structural changes' on the GHG Protocol website (www.ghgprotocol.org).
- 8 As noted in chapter 8, offsets can be converted to credits. Credits are thus understood to be a subset of offsets. This chapter uses the term offsets as a generic term.
- 9 For the purposes of this chapter, the terms 'internal' and 'external' refer to whether the reductions occur at sources inside (internal) or outside (external) the target boundary.
- 10 This equivalence is sometimes referred to as 'fungibility.' However, 'fungibility' can also refer to equivalence in terms of the value in meeting a target (two fungible offsets have the same value in meeting a target, i.e., they can both be applied to the same target).
- 11 Overlap here refers to a situation when two or more targets include the same sources in their target boundaries.
- 12 Similarly, company A in this example could be subject to a mandatory cap on its direct emissions under a trading program and engage in trading allowances covering the common sources it shares with company B.  In this case, the example in the section 'Double counting of allowances traded in external programs' is more relevant.
- 13 The energy efficiency measures implemented by company C may not always result in an actual reduction of company B's emissions. See chapter 8 for further details on reductions in indirect emissions.

<!-- image -->

A

## Accounting for Indirect Emissions from Purchased Electricity

his appendix provides guidance on how to account for and report indirect emissions associated with the purchase of electricity. Figure A-1 provides an overview of the transactions associated with purchased electricity and the corresponding emissions. T

companies and electricity suppliers often exercise choice over where they purchase electricity, this provides them with an important

## Purchased electricity for own consumption

Emissions associated with the generation of purchased electricity that is consumed by the reporting company are reported in scope 2. Scope 2 only accounts for the portion of the direct emissions from generating electricity that is actually consumed by the company. A company that purchases electricity and transports it in a transmission and distribution (T&amp;D) system that it owns or controls reports the emissions associated with T&amp;D losses under scope 2. However, if the reporting company owns or controls the T&amp;D system but generates (rather than purchases) the electricity transmitted through its wires, the emissions associated with T&amp;D losses are not reported under scope 2, as they would already be accounted for under scope 1. This is the case when generation, transmission, and distribution systems are vertically integrated and owned or controlled by the same company.

## Purchased electricity for resale to end-users

Emissions from the generation of purchased electricity for resale to end-users, for example purchases by a utility company, may be reported under scope 3 in the category 'generation of purchased electricity that is sold to end-users.' This reporting category is particularly relevant for utility companies that purchase wholesale electricity supplied by independent power producers for resale to their customers. Since utility

GHG reduction opportunity (see Seattle City Light case study in chapter 4). Since scope 3 is optional, companies that are unable to track their electricity sales in terms of end users and non-end users can choose not to report these emissions in scope 3. Instead, they can report the total emissions associated with purchased electricity that is sold to both end- and non-end-users under optional information in the category 'generation of purchased electricity, heat, or steam for re-sale to non-end users.'

## Purchased electricity for resale to intermediaries

Emissions associated with the generation of purchased electricity that is resold to an intermediary (e.g., trading transactions) may be reported under optional information under the category 'Generation of purchased electricity, heat, or steam for re-sale to nonend users.' Examples of trading transactions include brokerage/trading room transactions involving purchased electricity or any other transaction in which electricity is purchased directly from one source or the spot market and then resold to an intermediary (e.g., a non-end user). These emissions are reported under optional information separately from scope 3 because there could be a number of trading transactions before the electricity finally reaches the end-user. This may cause duplicative reporting of indirect emissions from a series of electricity trading transactions for the same electricity.

FIGURE A- 1. Accounting for the indirect GHG emissions associated with purchased electricity

<!-- image -->

## GHG emissions upstream of the generation of electricity

Emissions associated with the extraction and production of fuels consumed in the generation of purchased electricity may be reported in scope 3 under the category 'extraction, production, and transportation of fuels consumed in the generation of electricity.' These emissions occur upstream of the generation of electricity. Examples include emissions from mining of coal, refining of gasoline, extraction of natural gas, and production of hydrogen (if used as a fuel).

## Choosing electricity emission factors

To quantify scope 2 emissions, the GHG Protocol Corporate Standard recommends that companies obtain source/supplier specific emission factors for the electricity purchased. If these are not available, regional or grid emission factors should be used. For more information on choosing emission factors, see the relevant GHG Protocol calculation tools available on the GHG Protocol website (www.ghgprotocol.org).

## GHG emissions associated with the consumption of electricity in T&amp;D

Emissions from the generation of electricity that is consumed in a T&amp;D system may be reported in scope 3 under the category 'generation of electricity that is consumed in a T&amp;D system' by end-users. Published electricity grid emission factors do not usually include T&amp;D losses. To calculate these emissions, it may be necessary to apply supplier or location specific T&amp;D loss factors. Companies that purchase electricity and transport it in their own T&amp;D systems would report the portion of electricity consumed in T&amp;D under scope 2.

## Accounting for indirect emissions associated with T&amp;D losses

There are two types of electricity emission factors: Emission factor at generation (EFG) and Emissions factor at consumption (EFC). EFG is calculated from CO emissions from generation of electricity divided 2 by amount of electricity generated. EFC is calculated from CO 2 emissions from generation divided by amount of electricity consumed.

EFC and EFG are related as shown below.

EFC x ELECTRICITY CONSUMED

=

EFG x ( E L E C T R I C I T Y   C O N S U M E D   + T &amp; D   L O S S E S )

EFC = EFG

## T &amp; D   L O S S E S

ELECTRICITY CONSUMED ( 1 +

)

x

As these equations indicate, EFC multiplied by the amount of consumed electricity yields the sum of emissions attributable to electricity consumed during end use and transmission and distribution. In contrast, EFG multiplied by the amount of consumed electricity yields emissions attributable to electricity consumed during end use only.

Consistent with the scope 2 definition (see chapter 4), the GHG Protocol Corporate Standard requires the use of EFG to calculate scope 2 emissions. The use of EFG ensures internal consistency in the treatment of electricity related upstream emissions categories and avoids double counting in scope 2. Additionally, there are several other advantages in using EFG:

- 1)  It is simpler to calculate and widely available in published regional, national, and international sources.
- 2)  It is based on a commonly used approach to calculate emissions intensity, i.e., emissions per unit of production output.
- 3)  It ensures transparency in reporting of indirect emissions from T&amp;D losses.

The formula to account for emissions associated with T&amp;D losses is the following:

In some countries such as Japan, local regulations may require utility companies to provide both EFG and EFC to its consumers, and consumers may be required to use EFC to calculate indirect emissions from the consumption of purchased electricity. In this case, a company still needs to use EFG to report its scope 2 emissions for a GHG report prepared in accordance with GHG Protocol Corporate Standard .

A

P

P

E

N

D

I

X

A

key purpose of the GHG Protocol Corporate Standard is to provide companies with guidance on how to develop inventories that provide an accurate and complete picture of their GHG emissions both from their direct operations as well as those along the value chain. 1 For some types of companies, this is not possible without addressing the company's impacts on sequestered atmospheric carbon. 2 A

## Sequestered atmospheric carbon

During photosynthesis, plants remove carbon (as CO ) 2 from the atmosphere and store it in plant tissue. Until this carbon is cycled back into the atmosphere, it resides in one of a number of 'carbon pools.' These pools include (a) above ground biomass (e.g., vegetation) in forests, farmland, and other terrestrial environments, (b) below ground biomass (e.g., roots), and (c) biomass-based products (e.g., wood products) both while in use and when stored in a landfill.

Carbon can remain in some of these pools for long periods of time, sometimes for centuries. An increase in the stock of sequestered carbon stored in these pools represents a net removal of carbon from the atmosphere; a decrease in the stock represents a net addition of carbon to the atmosphere.

## Why include impacts on sequestered carbon in corporate GHG inventories?

It is generally recognized that changes in stocks of sequestered carbon and the associated exchanges of carbon with the atmosphere are important to national level GHG emissions inventories, and consequently, these impacts on sequestered carbon are commonly addressed in national inventories (UNFCCC, 2000). Similarly, for companies in biomass-based industries, such as the forest products industry, some of the most significant aspects of a company's overall impact on atmospheric CO 2 levels will occur as a result of impacts on sequestered carbon in their direct operations as well as along their value chain. Some forest product companies have begun to address this aspect of their GHG footprint within their corporate GHG inventories (Georgia Pacific, 2002). Moreover, WBCSD's Sustainable Forest Products Industry Working Group-which represents a significant cluster of integrated forestry companies operating internationally-is developing a project that will further investigate carbon measurement, accounting, reporting, and ownership issues associated with the forest products value chain.

Information on a company's impacts on sequestered atmospheric carbon can be used for strategic planning, for educating stakeholders, and for identifying opportunities for improving the company's GHG profile. Opportunities may also exist to create value from reductions created along the value chain by companies acting alone or in partnership with raw material providers or customers.

## Accounting for sequestered carbon in the context of the GHG Protocol Corporate Standard

Consensus methods have yet to be developed under the GHG Protocol Corporate Standard for accounting of sequestered atmospheric carbon as it moves through the value chain of biomass-based industries. Nonetheless, some issues that would need to be addressed when addressing impacts on sequestered carbon in corporate inventories can be examined in the context of existing guidance provided by the GHG Protocol Corporate Standard as highlighted below.

## SETTING ORGANIZATIONAL BOUNDARIES

The GHG Protocol Corporate Standard outlines two approaches for consolidating GHG data-the equity share approach and the control approach. In some cases, it may be possible to apply these approaches directly to emissions/removals associated with sequestered atmospheric carbon. Among the issues that may need to be examined is the ownership of sequestered carbon under the different types of contractual arrangements involving land and wood ownership, harvesting rights, and control of land management and harvesting decisions. The transfer of ownership as carbon moves through the value chain may also need to be addressed. In some cases, as part of a risk management program for instance, companies may be interested in performing value chain assessments of sequestered carbon without regard to ownership or control just as they might do for scope 2 and 3 emissions.

## SETTING OPERATIONAL BOUNDARIES

As with GHG emissions accounting, setting operational boundaries for sequestered carbon inventories would help companies transparently report their impacts on sequestered carbon along their value chain. Companies may, for example, provide a description of the value chain capturing impacts that are material to the results of the analysis. This should include which pools are

included in the analysis, which are not, and the rationale for the selections. Until consensus methods are developed for characterizing impacts on sequestered atmospheric carbon along the value chain, this information can be included in the 'optional information' section of a GHG inventory compiled using the GHG Protocol Corporate Standard.

## T R A C K I N G   R E M O VA L S   O V E R   T I M E

As is sometimes the case with accounting for GHG emissions, base year data for impacts on sequestered carbon may need to be averaged over multiple years to accommodate the year-to-year variability expected of these systems. The temporal scale used in sequestered carbon accounting will often be closely tied to the spatial scale over which the accounting is done. The question of how to recalculate base years to account for land acquisition and divestment, land use changes, and other activities also needs to be addressed.

## I D E N T I F Y I N G   A N D   C A L C U L A T I N G   G H G   R E M O V A L S

The GHG Protocol Corporate Standard does not include consensus methods for sequestered carbon quantification. Companies should, therefore, explain the methods used. In some instances, quantification methods used in national inventories can be adapted for corporatelevel quantification of sequestered carbon. IPCC (1997; 2000b) provides useful information on how to do this.  In 2004, IPCC is expected to issue Good Practice Guidance for Land Use, Land Use Change and Forestry, with information on methods for quantification of sequestered carbon in forests and forest products.  Companies may also find it useful to consult the methods used to prepare national inventories for those countries where significant parts of their company's value chain reside.

In addition, although corporate inventory accounting differs from project-based accounting (as discussed below), it may be possible to use some of the calculation and monitoring methods derived from project level accounting of sequestration projects.

## ACCOUNTING FOR REMOVAL ENHANCEMENTS

A corporate inventory can be used to account for yearly removals within the corporate inventory boundary. In contrast, the forthcoming GHG Protocol Project

Quantification Standard is designed to calculate project reductions that will be used as offsets, relative to a hypothetical baseline scenario for what would have happened without the project. In the forestry sector , projects take the form of removal enhancements.

Chapter 8 in this document addresses some of the issues that must be addressed when accounting for offsets from GHG reduction projects. Much of this guidance is also applicable to removal enhancement projects. One example is the issue of reversibility of removals - also briefly described in chapter 8.

## REPORTING GHG REMOVALS

Until consensus methods are developed for characterizing impacts on sequestered atmospheric carbon along the value chain, this information can be included in the 'optional information' section of the inventory (See chapter 9). Information on sequestered carbon in the company's inventory boundary should be kept separate from project-based reductions at sources that are not in the inventory boundary. Where removal enhancement projects take place within a company's inventory boundary they would normally show up as an increase in carbon removals over time, but can also be reported in optional information. However, they should also be identified separately to ensure that they are not double counted. This is especially important when they are sold as offsets or credits to a third party.

As companies develop experience using various methods for characterizing impacts on sequestered carbon, more information will become available on the level of accuracy to expect from these methods. In the early stages of developing this experience, however, companies may find it difficult to assess the uncertainty associated with the estimates and therefore may need to give special care to how the estimates are represented to stakeholders.

## NOTES

- 1 In this Appendix, 'value chain' means a series of operations and entities, starting with the forest and extending through end-of-life management, that (a) supply or add value to raw materials and intermediate products to produce final products for the marketplace and (b) are involved in the use and end-of-life management of these products.
- 2 In this Appendix the term 'sequestered atmospheric carbon' refers exclusively to sequestration by biological sinks.

<!-- image -->

| NAME OF PROGRAM                                                                               | T YPE OF PROGRAM                                   | FOCUS (Organization, project, facility)   | GASES COVERED                                                                                | ORGANIZATIONAL PROJECT BOUNDARIES                       |
|-----------------------------------------------------------------------------------------------|----------------------------------------------------|-------------------------------------------|----------------------------------------------------------------------------------------------|---------------------------------------------------------|
| California Climate Action Registry www.climateregisty.org                                     | Voluntary registry                                 | Organization (Projects possible in 2004)  | Organizations report CO 2 for first three years of participa- tion, all six GHGs thereafter. | Equity share or control for California or US operations |
| US EPA Climate Leaders www.epa.gov/climateleaders                                             | Voluntary reduction program                        | Organization                              | Six                                                                                          | Equity share or control for US operations at a minimum  |
| WWF Climate Savers www.worldwildlife.org/climatesavers                                        | Voluntary registry                                 | Organization                              | CO 2                                                                                         | Equity share or control for worldwide operations        |
| World Economic Forum Global GHG Register www.weforum.org                                      | Voluntary registry                                 | Organization                              | Six                                                                                          | Equity share or control for worldwide operations        |
| EU GHG Emissions Allowance Trading Scheme www.europa.eu.int/comm/environment/                 | Mandatory allowance trading scheme                 | Facility                                  | Six                                                                                          | Facilities in selected sectors                          |
| European Pollutant Emission Registry www.europa.eu.int/comm/environ- ment/ippc/eper/index.htm | Mandatory registry for large industrial facilities | Facility                                  | Six Kyoto gases as well as other pollutants                                                  | Facilities that fall under EU IPPC directive            |
| Chicago Climate Exchange www.chicagoclimateexchange.com                                       | Voluntary allowance trading scheme                 | Organization and project                  | Six                                                                                          | Equity share                                            |
| Respect Europe BLICC www.respecteurope.com/rt2/blicc/                                         | Voluntary reduction program                        | Organization                              | Six                                                                                          | Equity share or control for worldwide operations        |

| OPERATIONAL BOUNDARIES                                                            | NATURE/PURPOSE OF PROGRAM                                                               | BASE YEAR                                                                                                                       | TARGET                                                                                                              | VERIFICATION                                                                                  |
|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
| Scope 1 and 2 required, scope 3 to be decided                                     | Baseline protection, public reporting, possible future targets                          | Specific to each organization, recalculation consistent with GHG Protocol Corporate Standard required                           | Encouraged but optional                                                                                             | Required through certi- fied third party verifier                                             |
| Scope 1 and 2 required, scope 3 optional                                          | Public recognition, assistance setting targets and achieving reductions                 | Year that organization joins program, recalculation consistent with GHG Protocol Corporate Standard required                    | Required, specific to each organization                                                                             | Optional, provides guidance and checklist of components that should be included if undertaken |
| Scope 1 and 2 required, scope 3 optional                                          | Achieve targets, public recognition, expert assistance                                  | Chosen year since 1990, specific to each organization, recalcula- tion consistent with GHG Protocol Corporate Standard required | Required, specific to each organization                                                                             | Third party verifier                                                                          |
| Scope 1 and 2 required, scope 3 optional                                          | Baseline protection, public reporting, targets encouraged but optional                  | Chosen year since 1990, specific to each organization, recalcula- tion consistent with GHG Protocol Corporate Standard required | Encouraged but optional                                                                                             | Third party verifier or spot checks by WEF                                                    |
| Scope 1                                                                           | Achieve annual caps through tradable allowance market, initial period from 2005 to 2007 | Determined by member country for allowance allocation                                                                           | Annual compliance with allocated and traded allowances, EU committed to 8% overall reduction below 1990             | Third party verifier                                                                          |
| Scope 1 required                                                                  | Permit individual industrial facilities                                                 | Not applicable                                                                                                                  | Not applicable                                                                                                      | Local permitting authority                                                                    |
| Direct combustion and process emis- sion sources and indirect emissions optional. | Achieve annual targets through trad- able allowance market                              | Average of 1998 through 2001                                                                                                    | 1% below its baseline in 2003, 2% below baseline in 2004, 3% below base- line in 2005 and 4% below baseline in 2006 | Third party verifier                                                                          |
| Scope 1 and 2 required, scope 3 strongly encouraged                               | Achieve targets, public recognition, expert assistance                                  | Specific to each organization, recalculation consistent with GHG Protocol Corporate Standard required                           | Mandatory, specific to each organization                                                                            | Third party verifier                                                                          |

<!-- image -->

| SECTOR                                                      | SCOPE 1 EMISSION SOURCES                                                                                                                                                                                                                                                                                                                                                                                                                                  | SCOPE 2 EMISSION SOURCES                                                      | SCOPE 3 EMISSION SOURCES 1                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|-------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ENERGY                                                      |                                                                                                                                                                                                                                                                                                                                                                                                                                                           |                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Energy Generation                                           | • Stationary combustion (boilers and turbines used in the production of electricity, heat or steam, fuel pumps, fuel cells, flaring) • Mobile combustion (trucks, barges and trains for transportation of fuels) • Fugitive emissions (CH 4 leakage from transmission and storage facilities, HFC emissions from LPG storage facilities, SF 6 emissions from transmission and distri- bution equipment)                                                   | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (mining and extraction of fuels, energy for refining or processing fuels) • Process emissions (production of fuels, SF 6 emissions 2 ) • Mobile combustion (transportation of fuels/waste, employee business travel, employee commuting) • Fugitive emissions (CH 4 and CO 2 from waste landfills, pipelines, SF 6 emissions)                                                                                                            |
| Oil and Gas 3                                               | • Stationary combustion (process heaters, engines, turbines, flares, incinerators, oxidizers, production of electricity, heat and steam) • Process emissions (process vents, equipment vents, maintenance/turnaround activities, non-routine activities) • Mobile combustion (transportation of raw materials/products/waste; company owned vehicles) • Fugitive emissions (leaks from pressurized equipment, wastewater treatment, surface impoundments) | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (product use as fuel or combus- tion for the production of purchased materials) • Mobile combustion (transportation of raw materials/products/waste, employee business travel, employee commuting, product use as fuel) • Process emissions (product use as feedstock or emis- sions from the production of purchased materials) • Fugitive emissions (CH 4 and CO 2 from waste landfills or from the production of purchased materials) |
| Coal Mining                                                 | • Stationary combustion (methane flaring and use, use of explosives, mine fires) • Mobile combustion (mining equipment, transportation of coal) • Fugitive emissions (CH 4 emissions from coal mines                                                                                                                                                                                                                                                      | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (product use as fuel) • Mobile combustion (transportation of coal/waste, employee business travel, employee commuting) • Process emissions (gasification)                                                                                                                                                                                                                                                                                |
| METALS                                                      |                                                                                                                                                                                                                                                                                                                                                                                                                                                           |                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Aluminum 4                                                  | • Stationary combustion (bauxite to aluminum processing, coke baking, lime, soda ash and fuel use, on-site CHP) •Process emissions (carbon anode oxidation, electrol- ysis, PFC) • Mobile combustion (pre- and post-smelting trans- portation, ore haulers) • Fugitive emissions (fuel line CH 4 , HFC and PFC, SF 6 cover gas)                                                                                                                           | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (raw material processing and coke production by second party suppliers, manufacture of production line machinery) • Mobile combustion (transportation services, business travel, employee commuting) • Process emissions (during production of purchased materials) • Fugitive emissions (mining and landfill CH 4 and CO 2 , outsourced process emissions)                                                                              |
| Iron and Steel 5                                            | • Stationary combustion (coke, coal and carbonate fluxes, boilers, flares) • Process emissions (crude iron oxidation, consumption of reducing agent, carbon content of crude iron/ferroalloys) • Mobile combustion (on-site transportation) • Fugitive emission (CH 4 , N 2 O)                                                                                                                                                                            | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (mining equipment, production of purchased materials) • Process emissions (production of ferroalloys) • Mobile combustion (transportation of raw materials/products/waste and intermediate products) • Fugitive emissions (CH 4 and CO 2 from waste landfills)                                                                                                                                                                           |
| CHEMICALS                                                   |                                                                                                                                                                                                                                                                                                                                                                                                                                                           |                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Nitric acid, Ammonia, Adipic acid, Urea, and Petrochemicals | • Stationary combustion (boilers, flaring, reductive furnaces, flame reactors, steam reformers) • Process emissions (oxidation/reduction of substrates, impurity removal, N 2 O byproducts, catalytic cracking, myriad other emissions individual to each process) • Mobile combustion (transportation of raw materials/products/waste)                                                                                                                   | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (production of purchased mate- rials, waste combustion) • Process emissions (production of purchased materials) • Mobile combustion (transportation of raw materials/products/waste, employee business travel, employee commuting) • Fugitive emissions (CH 4 and CO 2 from waste landfills                                                                                                                                              |

| SECTOR                                        | SCOPE 1 EMISSION SOURCES                                                                                                                                                                                                                                                                                                                                                                                                               | SCOPE 2 EMISSION SOURCES                                                      | SCOPE 3 EMISSION SOURCES                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
|-----------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| MINERALS                                      |                                                                                                                                                                                                                                                                                                                                                                                                                                        |                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Cement and Lime 6                             | • Process emissions (calcination of limestone) • Stationary combustion (clinker kiln, drying of raw materials, production of electricity) • Mobile combustion (quarry operations, on-site transportation)                                                                                                                                                                                                                              | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (production of purchased mate- rials, waste combustion) • Process emissions (production of purchased clinker andlime) • Mobile combustion (transportation of raw materials/products/waste, employee business travel, employee commuting) • Fugitive emissions (mining and landfill CH 4 and CO 2 , outsourced process emissions)                                                                                                                                                 |
| WASTE 7                                       |                                                                                                                                                                                                                                                                                                                                                                                                                                        |                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Landfills, Waste combustion, Water services   | • Stationary combustion (incinerators, boilers, flaring) • Process emissions (sewage treatment, nitrogen loading) • Fugitive emissions (CH 4 and CO 2 emissions from waste and animal product decomposition) • Mobile combustion (transportation of waste/products)                                                                                                                                                                    | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion(recycled waste used as a fuel) • Process emissions (recycled waste used as a feedstock) • Mobile combustion (transportation of waste/products, employee business travel, employee commuting)                                                                                                                                                                                                                                                                                     |
| PULP & PAPER                                  |                                                                                                                                                                                                                                                                                                                                                                                                                                        |                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Pulp and Paper 8                              | • Stationary combustion (production of steam and elec- tricity, fossil fuel-derived emissions from calcination of calcium carbonate in lime kilns, drying products with infrared driers fired with fossil fuels) • Mobile combustion (transportation of raw materials, prod- ucts, and wastes, operation of harvesting equipment) • Fugitive emissions (CH 4 and CO 2 from waste)                                                      | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (production of purchased mate- rials, waste combustion) • Process emissions (production of purchased materials) • Mobile combustion (transportation of raw materials/products/waste, employee business travel, employee commuting) • Fugitive emissions (landfill CH 4 and CO 2 emissions)                                                                                                                                                                                       |
| HFC, PFC, SF 6 & HCFC 22 PRODUCTION 9         | HFC, PFC, SF 6 & HCFC 22 PRODUCTION 9                                                                                                                                                                                                                                                                                                                                                                                                  |                                                                               | HFC, PFC, SF6 & HCFC 22 production                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| HCFC 22 production                            | • Stationary combustion(production of electricity, heat or steam) • Process emissions (HFC venting) • Mobile combustion (transportation of raw materials/products/waste) • Fugitive emissions (HFC use)                                                                                                                                                                                                                                | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (production of purchased materials) • Process emissions (production of purchased materials) • Mobile combustion (transportation of raw materials/prod- ucts/waste, employee business travel, employee commuting) • Fugitive emissions(fugitive leaks in product use, CH 4 and CO 2 from waste landfills)                                                                                                                                                                         |
| SEMICONDUCTOR PRODUCTION                      | SEMICONDUCTOR PRODUCTION                                                                                                                                                                                                                                                                                                                                                                                                               |                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Semiconductor production                      | • Process emissions (C 2 F 6 , CH 4 , CHF 3 , SF 6 , NF 3 , C 3 F 8 , C 4 F 8 , N 2 O used in wafer fabrication, CF 4 created from C 2 F 6 and C 3 F 8 processing) • Stationary combustion (oxidation of volatile organic waste, production of electricity, heat or steam) • Fugitive emissions (process gas storage leaks, container remainders/heel leakage) • Mobile combustion (transportation of raw materials/products/waste) 10 | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (production of imported mate- rials, waste combustion, upstream T&D losses of purchased electricity) • Process emissions (production of purchased materials, outsourced disposal of returned process gases and container remainder/heel) • Mobile combustion (transportation of raw materials/prod- ucts/waste, employee business travel, employee commuting) • Fugitive emissions (landfill CH 4 and CO 2 emissions, down- stream process gas container remainder/heel leakage) |
| OTHER SECTORS                                 | OTHER SECTORS                                                                                                                                                                                                                                                                                                                                                                                                                          |                                                                               | Other Sectors                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| Service sector/ Office based organizations 10 | • Stationary combustion(productionofelectricity, heatorsteam) • Mobile combustion (transportation of raw materials/waste) • Fugitive emissions (mainly HFC emissions during use of refrigeration and air-conditioning equipment)                                                                                                                                                                                                       | • Stationary combustion (consumption of purchased electricity, heat or steam) | • Stationary combustion (production of purchased materials) • Process emissions (production of purchased materials) • Mobile combustion (transportation of raw materials/products/waste, employee business travel, employee commuting)                                                                                                                                                                                                                                                                   |

## Appendix D

<!-- image -->

## NOTES

- 1 Scope 3 activities of outsourcing, contract manufacturing, and franchises are not addressed in this table because the inclusion of specific GHG sources will depend on the nature of the outsourcing.
- 2 Guidelines on unintentional SF 6 process emissions are to be developed.
- 3 The American Petroleum Institute's Compendium of Greenhouse Gas Emissions Methodologies for the Oil and Gas Industry (2004) provides guidelines and calculation methodology for calculating GHG emissions from the oil and gas sector.
- 4 The International Aluminum Institute's Aluminum Sector Greenhouse Gas Protocol (2003), in cooperation with WRI and WBCSD, provides guidelines and tools for calculating GHG emissions from the aluminum sector.
- 5 The International Iron and Steel Institute's Iron and Steel sector guidelines, in cooperation with WRI and WBCSD, are under development.
- 6 The WBCSD Working Group Cement: Toward a Sustainable Cement Industry has developed The Cement CO 2 Protocol: CO 2 Emissions Monitoring and Reporting Protocol for the Cement Industry (2002), which includes guidelines and tools to calculate GHG emissions from the cement sector.
- 7 Guidelines for waste sector are to be developed.
- 8 The Climate Change Working Group of the International Council of Forest and Paper Associations has developed Calculation Tools  for Estimating Greenhouse Gas Emissions from Pulp and Paper Mills (2002), which includes guidelines and tools to calculate GHG emissions from the pulp and paper sector.
- 9 Guidelines for PFC and SF 6 production are to be developed.
- 10 Businesses in 'other sectors' can estimate GHG emissions using cross-sectoral estimation tools-stationary combustion, mobile (transportation) combustion, HFC use, measurement and estimation uncertainty, and waste.
- 11 WRI has developed Working 9 to 5 on Climate Change: An Office Guide (2002) and www.Safeclimate.net, which include guidelines and calculation tools for calculating GHG emissions from officebased organizations.

## Acronyms

CDM Clean Development Mechanism

CEM Continuous Emission Monitoring

CH 4 Methane

CER Certified Emission Reduction

CCAR California Climate Action Registry

CCX Chicago Climate Exchange

CO 2 Carbon Dioxide

CO 2 - e Carbon Dioxide Equivalent

EPER European Pollutant Emission Register

EU ETS European Union Emissions Allowance Trading Scheme

GHG

Greenhouse Gas

GAAP Generally Accepted Accounting Principles

HFCs Hydrofluorocarbons

I P C C Intergovernmental Panel on Climate Change

I P I E C A

International Petroleum Industry

Environmental Conservation Association

I S O International Standards Organization

J I Joint Implementation

N 4 O Nitrous Oxide

NGO Non-Governmental Organization

PFCs

Perfluorocarbons

SF 6 Sulfur Hexafluoride

T &amp; D

Transmission and Distribution

UK ETS United Kingdom Emission Trading Scheme

WBCSD

World Business Council

for Sustainable Development

WRI World Resources Institute

<!-- image -->

Absolute target

A target defined by reduction in absolute emissions over time e.g., reduces CO 2 emissions by 25% below 1994 levels by 2010. (Chapter 11)

Additionality

A criterion for assessing whether a project has resulted in GHG emission reductions or removals in addition to what would have occurred in its absence. This is an important criterion when the goal of the project is to offset emissions elsewhere. (Chapter 8)

Allowance

A commodity giving its holder the right to emit a certain quantity of GHG. (Chapter 11)

Annex 1 countries

Defined in the International Climate Change Convention as those countries taking on emissions reduction obligations: Australia; Austria; Belgium; Belarus; Bulgaria; Canada; Croatia; Czech Republic; Denmark; Estonia; Finland; France; Germany; Greece; Hungary; Iceland; Ireland; Italy; Japan; Latvia; Liechtenstein; Lithuania; Luxembourg; Monaco; Netherlands; New Zealand; Norway; Poland; Portugal; Romania; Russian Federation; Slovakia; Slovenia; Spain; Sweden; Switzerland; Ukraine; United Kingdom; USA.

Associated/affiliated company

The parent company has significant influence over the operating and financial policies of the associated/affiliated company, but not financial control. (Chapter 3)

Audit Trail

Well organized and transparent historical records documenting how an inventory was compiled.

Baseline

A hypothetical scenario for what GHG emissions, removals or storage would have been in the absence of the GHG project or project activity. (Chapter 8)

Base year

A historic datum (a specific year or an average over multiple years) against which a company's emissions are tracked over time. (Chapter 5)

Base year emissions

GHG emissions in the base year. (Chapter 5)

Base year emissions recalculation

Recalculation of emissions in the base year to reflect a change in the structure of the company, or to reflect a change in the accounting methodology used. This ensures data consistency over time, i.e., comparisons of like with like over time. (Chapter 5, 11)

Biofuels

Fuel made from plant material, e.g. wood, straw and ethanol from plant matter (Chapter 4, 9, Appendix B)

Boundaries

GHG accounting and reporting boundaries can have several dimensions, i.e. organizational, opera- tional, geographic, business unit, and target boundaries. The inventory boundary determines which emissions are accounted and reported by the company. (Chapter 3, 4, 11)

Cap and trade system

A system that sets an overall emissions limit, allocates emissions allowances to participants, and allows them to trade allowances and emission credits with each other. (Chapter 2, 8, 11)

Capital Lease

A lease which transfers substantially all the risks and rewards of ownership to the lessee and is accounted for as an asset on the balance sheet of the lessee. Also known as a Financial or Finance Lease. Leases other than Capital/Financial/Finance leases are Operating leases. Consult an accountant for further detail as definitions of lease types differ between various accepted financial standards. (Chapter 4)

Carbon sequestration

The uptake of CO 2 and storage of carbon in biological sinks.

Clean Development Mechanism (CDM)

A mechanism established by Article 12 of the Kyoto Protocol for project-based emission reduction activities in developing countries. The CDM is designed to meet two main objectives: to address the sustainability needs of the host country and to increase the opportunities available to Annex 1 Parties to meet their GHG reduction commitments. The CDM allows for the creation, acquisition and transfer of CERs from climate change mitigation projects undertaken in non-Annex 1 countries.

| Certified Emission Reductions (CERs)             | A unit of emission reduction generated by a CDM project. CERs are tradable commodities that can be used by Annex 1 countries to meet their commitments under the Kyoto Protocol.                                                                                                                                                                                                                                                                                               |
|--------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Co-generation unit/Combined heat and power (CHP) | A facility producing both electricity and steam/heat using the same fuel supply. (Chapter 3)                                                                                                                                                                                                                                                                                                                                                                                   |
| Consolidation                                    | Combination of GHG emissions data from separate operations that form part of one company or group of companies. (Chapter 3, 4)                                                                                                                                                                                                                                                                                                                                                 |
| Control                                          | The ability of a company to direct the policies of another operation. More specifically, it is defined as either operational control (the organization or one of its subsidiaries has the full authority to introduce and implement its operating policies at the operation) or financial control (the organization has the ability to direct the financial and operating policies of the operation with a view to gaining economic benefits from its activities). (Chapter 3) |
| Corporate inventory program                      | A program to produce annual corporate inventories that are in keeping with the principles, standards, and guidance of the GHG Protocol Corporate Standard . This includes all institutional, managerial and technical arrangements made for the collection of data, preparation of a GHG inventory, and imple- mentation of the steps taken to manage the quality of their emission inventory.                                                                                 |
| CO 2 equivalent (CO 2 -e)                        | The universal unit of measurement to indicate the global warming potential (GWP) of each of the six greenhouse gases, expressed in terms of the GWP of one unit of carbon dioxide. It is used to evaluate releasing (or avoiding releasing) different greenhouse gases against a common basis.                                                                                                                                                                                 |
| Cross-sector calculation tool                    | A GHG Protocol calculation tool that addresses GHG sources common to various sectors, e.g. emissions from stationary or mobile combustion. See also GHG Protocol calculation tools (www.ghgprotocol.org).                                                                                                                                                                                                                                                                      |
| Direct GHG emissions                             | Emissions from sources that are owned or controlled by the reporting company. (Chapter 4)                                                                                                                                                                                                                                                                                                                                                                                      |
| Direct monitoring                                | Direct monitoring of exhaust stream contents in the form of continuous emissions monitoring (CEM) or periodic sampling. (Chapter 6)                                                                                                                                                                                                                                                                                                                                            |
| Double counting                                  | Two or more reporting companies take ownership of the same emissions or reductions. (Chapter 3, 4, 8, 11)                                                                                                                                                                                                                                                                                                                                                                      |
| Emissions                                        | The release of GHG into the atmosphere.                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Emission factor                                  | A factor allowing GHG emissions to be estimated from a unit of available activity data (e.g. tonnes of fuel consumed, tonnes of product produced) and absolute GHG emissions. (Chapter 6)                                                                                                                                                                                                                                                                                      |
| Emission Reduction Unit (ERU)                    | A unit of emission reduction generated by a Joint Implementation (JI) project. ERUs are tradable commodities which can be used by Annex 1 countries to help them meet their commitment under the Kyoto Protocol.                                                                                                                                                                                                                                                               |
| Equity share                                     | The equity share reflects economic interest, which is the extent of rights a company has to the risks and rewards flowing from an operation. Typically, the share of economic risks and rewards in an oper- ation is aligned with the company's percentage ownership of that operation, and equity share will normally be the same as the ownership percentage. (Chapter 3)                                                                                                    |
| Estimation uncertainty                           | Uncertainty that arises whenever GHG emissions are quantified, due to uncertainty in data inputs and calculation methodologies used to quantify GHG emissions. (Chapter 7)                                                                                                                                                                                                                                                                                                     |
| Finance lease                                    | A lease which transfers substantially all the risks and rewards of ownership to the lessee and is accounted for as an asset on the balance sheet of the lessee. Also known as a Capital or Financial Lease. Leases other than Capital/Financial/Finance leases are Operating leases. Consult an accountant for further detail as definitions of lease types differ between various accepted accounting principles. (Chapter 4)                                                 |

Fixed asset investment

Fugitive emissions

Green power

Greenhouse gases (GHG)

GHG capture

GHG credit

GHG offset

GHG program

GHG project

GHG Protocol calculation tools

GHG Protocol Initiative

GHG Protocol Project Quantification Standard

GHG Protocol sector specific calculation tools

GHG public report

Equipment, land, stocks, property, incorporated and non-incorporated joint ventures, and partnerships over which the parent company has neither significant influence nor control. (Chapter 3)

Emissions that are not physically controlled but result from the intentional or unintentional releases of GHGs. They commonly arise from the production, processing transmission storage and use of fuels and other chemicals, often through joints, seals, packing, gaskets, etc. (Chapter 4, 6)

A generic term for renewable energy sources and specific clean energy technologies that emit fewer GHG emissions relative to other sources of energy that supply the electric grid. Includes solar photovoltaic panels, solar thermal energy, geothermal energy, landfill gas, low-impact hydropower, and wind turbines. (Chapter 4)

For the purposes of this standard, GHGs are the six gases listed in the Kyoto Protocol: carbon dioxide (CO ); methane (CH ); nitrous oxide (N O); hydrofluorocarbons (HFCs); perfluorocarbons (PFCs); and 2 4 2 sulphur hexafluoride (SF ). 6

Collection of GHG emissions from a GHG source for storage in a sink.

GHG offsets can be converted into GHG credits when used to meet an externally imposed target. A GHG credit is a convertible and transferable instrument usually bestowed by a GHG program. (Chapter 8, 11)

Offsets are discrete GHG reductions used to compensate for (i.e., offset) GHG emissions elsewhere, for example to meet a voluntary or mandatory GHG target or cap. Offsets are calculated relative to a baseline that represents a hypothetical scenario for what emissions would have been in the absence of the mitigation project that generates the offsets. To avoid double counting, the reduction giving rise to the offset must occur at sources or sinks not included in the target or cap for which it is used.

A generic term used to refer to any voluntary or mandatory international, national, sub-national, government or non-governmental authority that registers, certifies, or regulates GHG emissions or removals outside the company. e.g. CDM, EU ETS, CCX, and CCAR.

A specific project or activity designed to achieve GHG emission reductions, storage of carbon, or enhancement of GHG removals from the atmosphere. GHG projects may be stand-alone projects, or specific activities or elements within a larger non-GHG related project. (Chapter 8, 11)

A number of cross-sector and sector-specific tools that calculate GHG emissions on the basis of activity data and emission factors (available at www.ghgprotocol.org).

A multi-stakeholder collaboration convened by the World Resources Institute and World Business Council for Sustainable Development to design, develop and promote the use of accounting and reporting standards for business. It comprises of two separate but linked standards-the GHG Protocol Corporate Accounting and Reporting Standard and the GHG Protocol Project Quantification Standard.

An additional module of the GHG Protocol Initiative addressing the quantification of GHG reduction projects. This includes projects that will be used to offset emissions elsewhere and/or generate credits. More information available at www.ghgprotocol.org. (Chapter 8, 11)

A GHG calculation tool that addresses GHG sources that are unique to certain sectors, e.g., process emissions from aluminum production. (see also GHG Protocol Calculation tools)

Provides, among other details, the reporting company's physical emissions for its chosen inventory boundary. (Chapter 9)

GHG registry

A public database of organizational GHG emissions and/or project reductions. For example, the US Department of Energy 1605b Voluntary GHG Reporting Program, CCAR, World Economic Forum's Global GHG Registry. Each registry has its own rules regarding what and how information is reported. (Introduction, Chapter 2, 5, 8, 10)

GHG removal

Absorbtion or sequestration of GHGs from the atmosphere.

GHG sink

Any physical unit or process that stores GHGs; usually refers to forests and underground/deep sea reservoirs of CO . 2

GHG source

Any physical unit or process which releases GHG into the atmosphere.

GHG trades

All purchases or sales of GHG emission allowances, offsets, and credits.

Global Warming Potential (GWP)

A factor describing the radiative forcing impact (degree of harm to the atmosphere) of one unit of a given GHG relative to one unit of CO . 2

Group company/ subsidiary

The parent company has the ability to direct the financial and operating policies of a group company/subsidiary with a view to gaining economic benefits from its activities. (Chapter 3)

Heating value

The amount of energy released when a fuel is burned completely. Care must be taken not to confuse higher heating values (HHVs), used in the US and Canada, and lower heating values, used in all other countries (for further details refer to the calculation tool for stationary combustion available at www.ghgprotocol.org).

Indirect GHG emissions

Emissions that are a consequence of the operations of the reporting company, but occur at sources owned or controlled by another company. (Chapter 4)

Insourcing

The administration of ancillary business activities, formally performed outside of the company, using resources within a company. (Chapter 3, 4, 5, 9)

Intensity ratios

Ratios that express GHG impact per unit of physical activity or unit of economic value (e.g. tonnes of CO 2 emissions per unit of electricity generated). Intensity ratios are the inverse of productivity/effi- ciency ratios. (Chapter 9, 11)

Intensity target

A target defined by reduction in the ratio of emissions and a business metric over time e.g., reduce CO 2 per tonne of cement by 12% between 2000 and 2008. (Chapter 11)

Intergovernmental Panel on Climate Change (IPCC)

International body of climate change scientists. The role of the IPCC is to assess the scientific, technical and socio-economic information relevant to the understanding of the risk of human-induced climate change (www.ipcc.ch).

Inventory

A quantified list of an organization's GHG emissions and sources.

Inventory boundary

An imaginary line that encompasses the direct and indirect emissions that are included in the inven- tory. It results from the chosen organizational and operational boundaries. (Chapter 3, 4)

Inventory quality

The extent to which an inventory provides a faithful, true and fair account of an organization's GHG emissions. (Chapter 7)

Joint Implementation (JI)

The JI mechanism was established in Article 6 of the Kyoto Protocol and refers to climate change miti- gation projects implemented between two Annex 1 countries. JI allows for the creation, acquisition and transfer of 'emission reduction units' (ERUs).

Kyoto Protocol

A protocol to the United Nations Framework Convention on Climate Change (UNFCCC). Once entered into force it will require countries listed in its Annex B (developed nations) to meet reduction targets of GHG emissions relative to their 1990 levels during the period of 2008-12.

Leakage (Secondary effect)

Leakage occurs when a project changes the availability or quantity of a product or service that results in changes in GHG emissions elsewhere. (Chapter 8)

Life Cycle Analysis

Assessment of the sum of a product's effects (e.g. GHG emissions) at each step in its life cycle, including resource extraction, production, use and waste disposal. (Chapter 4)

Material discrepancy

An error (for example from an oversight, omission, or miscalculation) that results in the reported quantity being significantly different to the true value to an extent that will influence performance or decisions. Also known as material misstatement.(Chapter 10)

Materiality threshold

A concept employed in the process of verification. It is often used to determine whether an error or omission is a material discrepancy or not. It should not be viewed as a de minimus for defining a complete inventory. (Chapter 10)

Mobile combustion

Burning of fuels by transportation devices such as cars, trucks, trains, airplanes, ships etc. (Chapter 6)

Model uncertainty

GHG quantification uncertainty associated with mathematical equations used to characterize the relationship between various parameters and emission processes. (Chapter 7)

Non-Annex 1 countries

Countries that have ratified or acceded to the UNFCC but are not listed under Annex 1 and are there- fore not under any emission reduction obligation (see also Annex 1 countries).

Operation

A generic term used to denote any kind of business, irrespective of its organizational, governance, or legal structures. An operation can be a facility, subsidiary, affiliated company or other form of joint venture. (Chapter 3, 4)

Operating lease

A lease which does not transfer the risks and rewards of ownership to the lessee and is not recorded as an asset in the balance sheet of the lessee. Leases other than Operating leases are Capital/Financial/Finance leases. Consult an accountant for further detail as definitions of lease types differ between various accepted financial standards. (Chapter 4)

Operational boundaries

The boundaries that determine the direct and indirect emissions associated with operations owned or controlled by the reporting company. This assessment allows a company to establish which operations and sources cause direct and indirect emissions, and to decide which indirect emissions to include that are a consequence of its operations. (Chapter 4)

Organic growth/decline

Increases or decreases in GHG emissions as a result of changes in production output, product mix, plant closures and the opening of new plants. (Chapter 5)

Organizational boundaries

The boundaries that determine the operations owned or controlled by the reporting company, depending on the consolidation approach taken (equity or control approach). (Chapter 3)

Outsourcing

The contracting out of activities to other businesses. (Chapter 3, 4, 5)

Parameter uncertainty

GHG quantification uncertainty associated with quantifying the parameters used as inputs to estima- tion models. (Chapter 7)

Primary effects

The specific GHG reducing elements or activities (reducing GHG emissions, carbon storage, or enhancing GHG removals) that the project is intended to achieve. (Chapter 8)

Process emissions

Emissions generated from manufacturing processes, such as the CO 2 that is arises from the break- down of calcium carbonate (CaCO ) during cement manufacture. (Chapter 4, Appendix D) 3

Productivity/efficiency ratios

Ratios that express the value or achievement of a business divided by its GHG impact. Increasing effi- ciency ratios reflect a positive performance improvement. e.g. resource productivity(sales per tonne GHG). Productivity/efficiency ratios are the inverse of intensity ratios. (Chapter 9)

Ratio indicator

Indicators providing information on relative performance such as intensity ratios or productivity/effi- ciency ratios. (Chapter 9)

Renewable energy

Energy taken from sources that are inexhaustible, e.g. wind, water, solar, geothermal energy, and biofuels.

Reporting

Presenting data to internal management and external users such as regulators, shareholders, the general public or specific stakeholder groups. (Chapter 9)

Reversibility of reductions

This occurs when reductions are temporary, or where removed or stored carbon may be returned to the atmosphere at some point in the future. (Chapter 8)

Rolling base year

The process of shifting or rolling the base year forward by  a certain number of years at regular inter- vals of time. (Chapter 5, 11)

Scientific Uncertainty

Uncertainty that arises when the science of the actual emission and/or removal process is not completely understood. (Chapter 7)

Scope

Defines the operational boundaries in relation to indirect and direct GHG emissions. (Chapter 4)

Scope 1 inventory

A reporting organization's direct GHG emissions. (Chapter 4)

Scope 2 inventory

A reporting organization's emissions associated with the generation of electricity, heating/ cooling, or steam purchased for own consumption. (Chapter 4)

Scope 3 inventory

A reporting organization's indirect emissions other than those covered in scope 2. (Chapter 4)

Scope of works

An up-front specification that indicates the type of verification to be undertaken and the level of assurance to be provided between the reporting company and the verifier during the verification process. (Chapter 10)

Secondary effects (Leakage)

GHG emissions changes resulting from the project not captured by the primary effect(s). These are typically the small, unintended GHG consequences of a project. (Chapter 8)

Sequestered atmospheric carbon

Carbon removed from the atmosphere by biological sinks and stored in plant tissue. Sequestered atmospheric carbon does not include GHGs captured through carbon capture and storage.

Significance threshold

A qualitative or quantitative criteria used to define a significant structural change. It is the responsi- bility of the company/ verifier to determine the 'significance threshold' for considering base year emissions recalculation. In most cases the 'significance threshold' depends on the use of the infor- mation, the characteristics of the company, and the features of structural changes. (Chapter 5)

Stationary Combustion

Burning of fuels to generate electricity, steam, heat, or power in stationary equipment such as boilers, furnaces etc.

Structural change

A change in the organizational or operational boundaries of a company that result in the transfer of ownership or control of emissions from one company to another. Structural changes usually result from a transfer of ownership of emissions, such as mergers, acquisitions, divestitures, but can also include outsourcing/ insourcing. (Chapter 5)

Target base year

The base year used for defining a GHG target, e.g. to reduce CO 2 emissions 25% below the target base year levels by the target base year 2000 by the year 2010. (Chapter 11)

Target boundary

The boundary that defines which GHG's, geographic operations, sources and activities are covered by the target. (Chapter 11)

Target commitment period

The period of time during which emissions performance is actually measured against the target. It ends with the target completion date. (Chapter 11)

Target completion date

The date that defines the end of the target commitment period and determines whether the target is relatively short- or long-term. (Chapter 11)

Target double counting policy

Uncertainty

United Nations Framework Convention on Climate Change (UNFCCC)

Value chain emissions

A policy that determines how double counting of GHG reductions or other instruments, such as allowances issued by external trading programs, is dealt with under a GHG target. It applies only to companies that engage in trading (sale or purchase) of offsets or whose corporate target boundaries interface with other companies' targets or external programs. (Chapter 11)

- 1. Statistical definition: A parameter associated with the result of a measurement that characterizes the dispersion of the values that could be reasonably attributed to the measured quantity. (e.g., the sample variance or coefficient of variation). (Chapter 7)
- 2. Inventory definition: A general and imprecise term which refers to the lack of certainty in emissionsrelated data resulting from any causal factor, such as the application of non-representative factors or methods, incomplete data on sources and sinks, lack of transparency etc. Reported uncertainty information typically specifies a quantitative estimates of the likely or perceived difference between a reported value and a qualitative description of the likely causes of the difference. (Chapter 7).

Signed in 1992 at the Rio Earth Summit, the UNFCCC is a milestone Convention on Climate Change treaty that provides an overall framework for international efforts to (UNFCCC) mitigate climate change. The Kyoto Protocol is a protocol to the UNFCCC.

Emissions from the upstream and downstream activities associated with the operations of the reporting company. (Chapter 4)

Verification

An independent assessment of the reliability (considering completeness and accuracy) of a GHG inventory. (Chapter 10)

<!-- image -->

API (2004), Compendium of Greenhouse Gas Emissions Methodologies for the Oil and Gas Industry, Final Draft, American Petroleum Institute

BP (2000), Environmental Performance: Group Reporting Guidelines, Version 2.2

CCAR (2003), General Reporting Guidelines, California Climate Action Registry

DEFRA (2003), Guidelines for the Measurement and Reporting of Emissions by direct participants in the UK Emissions Trading Scheme, UK Department for Environment, Food and Rural Affairs, London, UK ETS(01)05rev2

EC-DGE (2000), Guidance Document for EPER Implementation, European Commission Directorate-General for Environment

EPA (1999), Emission Inventory Improvement Program, Volume VI: Quality Assurance/Quality Control, U.S. Environmental Protection Agency

Georgia Pacific (2002), Protocol for the Inventory of Greenhouse Gases in Georgia-Pacific Corporation, Georgia-Pacific Corporation, Atlanta

GRI (2002), Global Reporting Initiative, Sustainability Reporting Guidelines, Global Reporting Initiative

IAI (2003), Aluminum Sector Greenhouse Gas Protocol, International Aluminum Institute

ICFPA (2002), Calculation Tools and for Estimating Greenhouse Gas Emissions from Pulp and Paper Mills, Climate Change Working Group of the International Council of Forest and Paper Associations

IPCC (1996), Revised IPCC Guidelines for National GHG Inventories: Reference Manual, Intergovernmental Panel on Climate Change

IPCC (1997), Revised 1996 IPCC Guidelines for National Greenhouse Gas Inventories, Intergovernmental Panel on Climate Change

IPCC (1998), Evaluating Approaches for Estimating Net Emissions of Carbon Dioxide from Forest Harvesting and Wood Products, by S. Brown , B. Lim , and B. Schlamadinger , Intergovernmental Panel on Climate Change

IPCC (2000a), Good Practice Guidance and Uncertainty Management in National Greenhouse Gas Inventories, Intergovernmental Panel on Climate Change

IPCC (2000b), Land Use, Land Use Change, and Forestry: A Special Report of the IPCC, Intergovernmental Panel on Climate Change. Cambridge University Press, Cambridge, UK

IPIECA (2003), Petroleum Industry Guidelines for Reporting Greenhouse Gas Emissions, International Petroleum Industry Environmental Conservation Association, London

ISO (1999), International Standard on Environmental Performance Evaluation, (ISO 14031), International Standard Organization, Geneva

KPMG (2000), Global Accounting: UK, US, IAS and Netherlands Compared, 2nd Edition, KPMG Accountants NV

NZBCSD (2002), The Challenge of GHG Emissions: the 'why' and 'how' of accounting and reporting for GHG emissions: An Industry Guide, New Zealand Business Council for Sustainable Development, Auckland

Ontario MOE (2001), Airborne Contaminant Discharge Monitoring and Reporting, Ontario Ministry of the Environment, Toronto, Ontario Regulation 127/01

UNFCCC (2000), Synthesis Report on National Greenhouse Gas Information Reported by Annex I Parties for the Land-Use Change and Forestry Sector and Agricultural Soils Category, FCCC/TP/1997/5, United Nations Framework Convention on Climate Change

Verfaillie, H. , and R. Bidwell (2000), Measuring Eco-efficiency: A Guide to Reporting Company Performance, World Business Council for Sustainable Development, Geneva

WBCSD (2001), The Cement CO 2 Protocol: CO 2 Emissions Monitoring and Reporting Protocol for the Cement Industry, World Business Council for Sustainable Development: Working Group Cement, Geneva

WRI (2002), Working 9 to 5 on Climate Change: An Office Guide, World Resources Institute, Washington, DC

WRI (2003), Renewable Energy Certificates: An Attractive Means for Corporate Customers to Purchase Renewable Energy, World Resources Institute, Washington, DC

## Contributors

## Structured Feedback Companies (REVISED EDITION)

AstraZeneca

Birka Energi

Eastman Kodak Co.

ENDESA

IKEA International A / S

Interface, Inc.

Kansai Electric Power Company

Nike, Inc.

Norsk Hydro

N.V. Nuon Renewable Energy

Philips &amp; Yaming Co., Ltd.

Seattle City Light

Simplex Mills Co. Ltd.

Sony Corporation

STMicroelectronics

Tata Iron &amp; Steel Company Ltd.

Tokyo Electric Power Company

Tokyo Gas Co. Ltd.

We Energies

## Road Testers  (FIRST EDITION)

Baxter International

BP

CODELCO

Duncans Industries

Dupont Company

Ford Motor Company

Fortum Power and Heat

General Motors Corporation

Hindalco Industries

IBM Corporation

Maihar Cement

Nike, Inc.

Norsk Hydro

Ontario Power Generation

Petro-Canada

PricewaterhouseCoopers road tested with European companies in the non-ferrous metal sector

Public Service Electric and Gas

Shree Cement

Shell Canada

Suncor Energy

Tokyo Electric Power Company

Volkswagen

World Business Council for Sustainable Development

World Resources Institute

500 PPM road tested with several small and medium companies in Germany

## WRI &amp; WBCSD GHG Protocol Initiative Team (FIRST EDITION)

Janet Ranganathan

World Resources Institute

Pankaj Bhatia

World Resources Institute

David Moorcroft

World Business Council for Sustainable Development

Jasper Koch

World Business Council for Sustainable Development

## Project Management Team (FIRST EDITION)

Brian Smith

Innovation Associates

Hans Aksel Haugen

Norsk Hydro

Vicki Arroyo

Pew Center on Climate Change

Aidan J. Murphy

Royal Dutch/ Shell

Sujata Gupta

The Energy Research Institute

Yasuo Hosoya

Tokyo Electric Power Company

Rebecca Eaton

World Wildlife Fund

## Contributors

Heather Tansey

3M Corporation

Ingo Puhl

500 PPM

Dawn Fenton

ABB

Christian Kornevall

ABB

Paul-Antoine Lacour

AFOCEL

Kenneth Martchek

Alcoa

Vince Van Son

Alcoa

Ron Nielsen

Alcan

Steve Pomper

Alcan

Pat Quinn

Allegheny Energy

Joe Cascio Booz

Allen &amp; Hamilton Inc.

David Jaber

Alliance to Save Energy

Alain Bill

Alstom Power Environment

Robert Greco

American Petroleum Institute

Walter C. Retzsch

American Petroleum Institute

Karen Ritter

American Petroleum Institute

Tom Carter

American Portland Cement Alliance

Dale Louda

American Portland Cement Alliance

Ted Gullison

Anova

J Douglas Akerson

Aon Risk Services of Texas Inc

John Molburg

Argonne National Laboratory

Sophie Jabonski

Arthur Anderson

Fiona Gadd

Arthur Andersen

Christophe Scheitzky

Arthur Andersen

Scot Foster

Arthur D. Little

Mike Isenberg

Arthur D. Little

Bill Wescott

Arthur D. Little

Keith Moore

AstraZeneca

Birgita Thorsin

AstraZeneca

Thomas E. Werkem

Atofina Chemicals

Jean-Bernard Carrasco

Australian Greenhouse Office

David Harrison

Australian Greenhouse Office

Bronwyn Pollock

Australian Greenhouse Office

Linda Powell

Australian Greenhouse Office

James Shevlin

Australian Greenhouse Office

Chris Loreti

Battelle Memorial Institute

Ronald E. Meissen

Baxter International

Göran Andersson

Birka Energi

Sofi Harms-Ringdahl

Birka Energi

Britt Sahlestrom

Birka Energi

David Evans

BP

Nick Hughes

BP

Tasmin Lishman

BP

Mark Barthel

British Standards Institution

JoAnna Bullock

Business for Social Responsibility

Robyn Camp

California Climate Action Registry

Jill Gravender

California Climate Action Registry

Dianne Wittenberg

California Climate Action Registry

David Cahn

California Portland Cement

Paul Blacklock

Calor Gas Limited

Julie Chiaravalli

Cameron-Cole

Connie Sasala

Cameron-Cole

Evan Jones

Canada's Climate Change Voluntary Challenge and Registry Inc.

Alan D. Willis

Canadian Institute of Chartered Accountants

Miguel A Gonzalez

CEMEX

Carlos Manuel Duarte Oliveira

CEMEX

Inna Gritsevich

CENEf

(Center for Energy Efficiency)

Ellina Levina

Center for Clean Air Policy

Steve Winkelman

Center for Clean Air Policy

Aleg Cherp

Central European University (Hungary) and ECOLOGIA

Mark Fallon

CH2M Hill

Lisa Nelowet Grice

CH2M Hill

Arthur Lee

ChevronTexaco

William C. McLeod

ChevronTexaco

Susann Nordrum

ChevronTexaco

Alice LeBlanc

Chicago Climate Exchange

Charlene R. Garland

Clean Air-Cool Planet

Donna Boysen

Clean Energy Group

Jennifer DuBose

Climate Neutral Network

Sue Hall

Climate Neutral Network

Karen Meadows

Climate Neutral Network

Michael Burnett

Climate Trust

David Olsen

Clipper Windpower

Marco Bedoya

Cimpor

Jose Guimaraes

Cimpor

## Contributors

Elizabeth Arner

CO2e.com/Cantor Fitzgerald

Fernando E. Toledo

CODELCO

Bruce Steiner

Collier Shannon Scott

Lynn Preston

Collins &amp; Aikman

Annick Carpentier

Confederation of European Paper Industries

K.P. Nyati

Confederation of Indian Industry

Sonal Pandya

Conservation International

Michael Totten

Conservation International

Dominick J. Mormile

Consolidated Edison Company

John Kessels

CRL Energy Ltd.

Ian Lewis

Cumming Cockburn Limited

Raymond P. Cote

Dalhousie University

Olivia Hartridge

DEFRA/European Commission

Robert Casamento

Deloitte &amp; Touche

Markus Lehni

Deloitte &amp; Touche

Flemming Tost

Deloitte &amp; Touche

Philip Comer

Det Norske Veritas

Simon Dawes

Det Norske Veritas

Trygve Roed Larsen

Det Norske Veritas

Einar Telnes

Det Norske Veritas

Kalipada Chatterjee

Development Alternatives

Vivek Kumar

Development Alternatives

Samrat Sengupta

Development Alternatives

Francesco Balocco

The Dow Chemical Company

Paul Cicio

The Dow Chemical Company

Frank Farfone

The Dow Chemical Company

Peter Molinaro

The Dow Chemical Company

Scott Noesen

The Dow Chemical Company

Stephen Rose

The Dow Chemical Company

Jorma Salmikivi

The Dow Chemical Company

Don Hames

The Dow Chemical Company

R. Swarup

Duncans Industries

John B. Carberry

DuPont Company

David Childs

DuPont Company

John C. DeRuyter

Dupont Company

Tom Jacob

DuPont Company

Mack McFarland

DuPont Company

Ed Mongan

DuPont Company

Ron Reimer

DuPont Company

Paul Tebo

DuPont Company

Fred Whiting

DuPont Company

Roy Wood

Eastman Kodak Co.

Jochen Harnisch

ECOFYS

Alan Tate

Ecos Corporation

Pedro Moura Costa

EcoSecurities

Justin Guest

EcoSecurities

D. Gary Madden

Emission Credit LLC

Kyle L. Davis

Edison Mission Energy/ MidAmerican Energy Holdings Co.

Maria Antonia Abad Puértolas

ENDESA

David Corregidor Sanz

ENDESA

Elvira Elso Torralba

ENDESA

Joel Bluestein

Energy &amp; Environmental Analysis, Inc.

Y P Abbi

The Energy Research Institute

Girish Sethi

The Energy Research Institute

Vivek Sharma

The Energy Research Institute

Crosbie Baluch

Energetics Pty. Ltd.

Marcus Schneider

Energy Foundation

David Crossley

Energy Futures Australia Pty Ltd

Patrick Nollet

Entreprises pour l'Environnement Envinta

James L. Wolf

Kenneth Olsen

Environment Canada

Adrian Steenkamer

Environment Canada

Millie Chu Baird

Environmental Defense

Sarah Wade

Environmental Defense

Satish Kumar

Environmental Energy Technologies

John Cowan

Environmental Interface

Edward W. Repa

Environmental Research and Education Foundation

Tatiana Bosteels

Environmental Resources Management

William B. Weil

Environmental Resources Management

Wiley Barbour

Environmental Resources Trust

Barney Brannen

Environmental Resources Trust

Ben Feldman

Environmental Resources Trust

Al Daily

Environmental Synergy

Anita M. Celdran

Environmental Technology Evaluation Center

William E. Kirksey

Environmental Technology Evaluation Center

James Bradbury

EPOTEC

Alan B. Reed

EPOTEC

Daniele Agostini

Ernst &amp; Young

Juerg Fuessler

Ernst Basler &amp; Partners

Stefan Larsson

ESAB

Lutz Blank

European Bank for Reconstruction and Development

Alke Schmidt

European Bank for Reconstruction and Development

Peter Vis

European Commission

Chris Evers

European Commission

Yun Yang

ExxonMobil Research &amp; Engineering Company

Urs Brodmann

Factor Consulting and Management

M.A. J. Jeyaseelan

Federation of Indian Chambers of Commerce &amp; Industry

Anu Karessuo

Finnish Forest Industries Federation

Tod Delaney

First Environment

Brian Glazebrook

First Environment

James D. Heeren

First Environment

James T. Wintergreen

First Environment

Kevin Brady

Five Winds International

Duncan Noble

Five Winds International

Steven Young

Five Winds International

Larry Merritt

Ford Motor Company

Chad McIntosh

Ford Motor Company

John Sullivan

Ford Motor Company

Debbie Zemke

Ford Motor Company

Dan Blomster

Fortum Power and Heat

Arto Heikkinen

Fortum Power and Heat

Jussi Nykanen

Fortum Power and Heat

Steven Hellem

Global Environment Management Initiative

Judith M. Mullins

General Motors Corporation

Terry Pritchett

General Motors Corporation

Richard Schneider

General Motors Corporation

Robert Stephens

General Motors Corporation

Kristin Zimmerman

General Motors Corporation

Mark Starik

George Washington University

Michael Rumberg

Gerling Group of Insurances

Jeffrey C. Frost

GHG Spaces

T. Imai

Global Environment and Energy Group

Joseph Romm

Global Environment and Technology Foundation

Arthur H Rosenfeld

Global Environment and Technology Foundation

Dilip Biswas

Government of India Ministry of Environment &amp; Forests

Matthew DeLuca

Green Mountain Energy

Richard Tipper

Greenergy ECCM

Ralph Taylor

Greenleaf Composting Company

Glenna Ford

GreenWare Environmental Systems

Nickolai Denisov

GRID-Arendal / Hindalco Industries

Y.K. Saxena

Gujarat Ambuja Cement

Mihir Moitra

Hindalco Industries Ltd.

Claude Culem

Holcim

Adrienne Williams

Holcim

Mo Loya

Honeywell Allied Signal

Edan Dionne

IBM Corporation

Ravi Kuchibhotla

IBM Corporation

Thomas A. Cortina

ICCP

Paul E. Bailey

ICF Consulting

Anne Choate

ICF Consulting

Craig Ebert

ICF Consulting

Marcia M. Gowen

ICF Consulting

Kamala R. Jayaraman

ICF Consulting

Richard Lee

ICF Consulting

Diana Paper

ICF Consulting

Frances Sussman

ICF Consulting

Molly Tirpak

ICF Consulting

Thomas Bergmark

IKEA International A / S

Eva May Lawson

IKEA International A / S

Mona Nilsson

IKEA International A / S

Othmar Schwank

INFRAS

Roel Hammerschlag

Institute for Lifecycle Energy Analysis

Shannon Cox

Interface Inc.

Buddy Hay

Interface Inc.

Alyssa Tippens

Interface Inc.

Melissa Vernon

Interface Inc.

Willy Bjerke

International Aluminum Institute

Jerry Marks

International Aluminum Institute

Robert Dornau

International Emissions Trading Association

## Contributors

Andrei Marcu

International Emissions Trading Association

Akira Tanabe

International Finance Corporation

George Thomas

International Finance Corporation

Danny L. Adams

International Paper Company

Julie C. Brautigam

International Paper Company

Carl Gagliardi

International Paper Company

Thomas C. Jorling

International Paper Company

Mark E. Bateman

Investor Responsibility Research Center

S.K. Bezbaroa

ITC Ltd.

H.D. Kulkami

ITC Ltd.

Michael Nesbit

JAN Consultants

Chris Hunter

Johnson &amp; Johnson International

Harry Kaufman

Johnson &amp; Johnson International

Daniel Usas

Johnson &amp; Johnson Worldwide Engineering Services

Shintaro Yokokawa

Kansai Electric Power Co.

Iain Alexander

KPMG

Giulia Galluccio

KPMG

Lisa Gibson

KPMG

Jed Jones

KPMG

Sophie Punte

KPMG

Michele Sanders

KPMG

Chris Boyd

Lafarge Corporation

David W. Carroll

Lafarge Corporation

Ed Vine

Lawrence Berkeley National Laboratory

Richard Kahle

Lincoln Electric Service

Michael E. Canes

Logistics Management Institute

Erik Brejla

The Louis Berger Group

Michael J. Bradley

M.J. Bradley &amp; Associates

Brian Jones

M.J. Bradley &amp; Associates

Craig McBernie

McBernie QERL

Tracy Dyson

Meridian Energy Limited

Tim Mealey

Meridian Institute

Maria Wellisch

MWA Consultants

Margriet Kuijper

NAM

Sukumar Devotta

National Chemical Laboratory

Neil B. Cohn

Natsource

Garth Edward

Natsource

Robert Youngman

Natsource

Dale S. Bryk

Natural Resources Defense Council

Jeff Fiedler

Natural Resources Defense Council

Brad Upton

NCASI

Timothy J. Roskelley

NESCAUM

Matthew W. Addison

Nexant

Atulya Dhungana

Nexant

David H. King

Niagara Mohawk Power Corporation

Martin A. Smith

Niagara Mohawk Power Corporation

Jim Goddard

Nike Inc.

Leta Winston

Nike Inc.

Amit Meridor

NILIT

Karina Aas

Norsk Hydro

Jos van Danne

Norsk Hydro

Hans Goosens

Norsk Hydro

Jon Rytter Hasle

Norsk Hydro

Tore K. Jenssen

Norsk Hydro

Halvor Kvande

Norsk Hydro

Bernt Malme

Norsk Hydro

Lillian Skogen

Norsk Hydro

Jostein Soreide

Norsk Hydro

Lasse Nord

Norsk Hydro

Thor Lobben

Norske Skogindustrier ASA

Morton A. Barlaz

North Carolina State University

Geir Husdal

Novatech

Gard Pedersen

Novatech

Ron Oei

Nuon N.V.

Jan Corfee-Morlot

OECD

Stephane Willems

OECD

Anda Kalvins

Ontario Power Generation

Mikako Kokitsu

Osaka Gas Co.

Greg San Martin

Pacific Gas and Electric Company

Ken Humphreys

Pacific Northwest National Laboratory

Michael Betz

PE Europe GmbH

Kathy Scales

Petro-Canada

Judith Greenwald

Pew Center

Naomi Pena

Pew Center

Daniel L. Chartier

PG&amp;E Generating

Zhang Fan

Philips &amp; Yaming Co. Ltd.

Xue Gongren

Philips &amp; Yaming Co. Ltd.

Orestes R. Anastasia

Planning and Development Collaborative International

Robert Hall

Platts Research and Consulting

Neil Kolwey

Platts Research and Consulting

David B. Sussman

Poubelle Associates

Bill Kyte

Powergen

Surojit Bose

PricewaterhouseCoopers

Melissa Carrington

PricewaterhouseCoopers

Rachel Cummins

PricewaterhouseCoopers

Len Eddy

PricewaterhouseCoopers

Dennis Jennings

PricewaterhouseCoopers

Terje Kronen

PricewaterhouseCoopers

Craig McBurnie

PricewaterhouseCoopers

Olivier Muller

PricewaterhouseCoopers

Dorje Mundle

PricewaterhouseCoopers

Thierry Raes

PricewaterhouseCoopers

Alain Schilli

PricewaterhouseCoopers

Hans Warmenhoven

PricewaterhouseCoopers

Pedro Maldonado

PRIEN

Alfredo Munoz

PRIEN

Mark S. Brownstein

PSEG

James Hough

PSEG

Samuel Wolfe

PSEG

Vinayak Khanolkar

Pudumjee Pulp &amp; Paper Mills Ltd.

Federica Ranghieri

Ranghieri &amp; Associates

Jennifer Lee

Resources for the Future

Kaj Embren

Respect Europe

Mei Li Han

Respect Europe

David W. Cross

The RETEC Group

Alan Steinbeck

Rio Tinto

Katie Smith

RMC Group

Rick Heede

Rocky Mountain Institute

Chris Lotspeich

Rocky Mountain Institute

Anita M. Burke

Royal Dutch / Shell

David Hone

Royal Dutch / Shell

Thomas Ruddy

Ruddy Consultants

Julie Doherty

Science Applications Intl. Corp.

Richard Y. Richards

Science Applications Intl. Corp.

Corinne Grande

Seattle City Light

Doug Howell

Seattle City Light

Edwin Aalders

SGS

Irma Lubrecht

SGS

Gareth Phillips

SGS

Antoine de La Rochefordière

SGS

Murray G. Jones

Shell Canada

Sean Kollee

Shell Canada

Rick Weidel

Shell Canada

Pipope Siripatananon

Siam Cement

J.P . Semwal

Simplex Mills Co. Ltd.

Ros Taplin

SMEC Environment

Robert K. Ham

Solid &amp; Hazardous Waste Engineering

Jeremy K. O'Brien

Solid Waste Association of North America

Hidemi Tomita

Sony Corporation

Gwen Parker

Stanford University

Georges Auguste

STMicroelectronics

Ivonne Bertoncini

STMicroelectronics

Giuliano Boccalletti

STMicroelectronics

Eugenio Ferro

STMicroelectronics

Philippe Levavasseur

STMicroelectronics

Geoffrey Johns

Suncor Energy

Manuele de Gennaro

Swiss Federal Institute of Technology, ETH Zurich

Markus Ohndorf

Swiss Federal Institute of Technology, ETH Zurich

Matthias Gysler

Swiss Federal Office for Energy

Christopher T. Walker

Swiss Reinsurance Co.

Gregory A. Norris

Sylvatica

GS Basu

Tata Iron &amp; Steel Company Ltd.

RP Sharma

Tata Iron &amp; Steel Company Ltd.

Robert Graff

Tellus Institute

Sivan Kartha

Tellus Institute

Michael Lazarus

Tellus Institute

Allen L. White

Tellus Institute

Will Gibson

Tetra Tech Em Incorporated

Satish Malik

Tetra Tech Em Incorporated

Fred Zobrist

Tetra Tech Em Incorporated

Sonal Agrawal

Tetra Tech India

Ranjana Ganguly

Tetra Tech India

Ashwani Zutshi

Tetra Tech India

Mark D. Crowdis

Think Energy

| Tinus Pulles      | TNO MEP                              |
|-------------------|--------------------------------------|
| Yasushi Hieda     | Tokyo Electric Power Co. Ltd         |
| Midori Sasaki     | Tokyo Electric Power Co. Ltd.        |
| Tsuji Yoshiyuki   | Tokyo Electric Power Co. Ltd.        |
| Hiroshi Hashimoto | Tokyo Gas Co. Ltd.                   |
| Takahiro Nagata   | Tokyo Gas Co. Ltd                    |
| Kentaro Suzawa    | Tokyo Gas Co. Ltd.                   |
| Satoshi Yoshida   | Tokyo Gas Co. Ltd.                   |
| Ralph Torrie      | Torrie Smith Associates              |
| Manuela Ojan      | Toyota Motor Company                 |
| Eugene Smithart   | Trane Company                        |
| Laura Kosloff     | Trexler & Associates                 |
| Mark Trexler      | Trexler & Associates                 |
| Walter Greer      | Trinity Consultants                  |
| Jochen Mundinger  | University of Cambridge              |
| Hannu Nilsen      | UPM-Kymmene Corporation              |
| Nao Ikemoto       | U.S. Asia Environmental Partnership  |
| Stephen Calopedis | U.S. Department of Energy            |
| Gregory H. Kats   | U.S. Department of Energy            |
| Dick Richards     | U.S. Department of Energy            |
| Arthur Rosenfeld  | U.S. Department of Energy            |
| Arthur Rypinski   | U.S. Department of Energy            |
| Monisha Shah      | U.S. Department of Energy            |
| Tatiana Strajnic  | U.S. Department of Energy            |
| Kenneth Andrasko  | U.S. Environmental Protection Agency |
| Jan Canterbury    | U.S. Environmental Protection Agency |
| Ed Coe            | U.S. Environmental Protection Agency |
| Lisa H. Chang     | U.S. Environmental Protection Agency |
| Andrea Denny      | U.S. Environmental Protection Agency |
| Bob Doyle         | U.S. Environmental Protection Agency |
| Henry Ferland     | U.S. Environmental Protection Agency |
| Dave Godwin       | U.S. Environmental Protection Agency |
| Katherine Grover  | U.S. Environmental Protection Agency |
| John Hall         | U.S. Environmental Protection Agency |
| Lisa Hanle        | U.S. Environmental Protection Agency |
| Reid Harvey       | U.S. Environmental Protection Agency |
| Kathleen Hogan    | U.S. Environmental Protection Agency |
| Roy Huntley       | U.S. Environmental Protection Agency |
| Bill N. Irving    | U.S. Environmental Protection Agency |

| Dina Kruger          | U.S. Environmental Protection Agency   |
|----------------------|----------------------------------------|
| Skip Laitner         | U.S. Environmental Protection Agency   |
| Joseph Mangino       | U.S. Environmental Protection Agency   |
| Pam Herman Milmoe    | U.S. Environmental Protection Agency   |
| Beth Murray          | U.S. Environmental Protection Agency   |
| Deborah Ottinger     | U.S. Environmental Protection Agency   |
| Paul Stolpman        | U.S. Environmental Protection Agency   |
| Susan Thorneloe      | U.S. Environmental Protection Agency   |
| Chloe Weil           | U.S. Environmental Protection Agency   |
| Phil J. Wirdzek      | U.S. Environmental Protection Agency   |
| Tom Wirth            | U.S. Environmental Protection Agency   |
| Michael Savonis      | U.S. Federal Highway Administration    |
| M. Michael Miller    | U.S. Geological Survey                 |
| Hendrik G. van Oss   | U.S. Geological Survey                 |
| Valentin V. Tepordei | U.S. Geological Survey                 |
| Marguerite Downey    | U.S. Postal Service                    |
| Hussein Abaza        | UNEP                                   |
| Lambert Kuijpers     | UNEP                                   |
| Gary Nakarado        | UNEP                                   |
| Mark Radka           | UNEP                                   |
| Stelios Pesmajoglou  | UNFCCC                                 |
| Alden Meyer          | Union of Concerned Scientists          |
| Judith Bayer         | United Technologies Corporation        |
| Fred Keller          | United Technologies Corporation        |
| Paul Patlis          | United Technologies Corporation        |
| Ellen J. Quinn       | United Technologies Corporation        |
| Bill Walters         | United Technologies Corporation        |
| Gary Bull            | University of British Colombia         |
| Zoe Harkin           | University of British Columbia         |
| Gerard Alleng        | University of Delaware                 |
| Jacob Park           | University of Maryland                 |
| Terri Shires         | URS Corporation                        |
| Angela Crooks        | USAID                                  |
| Virginia Gorsevski   | USAID                                  |
| Carrie Stokes        | USAID                                  |
| Sandeep Tandon       | USAID                                  |
| A.K. Ghose           | Vam Organosys Ltd.                     |
| Cyril Coillot        | Vivendi Environment                    |
| Eric Lesueur         | Vivendi Environment                    |

Michael Dillman

Volkswagen

Stephan Herbst

Volkswagen

Herbert Forster

Votorantim

Claude Grinfeder

Votorantim

Mahua Acharya

World Business Council for Sustainable Development

Christine Elleboode

World Business Council for Sustainable Development

Margaret Flaherty

World Business Council for Sustainable Development

Al Fry

World Business Council for Sustainable Development

Susanne Haefeli

World Business Council for Sustainable Development

Kija Kummer

World Business Council for Sustainable Development

Heidi Sundin

World Business Council for Sustainable Development

Donna Danihel

We Energies

Gary Risner

Weyerhauser

Thomas F. Catania

Whirlpool Corporation

Eric Olafson

Williams Company

Johannes Heister

World Bank

Ajay Mathur

World Bank

Richard Samans

World Economic Forum

Andrew Aulisi

World Resources Institute

Kevin Baumert

World Resources Institute

Carey Bylin

World Resources Institute

Florence Daviet

World Resources Institute

Manmita Dutta

World Resources Institute

Suzie Greenhalgh

World Resources Institute

Craig Hanson

World Resources Institute

Fran Irwin

World Resources Institute

David Jhirad

World Resources Institute

Nancy Kete

World Resources Institute

Bill LaRocque

World Resources Institute

Jim MacKenzie

World Resources Institute

Emily Matthews

World Resources Institute

Sridevi Nanjundaram

World Resources Institute

Jim Perkaus

World Resources Institute

Jonathan Pershing

World Resources Institute

Samantha Putt del Pino

World Resources Institute

Anand Rao

World Resources Institute

Lee Schipper

World Resources Institute

Jason Snyder

World Resources Institute

Jennifer Morgan

World Wildlife Fund

WRI and WBCSD would also like to thank the following individuals and organizations for their generous financial support: Energy Foundation, Spencer T. and Ann W. Olin Foundation, John D. and Catherine T. MacArthur Foundation, Charles Stewart Mott Foundation, the US Agency for International Development, the US Environmental Protection Agency, Arthur Lee, Anglo American, Baxter International, BP, Det Norske Veritas, DuPont, Ford, General Motors, Lafarge, International Paper, Norsk Hydro, Ontario Power Generation, Petro-Canada, PowerGen, S.C.Johnson, SGS, Shell, Statoil, STMicroelectronics, Sulzer, Suncor, Swiss Re, Texaco, The Dow Chemical Company, Tokyo Electric Power Company, Toyota, TransAlta and Volkswagen.

<!-- image -->

## Ordering publications

WBCSD WBCSD, c/o Earthprint Limited Tel: (44 1438) 748 111 Fax: (44 1438) 748 844 wbcsd @ earthprint.com

Publications are available at: www.wbcsd.org www.earthprint.com

WRI

Hopkins Fulfillment Service

Tel: (1 410) 516 6956

Fax: (1 410) 516 6998

e-mail: hfscustserv @ mail.press.jhu.edu

Publications can be ordered from WRI's secure online store: http:// www.wristore.com

## Disclaimer

This document, designed to promote best practice GHG accounting and reporting, has been developed through a unique  multi-stakeholder  consultative  process  involving representatives of reporters and report-users from around the world. While WBCSD and WRI encourage use of the GHG  Protocol  Corporate  Standard  by  all  corporations and  organizations,  the  preparation  and  publication  of reports based fully or partially on the GHG Protocol is the full  responsibility  of  those  producing  them.  Neither  the WBCSD and WRI, nor other individuals who contributed to  this  standard  assume  responsibility  for  any  consequences or damages resulting directly or indirectly from its use in the preparation of reports or the use of reports based on the GHG Protocol Corporate Standard.

Copyright © World Resources Institute and World Business Council for Sustainable Development, March 2004 ISBN 1-56973-568-9

Printed in USA

<!-- image -->

T

<!-- image -->

<!-- image -->

<!-- image -->

## About WBCSD

## About WRI

The World Business Council for Sustainable Development (WBCSD) is a coalition of 170 international companies united by a shared commitment to  sustainable  development  via  the  three  pillars  of economic  growth,  ecological  balance  and  social  progress.  Our members are drawn from more than 35 countries and 20 major industrial  sectors.  We  also  benefit  from  a  global  network  of 48 national and regional business councils and partner organizations involving some 1,000 business leaders globally.

World Resources Institute is an independent nonprofit organization with  a  staff  of  more  than  100  scientists,  economists,  policy experts, business analysts, statistical analysts, mapmakers, and communicators working to protect the Earth and improve people's lives. The GHG Protocol Initiative is managed by WRI's Sustainable Enterprise Program which for more than a decade, has harnessed the power of business to create profitable solutions to environment and  development  challenges.  WRI  is  the  only  organization  that brings  together  four  influential  forces  to  accelerate  change  in business  practice:  corporations,  entrepreneurs,  investors,  and business schools.

<!-- image -->

<!-- image -->

WORLD RESOURCES I NSTITUTE

<!-- image -->

4, chemin de Conches 1231 Conches-Geneva Switzerland

Tel: (41 22) 839 31 00

Fax: (41 22) 839 31 31

E-mail: info

@ wbcsd.org

Internet: www.wbcsd.org

10 G Street, NE (Suite 800) Washington, DC 20002 USA

Tel: (1 202) 729 76 00

Fax: (1 202) 729 76 10

E-mail: sepinfo @ wri.org

Internet: www.wri.org

<!-- image -->