---
document_id: sbti_netzero_standard
title: "SBTi Corporate Net-Zero Standard (Version 1.1)"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "SBTi"
year: 2023
original_file: "sbti_corporate_net_zero_standard_v1.1.pdf"
tables_detected: 102
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## SBTi CORPORATE NET-ZERO STANDARD

Version 1.3.1

April 2026

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ABOUT SBTi

The Science Based Targets initiative (SBTi) is a corporate climate action organization that enables companies and financial institutions worldwide to play their part in combating the climate crisis.

We develop standards, tools and guidance which allow companies to set greenhouse gas (GHG) emissions reductions targets in line with what is needed to keep global heating below catastrophic levels and reach net-zero by 2050 at latest.

The SBTi is incorporated as a UK charity, with a subsidiary SBTi Services Limited, which hosts our target validation services (together with SBTi, the 'SBTi Group'). Partner organizations who facilitated SBTi's growth and development are CDP, the United Nations Global Compact, the We Mean Business Coalition, the World Resources Institute (WRI), and the World Wide Fund for Nature (WWF).

## DISCLAIMER

Although reasonable care was taken in the preparation of this document, the Science Based Targets initiative (SBTi) affirms that the document is provided without representation or warranty, either expressed or implied, of the contents of this document, including its accuracy, completeness, sufficiency or fitness for purpose. The SBTi hereby further disclaims any and all duty, liability or responsibility (whatsoever), whether direct or indirect, whether arising in tort, contract or statute or otherwise, for damages or loss relating to the use of this document or any statement or otherwise to the fullest extent permitted by law.

The information (including data) contained in this document is not intended to constitute or form the basis of any advice (legal, financial or otherwise). The SBTi does not accept any duty, liability or responsibility for any claim or loss (whether direct or indirect) arising from any use of or reliance on any data or information contained in this document.

This document is protected by copyright. Information or material from this document may be reproduced only in unaltered form for personal, non-commercial use. All other rights are reserved. Information or material used from this document may be used only for the purposes of private study, research, criticism, or review permitted under the Copyright Designs &amp; Patents Act 1988 as amended from time to time ('Copyright Act'). Any reproduction permitted in accordance with the Copyright Act shall acknowledge this document as the source of any selected passage, extract, diagram, content or other information.

The SBTi reserves the right to revise this document according to a set revision schedule or as advisable to reflect the most recent emissions scenarios, regulatory, legal or scientific developments, and GHG accounting best practices.

'Science Based Targets initiative' and 'SBTi' refer to the Science Based Targets initiative, a private company registered in England number 14960097 and registered as a UK Charity number 1205768.

© SBTi 2026

## VERSION HISTORY

| Version                           | Update description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | Release date      | Effective dates                         |
|-----------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|-----------------------------------------|
| 1.0 Corporate Net-Zero Standard   |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | 28 October 2021   | 28 October 2021 to 10 April 2023        |
| 1.1 Corporate Net-Zero Standard   | Non-substantive revision. For a detailed list of revisions made in V1.1, please refer to Annex I of the Main Changes document for V1.2 of the Corporate Net Zero Standard.                                                                                                                                                                                                                                                                                                                                                                    | 11 April 2023     | From 11 April 2023 to 12 March 2024     |
| 1.2 Corporate Net-Zero Standard   | Non-substantive revision. Relevant elements of the Target Validation Protocol and Corporate Manual (both retired) have been consolidated into this version of the Corporate Net-Zero Standard. For a detailed list of revisions made in V1.2, please refer to Table 1 of the Main Changes Document for V1.2 of the Corporate Net Zero Standard.                                                                                                                                                                                               | 13 March 2024     | From 13 March 2024 to 14 September 2025 |
| 1.3 Corporate Net-Zero Standard   | Non-substantive revision. Correction to bioenergy accounting requirements (C11), clarification of sold and/or distributed fossil fuels target applicability (C37), clarification of near-term target timeframe (C17 and C23) and clarification on long-term target years for companies in the power and maritime sectors. Introduction of near-term target year recommendation (R6) to support alignment of near-term target years with the mandatory transition period of the forthcoming update to SBTi's Corporate Net-Zero Standard V2.0. | 15 September 2025 | From 15 September 2025 to 12 April 2026 |
| 1.3.1 Corporate Net-Zero Standard | Non-substantive revision. Update to absolute contraction method for near-term targets, to accommodate targets set using more recent target base years. Addition of recommendations listed in Corporate Near-Term Criteria (R5, R8) for consistency across documents and updates to subsequent recommendation numbers.                                                                                                                                                                                                                         | 14 April 2026     | From 14 April 2026                      |

## CONTENTS

| ABOUT SBTi...........................................................................................................................   | 2   |
|-----------------------------------------------------------------------------------------------------------------------------------------|-----|
| DISCLAIMER...........................................................................................................................   | 3   |
| VERSION HISTORY................................................................................................................         | 4   |
| CONTENTS.............................................................................................................................   | 5   |
| 1. BACKGROUND TO THE CORPORATE NET-ZERO STANDARD.....................................8                                                  |     |
| 1.1 The Science Based Targets initiative...........................................................................                     | 8   |
| 1.2 Purpose of the Corporate Net-Zero Standard..............................................................                            | 8   |
| 1.3 Who should use the Corporate Net-Zero Standard?....................................................9                                |     |
| 1.4 The Corporate Net-Zero Standard development process............................................                                     | 9   |
| 1.5 Supporting documentation.........................................................................................                   | 10  |
| 1.6 Terms, definition & acronyms.................................................................................                       | 11  |
| 2. THE NET-ZERO STANDARD FRAMEWORK...................................................................12                                 |     |
| 2.1 Near-term science-based targets...............................................................................                      | 14  |
| 2.2 Long-term science-based targets...............................................................................14                    |     |
| 2.3 Neutralization.............................................................................................................         | 14  |
| 2.4 Beyond value chain mitigation....................................................................................14                 |     |
| 3.1 The science behind science-based net-zero targets..................................................16                               |     |
| 3.2 How mitigation pathways are used to inform science-based targets.........................                                           | 17  |
|                                                                                                                                         | 18  |
| 3.3 Overview of pathways and which companies should use them.................................                                           |     |
| 3.4 Transformative mitigation is required from all sectors................................................                              | 19  |
| 4. PROCESS TO SET SCIENCE-BASED TARGETS...........................................................                                      | 21  |
| 4.1 Select a base year......................................................................................................21          |     |
| 4.2 Calculate your company's emissions.........................................................................                         | 22  |
| 4.2.1 Develop a full GHG emissions inventory...........................................................22                               |     |
| 4.3 Set target                                                                                                                          |     |
| boundaries.................................................................................................                             | 24  |
| 4.3.1 Near-term science-based target boundary (scopes 1, 2, and 3).......................                                               | 24  |
| 4.3.2 Long-term science-based target boundary (scopes 1, 2, and 3).......................24 coverage.............................       |     |
| 4.3.3 Additional requirements for science-based target                                                                                  | 25  |
| 4.3.4 Meeting SBTi boundary criteria with several targets.........................................                                      | 27  |
| 4.3.5 Setting a single scope 3 target or multiple scope 3 targets...............................27                                      |     |
| 4.4 Choose a target year..................................................................................................28            |     |
| 4.5 Target-setting methods...............................................................................................29             |     |
| 4.6 Calculating near and long-term SBTs.........................................................................29                      |     |
| 4.7 Target wording and communication............................................................................31                      |     |
| 4.7.1 Overarching net-zero target..............................................................................                         | 32  |
| 4.7.3 Communicating targets.....................................................................................                        | 32  |
| 5. THE CORPORATE NET-ZERO STANDARD CRITERIA AND RECOMMENDATIONS...33                                                                    |     |
| 5.1 Background to the Corporate Net-Zero Standard Criteria..........................................33                                  |     |
| 5.1.1 Terminology.......................................................................................................                | 33  |

| 5.1.2 Effective dates of updated criteria.....................................................................                    | 34                                                                           |
|-----------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------|
| 5.2 General criteria...........................................................................................................34 |                                                                              |
| 5.2.1 Target boundary................................................................................................             | 34                                                                           |
| 5.2.1.1 Organizational boundary..........................................................................                         | 34                                                                           |
| 5.2.1.2 GHG coverage..........................................................................................34                  |                                                                              |
| 5.2.1.3 Scope coverage........................................................................................34                  |                                                                              |
| 5.2.1.4 Emissions coverage.................................................................................                       | 35                                                                           |
| 5.2.2 Method validity (near and long-term targets).....................................................35                         |                                                                              |
| 5.2.3 Emissions accounting requirements..................................................................36                       |                                                                              |
| 5.3 Net-zero target formulation.........................................................................................37        |                                                                              |
| 5.3.1 Net-zero definition.............................................................................................            | 37                                                                           |
| 5.3.2 Structure............................................................................................................       | 37                                                                           |
| 5.3.3 Timeframe.........................................................................................................          | 37                                                                           |
| 5.3.4 Ambition............................................................................................................        | 38                                                                           |
| 5.3.4.1 Scope 1 and 2 (near- and long-term targets)...........................................                                    | 38                                                                           |
| 5.3.4.2 Scope 3 (near- and long-term targets).....................................................                                | 39                                                                           |
| 5.3.4.3 Combined targets (near- and long-term targets)......................................                                      | 40                                                                           |
| 5.3.4.4 Renewable electricity targets (near- and long-term targets).....................40                                        |                                                                              |
| 5.3.5 Beyond value chain mitigation...........................................................................40                  |                                                                              |
| 5.3.6 Neutralization....................................................................................................          | 41                                                                           |
| 5.3.7 Target formulation..............................................................................................41          |                                                                              |
| 5.4 Reporting, recalculation and target validity................................................................                  | 41                                                                           |
| 5.4.1 Reporting...........................................................................................................        | 41                                                                           |
| 5.4.2 Recalculation and target validity........................................................................41                 |                                                                              |
| 5.5 Sector-specific guidance............................................................................................          | 43                                                                           |
| 5.5.1 Fossil fuel sales, distribution, and other business.............................................                            | 43                                                                           |
| 6. SECTOR-SPECIFIC REQUIREMENTS.............................................................................44                    |                                                                              |
| ANNEX A: SUPPLEMENTARY GUIDANCE ON GHG ACCOUNTING................................51                                               |                                                                              |
| ANNEX B: SUPPLEMENTARY GUIDANCE ON TARGET-SETTING METHODS...............                                                          | 56                                                                           |
| B.1 Cross-sector absolute reduction (all scopes).............................................................56                   |                                                                              |
| B.2 Sector-specific absolute reduction (all scopes)..........................................................57                   |                                                                              |
| B.3 Sector-specific intensity convergence (i.e., SDA, all scopes)....................................                             | 57                                                                           |
| B.4 Renewable electricity (scope 2).................................................................................              | 58                                                                           |
| B.5 Physical intensity reduction (scope                                                                                           | 3)........................................................................59 |
| B.6 Economic intensity reduction (scope 3).....................................................................                   | 60                                                                           |
| B.7 Supplier and/or customer engagement targets (scope 3)..........................................61                             |                                                                              |
| ANNEX C: CLASSIFICATION OF TARGET TEMPERATURE ALIGNMENT.......................63                                                  |                                                                              |
| C.1 Target classification rules...........................................................................................63      |                                                                              |
| ANNEX D: REPORTING GUIDANCE...................................................................................                    | 66                                                                           |
| D.1 Where to disclose......................................................................................................       | 66                                                                           |
| D.2 Reporting guiding principles......................................................................................            | 67                                                                           |
| D.3 GHG emissions inventory..........................................................................................             | 68                                                                           |
| D.3.1 Full GHG inventory...........................................................................................               | 68                                                                           |
| D.3.2 Data limitations.................................................................................................           | 68                                                                           |

| D.3.3 Verification of GHG inventory...........................................................................                                                                                                     | 68   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|
| D.3.4 Worked example: GHG emissions inventory....................................................                                                                                                                  | 69   |
| D.4 Target description......................................................................................................                                                                                       | 71   |
| D.4.1 Description of the target....................................................................................71                                                                                              |      |
| D.4.2 Different levels of ambition by scope and/or activity.........................................                                                                                                               | 72   |
| D.4.3 Exclusions from emissions inventory and/or target boundary..........................                                                                                                                         | 72   |
| D.4.4 Worked example: Target description.................................................................72                                                                                                        |      |
| D.5 Target progress..........................................................................................................73                                                                                    |      |
| D.5.1 Progress in the reporting year..........................................................................                                                                                                     | 73   |
| D.5.2 Level of disaggregation.....................................................................................74                                                                                               |      |
| D.5.3 Worked example: Target progress....................................................................                                                                                                          | 75   |
| D.6 Substantial emission variations and changes in targets............................................                                                                                                             | 76   |
| D.6.1 Base year recalculation policy and threshold...................................................                                                                                                              | 76   |
| D.6.2 Reasons for variation in emissions...................................................................                                                                                                        | 77   |
| D.6.3 Worked example: substantial emission variations and changes in targets.......78                                                                                                                              |      |
| D.6.3 Recalculated and revalidated targets...............................................................                                                                                                          | 78   |
| D.7 Actions towards meeting SBTs..................................................................................                                                                                                 | 78   |
| D.7.1 Information on emission reduction projects......................................................                                                                                                             | 78   |
| D.7.2 Information on contractual instruments (for scope 2 targets)...........................                                                                                                                      | 79   |
| D.7.3 Decarbonization pathway.................................................................................                                                                                                     | 79   |
| D.7.4 Planned milestones and/or near-term investments for neutralization...............79                                                                                                                          |      |
| D.7.5 Planned actions or investments to mitigate climate change beyond your value chain........................................................................................................................... | 80   |
| D.7.6 Use of carbon offset credits and avoided (product-level) emissions.................80                                                                                                                        |      |
| D.7.7 Climate transition plan......................................................................................                                                                                                | 80   |
| D.7.8 Worked example: actions towards meeting SBTs.............................................81                                                                                                                  |      |
| ANNEX E: GUIDANCE FOR COMPANIES IN LAND-INTENSIVE SECTORS.....................85                                                                                                                                   |      |
| E.1 Background on FLAG emissions...............................................................................                                                                                                    | 85   |
| E.2 SBTi FLAG Guidance................................................................................................                                                                                             | 85   |
| E.3 Greenhouse Gas Protocol Land Sector and Removals Guidance.............................86                                                                                                                       |      |
| E.4 Which companies are required to set FLAG targets?................................................                                                                                                              | 86   |

## 1. BACKGROUND TO THE CORPORATE NET-ZERO STANDARD

The Intergovernmental Panel on Climate Change's (IPCC) Special Report on Global Warming of 1.5°C (SR15, 2018)  was widely accepted as a warning that we must limit global , temperature rise to 1.5°C above pre-industrial levels and reach net-zero carbon dioxide (CO2) emissions by 2050 for the best chance of avoiding catastrophic climate breakdown. More recently, the IPCC's Sixth Assessment Report (2021) has confirmed that climate change is already affecting every region on Earth, its impacts increasingly visible in the form of extreme weather, worsened droughts and heightened risk of forest fires.

Against this backdrop, companies are increasingly adopting net-zero targets. The number of businesses committing to reach net-zero emissions has grown rapidly, but not all net-zero targets are equal. Without adhering to a common definition, net-zero targets can be inconsistent, and their collective impact is strongly limited.

While the growing interest in net-zero targets represents an unparalleled opportunity to drive corporate climate action, it has also created a pressing need for a common understanding of 'net-zero' in a corporate context. Business leaders need a robust, science-based framework for setting net-zero targets. Otherwise, they risk continuing to invest in business models that are inconsistent with the goals of the Paris Agreement.

The Science Based Targets initiative (SBTi) developed the first global science-based standard for companies to set net-zero targets, published in 2021. The SBTi Corporate Net-Zero Standard gives business leaders confidence that their greenhouse gas (GHG) mitigation targets are aligned with what is needed for a habitable planet, and it provides clarity on business climate action to a wide range of stakeholders.

## 1.1 The Science Based Targets initiative

The Science Based Targets initiative (SBTi) is a corporate climate action organization that enables companies and financial institutions worldwide to play their part in combating the climate crisis.

We develop standards, tools and guidance which allow companies to set greenhouse gas (GHG) emissions reductions targets in line with what is needed to keep global heating below catastrophic levels and reach net-zero by 2050 at latest.

The SBTi is incorporated as a UK charity, with a subsidiary SBTi Services Limited, which hosts our target validation services. Partner organizations who facilitated SBTi's growth and development are CDP, the United Nations Global Compact, the We Mean Business Coalition, the World Resources Institute (WRI), and the World Wide Fund for Nature (WWF).

## 1.2 Purpose of the Corporate Net-Zero Standard

The SBTi's Corporate Net-Zero Standard (also referred to as the 'Net-Zero Standard') contains guidance, criteria, and recommendations to support corporates in setting net-zero targets to be validated by the SBTi. The main objective of this standard is to provide a

consistent and robust approach for corporates to set net-zero targets aligned with climate science.

It is important to note that while the SBTi does provide some supplementary guidance on GHG accounting, companies should refer to the suite of corporate Greenhouse Gas Protocol standards on this topic.

## 1.3 Who should use the Corporate Net-Zero Standard?

The intended audience for this document is companies that wish to commit to setting and submitting science-based net-zero targets for validation through the SBTi. This document does not cover net-zero targets for financial institutions. The SBTi has published a separate Net-Zero Standard for Financial Institutions.

Small and medium-sized enterprises (SMEs) have the option to set targets using the Corporate Net-Zero Standard or the streamlined SME route (where some of the details contained within this document are not applicable). SMEs should refer to the SME definition and the SME FAQs for more information.

Please note that the Corporate Net-Zero Standard should and in some cases must (e.g., for companies with forest, land and agriculture activities) be complemented with SBTi sector guidance whenever the sector and/or activity covered by the sector guidance is relevant to the company. For example, a company with aviation, maritime, and financial services activities is encouraged to set separate sector-specific targets for each of the activities relevant to them based on SBTi sector guidance.

## 1.4 The Corporate Net-Zero Standard development process

The SBTi initiated a scoping phase of work in 2019 to develop a framework enabling companies to set robust and credible net-zero targets in line with a 1.5°C future. The standard development process formally began after the SBTi's publication of Foundations for Science-Based Net-Zero Target Setting in the Corporate Sector in September 2020. After publication, the SBTi convened a dedicated Net-Zero Expert Advisory Group (EAG), which was to be the main consensus building body for the project.

The SBTi then developed detailed criteria and guidance in regular consultation with the EAG, as well as the SBTi's Scientific and Technical Advisory Groups. The SBTi requested feedback from stakeholders to improve the standard through two public consultations and a company road test. The standard was launched on 28 October 2021. Further detail on this process can be found on the SBTi website.

Figure 1. An outline of key milestones in the Corporate Net-Zero Standard development process.

<!-- image -->

## 1.5 Supporting documentation

The table below outlines key SBTi resources that support the Corporate Net-Zero Standard. All resources, including translations, can be found on the Resources and the Corporate Net-Zero Standard sections of the SBTi website.

Table 1. A mapping of key SBTi resources that companies should refer to when setting science-based net-zero targets.

| Topic                              | Document                                                                                                   | Description                                                                                                                                                                                                                                                                                                                                                                                                           |
|------------------------------------|------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Background and technical resources | Foundations for Science-Based Net-Zero Target Setting in the Corporate Sector                              | This paper lays out the conceptual foundations for credible, science-based net-zero targets for the corporate sector.                                                                                                                                                                                                                                                                                                 |
| Background and technical resources | Pathways to Net-Zero: SBTi Technical Summary                                                               | Produced in collaboration with more than a dozen pioneering academics, IPCC lead authors and mitigation experts, this technical summary provides an overview of how the SBTi selected mitigation pathways to steer action.                                                                                                                                                                                            |
| Background and technical resources | Above and Beyond: An SBTi report on the design and implementation of beyond value chain mitigation (BVCM)  | This report provides suggestions to support the BVCM recommendation (R12) included within the Corporate Net-Zero Standard. Its purpose is to support companies in the design and implementation of BVCM strategies to accelerate progress towards global net-zero.                                                                                                                                                    |
| Background and technical resources | Raising the Bar: An SBTi report on accelerating corporate adoption of beyond value chain mitigation (BVCM) | This report draws upon SBTi research to consider both the barriers that limit private sector adoption of BVCM, as well as the positive incentives that have the potential to accelerate adoption. Based on the research findings, this report provides recommendations for different actors, offering a shared vision and 'theory of change' for scaling corporate climate finance into BVCM over the coming decades. |
| Background and technical resources | SBTi Glossary                                                                                              | This document provides a list of terms, definitions, and acronyms used within all SBTi technical resources, including the Corporate Net-Zero Standard.                                                                                                                                                                                                                                                                |

## Setting targets

| Getting Started Guide for Science-Based Target Setting                                                                 | A simple, step-by-step flowchart helping companies understand how to set science-based targets in their specific situation.                                                                                                                                                                                                                                                                                                                                      |
|------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Corporate Net-Zero Standard                                                                                            | This document, providing guidance, criteria, and recommendations to support corporates in setting net-zero targets through the SBTi. The Corporate Net-Zero Standard criteria, with which companies must conform to achieve validation, are set out in Chapter 7 of this document.                                                                                                                                                                               |
| Corporate Net-Zero Standard Criteria                                                                                   | The criteria companies' net-zero targets must conform to to achieve validation. This is a standalone version of chapter 7 of this document.                                                                                                                                                                                                                                                                                                                      |
| Corporate Net-Zero Tool                                                                                                | Target-setting tool to calculate long-term science-based targets in line with the Corporate Net-Zero Standard.                                                                                                                                                                                                                                                                                                                                                   |
| Corporate Near-Term Criteria                                                                                           | The criteria companies must meet to have their near-term targets approved as science-based by the SBTi. These criteria are also included within this document.                                                                                                                                                                                                                                                                                                   |
| Corporate Near-Term Tool                                                                                               | Target-setting tool to calculate near-term science-based targets in line with the Corporate Near-Term Criteria and the Corporate Net-Zero Standard criteria (for the near-term element).                                                                                                                                                                                                                                                                         |
| Engaging Supply Chains on the Decarbonization Journey: A Guide to Developing and Achieving Scope 3 Supplier Engagement | Guidance for companies that are considering or are already implementing their SBTi scope 3 supplier engagement targets. Also relevant for companies that are interested in exploring different supplier engagement tactics to address scope 3 emissions reduction.                                                                                                                                                                                               |
| SME Streamlined Target Validation Route                                                                                | SMEs have the option to use a streamlined process to set targets in line with climate science for both near-term and net-zero targets. This route enables SMEs to bypass the initial step of committing to set a science-based target and the regular target validation process and to immediately set near-term science-based targets for scope 1 and 2 emissions, and, optionally, net-zero targets by choosing from one of several predefined target options. |
| Standard Operating Procedure for the Validation of SBTi Targets                                                        | This document provides a detailed explanation of the SBTi target validation procedure. This is to be used in conjunction with other key resources.                                                                                                                                                                                                                                                                                                               |
| Criteria Assessment Indicators                                                                                         | The Criteria Assessment Indicators provide verifiable control points which will be evaluated during the target validation process. Conformity with these indicators determines companies' compliance with the SBTi Standard(s) under which they are submitting targets.                                                                                                                                                                                          |

## 1.6 Terms, definition &amp; acronyms

Terms, definitions and acronyms used within this document can be found in the SBTi Glossary.

## 2. THE NET-ZERO STANDARD FRAMEWORK

As described in more detail in Foundations for Science-Based Net-Zero Target Setting in the Corporate Sector, there are many different transition pathways to help achieve global net-zero emissions, each with different implications for our climate, nature and society.

Considering these implications, the Corporate Net-Zero Standard was developed with the intention of guiding corporates towards a state of net-zero in a way that is consistent with societal climate and sustainability goals and within the biophysical limits of the planet.

To reach a state of net-zero at the corporate level, companies must deeply reduce emissions and counterbalance the impact of any emissions that remain. The SBTi Net-Zero Standard defines corporate net-zero as:

- ● Reducing scope 1, 2, and 3 emissions to zero or a residual level consistent with reaching net-zero emissions at the global or sector level in eligible 1.5°C-aligned pathways; and
- ● Permanently neutralizing any residual emissions at the net-zero target year and any GHG emissions released into the atmosphere thereafter.

To contribute to societal net-zero goals, companies are strongly encouraged to go further than their science-based abatement targets to mitigate emissions beyond their value chains (known as 'beyond value chain mitigation').

The Corporate Net-Zero Standard sets out four key elements that make up a corporate net-zero target as depicted in Figure 2 :

- ● Near-term science-based target
- ● Long-term science-based target
- ● Neutralization of any residual emissions
- ● Beyond value chain mitigation (BVCM).

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Figure 2. Key elements of the Corporate Net-Zero Standard.

<!-- image -->

## 2.1 Near-term science-based targets

What : These are 5-10 year GHG mitigation targets in line with 1.5°C pathways.  When 1 companies reach their near-term target date, they must calculate new near-term science-based targets to serve as milestones on the path towards reaching their long-term science-based target.

Why : Near-term targets galvanize the action required for significant emissions reductions to be achieved by around 2030. Near-term emissions reductions are critical to not exceeding the global emissions budget and are not interchangeable with long-term targets. 2

## 2.2 Long-term science-based targets

What : These targets show companies how much they must reduce value chain emissions to align with reaching net-zero at the global or sector level in eligible 1.5°C pathways by 2050 or sooner.

Why : Long-term targets drive economy-wide alignment and long-term business planning to reach the level of global emissions reductions needed to meet climate goals based on science.

## 2.3 Neutralization

What : Measures companies take to remove carbon from the atmosphere and permanently store it, counterbalancing the impact of emissions that remain unabated after the long-term science-based target is achieved. Emissions excluded from the long-term target boundary and the GHG emissions inventory must also be neutralized.

Why : Although most companies will reduce emissions by at least 90% through their long-term science-based targets, not all companies will be able to achieve complete decarbonization and therefore, some residual emissions may remain. These emissions must be neutralized to reach net-zero emissions and a state of no impact on the climate from GHG emissions.

A company cannot claim to have reached net-zero until it has achieved its long-term science-based target across all scopes and neutralized residual emissions.

## 2.4 Beyond value chain mitigation

What : Mitigation action or investments that fall outside of a company's value chain. This includes activities that avoid or reduce GHG emissions, and those that remove and store GHGs from the atmosphere.

Why : The climate and ecological crises require bold and decisive action from companies. Decarbonizing a company's value chain in line with science and reaching net-zero emissions by 2050 is increasingly becoming the minimum societal expectation for companies.

Businesses can play a critical role in accelerating the net-zero transition and addressing the

1 Since July 2022, the SBTi has required near-term targets covering scope 1 and 2 emissions to be aligned with 1.5°C pathways and scope 3 targets to be aligned with well-below 2°C pathways.

2 Despite this, if a company sets a long-term science-based target to reach the level of decarbonization required to reach net-zero at a global or sectoral level in 1.5°C pathways within a 10 year timeframe, the long-term science-based target is not required.

ecological crisis by investing in mitigation action beyond their value chains. Additional investments like these could help increase the likelihood the global community stays within a 1.5˚C carbon budget but are not a substitute for the rapid and deep reduction of a company's own value chain emissions.

Please see the Beyond Value Chain Mitigation page on our website, the 'Above and Beyond: An SBTi report on the design and implementation of beyond value chain mitigation' report and the 'Raising the Bar: An SBTi report on accelerating corporate adoption of beyond value chain mitigation (BVCM)' report for more information and guidance.

## 3. MITIGATION PATHWAYS IN THE NET-ZERO STANDARD

Through the Paris Agreement, parties and signatories committed to 'holding the increase in global average temperature to well below 2°C above pre-industrial levels and pursuing efforts to limit the temperature increase to 1.5°C above pre-industrial levels.'

In the years since the Paris Agreement was signed, the need to limit warming to 1.5°C has become even stronger. Against the backdrop of increasingly frequent and destructive climate-related disasters, the IPCC's SR15 report delivered a harrowing scientific consensus: while impacts to human health, society, and nature associated with 1.5°C of warming are worse than previously acknowledged, the risks associated with exceeding 1.5°C are far higher. To mitigate these risks, SR15 highlighted pathways that limit warming to 1.5°C with no or limited overshoot (overshoot &lt;0.1°C).

## 3.1 The science behind science-based net-zero targets

As described in SR15, scenarios that limit warming to 1.5°C with no or limited overshoot reach net-zero CO2 emissions around 2050, accompanied by rapid reductions in non-CO2 GHG emissions. These scenarios entail profound transitions in the global energy, industry, urban and land systems that involve:

- ● Full or near-full decarbonization for energy and industrial CO  emissions achieving 2 a zero-emissions energy supply system by mid-century.
- ● Eliminating CO2 emissions associated with agriculture, forestry, and land-use.
- ● Deep reductions in non-CO2 emissions from all sectors.
- ● Removing CO2 from the atmosphere to neutralize residual emissions and, potentially, sustain net negative emissions that reduce cumulative CO  in the 2 atmosphere over time.

The different system transformations in 1.5°C mitigation scenarios occur simultaneously and all of them are needed for society to reach net-zero emissions and limit warming to 1.5°C. An understanding of the synergies and trade-offs between different climate change mitigation scenarios and sustainable development should inform climate action.

Pathways used by the SBTi aim to steer voluntary climate action and contribute to achieving the 1.5°C objective of the Paris Agreement and the Sustainable Development Goals (SDGs), reaching net-zero CO2 emissions at the global level by 2050 and net-zero GHG emissions in 2050 or later.  In aggregate, 1.5°C-aligned pathways used by the SBTi stay within a 500 3 gigatonne carbon budget under the assumption of about 20-40 gigatonnes of cumulative CO2 removal by 2050.

For a detailed overview of how the SBTi determines 1.5°C-aligned pathways for calculating SBTs, please see Pathways to Net-Zero: SBTi Technical Summary.

3 Energy efficiency improvements, infrastructural innovation, and phasing-out fossil fuels-characteristic of IPCC 'low energy demand' scenarios-can help meet the 1.5°C goal with the fewest adverse impacts. The IPCC states with high confidence that low energy demand scenarios have the most pronounced synergies with sustainable development and the SDGs (IPCC SR15, Summary for Policymakers D.4.2). They also reduce dependence on CO2 removal, which can pose risks to biodiversity, food security, water resources and human rights.

## 3.2 How mitigation pathways are used to inform science-based targets

Mitigation pathways play a key role in setting science-based targets. For near-term science-based targets, mitigation pathways inform the rate of emissions reductions or emissions intensity reductions that are needed. For long-term science-based targets, they inform the overall emissions reduction or convergence intensity that must be reached to be aligned with net-zero at the global or sector level.

Because of this, near-term science-based targets are target year dependent, while long-term science-based targets are target year independent. This means that a company's reduction target will differ depending on the target year for its near-term targets, but the reduction target will not differ depending on the target year for its long-term targets. This is illustrated in Figure 3 below. Because of this, companies will model long-term targets, and then set their net-zero and long-term target date depending on when they aim to achieve the required emissions reductions. Companies can select a target year of 2050 or earlier for long-term targets, which depends on how quickly it aims to reduce its emissions.

Figure 3. Graph showing target year dependency of near-term science-based targets in comparison to the target year independency of long-term science-based targets.

<!-- image -->

## Box 1. How are residual emissions determined for different sectors of the economy?

Residual emissions levels are grounded in what is needed to achieve net-zero CO2 emissions at the global level by 2050, limit warming to 1.5°C, and contribute to achieving the SDGs. In pathways used by the SBTi, residual emissions at the cross-sector level reflect the 2020-2050 emissions reduction needed. At the sector level, residual emissions reflect a sector-specific 2020-2050 emissions reduction or a 2050 convergence emissions intensity (except for the power and maritime transport sectors which use 2040 instead of 2050 due to an earlier net-zero year). The same pathways are used to calculate near-term SBTs and residual emissions levels for long-term SBTs and together they:

- 1. Stay within the remaining carbon budget for a 50% likelihood of limiting warming to 1.5°C.
- 2. Reduce energy and industrial process CO2 and methane (CH4) emissions by an amount roughly consistent with the International Energy Agency's (IEA) Net-Zero Emissions (NZE) scenario.
- 3. Mitigate forest, land and agriculture (FLAG) sector GHG emissions by an amount consistent with the detailed land-sector roadmap Contribution of the land sector to a 1.5°C world (Roe et al., 2019).
- 4. Reach global net-zero CO2 emissions by 2050, assuming at least low/medium CO2 removal (1-4 gigatonne CO2/year), and net-zero GHG emissions in 2050 or later, depending on CO2 removal levels and different mitigation choices across pathways.

To meet these conditions, an economy-wide emissions reduction of at least 90% by 2050 from a 2020 base year informs the level of residual emissions for most companies, as shown by the cross-sector pathway. The IEA's NZE scenario, which reduces energy and industrial process CO2 emissions 95% between 2020 and 2050, has been an important reference for this calculation; but ultimately, SBTi's approach to developing the cross-sector pathway was holistic, building from an expansive body of literature and iterative development with the SBTi's Scientific Advisory Group. For more information on the cross-sector pathway and sector-specific pathways used by the SBTi, please see the SBTi's Technical Summary on Pathways to Net-Zero.

## 3.3 Overview of pathways and which companies should use them

The SBTi offers a cross-sector pathway and sector-specific pathways for setting science-based targets. Companies in the power generation sector and the FLAG sectors are required to use sector-specific pathways. Other companies can choose to use either the cross-sector pathway or, if available, sector-specific pathways. Please see Table 4 in this document for further information on eligible pathways for each sector or activity.

Using the cross-sector pathway, companies can set near-term targets to reduce emissions at a linear annual rate that is base-year-dependent. For near-term SBTs the minimum ambition is calculated as a linear reduction rate of 4.2% per year for scope 1 and scope 2, and 2.5% per year for scope 3. The reduction rate is adjusted dynamically according to the time remaining between the company's base year and the pathway net-zero year (or the company's own net-zero target year, if earlier). The reduction rate increases as the timeframe to the net-zero year decreases, i.e., with later base years and/or earlier net-zero years. This ensures that the rate reflects the time available to achieve the same overall reduction required by the cross-sector pathway. Please refer to the Corporate Near-Term Tool for further details.

Some sector-specific pathways vary significantly from the cross-sector pathway in the near-term, requiring steeper or more gradual emissions reductions depending on the sector. Please refer to each applicable sector guidance for details.

In the long-term, emissions in the cross-sector pathway are reduced by at least 90% and most sector-specific pathways also reduce CO2 emissions by 90% or more from 2020 levels.

Consequently, long-term science-based targets will be equivalent to at least a 90% absolute reduction across scopes for many companies, regardless of whether the cross-sector pathway or sector-specific pathways are used. For details on the eligible pathway and methods for each sector, please refer to Table 4 in this document and the Getting Started Guide for Science-Based Target Setting.

Companies in heavy-emitting sectors often use sector-specific pathways to calculate both near-term and long-term intensity targets. Other companies with scope 3 emissions from heavy-emitting sector activities often use a mix of approaches to calculate targets. For example, a real estate development company may have significant scope 3 emissions attributed to both the steel and cement sectors. When setting targets that cover upstream scope 3 emissions, these companies may use a sector-specific pathway to set intensity targets, provided the pathway reflects both supply-side and demand-side mitigation where relevant (see sector-specific guidance for more information). Companies are encouraged to use the cross-sector pathway and reduce emissions on an absolute basis if emissions can be mitigated by reducing demand for these products and services. 4

## 3.4 Transformative mitigation is required from all sectors

The figures below (4a and 4b) show the ambition of the cross-sector pathway and sector-specific pathways used to calculate near-term and long-term SBTs. Figure 4a shows the cross-sector and sector-specific long-term SBTs included in the Corporate Net-Zero Standard. At the company level, absolute targets are based on the sector's 2020-2050 absolute emissions reduction (orange bars and data labels), and intensity targets are based on the 2050 convergence intensity (data labels only). For the power and maritime transport sectors, long-term SBTs are calculated based on 2040 rather than 2050 due to an earlier net-zero year for these activities. Blue bars show the sector-average intensity reduction for 2020-2050, which may differ from company targets. Figure 4b shows sector-specific intensity pathways (2020-2050) for the different sectors.

In some cases, companies with available sector-specific pathways can still opt to use the cross-sector pathway (see Table 4 for details). This is the case for two main reasons: (1) the difference in required emission reductions is small (&lt;10% of base year emissions) and (2) companies are required to neutralize unabated emissions regardless, which aims to counteract the impact of any residual emissions and incentivize continued abatement once net-zero is reached.

4 For example, a consultancy company should not set intensity targets on its aviation transport emissions because they have other means to reduce these emissions from the demand-side, e.g. reduce air travel.

<!-- image -->

Figure 4a (left): Cross-sector and sector-specific long-term SBTs included in the Corporate Net-Zero Standard.

<!-- image -->

Figure 4b (right): Sector-specific intensity pathways (2020-2050) for different sectors.

## 4. PROCESS TO SET SCIENCE-BASED TARGETS

Companies can take a variety of approaches to developing near-term and long-term science-based targets; however, the SBTi recommends following the five steps described in this section.

<!-- image -->

Figure 5. The SBTi recommends a five-step approach to setting science-based targets.

## 4.1 Select a base year

Companies need to establish a base year to track emissions performance consistently and meaningfully over the target period. The following considerations are important for selecting a base year:

- 1. Scope 1, 2, and 3 emissions data should be accurate and verifiable.
- 2. Base year emissions should be representative of a company's typical GHG profile. 5
- 3. The base year must be no earlier than 2015.
- 4. Companies that have already set near-term science-based targets must use the same base year for their long-term science-based target.
- 5. If more than one target is set, companies should use the same base year for all targets within the target timeframe. 6
- 6. Scope 1 and scope 2 targets must use the same base year.
- 7. Scope 3 targets are recommended but not required to use the same base year as scope 1 and scope 2 targets. For example, if scope 3 data is exceptionally difficult to obtain or if the company has a historical scope 1 and 2 base year, it is permissible that scope 1 and 2 targets use a different base year from scope 3 targets.
- 8. Base years across different scope 3 targets must be the same.
- 9. The SBTi does not accept multi-year average base years, unless this is specified in the sector-guidance relevant to the company.

Various factors, including but not limited to mergers, divestments, business function changes, and geographical implications, may necessitate recalculations of the base year inventory (and of the targets set) to ensure continued relevance and alignment with the GHG

5 Companies must provide all the relevant GHG inventory data including a most recent year GHG inventory. For submissions in 2025, a recent year inventory must be provided that is no earlier than 2023 i.e., allowable most recent years are 2023 and 2024 .

6 This best practice is most applicable to emission reduction targets, i.e., absolute and intensity targets. Companies' renewable electricity, supplier engagement and customer engagement targets may and sometimes must have different target years than emission reduction targets.

Protocol Corporate Standard GHG accounting requirements and SBTi requirements. See Annex D of this document, 'Reporting Guidance' for further information.

## 4.2 Calculate your company's emissions

## 4.2.1 Develop a full GHG emissions inventory

Companies are required to have a comprehensive emissions inventory that covers at least 95% of company-wide scope 1 and 2 GHG emissions and includes a complete scope 3 inventory.  The following points are important for aligning with the GHG Protocol Corporate 7 Standard and SBTi criteria.

Data quality: Companies should select data that is the most complete, reliable, and representative in terms of technology, time, and geography. Companies should collect high-quality primary data from suppliers and other value chain partners for scope 3 activities deemed most relevant and targeted for GHG reductions. Secondary data is permissible, but it is better suited for scope 3 categories that are not significant in magnitude, as it limits a company's ability to track performance. Please refer to Chapter 7 of the GHG Protocol Corporate Value Chain (Scope 3) Standard for further guidance on data quality issues.

Ensure the target boundary is aligned with the GHG inventory boundary: A company must select a single consolidation approach as outlined in the GHG Protocol Corporate Standard (operational control, financial control, or equity share) to (i) determine its organizational boundary, (ii) calculate its GHG emissions inventory, and (iii) define its science-based target boundaries. 8 The organizational boundary should align with the company's financial reporting. Both the emissions inventory and target boundary must cover all seven GHGs or classes of GHGs covered by the United Nations Framework Convention on Climate Change (UNFCCC) and Kyoto Protocol, namely: carbon dioxide (CO2), methane (CH4), nitrous oxide (N O), hydrofluorocarbons (HFCs), perfluorocarbons (PFCs), sulfur 2 hexafluoride (SF ), and nitrogen trifluoride (NF ). 6 3

For more information on organizational boundary setting, please see the GHG Protocol Corporate Standard (WRI &amp; WBCSD, 2004).

Determine how to treat complex business relationships (e.g., subsidiaries, joint ventures, etc.): Complex business relationships can complicate how the GHG inventory and thus the target boundary are drawn. The SBTi allows both parent companies and subsidiaries to submit targets. Parent companies are required to include emissions from subsidiary operations in their GHG inventory and target boundary according to the selected consolidation approach, regardless of whether the subsidiary has approved SBTs. For more information on subsidiaries, please see page 19 of the GHG Protocol Corporate Standard.

Include all mandatory scope 3 emissions: Companies must develop a complete scope 3 inventory in accordance with the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard (WRI &amp; WBCSD, 2011) and the Scope 3 Calculation Guidance. The scope 3 inventory must include all relevant categories and all emissions sources categorized

7 Exclusions in the GHG inventory and target boundary combined must not exceed 10% of total scope 3 emissions.

8 Using proxy data i.e., applying one reporting year's data to another reporting year is not permitted. For example, a company may not apply base year emissions to the most recent year.

as the minimum boundary in Table 5.4 (page 34) in the Scope 3 Standard. A complete scope 3 inventory is critical for identifying emissions hotspots, reduction opportunities, and areas of risk up and down the value chain.

Companies are expected to account for all scope 3 categories, including downstream emissions from intermediate products and services, where relevant. In the instance that a company faces barriers to calculating emissions from one category of scope 3, the company should demonstrate its best efforts to calculate these emissions, and this shall not preclude it from providing reasonable estimates of emissions in other categories.

One approach to calculating scope 3 emissions is to first develop a high-level screening inventory, typically based on secondary financial data. Many companies use a scope 3 screening tool as a first step in completing their scope 3 inventory. Over time, companies should develop complete inventories and improve data quality, particularly for high-impact categories (e.g., collect primary data from suppliers and other value chain partners), to better track progress against targets. Emission factors must be representative of the corresponding activities (i.e., country-specific emission factors should be used as a minimum), and the potential uncertainty of the adopted average data should be clearly disclosed along with planned actions to improve data quality over time. For more information on calculating a scope 3 emissions inventory, please see the GHG Protocol's Corporate Value Chain (Scope 3) Accounting and Reporting Standard and thhe GHG Protocol's calculation tools and guidance page.

Determine how to treat optional scope 3 emissions: Optional scope 3 emissions or reductions are not counted towards the required target boundary for science-based targets i.e., emissions within the 'minimum boundary'. 9 Despite this, if companies have significant optional scope 3 emissions and have levers to address them, they are encouraged to calculate these emissions and set optional targets in addition to the mandatory scope 3 target(s).

More information on optional scope 3 emissions can be found in 'Table 5.4 Description and boundaries of scope 3 categories' in the GHG Protocol's Corporate Value Chain (Scope 3) Accounting and Reporting Standard.

Review relevant sector-specific guidance: For some sectors or activities, separate sector-specific methodologies, frameworks, requirements, and tools apply. For more information, visit the sector guidance webpage, and please refer to Table 4 in this document.

Exclude the use of carbon credits: Carbon credits must be reported separately from the GHG inventory and do not count as reductions toward meeting near-term or long-term science-based targets. Carbon credits may be considered only as an option to neutralize residual emissions or to finance additional climate mitigation beyond their science-based emission reduction targets.

Exclude avoided emissions: Companies are often interested in understanding the GHG impacts of their products, relative to the situation where those products do not exist. Positive impacts are commonly referred to as 'avoided emissions'. Avoided emissions occur outside of the product's life cycle and therefore do not count as a reduction of a company's scope 1,

9 For near-term science-based targets, companies must include 67% of mandatory scope 3 emissions, and for long-term science-based targets companies must include 90% of mandatory scope 3 emissions. Optional emissions do not count towards these thresholds relative to a scenario.

2 and 3 inventory. Please refer to the World Resources Institute's paper on avoided emissions for more information on avoided emissions.

## 4.2.2 Calculate emissions reported separately from the GHG inventory

Bioenergy: Companies that use bioenergy must report direct CO2 emissions from biomass combustion, processing, and distribution, as well as the land-use emissions and removals associated with bioenergy feedstock. These emissions are reported separately from the company's GHG inventory, in line with Greenhouse Gas Protocol guidance.

Fossil fuels: Companies that sell, transmit, or distribute fossil fuels are required to report the use-phase emissions associated with those fossil fuels in scope 3 category 11 'use of sold products' and cover the emissions from the combustion of the sold, transmitted, or distributed fossil fuels with a target. For companies that transport or distribute, but do not sell, fossil fuels, these emissions must be calculated and covered by a target but are typically reported outside a company's GHG inventory.

## 4.3 Set target boundaries

## 4.3.1 Near-term science-based target boundary (scopes 1, 2, and 3)

Near-term science-based targets must cover at least 95% of company-wide scope 1 and 2 emissions. When scope 3 emissions make up 40% or more of total emissions (scope 1, 2, and 3 emissions), companies must set one or more emission reduction targets and/or supplier or customer engagement targets that collectively cover(s) at least 67% of total scope 3, considering the minimum boundary of each category in conformance with the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard. Companies in certain heavy-emitting sectors are required to include specific emissions sources or scope 3 categories in their science-based target boundary, please see Table 4 for a detailed list of sector-specific requirements.

Using a scope 3 inventory, companies can identify which categories should be included in the boundary of a scope 3 target(s) to meet the 67% threshold for near-term SBTs. The relative importance of different scope 3 categories will vary by sector. Scope 3 categories likely to be important (in terms of emissions magnitude) for companies in specific sectors include:

- ● Consumer packaged goods: purchased goods and services (category 1)
- ● Food processing: purchased goods and services (category 1)
- ● Logistics: upstream transportation and distribution (category 4)
- ● Automotive: use of sold products (category 11)
- ● Electronics: use of sold products (category 11)
- ● Gas distribution and retail: use of sold products (category 11)
- ● Chemicals: end of life treatment of sold products (category 12)

## 4.3.2 Long-term science-based target boundary (scopes 1, 2, and 3)

Long-term SBTs must cover at least 95% of company-wide scope 1 and 2 emissions and 90% of scope 3 emissions. See Box 2 for more information.

## Box 2. The 'expansive boundary' approach for scope 3

A comprehensive target boundary is necessary for companies to make credible net-zero claims. However, acknowledging the challenges that companies encounter with scope 3, the Corporate Net-Zero Standard follows an expansive boundary approach and a gradual increase in ambition.

In the near-term (5 to 10 years), a scope 3 target is required when a company's scope 3 emissions represent more than 40% of their total emissions. Near-term scope 3 targets need to cover 67% of scope 3 emissions and align with well-below 2°C ambition at a minimum . For long-term targets, the target boundary increases to cover all material sources of emissions in the value chain (materiality threshold of 90%), decarbonizing in line with 1.5°C scenarios.

Figure 6. A visual representation of the 'expansive boundary' approach the Corporate Net-Zero Standard takes to scope 3 target boundaries.

<!-- image -->

Increasing scope 3 target boundary coverage from 67% for near-term SBTs to 90% for long-term SBTs may be challenging, but it will drive major opportunities to collaborate across the value chain to support suppliers and customers to decarbonize. Through the expansive boundary scope 3 approach from the near to long-term, companies have time to work through the complexity of scope 3 and long-term scope 3 reductions, focusing on their most material emissions sources in the near-term.

## 4.3.3 Additional requirements for science-based target coverage

Bioenergy and fossil fuels: Companies using bioenergy must include direct CO2 emissions from biomass combustion, processing, and distribution, as well as the land-use emissions and removals associated with bioenergy feedstock within their target boundary, even though

these emissions are reported outside a company's GHG inventory. Similarly, companies transporting or distributing fossil fuels must include use-phase emissions in their target boundary, even though these emissions may not typically be reported in a company's GHG inventory.

FLAG targets: The SBTi requires companies that meet either of the following two conditions to set a FLAG-specific target separate from their target(s) for other emissions:

- ● Companies from the following SBTi-designated sectors are required to set a FLAG target: forest and paper products (forestry, timber, pulp and paper, rubber); food production (agricultural production); food production (animal source); food and beverage processing; food and staples retailing; and tobacco.
- ● Companies in any other sector with FLAG-related emissions that total more than 20% of overall emissions across scopes 1, 2, and 3. The 20% threshold should be accounted for as gross emissions, not net emissions (gross minus removals).

Companies meeting either of the above conditions must include emissions from land-use change (LUC) using either direct LUC or statistical LUC, as aligned with the Greenhouse Gas Protocol's draft Land Sector and Removals Guidance.

A summary of near-term and long-term science-based targets required coverage is shown in Table 2 .

Table 2. Minimum boundary coverage for near-term targets and long-term targets.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| MINIMUM %BOUNDARY COVERAGE BY SCOPE                                                                                  | MINIMUM %BOUNDARY COVERAGE BY SCOPE                                                              | MINIMUM %BOUNDARY COVERAGE BY SCOPE                        |
|----------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| GHG inventory scope                                                                                                  | Near-term targets                                                                                | Long-term targets                                          |
| Scopes 1 and 2                                                                                                       | 95% minimum coverage                                                                             | 95% minimum coverage                                       |
| Scope 3                                                                                                              | 67% minimum coverage (if scope 3 emissions are at least 40% of total scope 1, 2 and 3 emissions) | 90% minimum coverage (all companies)                       |
| SPECIAL BOUNDARY COVERAGE REQUIREMENTS BY EMISSIONS SOURCE                                                           | SPECIAL BOUNDARY COVERAGE REQUIREMENTS BY EMISSIONS SOURCE                                       | SPECIAL BOUNDARY COVERAGE REQUIREMENTS BY EMISSIONS SOURCE |
| Emissions source                                                                                                     | Near-term targets                                                                                | Long-term targets                                          |
| Use-phase emissions from sold or distributed fossil fuels                                                            | Must be covered by a separate absolute reduction target                                          | Must be covered by a separate absolute reduction target    |
| Direct CO 2 emissions from biomass combustion, processing and distribution, as well as land-use emissions and carbon | Must be included in target boundary                                                              | Must be included in target boundary                        |

| removals from bioenergy feedstock            |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
|----------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Sector-specific target boundary requirements | See Table 4 for a detailed list of sector-specific requirements                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Biogenic emissions and removals              | FLAG companies are required to account for land-related emissions (gross biogenic land CO 2 emissions and removals). This includes all emissions from direct land use change (LUC) and land management (biogenic CO 2 , N 2 O and CH 4 ) related to on-farm activities. Companies with land emissions below the 20% FLAG threshold (as per FLAG-C1) that choose not to set a separate FLAG target must account for gross biogenic land emissions separately but include these emissions in the traditional (non-FLAG) target boundary. Removals shall not be used in this case. Companies with bioenergy emissions in scopes 1, 2 and 3 are required to account for the biogenic emissions as per the SBTi C11 criteria (non-FLAG) criteria. This includes all emissions from direct land use change (LUC) and land management (biogenic CO 2 , N 2 O and CH 4 ) related to on-farm activities. |

## 4.3.4 Meeting SBTi boundary criteria with several targets

Companies often set several targets that collectively meet the boundary requirements described above. Companies may consider setting targets covering emissions from various sectors or different scope 3 categories. This approach is valid to meet SBTi requirements.

## 4.3.5 Setting a single scope 3 target or multiple scope 3 targets

In addition to targets covering scope 1 and 2 emissions, companies can choose to set multiple, category-specific targets or a single target covering all relevant scope 3 categories. They may also choose to set a single target covering total scope 1, 2, and 3 emissions. Each type of target boundary has advantages and disadvantages.

## 1) A single target for total scope 1, 2 and 3 emissions

Example: Company A commits to reduce absolute scope 1, 2 and 3 GHG emissions 55% by 2030 from a 2017 base year.

## Advantages:

- ● May provide more comprehensive management of emissions across the entire value chain.
- ● Simple to communicate to stakeholders.
- ● Does not require base year recalculation for shifting activities between scopes (e.g., outsourcing).

## Disadvantages:

- ● May provide less transparency for each scope 3 category's emissions and reporting on progress.
- ● Requires the same base year for the different scopes, which may be difficult if scope 1 and 2 base years have already been established.

## 2) A single target for total scope 3 emissions

Example: Company B commits to reduce absolute scope 3 GHG emissions 60% by 2030 from a 2019 base year.

## Advantages:

- ● May provide greater flexibility on how to achieve GHG reductions across all scope 3 categories.
- ● Relatively simple to communicate to stakeholders.

## Disadvantages:

- ● May provide less transparency for each scope 3 category's emissions and reporting on progress.
- ● May require base year recalculation for shifting activities between scopes (e.g., outsourcing).

## 3) Separate targets for individual scope 3 categories

Example: Company C commits to reduce absolute scope 3 purchased goods and services GHG emissions 50% by 2030 from a 2019 base year. Company C further commits to reduce scope 3 business travel and employee commuting GHG emissions 55% per employee within the same timeframe.

## Advantages:

- ● Allows customization of targets for different scope 3 categories based on different circumstances.
- ● Provides more transparency for each scope 3 category.
- ● Adjustments to other scope 3 categories outside the specific target boundary would not trigger a target recalculation.
- ● Easier to track progress of specific activities.

## Disadvantages:

- ● More complicated to communicate to stakeholders.
- ● May require base year recalculation for outsourcing or insourcing.
- ● May result in shifting of emissions to other scope 3 categories, unless those categories also have their own targets.

## 4.4 Choose a target year

Near-term targets must have a target year of 2030, or 5-10 years from the date of submission to the SBTi, while long-term targets must have a target year of 2050 or sooner (2040 for targets using the power and maritime transport sector pathways). 10

Because the ambition of long-term science-based targets is target year independent, companies should begin by choosing any eligible target year. Based on the results of their target calculation, the company may adjust its chosen target year depending on its ability to achieve its long-term target.

10 Companies  using  the  maritime  transport  sector  guidance  and  its associated sector-specific pathway cannot have a target year for near-term targets before 2030.

## 4.5 Target-setting methods

Science-based target methods are used to calculate near-term and long-term targets based on a mitigation pathway and company inputs. Companies may choose from the methods described in Annex B. 11

When using SBTi tools and resources to model targets, companies should note that the outputs are minimum requirements. Companies are encouraged to set targets more ambitious than the minimum percentage reductions generated by the tool. In some cases, the minimum target ambition output will vary by different methods for a given company. This is due to the differences in target formulation and variation among the acceptable reduction pathways. For example, the minimum ambition required for a sector by the intensity convergence method (i.e., SDA) may require more or less emission reductions than the absolute reduction rate. To support the global transition to net-zero and demonstrate leadership, companies should screen the available methods and choose those that lead to the earliest reductions and the least cumulative emissions.

Certain types of target-setting methods are not permitted because of the difficulty in establishing whether these targets result in the necessary reductions, as they do not transparently demonstrate changes in emissions performance. In particular, targets to reduce emissions by a specified mass of GHGs (e.g., 'to reduce emissions by 5 million tonnes by 2030'). Please see Annex B for a list of permitted target-setting methods.

## 4.6 Calculating near and long-term SBTs

There are important differences when setting near-term and long-term science-based targets, as summarized in Table 3 below.

When calculating near-term targets, target ambition depends on the chosen base year and target year. Additionally, for companies using a base year earlier than the most recent year, some scope 1 and/or scope 2 targets must also have sufficient forward-looking ambition (FLA) (see Box 3 for an explanation on FLA).

On the other hand, calculating long-term targets does not depend on the chosen target year. Companies must either use the Corporate Net-Zero Tool to calculate long-term science-based targets, or, in some cases the relevant sector-specific tool. For example, companies with aviation, maritime and steel activities may also choose to use the respective sector-specific tools to calculate their long-term science-based targets.

Table 3. A comparison of boundary, ambition, timeframe, and methods between near and long-term targets.

11 This section does not cover methods that are specific to financial institutions. Please refer to Table 4 in this document and to the Financial Sector Science-Based Targets Guidance for information on methods for financial institutions.

|                 |               | Boundary What percentage is required for the emissions inventory coverage?   | Ambition What is the level of limiting temperature rise?   | Timeframe How many years does the target cover?                     | Methods What are the eligible methods to set targets?                                                                                                                                                                       |
|-----------------|---------------|------------------------------------------------------------------------------|------------------------------------------------------------|---------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Near- term SBTs | Scope 1 & 2   | 95%                                                                          | 1.5°C                                                      | 5-10 years 12                                                       | Cross-sector absolute reduction Sector-specific absolute reduction Sector-specific intensity convergence (i.e., SDA) Renewable electricity                                                                                  |
| Near- term SBTs | Scope 3       | If >40% of total emissions, 67% coverage                                     | Well-below 2°C                                             | 5-10 years 12                                                       | Cross-sector absolute reduction Sector-specific absolute reduction Sector-specific intensity convergence (i.e., SDA) Supplier/customer engagement Scope 3 economic intensity reduction Scope 3 physical intensity reduction |
| Long -term SBTs | Scope 1 and 2 | 95%                                                                          | 1.5°C                                                      | 2050 latest (2040 for the power and maritime transport SDA targets) | Cross-sector absolute reduction Sector-specific absolute reduction Sector-specific intensity convergence (i.e., SDA) Renewable electricity (maintenance target)                                                             |
| Long -term SBTs | Scope 3       | 90%                                                                          | 1.5°C                                                      | 2050 latest (2040 for the power and maritime transport SDA targets) | Cross-sector absolute reduction Sector-specific absolute reduction Sector-specific intensity convergence (i.e., SDA) Scope 3 economic intensity reduction Scope 3 physical intensity reduction                              |

## Box 3. Forward-looking ambition adjustment for near-term scope 1 and scope 2 SBTs

The forward-looking ambition (FLA) adjustment is an adjustment that must be applied to calculate the ambition of some near-term scope 1 and 2 absolute and intensity targets that do not use the most recent reporting year as the base year. It is a mechanism that rewards early action and ensures targets drive continued mitigation during a company's transition to net-zero, consistent with the Corporate Net-Zero Standard. The FLA adjustment prevents companies from setting targets that have already been achieved, and at the same time, it allows them to count past emissions reductions toward achieving near-term SBTs. This incentivizes companies to reduce their emissions as soon as possible and ensures a science-based minimum ambition requirement for companies that have taken early action.

The FLA adjustment only applies to companies that do not use the most recent year as a base year, and is applied within the Validation Portal. If a base year earlier than the most recent year is chosen, minimum target ambition requirements are calculated and the FLA adjustment is applied accordingly.

The FLA adjustment may be applied to scope 1 and 2 near-term targets that use the sector-specific absolute reduction method and the sector-specific intensity convergence method.

For both of these methods, the FLA adjustment depends on the base year, the most recent year, target year, and the magnitude of past emissions reductions, as described in the following formula:

12 Targets using the maritime transport pathway cannot have a target year for near-term targets before 2030.

## Where:

RTD = Percentage reduction (%) to date expressed as the reduction between base year and most recent year.

NZA = Percentage reduction (%) required for reaching net zero in 2050 from the chosen target base year (90%).

A0 = Minimum target ambition (%) based on the sector-specific absolute reduction before FLA adjustment.

In the formula above, the maximum value, either the calculated adjustment value or 0, is taken as the FLA adjustment. By taking the maximum value, companies with a negative calculated adjustment value will not have a reduction in ambition since 0 will be the greater of the two values. This approach means companies will not have an ambition decrease when their most recent year emissions are greater than their base year emissions.

The FLA adjustment formula shown above is applied to each scope separately. This means that for combined scope 1 and scope 2 targets, the FLA adjustment will be calculated independently for each scope to determine the combined scope 1 and scope 2 ambition.

For the sector-specific absolute reduction method , the FLA of near-term scope 1 and/or scope 2 targets must be consistent with reaching net-zero by 2050, assuming a linear absolute reduction between the most recent year and 2050. The closer a company gets to reducing emissions to the net-zero benchmark (e.g. 90%) from the base year by the most recent year, the less they need to further reduce emissions from the most recent year onwards for an eligible near-term SBT.

For the sector-specific intensity convergence method , the FLA of near-term scope 1 and/or scope 2 targets must be consistent with reaching net-zero by 2050, assuming a linear intensity reduction or intensity convergence between the most recent year and 2050. There are two options for ensuring that FLA meets SBTi requirements when using the sector-specific intensity convergence method:

- ● Option 1: The emissions intensity reduction between the most recent year and target year is equal to or exceeds the linear intensity reduction rate between the most recent year and 2050. In this case, the formula above applies.
- ● Option 2: The emissions intensity reduction between the most recent year and target year is consistent with the ambition required from the sector-specific intensity convergence between the most recent year and 2050. In some cases, the FLA adjustment with the sector-specific intensity convergence method using the most recent year will require a larger reduction than calculated by the sector-specific intensity convergence using base year data.

## 4.7 Target wording and communication

Finally, it is important to consider how the net-zero target and underlying target(s) can be expressed clearly and succinctly. There are three components that make up net-zero target wording:

- ● Overarching net-zero target
- ● Near-term science-based target

## ● Long-term science-based target

Figure 7. Net-zero target wording structure.

<!-- image -->

## 4.7.1 Overarching net-zero target

The company net-zero date is determined by the latest long-term SBT target date. Companies can express their overarching net-zero targets as:

Company X commits to reach net-zero GHG emissions across the value chain by [insert latest long-term SBT target date].

## 4.7.2 Near-term and long-term science-based target wording

Companies must include the near-term and long-term science-based target wording within their overall net-zero target. Please refer to the Standard Operating Procedure for the Validation of SBTi Targets for details.

## 4.7.3 Communicating targets

It is important that companies communicate accurately and effectively about their commitments or approved science-based targets along all stages of the SBTi journey. More information can be found in the Communications Guide for Companies and Financial Institutions and the Standard Operating Procedure for Validation of SBTi Targets.

## 5. THE CORPORATE NET-ZERO STANDARD CRITERIA AND RECOMMENDATIONS

## 5.1 Background to the Corporate Net-Zero Standard Criteria

The SBTi Corporate Net-Zero Standard Criteria was developed through extensive stakeholder consultation, in collaboration with the Net-Zero Expert Advisory Group. It includes all criteria that must be met for net-zero target(s) to be validated by the Science Based Targets initiative (SBTi), as well as recommendations which are important for transparency and best practice. It is important to note that criteria and recommendations are subject to change and may be updated.

Although this document contains all criteria for setting near-term science-based targets, companies should refer to the Corporate Near-term Criteria V5.3 if they wish to set science-based near-term targets only.

These criteria apply to companies not classified as financial institutions or small and medium-sized enterprises (SMEs). Financial institutions must set targets using the Financial Sector Science-based Targets Guidance. SMEs may use the SME validation route or the regular validation route to set targets.

Companies must also follow the GHG Protocol Corporate Standard, Scope 2 Guidance, and Corporate Value Chain (Scope 3) Accounting and Reporting Standard.

The SBTi Corporate Net-Zero Standard V1.3 should be read in conjunction with the Standard Operating Procedure for Validation of SBTi Targets, which describes the underlying process followed to assess targets, the Criteria Assessment Indicators for near-term and net-zero targets that detail the indicators used to determine conformance and non-conformance with criteria, and the SBTi Glossary, which lists the terms, definitions, and acronyms used in this document.

## 5.1.1 Terminology

This document explains the criteria, which are requirements that companies must follow, and recommendations, which companies should follow, to align with the Corporate Net-Zero Standard. Unless otherwise stated (including specific sections), all criteria apply to scopes 1, 2, and 3.

This document uses precise language to indicate requirements, recommendations, and allowable options that companies may choose to follow.

- ● The terms 'shall' or 'must' are used throughout this document to indicate what is required for targets to be in conformance with the Corporate Net-Zero Standard.
- ● The term 'should' is used to indicate a recommendation, but not a requirement.
- ● The term 'may' is used to indicate an option that is permissible or allowable.

The terms 'required' or 'must' are used in the guidance to refer to requirements. 'Can' and 'is encouraged' may be used to provide recommendations on implementing a requirement or 'cannot' may be used to indicate when an action is not possible.

The letter 'C' preceding a number indicates a criterion and the letter 'R' preceding a number indicates a recommendation.

## 5.1.2 Effective dates of updated criteria

The Corporate Net-Zero Standard Criteria version 1.3.1 will be in effect as of 13 April 2026. Criteria and recommendations that have been revised since Version 1.0 are marked with an asterisk (*).

## 5.2 General criteria

## 5.2.1 Target boundary

## 5.2.1.1 Organizational boundary

C1 - Organizational boundary: Companies should submit targets only at the parent- or group level, not the subsidiary level. Parent companies shall include the emissions of all subsidiaries in their target submission, in accordance with the boundary criteria. 13 In cases where both parent companies and subsidiaries submit targets, the parent company's target must also include the emissions of the subsidiary if it falls within the parent company's emissions boundary given the chosen inventory consolidation approach. 14, 15

- R1 - Setting organizational boundaries: The SBTi strongly recommends that a company's organizational boundary, as defined by the GHG Protocol Corporate Standard, is consistent with the organizational boundary used in the company's financial accounting and reporting procedures. Companies should use the same organizational boundary year-on-year. If a company's organizational boundary changes, they should refer to C33 of this standard.

## 5.2.1.2 GHG coverage

- C2 - Greenhouse gasses: The targets shall cover all relevant emissions of the seven GHGs required by the GHG Protocol Corporate Standard. 16

## 5.2.1.3 Scope coverage

- C3 - Scope 1 and scope 2: The targets shall cover company-wide scope 1 and scope 2 emissions, as defined by the GHG Protocol Corporate Standard. 17

C4 - Scope 3: If a company's relevant scope 3 emissions are 40% or more of total scope 1, 2, and 3 emissions, they shall be included in near-term science-based targets. All companies involved in the sale or distribution of natural gas and/or other fossil fuels shall set separate scope 3 targets for the use of sold products, irrespective of the share of these emissions

13 * As outlined in C2 to C7.

14 * Brands, licensees, and/or specific regions or business divisions of a company will not be accepted as separate targets, unless they fall outside of a parent company's chosen consolidation approach.

15 * Companies must integrate emissions from their structural changes into their GHG inventory within a reasonable timeframe.

16 The seven GHGs are carbon dioxide (CO2), methane (CH4), nitrous oxide (N2O), hydrofluorocarbons (HFCs), perfluorocarbons (PFCs), sulfur hexafluoride (SF ), and nitrogen trifluoride (NF ). 6 3

17 * GHG accounting that is not proven to adhere to the GHG Protocol accounting standard and the SBTi criteria assessment indicators will not be accepted by the SBTi.

compared to total scope 1, 2, and 3 emissions of the company. All companies shall include emissions from all relevant scope 3 categories in long-term science-based targets.

## 5.2.1.4 Emissions coverage

- C5 - Scope 1, 2, and 3 allowable exclusions: Companies shall not exclude more than 5% of total combined scope 1 and scope 2 emissions from either the boundary of the GHG inventory or the target boundary. 18, 19 Companies shall not exclude more than 5% of emissions from their total scope 3 GHG inventory. 20 Scope 3 target boundary requirements are outlined in C6 and C7.
- C6 - Scope 3 emissions coverage for near-term targets: Companies shall set one or more emission reduction near-term targets and/or supplier or customer engagement targets that collectively cover(s) at least 67% of total reported and excluded scope 3 emissions considering the minimum boundary of each scope 3 category in conformance with the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard. 21
- C7 - Scope 3 emissions coverage for long-term targets: The boundary of long-term science-based targets shall cover at least 90% of total scope 3 emissions considering the minimum boundary of each category in conformance with the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard. Exclusions in the GHG inventory and target boundary shall not exceed 10% of total scope 3 emissions.
- R2 - Targets covering optional scope 3 emissions: Targets to reduce scope 3 emissions that fall outside the minimum boundary of scope 3 categories are not required but are nevertheless encouraged when these emissions are significant. Companies may cover these emissions with a scope 3 target, but such targets cannot count towards the thresholds defined in C6 and C7 for scope 3 emissions (i.e., these targets are in addition to the company's required scope 3 targets). For a definition of optional emissions for each scope 3 category, please see Table 5.4 (page 34) of the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard.

## 5.2.2 Method validity (near and long-term targets)

- C8 - Method validity: Targets must be modeled using the latest version of methods and tools approved by the SBTi. Targets modeled using previous versions of the tools or methods may only be submitted to the SBTi for validation within 6 months of the publication of the revised method or sector-specific tools.

18 * The total targeted scope 1 and 2 emissions shall be greater than or equal to 95% of total (reported + excluded) scope 1 and 2 emissions. This means that a company shall not exclude 5% from the inventory boundary and then also exclude a further 5% from the target boundary.

20 The SBTi does not recognize emissions perceived to be 'negligible' as a rationale for not reporting them. Even if emissions from certain activities or operations are perceived to be negligible, these emissions still must be quantified and reported in the reporting company's GHG inventory or disclosed as an exclusion. 19 Where a company's scope 1 or 2 emissions are deemed immaterial (i.e., under 5% of total combined scope 1 and 2 emissions), companies may set their SBT solely on the scope (either scope 1 or scope 2) that covers more than 95% of the total scope 1 and 2 emissions. The company shall continue to report on both scopes and adjust their targets as needed, according to the GHG Protocol's principle of completeness, and as per C32 and C33.

21 * GHG accounting that is not proven to adhere to the GHG Protocol minimum boundaries and the SBTi criteria assessment indicators will not be accepted by the SBTi.

## 5.2.3 Emissions accounting requirements

C9 - Scope 2 accounting approach: Companies shall disclose whether they are using a location- or market-based accounting approach as per the GHG Protocol Scope 2 Guidance to calculate base year emissions and to track performance against a science-based target. The GHG Protocol requires measuring and reporting scope 2 emissions using both approaches. However, a single and consistent approach must be used for setting and tracking progress toward a SBT (e.g., using location-based approach for both target setting and progress tracking).

C10 - Scope 3 inventory: Companies shall complete a scope 3 inventory covering gross scope 3 emissions for all its relevant emissions sources according to the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard. 22, 23

*C11 - Biogenic accounting: Companies that use bioenergy or have biogenic emissions within their operations or value chain shall:

- ● Report all CO  emissions and removals in line with GHG Protocol guidance. ₂
- ● Include net 24 CO  emissions from biogenic sources in the target boundary for scopes ₂ 1, 2 and 3 25 , and track these net emissions when reporting progress against science-based targets.
- ● Include the required footnote in target language 26 : 'The target boundary includes land-related emissions and removals from biogenic feedstocks.'
- ● Report all upstream CO e emissions from bioenergy and biogenic feedstocks in the ₂ main GHG inventory. Upstream emissions must include:
- ○ CO e from direct land use change 27  (LUC) ₂
- ○ Non-LUC emissions, including N O and CH  from land management ₂ ₄
- ○ CO e from processing and distribution ₂
- ● Follow any future GHG Protocol guidance on bioenergy accounting once released to maintain alignment with C11.

22 * To determine relevance of scope 3 activities for inclusion in the target boundary, companies will be assessed against minimum boundary in Table 5.4 and using the criteria in Table 6.1 of the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard. Please note that, although beyond the minimum boundary, all transport-related emissions across all sectors must be reported on a well-to-wheel (WTW) basis in companies' GHG inventories (well-to-wake for aviation and maritime transport). All use-phase emissions from third-party distributed fossil fuels must be reported in scope 3 category 11 for all companies engaged in this type of distribution activity.

23 * Companies may use the Partnership for Carbon Accounting Financials (PCAF) Global GHG Accounting and Reporting Standard for the Financial Industry to calculate financed emissions. However, emissions beyond the minimum requirements of the Greenhouse Gas Protocol for Scope 3 Category 15 Investments as per Table 5.9 (page 52) of the GHG Protocol Corporate Value Chain (Scope 3) Accounting and Reporting Standard shall not count towards the mandatory boundary for scope 3 targets (see C6 and C7). Companies may, however, set optional targets on these emissions (see R2).

24 Negative emissions due to biogenic removals shall not be accounted for in a company's target formulation or as progress towards SBTs. In addition, removals that are not directly associated with biogenic feedstock production are not accepted to count as progress towards SBTs or to net emissions in a company's GHG inventory.

25 Biogenic scope 3 emissions must only be included if the net scope 3 coverage is below the minimum threshold.

26 Companies intending to use bioenergy or other biogenic emissions sources during the target timeframe must also include the required footnote in their target language.

27 Reporting emissions from indirect LUC is optional.

- C12 - Carbon credits: The use of carbon credits must not be counted as emission reductions toward the progress of companies' near-term or long-term science-based targets. Carbon credits may only be considered as an option for neutralizing residual emissions (see C28) or to finance additional climate mitigation beyond their science-based emission reduction targets (see R12).
- C13 - Avoided emissions: Avoided emissions fall under a separate accounting system from corporate inventories and do not count toward near-term or long-term science-based emission reduction targets.
- R3 - Biofuel certification: The SBTi recommends that companies using or producing biofuels for transport should support their bioenergy GHG accounting with recognized biofuels certification(s) to disclose that the data on land-related emissions and removals represents the relevant biofuel feedstock production.
- R4 - Bioenergy data reporting: The SBTi recommends that companies report direct biogenic CO2 emissions and removals from bioenergy separately. Emissions and CO2 removals associated with bioenergy shall be reported as net emissions, according to C11, at a minimum. However, companies are encouraged to report gross emissions and gross removals from bioenergy feedstocks.

## 5.3 Net-zero target formulation

## 5.3.1 Net-zero definition

C14 - State of net-zero emissions: Companies shall set one or more targets to reach a state of net-zero emissions, which involves: (a) reducing scope 1, 2 and 3 emissions to zero or a residual level consistent with reaching net-zero emissions at the global or sector level in eligible 1.5°C scenarios or sector pathways and (b) neutralizing any residual emissions at the net-zero target date - and any GHG emissions released into the atmosphere thereafter.

## 5.3.2 Structure

- C15 - Net-zero target structure: Companies shall set both near-term and long-term science-based emission reduction targets according to the requirements outlined in this standard. If a company sets a near-term target that meets long-term target requirements, the target shall be accompanied by a long-term target that, at a minimum, maintains the same level of emissions thereafter.

## 5.3.3 Timeframe

- C16 - Base year: The base year shall be no earlier than 2015. The company shall use the same base year for its long-term science-based targets as its near-term science-based targets. Scope 1 and scope 2 targets shall use the same base year. 28 The SBTi does not accept multi-year average base years, unless this is specified in the sector guidance relevant to the company.
- *C17 - Target year(s): Absolute and intensity-based emission reduction near-term targets shall cover a minimum of 5 years and a maximum of 10 years from the date the target is

28 * Scope 3 targets are recommended but not required to use the same base year as scope 1 and scope 2 targets. Base years across different scope 3 targets must be the same.

submitted to the SBTi for validation. Long-term targets shall have a target year no later than 2050. For companies using sector pathways that reach net-zero before 2050 (e.g., power generation and maritime), long-term science-based targets covering relevant activities shall have a target year no later than the sector's year of net-zero in eligible 1.5˚C pathways.

C18 - Progress to date: The minimum forward-looking ambition of near-term targets covering scope 1 and/or scope 2 emissions is consistent with reaching net-zero by 2050 at the latest, assuming a linear absolute reduction, linear intensity reduction, or intensity convergence between the most recent year and 2050 (not increasing absolute emissions or intensity). 29, 30

R5 - Long-term targets: Targets that cover more than 10 years from the date of submission are considered long-term targets. Long-term targets can only be validated in accordance with the SBTi Corporate Net-Zero Standard Criteria.

R6 - Consistency: It is recommended that companies use the same base years for all near-term targets.

*R7 - 2030 target year: It is recommended that companies select a 2030 target year for all near-term targets. Applying this recommendation exempts a company from the 5-10 year timeframe requirement in C17.

## 5.3.4 Ambition

## 5.3.4.1 Scope 1 and 2 (near- and long-term targets)

C19 - Level of ambition for scope 1 and 2 targets: At a minimum, scope 1 and scope 2 targets shall be consistent with the level of decarbonization required to keep global temperature increase to 1.5°C compared to pre-industrial temperatures. This applies to both near-term and long-term targets. 31

C20 - Absolute targets: Absolute reduction targets for scope 1 and scope 2 are eligible when they are at least as ambitious as the minimum of the approved range of emissions scenarios consistent with the 1.5°C goal or aligned with the relevant 1.5°C sector-specific absolute pathway (long-term targets only).

C21 - Intensity targets: Intensity targets for scope 1 and scope 2 emissions are only eligible when they are modeled using an approved 1.5°C sector pathway applicable to companies' business activities.

29 * The most recent year used for scope 1 and scope 2 emissions shall be the same year. The most recent year used for scope 3 emissions is recommended to be the same year as scope 1 and scope 2.

30 * Companies shall provide all the relevant GHG inventory data including a most recent year GHG inventory. For submissions in 2025, the most recent inventory shall be no earlier than 2023 i.e. allowable most recent years are 2023 and 2024. Companies should also note that using proxy data (i.e., applying one reporting year's data to another reporting year) is not permitted. For example, a company may not apply base year emissions to the most recent year.

31 * When a company uses fiscal years in its GHG accounting, the SBTi assesses minimum ambition based on the calendar year (CY) where the majority of the months occur. E.g. FY2022 with a date range of April 2021 March 2022 it would be assessed as CY2021. In the case where a FY is evenly split across a CY (i.e., a FY ends on June, 30), ambition is assessed using the later year in the date range. This approach is applicable to all targets.

R8 - Choosing an approach: The SBTi recommends using the most ambitious decarbonization scenarios that lead to the earliest reductions and the least cumulative emissions.

## 5.3.4.2 Scope 3 (near- and long-term targets)

C22 - Level of ambition for scope 3 emissions reductions targets: At a minimum, near-term scope 3 targets (covering total required scope 3 emissions or individual scope 3 categories) shall be aligned with methods consistent with the level of decarbonization required to keep global temperature increase well-below 2°C compared to pre-industrial temperatures. For long-term scope 3 targets, this minimum ambition is increased to 1.5°C. 32

*C23 - Supplier or customer engagement targets: Near-term targets to drive the adoption of science-based emission reduction targets by their corporate suppliers and/or customers shall meet the following requirements:

- ● Boundary: Companies may set engagement targets across upstream or downstream scope 3 categories.
- ● Formulation: Companies shall provide information in the target language on what percentage of emissions from relevant upstream and/or downstream categories is covered by the engagement target or, if that information is not available, what percentage of annual procurement spend is covered by the target. 33
- ● Timeframe: Engagement targets shall be fulfilled within a maximum of 5 years from the date the company's target is submitted to the SBTi for validation.
- ● Ambition level: The company's suppliers/customers shall have science-based emission reduction targets in line with the latest version of the SBTi Corporate Near-term Criteria.

C24 - Absolute targets (scope 3): Absolute targets for scope 3 are eligible when they are at least as ambitious as the minimum of the approved range of emissions scenarios consistent with the well-below 2°C goal (near-term targets), the 1.5°C goal (long-term targets), or aligned with the relevant 1.5°C sector-specific absolute pathway (long-term targets only).

C25 - Intensity targets (scope 3): Intensity targets for scope 3 are eligible when they are modeled using an approved sector-specific physical intensity pathway where applicable to companies' business activities or using eligible physical intensity or economic intensity approaches. This applies to both near-term and long-term targets. Intensity targets on upstream scope 3 categories must reflect both supply-side and demand-side mitigation levers, where specified by sector-specific guidance.

*R9 - Supplier engagement: Companies should recommend that their suppliers use the SBTi guidance and tools available to set science-based targets. SBTi validation of supplier

32 * When a company uses fiscal years in its GHG accounting, the SBTi assesses minimum ambition based on the calendar year (CY) where the majority of the months occur. E.g. FY2022 with a date range of April 2021 March 2022 it would be assessed as CY2021. In the case where a FY is evenly split across a CY (i.e., a FY ends on June, 30), ambition is assessed using the later year in the date range. This approach is applicable to all targets.

33 If measuring coverage by spend, the company shall provide an estimate of the emissions coverage associated with that spend for validation purposes to demonstrate that criterion C6 has been met, by the supplier or customer target alone, or together with other scope 3 target(s).

science-based targets is recommended but not required. Additionally, it is recommended to use 2030 or earlier as the supplier engagement target year.

## 5.3.4.3 Combined targets (near- and long-term targets)

C26 - Combined scope targets: Targets combining scopes (e.g., 1+2, or 1+2+3) are permitted if the SBTi can review the ambition of the individual target components and confirm each meets the relevant ambition criteria. 34

## 5.3.4.4 Renewable electricity targets (near- and long-term targets)

C27 - Renewable electricity (scope 2 only): Targets to actively source renewable electricity at a rate consistent with 1.5°C scenarios are an acceptable alternative to scope 2 emission reduction targets over emissions from the generation of procured electricity. 35 The SBTi has identified 80% renewable electricity procurement by 2025 and 100% by 2030 as thresholds (portion of renewable electricity over total electricity use) for this approach, in line with the recommendations of RE100. 36  Companies that already source electricity at or above these thresholds shall maintain or increase their use of renewable electricity to qualify. For long-term targets, companies shall maintain 100% renewable electricity procurement beyond 2030.

R10 - Purchased heat and steam: When modeling targets using the Sectoral Decarbonization Approach (SDA), companies should model purchased heat and steam related emissions as if they were part of their direct emissions, i.e., scope 1.

R11 - Efficiency considerations for target modeling: If companies are using a method that does not already embed efficiency gains for the specific sector, market - and the decarbonization projected for the power sector is based on a 1.5°C scenario - these factors should be considered when modeling electricity-related scope 2 targets.

## 5.3.5 Beyond value chain mitigation

R12 - Beyond value chain climate mitigation: Companies should take action or make investments outside their own value chains to mitigate GHG emissions in addition to their near-term and long-term science-based targets. For example, a company could provide annual support to projects, programs and solutions providing quantifiable benefits to climate, especially those that generate additional co-benefits for people and nature. Companies should report annually on the nature and scale of those actions. 37

34 * When submitting combined near-term targets, the scope 1+2 portion must be in line with at least a 1.5°C scenario and the scope 3 portion of the target must be in line with at least a well-below 2°C scenario for near-term targets. When submitting combined long-term targets, the scope 1+2 portion must be in line with at least a 1.5°C scenario and the scope 3 portion of the target must be in line with at least a 1.5°C scenario. For sectors where minimum target ambition is further specified for companies' scope 3 activities, C35 supersedes C26.

35 * Companies reporting scope 2 emissions using location-based methods can still set a renewable electricity target provided they have the capacity to demonstrate active sourcing of renewable electricity through market instruments.

36 RE100 guidance states that setting a 100% renewable electricity target by 2030 at the latest shows a strong level of leadership.

37 Please see the SBTi 'Above and Beyond: An SBTi report on the design and implementation of beyond value chain mitigation (BVCM)' for details.

## 5.3.6 Neutralization

C28 - Neutralization of unabated emissions to reach net-zero: Companies shall remove carbon from the atmosphere and permanently store it to counterbalance the impact of any unabated emissions that remain once companies have achieved their long-term science-based target, and for subsequent years thereafter. The neutralization of unabated emissions applies to both the emissions reduction target boundary and to any unabated emissions that have been excluded from the GHG inventory. 38

R13 - Neutralization milestones: Companies should disclose information such as planned milestones and near-term investments that demonstrate the integrity of commitments to neutralize unabated emissions at net-zero.

## 5.3.7 Target formulation

C29 - Target formulation: Companies shall publicly set a net-zero target that clearly and transparently communicates each of the target's relevant components including (a) net-zero target year, (b) magnitude of emissions reductions that will be achieved for near-term and long-term science-based targets, and (c) a base year. 39

## 5.4 Reporting, recalculation and target validity

## 5.4.1 Reporting

C30 - Frequency: The company shall publicly report its company-wide GHG emissions inventory and progress against published targets on an annual basis.

C31 - Reporting completeness: Companies shall publicly report information pertaining to progress against validated targets, including separately reporting emissions and removals in the annual GHG inventory.

R14 - Where to disclose: There are no specific requirements regarding where the inventory and progress against published targets should be disclosed, as long as it is publicly available. The SBTi recommends disclosure through standardized, comparable data platforms such as CDP's climate change annual questionnaire. Annual reports, sustainability reports and the company's website are also acceptable platforms.

## 5.4.2 Recalculation and target validity

C32 - Mandatory target review: Companies shall review all active targets, at a minimum, every 5 years to ensure consistency with the latest SBTi criteria. 40 If targets do not meet SBTi criteria, then they shall be updated and revalidated. Companies with targets approved in

38 * For example, a company with 100 tCO2e emissions in the base year excludes 1 tCO2e from its GHG inventory and 1 tCO2e from its target boundary, resulting in 98 tCO e covered by its long-term SBT. After reducing 2 emissions covered by its long-term SBT by 90%, this results in 9.8 tCO e of residual emissions. Assuming the 2 exclusions remain constant, the company is required to neutralize 11.8 tCO e (1 tCO e from inventory exclusions, 2 2 1 tCO2e from target boundary exclusions, and the remaining 9.8 tCO2 e).

39 * Please note that the base year may be excluded from the overarching wording only if the scope 1 and 2 base year is different from the scope 3 base year.

40 * Please note that the beginning of the review period for all active targets corresponds to the date of initial validation of the oldest currently active target or the most recent target validation date of each target where all the company targets were updated.

2020 or earlier shall review all active targets by 2025. Companies shall follow the most recent applicable criteria at the time of resubmission.

C33 - Triggered target recalculation: Targets shall be recalculated and revalidated when significant changes occur that could compromise the existing target. The following changes shall trigger a target recalculation:

- ● Scope 3 emissions become 40% or more of aggregated scope 1, 2 and 3 emissions (applies only to near-term science-based targets).
- ● Changes in the consolidation approach chosen for the GHG inventory.
- ● Emissions of exclusions in the inventory or target boundary change significantly.
- ● Significant changes in company structure and activities (e.g., acquisition, divestiture, merger, insourcing or outsourcing, shifts in goods or service offerings). 41
- ● Adjustments to data sources or calculation methodologies resulting in significant changes to an organization's total base year emissions or the target boundary base year emissions (e.g., discovery of significant errors or a number of cumulative errors that are collectively significant).
- ● Other significant changes to projections/assumptions used in setting the science-based targets. 42

Companies shall apply a significance threshold of 5% or less. For base year emissions, a change of 5% in an organization's total base year emissions would trigger a base year emissions recalculation. A change of 5% or more in the base year emissions covered within a target boundary would trigger a target recalculation. 43

If a significant change occurs and the company's target(s) no longer meet SBTi criteria, then the target(s) shall be recalculated and revalidated. Companies shall follow the most recent applicable criteria at the time of resubmission.

C34 - Target validity: Companies with approved targets must announce their target publicly on the SBTi website within 6 months of the approval date. Targets unannounced after 6 months must go through the approval process again unless a different publication time frame has been agreed in writing with the SBTi.

R15 - Validity of target projections: The SBTi recommends companies check the validity of their target-related projections on an annual basis. The company should notify the SBTi of any significant changes and report these major changes publicly, as relevant.

41 * For example, a target recalculation may be triggered if a shift of goods and service offerings results in a shift of emissions between scopes of already validated targets (e.g.,  if a company has a scope 1+2 target separate from a scope 3 target, and emissions that were first in scope 3 are shifted to scope 1 or scope 2 because of a change in the company's offering). A target recalculation may also be triggered if a company's current targets use a metric that becomes irrelevant after a shift in goods or service offerings (e.g., if a car manufacturer stopped selling passenger cars and pivoted to freight trucks, their use of sold products target would no longer be appropriate to model with the sold vehicle pathway and 'passenger-kilometers' would no longer be an appropriate metric).

42 * For example, for intensity targets, changes in growth projections.

43 * Please note that the significance threshold for target recalculation is relative to the scopes covered by the target. For example, if a company has a validated scope 1+2 target and their scope 1+2 base year emissions change by 5% or more, this triggers a target recalculation. Similarly, if a company has a validated scope 1+2+3 target and their scope 1+2+3 base year emissions change by 5% or more, this triggers a target recalculation.

## 5.5 Sector-specific guidance

C35 - Requirements from sector-specific guidance: Companies must follow requirements for target setting and minimum ambition levels as indicated in relevant sector-specific methods and guidance - at the latest, 6 months after sector guidance publication. A list of the sector-specific guidance and requirements is available below (Table 4 of the Corporate Net-Zero Standard). 44

## 5.5.1 Fossil fuel sales, distribution, and other business

C36 - Companies in the fossil fuel production business, or with significant revenue from fossil fuel business lines: The SBTi will not currently validate targets for:

- ● Companies with any level of direct involvement in exploration, extraction, mining and/or production of oil, natural gas, coal or other fossil fuels, irrespective of percentage revenue generated by these activities.
- ● Companies that derive 50% or more of their revenue from the sale, transmission and distribution of fossil fuels, or by providing equipment or services to fossil fuel companies.
- ● Companies with more than 5% revenue from fossil fuel assets (e.g., coal mine, lignite mine, etc.) for extraction activities with commercial purposes.

These companies must follow the applicable sector standards if available.

*C37 - Sale, transmission, distribution of oil, natural gas, coal as well as other fossil fuels: Companies that sell, transmit, or distribute natural gas (or other fossil fuel products) shall set separate emission reduction targets for scope 3 category 11 'use of sold products' covering emissions from the combustion of the sold, transmitted, or distributed fossil fuels that are at a minimum consistent with the level of decarbonization required to keep global temperature increase to 1.5°C compared to pre-industrial temperatures, irrespective of the share of these emissions compared to the total scope 1, 2, and 3 emissions of the company 45 , company's sector classification, or whether fossil fuel sale/distribution is the company's primary business. In order to meet the 67% near-term and 90% long-term scope 3 coverage, companies may need to set additional targets covering other scope 3 categories. Customer engagement targets are not eligible for this criterion.

45 Sales of low-volume fossil fuel products intended for occasional personal use, such as lighters and single-use camping stove canisters, are exempt from this requirement. Furthermore, this requirement does not apply if emissions in scope 3 category 11 from the combustion of the sold, transmitted, or distributed fossil fuels constitute less than 1% of the company's total scope 3 inventory and are less than 100,000 tCO2e. 44 * The Corporate Net-Zero Standard should be complemented with SBTi sector-specific guidance whenever the sector and/or activity covered by the sector guidance is relevant to the company seeking SBTi validation, e.g. a company with aviation, maritime, and financial services activities is encouraged to set separate sector-specific targets for each of the activities relevant to them based on SBTi sector guidance. Please note that the target boundary coverage is to be met at the company wide-level, not at target level, unless otherwise stated.

## 6. SECTOR-SPECIFIC REQUIREMENTS

Sector-specific guidance and methods are currently available for many sectors. All new sector-specific guidance that becomes available will be uploaded to the sector guidance page on the SBTi website. The SBTi has sector-specific requirements related to the use of target-setting methodologies and minimum ambition levels (please see table below). 46

Table 4. Eligible pathways, methods, and tools for all sectors and activities

| Sector/activity                                   | Eligible pathways, methods, tools                                                                                                                                                                                                                                       | Guidance and further notes                                                                                                                                                                                                                                                                                                             |
|---------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Companies not covered by any SBTi sector guidance | ● Cross-sector pathway with absolute reduction method for near-, and long-term targets. See Corporate Near-Term Tool and Corporate Net-Zero Tool.                                                                                                                       | Please note that companies in certain sectors (e.g., oil and gas) cannot currently set targets with the SBTi.                                                                                                                                                                                                                          |
| Aluminum                                          | ● Cross-sector pathway with absolute reduction method for near-, and long-term targets. See Corporate Near-Term Tool and Corporate Net-Zero Tool.                                                                                                                       |                                                                                                                                                                                                                                                                                                                                        |
| Apparel                                           | Cross-sector pathway with absolute reduction method for near-, and long-term targets. See Corporate Near-Term Tool and Corporate Net-Zero Tool.                                                                                                                         | Optional guidance is available for companies in the apparel and footwear sector.                                                                                                                                                                                                                                                       |
| Air transport                                     | Options: ● Aviation pathway with intensity convergence method (i.e., SDA) for near-, and long-term targets on well-to-wake (WTW) emissions, recommended for all companies providing air transport services. See the Aviation Tool. ● Cross-sector pathway with absolute | For all transport-related emissions across all sectors, companies shall set targets over these emissions on a well-to-wheel (WTW) basis in their GHG inventory (well-to-wake for aviation and maritime transport). Aviation target formulation and communication must explicitly state that targets are exclusive of non-CO ₂ factors. |

46 Please note that in case of inconsistencies between Table 4 and sector-specific guidance, the latest published information applies.

| Sector/activity   | Eligible pathways, methods, tools                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Guidance and further notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                   | reduction method for near-, and long-term targets on WTW. See Corporate Near-Term Tool and Corporate Net-Zero Tool. Please note that whichever pathway is chosen, the target boundary must cover WTW, as specified in the SBTi Aviation Guidance.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Targets must include a footnote stating that non-CO ₂ factors which may also contribute to aviation-induced warming are not included in this target and whether the company has publicly reported or commits to publicly report its non-CO 2 impacts. All companies using the Aviation Tool must not choose 2020, 2021 or 2022 as the base year. The years 2020-2022 are anomalous for the industry due to the COVID-19 pandemic.                                                                                                                                                                                                                                                                       |
| Buildings         | Companies that own, develop and manage buildings and meet the emissions-based thresholds outlined in the Buildings Criteria are required to ● Use the sector-specific intensity convergence method (i.e., SDA) for in-use operational emissions using the new SBTi-CRREM (Carbon Risk Real Estate Monitor) pathways if at least 20% of their GHG inventory (scopes 1, 2, and 3) are emissions from buildings' operations. ● Use the SBTi cross-sector methods, or the intensity convergence method (i.e., SDA) or the sector-specific absolute reduction method to model upfront embodied emissions targets, if at least 20% of their GHG inventory (scopes 1, 2, and 3) are emissions from buildings' operations See the SBTi Buildings Target-Setting | Real estate investment trusts (REITs) wishing to set targets must specify if they are a mortgage-based or equity-based REIT. Equity REITs must pursue the regular target validation route for companies. Mortgage REITs must instead utilize the Financial Institutions guidance for setting science-based targets. The sector-specific Buildings resources include: ● Criteria and explanatory guidance for GHG accounting and target-setting for both in-use operational and upfront embodied emissions. ● Standalone Buildings Target-Setting Tool for target-setting with sector-specific methods using granular sectoral pathways for in-use operational emissions and upfront embodied emissions. |
| Cement            | Options: ● Sector-specific intensity convergence method (i.e., SDA) for near-, and long-term targets. See Corporate Near-Term Tool and Corporate Net-Zero Tool. ● Sector-specific absolute reduction method for long-term targets. See Corporate Net-Zero Tool. ● Cross-sector pathway with absolute reduction method for near-, and long-term targets. See Corporate                                                                                                                                                                                                                                                                                                                                                                                   | The SBTi has released guidance to aid companies in the cement industry in setting science-based targets. Regardless of the pathway chosen, near-term science-based targets for cement activities shall include a scope 3 target which includes the emissions from purchased cement and clinker (under scope 3 category 1 'purchased goods and services'), irrespective of the share of these emissions compared to the total scope 1, 2 and 3 emissions of                                                                                                                                                                                                                                              |

| Sector/activity        | Eligible pathways, methods, tools                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Guidance and further notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
|------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                        | Near-Term Tool and Corporate Net-Zero Tool.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | the company.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Chemicals              | See 'all other sectors'.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | The SBTi is developing guidance for companies in the chemicals sector.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Financial institutions | Financial Institutions Near-Term Criteria enable financial institutions to set science-based targets on their financed emissions in the near term-covering a 5-10 year timeframe: ● Absolute reduction method or sector-specific intensity convergence (i.e., SDA) for near-term targets on scope 1 and 2 emissions. See Corporate Near-Term Tool. For near-term targets on scope 3 category 15 activities: ● Sector-specific intensity convergence method (i.e., SDA). See Corporate Near-Term Tool and other sector-specific tools. Based on this method, only financing within the same sector is aggregated to produce a portfolio-level intensity. ● Portfolio Coverage method. See SBTi Finance Portfolio Coverage tool. Based on this method, financial institutions increase the percentage of portfolio companies that have SBTi-validated science-based targets until all portfolio companies have validated science-based targets by 2040. ● Temperature Rating method. See SBTi Finance Temperature Scoring Tool. Based on this method, financial institutions commit to improve portfolio temperature alignment scores, so that the portfolio's scope 1 and 2 temperature score is 1.5ºC and 1.75ºC for scope 1, 2 and 3 by 2040. ● The Fossil Fuel Finance method requires the disclosure, halt, transition, and phaseout of fossil fuel-related activities. The SBTi Financial Institutions Net-Zero Standard allows the use of the following target-setting methods, all of which can be calculated using the SBTi Financial Institutions Net-Zero Target-Setting Tool: ● Portfolio climate-alignment targets require financial institutions to | The SBTi Financial Institutions Near-Term Criteria is required for entities that generate 5% or more of its revenue from investment and lending activities. This includes but is not limited to banks, asset managers and private equity firms, asset owners and insurance companies, and mortgage real estate investment trusts (REITs). Real economy companies that have more than 5% of revenue from financial activities are encouraged to use SBTi to set targets on those activities in addition to their corporate targets. Currently, public financial institutions are not covered within the SBTi framework. The SBTi Financial Institutions Net-Zero Standard is designed for institutions of all sizes and geographies that generate 5% or more of their revenue from any of the following five financial activities: lending, asset owner investing, asset manager investing, insurance underwriting and capital market activities. The Standard is intended for all commercially-operated, private, and public financial institutions, including public pension funds and sovereign wealth funds. Other businesses that generate less than 5% of their revenue from financial activities are encouraged, but not required, to use the Standard when setting science-based targets. The Financial Institutions Net-Zero Standard presents several innovations compared to the existing Financial Institutions Near-Term Criteria, including: a more comprehensive set of asset classes and financial activities (i.e., insurance underwriting and capital market activities); extended use of more actionable metrics and targets (in addition to emission reduction targets); and policies to align the most emission intensive activities, such as financing for fossil fuel activities and deforestation. The Financial Institutions Net-Zero |

| Sector/activity                     | Eligible pathways, methods, tools                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | Guidance and further notes                                                                                                                                                                                                                                                                                                                                                                                        |
|-------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                     | increase the share of climate-aligned financial activities across their portfolio. This method is available to cover financial activities when setting both near-term and long-term portfolio targets. Optional sectoral target-setting methods for near-term portfolio targets: ● Phaseout targets require a 100% reduction in absolute emissions from the coal sector by the phase out year. ● Absolute Contraction: requires a % reduction of absolute emissions from the oil and gas sector in line with the referenced sector pathway. ● Portfolio Intensity Convergence: requires the portfolio intensity to converge to the referenced sector pathway. ● Portfolio Index Alignment: indicates the minimum %share of zero-emissions electricity generation capacity or the %share of zero-emission vehicles produced relative to all electricity generation capacity or vehicles that are attributed to financial activities, in line with the respective sectoral pathway in the reference year. More details about these methods are available in the Financial Institutions Net-Zero Target-Setting Methods and Tool Documentation and Table 4.3 in the Financial Institutions Net-Zero Standard lists the accepted metrics and the | Standard complements the SBTi Corporate Net-Zero Standard: together, they cover all emissions scopes and categories. The Financial Institutions Net-Zero Standard is used for setting targets on financial activities (scope 3, category 15 emissions), while the Corporate Net-Zero Standard covers scopes 1, 2, and 3 categories 1-14 emissions. Please see the finance sector guidance for further details.    |
| Forest, land and agriculture (FLAG) | Companies with significant FLAG emissions are required to set FLAG targets (see criteria in the column to the right). FLAG targets are complementary and separate from science-based targets that cover energy/industry (non-FLAG) emissions. Options: ● Sector-specific absolute reduction method for near-term targets. See FLAG Tool. ● Sector-specific absolute reduction method for long-term targets covering agriculture only. See                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | The following companies are required to set FLAG targets: 1. Companies with FLAG emissions that total 20% or more of overall emissions across scopes; and 2. Companies in the following sectors: ● Forest and Paper Products - Forestry, Timber, Pulp and Paper, Rubber ● Food Production - Agricultural Production ● Food Production - Animal Source ● Food and Beverage Processing ● Food and Staples Retailing |

| Sector/activity                                          | Eligible pathways, methods, tools                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Guidance and further notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|----------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                          | Corporate Net-Zero Tool. ● Commodity pathways for near-term intensity targets. See FLAG Tool. Commodity pathways are available for 10 agricultural commodities: beef, chicken, dairy, leather, maize, palm oil, pork, rice, soy, wheat. Companies with emissions associated with one or more of the available agricultural commodity pathways that account for 10% or more of a company's total (gross) FLAG emissions for each of those commodities may use the commodity pathway for that commodity (but are not required to do so). Companies in the forest products sector or with emissions related to timber & wood fiber accounting for 10% or more of their FLAG emissions are required to use the commodity pathway for timber and wood fiber. | ● Tobacco Please note that FLAG near-term targets must cover at least 95% of FLAG-related scope 1 and 2 emissions and at least 67% of FLAG-related scope 3 emissions. Please see the FLAG Guidance for further details. Please note that there is currently no long-term pathway available for timber and wood fiber. Targets from companies operating in the forest and paper products sector shall include a footnote stating that timber and wood fiber emissions are not included in the long-term target. These companies must (re)submit their long-term FLAG target covering these emissions within six months of the release of the long-term pathway for timber and wood fiber. |
| Fossil fuel sale/ transmission/ distribution             | Companies that sell, transmit, and/or distribute fossil fuels (and that derive less than 50% of revenue from these activities) are required to set targets for scope 3 category 11 'use of sold products' emissions, irrespective of the share of these emissions compared to the total scope 1, 2 and 3 emissions of the company. Separate and additional scope 3 targets may need to be set.                                                                                                                                                                                                                                                                                                                                                          | This requirement is applicable to companies that derive less than 50% of revenue from the sale, transmission and distribution of fossil fuels. For companies receiving 50% or more of their revenue from these activities, please refer to the Oil and Gas section.                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Information and communication technology (ICT) providers | ● Cross-sector absolute reduction method for near-, and long-term targets. See Corporate Near-Term Tool and Corporate Net-Zero Tool.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | Optional guidance is available for ICT companies including mobile networks operators, fixed networks operators, and data centers operators.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Iron and steel                                           | Options: ● Sector-specific intensity convergence method (i.e., SDA) for near-, and long-term targets. See Steel SDA Tool and Corporate Net-Zero Tool respectively. ● Sector-specific absolute reduction method for long-term targets. See Corporate Net-Zero Tool. ● Cross-sector absolute reduction method for near-, and long-term targets. See Corporate Near-Term Tool and Corporate Net-Zero Tool. Please note that regardless of the pathway chosen, the iron & steel core                                                                                                                                                                                                                                                                        | The SBTi has released guidance to aid companies in the steel industry in setting science-based targets. Near-term iron and steelmakers science-based targets shall include a scope 3 target that covers all scope 3 category 3 'Fuel- and energy-related emissions not included in scope 1 or scope 2' emissions according to the GHG Protocol.                                                                                                                                                                                                                                                                                                                                          |

| Sector/activity    | Eligible pathways, methods, tools                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Guidance and further notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
|--------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                    | boundary must be applied to all near-term targets.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Maritime transport | Options: ● Maritime pathway with intensity convergence method (i.e., SDA) for near-, and long-term targets on well-to-wake (WTW) is available for all companies providing applicable maritime transport services. See Maritime Tool. When using the maritime pathway, near-term targets can be no earlier than 2030 and long-term targets must be no later than 2040. ● Cross-sector pathway with absolute reduction method for near-, and long-term targets on WTW. See Corporate Near-Term Tool and Corporate Net-Zero Tool. When using the cross-sector pathway, near-term targets must follow the 5-10 year timeframe, and long-term targets must be no later than 2050.                                            | Companies using the maritime pathway to set near-term targets science-based targets covering emissions from own operations (e.g., vessel owners or operators) are required to also submit long-term science-based targets modeled with the maritime pathway along with their near-term target submission. Please note that in this case, the long-term target year for maritime targets is 2040. Companies using the maritime guidance to set near-term science-based targets covering scope 3 emissions from subcontracted maritime transport operations (e.g., cargo owners or shippers) are not required to submit long-term science-based targets. For all transport-related emissions across all sectors, companies shall set targets over these emissions on a well-to-wheel (WTW) basis in their GHG inventory (well-to-wake for aviation and maritime transport). Please see the transport sector page for the Maritime Transport Guidance and |
| Oil & gas          | The SBTi is developing a new standard for companies in the oil and gas sector to set science-based targets. Currently, the SBTi is unable to accept commitments or validate targets for companies in the oil and gas or fossil fuels sectors. Companies that have dormant or active fossil fuel assets (e.g., coal mine, lignite mine, etc.) for extraction activities with commercial purposes (meaning sales), cannot validate targets at this stage, until further specific methods and guidance are developed. Please see our policy for further information. The SBTi will assess companies on a case-by-case basis to determine sector classification and reserves the right to not move forward with a company's | Companies in this sector include - but are not limited to - integrated oil and gas companies, integrated gas companies, exploration and production pure players, refining and marketing pure players, oil products distributors, and traditional oil and gas service companies. Please see the oil and gas sector page on our website for more information. Fossil fuel service companies need to account for the indirect emissions related to the fossil fuels directly or indirectly managed by the company. The SBTi defines fossil fuel service companies as businesses that support exploration, extraction, mining or production of fossil fuels, and other significant activities along the fossil fuels value chain, not covered by sale, transportation or distribution category. The SBTi recommends companies to decommission fossil fuel assets, instead                                                                                  |

| Sector/activity                       | Eligible pathways, methods, tools                                                                                                                                                                                                                                                                                                                                              | Guidance and further notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|---------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                       | validation, until methods/guidance have been developed/completed.                                                                                                                                                                                                                                                                                                              | of divesting, as this approach better reflects the need to phase-out fossil fuels in our global economy, as science indicates is necessary. If a company completely decommissions/divests from fossil fuel assets, they will no longer be considered under these rules, and can submit targets as per standard route. The SBTi recommends companies to follow the GHG Protocol for base year recalculations.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| Electric utilities & power generation | Companies in the power sector are required to set targets using the power sector pathway for near-, and long-term targets (intensity convergence method only (i.e., SDA) within the Corporate Near-Term Tool and Corporate Net-Zero Tool). Please note that the long-term power target(s) shall be no later than 2040.                                                         | Companies in the power sector with scope 3 emissions representing 40% or more of overall emissions must set at least two targets: ● An intensity target covering all sold electricity (including purchased and resold electricity in scope 3 category 3 'fuel- and energy-related emissions not included in scope 1 or scope 2' emissions) ● An intensity target covering all electricity generation in scope 1 expressed in terms of MWh (megawatt hour) energy generated. For power generation companies that distribute and sell fossil fuels, a third target shall be set covering 100% of emissions from downstream use of fossil fuels. This should be an absolute target that aligns with a 1.5°C mitigation pathway. In order to meet the 67% scope 3 coverage threshold, power companies may need to set a target over other scope 3 categories as well. Please see the Electric Utilities/Power Guidance for further details. |
| Land transport: Road and rail         | Options: ● Cross-sector pathway with absolute reduction method for near-, and long-term targets. See Corporate Near-Term Tool and Corporate Net-Zero Tool. ● Companies that subcontract transport services can use the cross-sector pathway or use the legacy Transport Tool with the WB2C (well-below 2°C) pathway. No 1.5ºC sector intensity pathway is currently available. | For all transport-related emissions across all sectors, companies shall set targets over these emissions on a well-to-wheel (WTW) basis in their GHG inventory (well-to-wake for aviation and maritime transport).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Land transport:                       | ● Cross-sector pathway with absolute                                                                                                                                                                                                                                                                                                                                           | The SBTi will review and update the                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |

| Sector/activity           | Eligible pathways, methods, tools                                                                                                                                                                                                               | Guidance and further notes                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
|---------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Transport OEMs/Automakers | reduction method for near-, and long-term targets over use of sold products emissions. See Corporate Near-Term Tool and Corporate Net-Zero Tool. This is applicable once the interim 1.5ºC target-setting approach for automakers is published. | passenger, freight and OEM (original equipment manufacturer) sector target-setting guidance through a formal sector development process. The SBTi Interim 1.5°C Approach for Automakers will be reviewed and superseded upon the completion of this sector guidance update process. Until the Interim 1.5°C target-setting pathway for automakers is published, near- and long-term target validations and target updates for automakers are paused - as outlined in this policy. |

## ANNEX A: SUPPLEMENTARY GUIDANCE ON GHG ACCOUNTING

This annex details nuances in GHG accounting that SBTi requires and recommends as best practice for certain sectors and/or activities.

Downstream emissions from intermediate products for which end use is unknown may be excluded if reasonable justification is provided : In certain cases, the eventual end use of sold intermediate products may be unknown. For example, a company may produce an intermediate product (e.g., a chemical) with innumerable potential downstream applications, each of which has a different GHG emissions profile, and be unable to reasonably estimate the downstream emissions associated with the various end uses of the intermediate product. In such cases, companies must provide a robust justification for exclusion of downstream emissions from categories 10, 11, and 12 (but should not selectively exclude a subset of those categories) through the target validation process.

Include downstream emissions from intermediate products with specific applications: Downstream emissions from intermediate products that have specific applications, such as computer microchips, automotive parts, etc., must be accounted for within the GHG inventory.

Emission allocation from ports: Companies must define the geographical boundary of the relevant ports in which they operate and disclose their chosen boundary. Ships sitting in port must account for the emissions related to port usage. If a shipping company is a customer of a port i.e., they pay the port for use of facilities, these emissions are deemed to be direct use-phase emissions (scope 3 category 11 'use of sold products').

Retiring versus selling assets within a company: If a company sells a company asset, this is classified as a structural change according to the GHG Protocol Corporate Standard and shall trigger a recalculation of a company's base year emissions. Alternatively, if a company retires a company asset (removes an asset or part of an asset from the asset

portfolio without revenue generation), a company can consider this to be an emissions reduction within their organizational boundary.

Insetting: There are multiple definitions for the term 'insetting' (also referred to as supply chain interventions) and no standardization of the term, which makes it difficult to give a clear determination of what may and may not be included within scope 3 inventory reductions. Insetting is used to describe climate mitigation projects or programs wholly contained within the scope 3 value chain boundary of a company or projects partially within its scope 3 supply chain boundary (spanning their supply chain and other companies' supply chains).  Accounting approaches for insetting also vary with the use of both intervention (project) accounting and corporate inventory accounting.

As this issue has not been settled to date in the GHG Protocol process, the SBTi recommends a conservative approach at this time. Companies should only include emission reductions or removals (removals only in the case of FLAG targets) from 'insetting' projects that use a corporate accounting approach and are wholly contained within their supply chains or the portion of a 'partially-included' project that is within their supply chain and linked directly to sourcing. For further information, please see this resource.

Further work is ongoing to standardize the definition of insetting/supply chain interventions and clear accounting methodologies. For these reasons, the SBTi will assess insetting on a case-by-case basis during the validation process and may not approve their use.

Green gas/biogas: The SBTi currently recommends that companies follow the guidance within the GHG Protocol Corporate Standard on the use of green gas. Currently, the GHG Protocol does not allow the use of green gas certificates to reduce scope 1 emissions. However, this topic is being discussed as part of the current GHG Protocol Land Sector and Removals Guidance development process. The GHG Protocol has released an Interim update on accounting for Biomethane Certificates that provides an overview of the treatment of biomethane under the GHG Protocol. The SBTi cannot guarantee that these certificates would be a valid approach to meeting science-based targets.

Accounting for emissions from non-rechargeable batteries: Emissions from the production and waste of non-rechargeable batteries must be accounted i.e., production emissions accounted for in scope 3 category 1 'purchased goods and services', waste in operations accounted for in scope 3 category 5 'waste' and emissions from the end use of batteries accounted for in scope 3 category 12 'end-of-life treatment of sold products'.

Renewable energy certificates (RECs): Companies may use RECs as a measure to reduce scope 2 market-based emissions. However, the RECs need to be purchased and used within the same market, and cannot be used as a reduction mechanism for markets that the certificates were not purchased from. For more information please consult the RE100 Technical Criteria and the Scope 2 Quality Criteria in the GHG Protocol's Scope 2 Guidance.

Market-based scope 3 accounting: The SBTi continues to follow Greenhouse Gas Protocol guidance, which does not consider market-based scope 3 accounting. Therefore, the SBTi does not permit market-based accounting in scope 3, including the purchase of

market-based renewable electricity instruments on behalf of the reporting company's suppliers, customers, lessors, lessees, franchisees, or investments.

Accounting for emissions from transport-related fuels, general fuel use and purchased electricity: For any transport-related emissions from fuel use, emissions must be reported on a well-to-wheel (WTW) basis (well-to-wake for aviation and maritime transport) that reflects direct use emissions from fuel combustion (tank-to-wheel, TTW) and upstream emissions related to fuel production and distribution (well-to-tank, WTT). For purchased fuels, fuel related emissions must be accounted for on a WTW basis i.e., TTW emissions which are equivalent to scope 1 emissions and WTT emissions reported in scope 3 category 3 'fuel-and-energy-related activities'. Furthermore, the upstream emissions of purchased electricity (WTT emissions) must be accounted for in scope 3 category 3 'fueland energy-related activities' if not accounted for in scope 1 and/or 2. For more information, consult Table 5.4 (page 34) of the Corporate Value Chain (Scope 3) Accounting and Reporting Standard.

Mandatory versus optional scope 3 targets: Companies may request to include targets to reduce optional scope 3 emissions in the target language. Companies that wish to include a supplemental/optional target on optional scope 3 emissions should refer to the Procedure for Validation of SBTi Targets for details.

Direct use-phase emissions: The direct use-phase emissions of final products shall be calculated based on the lifetime consumption of the product(s). The allocation methodology shall be disclosed through the target validation process for the direct use-phase of components, except for engines, for which 100% of the vehicle's direct use-phase emissions shall be reported.

Indirect use-phase emissions: Indirect use-phase emissions are generated by products that only consume energy indirectly during use over their expected lifetime. These emissions are classified as optional and are therefore not within the 'minimum boundary' for scope 3 category 11 'use of sold products'. Examples include the washing and drying of apparel for apparel manufacturers and the cooking and refrigeration of food products for food retailers. Indirect use-phase emissions are 'optional', but their calculation methodology shall be disclosed through the validation process.

The table below provides a non-exhaustive list of examples of direct and indirect use-phase emission sources accounted for under scope 3 category 11 'use of sold products'.

Table 5. Direct and indirect use-phase emissions accounted for under scope 3 category 11.

| Sector                     | Direct use-phase emissions                                 | Indirect use-phase emissions   | Notes   |
|----------------------------|------------------------------------------------------------|--------------------------------|---------|
| Automobiles and components | ● Engines ● Headlights ● Air conditioning system ● Heaters | ● Tyres ● Bumpers ● Seatbelts  |         |

| Sector                                         | Direct use-phase emissions                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Indirect use-phase emissions                                                                                                                                                                                                  | Notes                                                                                                                                                                             |
|------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Apparel                                        |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | ● Washing and drying of clothes                                                                                                                                                                                               |                                                                                                                                                                                   |
| Architecture, engineering and design companies | ● Architecture, engineering and design companies must allocate the emissions from the use of building projects that have been constructed as direct use-phase emissions.                                                                                                                                                                                                                                                                                                                          |                                                                                                                                                                                                                               |                                                                                                                                                                                   |
| Energy and Electric Utilities                  | ● Fuels and feedstocks ● Rechargeable batteries (energy loss) ● Chargers ● Electricity transmission and distribution equipment (transmission loss and no-load consumption) ● Rechargeable batteries (energy stored and transmitted) ● First charge of the rechargeable battery before sale must be allocated to scope 2 of the producers ● Sold piping systems (lost heat and cooling) ● Power step-up and- down transformers ● Other power system equipment (lost electricity, heat and cooling) | ● Rechargeable batteries (energy stored and transmitted)                                                                                                                                                                      |                                                                                                                                                                                   |
| Electronics                                    | ● Displays ● Microchips ● Memory drives ● Cameras                                                                                                                                                                                                                                                                                                                                                                                                                                                 | ● Computer housing ● Camera lenses                                                                                                                                                                                            |                                                                                                                                                                                   |
| Food and beverage                              | ● CO ₂ release from beverages                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | ● Cooling of ice for beverages. ●Frying/microwaving/coo king of frozen meals or any other food item ● Use of household food waste disposer (for food producers) ● Direct cooling or heating of products in homes of consumers | ● The cooling or heating of products in retail, hotels, restaurants, pharmacies or hospitals must be allocated to scope 3 category 9 'downstream transportation and distribution' |
| Household appliances                           | ● Large and small household appliances, from washing machines to electric toothbrushes ● Lightbulbs ● Smart-home products ● Charcoal and lighter fluid for barbecues                                                                                                                                                                                                                                                                                                                              | ● Smart-home software use i.e., the use of computers, smartphone, and/or router energy consumption due to the use of the software                                                                                             |                                                                                                                                                                                   |
| Software and telecommunicati on services       |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | ● Software i.e., the energy consumption of computers or other electronic devices due to the use of software)                                                                                                                  | ● The energy consumption of the servers that run cloud-based software must be                                                                                                     |

| Sector                  | Direct use-phase emissions                                                                                                                                                               | Indirect use-phase emissions                                                                            | Notes                                                                                    |
|-------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|
|                         |                                                                                                                                                                                          | ● Telecommunication contracts i.e., the energy consumption of cell phones due to the use of the network | allocated to scope 3 category 1 'purchased goods and services' of the software provider. |
| Transport and logistics | ● If a shipping company is a customer of a port i.e., they pay the port for use of facilities, these emissions are deemed to be direct use-phase emissions of a port.                    | ● Maintenance of transport infrastructure e.g., roads, bridges, airports etc.                           |                                                                                          |
| On-premises services    | ● Emissions from the use of client facilities for the provision of services (e.g., catering firm cooking in client kitchens; cleaning firm with equipment that uses client electricity). |                                                                                                         |                                                                                          |

## ANNEX B: SUPPLEMENTARY GUIDANCE ON TARGET-SETTING METHODS

This annex provides further details on the SBTi's target-setting methods.

## B.1 Cross-sector absolute reduction (all scopes)

With this method (also known as 'absolute contraction'), companies reduce absolute emissions by an amount that is at least consistent with the cross-sector pathway. This method is applicable to near-term and long-term targets, across all scopes.

For near-term SBTs, the minimum ambition is calculated as a linear reduction rate of 4.2% per year for scope 1 and scope 2, and 2.5% per year for scope 3. The reduction rate is adjusted dynamically according to the time remaining between the company's base year and the pathway's net-zero year (or the company's own net-zero target year, if earlier). The reduction rate increases as the timeframe to the net-zero year decreases, i.e., with later base years and earlier net-zero target years. This ensures that the rate reflects the time available to achieve the same overall reduction magnitude required by the cross-sector pathway.

To limit cumulative emissions, a calculation adjustment is applied to near-term scope 2 targets and combined scope 1+2 targets, assuming scope 2 emissions are reduced to zero by 2040. This follows the assumption observed in net-zero-emission pathways that the global power system decarbonizes by 2040, thereby acting as a key enabler of the transition to net-zero. Assumptions regarding scope 1 emissions are unchanged, i.e., 90% reduction by 2050 or earlier. This calculation adjustment does not affect requirements related to net-zero target design, e.g., net-zero year and minimum ambition. The target ambition for combined scope 1+2 targets is calculated using a weighted-average rate of reduction based on the company's scope 1+2 GHG inventory for the most recent year. Further details on this method adjustment, including updated method equations, are available in the CNZS v1.3.1 Method Appendix.

For long-term SBTs, the minimum ambition is a 90% reduction, applicable for all scopes.

## Advantages

- ● More transparent.
- ● Less dependent on variables. e.g., projections of production.
- ● Widely accepted as best practice.

## Disadvantages

- ● Does not allow comparisons of GHG intensity amongst peers.
- ● Does not necessarily track efficiency improvements, as reported reductions can result from declines in production output, rather than improvements in performance.
- ● May be more challenging to achieve if the company grows and growth is linked to GHG emissions.

## B.2 Sector-specific absolute reduction (all scopes)

Using the sector-specific absolute reduction method, absolute emissions are reduced by an amount that is, at a minimum, consistent with a sector-specific pathway. This method is applicable to near-term and long-term targets across all scopes, unless otherwise stated within sector-specific guidance.

This method is available for agriculture, power, cement, steel, and residential and service buildings. For agriculture, the minimum reduction is 72% for long-term targets. For the power, cement, steel and buildings sectors the minimum reduction is at least 90% for long-term targets.

## Advantages

- ● Provides sector-specificity.
- ● More transparent.
- ● Less dependent on variables, e.g., projections of production.
- ● Widely accepted as best practice.

## Disadvantages

- ● Does not allow comparisons of GHG intensity amongst peers.
- ● Does not necessarily track with efficiency improvements, as reported reductions can result from declines in production output, rather than improvements in performance.
- ● May be more challenging to achieve if the company grows and growth is linked to GHG emissions.

## B.3 Sector-specific intensity convergence (i.e., SDA, all scopes)

Using this method, all companies in a heavy-emitting sector converge to a sector-specific emissions intensity in 2050 (2040 for power and maritime transport), for example, tonnes GHG per tonne product or MWh generated. Also referred to as 'physical intensity convergence' or 'Sectoral Decarbonization Approach (SDA)'. This method applies to near-term and long-term targets across all scopes unless otherwise stated in sector-specific guidance.

For near-term targets, the minimum ambition is calculated using the SDA formula, which adjusts a company's target based on its starting point, target year, and projected output growth. For long-term targets, the target year emissions intensity is equal to the sector's emissions intensity in 2050 (2040 for power and maritime transport).

## Advantages

- ● Best suited for use within sectors that create a homogenous product (e.g., steel or cement sectors).
- ● Reflect GHG performance and efficiency improvements independent of business growth or decline.

- ● May increase the comparability of GHG performance among companies (assuming that inventory consolidation approaches used are the same and product mixes are highly similar).

## Disadvantages

- ● Does not necessarily lead to reductions in absolute emissions. This is because increases in business output can cause absolute emissions to rise even if efficiency improves on a per unit basis (please see Figure 8 below for an illustration of this point).
- ● May be less credible to stakeholders because absolute emissions may rise even if intensity decreases (e.g., because output increases more than GHG intensity decreases).

Figure 8. Intensity reduction targets can lead to absolute emissions increases when production levels increase.

<!-- image -->

## B.4 Renewable electricity (scope 2)

The renewable electricity (RE) method is an acceptable alternative to scope 2 emission reduction targets. Using this method, companies set targets to procure at least 80% renewable electricity by 2025 and 100% by 2030. Companies can use this method to set near-term targets and then set a maintenance target to ensure the level of renewable electricity achieved is maintained over time. Please see Table 6 below for the minimum acceptable thresholds for renewable electricity procurement between 2025 and 2030 consistent with limiting warming to 1.5°C.

Table 6. Minimum acceptable thresholds for renewable electricity procurement between 2025 and 2030. Targets at this ambition level are consistent with limiting warming to 1.5°C.

## Advantages

- ● Easy to track progress.
- ● Once achieved, RE targets can be adapted to maintenance targets to ensure RE procurement remains high.

## Disadvantages

- ● Depends on the regions in which a company operates and may not be accessible to companies that do not have the capacity to demonstrate active sourcing of renewable electricity through market instruments.
- ● Certain market instruments that companies use to procure RE may be lower quality. Renewable energy certificates (RECs) in particular, have been criticized for being non-additional due to low and uncertain prices. 47, 48 Power purchase agreements (PPAs) on the other hand, do not face the same criticism as they represent a long-term commitment by a company to purchase power from a particular renewable energy project. 12

## B.5 Physical intensity reduction (scope 3)

Using this method, companies define their own physical intensity metric and set targets to reduce physical emissions intensity by an amount that is, at minimum, consistent with limiting global warming to well-below 2˚C for near-term targets and 1.5°C for long-term targets. This method is only applicable to scope 3.

For near-term targets, the minimum intensity reduction is calculated as a 7% year-on-year reduction, plus an adjustment for targets with a base year later than 2020. For long-term targets, the minimum reduction is calculated as an overall 97% reduction.

Eligible denominators for using the scope 3 physical intensity method must be a representative measure of a company activity intrinsically related to the emissions boundary of the target. Eligible activity types for applying this method include:

- ● Company size (e.g., employee headcount, FTE, office/retail area, etc.)
- ● Production input (e.g., amount procured of raw materials)
- ● Production output (e.g., volume of production, sales, built area)

47 Hamburger, Á., &amp; Harangozó, G. (2018). Factors affecting the evolution of renewable electricity generating capacities: A panel data analysis of European countries. International Journal of Energy Economics and Policy, 8(5), 161.

48 Bjørn, A., Lloyd, S. M., Brander, M., &amp; Matthews, H. D. (2022). Renewable energy certificates threaten the integrity of corporate science-based targets. Nature Climate Change, 12(6), 539-546. .https://doi.org/10.1038/s41558-022-01379-5.

- ● Level of service (e.g., payload or passenger distance, number of users/subscriptions, service output per unit)

Non-physical denominators such as profit, value added, revenue, sales, etc., cannot be used for calculating targets using the scope 3 physical intensity method.

## Advantages

- ● Physical intensity metrics reflect GHG performance and efficiency improvements independent of business growth or decline.
- ● May increase the comparability of GHG performance among companies (assuming that inventory consolidation approaches used are the same and product mixes are highly similar).

## Disadvantages

- ● May be less suitable for companies that generate a diverse product mix due to the difficulty in defining a single physical intensity business metric.
- ● High data requirements given that physical activity data may not be readily available.
- ● May be less credible to stakeholders because absolute emissions may rise even if intensity decreases (e.g., because output increases more than GHG intensity decreases).

## B.6 Economic intensity reduction (scope 3)

Using this method, companies reduce economic emissions intensity (e.g., tCO2 per unit of value added) by an amount that is, at minimum, consistent with limiting warming to well-below 2°C for near-term targets and 1.5˚C for long-term targets. This method is only applicable to scope 3.

For near-term targets, the minimum intensity reduction is calculated as a 7% year-on-year reduction, plus an adjustment for targets with a base year later than 2020. For long-term targets, the minimum reduction is calculated as an overall 97% reduction.

## Advantages

- ● May be used to normalize emissions for sectors with varying products that are difficult to directly compare against one another (e.g., retail or chemical sectors).
- ● May provide more flexibility for companies that are prioritizing growth.

## Disadvantages

- ● May only be appropriate for sectors with limited fluctuations in product prices over time, where growth in emissions is often tied to economic growth of the company. In other words, if a company sells more products, more emissions are produced to make those products.
- ● May be difficult to track emissions reduction progress using economic intensity indicators, especially if a company experiences financial losses in certain years.

- ● Subject to a number of variables that can lead to apparent changes in a company's carbon intensity that are not linked to its environmental performance, but rather with extrinsic factors. Examples include the fluctuation of commodity prices, inflation, or changes in the relative contribution of different business activities to a company's bottom line. 49
- ● May not be useful for tracking emissions performance.
- ● Growth projections must be accurate for economic intensity targets to lead to sufficient absolute emissions reductions.

## B.7 Supplier and/or customer engagement targets (scope 3)

Using this method, companies set a target for suppliers or customers representing a certain percentage of emissions to set their own science-based targets in line with the latest version of the SBTi Corporate Near-Term Criteria. This method only applies to scope 3, near-term targets.

Engagement targets may be set around any credible, relevant upstream or downstream scope 3 category where engagement efforts could lead to a reduction in emissions. Using this method, companies can set engagement targets based on spend and/or emissions data. 50 Engagement targets may alternatively focus on 'critical suppliers' or 'strategic suppliers' that the company has already identified based on a variety of factors, such as operational risk. Spend data and critical supplier lists are advantageous when they can reliably serve as a proxy for leverage over suppliers.

When using a spend-based method, it is important to note that the biggest suppliers by spend are not always the biggest GHG emitters and as a result, the amount of emissions reduction associated with a spend-based engagement target is less clear than emissions-based targets. Therefore, it is important for companies to ensure that the engagement target and any additional scope 3 targets cover at least 67% of total scope 3 emissions.

## Advantages

- ● May be valuable if a company has yet to identify levers for more specific reduction opportunities amongst its value chain partners and/or if it does not spend enough on individual suppliers to support collaborative reduction efforts.
- ● May enable early actions from companies with limited data or information on what reduction levers are most suitable.
- ● May drive reduction behaviors that benefit other customers of the same supplier.
- ● May encourage collaborative ownership and responsibility for emission reductions.
- ● Easy to track.

49 Volatile pricing may happen for a variety of reasons. For example, a pharmaceutical company's prices for certain drugs may fluctuate based on demand, patents or regulatory factors; the value added (or gross profit) of a luxury brand company can be related to marketing and consumer willingness to pay for a premium product, introducing variability into pricing; the price of many commodities (e.g., metals and agricultural commodities) is set by trades placed on commodity exchanges.

50 If measuring coverage by spend, the company must provide an estimate of the emissions coverage associated with that spend for validation purposes to demonstrate that the criterion for scope 3 target boundary coverage has been met, by the supplier or customer target alone or together with other scope 3 target(s).

## Disadvantages

- ● The emissions reduction associated with a spend-based engagement target is less clear than emissions-based targets.
- ● Companies may focus on suppliers' or customers' scope 1 and 2 emissions as a starting point, so the scope of such targets may be limited.

## ANNEX C: CLASSIFICATION OF TARGET TEMPERATURE ALIGNMENT

Temperature alignment indicates the degree of global temperature increase relative to preindustrial levels that companies' targets align with, relative to the goals of the Paris Agreement. Companies must set near-term targets with a minimum ambition of 1.5°C for scopes 1 and 2 and a minimum ambition of well-below 2°C for scope 3. 51  Long-term targets must have a minimum ambition of 1.5°C across scopes.

The SBTi publicly discloses temperature alignment based on the ambition of a company's scope 1 and 2 targets. 52 Temperature alignment is identified in the target dashboard on the SBTi website with one of the following values: 1.5°C, well-below 2°C, and 2°C. Methods used to set scope 3 targets are also evaluated during the target validation process to ensure they meet the minimum ambition corresponding to the temperature alignment or supplier / customer engagement requirements; however, an assessment of temperature alignment for most scope 3 targets is not disclosed.

## C.1 Target classification rules

Target classification describes the alignment of a company's scope 1 and 2 emissions reduction targets as a whole, relative to a long-term temperature goal. All long-term target-setting methods are in alignment with scope 3, therefore, the target classification rules described below apply to near-term science-based targets.

It is important to note that this classification, however, does not imply that a company's overall ambition and business strategy are aligned with a temperature goal, as the current classification does not extend to scope 3 for most companies, i.e., does not cover the full GHG inventory, and the SBTi validation body does not conduct comprehensive assessments of companies' business models or strategies.

Near-term science-based targets are classified by target type and scope coverage. Target classifications only consider the ambition over the target timeframe (i.e., ambition from the base year to the target year) to best reflect a company's target trajectory. This means forward-looking ambition (i.e., ambition from the most recent year of data to 2050) is not used to determine target classifications.

Classification rules for a range of target formulations and scope combinations are as follows:

- ● Absolute scope 1 and 2 combined targets modeled using the cross-sector absolute reduction approach: These targets are classified using the cross-sector absolute reduction thresholds.

51 These scenarios imply a &gt;50% chance of limiting warming in 2100 to 1.5˚ C; and a &gt;67% chance of limiting peak warming between now and 2100 to below 2˚ C, respectively. The SBTi strongly encourages companies to go beyond the minimum ambition requirements.

52 Temperature alignment is only provided for most companies' scope 1 and 2 targets. The exception is auto manufacturers, which also have scope 3 category 11 temperature alignment.

- ● Scope 1 and 2 combined intensity targets modeled using the sector-specific intensity convergence approach (i.e., SDA): Scope 1 and 2 intensity targets modeled using the sector-specific intensity convergence approach (i.e., SDA) are compared and classified against the 1.5°C Scenario in the Corporate Near-Term Tool and/or the sector-specific tools.
- ● Renewable electricity targets: Renewable electricity targets that meet SBTi requirements are 1.5°C aligned. Heating, steam and cooling-related emissions are not covered by renewable electricity targets, therefore if renewable electricity targets are additional to absolute/intensity scope 1 and 2 targets, the classification is based on the other scope 1 and 2 targets and not the renewable electricity target.
- ● Combined scope targets (scopes 1+2+3): Companies must provide the breakdown in ambition for combined scope targets (scopes 1, 2, and 3), i.e., the ambition of the scope 1 and 2 portion and the ambition of the scope 3 portion of the target. The classification of the company is then based only on the scope 1+2 ambition.

Table 7. Ambition ranges for target classifications of near-term science-based targets

| Method                                                                                            | Minimum annual linear reduction rate over target period   |
|---------------------------------------------------------------------------------------------------|-----------------------------------------------------------|
| Cross-sector absolute reduction method with 1.5˚C long-term temperature goal for scopes 1 and 2   |                                                           |
| Cross-sector absolute reduction method with well-below 2˚C long-term temperature goal for scope 3 |                                                           |
| Economic intensity reduction method with well-below 2˚C long-term temperature goal for scope 3    |                                                           |
| Physical intensity reduction method with well-below 2˚C long-term temperature goal for scope 3    |                                                           |

## ANNEX D: REPORTING GUIDANCE

According to SBTi criteria, companies must publicly disclose GHG emissions and progress against targets annually. This annex sets out recommendations on how businesses, including SMEs, should publicly report their GHG emissions inventory and annual progress against their published science-based targets. 53

## D.1 Where to disclose

Disclosure is critical in positioning companies to respond to climate-related frameworks issued by both government and non-governmental entities. For instance, companies could be subject to sustainability disclosure regulations, such as the Exchange Act reporting requirements from the US Securities and Exchange Commission (SEC), or the Corporate Sustainability Reporting Directive (CSRD) from the European Financial Reporting Advisory Group (EFRAG). Companies may also want to align their sustainability disclosures to meet the Task Force on Climate-related Financial Disclosures (TCFD) recommendations or adopt the climate reporting standard set by the International Sustainability Standards Board (ISSB). All of these frameworks or standards require that organizations disclose their GHG emissions, targets used to manage climate-related issues, and the performance against these targets. Therefore, in addition to fulfilling SBTi's annual reporting requirements, it is in a company's best interest to focus on transparent disclosure of GHG emissions and target progress. The list below outlines some of the avenues through which companies may publicly disclose this information.

- ● CDP's climate change questionnaire: CDP provides a platform to disclose climate-related indicators to investors, purchasers and governments through its climate change questionnaire. This is a well-known public resource for reaching large external audiences that continuously evolves to align with the most relevant climate-related disclosure standards. CDP recognizes science-based targets as best practice and incentivizes their adoption and progress through its scoring methodologies. CDP aligns the climate change questionnaire on a yearly basis to reflect the latest criteria and recommendations adopted by the SBTi and issues a dedicated technical note on science-based targets accompanying its climate change questionnaire. CDP also communicates SBTs to the Global Climate Action portal, which tracks significant commitments made by 'non-state actors', including companies, as part of the UNFCCC's Action Agenda.
- ● Corporate public reports: Companies may use public reports such as sustainability reports, corporate social responsibility reports, annual reports and strategic plans to periodically disclose GHG-related information and to integrate emissions performance data into their non-financial disclosures. Target information can also be presented in the company's webpage, linking it to related sustainability resources.

53 Companies that have approved targets through the streamlined validation route for SMEs should follow this reporting guidance, where applicable. SMEs using the streamlined validation route for SMEs are committed to measure and reduce scope 3 emissions as part of their targets, and therefore should disclose their scope 3 emissions in the company's annual GHG inventory. The SBTi recommends that SMEs report using best practice while acknowledging the unique constraints and barriers that they may face in reaching the detailed level of disclosure required of larger companies.

Integrating this information in public reports and websites facilitates access to any stakeholder and can be used to provide further detail and context.

- ● The Global Reporting Initiative (GRI): Companies may publicly report on targets set and their performance in their GRI-aligned reports by registering them in the GRI Standards Report Registration System. GRI is an initiative that provides a widely used framework for reporting environmental, social, and governance indicators.

Disclosure in any of these resources should follow the reporting principles and recommendations presented in this annex to ensure adequate performance tracking of science-based targets.

## D.2 Reporting guiding principles

Annual target reporting is important as it enables companies to communicate year-on-year progress against targets to stakeholders. By disclosing all pertinent aspects of the target outlined in this section, companies can enable their audiences to fully understand the context, implications, and nuances of their target(s).

The GHG Protocol Corporate Standard defines five overarching principles to guide the development of corporate GHG inventories. These principles should also be applied to target disclosure and progress reporting.

- 1. Relevance: Ensure the target appropriately reflects the GHG emissions of the company and serves the decision-making needs of the users - both internal and external to the company.
- 2. Completeness: Account for and report on all GHG emission sources and activities within the chosen target boundary. Disclose and justify any specific exclusions.
- 3. Consistency: Use consistent methodologies to allow for meaningful comparisons of emissions over time. Transparently document any changes to the data, inventory boundary, methods or any other relevant factors in the time series.
- 4. Transparency: Address all relevant issues in a factual and coherent manner, based on a clear audit trail. Disclose any relevant assumptions and make appropriate references to the accounting, calculation methodologies and data sources used.
- 5. Accuracy: Ensure the quantification of GHG emissions is systematically not overreported nor underreported, and that uncertainties are reduced as far as practicable. Achieve sufficient accuracy to enable users to make decisions with reasonable assurance as to the integrity of the reported information.

In line with best practice, companies should cover the following aspects in their disclosure of progress against science-based targets:

- 1. GHG emissions inventory
- 2. Target description
- 3. Target progress
- 4. Substantial emission variations and changes in targets
- 5. Actions towards meeting SBTs

The sections below provide further recommendations for each of these disclosure items.

## D.3 GHG emissions inventory

## D.3.1 Full GHG inventory

As stated previously, companies must report a full GHG emissions inventory on an annual basis. Further detail is described below:

- ● Companies must report all emissions scopes (1, 2 and 3) and all scope 3 categories, including those that do not fall within a target boundary.
- ● Companies must disclose what the reporting period is and should clarify what the choice of year type is (i.e., calendar year or financial year).
- ● Any exclusions from the inventory (scope 1, 2 or 3) must be described, estimated and disclosed.
- ● For scope 3 categories that are considered negligible, companies should report an estimate (either in tonnes of CO  equivalent or percentage of total scope 3 2 emissions).
- ● Companies should report the type of data used, data sources, methodologies and assumptions used to determine the GHG emissions data. For example, for scope 3 emissions, companies should disclose which portions of the reported emissions data come from primary data (i.e., data obtained from suppliers or value chain partners) versus other data sources, such as average emission factors.
- ● Companies should describe their plans for improving the accuracy of their GHG inventory data over time e.g., including a greater percentage of primary data in their scope 3 inventories.
- ● If relevant, the FLAG inventory and non-FLAG inventory must be reported separately.
- ● Companies must disclose their GHG inventory for the base year and current reporting year. They may also disclose GHG inventories for the intervening years between the base year and reporting year to show the trend in emissions over time.

## D.3.2 Data limitations

Companies should report on how they plan to bridge data gaps, exclusions and improve data quality. Companies should quantify and provide the level of uncertainty that has been introduced by use of estimates or averages, where possible.

## D.3.3 Verification of GHG inventory

Verification is a process performed by an independent third-party accredited to perform the verification of GHG emissions data. Third-party verification is considered best practice as it supports the quality of underlying data and calculation methods.

If a company has their GHG emissions inventory verified, the following information should be disclosed:

- ● Status of third-party verification (third-party verification underway or third-party verification process in place).
- ● Specification on the scope(s): information should be disclosed for each scope separately. For scope 2, it should be stated whether the location-based and/or the market-based figure has been verified. For scope 3, the scope 3 categories that the verification/assurance covers should be disclosed.

- ● Proportion of reported emissions verified as a percentage, e.g., 100% of scope 2 emissions have been verified.
- ● Frequency of verification cycle, e.g., biannual, annual or biennial.
- ● Type of assurance: limited assurance, moderate assurance, reasonable assurance or high assurance.
- ● If the GHG inventory has been verified or assured for previous years, this information should be available for these years, including the base year.
- ● The opinion issued by the provider(s).
- ● Link/attachment of verification or assurance statement.
- ● Standard used for the verification or assurance.
- ● The name of the provider(s).

## D.3.4 Worked example: GHG emissions inventory

This section provides a worked example that summarizes the reporting guidance for GHG emissions inventory set out in the section above.

## Full GHG inventory

Example Corp. performs a full GHG inventory of its scope 1, 2 and 3 GHG emissions on an annual basis. The reporting period of the inventory (scopes 1, 2 and 3) covers a financial year running from 1 April to 31 March.

Table 8. Example Corp.'s GHG inventory

| Scope or scope 3 category                                     | Base year emissions, FY2018 (tCO 2 e)   | FY2019 (tCO 2 e)   | FY2020 (tCO 2 e)   | FY2021 (tCO 2 e)   | FY2022 (tCO 2 e)   |
|---------------------------------------------------------------|-----------------------------------------|--------------------|--------------------|--------------------|--------------------|
| Scope 1                                                       | 1,000                                   | 1,100              | 350                | 300                | 880                |
| Scope 2 (location-based)                                      | 10,000                                  | 9,800              | 2,200              | 5,000              | 12,000             |
| Scope 2 (market-based)                                        | 8,000                                   | 6,800              | 1,200              | 2,500              | 6,320              |
| Scope 3, category 1: Purchased goods and services             | 202,000                                 | 203,000            | 180,500            | 170,500            | 175,500            |
| Scope 3, category 2: Capital goods                            | 30,000                                  | 29,000             | 3,000              | 18,000             | 16,000             |
| Scope 3, category 3: Fuel- and energy-related activities      | 3,000                                   | 2,940              | 660                | 1,500              | 3,600              |
| Scope 3, category 4: Upstream transportation and distribution | 70,000                                  | 70,000             | 55,000             | 62,000             | 68,000             |
| Scope 3, category 5: Waste generated in operations            | 10,000                                  | 9,500              | 9,500              | 8,000              | 9,000              |
| Scope 3, category 6: Business travel                          | 5,000                                   | 6,000              | 5,500              | 200                | 2,500              |
| Scope 3, category 7: Employee                                 | 2,500                                   | 2,500              | 2,400              | 100                | 1,000              |

| Scope or scope 3 category                                       | Base year emissions, FY2018 (tCO 2 e)   | FY2019 (tCO 2 e)   | FY2020 (tCO 2 e)   | FY2021 (tCO 2 e)   | FY2022 (tCO 2 e)   |
|-----------------------------------------------------------------|-----------------------------------------|--------------------|--------------------|--------------------|--------------------|
| commuting                                                       |                                         |                    |                    |                    |                    |
| Scope 3, category 8: Upstream leased assets                     | 0                                       | 0                  | 0                  | 0                  | 0                  |
| Scope 3, category 9: Downstream transportation and distribution | 0                                       | 0                  | 0                  | 0                  | 0                  |
| Scope 3, category 10: Processing of sold products               | 0                                       | 0                  | 0                  | 0                  | 0                  |
| Scope 3, category 11: Use of sold products                      | 0                                       | 0                  | 0                  | 0                  | 0                  |
| Scope 3, category 12: End-of-life treatment of sold products    | 15,000                                  | 15,150             | 12,000             | 12,300             | 15,600             |
| Scope 3, category 13: Downstream leased assets                  | 0                                       | 0                  | 0                  | 0                  | 0                  |
| Scope 3, category 14: Franchises                                | 0                                       | 0                  | 0                  | 0                  | 0                  |
| Scope 3, category 15: Investments                               | 0                                       | 0                  | 0                  | 0                  | 0                  |
| Total: scope 1, scope 2 market-based, scope 3 (all categories)  | 346,500                                 | 345,990            | 268,910            | 272,900            | 291,200            |

## Exclusions

Emissions from small offices with fewer than 5 employees are excluded from the inventory and consist of 0.1% of scope 1 and 2 emissions in the target base year of FY2018.

## Data limitations

For our emissions from scope 3, category 1 'purchased goods and services', manufacturers are invited to present their own estimates based on fuel consumption and specific activity data. We expect to improve the methodology to calculate these emissions for next year's GHG inventory by increasing the proportion of data from primary sources in this category from 50% to 80%. If current values or assumptions are adjusted in any material way, Example Corp. will communicate these changes and perform the corresponding adjustments to the baseline, following our base year emissions recalculation policy.

## Verification of GHG emissions

Example Corp. engaged with 'Name of third-party verification body' to conduct a verification of our corporate GHG emissions inventory over the period April 1, 2021 to March, 31 2022. The verification was performed in accordance with the 'Name of verification standard used'.

The verified metrics included scope 1, scope 2, scope 3 category 1 'purchased goods and services', category 2 'capital goods', category 3 'fuel- and energy-related activities', category 4 'upstream transportation and distribution', category 5 'waste generated in operations, category 6 'business travel, category 7 'employee commuting' and category 12 'end-of-life treatment of sold products'. The verification body found no evidence that the above metrics reported are not materially correct, and no evidence that the assertion is not consistent with Example Corp. actual corporate GHG emissions position, with a moderate (i.e., limited) level of assurance. The results of the assessment can be found in the following link to the 'Independent Assurance Statement'.

## D.4 Target description

## D.4.1 Description of the target

Companies must publicly disclose all approved targets (scope 1, 2 and/or 3) annually. Targets should be described with the exact SBTi-approved wording, details should be consistent with the information presented in the SBTi target dashboard and should cover the below elements:

- ● Target type (e.g., absolute, intensity, renewable electricity, supplier/customer engagement) and target sub-type (e.g. maintenance target) when applicable.
- ● Target IDs as provided by the SBTi (when applicable) of near term and long-term targets (e.g., 'ABS1' illustrating the first absolute target set by a company).
- ● The year the target was set (i.e., the year the target was validated).
- ● Names of emission scope(s) and scope 3 category/categories covered by the target, including percentage of base year emissions covered and activities covered.
- ● Target base year.
- ● Target coverage of base year emissions in tonnes of CO2 equivalent and represented as a percentage, disaggregated by scope and scope 3 category.
- ● Percentage of exclusions from GHG inventory and/or target boundary (see section 1.7 of the reporting guidance).
- ● Target year.
- ● Target value, i.e., targeted percentage reduction from base year. (see section D.4.2 of the reporting guidance).
- ● Companies may specify the target's absolute emissions reductions (in tonnes CO2e) in addition to the targeted percentage reduction from base year.
- ● For intensity targets, an explanation of the metric or activity value used. Please note that intensity targets should be expressed on both an absolute and an intensity basis.
- ● For scope 2 targets, whether a location-based or market-based approach was used to calculate emissions in the base year and to track performance.
- ● Method(s) used for target-setting, including whether a cross-sector, commodity pathway (FLAG targets), a sector pathway or a combination of pathways was used.
- ● References to the version of the SBTi criteria and target-setting tool used.
- ● Any other information used to calculate targets (assuming that the data is not commercially sensitive).
- ● Emissions to be neutralized per scope 1, 2 and 3 at the target year and any planned neutralization milestones (in tonnes CO e and percentage). 2
- ● Nature and scale of planned actions to mitigate emissions beyond the company's value chain (see section D.7.5).

## D.4.2 Different levels of ambition by scope and/or activity

In cases where ambition is differentiated across scopes or scope 3 categories included within a single target, this should be clarified in the description of the target. For example, if a company has a target to reduce absolute scope 1 and 2 GHG emissions by 50% but plans to reduce scope 1 by 40% and scope 2 by 75%, this should be made clear in the description of the target.

## D.4.3 Exclusions from emissions inventory and/or target boundary

Companies should describe the exclusions from the emissions inventory and/or target boundary and communicate future plans to bring any currently excluded emissions into their emissions inventory and/or target boundary.

## D.4.4 Worked example: Target description

This section sets out a reporting example of Example Corp. that summarizes the reporting guidance for the target description as set out in the section above. Details about the target base year emissions and target coverage disaggregated per scope, exclusions from emissions inventory and/or target boundary, and scope 2 methodological approach, are presented in the worked example of the 'Target progress' section below (see section D.5.3).

## Table 9. Example Corp.'s approved science-based targets

Example Corp.'s near-term emission reduction targets were approved by the Science Based Targets initiative in 2019. Our long-term and net-zero targets were approved in 2022. Our approved science-based targets are as follows:

| Target ID   | Target type           | Target wording                                                                                                                                                                           | Scopes covered   |
|-------------|-----------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------|
| NZ          | Net-zero              | Example Corp. commits to reach net-zero greenhouse gas emissions across the value chain by FY2050 from a FY2018 base year.                                                               | 1+2+3            |
| ABS1        | Absolute (near-term)  | Example Corp. commits to reduce scope 1 and 2 emissions 50% by FY2030 from a FY2018 base year.                                                                                           | 1+2              |
| O1          | Renewable electricity | Example Corp. also commits to increase annual sourcing of renewable electricity from 20% in FY2018 to 100% by FY2025                                                                     | 2                |
| INT1        | Physical intensity    | Example Corp. also commits to reduce scope 3 purchased goods and services and upstream transportation and distribution emissions 69% per product sold by FY2030 from a FY2018 base year. | 3                |
| O2          | Supplier engagement   | Example Corp. also commits that 80% of suppliers by emissions covering purchased goods and services will have science-based targets by FY2025.                                           | 3                |

Reference to SBTi criteria and target-setting tools used to set targets:

- ● Net-zero and long-term targets were set according to the SBTi Corporate Net-Zero Standard Version 1.0 and Net-Zero Tool Version 1.0.2, consistent with the Pathways to Net-Zero: SBTi Technical Summary Version 1.0.
- ● Near-term targets were set using the cross-sector absolute reduction and scope 3 physical intensity reduction methods, according to the SBTi Criteria and Recommendations Version 4.0 and the Science-Based Target-Setting Tool Version 1.1.

## D.5 Target progress

## D.5.1 Progress in the reporting year

Companies must report on progress toward their targets on an annual basis, and should cover the elements described below:

- ●  Target progress from the base year to the reporting year in terms of emissions reductions, share of renewable electricity or supplier/customer engagement (annual breakdowns are preferable).
- ●  An analysis of trends or changes over multiple years; variability of progress against targets between years is expected.
- ●  The base period of reported data from which progress is measured (i.e., for fiscal years, they should indicate the starting month of the fiscal year).
- ●  Any adjustments or recalculations to baseline emissions should be made before target progress is calculated and reported. See section D.6 in this reporting guidance for further information.
- ●  Percentage of target completion: Completed targets are indicated with a value of 100%. For absolute or intensity emission reduction targets, percentage of target completion relative to base year is calculated as follows:

Target completion (%) = (base year emissions value - reporting year emissions value) / (base year emissions value x targeted reduction from base year (%) / 100) x 100

For example, a company with a 60% absolute reduction target that has a base year value of 1,000 tCO2 e, a reporting year value of 700 tCO e, and a target year value of 2 400 tCO2e would have a target completion percentage of (1,000 - 700) / (1,000 x (60% / 100) x 100 = 50%.

For renewable energy or supplier engagement targets, target completion is based on the share of renewable energy or supplier engagement as of the reporting year, calculated as follows:

Target completion (%) = (% share in reporting year - % share in base year) / (% share in target year - % share in base year) x 100

For example, a company with a  target of 100% sourcing of renewable electricity that has a base year share of 40%, and a reporting year share of 64%, would have a target completion percentage of (64 - 40) / (100 - 40) x 100 = 40%.

## Absolute emissions reduction targets

- ●  Companies should report absolute emission values (within the target boundary) for near and long-term targets in the reporting year by scope and by scope 3 category.

## Emissions intensity targets

- ●  Companies should report emissions in tCO2e per unit of activity based on the activity metric chosen in the reporting year e.g., tonnes of CO e per unit of production, tonnes 2 of CO2e per passenger kilometer, tonnes CO2e per FTE employee, etc.
- ●  Companies with emissions intensity targets should also report their equivalent absolute emission values in tCO2 e.

## Renewable electricity targets

Companies setting renewable electricity targets should report:

- ●  The level of renewable electricity procurement at the base year and the reporting year in terms of the percentage of renewable electricity procured out of total electricity consumed. For example, a company with a 100% renewable electricity target and a reporting year value of 80% has a progress of 80% of a 100% share of renewable electricity.
- ●  The absolute quantity of electricity procurement (in kWh or a comparable unit) and the quantity of electricity procurement that comes from renewable sources, in accordance with the recommendations of the RE100 Technical Criteria.

## Supplier/customer engagement targets

- ●  Companies should report the percentage of suppliers or customers, as defined by the relevant metric (e.g., by emissions or by spend), with science-based targets at the base year and the reporting year.
- ●  Supplier or customer bases are expected to change over time, and companies should account for corresponding changes in their scope 3 inventory. Even though suppliers or customers change and their emissions fluctuate, the target value continues to apply until the target date is reached.
- ●  If a company sets a goal for  a certain percentage of its suppliers / customers by emissions to have science-based targets, then it will recalculate the portion of scope 3 emissions each supplier / customer with science-based targets represents and aggregate the emissions covered by suppliers annually to find the reporting year value.

## D.5.2 Level of disaggregation

Companies shall report their progress toward each of their target(s) at the level of disaggregation as set out in the approved target language on the SBTi target dashboard and as described below:

## Multiple targets:

- ● Companies should not combine or aggregate approved SBTs into a single target unless they have also reported at the level of disaggregation that is communicated in their approved target language. For example, a company has set a physical intensity target on scope 3 category 1 'purchased goods and services' and an absolute target

on scope 3 category 11 'use of sold products' and category 12 'end-of-life treatment of sold products.' This company shall report on the physical intensity scope 3 target and the absolute scope 3 target for categories 11 and 12 separately.

## Combined scope targets:

- ● Combined scope targets (e.g., scope 1+2+3) should be reported with the same level of aggregation as the approved target at a minimum.
- ● In addition, progress against scope 1 and 2 targets and scope 3 targets should be reported separately.
- ● Progress against a more detailed level of disaggregation, for example separating scope 1 and 2, or scope 3 categories, may optionally be reported.

## D.5.3 Worked example: Target progress

This section provides a worked example that summarizes the reporting guidance for target progress set out in the section above.

Table 10. Example Corp.'s progress on their approved scope science-based targets.

| Reporting item [target]                                | Base year value FY2018 *   | Base year emissions covered by targets, (tCO 2 e) (%)   | FY2019 value   | FY2020 value   | FY2021 value   | FY2022 value   | FY2022 % change (from FY2018)   | Target completion (%)   |
|--------------------------------------------------------|----------------------------|---------------------------------------------------------|----------------|----------------|----------------|----------------|---------------------------------|-------------------------|
| Scope 1 (tCO 2 e)                                      | 1,000                      | 1,000 (100%)                                            | 1,100          | 350            | 300            | 880            | -12%                            | N/A                     |
| Scope 2 (market-based) (tCO 2 e)                       | 8,000                      | 8,000 (100%)                                            | 6,800          | 1,200          | 2,500          | 6,320          | -21%                            | N/A                     |
| Total scope 1+2 (market-based) (tCO 2 e) [ABS1]        | 9,000                      | 9,000 (100%)                                            | 7,900          | 1,550          | 2,800          | 7,200          | -20%                            | 40%                     |
| Total electricity use (MWh)                            | 22,000                     | N/A                                                     | 21,500         | 5,000          | 11,000         | 28,000         | +27%                            | N/A                     |
| Electricity procurement from renewable sources (MWh)   | 4,400                      | N/A                                                     | 6,450          | 1,500          | 3,300          | 14,000         | +218%                           | N/A                     |
| %of electricity from renewable sources [O1]            | 20%                        | N/A                                                     | 30%            | 30%            | 30%            | 50%            | +150%                           | 37.5%                   |
| Scope 3, cat.1: Purchased goods and services (tCO 2 e) | 202,000                    | 200,000 / 99% (INT1)**                                  | 201,00 0       | 180,00 0       | 170,00 0       | 175,00 0       | -12.5%                          | N/A                     |

| Reporting item [target]                                                                                   | Base year value FY2018 *   | Base year emissions covered by targets, (tCO 2 e) (%)   | FY2019 value   | FY2020 value   | FY2021 value   | FY2022 value   | FY2022 % change (from FY2018)   | Target completion (%)   |
|-----------------------------------------------------------------------------------------------------------|----------------------------|---------------------------------------------------------|----------------|----------------|----------------|----------------|---------------------------------|-------------------------|
| Scope 3, cat. 4: Upstream transportation and distribution (tCO 2 e)                                       | 70,000                     | 70,000 / 100% (INT1)                                    | 70,000         | 55,000         | 62,000         | 68,000         | -2.9%                           | N/A                     |
| Total scope 3, cat. 1 and 4 (tCO 2 e)                                                                     | 272,000                    | 270,000                                                 | 271,00 0       | 235,00 0       | 232,00 0       | 243,00 0       | -10.7%                          | N/A                     |
| Activity level: number of products sold                                                                   | 10,000                     | 10,000                                                  | 10,100         | 8,000          | 8,200          | 10,410         | +4.1%                           | N/A                     |
| Overall emissions intensity (tCO 2 e/product) [INT1]                                                      | N/A                        | 27.00                                                   | 26.83          | 29.38          | 28.29          | 23.34          | -13.6%                          | 19.6%                   |
| Suppliers of purchased goods and services with science-based targets (% coverage of scope 3, cat. 1) [O2] | 0%                         | N/A                                                     | 0%             | 5%             | 10%            | 20%            | 20%                             | 25%                     |
| Scope 1, scope 2 market-based, scope 3 (all categories) (tCO 2 e) [LTABS1]                                | 346,500                    | 346,500                                                 | 345,99 0       | 268,91 0       | 272,90 0       | 291,20 0       | -16.0%                          | 17.7%                   |

*Example Corp. performs a full inventory of its scope 1, 2 and 3 emissions on an annual basis. Emissions from small offices with fewer than 5 employees are excluded from the inventory and consist of 0.1% of scope 1 and 2 emissions in the target base year.

**This target does not cover purchased office supplies and cleaning services emissions within scope 3 category 1 'purchased goods and services'.

## D.6 Substantial emission variations and changes in targets

## D.6.1 Base year recalculation policy and threshold

According to the GHG Protocol Corporate Standard, 'companies shall develop a base year emissions recalculation policy, and clearly articulate the basis and context for any

recalculations. If applicable, the policy shall state any 'significance threshold' applied for deciding on historic emissions recalculation'. The SBTi requires companies' base year emissions recalculation policies to include a significance threshold of 5% or less according to Criterion C27 and  C33 of the Corporate Near-Term Criteria and the Corporate Net-Zero Standard criteria respectively.

Companies should disclose whether they have a base year recalculation policy and what significance threshold is used in their annual reporting. The base year emissions recalculation policy should be indicated in annual reports, either in the reporting itself or as a reference to the policy published elsewhere.

For detailed guidelines related to emissions inventory rebaselining, please review Chapter 5 'Tracking Emissions Over Time' of the GHG Protocol Corporate Standard.

## D.6.2 Reasons for variation in emissions

Companies should annually disclose and justify significant increases or decreases in scope 1, 2 and 3 emissions between the current reporting year and previous reporting years. 54 Companies should contextualize the reasons for variation by including an analysis of the changes in emissions and impact on the GHG inventory.

Company emissions may vary for the many reasons, including:

- ● Changes in renewable energy consumption
- ● Emission reduction activities
- ● Divestments, acquisitions, and mergers
- ● Change in business output (product and/or service), e.g., organic growth, purchase of new facilities due to business expansion or release of a new product
- ● Change in methodology used to calculate the emissions inventory, e.g., changes in emission factors
- ● Change in organizational boundary or operational boundary used in emissions inventory calculation, e.g., changing from equity share approach to operational control approach
- ● Change in physical operating conditions, e.g., increased rainfall heightened the production of hydroelectricity

In some cases, significant changes in company emissions or circumstances can trigger a target recalculation. In this case, companies should provide background and justification for the changes in emissions). For example, in the case of methodological improvements or changes to the base year emissions methodology, the company should include a description of the following:

- ● The previous methodology and the new methodology
- ● Any changes in sources of data and/or emission factors
- ● Details on how changes were implemented
- ● Corrective actions adopted
- ● Description of the extent of their impact on the GHG inventory (e.g., % impact on base year emissions)

54 The SBTi defines significance as 5% or more.

If the baseline data has changed due to merger, acquisition or divestment, the company should provide the type of structural change, date of completion and percentage impact on base year emissions.

## D.6.3 Worked example: substantial emission variations and changes in targets

This section provides a worked example that summarizes the reporting guidance for substantial emission variations, base year emissions recalculations, and changes in target, set out in the section above.

Example Corp. has recalculated and restated its base year emissions (financial year 2018) across scope 3 category 4, 'upstream transportation and distribution', to reflect an improved data collection methodology and ensure consistent estimation methods for each reporting year.

Our company's base years emissions recalculation policy defines a significant change as a cumulative change of 5% or more in our total base year emissions. We have assessed the implications of this restatement on our science-based targets and have not identified a need to update the target as the change represents an impact of less than 5%.  To access our recalculation policy follow 'this link'.

## D.6.3 Recalculated and revalidated targets

If a target has been updated due to new target submissions or a triggered target recalculation, companies must report progress on their currently active target(s) as presented in the SBTi target dashboard. Companies with revalidated targets should report on the details on the revisions to the target, including an explanation of the reason for revision. Companies should also include the target language of the target that was replaced by the updated target.

When disclosing progress against a target that has replaced a previous target due to a base year recalculation of the GHG emissions inventory, the company must ensure that they are disclosing the rebaselined emissions inventory. For consistency, the company may restate the GHG emissions data between the base year and the reporting year.

If a company is in the process of updating its targets whilst a SBTi validation is still in progress, the company should report progress on the target that is valid at the time of reporting. The company may state that an updated target is under review and report progress against the future updated target, highlighting that it has not yet been formally validated.

## D.7 Actions towards meeting SBTs

## D.7.1 Information on emission reduction projects

Companies should report information on emission reduction initiatives contributing to the achievement of their targets, and include the following information:

- ● Description of the emission reduction initiatives within the reporting year and the total estimated annual CO2e savings. The stage of development of each emissions reduction initiative should be clear i.e., to be implemented, implementation commenced or implemented, as well as the scope(s) and/or scope 3 category(ies) the GHG emissions impacts are expected or have already occurred.
- ● Novel or innovative efforts or partnerships that have been put into place to reduce emissions.
- ● Investments or changes that have been made that may not yet have delivered significant results but that are expected to do so in the coming years or that enable the necessary transformation towards a long-term goal.
- ● Companies should disclose their climate transition plans (including their financial plans) to outline how they will deliver on their strategy to reach their targets. See section D.7.7 for further information.

## D.7.2 Information on contractual instruments (for scope 2 targets)

Companies should provide details on the types of contractual instruments (e.g., unbundled renewable energy certificates, power purchase agreements) that are used to reduce their scope 2 market-based emissions and/or make progress towards a renewable electricity target. Companies should align with the RE100 Technical Criteria.

Companies should illustrate how the market-based instruments being used conform with the GHG Protocol Scope 2 Guidance, specifically the scope 2 quality criteria.

## D.7.3 Decarbonization pathway

If possible, companies should specify the anticipated and/or observed progress curve against their targets, e.g., linear or variable, that describes the expected pace of reduction. When applied to renewable electricity and engagement targets, the progress curve is not a function of emission reductions but instead progress of the relevant metric for those targets e.g., percentage of suppliers engaged for a scope 3 supplier engagement target over time.

If progress of targets and planned emission reductions are currently not on track or deviates away from the target pathway, companies should provide an explanation and describe the strategy for addressing these deficits in the future.

## D.7.4 Planned milestones and/or near-term investments for neutralization

Companies should disclose the following elements:

- ● The magnitude of emissions planned to be neutralized in the net-zero target year. This quantity of emissions should include not only unabated emissions within the target boundary, but also emissions excluded from the target boundary and/or inventory.
- ● Description of any planned milestones and/or near-term investments that demonstrate the integrity of its commitment to neutralize unabated emissions in the target year. For example, a company should disclose if it is investing or planning to invest into carbon dioxide removal and storage technologies (e.g., direct air capture) in the near-term.

## D.7.5 Planned actions or investments to mitigate climate change beyond your value chain

The SBTi Corporate Net-Zero Standard strongly recommends that companies take immediate action above and beyond their science-based targets to contribute to reaching global net-zero through beyond value chain mitigation (BVCM). Companies should refer to the BVCM Report section 'Step 4: Report BVCM Activities and Outcomes', and, at a minimum, report the following elements:

- ● Description of any actions taken, or investments deployed in the reporting year, as well as plans for beyond value chain mitigation activities or investments in future years to accelerate the net-zero transition beyond the company's value chain. Companies should report annually on the nature and scale of those actions and/or investments.
- ● If no beyond value chain mitigation activities are taken or considered, companies should provide an explanation.

## D.7.6 Use of carbon offset credits and avoided (product-level) emissions

Companies should publicly disclose carbon credits, which are sourced from outside the company's value chain (i.e., often referred to as "offset credits"), separately from their reported GHG inventory and ensure that they are not counted towards the progress of their science-based targets.

Companies should publicly disclose emission reductions that occur outside of a product's life cycle or value chain but as a result of the use of that product (often described as "avoided emissions") separately from their reported GHG inventory and ensure that they are not counted towards the progress of their science-based targets.

This information should be publicly available and easily accessible. Companies should refrain from using any misleading wording and it should be very clear that target progress does not include carbon offset credits and/or avoided (product-level) emissions.

## D.7.7 Climate transition plan

According to CDP, a climate transition plan is a time-bound action plan that outlines how an organization will pivot its existing assets, operations and entire business model towards a trajectory aligned with the latest and most ambitious climate science recommendations. Climate transition plans should be ambitious, have integrity and transparency, be credible and fair. Companies should develop comprehensive and actionable transition plans which indicate detailed target descriptions and the actions that will be undertaken to meet their targets. They should be updated every 5 years and progress (including any changes to the plan) should be reported annually. Specifically, companies should publicly disclose:

- ● Governance structure to oversee the development, implementation and verification of climate transition plans and the review frequency of these plans.
- ● Incentive structure related to climate change including any executive compensation linked to near and long-term targets.
- ● Description of alignment with credible sector pathways consistent with limiting warming to 1.5°C and explanation of any material difference between the company's

transition plan and sector pathways. Please refer to Pathways to Net-Zero: SBTi Technical Summary and sector guidance for more information (e.g., FLAG guidance).

- ● Financial indicators (e.g., capital expenditure (CAPEX), operating expenditure (OPEX), revenue and research and development expenditure) and how these are used to plan and implement a business model aligned with a 1.5°C world. Capital expenditure plans, research and development plans and investments should be split between new and legacy/stranded assets.
- ● Specific actions across all parts of the company's value chain that will help meet its science-based targets, including through supplier and customer engagement.
- ● Specific actions to address any data limitations (e.g., on emissions).
- ● Skills and human resource development related to climate change.
- ● Specific policies and regulations, including carbon pricing, needed to facilitate transition plans.
- ● Clear disclosures on public advocacy, lobbying and policy engagement expenditures and effort on policies that could limit or worsen climate change. Specifically, companies should describe how current and future lobbying and policy engagement activities are consistent or inconsistent with a 1.5°C world.
- ● Actions planned or implemented that contribute to a just transition (e.g., partnerships with workers, trade unions, communities, and suppliers and the integration of free, prior and informed consent of Indigenous Peoples). Specifically, the climate transition plan should explain how it considers and addresses social consequences and impacts of mitigation actions, including on race, gender, and intergenerational equity.
- ● Actions planned or implemented to avoid the conversion of remaining natural ecosystems - eliminating deforestation, wetland and peatland loss by 2025 at the latest, and the conversion of other remaining natural ecosystems by 2030.
- ● Results of any third-party assessment and/or verification of the company's climate transition plan or 'readiness for net-zero' by other initiatives, such as ACT (Assessing Low Carbon Transition).

Companies should refer to further guidance on transition plans, for example, the CSRD reporting requirements; report from the United Nations' High Level Expert Group on the Net -Zero Emissions Commitments of Non-State Entities 'Integrity Matters: Net Zero Commitments by Businesses, Financial Institutions, Cities and Regions'; CDP resources on transition plans; the Transition Plan Taskforce Disclosure Framework and the Glasgow Financial Alliance for Net Zero ('GFANZ') 'Expectations for Real-economy Transition Plans' report.

Companies without a formal transition plan should disclose information related to their climate transition as described above to provide a robust context and increase transparency in their decarbonization journey.

## D.7.8 Worked example: actions towards meeting SBTs

This section sets out a reporting example of Example Corp. that summarizes the reporting guidance for actions towards meeting SBTs set out in the section above.

Table 11. Example Corp.'s actions taken to meet its science-based targets

| Target                                                                                                                                                        | Actions towards meeting SBTs                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Reduce absolute scope 1 and 2 emissions 50% by FY2030 from a FY2018 base year (ABS1).                                                                         | In 2022, we decreased our scope 1 and 2 emissions by 20% compared to 2018 levels. This was achieved through a 12% reduction in scope 1 and 21% reduction in scope 2 market-based emissions.In scope 1, we reduced direct emissions by continuing to convert our fleet of internal combustion engine vehicles and propane forklifts to electric vehicles and machines. In scope 2, we have increased our manufacturing facility energy efficiency by an average of 9% since 2018 resulting in a decrease in electricity demand, which has been partially offset by the electricity used for our new fleet.                                                                                        |
| Increase annual sourcing of renewable electricity from 20% in 2018 to 100% by 2025 (O1).                                                                      | We have entered into renewable electricity purchase agreements that have reduced scope 2 market-based emissions further and helped us make progress towards our goal of 100% renewable electricity by 2025.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Reduce scope 3 purchased goods and services and upstream transportation and distribution emissions 69% per product sold by 2030 from a 2018 base year (INT1). | Significant progress has been made to make our products with less raw materials per item. Additionally, we are working to engage our suppliers and provide resources for them to decarbonize their own operations. We may need to recalculate our baseline in a few years as we switch from using average emission factors to supplier-specific factors, at which time we will assess whether our target needs to be revised and updated with the SBTi. Overall, covered emissions in categories 1 and 4 have decreased by 10% while the number of products sold has increased by 4%, from 10,000 in 2018 to 10,410 in 2022. Emissions intensity has thus decreased by 13.6% from the base year. |
| Key suppliers representing 80% of emissions from our purchased goods will set a science-based emission reduction target by FY2025 (O2).                       | Key suppliers representing 20% of emissions from our purchased goods and services have set a science-based emissions reduction target as of the end of FY2022. We have undertaken workshops with these subcontractors to improve their scope 1, 2 and 3 reporting, modeled science-based targets together and developed carbon reduction plans. We have also worked with them to support their supply chains to set science-based targets.                                                                                                                                                                                                                                                       |
| Reduce absolute scope 1, 2 and 3 GHG emissions 90% by FY2050 from a FY2018 base year (LTABS1).                                                                | Our long-term target includes all scopes and scope 3 categories at 100% coverage. Progress towards this target is displayed in Table 10. As of FY2022, we have reduced our total scope 1, 2 and 3 emissions by 16%, which is almost 18% of the way to achieving our target. To accomplish this goal, we have finalized our transition plan, which describes key actions and investment strategies, including the review of procurement practices, engagement with business partners, lower carbon intensity products and the improvement in the accuracy of our GHG accounting to identify additional reduction opportunities.                                                                   |
| Reach net-zero greenhouse gas emissions across the value chain by FY2050 from a FY2018 base year (NZ)                                                         | Reaching net-zero greenhouse gas emissions across the value chain is linked to achieving the long-term target (LTABS1) and neutralizing all unabated emissions with permanent removals. In 2050, Example Corp. commits to neutralizing 34,668 tonnes of CO 2 -equivalent equivalent to 9% of total actual emissions. This target is also linked to the aforementioned near-term targets, which are interim steps on the                                                                                                                                                                                                                                                                          |

| Target completion: N/A                           | path to net-zero: ABS1, O1, INT1, and O2. Example Corp. is exploring opportunities for investment in direct air capture in the near future.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
|--------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Use of carbon credits                            | Example Corp. buys carbon credits that relate to mitigation outside of the value chain boundary from XYZ but does not count them as progress towards science-based targets and instead reports them as a BVCM activity. We purchase 350 tCO 2 e of emission reduction carbon credits at an average price of 80 USD/tCO 2 e from 'Name of activity type', verified to 'Name of standard'. These carbon credits are used as part of the delivery of Example Corp's BVCM pledge and the company makes a claim that it has contributed to global mitigation efforts, over and above its 1.5°C science-based target .                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Avoided emissions                                | Example Corp. develops products which enable its customers to reduce emissions, but these emissions reductions are not accounted for in Example Corp's GHG inventory. These avoided (product-level) emissions are not counted towards the company's science-based target and are reportedly separately from the GHG inventory.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Climate transition plan information and progress | Governance: The Board of Directors of Example Corp. approves the company's decarbonization strategy and oversees climate performance metrics, emissions reduction targets, low-carbon technological developments and investment plans to ensure that they are on track and compliant with the approved transition plan. The Board of Directors reviews the climate transition plan once a year. Incentive structure: Example Corp. has set an internal carbon price to help guide investment decisions on new projects and assess whether an investment is in line with the decarbonization path. Part of the CEO's and Executive Leadership team's annual bonus is dependent on the achievement of the climate performance indicators set out in the climate transition plan. Further bonus-based incentives on the climate transition have been rolled out for upper management and middle management across the company. In relation to climate change, 2% of the annual bonus for the CEO and management team is dependent on being on track with achieving our science-based targets. Financial indicators: Example Corp. will allocate a total of 20 million Euros for FY2023-FY2025 to low-carbon investments, representing 25% of total planned investment for the period. The company has also established a goal to dedicate 10% for FY2023-FY2030 for the investment in R&D projects to be in line with the climate transition plan. Overall, by 2030 Example Corp plans to spend 50% of its CAPEX and OPEX in activities aligned with a 1.5°C future and it is planning to generate 60% of its revenues from low-carbon products by 2030. In the reporting year, the company was on track to achieve these |

goals (please see the transition plan footnotes on our financial statements for details).

## Just transition:

Example Corp is investing in a new factory in Tanzania fully powered by renewable energy generated on-site. Any surplus energy will be sold at a rebated price to the local community to reduce the usage of fossil fuel-powered generators. The factory is planned to be completed by 2025. There is also a plan to create a training program for the local community on solar panel maintenance which aims at ensuring business continuity whilst reducing unemployment and increasing income per capita in the area.

## Public advocacy:

Example Corp. has joined relevant pledges (e.g., the Business Ambition 1.5°C declaration) and has advocated for an ambitious approach to fully decarbonize the sector by 2050. Example Corp has not supported any policy that advocates for fossil fuel expansion in the past year.

## ANNEX E: GUIDANCE FOR COMPANIES IN LAND-INTENSIVE SECTORS

Companies with land-intensive activities in their value chain are expected to set a forest, land and agriculture (FLAG) target - that includes both emission reductions and removals in addition to science-based targets that cover energy and industrial processes. The FLAG target indicates how much and how quickly a company needs to reduce its land-based emissions to limit global warming to 1.5°C. Companies should refer to the FLAG guidance and the forthcoming GHG Protocol Land Sector and Removals Guidance (draft guidance released September 2022) to account for agriculture, forestry, and other land use (AFOLU) emissions or removals in their targets or disclosures.

## E.1 Background on FLAG emissions

The FLAG sector, also known in the scientific community as the AFOLU sector, represents about 22% of global anthropogenic GHG emissions (~13 GtCO2e per year), around half coming from agriculture and the other half from land use, land-use change, and forestry (LULUCF) (IPCC, 2022). Even though GHG emissions from FLAG sectors have been historically difficult to evaluate through GHG accounting and target-setting approaches, they must be significantly reduced by 2050 while agricultural production is expected to increase 50% to meet increased food demand. 55

The AFOLU sector has the potential to deliver up to 37% of the emissions reductions and removals needed through 2030, and 20% through 2050 (Griscom et al., 2017). Aligning the AFOLU sector with 1.5°C pathways through reductions is feasible by stopping deforestation and land conversion, reducing peat burning and forest degradation, lowering agricultural emissions and reducing emissions via demand shifts (e.g., addressing diet shift, food loss and waste).

Mitigation in the land sector also requires accounting for biogenic CO  removals (enhancing 2 sinks) due to the potential for forests and soils to store carbon. Biogenic CO  removals 2 include restoring natural ecosystems, deploying silvopasture, improving forest management practices and enhancing soil carbon sequestration (Roe et al., 2019).

## E.2 SBTi FLAG Guidance

The FLAG guidance is aimed at companies in land-intensive sectors, including food, agriculture, and forestry. FLAG pathways include not only emissions reductions, but also removals within the land sector. It includes an overall FLAG sector mitigation pathway as well as 11 specific FLAG mitigation pathways for major commodities: beef, chicken, dairy, leather, maize, palm oil, pork, rice, soy, wheat, and timber and wood fiber. All FLAG pathways include CO2 and non-CO2 emissions related to agriculture and forestry 'to farm gate'.

55 WRI, Creating a Sustainable Food Future.

It is important to consider that companies are required to report emission reductions and removals separately, and removals are included only in FLAG targets. Crucially, FLAG science-based targets are separate from SBTs that cover emissions from energy and industrial processes - therefore, FLAG mitigation cannot be used to meet energy/industry (non-FLAG) targets (e.g., a company cannot bring forests into its value chain to meet another SBT; removals included in FLAG targets cannot be used to meet energy/industrial SBTs).

## E.3 Greenhouse Gas Protocol Land Sector and Removals Guidance

The two FLAG approaches available in the FLAG Guidance (FLAG sector approach and FLAG commodity approach) seek to align with the GHG Protocol Land Sector and Removals Guidance (final version expected in 2024). The guidance will explain how companies should account for emissions and removals from land management, LUC, biogenic products, technological CO2 removals and related activities in GHG inventories.

FLAG guidance and tools will be updated as needed to align with the GHG Protocol Land Sector and Removals Guidance, once finalized, and as new and improved data become available. From April 30, 2023, companies with land-intensive operations shall prepare for and set FLAG targets using the draft version.

## E.4 Which companies are required to set FLAG targets?

Companies with land intensive activities in their value chain from the following sectors are required to set a FLAG science-based target:

- ● Forest and paper products such as timber, pulp and paper, and rubber.
- ● Agricultural production.
- ● Food production from animal sources.
- ● Food and beverage processing.
- ● Food and staples retailing.
- ● Tobacco.

Companies in any other sector that have land-related emissions that total 20% or more of overall emissions across scopes 1, 2 and 3 are also required to set a FLAG target.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->