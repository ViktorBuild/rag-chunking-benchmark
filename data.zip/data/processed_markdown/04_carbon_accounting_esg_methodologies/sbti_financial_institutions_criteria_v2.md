---
document_id: sbti_financial_criteria
title: "Financial Institutions Near-Term Criteria (Version 2.0)"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "SBTi"
year: 2024
original_file: "sbti_financial_institutions_criteria_v2.pdf"
tables_detected: 45
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## SBTi FINANCIAL INSTITUTIONS' NEAR-TERM CRITERIA

Version 2.0

May 2024

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ABOUT SBTi

The Science Based Targets initiative (SBTi) is a corporate climate action organization that enables companies and financial institutions worldwide to play their part in combating the climate crisis.

We develop standards, tools and guidance that allow companies to set greenhouse gas emissions reduction targets in line with what is needed to keep global heating below catastrophic levels and reach net-zero by 2050 at the latest.

The SBTi is incorporated as a charity, with a subsidiary that hosts our target validation services. Our partners are CDP, the United Nations Global Compact, the We Mean Business Coalition (WMBC), World Resources Institute (WRI) and the World Wide Fund for Nature (WWF).

## DISCLAIMER

Although reasonable care was taken in the preparation of this document, the Science Based Targets initiative (SBTi) affirms that the document is provided without warranty, either expressed or implied, of accuracy, completeness or fitness for purpose. The SBTi hereby further disclaims any liability, direct or indirect, for damages or loss relating to the use of this document to the fullest extent permitted by law.

The information (including data) contained in the document is not intended to constitute or form the basis of any advice (financial or otherwise). The SBTi does not accept any liability for any claim or loss arising from any use of or reliance on any data or information in the document.

This document is protected by copyright. Information or material from this document may be reproduced only in unaltered form for personal, noncommercial use. All other rights are reserved. Information or material used from this document may be used only for the purposes of private study, research, criticism or review permitted under the Copyright, Designs and Patents Act 1988 ('Copyright Act') as amended from time to time. Any reproduction permitted in accordance with the Copyright Act shall acknowledge this document as the source of any selected passage, extract, diagram, content or other information.

The SBTi reserves the right to revise this document according to a set revision schedule or as needed to reflect the most recent emissions scenarios, regulatory, legal or scientific developments, and greenhouse gas accounting best practices.

'Science Based Targets initiative' and 'SBTi' refer to the Science Based Targets initiative, a registered charity in England and Wales, number 1205768, and a limited company registered in England and Wales, number 14960097.

© SBTi 2024

|

## VERSION HISTORY

| Version   | Change/Update Description                                                                                                                                                                                                                                                                                | Release Date   | Effective Dates                  |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|----------------------------------|
| Pilot     | The pilot version of the Criteria and Recommendations for Financial Institutions.                                                                                                                                                                                                                        | October 2020   | October 2020 to January 2022     |
| 1.0       | No changes made to the criteria. Version changed from pilot to 1.0 to recognize the end of the pilot phase.                                                                                                                                                                                              | February 2022  | February 2022 to June 2022       |
| 1.1       | Clarification for loan coverage metric, noting that financed emissions may be used to cover the 67% minimum threshold. Clarification to the coverage footnote (footnote B), that small- and medium-sized enterprise lending does not have to be included in the calculation of the minimum 67% coverage. | July 2022      | August 2022 to November 30, 2024 |
| 2.0       | Updates to criteria FI-C10, FI-C12, FI-C15, FI-C16, FI-C17.1, FI-C17.2, FI-C17.3, FI-C17.4, among others, and various clarifications - see the accompanying Main Changes Document for a summary of changes and the development process.                                                                  | May 28, 2024   | From November 30, 2024           |

|

## CONTENTS

| DISCLAIMER........................................................................................................................... 3   |
|-------------------------------------------------------------------------------------------------------------------------------------------|
| CONTENTS............................................................................................................................. 5   |
| INTRODUCTION......................................................................................................................6       |
| 1. GHG EMISSIONS AND TARGET BOUNDARY.................................................................. 8                                  |
| 2. METHOD AND EMISSIONS ACCOUNTING REQUIREMENTS...................................... 10                                                  |
| 3. SCOPE 1 AND 2 TARGETS.............................................................................................. 12                 |
| 4. SCOPE 2............................................................................................................................13  |
| 5. SCOPE 3 PORTFOLIO TARGET-SETTING REQUIREMENTS........................................14                                                |
| 6. REPORTING REQUIREMENTS........................................................................................32                       |
| 7. RECALCULATION AND TARGET VALIDITY................................................................... 34                                |
| 8. HOW TO COMMUNICATE TARGETS AND TRACK PROGRESS...................................35                                                     |
| APPENDIX............................................................................................................................. 39  |

|

## INTRODUCTION

This document, the SBTi Financial Institutions' Near-Term Criteria Version 2.0, includes all criteria that must be met for financial institutions' near-term target(s) to be validated by the SBTi as well as recommendations that are important for transparency and best practice. It is important to note that criteria and recommendations are subject to change and may be updated.

These criteria apply to financial institutions (FIs). The SBTi defines a financial institution as an entity that generates 5% or more of its revenue from investment, lending or insurance activities. This includes but is not limited to banks, asset managers and private equity firms, asset owners and insurance companies, and mortgage real estate investment trusts (REITs). The SBTi encourages real economy companies that have more than 5% of their revenue from financial activities to use these SBTi Financial Institutions' Near-Term Criteria to set targets for those activities in addition to their corporate targets. Currently, public financial institutions are not covered within the SBTi framework. The Financial Institutions' Near-Term Criteria cover the subset of activities and asset classes described in Table 1 below; the SBTi is preparing additional documentation which will supersede these criteria once published.

These sector-specific criteria supersede the general SBTi Corporate Near-Term Criteria, which serve as the basis for this document, with some adjustments for FIs. FIs must also follow the Greenhouse Gas Protocol (GHGP) Corporate Standard, Scope 2 Guidance and Corporate Value Chain (Scope 3) Accounting and Reporting Standard for their emissions accounting and reporting. 1

The SBTi Financial Institutions' Near-Term Criteria Version 2.0 should be read in conjunction with the Financial Sector Near-Term Science-Based Targets Explanatory Document Version 2.0 and the Private Equity Sector Science-Based Target Guidance, which include informative guidance; the Main Changes Document, which summarizes the development process and key revisions of the Financial Institutions' Near-Term Criteria Version 2.0; the Procedure for Validation of SBTi Targets, which describes the underlying process followed to assess targets; the Criteria Assessment Indicators, which detail the indicators used to determine conformance and non-conformance with criteria; and the SBTi Glossary, which lists the terms, definitions and acronyms used in this document. Translations of the Financial Institutions' Near-Term Criteria Version 2.0 will be made available; the English version shall prevail in the event of any discrepancies in translation. The SBTi encourages FIs to develop additional, long-term targets in accordance with the SBTi FI Net-Zero Standard upon its publication.

## Development Process

The SBTi first published its near-term criteria for FIs in October 2020 after extensive stakeholder consultation. After receiving significant feedback and synthesizing lessons learned, the SBTi began updating the criteria in April 2022. This preceded the SBTi Board's adoption of the Standard Operating Procedure (SOP) for Development of SBTi Standards on 14 December 2023, and its publication in April 2024. After multiple rounds of research and

1 Limited deviations from the scope 3 standard in this framework are described in Section 4.1 of the Financial Sector Near-Term SBT Explanatory Document.

drafting, a draft of this document was published in June 2023 for public consultation until August 2023, which was followed by further research and drafting until October 2023. The development process thereafter followed a streamlined version of the procedures outlined in the SOP because the project was already in an advanced stage of development when the SOP was formally adopted. However, the SBTi adhered to the procedures and processes where possible and this document was subject to pilot testing, Technical Council review and approval (on March 22, 2024 and April 26, 2024) and SBTi Board adoption (on March 28, 2024).

## Terminology

This document explains the criteria, which are requirements that FIs must follow, and recommendations, which FIs should follow, to align with the Financial Institutions' Near-Term Criteria. Unless otherwise stated (including specific sections), all criteria apply to scopes 1, 2 and 3.

This document uses precise language to indicate requirements, recommendations and allowable options that FIs may choose to follow.

- ● The terms ' shall ' and ' must ' and ' required ' are used throughout this document to indicate what is required for targets to conform with the Financial Institutions' Near-Term Criteria.
- ● The terms ' should ' and ' is encouraged ' and ' is recommended ' are used to indicate a recommendation, but not a requirement.
- ● The term ' may ' is used to indicate an option that is permissible or allowable.

The letter 'C' preceding a number indicates a criterion and the letter 'R' preceding a number indicates a recommendation.

## Effective dates of updated criteria

The Financial Institutions' Near-Term Criteria Version 2.0 will be in effect as of November 30, 2024. All submissions received by the SBTi prior to November 30, 2024 can be assessed against either Financial Institutions' Near-Term Criteria Version 1.1 or 2.0.

|

## 1. GHG EMISSIONS AND TARGET BOUNDARY

## Organizational Boundary

FI-C1 - Organizational Boundary: Parent companies must include the emissions of all subsidiaries in their target submission, in accordance with the boundary criteria outlined below. FIs should submit targets only at the parent or group level, not the subsidiary level. In cases where both parent companies and subsidiaries submit targets, 2 the parent company's target must also include the emissions of the subsidiary if it falls within the parent company's emissions boundary, given the chosen inventory consolidation approach. 3 Targets may be submitted at a subsidiary level if the subsidiary is a legal entity. Multiple subsidiaries within a group may submit targets but must do so separately, and their target language must explicitly state the specific target-setting entity.

FI-R1 - Setting Organizational Boundaries: The SBTi strongly recommends that an FI's organizational boundary, as defined by the GHGP, be consistent with the organizational boundary used in the FI's financial accounting and reporting procedures. FIs should use the same organizational boundary year-on-year.

## GHG / Scope / Emissions Coverage

FI-C2 - Greenhouse Gases (GHGs): Scope 1 and 2 targets must cover all relevant emissions of the seven GHGs required by the GHGP Corporate Standard. 4 If optional targets for scope 3, categories 1-14, are set, they shall also cover all relevant GHGs. Coverage of all relevant GHGs is recommended, where possible, for FIs' scope 3 portfolio targets. If FIs are unable to cover all GHGs for scope 3 portfolio targets, they shall cover carbon dioxide (CO2) emissions at a minimum, unless otherwise specified.

FI-C3 - Scopes: FIs must set targets that cover institution-wide scope 1 and scope 2 emissions, as defined by the GHGP Corporate Standard, and scope 3 investment and lending activities as defined in FI-C14 and FI-C15. FIs may set targets for remaining scope 3 emissions categories as specified in FI-R2.

FI-C4 - Scope 1 and 2 Allowable Exclusions: FIs must not exclude more than 5% of total combined scope 1 and scope 2 emissions from either the boundary of the GHG inventory or the target boundary. 5 Scope 3 target boundary requirements are outlined in FI-C14, FI-C15 and FI-R2.

## FI-R2 - Measuring Emissions and Setting Targets for Scope 3, Categories 1-14: The SBTi

3 For example, asset owners with asset management businesses that submit targets at the group level must include all assets owned or managed by group-owned asset managers in their submission. However, although the SBTi strongly recommends banks to cover their asset management businesses in their scope 1, 2, and 3 target boundaries, it is currently optional as an exception under this version of the criteria. If FIs make such an exclusion, they shall disclose it clearly in the target language (see Table 3). 2 Brands, licensees, and/or specific regions or business divisions (with the exception of banks' asset management businesses) of an FI will not be accepted as separate targets unless they fall outside of a parent company's chosen consolidation approach.

4 The seven GHGs are carbon dioxide (CO2), methane (CH4), nitrous oxide (N2O), hydrofluorocarbons (HFCs), perfluorocarbons (PFCs), sulfur hexafluoride (SF ) and nitrogen trifluoride (NF ). 6 3

5 This means that an FI must not exclude 5% from the inventory boundary and then also exclude a further 5% from the target boundary. Where FIs' scope 1 or 2 emissions are deemed immaterial (i.e., under 5% of total combined scope 1 and 2 emissions), FIs may set their SBT solely on the scope (either scope 1 or scope 2) that covers more than 95% of the total scope 1 and 2 emissions. FIs must continue to report on both scopes and adjust their targets as needed, in accordance with the GHGP's principle of completeness and following the FI-C21-Mandatory target recalculation.

|

recommends but does not require FIs to measure and set target(s) on scope 3, categories 1-14, emissions as defined by GHGP Corporate Value Chain (Scope 3) Accounting and Reporting Standard. When submitting scope 3, categories 1-14, targets for validation, FIs must include a complete emissions inventory following the minimum boundary for each scope 3 category in conformance with the GHGP Scope 3 Standard. Optional targets for these categories must also meet the scope 3 criteria in the latest SBTi criteria for corporates to be approved by the SBTi. For example,

- ● FIs must not exclude more than 5% of emissions from their total scope 3, categories 1-14, GHG inventory. 6
- ● Near-term emission reduction targets must cover a minimum of five years and a maximum of 10 years from the date the targets are submitted to the SBTi for an official validation.
- ● FIs must fulfill supplier or customer engagement targets within a maximum of five years from the date the targets are submitted to the SBTi for an official validation.

The SBTi recommends that FIs set targets for scope 3, categories 1-14, separately from scope 1 and 2 targets. Targets combining scopes (e.g., 1+2, or 1+2+3) are permitted if the SBTi can review the ambition of the individual target components and confirm each meets the relevant ambition criteria.

6 The SBTi does not recognize emissions perceived to be 'negligible' as a rationale for not reporting them. Even if emissions from certain activities or operations are perceived to be negligible, these emissions still must be quantified and reported in the reporting FI's GHG inventory. This is regardless of whether the reporting FI chooses to exclude them or not, as exclusions must also be quantified and reported.

## 2. METHOD AND EMISSIONS ACCOUNTING REQUIREMENTS

## Method Validity

FI-C5 - Method Validity: FIs must model targets using the latest version of methods and tools approved by the SBTi, subject to a six-month transition period. During this transition period, FIs may submit targets modeled using previous versions of the tools or methods to the SBTi for an official validation within six months of the publication of the revised method or relevant sector-specific tools. FIs will need to check the relevant SBTi sector webpages for the most up-to-date information.

## Emissions Accounting Requirements

FI-C6 - Scope 2 Accounting Approach: FIs shall disclose whether they are using a locationor market-based approach as per the GHGP Scope 2 Guidance to calculate base-year emissions and to track performance against a science-based target (SBT). The SBTi encourages FIs to measure and report scope 2 emissions using both approaches. However, FIs must use a single and consistent approach for setting and tracking progress toward an SBT. FIs that set renewable electricity procurement targets must select market-based accounting as the mechanism for setting and tracking progress toward their SBTs.

FI-C7 - Bioenergy Accounting: FIs shall report CO 2 emissions from the combustion, processing and distribution phase of bioenergy as well as the land use emissions and removals associated with bioenergy feedstocks alongside their GHG inventory. 7 Furthermore, they shall include these emissions in the target boundary when setting a science-based target (in scopes 1, 2 and/or 3, as relevant) and when reporting progress toward that target. 8

Land-related emissions accounting shall include CO2 emissions from direct land use change (LUC) and non-LUC emissions, inclusive of nitrous oxide (N O) and methane (CH4) 2 emissions from land use management. Including emissions associated with indirect LUC is optional.

FIs are expected to adhere to any additional GHGP Guidance on bioenergy accounting when released in order to maintain compliance with FI-C7.

FI-C8 - Carbon Credits: FIs must not count the use of carbon credits as emissions reductions toward the progress of their science-based targets. FIs may only consider carbon credits as an option to finance additional climate mitigation beyond their science-based emissions reduction targets.

FI-C9 - Avoided Emissions: Avoided emissions fall under a separate accounting system from FIs' inventories and do not count toward science-based emissions reduction targets.

7 FIs shall not account for negative emissions due to biogenic removals in their target formulation or as progress toward SBTs. In addition, the SBTi does not count removals not directly associated with bioenergy feedstock production as progress toward SBTs or toward net emissions in an FI's GHG inventory.

8 Please note that FIs that use/produce or have bioenergy within their value chain or intend to account for bioenergy as a decarbonization lever over the lifetime of their target must include the following bioenergy footnote in their target language: 'The target boundary includes land-related emissions and removals from bioenergy feedstocks.'

FI-R3 - Forest, Land and Agriculture (FLAG) Emissions: The SBTi recommends that FIs which finance companies with FLAG related emissions totaling 20% or more of overall emissions across scopes to set a Portfolio Coverage target for those companies. These companies would then be required to set a separate FLAG target to account for their FLAG-related emissions (gross biogenic land CO2 emissions and removals). The FLAG target includes all emissions from direct LUC and land management (biogenic CO2, N2 O and CH4).

Companies shall calculate their FLAG base-year emissions (in tons of carbon dioxide equivalent, or tCO e) in line with the forthcoming GHGP Land Sector and Removals 2 Guidance. SBTi FLAG Target-Setting Guidance and FLAG Target-Setting Methods Addendum are also available. 9

FI-R4 - Biofuel Certification and Bioenergy Data Reporting: The SBTi recommends that FIs using or producing biofuel(s) for transport support their bioenergy GHG accounting with recognized biofuel certification(s) to disclose that the data on land-related emissions and removals represent the relevant biofuel feedstock production.

The SBTi recommends that companies report direct biogenic CO2 emissions and removals from bioenergy separately. Companies shall report emissions and removals of CO2 associated with bioenergy as net emissions according to FI-C7, at a minimum, but the SBTi encourages them to also report gross emissions and gross removals from bioenergy feedstocks.

9 The SBTi is managing a sector development project, the SBTi Forest, Land and Agriculture project ('SBTi FLAG'), to address the FLAG methodology. This effort focuses on the development of methods and guidance to enable the food, agriculture, and forest sectors to set science-based targets that include deforestation, and possibly other land-related impacts. In parallel to this effort, World Resources Institute (WRI) and the World Business Council for Sustainable Development (WBCSD) are leading the development of three new GHGP Standards on how companies should account for GHG emissions and removals in their annual inventories. The three standards will cover Carbon Removals and Sequestration, Land Sector Emissions and Removals, and Bioenergy. For more information on this work and how to participate, see here. The FLAG project and the new GHGP Standards are complementary workstreams that will provide the infrastructure needed for corporate target setting, accounting, and reporting of emissions related to agriculture, forestry and other land use.

## 3. SCOPE 1 AND 2 TARGETS

## Time Frame

FI-C10 - Base and Target Years: Scope 1 and 2 targets must cover a minimum of five years and a maximum of 10 years from the date the targets are submitted to the SBTi for an official validation. 10 The choice of base year shall be representative of the FI's activities and shall be no earlier than 2015. Scope 1 and scope 2 targets must use the same base year. 11

FI-C11 - Progress to Date: Targets that have already been achieved by the date they are submitted to the SBTi are not acceptable. The SBTi uses the year the target is submitted to the initiative or the most recent year 12 to assess forward-looking ambition. FIs must provide all the relevant GHG inventory data, including a most-recent-year GHG inventory, which must not be from earlier than two years prior to the year of submission. 13

FI-R5 - Base Year: The SBTi recommends choosing the most recent year as the base year.

FI-R6 - Long-Term Targets: Targets that cover more than 10 years from the date of submission are considered long-term targets. The SBTi will only validate long-term targets for FIs in accordance with the SBTi FI Net-Zero Standard upon its publication.

FI-R7 - Consistency: The SBTi recommends that FIs use the same base years for all scope 1, 2 and 3 near-term targets.

## Ambition

FI-C12 - Level of Ambition: At a minimum, scope 1 and scope 2 absolute emissions reduction targets will be consistent with the level of decarbonization required to keep global temperature increase to 1.5 degrees Celsius (°C) compared with preindustrial temperatures. Both the target time frame ambition level (base year to target year) and the forward-looking ambition level (most recent year to target year) must meet this ambition criterion. 14 Intensity targets for scope 1 and scope 2 emissions are eligible only when they are modeled using an approved 1.5°C sector pathway applicable to companies' business activities (e.g., scope 2 target using the Power Generation Sectoral Decarbonization Approach pathway).

FI-R8 - Choosing an Approach: The SBTi recommends using the most ambitious decarbonization scenarios that lead to the earliest reductions and the least cumulative emissions.

10 For targets submitted for an official validation in the first half of 2024, the valid target years are 2028-2033 inclusive. For targets submitted in the second half of 2024, the valid target years are between 2029 and 2034 inclusive.

11 Scope 3 targets are recommended but not required to use the same base year as scope 1 and scope 2 targets.

12 The most recent year used for scope 1 and scope 2 emissions must be the same year. The most recent year used for scope 3 emissions is recommended to be the same year as scope 1 and scope 2.

13 For targets submitted for an official validation in 2024, the most recent inventory must be from no earlier than 2022 (i.e., the allowable most recent years are 2022 and 2023).

14 For example, using the cross-sector absolute reduction method, the minimum ambition of near-term scope 1 and 2 targets is a 4.2% linear annual reduction between the base year and target year plus an adjustment for base years later than 2020. Also, for companies using a base year earlier than the most recent year, scope 1 and/or scope 2 targets must also have sufficient forward-looking ambition.

## 4. SCOPE 2

FI-C13 - Renewable Electricity Procurement Targets: Targets to actively source renewable electricity at a rate that is consistent with 1.5°C scenarios are an acceptable alternative to scope 2 emissions reduction targets. The SBTi has identified 80% renewable electricity procurement by 2025 and 100% by 2030 as thresholds (portion of renewable electricity over total electricity use) for this approach in line with the recommendations of the RE100 initiative. Please consult the RE100 Technical Criteria and the Scope 2 Quality Criteria in the GHGP Scope 2 Guidance for options for actively sourcing renewable electricity.

FIs that already source electricity at or above these thresholds shall maintain or increase their use share of renewable electricity to qualify. FIs that have zero scope 1 emissions and will cover scope 2 emissions with a renewable electricity procurement target shall also set a target to maintain zero scope 1 emissions.

FI-R9 - Purchased Heat and Steam: When modeling targets using the Sectoral Decarbonization Approach, FIs should model purchased heat and steam-related emissions as if they were part of their direct (i.e., scope 1) emissions.

FI-R10 - Efficiency Considerations for Target Modeling: If FIs are using a method that does not already embed efficiency gains for the specific sector or market - and the decarbonization projected for the power sector is based on a 1.5°C scenario - these factors should be considered when modeling electricity-related scope 2 targets.

|

## 5. SCOPE 3 PORTFOLIO TARGET-SETTING REQUIREMENTS

FI-C14 - Requirement to Set Target(s) on Investment and Lending Activities: All FIs shall set targets for their investment and lending activities as required by FI-C15, irrespective of the share of quantified scope 3 portfolio emissions as compared to the FI's total scope 1, 2 and 3 emissions. FIs may choose from the applicable methods for target setting, by asset class, as defined in Table 1.

FI-C15 - Portfolio Target Boundary: FIs are required to set one or more near-term targets for relevant activities in their portfolios according to Figure A-1, Table 1 and the following provisions: 15

- ● Relevant Activities: FIs shall determine relevant activities based on either financed emissions 16 or on an appropriate financial asset metric (such as loan value, invested value and/or assets under management). The selected approach must be consistently applied in determining the 67% minimum coverage requirement 17 and when considering the 5% materiality exclusion.
- ● Minimum Coverage: FIs must ensure that their targets collectively cover at least 67% of their Portfolio Target Boundary (PTB).

To calculate the minimum coverage, the denominator shall include the following:

- o All 'Required Activities' in Table 1.
- o All 'Optional Activities' in Table 1, subject to the following exclusion:
- ▪ Any 'Optional Activities' within the asset/investment/wealth management (AIWM) and consumer loan asset classes that make up less than 40% of all 'Required Activities' and 'Optional Activities' may be excluded from the PTB denominator.

To calculate the minimum coverage, the numerator shall include all 'Required Activities' and/or 'Optional Activities' that are covered by targets. FIs may set targets using any of the available methods specified in Table 1.

- ● Required Activities: FIs must ensure that their targets cover all 'Required Activities'

15 Although the SBTi strongly recommends banks (i.e., an FI with a banking license and a banking business that makes up a majority of its revenues) to cover their asset management businesses in their scope 1, 2 and 3 target boundaries, it is currently optional and may be excluded from the Portfolio Target Boundary coverage requirements as an exception under this version of the criteria. If such an exclusion is made, it shall be disclosed clearly in the target language (see Table 3). In situations where ambiguity arises regarding the applicable minimum coverage requirement for a specific activity, including its sector/market specifications, the more stringent criteria will prevail.

16 If using financed emissions, a complete inventory must be disclosed for all 'Required Activities' and 'Optional Activities' in Table 1 that must include at least the scope 1 + 2 + 3 emissions of activities in the automotive and fossil fuel sectors and scope 1 + 2 emissions of activities in all other sectors. The SBTi strongly recommends, however, that FIs include the scope 1 + 2 + 3 emissions of activities in all sectors. Emissions estimates are acceptable, with the expectation that data quality will improve over time. The SBTi requires comprehensive and transparent disclosure of the methodology used to measure emissions and recommends the disclosure of data quality. The SBTi has identified the Global GHG Accounting and Reporting Standard for the Financial Industry by the Partnership for Carbon Accounting Financials as a freely available approach to measure portfolio-wide or asset-level financed emissions. See the Financial Sector Near-Term SBT Explanatory Document for more details on measuring financed emissions to facilitate target setting.

17 This requirement is separate from the 67% minimum coverage requirement for the corporate loan asset class.

subject to the below 5% materiality exclusion option.

- ● Exclusion of Non-Material Activities: FIs may exclude specific sub-asset classes categorized under 'Required Activities' from their targets, provided these sub-asset classes constitute less than 5% of the Portfolio Target Boundary. Exclusions must apply to entire sub-asset classes uniformly and may not exempt any activities related to fossil fuels.
- ● Asset/Investment/Wealth Management: The AIWM asset class applies to situations where FIs are managing investment funds on the behalf of third parties. Assets that are owned by an FI but managed by third-party asset managers are considered the FI's own investments and not AIWM. For the purposes of target validation, FIs shall define and disclose the types of asset management businesses they are involved with, which must align with the following categories:
- ○ Discretionary mandates apply to situations where the FI is granted discretion by the third party to make investment decisions (e.g., fund, index or security selection) without seeking prior approval from that third party.
- ○ Advisory mandates apply to situations where the FI provides recommendations and makes investments on behalf of the third party that are subject to that third party's instructions or approval.
- ■ This includes situations where the FI selects funds for third parties to choose from but thereafter has no control over investment decisions (e.g., fund, index or security selection).
- ○ Execution-only mandates apply to situations where the FI only executes investment instructions and has no control over investment decisions.

Table 1. Required Coverage in Portfolio Target Setting for Financial Institutions

Legend

Required Activities

Optional Activities

Out of Scope

| Asset Class a                                   | Sub-Asset Class        | Sector / Market Specifications            | Minimum Coverage Requirement   | Applicable Methods b         |
|-------------------------------------------------|------------------------|-------------------------------------------|--------------------------------|------------------------------|
| Asset / Investment / Wealth management (AIWM) c | Discretionary mandates | Underlying assets are Required Activities | See respective asset classes   | See respective asset classes |
| Asset / Investment / Wealth management (AIWM) c | Discretionary mandates | Underlying assets are Optional Activities | Optional                       | See respective asset classes |
| Asset / Investment / Wealth management (AIWM) c | Discretionary mandates | Underlying assets are Out of Scope        | n/a                            | n/a                          |

May 2024 | 15

|                  | Advisory mandates                                                | Underlying assets are Required or Optional Activities                  | Optional                                                                                                                                                                                                                       | See respective asset classes   |
|------------------|------------------------------------------------------------------|------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------|
|                  | Advisory mandates                                                | Underlying assets are Out of Scope                                     | n/a                                                                                                                                                                                                                            | n/a                            |
|                  | Execution-only mandates (brokerage services)                     | Underlying assets are Required or Optional Activities, or Out of Scope | n/a                                                                                                                                                                                                                            | n/a                            |
|                  | Assets under custody (custody services)                          | Underlying asset is Required, Optional or Out of Scope                 | n/a                                                                                                                                                                                                                            | n/a                            |
| Consumer loan    | Residential mortgages                                            | Residential mortgages                                                  | Optional                                                                                                                                                                                                                       | SDA                            |
|                  | Motor vehicle loans                                              | Motor vehicle loans                                                    | n/a                                                                                                                                                                                                                            | n/a                            |
|                  | Other consumer loans                                             | Other consumer loans                                                   | n/a                                                                                                                                                                                                                            | n/a                            |
| Project finance  | Electricity generation project finance (direct and/or via funds) | Electricity generation project finance (direct and/or via funds)       | 100% of base-year activity (MWh)                                                                                                                                                                                               | SDA                            |
| Project finance  | Fossil fuel project finance (direct and/or via funds)            | Fossil fuel project finance (direct and/or via funds)                  | 100% of base-year financed emissions                                                                                                                                                                                           | SDA / FFF d                    |
| Project finance  | Real estate project finance (direct and/or via funds)            | Real estate project finance (direct and/or via funds)                  | Optional                                                                                                                                                                                                                       | SDA e                          |
| Project finance  | Other project finance (e.g., infrastructure projects/assets)     | Other project finance (e.g., infrastructure projects/assets)           | n/a                                                                                                                                                                                                                            | n/a                            |
| Corporate loan f | Long-term (more than one year) corporate g loans                 | Electricity generation (listed and private companies)                  | 100% of base-year activity (MWH) or financed emissions                                                                                                                                                                         | SDA / PC / TR                  |
| Corporate loan f | Long-term (more than one year) corporate g loans                 | Fossil fuel (listed and private companies)                             | 100% of base-year loan value or financed emissions                                                                                                                                                                             | SDA / PC / TR / FFF d          |
| Corporate loan f |                                                                  | All other sectors (listed companies)                                   | 100% within target boundary of any PC and/or TR target(s) AND 67% of base-year loan value or financed emissions across all SDA, PC, TR target(s), to be calculated across any mix of required and optional corporate loans and | SDA / PC / TR                  |

|                       |                                                                                                 |                                                                                                 | commercial real estate asset loans h               |                       |
|-----------------------|-------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------|----------------------------------------------------|-----------------------|
|                       |                                                                                                 | All other sectors (private companies)                                                           | Optional                                           | SDA / PC / TR         |
|                       | Short-term corporate g loans (one year or less, such as line of credit, intraday, and overdraft | Fossil fuel (listed and private companies)                                                      | 100% of base-year loan value or financed emissions | SDA / PC / TR / FFF d |
|                       | facilities)                                                                                     | Electricity generation and all other sectors (listed and private companies)                     | Optional                                           | SDA / PC / TR         |
|                       | Long- and short-term small- and medium-sized enterprise (SME) i loans                           | Fossil fuel (listed and private companies)                                                      | 100% of base-year loan value or financed emissions | SDA / PC / TR / FFF d |
|                       |                                                                                                 | Per SBTi definition or national/regional regulatory definition                                  | Optional                                           | SDA / PC / TR         |
|                       | Supranational, sovereign, sub-sovereign (including municipal), government and government agency | Supranational, sovereign, sub-sovereign (including municipal), government and government agency | n/a                                                | n/a                   |
|                       | Common and preferred stock of corporates g and SMEs i and private equity (direct holdings and   | Electricity generation and fossil fuel (listed and private companies)                           | 100%                                               | SDA / PC / TR / FFF d |
|                       |                                                                                                 | All other sectors (listed companies)                                                            | 100%                                               | SDA / PC / TR         |
|                       | co-investments)                                                                                 | All other sectors (private companies)                                                           | Per SBTi Private Equity Guidance l                 | SDA / PC / TR         |
| Equity k (investment) | via Funds (invested in assets, e.g., exchange                                                   | Electricity generation and fossil fuel (listed and private companies)                           | 100%                                               | SDA / PC / TR / FFF d |
| Equity k (investment) | traded funds,                                                                                   | All other sectors (listed companies)                                                            | 100%                                               | SDA / PC / TR         |
| Equity k (investment) | mutual funds, hedge funds, other collective                                                     | All other sectors (private companies)                                                           | Optional                                           | SDA / PC / TR         |
| Equity k (investment) | investment schemes)                                                                             | with non-transparent strategy m                                                                 | n/a                                                | n/a                   |
| Equity k (investment) | via Fund of Funds (funds invested in funds)                                                     | via Fund of Funds (funds invested in funds)                                                     | Optional                                           | SDA / PC / TR         |

|                               | Corporate g and SME i bonds and private debt (direct holdings and co-investments)                                                      | Electricity generation and fossil fuel (listed and private companies)                                                                  | 100%                                                                                                          | SDA / PC / TR / FFF d          |
|-------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------|--------------------------------|
|                               | Corporate g and SME i bonds and private debt (direct holdings and co-investments)                                                      | All other sectors (listed companies)                                                                                                   | 100%                                                                                                          | SDA / PC / TR                  |
|                               | Corporate g and SME i bonds and private debt (direct holdings and co-investments)                                                      | All other sectors (private companies)                                                                                                  | Optional                                                                                                      | SDA / PC / TR                  |
|                               | via Funds (invested in assets, e.g., exchange traded funds,                                                                            | Electricity generation and fossil fuel (listed and private companies)                                                                  | 100%                                                                                                          | SDA / PC / TR / FFF d          |
| Fixed income k,n (investment) | mutual funds,                                                                                                                          | All other sectors (listed companies)                                                                                                   | 100%                                                                                                          | SDA / PC / TR                  |
| Fixed income k,n (investment) | hedge funds, other collective                                                                                                          | All other sectors (private companies)                                                                                                  | Optional                                                                                                      | SDA / PC / TR                  |
| Fixed income k,n (investment) | investment schemes)                                                                                                                    | with non-transparent strategy m                                                                                                        | n/a                                                                                                           | n/a                            |
| Fixed income k,n (investment) | via Fund of Funds (funds invested in funds)                                                                                            | via Fund of Funds (funds invested in funds)                                                                                            | Optional                                                                                                      | SDA / PC / TR                  |
| Fixed income k,n (investment) | Securitized fixed income, including asset-backed securities, mortgage-backed securities, covered bonds (direct holdings or via funds)  | Securitized fixed income, including asset-backed securities, mortgage-backed securities, covered bonds (direct holdings or via funds)  | Optional (if a method is available for the underlying assets, such as for real estate assets) or out of scope | SDA                            |
| Fixed income k,n (investment) | Supranational, sovereign, sub-sovereign (including municipal), government and government agency bonds (direct holdings or via funds) j | Supranational, sovereign, sub-sovereign (including municipal), government and government agency bonds (direct holdings or via funds) j | n/a                                                                                                           | n/a                            |
|                               | Consumer loans: residential mortgages                                                                                                  | Consumer loans: residential mortgages                                                                                                  | Optional                                                                                                      | SDA                            |
|                               | Real estate project finance (construction)                                                                                             | Real estate project finance (construction)                                                                                             | Optional                                                                                                      | SDA e                          |
|                               | General purpose loans to real estate companies                                                                                         | General purpose loans to real estate companies                                                                                         | See corporate loan asset class                                                                                | See corporate loan asset class |
| Real estate o                 | Long-term (more than one year) commercial real estate asset loans (residential and service buildings) p                                | Long-term (more than one year) commercial real estate asset loans (residential and service buildings) p                                | 67% of base-year activity (m 2 ) or financed emissions                                                        | SDA                            |
| Real estate o                 | Short-term (one year or less) commercial real estate asset loans p                                                                     | Short-term (one year or less) commercial real estate asset loans p                                                                     | Optional                                                                                                      | SDA                            |
| Real estate o                 | Direct investment in real estate assets (for own use or investment purposes, if not already covered by scope 1 + 2 and/or scope 3      | Direct investment in real estate assets (for own use or investment purposes, if not already covered by scope 1 + 2 and/or scope 3      | 67% of base-year activity (m 2 ) or financed emissions                                                        | SDA                            |

| categories 1-14 targets)                                                                    | categories 1-14 targets)                                                                    |                                                        |                              |
|---------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------|--------------------------------------------------------|------------------------------|
| Equity and fixed-income (investment in real estate companies)                               | Equity and fixed-income (investment in real estate companies)                               | See respective asset classes                           | See respective asset classes |
| Investment in real estate funds (listed and private)                                        | REITs and real estate companies (listed)                                                    | 100%                                                   | SDA / PC / TR                |
| Investment in real estate funds (listed and private)                                        | Real estate assets                                                                          | 67% of base-year activity (m 2 ) or financed emissions | SDA                          |
| Investment in real estate funds (listed and private)                                        | REITs and real estate companies (private)                                                   | Optional                                               | SDA / PC / TR                |
| Cash and cash equivalents r                                                                 | Cash and cash equivalents r                                                                 | n/a                                                    | n/a                          |
| Derivatives                                                                                 | Derivatives                                                                                 | n/a                                                    | n/a                          |
| Debt and equity securities underwriting, advisory services (e.g., mergers and acquisitions) | Debt and equity securities underwriting, advisory services (e.g., mergers and acquisitions) | n/a                                                    | n/a                          |
| Commodities trading                                                                         | Commodities trading                                                                         | n/a                                                    | n/a                          |
| Insurance underwriting, reinsurance, credit guarantees                                      | Insurance underwriting, reinsurance, credit guarantees                                      | n/a                                                    | n/a                          |

## Notes :

- a Asset finance falls under scope 3, categories 1-14 emissions. Separately, Islamic financing shall be categorized in the asset class listed in Table 1 that is closest in accounting nature (e.g., sukuk as fixed income).
- b SDA = SBTi Sectoral Decarbonization Approach or sector-specific guidance; PC = SBT Portfolio Coverage; TR
- = Temperature Rating; FFF = SBTi Fossil Fuel Finance Targets.
- c Although the SBTi strongly recommends that banks (i.e., FIs with a banking license and a banking business that makes up a majority of their revenues) cover their asset management businesses in their scope 1, 2 and 3 target boundaries, it is currently optional and may be excluded from the Portfolio Target Boundary coverage

requirements as an exception under this version of the criteria. If such an exclusion is made, it shall be disclosed clearly in the target language (see Table 3). In terms of minimum coverage requirements for FIs that do cover

their asset management business, if an FI manages or administers assets under discretionary (which is required)

and advisory (optional) mandates that all fall within the Portfolio Target Boundary and are each invested in corporate bonds (required), private debt (optional) and sovereign bonds (out of scope), then only the corporate

bonds under discretionary mandates are required to be covered by targets, while the private debt under discretionary and advisory mandates and corporate bonds under advisory mandates are optional (but still subject

to the 67% Portfolio Target Boundary coverage requirement). Meanwhile, all assets under execution-only mandates are out of scope, whether they are invested in corporate bonds, private debt or sovereign bonds.

- d FIs required to set targets for the fossil fuel sector according to the coverage requirements outlined in Table 1 in FI-C17.4. The SDA method is expected to be available upon the publication of the SBTi Oil and Gas Sector
- may set such targets using any of the available methods specified in Table 1 or use the requirements described Guidance.
- e Please refer to the forthcoming Buildings Sector Guidance for embodied emissions targets.
- f FIs may select the loan outstanding amount, loan commitment amount or exposure at default as the numerator of the attribution factor used to calculate financed emissions for corporate loans. However, FIs must apply this consistently (i.e., they may not switch) during the target period.
- g For the purposes of Table 1, 'corporate' includes FIs. For example, corporate bonds include bonds issued by FIs.
- h For example, if an FI decides to set a target to reach 50% SBT portfolio coverage on its corporate loans, then it must target half of all of its borrowers having SBTi-validated targets, and not half of 67% of its borrowers having SBTi-validated targets, since data (whether a borrower has or doesn't have an SBTi-validated target in this case) is not an issue. If SDA targets as well as PC and/or TR targets are set for corporate loans, then the PC and/or TR targets must have 100% coverage within their target boundaries, and all of the SDA, PC and/or TR targets combined must meet the 67% minimum coverage requirement. For example, if an FI had $25 of loans in total and

covered 50% of its $10 in corporate loans to 'all other sectors' with SDA targets and 100% of its $15 in SME loans with a PC target, then the FI may be considered to have met the 67% minimum coverage requirement [((50% * $10) + (100% * $15)) / ($10 + $15) = 80%]. If using financed emissions to calculate target coverage, the scope 1 + 2 + 3 emissions of portfolio companies in the automotive and fossil fuel sectors shall be included in the calculation while the scope 1 + 2 emissions of portfolio companies in 'all other sectors' shall be included. The SBTi, however, strongly recommends that FIs include the scope 1 + 2 + 3 emissions of portfolio companies in all sectors and go beyond the minimum coverage requirements.

- i As the definition of small- and medium-sized enterprises (SMEs) may vary from region to region, FIs shall use either the SBTi definition or the relevant national or regional regulatory definition(s) to determine the applicable coverage requirements in Table 1. For target validation, companies may set targets through the streamlined validation route if they meet the SBTi definition of an SME or they may choose to set targets through the standard validation route. For more information on the SBTi's definition and target-setting option for SMEs, please see our FAQ regarding the SME target-setting route.
- j The SBTi does not currently validate targets for cities, local governments, public sector institutions, educational institutions or non-profit organizations. However, government ownership does not necessarily mean that an entity is a public sector institution. If an entity's primary objective is to fulfill public needs and interests (over profit motives), then it should be considered a public sector institution. If an entity operates in a commercial market or has a commercial orientation and aims to generate profits while providing services, then it should be considered for target validation.
- k The coverage requirements for equity- and fixed-income investments apply to all securities in the banking book while securities in the trading book are optional and assets that have already been sold are out of scope.
- l All FIs shall cover their private equity investments based on the requirements provided in the SBTi Private Equity Sector Science-Based Target Guidance. Note that targets are currently required only for a private equity investment if the FI has a board seat in the portfolio company, among other conditions.
- m This optionality is restricted to cases where the disclosure of underlying holdings negates the investment strategy (e.g., some hedge funds).
- n Fixed-income investments include convertible bonds and other hybrid instruments.
- o Real estate assets with no operational emissions are out of scope.
- p Commercial real estate asset loans refer to all loans for the purchase, refinance, maintenance or operation of real estate assets (i.e., residential and service buildings) that are not provided to consumers. General purpose loans to real estate investment trusts (REITs) or real estate companies may be included under 'all other sectors' of corporate loans.
- q Emissions accounting and target-setting methods are necessary before out-of-scope activities may become in scope. The potential addition of new asset classes may be explored under the SBTi FI Net-Zero Standard.
- r Cash equivalents may include commercial paper, certificates of deposit, time deposits, banker's acceptance and short-term repurchase agreements.

Source : Authors 2024.

FI-C16 - Base Year and Progress to Date: The choice of base year shall be representative of the FI's activities and shall be no earlier than 2015. Targets that have already been achieved by the date they are submitted to the SBTi are not acceptable. The SBTi uses the year the target is submitted to the initiative (or the most recent data) to assess forward-looking ambition. The most recent data must not be from earlier than two years prior to the year of submission.

FI-C17.1 - Sectoral Decarbonization Approach Targets: 18 FIs' targets using the SDA are considered acceptable when the following conditions are met:

- ● Boundary: FIs shall set SDA targets for their real estate assets as well as electricity generation project finance as specified in Table 1. SDA targets may also be set for other activities listed in Table 1, such as residential mortgages, corporate loans, listed and private equity and debt for sectors for which SBTi sector-specific guidance is

18 The Sectoral Decarbonization Approach (SDA) is a method for setting physical intensity targets that uses convergence of emissions intensity. An intensity target is defined by a reduction in emissions relative to a specific business metric, such as production output of the company (e.g., metric ton CO e per ton product produced). Please see the Financial Sector Near-Term 2 SBT Explanatory Document for more information on the SDA.

May 2024 | 20

available.

- ● Ambition: Portfolio SDA targets must meet the minimum ambition level indicated by sector-specific methods for 1.5°C pathways. When a 1.5°C pathway for a sector is not available, a well-below-2°C pathway may be used instead. FIs may use any 1.5°C-aligned climate scenarios as long as their physical intensity targets are of equal or greater ambition than the minimum target ambition level required by the relevant SBTi tool.

FIs that already finance only renewable electricity projects (which may also include projects and assets such as energy storage and other directly related energy infrastructure) in the base year may set targets to continue doing so through 2030.

Separately, FIs that meet all the following conditions may set an emissions intensity maintenance target up to 2030 for an electricity generation project finance portfolio:

- i. A portfolio emissions intensity that is at or below the 2030 sector intensity level in a 1.5°C-aligned pathway for the power sector (100 gCO e/kWh). ₂
- ii. At least 80% renewable or other zero-emission electricity generation project financing.
- iii. A commitment to maintain the base-year portfolio emissions intensity through 2030 and finance only 1.5°C-aligned electricity generation projects,
- o where 1.5°C-aligned financing for the power sector is defined as a commitment to finance only new capacity from zero-emission sources and/or additional exposure to existing capacity if the infrastructure has an emissions reduction plan consistent with limiting warming to 1.5°C with no or limited overshoot.

FIs that meet the following conditions may set an emissions intensity maintenance target up to 2030 for an investment or lending portfolio of real estate assets:

- i. A portfolio emissions intensity that is at or below the 2030 sector intensity level in a 1.5°C-aligned pathway for the real estate sector (based on SBTi sector-specific guidance).
- ii. A commitment to maintain the base-year portfolio emissions intensity through 2030 and finance only 1.5°C-aligned real estate assets,
- o where 1.5°C-aligned financing for the real estate sector is defined as a commitment to finance only new developments that are zero-carbon-ready (i.e., highest energy efficiency class based on local rating schemes and uses either renewable energy directly or an energy supply that will be fully decarbonized by 2050, such as electricity or district heat) and/or existing developments if they have an emissions reduction plan consistent with limiting warming to 1.5°C with no or limited overshoot.
- ● Time Frame: Portfolio SDA targets must cover a minimum of five years and a maximum of 10 years from the date the targets are submitted to the SBTi for an official validation. 19 The SBTi recommends that the same base year be used for all SDA

19 For example, for targets submitted for an official validation in the first half of 2024, the valid target years are 2028-2033 inclusive. For targets submitted in the second half of 2024, the valid target years are between 2029 and 2034 inclusive.

May 2024 | 21

targets and that the most recent year be used as the base year. The SBTi encourages FIs to develop additional long-term targets in accordance with the SBTi FI Net-Zero Standard upon its publication.

- ● Scope of Borrower and/or Investee Emissions: FIs shall set targets for emissions scopes as required by the relevant SBTi sector-specific guidance. 20

FI-C17.2 - SBT Portfolio Coverage Targets: FIs' targets to drive the adoption of science-based emissions reduction targets by their borrowers and/or investees are considered acceptable when the following conditions are met:

- ● Boundary: FIs shall set engagement targets for activities as specified in Table 1.
- ● Ambition: FIs shall commit to having a portion of their borrowers and/or investees set their own SBTi-validated science-based targets such that they are on a linear path to 100% portfolio coverage by 2040 (using a weighting approach). 21 Fulfillment of portfolio coverage targets means that the SBTi has approved the borrowers' and/or investees' SBTs.
- ● Weighting Approach: FIs shall use one of the weighting approaches in the SBTi Finance Tool (listed in Appendix D of the Financial Sector Near-Term SBT Explanatory Document) consistently throughout the target period. As the Portfolio Coverage (PC) method is binary, FIs may replace the outcome from the Temperature Rating method for the companies (i.e., TS in the formula) with the outcome of the PC assessment: 1 if the company has an SBTi-approved target or 0 if the company does not have an SBTi-approved target. This means that FIs may use the same weighting methods for both Temperature Rating and Portfolio Coverage; they must simply replace TS with PC in the formula.
- ● Time Frame: The target year of FIs' Portfolio Coverage targets must be any year up to 2030 inclusive or within a maximum of five years from the date the targets are submitted to the SBTi for an official validation. 22 FIs may also set a second, longer-term 100% Portfolio Coverage target but only if it is in addition to one that meets the aforementioned time frame. The same base year shall be used for all Portfolio Coverage targets, and the SBTi recommends choosing the most recent year as the base year.
- ● Scope of Borrower and/or Investee Emissions: FIs' borrowers and/or investees shall follow the latest SBTi criteria required for companies as of the date of their target submission in order to set science-based targets. For example, near-term targets for corporates must cover at least 67% of scope 3 emissions when their scope 3 emissions are more than 40% of their total scope 1, 2 and 3 emissions.

20 A list of the sector-specific guidance and requirements is available in the SBTi Criteria Assessment Indicators.

21 For example, an FI starting with 10% coverage in 2020 would need to increase coverage by 4.5% per year ((100% - 10%) / (2040 - 2020)) and reach at least 32.5% (10% + [(2025 - 2020) x 4.5%]) coverage by 2025.

22 For example, for targets submitted for an official validation in the first half of 2026, the valid target years are up to 2030 inclusive. For targets submitted in the second half of 2026, the valid target years are up to 2031 inclusive.

FI-C17.3 - Portfolio Temperature Rating Targets: FIs' targets to align the Temperature Rating of their portfolios with the temperature goals set out in the Paris Agreement are considered acceptable when the following conditions are met:

- ● Boundary: FIs shall set portfolio Temperature Rating targets for activities as specified in Table 1.
- ● Ambition: FIs shall align their portfolio scope 1 and 2 temperature scores with a minimum 1.5°C scenario and in addition align their portfolio scope 1, 2 and 3 temperature scores with a minimum well-below-2°C scenario by 2040. Alignment with more ambitious scenarios such as 1.5°C across all scopes is highly encouraged. FIs shall commit to reducing their portfolio temperature scores such that they are on a linear path to the stated goal by 2040. 23 FIs shall set separate targets for scopes 1 and 2 and for scopes 1, 2 and 3.
- ● Methodology: FIs shall calculate company-specific temperature scores and portfolio temperature alignment levels according to the published temperature rating methodology used by the SBTi. Temperature scores may be calculated using the SBTi open-source tool or other third-party temperature scores produced according to this method. 24
- ● Data Consistency: FIs shall use the same source of temperature scores consistently throughout the target period or re-baseline if the source of temperature scores changes during the target period.
- ● Weighting Approach: FIs shall use one of the weighting approaches in the SBTi Finance Tool (listed in Appendix D of the Financial Sector Near-Term SBT Explanatory Document) consistently throughout the target period.
- ● Time Frame: The target year of FIs' Portfolio Temperature Rating targets must be any year up to 2030 inclusive or within a maximum of five years from the date the targets are submitted to the SBTi for an official validation. 25 The same base year shall be used for all Temperature Rating targets, and the SBTi recommends choosing the most recent year as the base year. The SBTi encourages FIs to develop long-term targets in accordance with the SBTi FI Net-Zero Standard upon its publication.
- ● Scope of Borrower and/or Investee Emissions: Temperature scores are calculated for

23 For example, an FI setting a Temperature Rating target with a base year of 2021, target year of 2027, starting portfolio scope 1 + 2 temperature score of 2.8°C, starting portfolio scope 1 + 2 + 3 temperature score of 3.0°C, and a temperature alignment goal of 1.5°C for both scope 1 + 2 and scope 1 + 2 + 3 would need to reach at least a ~2.38°C portfolio scope 1 + 2 temperature score [2.8°C - (2.8°C - 1.5°C) / (2040 - 2021) * (2027 - 2021)] and a ~2.52°C portfolio scope 1 + 2 + 3 temperature score [3.0°C - (3.0°C - 1.5°C) / (2040 - 2021) * (2027 - 2021)] by 2027.

24 For the purposes of target validation, FIs must provide the following information when submitting targets for an official validation: (1) the data provider and tool used (e.g., SBTi tool using data from [provider name], or temperature scores from [provider name]), and a link to public documentation stating the score provider's application of the published temperature rating methodology; and (2) the published Intergovernmental Panel on Climate Change (IPCC) 1.5°C scenario data used; and (3) the weighting approach used to generate a portfolio-level temperature rating; and (4) the percentage of portfolio GHG emissions and/or portfolio value that is covered by public targets and the percentage of portfolio GHG emissions and/or portfolio value that is assessed using default scores in the reporting year. Stakeholders are advised to check the SBTi Financial Institutions webpage for the most recent documentation and tool.

25 For example, for targets submitted for an official validation in the first half of 2026, the valid target years are up to 2030 inclusive. For targets submitted in the second half of 2026, the valid target years are up to 2031 inclusive.

FIs' borrowers' and/or investee's scope 1 and 2 and scope 1, 2 and 3 emissions, for both of which FIs must set separate targets. The temperature score of the portfolio company's parent company may be used if temperature scores are not available for the portfolio company.

FI-C17.4 - Fossil Fuel Finance Targets: FIs that are required to set targets for the fossil fuel sector may set such targets using any of the available methods specified in Table 1 or use the requirements described in this section.

Table 2. Fossil Fuel Finance Targets Definitions and Scope

|                                                                                                                                                                                                                                                                                                                                                                                                                    | Disclose                                                                                                                                                                                                                                                                                                                                                                                                           | Halt                                                                                                                                                                                                                                                                                                                                                                                                               | Transition                                                                                                                                                                                                                                                                                                                                                                                                         | Phaseout                                                                                                                                                                                                                                                                                                                                                                                                           |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Coal Company                                                                                                                                                                                                                                                                                                                                                                                                       | ● Companies listed in Global Coal Exit List (GCEL); or ● Companies with >10% of revenue from coal value chain; or ● Both of the above ●                                                                                                                                                                                                                                                                            | ● Companies listed in GCEL with expansion plans (per GCEL); or Companies with >10% of revenue from coal value chain with expansion plans (or also without if unable to determine expansion plans); or ● Both of the above                                                                                                                                                                                          | ● Companies listed in GCEL (that are not covered by an electricity generation target); or ● Companies with >10% of revenue from coal value chain (that are not covered by an electricity generation target); or ● Both of the above                                                                                                                                                                                | ● Companies listed in GCEL; or ● Companies with >10%                                                                                                                                                                                                                                                                                                                                                               |
| Ring-fenced projects with >10% of revenue from coal value chain                                                                                                                                                                                                                                                                                                                                                    | Ring-fenced projects involved in new coal mines, extensions or expansions of coal mines or new unabated coal-fired power                                                                                                                                                                                                                                                                                           | plants                                                                                                                                                                                                                                                                                                                                                                                                             | Ring-fenced projects with >10% of revenue from coal value chain (that are not covered by an electricity generation target)                                                                                                                                                                                                                                                                                         | Coal Project Ring-fenced projects with >10% of revenue from coal value chain                                                                                                                                                                                                                                                                                                                                       |
| Coal Value Chain FIs to disclose the definition used by providing industry codes (and other relevant information for activities without a specific industry code), which must include at least exploration, mining or extraction and the development or expansion of mines for all thermal coal grades as well as power plants (that use coal), with a recommendation to also include metallurgical coal and other | Coal Value Chain FIs to disclose the definition used by providing industry codes (and other relevant information for activities without a specific industry code), which must include at least exploration, mining or extraction and the development or expansion of mines for all thermal coal grades as well as power plants (that use coal), with a recommendation to also include metallurgical coal and other | Coal Value Chain FIs to disclose the definition used by providing industry codes (and other relevant information for activities without a specific industry code), which must include at least exploration, mining or extraction and the development or expansion of mines for all thermal coal grades as well as power plants (that use coal), with a recommendation to also include metallurgical coal and other | Coal Value Chain FIs to disclose the definition used by providing industry codes (and other relevant information for activities without a specific industry code), which must include at least exploration, mining or extraction and the development or expansion of mines for all thermal coal grades as well as power plants (that use coal), with a recommendation to also include metallurgical coal and other | Coal Value Chain FIs to disclose the definition used by providing industry codes (and other relevant information for activities without a specific industry code), which must include at least exploration, mining or extraction and the development or expansion of mines for all thermal coal grades as well as power plants (that use coal), with a recommendation to also include metallurgical coal and other |

May 2024 | 25

| Oil and Gas Project     | Ring-fenced projects with >10% of revenue from oil and gas value chain                                                                                                                                                                                                                                                    | New long-lead time upstream oil and gas projects and midstream infrastructure dedicated to new long-lead time upstream oil and gas projects                                                                                                                                                                               | Ring-fenced projects with >10% of revenue from oil and gas value chain that are in the upstream segment                                                                                                                                                                                                                   | n/a                                                                                             |
|-------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------|
| Oil and Gas Value Chain | FIs to disclose the definition used by providing industry codes (and other relevant information for activities without a specific industry code), which must include at least the exploration, extraction and development or expansion of fields, with a recommendation to also include other segments of the value chain | FIs to disclose the definition used by providing industry codes (and other relevant information for activities without a specific industry code), which must include at least the exploration, extraction and development or expansion of fields, with a recommendation to also include other segments of the value chain | FIs to disclose the definition used by providing industry codes (and other relevant information for activities without a specific industry code), which must include at least the exploration, extraction and development or expansion of fields, with a recommendation to also include other segments of the value chain | n/a                                                                                             |
| Minimum Required Scope  | ● Disclosure of financial metric(s) for all Required, Optional, and Out-of-Scope Activities in Table 1 (related to fossil fuel sector) ● Disclosure of GHG emissions for all Required and Optional Activities in Table 1 (related to fossil fuel sector)                                                                  | All Required, Optional* and Out-of-Scope* Activities in Table 1 (related to fossil fuel sector)                                                                                                                                                                                                                           | All Required and Optional* Activities in Table 1 (related to fossil fuel sector)                                                                                                                                                                                                                                          | All Required, Optional* and Out-of-Scope* Activities in Table 1 (related to fossil fuel sector) |

* For the asset / investment / wealth management asset class (AIWM), only discretionary mandates are required under these criteria.

- ● Boundary: FIs shall set targets for their fossil fuel-related projects and companies as outlined in Table 2 and below that supersede the coverage requirements in Table 1.
- o Coal Company: Unless otherwise specified in Table 2, FIs shall define coal companies as those listed in the Global Coal Exit List (GCEL) 26 AND/OR companies with 10% or more of revenues from the coal value chain.
- o Coal Project: Unless otherwise specified in Table 2, FIs shall define coal projects as ring-fenced projects with 10% or more of their revenue generated in the coal value chain.

26 The use of third-party lists within the Fossil Fuel Finance Targets method criteria is intended to provide guidance and support for target-setting processes. Although the lists referenced herein have been included for the purposes of this version of the criteria, the SBTi intends to review its assessment procedures and inclusion of third-party lists on a periodic basis.

- o Coal Value Chain: When using a revenue threshold, the FI must disclose how the projects and/or companies were determined to be in-scope of the coal value chain, by providing industry codes from an industry classification system such as the North American Industry Classification System (NAICS), Global Industry Classification Standard (GICS), Standard Industrial Classification (SIC) or Nomenclature of Economic Activities (NACE), and other relevant information for activities without a specific industry code. This must include at least exploration, extraction and the development or expansion of mines for all thermal coal grades as well as power plants (that use coal). The SBTi also recommends including all metallurgical coal grades and other segments of the value chain, such as mining services; any dedicated transport and logistics; processing; storage; trading; and any services dedicated to supporting the coal value chain (e.g., operations and maintenance; engineering, procurement and construction).
- o Oil and Gas Company: Unless otherwise specified in Table 2, FIs shall define oil and gas companies as those listed in the Global Oil &amp; Gas Exit List (GOGEL) and all National Oil Companies (i.e., oil and gas companies fully or majority-owned by a national government) AND/OR companies with 10% or more of revenues from the oil and gas value chain.
- o Oil and Gas Project: Unless otherwise specified in Table 2, FIs shall define oil and gas projects as ring-fenced projects with 10% or more of their revenue generated in the oil and gas value chain.
- o Oil and Gas Value Chain: When using a revenue threshold, the FI must disclose how the projects and/or companies were determined to be in-scope of the oil and gas value chain, by providing industry codes from an industry classification system such as NAICS, GICS, SIC or NACE and other relevant information for activities without a specific industry code. This must include at least the exploration, extraction, and development or expansion of fields. The SBTi also recommends including other segments of the value chain, such as transportation and distribution infrastructure, terminals, storage, liquified natural gas, liquified petroleum gas, gas to liquids, refining, transportation of products, trading, marketing and retailing.
- ● Disclose: FIs shall commit, via a publicly available policy published prior to submission of the FI's science-based target, to publicly disclose information at a portfolio level on an annual basis to provide a level of transparency that aids stakeholders' understanding of the extent of financial activities related to fossil fuel projects and companies. FIs shall disclose the following data points annually at a fixed point in time

(e.g., the last day of the FI's fiscal year), beginning in the year of target submission.

- o Financial metric(s) (e.g., dollar amount of loans, investments and assets under management; debt and equity underwriting volume; insurance underwriting premiums) for all of the FI's Required Activities, Optional Activities, and Out-of-Scope Activities (per Table 1) related to projects and companies (as defined in Table 2) in the (i) coal sector separately and (ii) oil and gas sectors together or separately.
- o Total absolute GHG emissions (scopes 1, 2 and 3 in aggregate or separately), i.e., all relevant GHGs (including methane), attributed to the FI's Required Activities and Optional Activities (per Table 1) related to projects and companies

(as defined in Table 2) in the (i) coal sector separately and (ii) oil and gas sectors together or separately.

FIs may provide the above data points in further granularity (e.g., by upstream, midstream and downstream segments of the value chain). The SBTi recommends that data points be measured on a time-weighted average basis and disclosed along with the calculation methodology used. FIs should also disclose methane emissions attributed to their financial activities in the fossil fuel sector as well as financing for the permanent decommissioning of fossil fuel production activities and capacity separately.

- ● Halt: FIs shall commit, via a publicly available policy published prior to submission of the FI's science-based target, to the immediate cessation (upon the publication of the policy) of all new financial activities related to the projects and companies below, with the exception of new financial activities dedicated to the permanent decommissioning of production activities and capacity.
- ○ Projects and companies (as defined in Table 2) involved in new coal mines, extensions/expansions of coal mines, or new unabated coal-fired power plants.
- ○ New long-lead time upstream oil and gas projects and midstream infrastructure dedicated to new long-lead time upstream oil and gas projects.
- ■ For target validation purposes, five years (from the date of target submission) will be used as the threshold to define long-lead time.
- ○ Oil and gas companies (as defined in Table 2) involved in the above oil and gas activities.
- ■ Alternatively, new financial activities (as defined below for Halt), which the FI provides to companies of any type (including financing with known use of proceeds, underwriting of securities with known use of proceeds, insurance underwriting), that are dedicated to new long-lead time upstream oil and gas activities and midstream infrastructure dedicated to new long-lead time upstream oil and gas activities must be covered under the Halt target. Meanwhile, all other Required Activities, as well as Optional Activities (per Table 1) outside of AIWM (i.e., only discretionary mandates in AIWM are required under these criteria) that are related to oil and gas companies (as defined in Table 2 for Transition) must be covered under the Transition target below.
- ○ The applicability of abatement for the purpose of the halt of financial activities to new unabated coal-fired power plants is considered to be at least a 90% reduction of scope 1 and 2 emissions from the associated coal assets of the holding company or project. For carbon capture to be considered part of the 90%, it (i) must be utilized for mitigation products that have century-scale (or greater) lifetimes (i.e., geological carbon capture and storage) and (ii) must not support enhanced oil recovery or any other processes that enable continued fossil fuel extraction and production development.

## Specifically, FIs may not provide the following:

- ● For the above projects and companies that the FI isn't already involved with:
- ○ Any Required Activities, Optional Activities, or Out-of-Scope Activities (per Table 1), except for the AIWM asset class where only discretionary mandates

may not be provided.

- ● For projects and companies that the FI is already involved with:
- ○ Any new/additional Required Activities, Optional Activities, or Out-of-Scope Activities (per Table 1), except for the AIWM asset class where only discretionary mandates may not be provided. 27
- ● Transition: FIs shall establish the following near-term targets at the portfolio level:
- o Absolute targets: FIs shall set target(s) for reducing absolute GHG emissions attributed to all of their Required Activities, as well as Optional Activities (per Table 1) outside of AIWM (i.e., only discretionary mandates in AIWM are required under these criteria), that are related to projects and companies (as defined in Table 2) in the upstream segment of the oil and gas value chain. FIs may set one aggregated target or multiple targets (e.g., one each for upstream oil and upstream gas) as long as the aggregated amount of absolute emissions reductions is, at a minimum, consistent with the cross-sector pathway. The cross-sector absolute reduction method requires absolute emissions reductions at or above a fixed annual rate (currently defined as 4.2% linear annual reduction between the base year and target year plus an adjustment for base years later than 2020), with sufficient forward-looking ambition. The SBTi strongly recommends that FIs set targets that go beyond the minimum ambition required by the cross-sector pathway. FIs may communicate their absolute targets in financial exposure terms, but the SBTi will assess the target against the absolute emissions pathway described above. In addition, the SBTi recommends that FIs set separate target(s) to specifically reduce absolute methane emissions from their fossil fuel portfolios.

FIs shall also set target(s) for reducing absolute GHG emissions attributed to their Required Activities, as well as Optional Activities (per Table 1) outside of AIWM (i.e., only discretionary mandates in AIWM are required under these criteria) that are related to coal projects and coal companies (as defined in Table 2, such that activities in the power generation sector that shall be covered separately by a Power Generation SDA target according to the requirements outlined in Table 1) in line with the phaseout time frame required further below, if the year of full phaseout is more than five years from the year of target submission. 28

The SBTi theory of change holds that FIs are essential for providing capital and engaging companies to transition to a 1.5°C pathway. The SBTi also recognizes that the emissions impact of divestment from fossil fuel assets is not always clear or consistent, as real economy companies, policymakers and other stakeholders will play a vital role in determining fossil fuel demand. An FI using its influence and actively engaging companies to align with a 1.5°C

27 For example, if an FI already holds 30 shares in a coal company with expansion plans, then the FI may continue to hold the 30 shares but may not buy any more shares in that coal company, and if the FI sells 10 of the 30 shares at a later point, then thereafter the FI may continue to hold 20 shares but may not add to its 20 remaining shares. As another example, if an FI has already provided a $60 loan to a coal company with expansion plans, then the FI may not provide any new loans to that coal company or extend or renew the $60 loan past the original maturity date.

28 For example, an FI submitting targets in 2024 with a 2028 coal phaseout would not need to set a Transition target while an FI submitting targets in 2024 with a 2022 base year and 2040 phaseout year would need to reduce its coal-related GHG emissions by 5.56% per year [(100%) / (2040 - 2022)] and reach at least a 44.5% [(2030 - 2022) x 5.56%]) reduction by 2030.

transition is thus considered the 'first-best' option to support climate stabilization and should be the basis of progress toward the target(s) set. The SBTi also highly encourages new financing dedicated to the decarbonization and permanent decommissioning of fossil fuel production and capacity, in order to enable the projects' and companies' transitions to become 1.5°C-aligned.

- o Time Frame: Fossil Fuel Finance transition targets must cover a minimum of five years and a maximum of 10 years from the date the targets are submitted to the SBTi for an official validation. 29 The same base year shall be used for all Fossil Fuel Finance transition targets, and the SBTi recommends choosing the most recent year as the base year. The SBTi encourages FIs to develop long-term targets in accordance with the SBTi Financial Institutions Net-Zero Standard upon its publication.
- o Scope of Borrower and/or Investee Emissions: Targets shall cover projects and companies in the coal sector and upstream segment of the oil and gas value chain (as defined in Table 2 and above). The scope 1, 2 and 3 (including upstream and downstream) emissions attributed to the FIs' Required Activities, as well as Optional Activities (per Table 1) outside of AIWM (i.e., only discretionary mandates in AIWM are required under these criteria), from these projects and companies shall be covered by the targets. Coverage of all relevant GHGs, including methane, is required.
- ● Phaseout: FIs shall commit, via a publicly available policy published prior to the submission of their science-based target, to phasing out their Required Activities, Optional Activities outside of AIWM and Out-of-Scope Activities (per Table 1) outside of AIWM (i.e., only discretionary mandates in AIWM are required under these criteria) that are related to coal projects and coal companies (as defined in Table 2) in line with a full phaseout by the end of 2030 for projects and companies operating in OECD (Organization for Economic Co-operation and Development) countries and by the end of 2040 globally, with the exception of new financial activities dedicated to the permanent decommissioning of production activities and capacity. FIs should encourage the coal projects and companies they support to adopt managed phaseout plans well in advance of phaseout, with facility-by-facility closure dates that include just transition and re-training plans for workers.

FI-R11 - Transition of Fossil Fuel Support: The SBTi recommends the following measures that will not be validated but may be included in the brief summary of strategy and actions the FI will implement to reach its science-based target(s) and supplement the Fossil Fuel Finance Targets method.

- ● FIs should disclose methane emissions attributed to their financial activities that are related to projects and companies in the fossil fuel sector and set target(s) to specifically reduce methane emissions (in absolute and intensity terms) from their fossil fuel portfolios in line with the latest climate science.

29 For example, for targets submitted for an official validation in the first half of 2024, the valid target years are 2028-2033 inclusive. For targets submitted in the second half of 2024, the valid target years are between 2029 and 2034 inclusive.

May 2024 | 30

- ● FIs should commit to publicly disclosing the percentage share of their portfolio companies in the fossil fuel sector that have 1.5°C-aligned transition plans as well as setting a target to increase that ratio.
- ● FIs should set GHG emissions intensity reduction targets for their Required Activities, as well as Optional Activities (per Table 1) outside of AIWM (i.e., only discretionary mandates in AIWM are required under these criteria), that are related to fossil fuel projects and companies (e.g., attributed emissions per attributed barrel of oil equivalent; tCO2 e/boe).
- ● FIs should set a time-bound engagement period to enable fossil fuel projects and companies to transition, and phaseout support if engagement efforts are not successful. FIs that fail to phaseout financing to fossil fuel projects and companies that do not have and execute a 1.5°C-aligned transition plan expose themselves to risks of stranded assets and reputational damage.

FI-R12- Renewable to Fossil Fuel Ratio: The SBTi also recommends the following target that will not be validated but may be included in the brief summary of strategy and actions FIs will implement to reach their science-based target(s) and supplement the Fossil Fuel Finance Targets method. FIs should set a target to increase their ratio of financial support for renewable energy (relative to financial support for fossil fuels) and to increase end use efficiency every year at the portfolio level, in line with the latest climate science. The ratio should be calculated at a fixed point in time (e.g., the last day of the FI's fiscal year) to consistently report progress on an annual basis.

May 2024 | 31

## 6. REPORTING REQUIREMENTS

FI-C18 - Disclosure of Scope 3 Portfolio Targets - Headline Target: Separate from the calculation of an FI's Portfolio Target Boundary to confirm that minimum coverage requirements have been met per FI-C15, FIs shall disclose, at the time of target announcement and along with approved targets, the percentage of their total investment and lending activities covered by scope 3 portfolio targets on the SBTi website, in a metric representative of the magnitude of FIs' main business activities, which may involve any combination of lending, own investments and asset management. Examples include total balance sheet assets, total investments, total lending book and total assets under management, as relevant. FIs must also disclose a breakdown of required, optional and out-of-scope activities as outlined in the headline target language template in Table 3. These disclosure requirements are intended to enhance the transparency and comparability of portfolio targets.

FIs will use the formula below to calculate the percentage of activities covered by targets:

% 𝑐𝑜𝑣𝑒𝑟𝑎𝑔𝑒 =

𝐴𝑙𝑙  𝑐𝑜𝑣𝑒𝑟𝑒𝑑 𝑏𝑦 𝑡arg𝑒𝑡𝑠

𝐴𝑙𝑙 𝑟𝑒𝑞𝑢𝑖𝑟𝑒𝑑, 𝑜𝑝𝑡𝑖𝑜𝑛𝑎𝑙 𝑎𝑛𝑑 𝑜𝑢𝑡-𝑜𝑓-𝑠𝑐𝑜𝑝𝑒 𝑎𝑠𝑠𝑒𝑡 𝑐𝑙𝑎𝑠𝑠𝑒𝑠

Out-of-scope asset classes include those listed as such in Table 1 and other tangible assets that are held, owned, controlled or managed by the FI, such as cash, deposits at central banks, receivables, assets held for sale and other financial instruments. Fixed assets (i.e., property for own use or to lease out that are covered by scope 1 and 2 or scope 3, categories 1-14 targets; plant and equipment) unless related to the fossil fuel sector, as well as leased assets, prepaid expenses, accrued income and other intangible assets (e.g., goodwill, current and deferred tax assets) may be excluded from the denominator. For example, while assets administered under advisory and/or execution-only mandates are optional or out of scope for asset managers, they will still need to be included in the denominator even if they are not covered by targets.

FI-C19 - Implementation Reporting: At the time of target submission, the FI shall submit a brief summary of how it intends to meet its scope 3 portfolio targets in conformity with the template provided in the SBTi target submission form for FIs. This disclosure is intended to create transparency. The summary shall focus on future actions rather than past achievements. The content of the summary will not be used as a basis for validation of targets. At the time of target announcement, the summary shall be made public. 30

FI-C20 - Tracking and Reporting Target Progress: After target approval, the SBTi requires annual disclosure of scope 1 and 2 GHG emissions, disclosure of progress against all approved targets in the relevant metric, 31 and disclosure of actions or strategies undertaken during the year to meet scope 3 portfolio targets. If the FI submits optional targets on scope 3, categories 1-14, as described in FI-R2, and these are approved by the SBTi, the FI shall disclose progress toward them as well. FIs should also annually disclose a full GHG emissions inventory for their portfolios, covering all activities for which a GHG accounting method is available at the time of target submission (i.e., all Required Activities and Optional

30 FIs will have opportunities to review the summary language before the SBTi publishes it on its website.

31 See the Financial Sector Near-Term SBT Explanatory Document on guidance to disclose progress against targets.

Activities per Table 1).

FI-R13 - Where to Disclose: There are no specific requirements regarding where FIs should disclose their GHG inventory, progress against published targets, and actions or strategies to meet scope 3 portfolio target, as long as this information is publicly available. The SBTi recommends disclosure through standardized, comparable data platforms such as the Net Zero Data Public Utility or CDP's annual climate change questionnaire. Annual reports, sustainability reports and the company's website are also acceptable platforms.

May 2024

|

33

## 7. RECALCULATION AND TARGET VALIDITY

FI-C21 - Mandatory Target Recalculation: To ensure consistency with most recent climate science and best practices, FIs must review targets, and, if necessary, recalculate and submit them for revalidation within five years from the date of target approval. FIs with an approved target that requires recalculation must follow the most recently applicable criteria at the time of resubmission.

FI-C22 - Target Validity: The FI and SBTi must agree upon target language before the SBTi can validate the target submission. FIs with approved targets must publish their target publicly on the SBTi website within six months of the approval date. Targets unannounced after six months must go through the approval process again unless a different publication time frame has been agreed upon in writing with the SBTi. FIs must use the same target language in their own communications as on the SBTi website but are welcome to add additional details in their own communications. Disclaimers in the target language published on the SBTi website may include links to only the FI's website or its own publications.

FI-R14 - Triggered Target Recalculation: FIs should recalculate targets, as needed, to reflect significant changes that could compromise the relevance and consistency of the existing target. Targets should be recalculated as soon as possible to reflect significant changes and remain relevant to the current institutional structure and operations. FIs should re-baseline anytime structural changes prompt a change of 5% or greater to their overall (i.e., scope 1, 2 and 3) emissions inventory and then recalculate their targets (after re-baselining) to check that the ambition and coverage are still sufficient. The following list includes examples of changes that should trigger a target recalculation:

- ● Changes in the consolidation approach chosen for the GHG inventory.
- ● Emissions of excluded categories in the inventory or target boundary change that significantly exceed allowable exclusion limits.
- ● Significant changes in institutional structure and activities (e.g., acquisition, divestiture, merger, insourcing or outsourcing, shifts in goods or service offerings, changes in proportion of investments by asset classes, addition of new products covered by available methods).
- ● Significant adjustments to the base-year inventory, data sources or calculation methodologies, or changes in data used to set targets (e.g., discovery of significant errors or a number of cumulative errors that are collectively significant).
- ● Other significant changes to projections or assumptions used in setting the science-based targets (e.g., changes in growth projections).

FI-R15 - Validity of Target Projections: The SBTi recommends that FIs check the validity of target-related projections on an annual basis. The FI should notify the SBTi of any significant changes, report these major changes publicly and consider a target recalculation, as relevant.

## 8. HOW TO COMMUNICATE TARGETS AND TRACK PROGRESS

The SBTi requires FIs to develop target language in the target submission form for FIs that will be used for public communication if and when the targets are approved. Table 3 provides the detailed target language template. The target submission form includes additional guidance on formulating target language and shall be followed by FIs when setting targets.

Table 3: Target Language Template for FIs

## Scope 1 and 2 Targets

Absolute target : [FI name] commits to reduce absolute scope 1 and 2 GHG emissions [XX]% by [target year] from a [20xx] base year.

Renewable electricity procurement target : [FI name] commits to increase active annual sourcing of renewable electricity from [XX]% in [base year] to 100% by [year before 2030] and to continue active sourcing of 100% renewable electricity through 2030. or

[FI name] commits to maintain zero absolute scope 1 GHG emissions from [base year] through [target year] and commits to increase active annual sourcing of renewable electricity from [XX]% in [base year] to [XX]% by [target year].

or

[FI name] commits to continue active annual sourcing of 100% renewable electricity from [base year] through 2030.

## Scope 3, Categories 1-14 Targets [optional]

Absolute targets: [FI name] commits to reduce absolute [enter scopes] GHG emissions [XX]% by [target year] from a [20xx] base year.

or

Intensity targets: [FI name] commits to reduce [enter scopes] GHG emissions [XX]% per [unit] by [target year] from a [20xx] base year.

or

Engagement targets: [FI name] commits that [XX]% of its suppliers/customers [by spend / revenue / emissions] covering [name scope 3 categories] will have science-based targets by [target year].

## Scope 3 Portfolio Targets - Headline Target

[FI name]'s portfolio targets cover [XX]% of its total investment and lending by [unit] as of [base year]. 1 As of [('that year') or (year)], required activities made up [XX]% of [FI name]'s total investment and lending by [unit], while optional activities made up [XX]% and out-of-scope activities made up [XX]%.

The unit selected should be financed emissions (if quantified) or otherwise linked to the asset classes covered. For example, asset managers should use assets under management, while private equity firms should use invested capital (including cash) and other FIs may use total assets. If financed emissions are used, FIs must also provide the above headline target based on a financial asset metric for comparability purposes (with FIs that solely use a financial asset metric). FIs with activities that span across lending,

investments and/or asset management may add an additional breakdown of % coverage of their loan, investment or asset management portfolio individually.

Separately, banks must also include the following footnote for the headline target:

- 1 These targets and coverage % [do not] include third-party asset management activities. Third-party asset management activities made up X% of total investment, lending and asset management activities by [metric (e.g., loan value and assets under management)].

## Scope 3 Portfolio Targets - Asset Class Target

| Asset Class                            | Method   | Target Output Example                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
|----------------------------------------|----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Real estate                            | SDA      | [FI name] commits to reduce its real estate [investment / loan] portfolio GHG emissions [XX]% per square meter by [target year] from a [20xx] base year. or [FI name] commits to maintain the GHG emissions intensity of its real estate investment/loan portfolio at or below [the base-year emissions intensity] kgCO ₂ e/m 2 from [base year] through 2030 and finance only 1.5°C-aligned real estate assets.                                                                                                                                                     |
| Residential mortgages (consumer loan)  | SDA      | [FI name] commits to reduce its mortgage portfolio GHG emissions [XX]% per square meter by [target year] from a [20xx] base year.                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| Electricity generation project finance | SDA      | [FI name] commits to reduce its electricity generation project finance portfolio GHG emissions [XX]% per MWh by [target year] from a [20xx] base year. or [FI name] commits to continue providing electricity generation project finance for only renewable electricity through 2030. or [FI name] commits to maintain the GHG emissions intensity of its electricity generation project finance portfolio at or below [the base-year emissions intensity] gCO ₂ e/kWh from [base year] through 2030 and finance only 1.5°C-aligned electricity generation projects. |
| Corporate                              | SDA      | [FI name] commits to reduce GHG emissions from the [XX]                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |

| instruments (equity, bonds, loans)   |                              | sector within its [asset class] portfolio [XX]% per ton of [metric] by [target year] from a [20xx] base year.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|--------------------------------------|------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                      | Portfolio Coverage           | [FI name] commits to [XX]% of its [eligible] [asset class] portfolio by [unit] setting SBTi-validated targets by [target year] from a [20xx] base year.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|                                      | Temperature Rating           | [FI name] commits to align its scope 1 + 2 portfolio temperature score by [unit] within the [XX] sector of its [asset class] portfolio from [X.XX]°C in [base year] to [X.XX]°C by [target year]. [FI name] commits to align its scope 1 + 2 + 3 portfolio temperature score by [unit] within the [XX] sector of its [asset class] portfolio from [X.XX]°C in [base year] to [X.XX]°C by [target year].                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|                                      | Fossil Fuel Finance Targets* | [FI name] commits to publicly disclose on an annual basis all of its financial activities by [financial metric(s)] as well as the GHG emissions attributed to its [loans, investments and/or assets under management] that are related to projects and companies in the [coal, oil and/or gas] sectors separately. [FI name] commits to immediately end all new financial activities related to (i) projects and companies involved in new coal mines, extensions or expansion of coal mines or new unabated coal-fired power plants; and (ii) new long-lead time upstream oil and gas projects and midstream infrastructure dedicated to new long-lead time upstream oil and gas projects; and (iii) [(companies engaged in such projects) and/or (including those provided to companies that are dedicated to such oil and gas activities)]. [ FI name] commits to reduce GHG emissions from the [coal, oil and/or gas] sector[s] within its [corporate loan, investment and/or asset management] portfolio [XX]% by [target year] from a [20xx] base year. [FI name] commits to phase out all financial activities to all [non-decommissioning] coal projects and coal companies by [target year]. * FIs shall disclose the definitions used to define coal and oil & gas projects, companies and value chain. |

## Action Plan to Achieve Targets

[FI name] will implement the following strategy and actions to achieve its targets:

- ● Example: [FI name] aims to steer its [XX dollar amount] of corporate equity, bonds and loan book in power generation, steel, cement and aviation through actively supporting clients' SBT achievement and zero-carbon transformation. For example, [FI name] will offer more favorable interest rates to borrowers that set and stay on track to meet ambitious climate goals. [FI name] selected these actions because [add reasons].

May 2024

|

38

## APPENDIX

## Figure A-1. Portfolio Target Boundary (PTB) Process Tree

<!-- image -->

|

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->