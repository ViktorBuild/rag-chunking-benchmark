---
document_id: sbti_bvcm_raising_the_bar
title: "Raising the Bar: A Guide to Accelerating Beyond Value Chain Mitigation"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "SBTi"
year: 2024
original_file: "sbti_bvcm_raising_the_bar_guide.pdf"
tables_detected: 12
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

RAISING THE BAR: AN SBTI REPORT ON ACCELERATING CORPORATE ADOPTION OF BEYOND VALUE CHAIN MITIGATION (BVCM)

VERSION 1.0

FEBRUARY 2024

## CONTENTS

| INTRODUCTION                                              |   4 |
|-----------------------------------------------------------|-----|
| The SBTi                                                  |   5 |
| The Corporate Net-Zero Standard                           |   5 |
| BVCM                                                      |   6 |
| The purpose and structure of this report                  |   7 |
| PROBLEM STATEMENTANDVISION                                |   8 |
| RESEARCH METHODSAND PROCESS                               |  11 |
| FINDINGS                                                  |  14 |
| The business case for BVCM                                |  16 |
| Barriers preventing greater adoption and/or scale of BVCM |  22 |
| Newincentives mechanisms                                  |  27 |
| TOOLBOX FORACCELERATING CORPORATEADOPTIONAND              |  31 |
| Toolbox                                                   |  32 |
| Relevant actors across the ecosystem                      |  33 |
| CONCLUSION                                                |  38 |
|                                                           |  41 |

REFERENCES

2

<!-- image -->

## ACKNOWLEDGMENTS

This document was produced by the SBTi.

This research that informed this report is funded in part by the Gordon and Betty Moore Foundation, the Climate and Land Use Alliance and the Voluntary Carbon Markets Integrity Initiative (VCMI), an international non-profit organization. The funders do not necessarily share the positions expressed in the publication.

Systemiq and Boston Consulting Group also supported the development of this report, whose experts conducted and assessed the interviews and surveys with companies and other stakeholders.

## DISCLAIMERS

Although reasonable care was taken in the preparation of this document, the Science Based Targets initiative (SBTi) hereby states and affirms that the document is provided without warranty, either expressed or implied, of accuracy, completeness, or fitness for purpose. The SBTi hereby further disclaims any liability, direct or indirect, for damages or loss relating to the use of this document to the fullest extent permitted by law.

The information (including data) contained in the document is not intended to constitute or form the basis of any advice (financial or otherwise). The SBTi does not accept any liability for any claim or loss arising from any use of or reliance on any data or information in the document.

All information, opinions and views expressed herein by the SBTi are based on its judgment at the time this document was prepared and is subject to change without notice due to economic, political, industry, firm-specific, or other factors.

The SBTi accepts no liability for the reliability of any information provided by third parties.

This document is protected by copyright. Information or material from this document may be reproduced only in unaltered form for personal, non-commercial use. All other rights are reserved. Information or material from this document may be used only for the purposes of private study, research, criticism, or review permitted under the Copyright Designs &amp; Patents Act 1988 as amended from time to time ('Copyright Act'). Any reproduction permitted in accordance with the Copyright Act shall acknowledge this document as the source of any selected passage, extract, diagram, or other information.

© SBTi 2024

Partner Organizations:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Author:

Scarlett Benson

## Project/Review team:

Alberto Carrillo Pineda Alice Farrelly Aman Sidhu Anita Sheth Astrid von Preussen Christa Anderson Emma Borjigin-Wang Emma Watson Ginger Kowal Haley Kazanecki Luisa Pastore Luke Pritchard Maria Outters Martha Stevenson Martina Massei Paulina Tarrant Roman Czebiniak

Rosie Williams

In collaboration with:

<!-- image -->

<!-- image -->

## INTRODUCTION

<!-- image -->

## THE SBTI

The Science Based Targets initiative (SBTi) drives ambitious corporate climate action by enabling businesses and financial institutions globally to set science-based greenhouse gas emissions reduction targets.

It was formed as a collaboration between CDP, the United Nations Global Compact, World Resources Institute (WRI), the World Wide Fund for Nature (WWF) and the We Mean Business Coalition. The SBTi's goal is to enable companies worldwide to do what climate science requires of the global economy: to halve emissions by 2030 and achieve net-zero before 2050.

The SBTi develops criteria and provides tools and guidance to enable businesses and financial institutions to set GHG emissions reduction targets in line with what science tells us is needed to keep global heating below 1.5°C.

## THE CORPORATE NET-ZERO STANDARD

In October 2021, the SBTi published the Corporate Net-Zero Standard which provides guidance, criteria, and recommendations for companies to set near- and long-term climate targets consistent with scenarios that limit global temperature rise to 1.5°C with no or limited overshoot. The Corporate Net-Zero Standard comprises four key components:

<!-- image -->

- Near-term science-based targets (SBTs) : Companies are required to set 5-10-year targets to reduce emissions within the company value chain in line with 1.5°C pathways. 1
- Long-term SBTs : Companies are required to set targets to reduce emissions within the company value chain to a residual level in line with 1.5°C scenarios by no later than 2050. 2

<!-- image -->

<!-- image -->

Beyond value chain mitigation (BVCM) : Companies are encouraged to take immediate and consistent action to mitigate emissions beyond their value chains to support global efforts to limit global temperature rise to 1.5°C.

<!-- image -->

Neutralization of any residual i  emissions : Companies are required to neutralize the climate impact of any residual emissions at the net-zero target year and any greenhouse gas (GHG) emissions released into the atmosphere thereafter through the permanent removal and storage of carbon from the atmosphere.

- i Residual emissions are those which cannot be completely eliminated despite implementing all available mitigation measures contemplated in pathways that limit warming to 1.5°C with no or limited overshoot. A company's residual emissions are its scope 1, 2, and 3 emissions that remain once its long-term target has been achieved.

## BVCM

BVCM is defined in the Corporate Net-Zero Standard as 'mitigation action or investments that fall outside a company's value chain, including activities that avoid or reduce GHG emissions, or remove and store GHGs from the atmosphere.' 1

It is included as a best practice recommendation rather than a criterion which must be met in order for a company's net-zero target to be validated by the SBTi. The BVCM recommendation is formulated as follows:

"R9 - Beyond value chain climate mitigation: Companies should take action or make investments outside their own value chains to mitigate GHG emissions in addition to their near-term and long-term science-based targets. For example, a company could provide annual support to projects, programs and solutions that provide quantifiable benefits to climate, especially those that generate additional co-benefits for people and nature. Companies should report annually on the nature and scale of those actions pending further guidance.' 2

It is important to emphasize that a company's efforts to deliver BVCM must not replace or delay efforts to reduce its scope 1, 2 and 3 emissions in line with a 1.5°C pathway. This is consistent with the Intergovernmental Panel on Climate Change (IPCC) Sixth Assessment Report (AR6) which states that 'unless there are immediate and deep emissions reductions across all sectors, limiting global warming to 1.5°C will be beyond reach.'

Instead, BVCM is a mechanism by which companies can go above and beyond their science-based targets to accelerate the global net-zero transition by helping other economic and social actors to reduce and/or remove GHG emissions today and by funding activities which can expect to deliver BVCM in the longer term. It can also be a way for companies to take responsibility for their unabated emissions as they transition to net-zero.

The SBTi's BVCM report, 'Above and Beyond: An SBTi report on the design and implementation of beyond value chain mitigation' launched in February 2024, provides suggestions to support the BVCM recommendation (R9) included within the Corporate Net-Zero Standard and to provide companies with proposals for the design and implementation of high-integrity and high-impact BVCM strategies.

<!-- image -->

## THE PURPOSE AND STRUCTURE OF THIS REPORT

This accompanying report is a complement to the 'Above and Beyond' BVCM report, and therefore should be read together. It explores, through engagement with corporates and other stakeholders, the incentives for BVCM over which the broader climate ecosystem has influence, including civil society, academia, policymakers, standard setters, advocacy organizations and multilateral organizations. It draws upon SBTi research to consider both the barriers that limit private sector adoption of BVCM, as well as the positive incentives that have the potential to accelerate adoption. Based on the research findings, this report provides recommendations for different actors, offering a shared vision and 'theory of change' for scaling corporate climate finance into BVCM over the coming decades.

The report is structured as follows:

- Problem statement and vision 1
- Summary of the barriers and incentives for BVCM 2
- Insights on the business case for BVCM
- Insights on barriers preventing greater adoption and/or scale of BVCM
- Insights on potential new incentive mechanisms
- A toolbox for accelerating corporate adoption and implementation of BVCM 3
- Conclusions 4

<!-- image -->

<!-- image -->

Please refer to the SBTi online glossary for definitions of key terms used within this document.

## PROBLEM STATEMENT AND VISION

<!-- image -->

## The world is dangerously close to passing the 1.5°C threshold,

beyond which humanity and other species are exposed to existential and irreversible negative impacts. To avoid the most severe climate impacts, global mean surface temperature must be stabilized at or below 1.5°C of warming. 3

Impacts are already being felt across the world. At today's level of warming (estimated between 0.95 and 1.2°C), tens of millions of people are already exposed to temperature extremes. 4,5  In 2022, climate change and La Niña drove overall losses of USD 270 billion and insured losses of USD 120 billion. 6

Progress to address the climate crisis is insufficient. There is a significant gap in terms of the globally committed levels of climate mitigation and climate finance and what is needed to limit warming to 1.5°C. Estimates suggest that annual mitigation finance needs to surpass USD 8.4 trillion per year between now and 2030, and to rise to USD 10.4 trillion per year in the following two decades, compared to just USD 1.2 trillion a year today. 7

Private sector adoption of emission reduction targets can play a significant role in addressing emissions within corporate value chains. While there has been an exponential increase in adoption of science-based targets over the past eight years (with companies committed to set or with validated science-based targets making up more than a third of the world's market capitalization at the end of 2022), there is still a large portion of the economy that has yet to align with a 1.5°C pathway. This underscores the need to scale-up the adoption and implementation of strategies to mitigate emissions from activities within corporate operations and wider value chains.

<!-- image -->

However, it is also important to catalyze private sector finance to mitigate emissions that occur beyond corporate value chains, mitigation opportunities that are commonly underserved by traditional finance mechanisms. For example approximately one-third of tropical deforestation is attributed to subsistence farming, 8 and over 50% of the food economies in Africa, Asia, and Latin America rely on traditional and transitional supply chains, 9 which are unlikely to be influenced by investments made through corporate climate commitments within the value chain. Despite the urgent need to achieve net-zero emissions at an accelerated pace, the Agriculture, Food, and Other Land Use (AFOLU) sector currently receives less than 4% of climate finance. 10

Companies also have a responsibility to finance mitigation beyond their value chains. The transition towards net-zero aligned business models is long-term and thus a company's unabated emissions that occur during that transition will accumulate in the atmosphere contributing to global warming and driving physical climate impacts. Beyond value chain mitigation represents a mechanism for companies to take responsibility for these unabated emissions during the transition by helping other economic and social actors reduce and/or remove GHG emissions.

While there are examples of leading companies making meaningful commitments to BVCM, the adoption rate remains low and, where companies are investing, it is often not at the scale commensurate with the magnitude of the climate crisis. For example, fewer than 12% of companies which disclosed to CDP in 2022 reported purchasing carbon credits to accelerate climate action beyond their value chains. 11  Only 0.5% of 5,998 companies that have committed or validated science-based targets have purchased durable carbon removal. Despite the imperative to mobilize a minimum of USD 2.6 trillion in private climate investments by 2030, annual corporate climate finance has only increased marginally from USD 183 billion to USD 192 billion annually since 2018. 12

Given this context, the authors propose the following articulation of a 'problem statement' and a 'vision' upon which the recommendations in this report have been formulated.

<!-- image -->

<!-- image -->

## PROBLEM STATEMENT

There are an insufficient number of companies funding and delivering BVCM consistently and at a scale commensurate with the magnitude of the climate crisis.

## VISION

A critical mass of companies are going beyond sciencebased targets to also fund and deliver BVCM, collectively contributing a significant volume of finance and mitigation to address the climate crisis.

<!-- image -->

## RESEARCH METHODS AND PROCESS

<!-- image -->

Information was obtained during 2023 via a corporate survey, an open public consultation survey, a workshop, desk-based literature reviews, direct engagement with expert advisory group members and interviews with companies, academics and industry experts.

Corporate Interviews and Survey: In March and April 2023, the SBTi conducted interviews with companies and hosted an online survey on the topic of BVCM with the support of the Boston Consulting Group (BCG). The survey was available for inputs from 13 March to 31 March 2023. 212 companies responded to the online survey and a further 22 companies were interviewed. The objective of the survey and interviews was to understand more about companies' existing BVCM funding activities, alongside motivators, barriers, and potential new mechanisms to drive investment. See here for the results.

<!-- image -->

Public Consultation: The SBTi also held a BVCM public consultation from 19 June to 30 July 2023. The objective of the public consultation was to elicit feedback from a diverse set of stakeholders on the topic of BVCM. Respondents were invited to submit their feedback on several complex technical and value-based considerations related to BVCM. One of the consultation areas focused on incentives and barriers for BVCM. The SBTi also held one-to-one meetings during the consultation period with key stakeholders on the topic, including organizations focused on supporting the rights of Indigenous Peoples and local communities. The public consultation results can be found here.

Workshop: The SBTi also hosted a workshop in New York, on 20 September 2023 during New York Climate Week to obtain feedback on incentives and barriers related to BVCM. The workshop was co-hosted by Deloitte, Gold Standard and the SBTi. Attendees were from approximately 50 organizations and companies from a range of sectors.

Desk Reviews, Expert Interviews and Group Discussion: The SBTi conducted desk-based literature reviews, engaged with the BVCM expert advisory group and interviewed academics and industry experts on the topic.

Image Source: Justin Merriman / EE Image Database

## Figure 1: Scope of the research conducted by the SBTi during 2023 on barriers to and incentives for BVCM

<!-- image -->

<!-- image -->

Image Source: National Renewable Energy Lab

## FINDINGS

<!-- image -->

Note: the SBTi accepts no liability for the reliability of any data provided by third parties. No representation or warranty (express or implied) is given by the SBTi as to the accuracy or completeness of the information, insights, results and/or opinions of the BVCM public consultation and corporate engagement survey results.

## THE BUSINESS CASE FOR BVCM

The BVCM corporate engagement process highlighted that the business case for BVCM varies across companies depending on factors such as the region, market and industry in which the company operates, its size and market share, and ultimately the extent to which the company is impacted by the changing physical environment linked to climate change and the associated changes in policy, financial markets, consumer markets, society and technology. Consumer-facing companies highlighted BVCM as an opportunity to differentiate their brand. Companies that are highly dependent on natural capital identified BVCM as an opportunity to enhance resilience across their operations and supply chains. Companies in higher emitting sectors identified BVCM as an opportunity to scale the availability of carbon dioxide removal (CDR) technologies needed to neutralize residual emissions in the future. Across all sectors, companies highlighted benefits linked to talent acquisition and retention and many highlighted BVCM as a core part of their social license to operate.

## BVCM benefits linked to the changes in the physical environment

Companies face acute and chronic physical risks as a result of climate change (e.g., rising temperatures, sea-level rise, extreme weather events, resource scarcity, ecosystem degradation), as well as systemic risks linked to climate tipping points and ecosystem collapse. Climate change and La Niña drove overall losses of USD 270 billion and insured losses of USD 120 billion in 2022. 13

By funding BVCM, companies can mitigate physical climate risks and realize opportunities linked to resilience and climate adaptation.

For example, investments to protect mangrove ecosystems have enormous benefits: mangrove forests provide more than USD 80 billion per year in avoided losses from coastal flooding, and efforts to protect them could deliver more than 60 million tCO2e a year of climate mitigation over the next two decades. 14,15

<!-- image -->

Image source: Abbie Trayler-Smith / Panos Pictures

An illustrative example of a company delivering BVCM to realize benefits linked to changes in the physical environment would be a manufacturing company funding the restoration of coastal ecosystems adjacent to its production facilities to mitigate the risk of cost increases or loss of revenue linked to storm surges damaging those production facilities.

## ILLUSTRATIVE QUOTES AND STATISTICS FROM THE SBTI BVCM CORPORATE ENGAGEMENT INTERVIEWS AND SURVEY

## Illustrative quote(s) from the corporate interviews:

'We invest in landscapes adjacent to our sourcing areas to support the health of those landscapes to secure future access to commodities.'

## Companies purchasing and retiring carbon credits:

## Companies funding BVCM through mechanisms other than carbon credits:

- The need to reach net-zero globally was the most commonly cited motivation for companies purchasing carbon credits, identified by 67% of 91 respondent companies (see page 29).
- 51% of 88 companies that reported on the factors they consider when selecting carbon credits stated that they consider whether they will help prevent ecological tipping points (see page 24).

## Companies not purchasing and retiring carbon credits:

- 41% of 71 companies stated that concerns about the supply-side quality of carbon credits was a reason for not purchasing and retiring credits (see page 32).
- 67% of 67 companies cited the need to reach net-zero globally as a motivator for funding BVCM (see page 46).
- 39% of 67 companies that reported on the factors they consider when selecting which types of activities to fund stated that they consider whether the associated activity will help prevent ecological tipping points (see page 42).
- 30% of 68 companies that reported on the quality dimensions considered in funding BVCM stated that they look to support activities at the highest risk of the negative impacts of climate change (see page 42).
- The most important reason for increasing non-credit based BVCM funding was trust that investments are delivering results (see page 44).

## BVCM benefits linked to the policy context

Companies face risks as a result of policies designed to constrain activities driving climate change, e.g., taxes and charges on polluting activities and tradable permits in cap-and-trade systems. 16  Companies also face climate-related litigation or legal risk as a result of claims being brought before the courts. 17

BVCM activities and investments as a supplement to scope 1, 2 and 3 abatement could potentially reduce future policy or litigation risk where BVCM is aligned with the polluter pays principle set out in the 1992 Rio Declaration which signifies that those who produce pollution should bear the costs of managing it to prevent damage to human health or the environment. 18

Companies can also realize opportunities linked to governmental efforts to incentivize corporate action on climate, e.g., subsidies and tax incentives. 19 Tax credits can be designed to allow businesses to deduct a certain percentage of green investment costs from their taxes. The Inflation Reduction Act in the United States includes 24 tax credits - most of which relate to climate and energy policies - and is anticipated to drive USD 380 billion of investment into renewable energy and sustainable technologies. 20

Policy-related opportunities also exist for organizations to utilize their BVCM funding activities to collaborate with governments to access new markets through financing BVCM through public-private partnerships and blended finance instruments.

An illustrative example of a company delivering BVCM to realize benefits linked to changes in the policy environment would be a media company looking to enhance its brand reputation investing into a blended finance mechanism that finances nature-based solutions in sub-Saharan Africa whereby development finance is leveraged to attract and de-risk private sector investments into developing and emerging economies.

## ILLUSTRATIVE QUOTES AND STATISTICS FROM THE SBTI BVCM CORPORATE ENGAGEMENT INTERVIEWS AND SURVEY

## Companies purchasing and retiring carbon credits:

- 33% of 83 companies identified a lack of policy incentives as a barrier to spending more on carbon credits (see page 29).
- Tax incentives were the  third-ranked incentive mechanism for purchasing and retiring carbon credits, with customer demand ranked number one and investor demand ranked number two (see page 33).

## Companies not purchasing and retiring carbon credits:

- 18% of 71 companies cited a lack of policy incentives as a rationale for not doing so (see page 32).

## Companies financing BVCM through mechanisms other than carbon credits:

- 40% of 57 companies identified a lack of policy incentives as a barrier to spending more. This was the second ranked barrier, after a lack of economic incentives (see page 46).
- 48% of 135 respondent companies stated that tax benefits would incentivize them to fund more BVCM (see page 52).

## BVCM benefits linked to changes in financial markets

Concern about climate change has been cited as the most common reason for financial groups to exclude companies from their portfolios, according to research from a coalition of non-profit environmental and sustainability groups. 21 Correspondingly, many investors see purpose-led brands as a key to future-proofing their portfolio, recognizing sustainability as an opportunity for growth. 22 BVCM thus presents an opportunity to retain and attract investors.

Moreover, companies can realize opportunities linked to new sustainability-linked financial mechanisms by underwriting or financing green bonds and infrastructure (e.g., low-emission energy production, energy efficiency, grid connectivity, or transport networks).

An illustrative example of a company delivering BVCM to realize benefits linked to changes in financial markets would be a fashion company funding the protection of the Amazon rainforest to signal that it is a purpose-led brand and to attract investors focused on purposeful businesses.

## ILLUSTRATIVE QUOTES AND STATISTICS FROM THE SBTI BVCM CORPORATE ENGAGEMENT INTERVIEWS AND SURVEY

## Illustrative quote(s) from the corporate interviews:

'There is a growing expectation among investors that our actions and targets are validated by third parties and science-based.'

## Companies purchasing and retiring carbon credits:

## Companies funding BVCM through mechanisms other than carbon credits:

- 38% of the 91 respondents stated a reason for doing so being that their stakeholders (e.g., customers, investors) were demanding it (see page 29).
- Lack of investor pressure was the lowest ranked barrier (see page 29).

## Companies not purchasing and retiring carbon credits:

- Investor demand was identified as one of the top factors that would motivate them to do so (see page 33).
- Lack of investor pressure was the lowest ranked barrier (see page 32).
- 49% of the 67 respondents stated a reason for doing so being that their stakeholders (e.g., customers, investors) were demanding it (see page 46).
- Investor demand was rated the most important factor that would incentivize them to deliver more BVCM (see page 48).

## Companies not funding BVCM through mechanisms other than carbon credits:

- Investor demand was identified as one of the top factors that would motivate them to do so (see page 50).

## BVCM benefits linked to changes in consumer markets and changing societal expectations of companies

Companies face market risks due to shifts in supply and demand for products and services as a result of climate change. They can also realize opportunities to increase market share through brand differentiation linked to climate leadership. Recent analysis showed that 14% of consumers cite environmental, social and governance (ESG) as their top buying criteria and more than 70% of consumers are willing to pay a reasonable premium (10-25%) for sustainability. 23  Numerous surveys have shown that corporate donations attract customers: Mintel, for example, found that charitable giving affects nearly three-quarters (73%) of Americans' spending decisions. Half of the consumers surveyed said they would switch to a company that supports a cause they believe in, including 61% of adults aged 41 or younger. 24 BVCM therefore represents an opportunity for companies to differentiate themselves from their peers and appeal to socially and environmentally minded consumers.

<!-- image -->

The social license to operate refers to the ongoing acceptance of a company or industry's business practices and operating procedures by its employees, stakeholders, and the general public. Companies can erode the social license by failing to take externalities into account even if they have already committed to reducing their value chain emissions in the short and long term, and as a result their core strategies may not be achievable. 25 Demonstrating a commitment to addressing the climate crisis through BVCM can help businesses avoid costs linked to loss of the social license to operate - for example, replacing an employee costs, on average, 21% of their annual pay. 26 It can also be an important factor in job selection, with more than 40% of millennials reporting that they seek jobs with a purpose. 27

An illustrative example of a company delivering BVCM to realize benefits linked to changes in consumer markets would be a telecommunications company funding the development of solar mini grids to differentiate itself from peers and to unlock opportunities for price premiums linked to climate leadership.

An illustrative example of a company delivering BVCM to realize benefits linked to changes in society's expectation of companies would be a high-profit technology company funding a portfolio of BVCM activities to demonstrate to civil society and regulators that its privileged economic position is balanced by tangible social responsibility.

## ILLUSTRATIVE QUOTES AND STATISTICS FROM THE SBTI BVCM CORPORATE ENGAGEMENT INTERVIEWS AND SURVEY

## Illustrative quote(s) from the corporate interviews:

'Our customers care about our sustainability goals and targets and will ask us about our progress. Sustainability is a license to operate.'

'Our BVCM investments and climate efforts are an extremely important recruitment tool. We need to live up to the standard we are setting.'

## Companies purchasing and retiring carbon credits:

- 65% of 91 respondents purchased and retired carbon credits because they wanted to be seen as a leader in corporate climate action (see page 29).
- 42% of 91 respondents purchased and retired carbon credits because they wanted to strengthen their brand reputation (see page 29).
- Of 88 respondents that reported on the factors they consider when selecting carbon credits, 45% stated that they consider the geographical location of their operations or consumer markets, 44% stated that they consider how they want our brand to be perceived in the market, and 18% stated that they consider what their consumers are passionate about (see page 24).

## Companies not purchasing and retiring carbon credits:

- Consumer demand was ranked as the most significant motivator for incentivizing carbon credit purchase and retirement (see page 33).

## Companies funding BVCM through mechanisms other than carbon credits:

- Of 67 respondents that reported on the factors they consider when funding BVCM through mechanisms other than carbon credits, 51% stated that they consider the geographical location of their operations or consumer markets, 40% stated that they consider how they want our brand to be perceived in the market, and 31% stated that they consider what their consumers are passionate about (see page 42).
- Of the 67 companies that reported on their motivation for funding BVCM through mechanisms other than carbon credits: 64% cited the desire to be seen as a leader in corporate climate action, 52% cited the desire to strengthen the brand reputation of the company, 49% cited that their stakeholders such as customers are demanding it, and 21% cited the desire to make a related claim (see page 46).
- Customer demand was seen as a top motivator for increasing investment into BVCM (see page 48).

## Companies funding BVCM through mechanisms other than carbon credits:

- Consumer demand was the highest ranked factor that would incentivize them to fund BVCM (see page 50).

## BVCM benefits linked to changes in technology

BVCM is a mechanism by which companies can deploy funds beyond their sector and their value chains to realize opportunities linked to technology R&amp;D and innovation. As such, using BVCM to accelerate technological innovation brings opportunities to access new markets and for associated return on investment. The global climate tech market is expected to reach USD 182.54 billion at a compound annual growth rate (CAGR) of 24.5% during forecast period 2023 to 2033. 28

BVCM also represents an opportunity to accelerate the development of CDR technologies needed to neutralize the impact of residual emissions by mid-century and thus to mitigate future costs and secure access to permanent removals.

<!-- image -->

An illustrative example of a company delivering BVCM to realize benefits linked to changes in technology related to the net-zero transition would be an aviation company funding BVCM by purchasing direct air carbon capture and storage (DACCS) carbon credits to help scale the availability of this technology to ensure that permanent carbon removals are available and affordable when the company has committed to neutralize residual emissions in 2050.

## ILLUSTRATIVE QUOTES AND STATISTICS FROM THE SBTI BVCM CORPORATE ENGAGEMENT INTERVIEWS AND SURVEY

## Illustrative quote(s) from the corporate interviews:

"The carbon [removal] credits we will have to buy in 2040 are an added cost to our business. We need a market that has adequate scale and integrity."

## Companies purchasing and retiring carbon credits:

- When asked about the purpose for the purchase and retirement of carbon credits in the context of SBTi targets, 34% of 124 respondent companies stated that they purchase and retire carbon removal credits in the transition to net-zero because they have set neutralization milestones (see page 30).

## Companies funding BVCM through mechanisms other than carbon credits:

- 73% of respondent companies provide renewable energy investment and 40% provide finance for green investments/technology (e.g., R&amp;D for precision agriculture technologies or CDR technologies). These were the two top categories of investment (see page 41).

## BARRIERS PREVENTING GREATER ADOPTION AND/OR SCALE OF BVCM

The research data highlighted a number of barriers that are preventing wide-scale implementation of BVCM by the private sector. The fear of greenwash accusation as a result of efforts to deliver BVCM, and the lack of a credible claim for communicating BVCM activities and investments were identified as two of the most significant barriers in the SBTi's public consultation on BVCM. ii  Figure 2 below shows the results from this consultation, with 194 respondents ranking the barriers preventing BVCM investment by companies. The results are shown for respondents that represent corporates, financial institutions, small and medium sized enterprises (SMEs) and all other organization types (including e.g., non-governmental organizations (NGOs), policymakers, research and academia).

## Figure 2: BVCM public consultation responses to the question 'in your opinion, what are the most significant barriers preventing BVCM investment?"

<!-- image -->

- ii Please note that this survey was conducted prior to the release of the Voluntary Carbon Markets Initiative (VCMI) Claims Code of Practice.

## Fear of greenwashing accusation

A number of companies who were interviewed on the topic of BVCM in 2023 highlighted their concern that efforts to deliver BVCM will attract criticism and accusation of greenwash. For example, companies are concerned that their efforts to go above and beyond science-based targets through BVCM will be misinterpreted by external stakeholders as tantamount to offsetting (where companies substitute abatement of value chain emissions by funding mitigation beyond the value chain). Corporate offsetting has been subject to widespread critique and therefore poses reputational risks to companies. 29

Respondents to the BVCM public consultation ranked the fear of greenwash accusation as the top barrier preventing BVCM deployment. The results of the corporate engagement survey also highlighted this as a significant barrier, with 35% of respondents citing this as a key barrier to spending more on carbon credits (29 of 83 respondents), and 28% of respondents stating it was a barrier to increased BVCM funding through mechanisms other than carbon credits

<!-- image -->

(16 of 57 respondents). Of respondent companies that reportedly do not purchase and retire credits, 40% (29 of 71 respondents) stated that this was a key rationale. Of respondent companies that reportedly do not fund BVCM through mechanisms other than carbon credits, 20% (13 of 66 respondents) stated that this was a key rationale. Emerging reputational risk linked to the purchase and retirement of credits was the second highest ranked reason for decreasing purchase and retirement of credits (where just 9 companies reported decreased purchase and retirement of credits).

## Lack of a credible BVCM claims

During the BVCM public consultation period (in June and July 2023), respondents ranked the lack of a credible claim for communicating BVCM activities and investments as the second greatest barrier preventing BVCM deployment. iii Financial institutions highlighted this as the most significant barrier. Almost half (45%) of corporate engagement survey respondents stated that the uncertainty around what investments and activities will count towards claims and targets in the future was a rationale for not purchasing and retiring credits (31 of 71 respondents), and 39% stated this was the rationale for not funding BVCM though other funding mechanisms (26 of 66 respondents).

Desk-based research showed that 'carbon neutral' and 'climate neutral' are historically two of the most widely used claims that relate to BVCM. 30 Typically companies have used the terms carbon or climate neutral to describe the practice of purchasing and retiring carbon credits equivalent to the volume of unabated CO2 or GHG emissions - either at the organizational or product level - in a given period. There are several perspectives on when and if these terms can be used credibly. One view is that the claim provides a business case for companies to go beyond their science-based targets to deliver BVCM, thus accelerating global mitigation. 31 An alternative view is that the claim conceals or downplays the remaining climate impact of businesses that have not fully decarbonized and therefore misleads stakeholders. 32,33

iii Please note that this survey was conducted prior to the release of the Voluntary Carbon Markets Initiative (VCMI) Claims Code of Practice.

Moreover, there are increasing examples of public efforts to regulate corporate climate claims through both law and softer regulatory instruments such as guidance from consumer, competition and financial authorities.

For example, the European Union has announced a ban on advertisements that make 'claims based on emissions offsetting schemes that a product has neutral, reduced or positive impact on the environment' by 2026.

There is an evolving dialogue and growing civil society support for a move away from carbon or climate neutrality claims towards 'contribution claims' that convey to audiences that the organization has provided support or finance to actions beyond the company's value chain with an expected climate mitigation outcome. 34,35,36,37,38  Such contribution claims do not imply that BVCM outcomes are netting out or counterbalancing the claimants' remaining value chain emissions, but instead are communicated as a contribution to global climate mitigation efforts or even the efforts of a country. However, it is not yet clear how much acceptance contribution claims will find with corporate actors and other stakeholder groups. 39

There is clear demand for external validation of high-integrity BVCM claims, with 79% of BVCM corporate engagement survey respondents stating that externally validated claims would incentivize the purchasing and retirement of carbon credits (131 out of 165 respondents).

Noteworthy: Following the corporate survey period, the Voluntary Carbon Markets Integrity Initiative (VCMI) published its Claims Code of Practice (Claims Code) with the purpose of guiding companies and other non-state actors on how they can credibly make voluntary use of high-quality carbon credits as part of their climate commitments and on how they communicate their use of those credits. The Claims Code sets out three types of claims that recognize increasing levels of BVCM (Carbon Integrity Silver, Gold and Platinum) through the purchase and retirement of high-quality carbon credits over and above the company's efforts to reduce their scope 1, 2 and 3 emissions in line with a 1.5°C pathway. VCMI provides a Monitoring, Reporting and Assurance (MRA) Framework, which outlines clear procedures for companies to follow in order to make a VCMI Claim. 40

## Perception of a weak financial business case for BVCM

Perception of a weak financial business case for BVCM was the third-ranked barrier preventing BVCM investment according to the public consultation. Of respondents to the corporate engagement survey that do not purchase and retire credits, 21% cited the lack of economic incentives as a rationale (15 of 71 respondents), and 29% of respondents that do purchase credits highlighted this as a barrier to spending more on carbon credit purchase and retirement (24 of 83 respondents). A smaller number of respondents that do not fund BVCM via other mechanisms cited the lack of economic incentives as a rationale (17%, or 11 of 66 respondents), and 49% of respondents that did cited this as a rationale for not funding more (28 of 57 respondents).

The BVCM interviews and survey responses highlight that while the business case for BVCM does exist, it is not widely understood and it is specific to each company depending on the range of physical and transition climate risks and opportunities that they face.

## Lack of guidance on best practice approaches to BVCM

Respondents to the BVCM public consultation ranked the lack of standardized guidance on minimum standards and best practice as the fourth biggest barrier preventing investment into BVCM. The second most commonly identified recommendation on how the SBTi could incentivize BVCM was to publish clear best practice and minimum practice guidance and tools.

The release of the SBTi report 'Above and Beyond: An SBTi report on the design and implementation of beyond value chain mitigation (BVCM)' was developed to address this barrier (as well as other barriers discussed such as the fear of greenwashing accusation), offering recommendations to companies on how to design and implement high-integrity and high-impact BVCM strategies. The VCMI Claims Code of Practice was also developed to address these barriers, by providing Carbon Integrity Silver, Gold and Platinum BVCM claims and a Monitoring, Reporting and Assurance (MRA) Framework.

## Lack of available funds to deliver BVCM

Respondents to the BVCM public consultation ranked the lack of available funds as the fifth biggest barrier preventing investment into BVCM. This was also a topic which was highlighted in the workshop on BVCM incentives and barriers held at New York Climate Week in 2023; attendees stated that, despite ambition to take on BVCM, limited internal resources (human and financial) presented constraints. Similarly, attendees highlighted barriers to long-term decision-making given the focus on quarterly financial results.

Nearly half (48%) of corporate engagement respondents stated that within value chain mitigation was a preferred focus and thus represented a barrier to spending more on carbon credits (40 out of 83 respondents). Of respondent companies that reportedly fund BVCM through other mechanisms, 39% stated this was a reason for not funding more (22 of 57 respondents), while 55% of respondents stated this was a reason for not purchasing or retiring carbon credits (39 of 71 respondents), and 33% stated this was a reason for not funding BVCM via other mechanisms (20 of 66 respondents).

## Lack of investor demand

Respondents to the BVCM public consultation ranked the lack of investor demand as the sixth biggest barrier to BVCM. However, just 8% of corporate survey respondents that already purchase carbon credits (7 of 83 respondents), and 13% of those that reportedly do not purchase carbon credits (9 of 71 respondents) cited this as a barrier. A quarter of respondents that fund BVCM via other mechanisms (14 of 57 respondents), and 15% of those which do not fund BVCM via other mechanisms cited this as a barrier (10 of 66 respondents).

The interviews conducted with investor groups on this topic, highlighted that unlocking investor demand for BVCM will depend on strong casemaking as to how BVCM helps to manage physical and transition climate-related financial risk across their portfolios.

<!-- image -->

## Lack of consumer and/or customer demand

Respondents to the BVCM public consultation ranked the lack of consumer demand as the seventh biggest barrier preventing investment into BVCM, and lack of business-to-business (B2B) customer demand as the eighth biggest barrier.

The green premium is the extra price producers can extract - and customers are willing to pay - over and above other price 'extras' such as those relating to the physical characteristics or carbon costs associated with producing a commodity. 41  Corporate engagement survey respondents cited the lack of evidence for a green premium (i.e., a lack of consumer demand) to be a barrier to spending more on carbon credits (22%, or 18 of 83 respondents) or in funding BVCM via other mechanisms (28%, or 16 of 57 respondents). For the respondents that reportedly do not purchase and retire carbon credits, 21% (15 of 71 respondents) stated this was a key rationale, while just 14% (9 of 66 companies) stated this was a reason for not funding BVCM via other mechanisms.

## Perception of environmental and social risks associated with BVCM

Many companies that were interviewed highlighted recent scientific publications and high-profile media campaigns that raise concerns about the environmental integrity of carbon crediting projects and certification methodologies. This has raised concerns that the carbon credits that companies are purchasing may not deliver the climate mitigation outcomes that they claim to, creating a reputational risk for companies making claims based on these activities.

While this was raised consistently throughout interviews, the perception of environmental and social risks associated with BVCM was ranked as the ninth biggest barrier to BVCM. However, corporate engagement survey respondents did raise concerns about the supply-side quality of carbon credits and identified this as a barrier to spending more on carbon credits (42%, or 35 of 83 respondents) and a rationale for not purchasing or retiring carbon credits (41%, or 29 of 71 respondents). It is worth highlighting the various initiatives working to enhance the supply-side integrity of carbon credits including the Integrity Council for Voluntary Carbon Markets (ICVCM), the Tropical Forest Credit Integrity (TFCI) Guide and the Carbon Credit Quality Initiative (CCQI).

## Lack of policy incentives

Corporate engagement survey respondents stated that the lack of current policy incentives represents a barrier to spending more on either carbon credits (33%, or 27 of 83 respondents) or non-credit based BVCM (40%, or 23 of 57 respondents) and a rationale for not purchasing and retiring carbon credits (18%, or 13 of 71 respondents) and not providing non-credit based BVCM finance (14%, or 9 of 66 respondents).

## NEW INCENTIVES MECHANISMS

The research highlighted a number of potential new incentive mechanisms that could accelerate implementation of BVCM by the private sector. Tax incentives and certification of BVCM claims were identified as two of the most significant potential incentives in the SBTi's public consultation on BVCM. Figure 3 below shows the results from this consultation, with 170 respondents ranking a list of potential incentive mechanisms. The results are shown for respondents that represent corporates, financial institutions, small and medium sized enterprises (SMEs) and all other organization types (including e.g., NGOs, policymakers, research and academia).

Figure 3. BVCM public consultation responses to the question 'in your opinion, what new incentive mechanisms could be most impactful in driving BVCM investment?"

<!-- image -->

## Tax incentives

Respondents to the BVCM public consultation ranked tax incentives as the top potential incentive mechanism for driving investment into BVCM. In particular, financial institutions ranked this highly.

Corporate engagement survey respondents highlighted tax incentives as the third most significant factor to incentivize (i) companies to start purchasing and retiring carbon credits; and (ii) companies already financing BVCM through non-credit based mechanisms to make further investments. Tax incentives were deemed the sixth most significant factor to incentivize companies not yet financing BVCM through non-credit based mechanisms to start doing so.

## Assessment and certification of BVCM claims and targets

Respondents to the SBTi BVCM public consultation ranked assessment and certification of BVCM claims as the second most significant incentive mechanism for driving investment into BVCM, and assessment of BVCM targets as the fifth most significant incentive mechanism.

Externally approved claims were also raised as an important incentive in the corporate engagement survey, but less highly rated: claims were identified as the fourth most significant factor to incentivize companies to start purchasing and retiring carbon credits; the fifth most significant factor to incentivize further investment from companies already financing BVCM through non-credit based mechanisms; and the seventh most significant factor for companies not funding BVCM through mechanisms other than carbon credits.

Corporate engagement survey respondents highlighted that some form of recognition or credit from the SBTi would be a valuable incentive. This was deemed to be the second most significant incentivizing factor for companies already financing BVCM through non-credit based mechanisms; the third most significant incentivizing factor for companies not yet financing BVCM through non-credit based mechanisms and the fifth most significant incentivizing factor for companies that do not yet purchase and retire carbon credits.

As noted above, the VCMI Claims Code of Practice was developed to provide an incentive for companies to fund BVCM through standardized claims.

<!-- image -->

## Integration of BVCM reporting requirements into environmental, social and governance (ESG) disclosure frameworks

Desk-based research showed that companies are increasingly required to disclose their climate impacts, risks and opportunities either through voluntary or regulatory means. While disclosure frameworks such as the Global Reporting Initiative (GRI) and CDP have existed for decades, the publication of the Taskforce for Climate-related Financial Disclosures (TCFD) Framework in 2017 and its subsequent adoption by regulators across the world has rapidly increased private sector climate-related disclosures. 42 While reporting requirements on the use of carbon credits is embedded in certain disclosure frameworks, including the CDP climate questionnaire, the International Sustainability Standards Board (ISSB) disclosure requirements and the Transition Plan Taskforce (TPT) disclosure framework, BVCM as a broader concept has yet to be fully integrated. 43,44,45

Respondents to the BVCM public consultation ranked the integration of BVCM into environmental, social and governance (ESG) disclosure frameworks as follows: integration into Sustainability Accounting Standards Board (SASB), GRI and the ISSB disclosure requirements (ranked third), integration into the TCFD framework (ranked eighth), and integration into CDP (ranked ninth).

Meanwhile, the corporate engagement survey results showed that companies deemed guidance for credibly reporting on BVCM investments to be an incentivizing factor, especially for companies either already funding BVCM through non-credit based mechanisms (fifth most significant factor) or who have yet to do so (second most significant factor).

<!-- image -->

## Regulation on BVCM claims

As mentioned above, desk-based research showed that there are increasing examples of public efforts to regulate corporate climate claims through both law and softer regulatory instruments such as guidance from consumer, competition and financial authorities. Prominent examples of new or emerging claims regulation and guidance include:

- The European Parliament and the Council of the EU struck a deal to ban advertisements that make 'claims based on emissions offsetting schemes that a product has neutral, reduced or positive impact on the environment' by 2026. 46  This latest decision concludes negotiations on the Empowering Consumers for the Green Transition (ECGT) directive, which the European Commission published in March 2023, with the intention of updating existing EU consumer protection legislation that was no longer fit for purpose. 47
- France's Decree No. 2022-539, which aims to prevent greenwashing by specifying rules for carbon offsetting and carbon neutrality claims, came into force in January 2023. It requires companies to report annually on their products' life cycle emissions as well as those emissions that are offset. 48
- The US State of California's bill AB-1305 on voluntary carbon market disclosures puts in place disclosure requirements for entities that purchase or use voluntary carbon credits and that make claims regarding the achievement of net-zero emissions, claims that the entity, related entity, or a product is 'carbon neutral,' or makes other claims implying the entity, related entity, or a product does not add net carbon dioxide or greenhouse gases to the climate or has made significant reductions to its carbon dioxide or greenhouse gas emissions. 49
- In December 2022, the US Federal Trade Commission consulted on potential updates to its Green Guides for the Use of Environmental Marketing Claims. In doing so, it requested public comment on four specific issues, of which carbon offsetting was one, explicitly inviting 'comments on whether the revised Guides should provide additional information on related claims and issues'. 50

While claims regulation does pose regulatory risks for companies, it also has the benefit of leveling the playing field and reducing the risk that companies unwittingly make misleading claims and are consequently accused of greenwashing. Respondents to the BVCM public consultation ranked regulation on BVCM claims as the fourth most significant potential incentive mechanism for driving investment into BVCM.

## Consumer-facing campaigns supporting BVCM

Public consultation respondents highlighted consumer-facing campaigns to ensure BVCM is considered part of the social license to operate and to spotlight high ambition companies as the sixth most impactful new incentive mechanism. The corporate engagement survey results consistently demonstrated the power of customer and investor demand in incentivizing BVCM; customer demand was deemed to be the most significant factor in incentivizing companies to start purchasing and retiring carbon credits.

## Development of BVCM standards

Respondents to the BVCM public consultation ranked the development of BVCM standards by dedicated bodies as the seventh most significant potential incentive mechanism for driving investment into BVCM. Standards are valuable for companies as they provide a clear set of criteria that companies have to meet and therefore provide a route for clear, consistent and accurate claims that stakeholders can trust.

TOOLBOX FOR ACCELERATING CORPORATE ADOPTION AND IMPLEMENTATION OF BVCM

<!-- image -->

## TOOLBOX

Based on the findings and suggestions provided by respondents and participants of this research on the BVCM barriers and incentives, the SBTi has produced a toolbox which is designed to guide different actors in incentivizing and accelerating the corporate adoption and implementation of BVCM (Figure 4).

Figure 4: Toolbox for accelerating corporate adoption and implementation of BVCM

<!-- image -->

## RELEVANT ACTORS ACROSS THE ECOSYSTEM

This toolbox can be applied by a range of actors to create a network of influence that encourages companies to deliver BVCM. The table below describes different activities that could be implemented by different actors towards this aim.

## Figure 5: Actors that have a role in incentivizing companies to deliver BVCM

- Policymakers
- Employees
- Investors
- Advocacy NGOs
- Industry associations
- Media
- Citizens
- Consumers
- Research and academia
- Voluntary standards/ frameworks
- Multilateral organizations
- Business-to-business (B2B) customers

## ACTIONS FOR POLICYMAKERS

- Establish networks for knowledge exchange and fund knowledge brokers to connect different stakeholders such as policymakers, researchers, practitioners, businesses and financial institutions to share and exchange knowledge on BVCM, including on the benefits to different stakeholders.
- Establish and/or fund public awareness campaigns on the need for companies to deliver BVCM and the benefits for citizens and consumers. Public awareness campaigns are widely used in healthcare to provide the public with information to promote healthy living.
- Use futures thinking tools such as visioning, foresighting, roadmapping and scenarios to create a set of common aims and objectives for accelerating corporate implementation of BVCM and to describe what the future will be like if BVCM adoption is scaled, and to establish an associated BVCM acceleration strategy.
- Provide training, best-practice guidelines and toolkits to support companies to deliver BVCM.
- Provide government-backed loans to support BVCM investment.
- Establish public-private partnerships and blended finance mechanisms for BVCM.
- Establish public procurement preferences for companies investing in BVCM.
- Provide tax benefits for companies investing in BVCM.
- Implement or signal the potential for future carbon taxing policy (or rising carbon taxes over time).
- Introduce regulations that would require companies (possibly in certain sectors) to deliver a given volume of BVCM.
- Develop governance mechanisms, standards and claims regulation to ensure integrity and to level the playing field to reduce the risk of greenwashing associated with BVCM.
- Implement disclosure requirements that include BVCM.

ENGAGE

## ENABLE

## INCENTIVIZE

## MANDATE

MOBILIZE

ENGAGE

## ENABLE

## INCENTIVIZE

MANDATE

MOBILIZE

ENGAGE

ENABLE

INCENTIVIZE

MANDATE

MOBILIZE

## ACTIONS FOR POLICYMAKERS

- Establish and/or endorse coalitions of leading companies that are deploying BVCM.
- Develop and disclose leaderboards of companies based on their delivery of BVCM.

## ACTIONS FOR FINANCIAL INSTITUTIONS

- Engage in dialogue with portfolio companies to make the business case for BVCM in the context of holistic climate transition planning.
- File shareholder proposals recommending that portfolio companies deliver BVCM and disclose on activities and investments.
- Consider BVCM in the context of investment screening.
- Educate policymakers on BVCM, e.g. facilitating implementation and evaluation of policies; initiating policy discussions to address gaps in regulatory frameworks.
- Insurance companies could commission, conduct and publish research on climate-related risks and the role of BVCM in managing risk.
- Establish BVCM investment funds.
- Endorse and support the development  of mature MRV frameworks for different BVCM investment types.
- Insurance companies could adjust risk premiums for companies demonstrably managing climate-related risks through BVCM.
- Signal investment preferences for companies managing transition risk through BVCM.
- Divest (either fully or partially) from companies failing to take action on BVCM.
- Screen investments based on the company's delivery of BVCM (possibly with minimum levels of investment calibrated based on profit per tCO2e emissions).
- Demonstrate leadership by delivering BVCM.
- Build investor coalitions to raise the voice of the investor community collectively on BVCM and/or integrate BVCM as a topic of engagement into existing investor coalitions.

## ACTIONS FOR ADVOCACY NGOS

- Develop materials and engage with a wide range of stakeholders to raise awareness as to the benefits of BVCM.
- Advocate for an enabling policy environment to accelerate BVCM adoption, including an exploration of the role of tax incentives and public procurement preferences.
- Endorse and/or support the development of best practice guidance on BVCM.
- Run campaigns highlighting the need for laggard companies to raise the bar on ambition.
- Highlight and champion leading companies delivering BVCM.
- N/A
- Run mobilization campaigns encouraging businesses to take action on BVCM.

| ACTIONS FOR INDUSTRY ASSOCIATIONS   | ACTIONS FOR INDUSTRY ASSOCIATIONS                                                                                                                                                         |
|-------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ENGAGE                              | Commission research and engage with corporate members to highlight sector-specific benefits and opportunities linked to BVCM. Engage with policymakers on BVCM on behalf of corporations. |
| ENABLE                              | Support the development of sector-specific guidance on BVCM and encourage companies to deliver BVCM.                                                                                      |
| INCENTIVIZE                         | Provide membership benefits contingent on companies delivering BVCM.                                                                                                                      |
| MANDATE                             | Establish minimum standards on BVCM for member companies.                                                                                                                                 |
| MOBILIZE                            | Run mobilization campaigns encouraging membersandthe broader industry as to the benefits of BVCM.                                                                                         |

## ACTIONS FOR MEDIA

| ENGAGE      | Create public awareness campaigns to highlight the benefits of BVCM.                             |
|-------------|--------------------------------------------------------------------------------------------------|
| ENABLE      | Highlight best practice guidance on BVCM to reduce risk of low-integrity approaches.             |
| INCENTIVIZE | Media coverage praising and promoting companies delivering on BVCM.                              |
| MANDATE     | Screen funders (via advertisements and sponsorship) based on BVCM.                               |
| MOBILIZE    | Participate in and support mobilization campaigns encouraging businesses to take action on BVCM. |

## ACTIONS FOR CITIZENS, CONSUMERS AND EMPLOYEES

| ENGAGE      | As citizens, be vocal (e.g., via social media) in raising awareness of BVCM and praising companies delivering BVCM and naming those who are not. As consumers, signal appetite for companies to deliver BVCM through purchasing decisions. As employees, signal appetite for employers to deliver BVCM through employment preferences.   |
|-------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ENABLE      | Give public support to companies delivering BVCM. As employees, encourage employers to include a matching donation strategy for BVCM. Exercise consumer choice in favor of companies delivering BVCM to send demand-signals.                                                                                                             |
| INCENTIVIZE | Use social media to praise companies delivering BVCM and name those who are not. As consumers, demonstrate willingness to opt for higher priced goods that support BVCM. As employees, advocate for corporate support of BVCM.                                                                                                           |
| MANDATE     | As consumers and employees, boycott companies failing As employees, call for performance benefits to be linked As citizens, initiative grassroots campaigns to demand companies net-zero.                                                                                                                                                |
| MOBILIZE    | Human                                                                                                                                                                                                                                                                                                                                    |

|             | ACTIONS FOR RESEARCHERS ANDACADEMICS                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|-------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ENGAGE      | Conduct impartial primary research on the impacts of climate change and biodiversity loss to continue to make the scientific case for BVCM. Conduct impartial research on effective governance mechanisms to ensure BVCM-related climate claims enhance global mitigation outcomes. Conduct impartial research on the effectiveness of different BVCM funding mechanisms (including but not limited to carbon credits) and methodologies for quantifying the climate impact of BVCM funding and provide recommendations on best practice. Conduct consumer market research to identify how BVCMcanincrease brand value and market share. Identify and propose regulatory solutions including the design of tax incentives to promote BVCM. |
| ENABLE      | Develop monitoring and mapping tools to identify areas of high investment impact potential.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| INCENTIVIZE | Through research, highlight high-impact and high-integrity BVCM approaches.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| MANDATE     | N/A                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| MOBILIZE    | Assess and publish evidence of BVCM results, e.g., through impartial research on the cost benefit analysis of BVCM investments and activities.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| ACTIONS FOR | VOLUNTARY STANDARD SETTERS ANDFRAMEWORKDEVELOPERS                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ENGAGE      | Advise policymakers to ensure the enabling conditions are right for BVCM. Through public consultation and standard development, articulate the need for companies to deliver BVCM and the benefits of doing so.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ENABLE      | Provide detailed guidance and standards on how companies should deliver high impact and high integrity BVCM. Develop monitoring, reporting and verification (MRV) and accounting guidance for BVCM. Establish BVCM pilots to demonstrate best practice and to build knowledge.                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| INCENTIVIZE | Provide recognition for companies delivering BVCM, e.g., through higher ambition tiers and/or by defining and validating high-integrity BVCM claims. Disclose information on whether or not companies are delivering BVCM and their differing levels of ambition and impact.                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| MANDATE     | Include a minimum level of BVCM as a requirement in corporate climate standards.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| MOBILIZE    | Launch mobilization campaigns to encourage adoption of BVCM. The Business Ambition for 1.5°C campaign was an urgent call to action from a global coalition of UNagencies, business and industry leaders for companies to adopt science-based targets and a similar approach could be taken with BVCM. Collaborate and coordinate to ensure a clear and coherent standards ecosystem which mobilizes action.                                                                                                                                                                                                                                                                                                                                |

|                                            | ACTIONS FOR MULTILATERAL ORGANIZATIONS                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
|--------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ENGAGE                                     | Establish networks for knowledge exchange and fund knowledge brokers to connect different stakeholders such as policymakers, researchers, practitioners, businesses and financial institutions to share and exchange knowledge on BVCM, including on the benefits to different stakeholders. Establish and/or fund public awareness campaigns on the need for companies to deliver BVCM and the benefits for citizens and consumers. Public awareness campaigns are widely used in healthcare to provide the public with information to promote healthy living. Use futures thinking tools such as visioning, foresighting, roadmapping and scenarios to create a set of common aims and objectives for accelerating corporate implementation of BVCM and to describe what the future will be like if BVCM adoption is scaled, and to establish an associated BVCM acceleration strategy. |
| ENABLE                                     | Provide training, best-practice guidelines and toolkits to support companies to deliver BVCM. Provide multilateral organization-backed loans to support BVCM investment. Establish public-private partnerships and blended finance mechanisms for BVCM.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| INCENTIVIZE                                | Multilateral organization procurement preferences for companies investing in BVCM. Implement or signal the potential for future carbon taxing policy (or rising carbon taxes over time) across members of the multilateral organization.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| MANDATE                                    | Introduce multilateral organization membership criteria that would require companies (possibly in certain sectors) to deliver a given volume of BVCM. Develop governance mechanisms, standards and claims regulation to ensure integrity and to level the playing field to reduce the risk of greenwashing associated with BVCM. Introduce disclosure requirements of multilateral organization members to require companies to report on BVCM.                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| MOBILIZE                                   | Establish and/or endorse coalitions of leading companies that are deploying BVCM. Develop and disclose leaderboards of companies based on their delivery of BVCM.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ACTIONS FOR BUSINESS-TO-BUSINESS CUSTOMERS | ACTIONS FOR BUSINESS-TO-BUSINESS CUSTOMERS                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| ENGAGE                                     | Include BVCM in the company supplier engagement strategy to exchange knowledge on BVCM, including on the benefits for businesses. Identify shared physical risks in supply chains that can be addressed through supplier/customer BVCM.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ENABLE                                     | Establish platforms for value chain partners to invest in BVCM (e.g. Mastercard Priceless Planet, Stripe 'Climate Orders').                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| INCENTIVIZE                                | Prioritize/incentivize bids from suppliers investing in BVCM. Implement a carbon fee as a percentage of contract value for suppliers not investing in BVCM.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| MANDATE                                    | Mandate suppliers to deliver BVCM.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| MOBILIZE                                   | Support pre-competitive business platforms. For example, the LEAF Coalition brings together forest governments, the private sector, donor governments, Indigenous Peoples and local communities and civil society to raise and deploy the finance needed to tackle deforestation. Another example is Frontier, an advanced market commitment that aims to accelerate the development of carbon removal technologies by guaranteeing future demand for them. Demonstrate leadership by delivering BVCM.                                                                                                                                                                                                                                                                                                                                                                                    |

## CONCLUSION

<!-- image -->

A wide range of actors have a role in achieving the vision of accelerating a critical mass of companies to go beyond science-based targets to also fund and deliver BVCM. This research report sought to highlight the ecosystem of actors and the diversity of actions that could play a role in unlocking corporate investment into BVCM.

The success of the various and diverse suggestions listed above depend on the ease of implementation. Often the actions most likely to be effective are the most difficult to implement. For example, if policymakers were to introduce regulations that would require companies to deliver BVCM, this could be a highly effective motivator. However, given few governments require companies to reduce their own emissions in line with net-zero goals, it is unlikely that government-mandated BVCM would become widespread in the near-term. Interventions could therefore be sequenced so that achieving interim results would be relatively easier to implement and create enabling conditions for interventions that are more long term, impactful and sustainable. For example, NGO-led mobilization campaigns can work to accelerate BVCM voluntary adoption by a small group of leading companies which can pave the way for the ratcheting of voluntary and/or regulatory minimum standards applied to a larger number of companies.

Given the BVCM public consultation results highlighted fear of greenwashing accusation and a lack of credible claims as the most significant barriers preventing companies from funding BVCM, activities that address these barriers are a top priority, including (but not limited to):

- Policymakers, voluntary standard setters and industry associations could provide training, best-practice guidelines, minimum and progressive standard requirements and toolkits to support companies to progressively and responsibly deliver BVCM. As noted in this report, there is recent progress on this front with the release of the SBTi's "Above and Beyond" report on BVCM and the VCMI Claims Code of Practice (as two illustrative examples).
- The media and advocacy or watchdog NGOs can then track and highlight best practices made by companies that adopt these measures to reduce risk of low-integrity implementation of BVCM.
- Policymakers and multilateral organizations could develop governance mechanisms, standards and claims regulation to ensure integrity and to level the playing field to reduce the risk of greenwashing associated with BVCM.
- Voluntary standard setters could develop performance and/or impact standards to audit, monitor, and report on conformity to requirements, including the verifications of achievements made at entry and progressive levels and enable a way to recognize companies delivering on BVCM, e.g., through higher ambition tiers and/or by defining and validating high-integrity BVCM claims.

Tax incentives were ranked as the most significant potential incentive mechanism in the BVCM public consultation and the corporate engagement survey highlighted customer demand as the most significant factor in incentivizing companies to start purchasing and retiring carbon credits. Priority actions could therefore include the following:

- Researchers and academics could propose regulatory solutions including the design of tax incentives to promote BVCM.
- Policymakers could provide tax benefits for companies investing in BVCM and implement or signal the potential for future carbon taxing policy (or rising carbon taxes over time).
- Consumers could signal appetite for companies to deliver BVCM through purchasing decisions. Companies can also signal appetite for their suppliers to deliver BVCM through purchasing decisions and supplier engagement.
- Advocacy and media organizations could create consumer-facing public awareness campaigns to highlight the benefits of BVCM and to praise and promote companies delivering on BVCM.

The intention of this research is to provide suggestions for a wide range of actors as they develop strategies to accelerate corporate adoption of high-integrity and high-impact BVCM. No one actor, nor any one action, will be sufficient to create a norm around BVCM. Every actor has a role in building a network of influence over time that encourages greater climate action by the corporate sector.

Image Source: Ashden / Ashden

<!-- image -->

## REFERENCES

- 1 Science Based Targets initiative. (2023). SBTi Corporate Net-Zero Standard. https:/ /sciencebasedtargets.org/ resources/files/Net-Zero-Standard.pdf
- 2 Ibid.
- 3 IPCC. (2022): Summary for Policymakers. In: Climate Change 2022: Mitigation of Climate Change. Contribution of Working Group III to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change.
- 4 IPCC. (2023). Summary for Policymakers. In: Climate Change 2023: Synthesis Report. Contribution of Working Groups I, II and III to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. https:/ / www.ipcc.ch/report/ar6/syr/downloads/report/IPCC\_AR6\_SYR\_SPM.pdf
- 5 Rockström, J., Gupta, J., Qin, D. et al. (2023). Safe and just Earth system boundaries. Nature. https:/ /doi. org/10.1038/s41586-023-06083-8
- 6 Munich RE. (2023). Climate change and La Nina driving losses: the natural disaster figures for 2022.. https:/ /www.munichre.com/en/company/media-relations/media-information-and-corporate-news/mediainformation/2023/natural-disaster-figures-2022.html
- 7 Climate Policy Initiative (CPI). (2023). Global Landscape of Climate Finance 2023. https:/ /www. climatepolicyinitiative.org/wp-content/uploads/2023/11/Global-Landscape-of-Climate-Finance-2023.pdf
- 8 FAO. (2020). The State of the World's Forests. https:/ /www.fao.org/state-of-forests/en/
- 9 Reardon, T., Echeverria, R., Berdegue J., Minten, B., Liverpool-Taise, S., Tschirley, D., Zilberman, D. (2019). Rapid transformation of food systems in developing regions: Highlighting the role of agricultural research and innovations. Agriculture Systems, Vol. 172. June 2019. https:/ /doi.org/10.1016/j.agsy.2018.01.022; Reardon, T., Bellemare, M.F., Zilberman, D. (220, April 2). How COVID-19 may disrupt food supply chains in developing countries. IFPRI Blog. https:/ /www.ifpri.org/blog/how-covid-19-may-disrupt-food-supply-chains-developingcountries
- 10  CPI. (2023). Op cit.
- 11  Ecosystem Marketplace. (2023). All in on Climate: The Role of Carbon Credits in Corporate Climate Strategies. https:/ /www.ecosystemmarketplace.com/articles/em-insights-briefings-corporate-buyers-report/
- 12  CPI. (2019). Global Landscape of Climate Finance 2019. https:/ /www.climatepolicyinitiative.org/publication/ global-landscape-of-climate-finance-2019/; CPI. (2023). Op cit.
- 13  Munich RE. Op cit.
- 14  Roe, S., Streck, C., Beach, R., Busch, J., Chapman, M., Daioglou, V., Deppermann, A., Doelman, J., Emmet-Booth, J., Engelmann, J., Fricko, O., Frischmann, C., Funk, J., Grassi, G., Griscom, B., Havlik, P., Hanssen, S., Humpenöder, F., Landholm, D., … Lawrence, D. (2021). Land-based measures to mitigate climate change: Potential and feasibility by country. Global Change Biology, 27, 6025-6058. https:/ /doi.org/10.1111/gcb.15873
- 15  Global Commission on Adaptation. (2019). Adapt Now: A Global Call for Leadership on Climate Resilience. https:/ /gca.org/wp-content/uploads/2019/09/GlobalCommission\_Report\_FINAL.pdf
- 16  Gupta, S., D. A. Tirpak, N. Burger, J. Gupta, N. Höhne, A. I. Boncheva, G. M. Kanoan, C. Kolstad, J. A. Kruger, A. Michaelowa, S. Murase, J. Pershing, T. Saijo, A. Sari. (2007). Policies, Instruments and Co-operative Arrangements. In IPCC (2007): Climate Change 2007 - Mitigation. Contribution of Working Group III to the Fourth Assessment Report of the Intergovernmental Panel on Climate Change. https:/ /www.ipcc.ch/site/ assets/uploads/2018/02/ar4-wg3-chapter13-2.pdf
- 17  Setzer, J. and Higham, C. (2023). Global Trends in Climate Change Litigation: 2023 Snapshot. London: Grantham Research Institute on Climate Change and the Environment and Centre for Climate Change Economics and Policy, London School of Economics and Political Science. https:/ /www.lse.ac.uk/granthaminstitute/ wp-content/uploads/2023/06/Global\_trends\_in\_climate\_change\_litigation\_2023\_snapshot.pdf

- 18  United Nations. (1992).  Rio Declaration on Environment and Development. Report of the United Nations Conference on Environment and Development. https:/ /www.un.org/en/development/desa/population/ migration/generalassembly/docs/globalcompact/A\_CONF.151\_26\_Vol.I\_Declaration.pdf
- 19  Gupta, S. et al. Op cit.
- 20  Thomson Reuters. (2023). How tax credits can be used to capitalize on the Green Transition. https:/ /www. thomsonreuters.com/en-us/posts/esg/tax-credits-green-transition/
- 21  Financial Exclusions Tracker. https:/ /financialexclusionstracker.org/
- 22  Bain &amp; Company. (2022). Purpose-led Brands Can Reshape the Consumer Goods Industry if They Can Scale… https:/ /www.bain.com/insights/purpose-led-brands-can-reshape-the-consumer-goods-industry-if-they-canscale/
- 23  Ibid.
- 24  Forman, A. (2021, 16 December). Boosting Charitable Giving Can Also Boost Profits. MIT Sloan Management Review. https:/ /sloanreview.mit.edu/article/boosting-charitable-giving-can-also-boost-profits/
- 25  Perez, L. et al. (2022, 10 August). Does ESG really matter - and why? McKinsey Quarterly. https:/ /www.mckinsey. com/capabilities/sustainability/our-insights/does-esg-really-matter-and-why
- 26  Chamberlain, A. (2017, March 6). Why Do Employees Stay? A Clear Career Path and Good Pay, for Starters. Harvard Business Review. https:/ /hbr.org/2017/03/why-do-employees-stay-a-clear-career-path-and-good-payfor-starters
- 27  Bain. Op cit.
- 28  Global Newswire. (2023, July 3). Global Climate Tech Market is expected to generate worth of USD 182.54 billion at CAGR of 24.5% during forecast period 2023 to 2033. https:/ /www.globenewswire.com/newsrelease/2023/07/04/2698797/0/en/Global-Climate-Tech-Market-is-expected-to-generate-worth-of-US-182-54Billion-at-CAGR-of-24-5-during-forecast-period-2023-to-2033-Data-by-Future-Market-Insights-Inc.html
- 29  Trouwloon, D., Streck, C., Chagas, T. and Martinus, G. (2023). Understanding the Use of Carbon Credits by Companies: A Review of the Defining Elements of Corporate Climate Claims. Global Challenges 2023 (7). https:/ /doi.org/10.1002/gch2.202200158
- 30  Ibid.
- 31  Burns, D., Langer, P. et al. (2022, June 2). Guidance on Voluntary Use of Nature-based Solution Carbon Credits Through 2040. https:/ /www.wri.org/technical-perspectives/guidance-voluntary-use-nature-based-solutioncarbon-credits-through-2040
- 32  BEUC. (2023). A Climate-Neutral Food Basket: Too Good to Be True? https:/ /www.beuc.eu/sites/default/files/ publications/BEUC-X-2023-025\_A\_climate-neutral\_food\_basket-Too\_good\_to\_be\_true.pdf
- 33  Committee of Advertising Practice (CAP). (2023) The Environment: misleading claims and social responsibility in advertising.  Advertising Guidance. https:/ /www.asa.org.uk/static/d819e399-3cf9-44ea942b82d5ecd6dff3/4d3c736f-1e59-471f-bf77e10614544b3b/CAP-guidance-on-misleading-environmentalclaims-and-social-responsibility.pdf
- 34  Government of the Netherlands. (2023, December 10). COP28: Netherlands, Germany, France, Spain, Finland, the federal government of Belgium and Austria propose framework to prevent greenwashing and restore integrity in voluntary carbon markets. https:/ /www.government.nl/latest/news/2023/12/10/cop28-netherlandsgermany-france-spain-finland-belgium-and-austria-propose-framework-to-prevent-greenwashing-and-restoreintegrity-in-voluntary-carbon-markets
- 35  Hewlett, O., Magrath, D., Hamilton, E., Leugers, S., &amp; Ballantyne, J. (2023). Fairly Contributing to Global Net Zero

Considerations for Credible Claims. Gold Standard. https:/ /www.goldstandard.org/sites/default/files/fairly\_ contributing\_to\_global\_net\_zero\_-\_considerations\_for\_credible\_claims.pdf

- 36  South Pole. (2023, June 27). South Pole calls for businesses to align around new future-proof green claim: Funding Climate Action. (Press release). https:/ /www.southpole.com/news/south-pole-calls-for-businesses-toalign-around-new-future-proof-green-claim-funding-climate-action
- 37  WWF. (2022). Reimagining how carbon credits fit into voluntary climate strategies. (Briefing paper).  https:/ / wwfint.awsassets.panda.org/downloads/briefing\_paper\_\_\_reimagining\_how\_carbon\_credits\_fit\_into\_ voluntary\_climate\_strategies.pdf
- 38  New Climate Institute. (2023). A Guide to Climate Contributions: Taking Responsibility for Emissions Without Offsetting. https:/ /newclimate.org/resources/publications/a-guide-to-climate-contributions-takingresponsibility-for-emissions
- 39  Trouwloon, D. et al. Op cit.
- 40  Voluntary Carbon Markets Integrity Initiative (VCMI). (2023). Claims Code - Supplementary Guidance. https:/ / vcmintegrity.org/wp-content/uploads/2023/11/Claims-Code-Supplementary-Guidance-November-2023.pdf
- 41  CRU. (2023, March 9). Demystifying green premia. https:/ /sustainability.crugroup.com/article/demystifyinggreen-premia
- 42  Financial Stability Board. (2023). Progress Report on Climate-Related Disclosures.  https:/ /www.fsb.org/ wp-content/uploads/P121023-1.pdf
- 43  CDP Climate Change 2023 Questionnaire. https:/ /guidance.cdp.net/en/tags?cid=46&amp;ctype=theme&amp;gettag s=0&amp;idtype=ThemeID&amp;incchild=1&amp;microsite=0&amp;otype=Questionnaire&amp;page=1&amp;tgprompt=TG-124%2CTG127%2CTG-125
- 44  International Sustainability Standards Board (ISSB). (2023). IFRS S2: Climate-related Disclosures. https:/ /www. ifrs.org/content/dam/ifrs/publications/pdf-standards-issb/english/2023/issued/part-a/issb-2023-a-ifrs-s2climate-related-disclosures.pdf?bypass=on
- 45  Transition Plan Taskforce (TPT). (2023). Disclosure Framework. https:/ /transitiontaskforce.net/wp-content/ uploads/2023/10/TPT\_Disclosure-framework-2023.pdf
- 46  European Parliament News. (2023, September 19). EU to ban greenwashing and improve consumer information on product durability. https:/ /www.europarl.europa.eu/news/en/press-room/20230918IPR05412/eu-to-bangreenwashing-and-improve-consumer-information-on-product-durability
- 47  European Commission Directorate-General for Justice and Consumers. (2022). Proposal for a Directive on empowering consumers for the green transition and annex. https:/ /commission.europa.eu/publications/ proposal-directive-empowering-consumers-green-transition-and-annex\_en
- 48  Legifrance. (2022). Décret n° 2022-539 du 13 avril 2022 relatif à la compensation carbone et aux allégations de neutralité carbone dans la publicité https:/ /www.legifrance.gouv.fr/jorf/id/JORFTEXT000045570611
- 49  California Legislative Information. (2023). Assembly Bill No. 1305 - Voluntary carbon market disclosures. https:/ / leginfo.legislature.ca.gov/faces/billTextClient.xhtml?bill\_id=202320240AB1305
- 50  Federal Register. (2022). Guides for the Use of Environmental Marketing Claims. https:/ /www.federalregister. gov/documents/2022/12/20/2022-27558/guides-for-the-use-of-environmental-marketing-claims

<!-- image -->

For general information and technical queries contact us at: info@sciencebasedtargets.org

<!-- image -->

/science-based-targets

<!-- image -->

Partner Organizations:

<!-- image -->

<!-- image -->

Science Based Targets

<!-- image -->

sciencebasedtargets.org

In collaboration with:

<!-- image -->

<!-- image -->