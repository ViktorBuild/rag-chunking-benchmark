---
document_id: eu_eed_2023_1791
title: "Directive (EU) 2023/1791 on Energy Efficiency (EED Recast)"
category_id: 4
category_name: "Carbon Accounting & ESG Methodologies (CO2 & ESG)"
source_organization: "European Parliament and Council"
year: 2023
original_file: "eu_energy_efficiency_directive_2023_1791.pdf"
tables_detected: 20
converted_with: "Docling v2.32 (TableFormer)"
---

EN

<!-- image -->

## DIRECTIVES

## DIRECTIVE (EU) 2023/1791 OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL

## of 13 September 2023

on energy efficiency and amending Regulation (EU) 2023/955 (recast)

(Text with EEA relevance)

THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,

Having regard to the Treaty on the Functioning of the European Union, and in particular Article 194(2) thereof,

Having regard to the proposal from the European Commission,

After transmission of the draft legislative act to the national Parliaments,

Having regard to the opinion of the European Economic and Social Committee ( ), 1

Having regard to the opinion of the Committee of the Regions ( ), 2

Acting in accordance with the ordinary legislative procedure ( ), 3

## Whereas:

- (1) Directive  2012/27/EU  of  the  European  Parliament  and  of  the  Council ( ) has  been  substantially  amended  several 4 times ( ). Since further amendments are to be made, that Directive should be recast in the interests of clarity. 5
- (2) In  its  communication  of  17  September  2020 on  'Stepping  up  Europe's  2030  climate  ambition  -  Investing  in  a climate-neutral  future  for  the  benefit  of our  people'  (the  'Climate  Target  Plan'),  the  Commission  proposed  to raise the Union's climate ambition by increasing the greenhouse gas (GHG) emissions target to at least 55 % below 1990 levels by 2030. That is a substantial increase compared to the existing 40 % reduction target. The proposal delivered on the commitment made in the communication of the Commission of 11 December 2019 on 'The European Green Deal'  (the  'European  Green  Deal')  to  put  forward  a  comprehensive  plan  to  increase  the  Union's  target  for  2030 towards 55 % in a responsible way. It is also in accordance with the objectives of the Paris Agreement adopted on 12 December 2015 under the United Nations Framework Convention on Climate Change (the 'Paris Agreement') to keep the global temperature increase to well below 2 °C and pursue efforts to keep it to 1,5 °C.

( 1 ) OJ C 152, 6.4.2022, p. 134.

( 2 ) OJ C 301, 5.8.2022, p. 139.

- ( 3 ) Position of the European Parliament of 11 July 2023 (not yet published in the Official Journal) and decision of the Council of 25 July 2023.
- ( 4 ) Directive  2012/27/EU  of  the  European  Parliament  and  of  the  Council  of  25  October  2012  on  energy  efficiency,  amending Directives 2009/125/EC and 2010/30/EU and repealing Directives 2004/8/EC and 2006/32/EC (OJ L 315, 14.11.2012, p. 1).
- ( 5 ) See Part A of Annex XVI.

EN

- (3) The  conclusions  of  the  European  Council  of  10-11  December  2020 endorsed  the  Union's  binding  domestic reduction  target  for  net  GHG  emissions  of  at  least  55  %  by  2030  compared  to  1990.  The  European  Council concluded that the climate ambition needed to be raised in a manner that would spur sustainable economic growth, create  jobs,  deliver  health  and  environmental  benefits  for  Union  citizens,  and  contribute  to  the  long-term  global competitiveness of the Union's economy by promoting innovation in green technologies.
- (4) To implement those objectives, the Commission, in its communication of 19 October 2020 on 'Commission Work Programme  2021  -  A  Union  of  vitality  in  a  world  of  fragility',  announced  a  legislative  package  to  reduce  GHG emissions by at least 55 % by 2030 (the 'Fit for 55 package'), and to achieve a climate-neutral European Union by 2050.  That  package  covers  a  range  of  policy  areas  including  energy  efficiency,  renewable  energy,  land  use,  land change and forestry, energy taxation, effort sharing and emissions trading.
- (5) The purpose of the Fit for 55 package is to safeguard and create jobs in the Union and to enable the Union to become a world leader in the development and uptake of clean technologies in the global energy transition, including energy efficiency solutions.
- (6) Projections indicate that, with the full implementation of current policies, GHG emission reductions by 2030 would be around 45 % compared to 1990 levels, when excluding land use emissions and absorptions, and around 47 %, when including them. The Climate Target Plan therefore provides for a set of required actions across all sectors of the economy and revisions of the key legislative instruments to reach that increased climate ambition.
- (7) In its communication of 28 November 2018 on 'A Clean Planet for all - A European strategic long-term vision for a prosperous, modern, competitive and climate neutral economy', the Commission stated that energy efficiency is a key area of action, without which the full decarbonisation of the Union's economy cannot be achieved. The need to capture  the  cost-effective  energy  saving  opportunities  has  led  to  the  Union's  current  energy  efficiency  policy.  In December  2018,  a  new  2030  Union  headline  energy  efficiency  target  of  at  least  32,5  %,  compared  to  projected energy use in 2030, was included as part of  the Clean Energy for All Europeans package, which aimed at putting energy efficiency first, achieving global leadership in renewable energies and providing a fair deal for consumers.
- (8) The impact assessment accompanying the Climate Target Plan demonstrated that, to achieve the increased climate ambition, energy efficiency improvements will need to be significantly raised from the current level of 32,5 %.
- (9) An increase in the Union's 2030 energy efficiency target can reduce energy prices and be crucial in reducing GHG emissions,  accompanied  by  an  increase  and  uptake  of  electrification,  hydrogen,  e-fuels  and  other relevant technologies  necessary  for  the  green  transition,  including  in  the  transport  sector.  Even  with  the  rapid  growth  of renewable electricity  generation, energy efficiency can  reduce  the  need  of  new  power  generation  capacity and  the costs relating to storage, transmission and distribution. Increased energy efficiency is also particularly important for the security of the energy supply of the Union, by lowering the Union's dependence on the import of fuels from third countries. Energy  efficiency is one  of the cleanest and  most  cost-efficient measures  by  which  to  address that dependence.
- (10) The sum of national contributions communicated by Member States in their national energy and climate plans falls short  of  the  Union's  target  of  32,5  %.  The  contributions  would  collectively  lead  to  a  reduction  of  29,7  %  for primary  energy  consumption  and  29,4  %  for  final  energy  consumption  compared  to  the  projections  from  the Commission's  2007  EU  Reference  Scenario  for  2030.  That  would  translate  in  a  collective  gap  of  2,8  percentage points for primary energy consumption and 3,1 percentage points for final energy consumption for the EU-27.

EN

- (11) A  number  of  Member  States  presented  ambitious  national  energy  and  climate  plans,  which  were  assessed  by  the Commission as 'sufficient', and which contained measures that allow those Member States to contribute to reaching the  collective  targets  for  energy  efficiency  with  a  ratio  larger  than  the  Union  average.  In  addition,  a  number  of Member States have documented 'early efforts' in achieving energy savings, namely energy savings above the Union average  trajectories  in  the  last  years.  Both  cases  are  significant  efforts  that  should  be  recognised  and  should  be included in the Union's future modelling projections and that can serve as good examples of how all Member States can work on their energy efficiency potential to deliver significant benefits to their economies and societies.
- (12) In  some cases, the assumptions used by the Commission in its 2020 EU Reference Scenario and the assumptions used by some Member States for their reference scenarios underpinning their national energy and climate plans are different.  This  may  lead  to  divergences  as  regards  the  calculation  of  primary  energy  consumption  but  both approaches are valid with regard to primary energy consumption.
- (13) While the energy savings potential remains large in all sectors, there is a particular challenge relating to transport, as it  is  responsible  for  more  than  30  %  of  final  energy  consumption,  and  to  buildings,  since  75  %  of  the  Union's building  stock  has  a  poor  energy  performance.  Another  increasingly  important  sector  is  the  information  and communications technology (ICT) sector, which is responsible for 5 to 9 % of  the world's total electricity use and more  than  2  %  of  global  emissions.  In  2018,  data  centres  accounted  for  2,7  %  of  the  electricity  demand  in  the EU-28. In that context, the Commission, in its communication of 19 February 2020 on 'Shaping Europe's digital future'  (the  'Union's  Digital  Strategy'),  highlighted  the  need  for  highly energy-efficient  and  sustainable  data  centres and  transparency  measures  for  telecoms  operators  as  regards  their  environmental  footprint.  Furthermore,  the possible  increase  in  industry's  energy  demand  that  may  result  from  its  decarbonisation,  particularly  for  energy intensive processes, should also be taken into account.
- (14) The higher level of ambition requires a stronger promotion of cost-effective energy efficiency measures in all areas of the energy system and in all relevant sectors where activity affects energy demand, such as the transport, water and agriculture  sectors.  Improving  energy  efficiency  throughout  the  full  energy  chain,  including  energy  generation, transmission, distribution and end-use, will benefit the environment, improve air quality and public health, reduce GHG emissions, improve energy security by decreasing the need for energy imports, in particular of fossil fuels, cut energy costs  for  households  and  companies,  help  alleviate  energy  poverty,  and  lead  to  increased  competitiveness, more  jobs  and  increased  economic  activity  throughout  the  economy.  Improving  energy  efficiency  would  thus improve citizens' quality of life, while contributing to the transformation of the Union's energy relations with thirdcountry  partners  towards  achieving  climate  neutrality.  That  complies  with  the  Union  commitments  made  in  the framework  of  the  Energy  Union  and  global  climate  agenda  established  by  the  Paris  Agreement.  Improving  the energy performance of various sectors has the potential of fostering urban regeneration, including improvement of buildings,  and  changes  in  mobility  and  accessibility  patterns,  while  promoting  more  efficient,  sustainable  and affordable options.
- (15) This Directive takes a step forward towards climate neutrality by 2050, under which energy efficiency is to be treated as an energy source in its own right. The energy efficiency first principle is an overarching principle that should be taken into account across all sectors, going beyond the energy system, at all levels, including in the financial sector. Energy  efficiency  solutions  should  be  considered  as  the  first  option  in  policy,  planning  and  investment  decisions when setting new rules for the supply side and other policy areas. While the energy efficiency first principle should be  applied  without  prejudice  to  other  legal  obligations,  objectives  and  principles,  such  obligations,  objectives  and principles should not hamper its application or lead to exemptions from applying the principle. The Commission should ensure that energy efficiency and demand response can compete on equal terms with generation capacity. Energy efficiency improvements need to be made whenever they are more cost-effective than equivalent supply-side solutions. That should help exploit the multiple benefits of energy efficiency for the Union, in particular for citizens and  businesses.  Implementing  energy  efficiency  improvement  measures  should  also  be  a  priority  in  alleviating energy poverty.

EN

- (16) Energy  efficiency  should  be  recognised  as  a  crucial  element  and  a  priority  consideration  in  future  investment decisions  on  the  Union's  energy  infrastructure.  The  energy  efficiency  first  principle  should  be  applied  taking  into consideration primarily the system efficiency approach and societal and health perspective, and paying attention to security  of  supply,  energy  system  integration  and  the  transition  to  climate  neutrality.  Consequently,  the  energy efficiency  first  principle  should  help  increase  the  efficiency of  individual  end-use  sectors  and  of  the  whole  energy system. The application of the principle should also support investments in energy-efficient solutions contributing to the environmental objectives of Regulation (EU) 2020/852 of the European Parliament and of the Council ( ). 6
- (17) The energy efficiency first principle is provided for in Regulation (EU) 2018/1999 of the European Parliament and of the Council ( ) and is at the core of the EU Strategy for Energy System Integration established in the Commission's 7 communication  of  8  July  2022.  While  the  principle  is  based  on  cost-effectiveness,  its  application  has  wider implications from the societal perspective. Those implications can vary depending on the circumstances and should be  carefully  evaluated  through  robust  cost-benefit  analysis  methodologies  that  take  into  account  the  multiple benefits of energy efficiency. The Commission has prepared dedicated guidelines for  the operation and application of  the  principle,  by  proposing  specific  tools  and  examples  of  application  in  various  sectors.  The  Commission  has also  issued  a  recommendation  to  Member  States  that  builds  on  the  requirements  laid  down  in  this  Directive  and calls  for  specific  actions  in  relation  to  the  application  of  the  principle.  Member  States  should  take  the  utmost account of that recommendation and be guided by it in implementing the energy efficiency principle in practice.
- (18) The  energy  efficiency  first  principle  implies  adopting  a  holistic  approach,  which  takes  into  account  the  overall efficiency of the integrated energy system, security of supply and cost effectiveness and promotes the most efficient solutions  for  climate  neutrality  across  the  whole  value  chain,  from  energy  production,  network  transport  to  final energy  consumption,  so  that  efficiencies  are  achieved  in  both  primary  energy  consumption  and  final  energy consumption. That approach should look at the system performance and dynamic use of energy, where demandside resources and system flexibility are considered to be energy efficiency solutions.
- (19) In order to have an impact, the energy efficiency first principle needs to be consistently applied by national, regional, local and sectoral decision makers in all relevant scenarios and policy, planning and major investment decisions that  is  to  say  large-scale  investments  with  a  value  of  more  than  EUR  100 000 000 each or  EUR  175 000 000 for transport infrastructure projects - affecting energy consumption or supply. The proper application of the principle requires using the right cost-benefit analysis methodology, setting enabling conditions for energy efficient solutions and proper monitoring. Cost-benefit analyses should be systematically developed and carried out, should be based on the most up-to-date information on energy prices and should include scenarios for rising prices, such as due to decreasing Union's emission trading system (EU ETS) allowances pursuant to Directive 2003/87/EC of the European Parliament  and  of  the  Council ( ),  in  order  to  provide  an  incentive  to  apply  energy  efficiency  measures.  Priority 8 should  be  given  to  demand-side  solutions  where  they  are  more  cost-effective  than  investments  in  energy  supply infrastructure  in  meeting  policy objectives.  Demand-side  flexibility can  bring  wider  economic,  environmental  and societal benefits to consumers and to society at large, including local communities, and can increase the efficiency of  the  energy  system  and  decrease  the  energy  costs,  for  example  by  reducing  system  operation  costs  resulting  in lower  tariffs  for  all  consumers.  Member  States  should  take  into  account  potential  benefits  from  demand-side flexibility  in  applying  the  energy  efficiency  first  principle  and  where  relevant  consider  demand  response  at  both centralised and decentralised level, energy storage, and smart solutions as part of their efforts to increase efficiency of the integrated energy system.

( 6 ) Regulation (EU) 2020/852 of the European Parliament and of the Council of 18 June 2020 on the establishment of a framework to facilitate sustainable investment, and amending Regulation (EU) 2019/2088 (OJ L 198, 22.6.2020, p. 13).

( 7 ) Regulation (EU) 2018/1999 of the European Parliament and of the Council of 11 December 2018 on the Governance of the Energy Union and Climate Action, amending Regulations (EC) No 663/2009 and (EC) No 715/2009 of the European Parliament and of the Council,  Directives  94/22/EC,  98/70/EC,  2009/31/EC,  2009/73/EC,  2010/31/EU,  2012/27/EU  and  2013/30/EU  of  the  European Parliament and of the Council, Council Directives 2009/119/EC and (EU) 2015/652 and repealing Regulation (EU) No 525/2013 of the European Parliament and of the Council (OJ L 328, 21.12.2018, p. 1).

( 8 ) Directive 2003/87/EC of the European Parliament and of the Council of 13 October 2003 establishing a system for greenhouse gas emission allowance trading within the Union and amending Council Directive 96/61/EC (OJ L 275, 25.10.2003, p. 32).

EN

- (20) When assessing the values of projects for the purpose of the application of the energy efficiency first principle, the Commission, in its report to the European Parliament and to the Council, should assess, in particular, whether and in what manner the thresholds are effectively applied in each Member State.
- (21) The energy efficiency first principle should always be applied in a proportional way and the requirements laid down in this Directive should not entail overlapping or conflicting obligations on Member States, where the application of the  principle  is  ensured  directly  by  other  legislation.  This  might  be  the  case  for  the  projects  of  common  interest included in the Union list pursuant to Article 3 of Regulation (EU) 2022/869 of the European Parliament and of the Council ( ), which introduces the requirements to consider  the energy efficiency first principle in the development 9 and assessment for those projects.
- (22) A fair transition towards a climate-neutral Union by 2050 is central to the European Green Deal. Energy poverty is a key  concept  in  the  Clean  Energy  for  All  Europeans  package  and  designed  to  facilitate  a  just  energy  transition. Pursuant  to  Regulation  (EU)  2018/1999  and  Directive  (EU)  2019/944  of  the  European  Parliament  and  of  the Council ( 10 ),  the  Commission, in  its  Recommendation (EU)  2020/1563 on energy poverty ( 11 ),  provided  indicative guidance on appropriate indicators for measuring energy poverty and defining a 'significant number of households in  energy  poverty'.  Directive  2009/73/EC  of  the  European  Parliament  and  of  the  Council ( 12 ) and  Directive (EU)  2019/944  require  Member  States  to  take  appropriate  measures  to  address  energy  poverty  wherever  it  is identified, including measures addressing the broader context of poverty. This is particularly relevant in a context of rising energy prices and inflationary pressure, where both short and long-term measures should be implemented to address systemic challenges to the Union's energy system.
- (23) People  facing  or  risking  energy  poverty,  vulnerable  customers,  including  final  users,  low-  and  medium-income households,  and  people  living  in  social  housing  should  benefit  from  the  application  of  the  energy  efficiency  first principle.  Energy  efficiency  measures  should  be  implemented  as  a  priority  to  improve  the  situations  of  those individuals and households and to alleviate energy poverty, and should not encourage any disproportionate increase in  housing,  mobility  or  energy  costs.  A  holistic  approach  in  policy  making  and  in  implementing  policies  and measures  requires  Member  States  to  ensure  that  other  policies  and  measures  have  no  adverse  effect  on  those individuals and households.
- (24) This  Directive  is  part  of  a  broader  policy  framework  of  energy  efficiency  policies  addressing  energy  efficiency potentials in specific policy areas, including buildings (Directive 2010/31/EU of the European Parliament and of the Council ( 13 )),  products (Directive 2009/125/EC of the European Parliament and of the Council ( 14 ) and Regulations (EU)  2017/1369 ( 15 ) and  (EU)  2020/740 ( 16 ) of  the  European  Parliament  and  of  the  Council),  and  governance (Regulation (EU) 2018/1999). Those policies play a very important role in delivering energy savings when products are replaced or buildings constructed or renovated.

( 9 ) Regulation (EU) 2022/869 of the European Parliament and of the Council of 30 May 2022 on guidelines for trans-European energy infrastructure,  amending  Regulations  (EC)  No  715/2009,  (EU)  2019/942  and  (EU)  2019/943  and  Directives  2009/73/EC  and (EU) 2019/944, and repealing Regulation (EU) No 347/2013 (OJ L 152, 3.6.2022, p. 45).

- ( 10 ) Directive (EU) 2019/944 of the European Parliament and of the Council of 5 June 2019 on common rules for the internal market for electricity and amending Directive 2012/27/EU (OJ L 158, 14.6.2019, p. 125).
- ( 11 ) Commission Recommendation (EU) 2020/1563 of 14 October 2020 on energy poverty (OJ L 357, 27.10.2020, p. 35).
- ( 12 ) Directive  2009/73/EC  of  the  European  Parliament  and  of  the  Council  of  13  July  2009  concerning  common  rules  for  the  internal market in natural gas and repealing Directive 2003/55/EC (OJ L 211, 14.8.2009, p. 94).
- ( 13 ) Directive  2010/31/EU  of  the  European  Parliament  and  of  the  Council  of  19  May  2010  on  the  energy  performance  of  buildings (OJ L 153, 18.6.2010, p. 13).
- ( 14 ) Directive 2009/125/EC of the European Parliament and of the Council of 21 October 2009 establishing a framework for the setting of ecodesign requirements for energy-related products (OJ L 285, 31.10.2009, p. 10).
- ( 15 ) Regulation (EU) 2017/1369 of the European Parliament and of the Council of 4 July 2017 setting a framework for energy labelling and repealing Directive 2010/30/EU (OJ L 198, 28.7.2017, p. 1).
- ( 16 ) Regulation (EU) 2020/740 of the European Parliament and of the Council of 25 May 2020 on the labelling of tyres with respect to fuel efficiency and other parameters, amending Regulation (EU) 2017/1369 and repealing Regulation (EC) No 1222/2009 (OJ L 177, 5.6.2020, p. 1).

EN

- (25) Reaching an ambitious energy efficiency target requires barriers to be removed in order  to facilitate investment in energy  efficiency measures.  The  Clean  Energy  Transition  sub-programme  of  the  Union's  LIFE  Programme, established by Regulation (EU) 2021/783 of the European Parliament and of the Council ( 17 ),  will  dedicate funding to support development of Union best practices in energy efficiency policy implementation, addressing behavioural, market, and regulatory barriers to energy efficiency.
- (26) The European Council, in its conclusion of 23 and 24 October 2014, supported a 27 % energy efficiency target for 2030  at  Union  level,  to  be  reviewed  by  2020  having  in  mind  a  Union-level  target  of  30  %.  In  its  resolution  of 15  December  2015 entitled 'Towards  a European  Energy  Union',  the  European  Parliament  called  on  the Commission to assess, in addition, the viability of a 40 % energy efficiency target for the same timeframe.
- (27) In its communication of 28 November 2018 on 'A Clean Planet for all - A European strategic long-term vision for a prosperous, modern, competitive and climate neutral economy', the Commission projects that the 32,5 % Union's energy  efficiency  target  for  2030  and  the  other  policy  instruments  of  the  existing  framework  would  lead  to  a reduction in GHG emissions of about 45 % by 2030. For an increased climate ambition of a 55 % decrease of GHG emissions by 2030, the impact assessment of the Climate Target Plan assessed what level of efforts would be needed in the different policy areas. It concluded that, in relation to the baseline, achieving the GHG emissions target in a cost-optimal way meant that primary energy consumption and final energy consumption are to decrease by at least 39 to 41 % and 36 to 37 % respectively.
- (28) The  Union's  energy  efficiency  target  was  initially  set  and  calculated  using  the  2007  EU  Reference  Scenario projections  for  2030  as  a  baseline.  The  change  in  the  Eurostat  energy  balance  calculation  methodology  and improvements in subsequent modelling projections call for a change of the baseline. Thus, using the same approach to define the target, namely by comparing it to the future baseline projections, the ambition of  the Union's 2030 energy efficiency target is set compared to the 2020 EU Reference Scenario projections for 2030 reflecting national contributions from the national energy and climate plans. With that updated baseline, the Union will need to further increase its energy efficiency ambition by at least 11,7 % in 2030 compared to the level of efforts under the 2020 EU Reference Scenario. The new way of expressing the level of ambition for the Union's targets does not affect the actual level of efforts needed and corresponds to a reduction of 40,5 % for primary energy consumption and 38 % for final energy consumption when compared to the 2007 EU Reference Scenario projections for 2030.
- (29) The methodology for calculation of primary energy consumption and final energy consumption is aligned with the new Eurostat methodology, but the indicators used for the purpose of this Directive have a different scope, in that they exclude ambient energy and include energy consumption in international aviation for  the targets in primary energy  consumption  and  final  energy  consumption.  The  use  of  new  indicators  also  implies  that  any  changes  in energy consumption of blast furnaces are now only reflected in primary energy consumption.
- (30) The need for  the Union to improve its energy efficiency should be expressed in primary energy consumption and final energy consumption, to be achieved in 2030, indicating an additional level of efforts required when compared to  the  measures  in  place  or  planned  measures  in  the  national  energy  and  climate  plans.  The  2020  EU  Reference Scenario  projects  864  Mtoe  of  final  energy  consumption  and  1 124 Mtoe  of  primary  energy  consumption  to  be reached in 2030 (excluding ambient energy and including international aviation). An additional reduction of 11,7 % results in 763 Mtoe and 992,5 Mtoe in 2030. Compared to 2005 levels, it means that final energy consumption in the  Union  should  be  reduced  by  approximately  25  %  and  primary  energy  consumption  should  be  reduced  by approximately 34 %. There are no binding targets at Member State level in the 2020 and 2030 perspectives, and Member States should establish their contributions to the achievement of the Union's energy efficiency target taking

( 17 ) Regulation  (EU)  2021/783  of  the  European  Parliament  and  of  the  Council  of  29  April  2021  establishing  a  Programme  for  the Environment and Climate Action (LIFE), and repealing Regulation (EU) No 1293/2013 (OJ L 172, 17.5.2021, p. 53).

EN

into account the formula provided for in this Directive. Member States should be free to set their national objectives based either on primary energy consumption or final energy consumption or primary energy savings or final energy savings, or on energy intensity. This Directive amends the way in which Member States should express their national contributions  to  the  Union's  target.  Member  States'  contributions  to  the  Union's  target  should  be  expressed  in primary energy consumption and final energy consumption to ensure consistency and monitoring of progress. A regular evaluation of progress towards the achievement of the Union's 2030 targets is necessary and is provided for in Regulation (EU) 2018/1999.

- (31) By 30 November 2023, the Commission should update the 2020 EU Reference Scenario based on the latest Eurostat data. Member  States  wishing  to  use the updated  reference scenario should  notify their updated  national contributions by 1 February 2024, as part of the iterative process provided for in Regulation (EU) 2018/1999.
- (32) It would be preferable for the energy efficiency targets to be achieved as a result of the cumulative implementation of specific  Union  and  national  measures  promoting  energy  efficiency  in  different  fields.  Member  States  should  be required  to  set  national  energy  efficiency  policies  and  measures.  Those  policies  and  measures  and  the  individual efforts  of  each  Member  State  should  be  evaluated  by  the  Commission,  alongside  data  on  the  progress  made,  to assess  the  likelihood  of  achieving  the  overall  Union  target  and  the  extent  to  which  the  individual  efforts  are sufficient to meet the common goal.
- (33) The public sector is responsible for approximately 5 % to 10 % of the Union's total final energy consumption. Public authorities  spend  approximately EUR 1 800 000 000 000 every year. This represents around 14 % of  the Union's gross  domestic  product.  For  that  reason  the  public  sector  constitutes  an  important  driver  to  stimulate  market transformation towards more efficient products, buildings and services, as well as to trigger behavioural changes in energy  consumption  by  citizens  and  enterprises.  Furthermore,  decreasing  energy  consumption  through  energy efficiency  improvement  measures  can  free  up  public  resources  for  other  purposes.  Public  bodies  at  national, regional and local level should fulfil an exemplary role as regards energy efficiency.
- (34) To  lead  by  example,  the  public  sector  should  set  its  own  decarbonisation  and  energy  efficiency  goals.  Energy efficiency improvements in the public sector should reflect the efforts required at Union level. To comply with the final  energy  consumption  target,  the  Union  should  decrease  its  final  energy  consumption  by  19  %  by  2030  as compared to the average energy consumption in years 2017, 2018 and 2019. An obligation to achieve an annual reduction  of  the  energy  consumption  in  the  public  sector  by  at  least  1,9  %  should  ensure  that  the  public  sector fulfils its exemplary role. Member States retain full flexibility regarding the choice of energy efficiency improvement measures  to  achieve  a  reduction  of  the  final  energy  consumption.  Requiring  an  annual  reduction  of  final  energy consumption has a lower administrative burden than establishing measurement methods for energy savings.
- (35) To  fulfil  their  obligation,  Member  States  should  target  the  final  energy  consumption  of  all  public  services  and installations of public bodies. To determine the scope of addressees, Member States should apply the definition of 'public bodies' provided for in this Directive, where 'directly financed by those authorities' means that those entities are mostly funded by public funds and 'administered by those authorities' means that a national, regional or local authority has a majority with regard to the choice of the entity's management. The obligation can be fulfilled by the reduction  of  final  energy  consumption  in  any  area  of  the  public  sector,  including  transport,  public  buildings, healthcare,  spatial  planning,  water  management  and  wastewater  treatment,  sewage  and  water  purification,  waste management,  district  heating  and  cooling,  energy  distribution,  supply  and  storage,  public  lighting,  infrastructure planning, education and social services. Member States may also include other  types of services when transposing this  Directive.  To  lower  the  administrative  burden  for  public  bodies,  Member  States  should  establish  digital platforms  or  tools  to  collect  the  aggregated  consumption  data  from  public  bodies,  make  them  publicly  available, and  report  the  data  to  the  Commission.  Member  States  should  provide  planning  and  annual  reporting  on  the consumption of public bodies in an aggregated form per sector.

EN

- (36) Member States should promote energy efficient means of mobility, including in their public procurement practices, such as rail, cycling,  walking  or shared mobility, by renewing and decarbonising fleets, encouraging a modal shift and including those modes in urban mobility planning.
- (37) Member States should exercise an exemplary role by ensuring that all energy performance contracts, energy audits and  energy  management  systems  are  carried  out  in  the  public  sector  in  line  with  European  or  international standards, or that energy audits are used to a large extent in energy-intense parts of the public sector. Member States should provide guidance and should provide for procedures for the use of those instruments.
- (38) Public authorities are encouraged to obtain support from entities such as sustainable energy agencies established at regional or local level, where applicable. The organisation of those agencies usually reflects the individual needs of public  authorities  in  a  certain  region  or  operating  in  a  certain  area  of  the  public  sector.  Centralised  agencies  can serve  the  needs  better  and  work  more  effectively  in  other  respects,  for  example,  in  smaller  or  centralised  Member States  or  regarding  complex  or  cross-regional  aspects  such  as  district  heating  and  cooling.  Sustainable  energy agencies  can  serve  as  one-stop  shops.  Those  agencies  are  often  responsible  for  developing  local  or  regional decarbonisation plans, which may also include other decarbonisation measures, such as the exchange of fossil fuel boilers,  and  for  supporting  public  authorities  in  the  implementation  of energy-related policies. Sustainable  energy agencies  or  other  entities  to  assist  regional  and  local  authorities  may  have  clear  competences,  objectives  and resources in the field of sustainable energy. Sustainable energy agencies could be encouraged to consider initiatives taken in the framework of the Covenant of Mayors, which brings together local governments voluntarily committed to  implementing  the  Union's  climate  and  energy  objectives,  and  other  existing  initiatives  for  that  purpose.  The decarbonisation plans should be linked to territorial  development plans and take into account the comprehensive assessment which the Member States should carry out.
- (39) Member States should support public bodies in planning and the uptake of energy efficiency improvement measures, including  at regional  and  local  level, by  providing  guidelines  promoting  competence-building  and  training opportunities and encouraging cooperation amongst public bodies including amongst agencies. For  that purpose, Member  States  could  set  up  national  competence  centres  on  complex  issues,  such  as  advising  local  or  regional energy  agencies  on  district  heating  or  cooling.  The  requirement  to  transform  buildings  into  nearly  zero-energy buildings  does  not  exclude  or  prohibit  a  differentiation  between  nearly  zero-energy  building  levels  for  new  or renovated buildings. Nearly zero-energy buildings, including the cost-optimal level, are defined in Directive 2010/31/EU.
- (40) Until the end of 2026, Member States that renovate more than 3 % of the total floor area of their buildings in any given  year  should  be  given  the  possibility  to  count  the  surplus  towards  the  annual  renovation  rate  of  any  of  the three  following  years.  A  Member  State  that  renovates  more  than  3  %  of  the  total  floor  area  of  its  buildings  from 1 January 2027 should be able to count the surplus towards the annual renovation rate of the following two years. That  possibility  should  not  be  used  for  purposes  that  are  not  in  line  with  the  general  objectives  and  the  level  of ambition of this Directive.
- (41) Member States should encourage public bodies to take into account the wider benefits beyond energy savings, such as  the  quality of  the  indoor  environment as well as an improvement of people's quality of  life and the comfort of renovated public buildings, in particular schools, day care centres, nursing homes, sheltered housing, hospitals, and social housing.
- (42) Buildings and transport, alongside industry, are the main energy users and main source of emissions. Buildings are responsible  for  about  40  %  of  the  Union's  total  energy  consumption  and  for  36  %  of  its  GHG  from  energy.  The Commission  communication  of  14  October  2020,  entitled  'Renovation  Wave'  addresses  the  twin  challenge  of energy  and  resource  efficiency  and  affordability  in  the  building  sector  and  aims  to  double  the  renovation  rate.  It focuses on the worst performing buildings, energy poverty and on public buildings. Moreover, buildings are crucial to achieving the Union objective of reaching climate neutrality by 2050. Buildings that are owned by public bodies account  for  a  considerable  share  of  the  building  stock  and  have  high  visibility  in  public  life.  It  is  therefore appropriate to set an annual rate of renovation of buildings that are owned by public bodies on the territory of a

EN

Member State to upgrade their energy performance and be transformed into at least nearly zero-energy buildings or zero-emission buildings. Member States are invited to set a higher renovation rate, where that is cost-effective in the framework of  the  renovation  of  their  buildings  stock  in  accordance  with  their  long-term  renovation  strategies  or national renovation programmes, or both. That renovation rate should be without prejudice to the obligations with regard to nearly zero-energy buildings set out in Directive 2010/31/EU. Member States should be able to apply less stringent requirements to some buildings, such as buildings with special architectural or historical merit. During the next review of Directive 2010/31/EU, the Commission should assess the progress Member States achieved regarding the  renovation  of  public  bodies'  buildings.  The  Commission  should  consider  submitting  a  legislative  proposal  to revise  the  renovation  rate,  while  taking  into  account  the  progress  achieved  by  the  Member  States,  substantial economic  or  technical  developments,  or  where  needed,  the  Union's  commitments  for  decarbonisation  and  zero pollution. The obligation to renovate public bodies' buildings in this Directive complements that in Directive  2010/31/EU,  which  requires  Member  States  to  ensure  that  when  existing  buildings  undergo  major renovation  their  energy  performance  is  upgraded  so  that  they  meet  the  requirements  on  nearly  zero-energy buildings.

- (43) Building automation and control systems and other solutions to provide active energy management are important tools  for  public  bodies  to  improve  and  maintain  the  energy  performance  of  buildings,  as  well  as  ensuring  the necessary indoor conditions in the buildings they own or occupy, in accordance with Directive 2010/31/EU.
- (44) Promoting green mobility is a key part of the European Green Deal. The provision of charging infrastructure is one of  the  necessary  elements  in  the  transition.  Charging  infrastructure  in  buildings  is  particularly  important  since electric  vehicles  park  in  buildings  regularly  and  for  long  periods  of  time,  thus  making  charging  easier  and  more efficient. Public bodies should make best efforts to install charging infrastructure in buildings they own or occupy in accordance with Directive 2010/31/EU.
- (45) To set the rate of renovations, Member States need to have an overview of the buildings that do not reach the nearly zero-energy  buildings  level.  Therefore,  Member  States  should  publish  and  keep  updated  an  inventory  of  public buildings,  including,  where  appropriate,  social  housing,  as  part  of  an  overall  database  of  energy  performance certificates.  That  inventory  should  also  enable  private  actors,  including  energy  service  companies  (ESCOs),  to propose renovation solutions, which can be aggregated by the EU Building Stock Observatory.
- (46) The inventory could integrate data from existing building stock inventories. Member States should take appropriate measures to facilitate data collection and make the inventory accessible to private actors, including ESCOs to enable their  active  role  in  renovation  solutions.  Available  and  publicly  shared  data  about  building  stock  characteristics, buildings renovation and energy performance may be aggregated by the EU Building Stock Observatory to ensure a better understanding of the energy performance of the building sector through comparable data.
- (47) In  2020,  more  than  half of  the  world's  population  lived  in  urban  areas.  That  figure  is  expected  to  reach  68  %  by 2050. In addition, half of  the urban infrastructures by 2050 are still to be built. Cities and metropolitan areas are centres of economic activity, knowledge generation, innovation and new technologies. Cities influence the quality of life  of the  citizens  who  live  or  work  in  them.  Member  States  should  support  municipalities  technically  and financially.  A  number  of  municipalities  and  other  public  bodies  in  the  Member  States  have  already  put  into place integrated  approaches  to  energy  saving  and  energy  supply  and  sustainable  mobility,  for  example  via  sustainable energy  action  plans  or  sustainable  urban  mobility  plans,  such  as  those  developed  under  the  Covenant  of  Mayors initiative,  and  integrated  urban  approaches  which  go  beyond  individual  interventions  in  buildings  or  transport modes.  Further  efforts  are  needed  in  the  area  of  improving  the  energy  efficiency  of  urban  mobility,  for  both passenger and freight transport, as it uses around 40 % of all road transport energy.

EN

- (48) All  the  principles  of  Directives  2014/23/EU ( 18 ),  2014/24/EU ( 19 ) and 2014/25/EU ( 20 ) of  the  European  Parliament and of the Council remain fully applicable within the framework of this Directive.
- (49) With regard to the purchase of certain products and  services  and  the  purchase  and  rent of  buildings,  contracting authorities  and  contracting  entities  which  conclude  public  works,  supply  or  service  contracts  should  lead  by example and make energy-efficient  purchasing  decisions  and  apply  the  energy  efficiency  first  principle,  including for  those  public  contracts  and  concessions  for  which  no  specific  requirements  are  provided  for  in  this  Directive. This should apply to contracting authorities and contracting entities falling within the scope of Directives 2014/23/EU, 2014/24/EU or 2014/25/EU. Member States should remove barriers to joint procurement within a Member State or across borders if this can reduce the costs and enhance the benefits of the internal market by creating business opportunities for suppliers and energy service providers.
- (50) All public entities investing public resources through procurement should lead by example when awarding contracts and concessions by choosing products, buildings, works and services with the highest energy efficiency performance,  also in relation to those procurements  that  are not subject to specific requirements  under Directive  2009/30/EC.  In  that  context,  all  award  procedures  for  public  contracts  and  concessions  with  a  value above  the  thresholds  set  out  in  Article  8  of  Directive  2014/23/EU,  Article  4  of  Directive  2014/24/EU,  and Article  15  of  Directive  2014/25/EU need to take into account the energy efficiency performance of  the products, buildings and services set by Union or national law, by considering as priority the energy efficiency first principle in their procurement procedures.
- (51) It  is  also  important that Member States monitor how the energy efficiency requirements are taken into account by contracting  authorities  and  contracting  entities  in  the  procurement  of  products,  buildings,  works  and  services  by ensuring that information about the impact on the energy efficiency of those winning tenders above the thresholds referred to in the procurement directives are made publicly available. That would allow stakeholders and citizens to assess the role of the public sector in ensuring energy efficiency first in public procurement in a transparent manner.
- (52) The  obligation  for  Member  States  to  ensure  that  contracting  authorities  and  entities  purchase  only  products, buildings, works and services with high energy efficiency performance should not, however, prevent Member States from purchasing goods necessary to protect, and respond to, public security or public health emergencies.
- (53) The  European  Green  Deal  recognises  the  role of the circular economy  in  contributing  to  overall  Union decarbonisation  objectives.  The  public  sector  and,  in  particular,  the  transport  sector,  should  contribute  to  those objectives  by  using  their  purchasing  power  to,  where  appropriate,  choose  environmentally  friendly  products, buildings,  works  and  services  via  available  tools  for  green  public  procurement,  and  thus  making  an  important contribution to reduce energy consumption and environmental impacts.
- (54) It is important that Member States provide the necessary support to public bodies in the uptake of energy efficiency requirements in public procurement and, where appropriate, in the use of green public procurement by providing necessary guidelines and methodologies on carrying out the assessment of life-cycle costs and environment impacts and costs. Well-designed tools, in particular digital tools, are expected to facilitate the procurement procedures and reduce the administrative costs especially in smaller Member States that may not have sufficient capacity to prepare tenders.  In  this  regard,  Member  States  should  actively  promote  the  use  of  digital  tools  and  cooperation  amongst contracting authorities including across borders for the purpose of exchanging best practices.

( 18 ) Directive  2014/23/EU  of  the  European  Parliament  and  of  the  Council  of  26  February  2014  on  the  award  of  concession  contracts (OJ L 94, 28.3.2014, p. 1).

( 19 ) Directive  2014/24/EU  of  the  European  Parliament  and  of  the  Council  of  26  February  2014  on  public  procurement  and  repealing Directive 2004/18/EC (OJ L 94, 28.3.2014, p. 65).

( 20 ) Directive 2014/25/EU of the European Parliament and of the Council of 26 February 2014 on procurement by entities operating in the water, energy, transport and postal services sectors and repealing Directive 2004/17/EC (OJ L 94, 28.3.2014, p. 243).

EN

20.9.2023

- (55) Given that buildings are responsible for GHG emissions before and after their operational lifetime, Member States should also consider the whole life cycle of carbon emissions of buildings. That should take place in the context of efforts to increase the attention given to whole life-cycle performance, circular economy aspects and environmental impacts, as part of the exemplary role of the public sector. Public procurement can thus serve as an opportunity to address the embodied carbon in buildings over their life cycle. In this regard, contracting authorities are important actors  that  can  take  action  as  part  of  procurement  procedures  by  purchasing  new  buildings  that  address  global warming potential over the full life cycle.
- (56) The global warming potential over  the full life cycle measures  the GHG emissions associated with the building at different stages along its life cycle. It therefore measures the building's overall contribution to emissions that lead to climate  change.  That  is  sometimes  referred  to  as  a  carbon  footprint  assessment  or the  whole  life  carbon measurement. It brings together carbon emissions embodied in building materials with direct and indirect carbon emissions from use stage. Buildings are a significant material bank, being repositories for carbon intensive resources over many decades, and so it is important to explore designs that facilitate future reuse and recycling at the end of the operational life in line with the new circular economy action plan. Member States should promote circularity, durability, and adaptability of building materials, in order to address the sustainability performance of construction products.
- (57) The global warming potential is expressed as a numeric indicator in kgCO eq/m 2 2 (of useful internal floor area) for each  life-cycle  stage  averaged  for  one  year  of  a  reference  study  period  of  50  years.  The  data  selection,  scenario definition and calculations are carried out in accordance with standard EN 15978. The scope of building elements and technical equipment are set out in indicator 1,2 of  the Level(s) common Union framework. Where a national calculation tool exists, or is required for making disclosures or for obtaining building permits, it should be possible to use that national tool to provide the required information. It should be possible to use other calculation tools, if they fulfil the minimum criteria laid down by the Level(s) common Union framework.
- (58) Directive  2010/75/EU  of  the  European  Parliament  and  of  the  Council ( 21 ) lays  down  rules  on  installations  that contribute  to  energy  production  or  use  energy  for  production  purposes,  and  provides  that  information  on  the energy used in or generated by the installation is to be included in applications for integrated permits in accordance with Article 12(1), point (b) of  that Directive.  Moreover, Article 11 of  that Directive provides that efficient use of energy is  one  of  the  general  principles  governing  the  basic  obligations  of  the  operator  and  one  of  the  criteria  for determining best available techniques pursuant to Annex III to that Directive. The operational efficiency of energy systems  at  any  given  moment  is  influenced  by  the  ability  to  feed  power  generated  from  different  sources  with different degrees of inertia and start-up times into the grid smoothly and flexibly. Improving efficiency will enable better use to be made of renewable energy.
- (59) Improvement in energy efficiency can contribute to higher economic output. Member States and the Union should aim to decrease energy consumption regardless of levels of economic growth.
- (60) The energy savings obligation established by this Directive should be increased and should also apply after 2030. That  ensures  stability  for  investors  and  thus  encourages  long-term  investments  and  long-term  energy  efficiency measures,  such  as  the  deep  renovation  of  buildings  with  the  long-term  objective  of  facilitating  the  cost  effective transformation  of  existing  buildings  into  nearly  zero-energy  buildings.  The  energy  savings  obligation  plays  an important  role  in  the  creation  of  local  growth,  jobs,  competitiveness  and  alleviating  energy  poverty.  It  should ensure  that  the  Union  can  achieve  its  energy  and  climate  objectives  by  creating  further  opportunities  and  by breaking  the  link  between  energy  consumption  and  growth.  Cooperation  with  the  private  sector  is  important  to assess  the  conditions  on  which  private  investment  for  energy  efficiency  projects  can  be  unlocked  and  to  develop new revenue models for innovation in the field of energy efficiency.

( 21 ) Directive  2010/75/EU  of  the  European  Parliament  and  of  the  Council  of  24  November  2010  on  industrial  emissions  (integrated pollution prevention and control) (OJ L 334, 17.12.2010, p. 17).

EN

- (61) Energy  efficiency  improvement  measures  also  have  a  positive  impact  on  air  quality,  as  more  energy  efficient buildings  contribute  to  reducing  the  demand  for  heating  fuels,  including  solid  heating  fuels.  Energy  efficiency measures  therefore  contribute  to  improving  indoor  and  outdoor  air  quality  and  help  achieve,  in  a  cost-effective manner, the objectives of the Union's air quality policy, as laid down in particular by Directive (EU) 2016/2284 of the European Parliament and of the Council ( 22 ).
- (62) With  a  view  to  ensuring  a  stable  and  predictable  contribution  towards  achieving  the  Union's  energy  and  climate targets  for  2030  and  the  climate  neutrality objective  for  2050,  Member  States  are  required  to  achieve  cumulative end-use  energy  savings  for  the  entire  obligation  period  up  to  2030,  equivalent  to  new  annual  savings  of  at  least 0,8 % of final energy consumption up to 31 December 2023 and of at least 1,3 % from 1 January 2024, 1,5 % from 1 January 2026 and 1,9 % from 1 January 2028. That requirement could be met by new policy measures that are adopted during the obligation period from 1 January 2021 to 31 December 2030 or by new individual actions as a result  of  policy  measures  adopted  during  or  before  the  previous  period,  provided  that  the  individual  actions  that trigger  energy  savings  are  introduced  during  the  following  period.  To  that  end,  Member  States  should  be  able  to make use of an energy efficiency obligation scheme, alternative policy measures, or both.
- (63) For  the  period  from  1  January  2021 to  31  December  2023,  Cyprus  and  Malta  should  be  required  to  achieve cumulative  end-use  energy  savings  equivalent  to  new  savings  of  0,24  %  of  annual  final  energy  consumption averaged over  the  most  recent  three-year  period  preceding  1  January  2019.  For  the  period  from  1  January  2024 to  31  December  2030,  Cyprus  and  Malta  should  be  required  to  achieve  cumulative  end-use  energy  savings  of 0,45 % of annual final energy consumption, averaged over the most recent three-year period preceding 1 January 2019.
- (64) Where using an obligation scheme, Member States should designate obligated parties among transmission system operators,  distribution  system  operators,  energy  distributors,  retail  energy  sales  companies  and  transport  fuel distributors or  transport fuel retailers on the basis of objective and non-discriminatory criteria. The designation or exemption from designation of certain categories of such entities should not be understood to be incompatible with the principle of non-discrimination. Member States are therefore able to choose whether such entities or only certain categories  thereof are  designated  as  obligated parties.  To  empower and  protect  people affected by energy  poverty, vulnerable customers, people in low-income households and, where applicable, people living in social housing, and to  implement  policy  measures  as  a  priority  among  those  people,  Member  States  can  require  obligated  parties  to achieve  energy  savings  among  those  people.  For  that  purpose,  Member  States  can  also  establish  energy  cost reduction targets. Obligated parties could achieve those targets by promoting the installation of measures that lead to energy savings and financial savings on energy bills, such as the installation of insulation and heating measures, and by supporting energy savings initiatives by renewable energy communities and citizen energy communities.
- (65) When designing policy measures to fulfil the energy savings obligation, Member States should respect the climate and environmental standards and priorities of the Union and comply with the principle of 'do no significant harm' within  the  meaning  of  Regulation  (EU)  2020/852.  Member  States  should  not  promote  activities  that  are  not environmentally sustainable such as the use of fossil fuels. The energy savings obligation aims at strengthening the response to climate change by promoting incentives to Member States to implement a sustainable and clean policy mix, which is resilient, and mitigates climate change. Therefore, energy savings from policy measures regarding the use of direct fossil fuel combustion may be eligible energy savings under the energy savings obligation under certain conditions and for a transitional period following the transposition of this Directive in accordance with an annex to this Directive. It will allow aligning the energy savings obligation with the objectives of the European Green Deal, the Climate  Target  Plan,  the  Renovation  Wave,  and  mirror  the  need  for  action  identified  by  the  International  Energy Agency  in  its  net  zero  report.  The  restriction  aims  at  encouraging  Member  States  to  spend  public  money  into future-proof,  sustainable  technologies  only.  It  is  important  that  Member  States  provide  a  clear  policy  framework and investment certainty to market actors. The implementation of  the calculation methodology under  the energy

( 22 ) Directive  (EU)  2016/2284  of  the  European  Parliament  and  of  the  Council  of  14  December  2016  on  the  reduction  of  national emissions  of  certain  atmospheric  pollutants,  amending  Directive  2003/35/EC  and  repealing  Directive  2001/81/EC  (OJ  L  344, 17.12.2016, p. 1).

EN

savings  obligation  should  allow  all  market  actors  to  adapt  their  technologies  in  a  reasonable  timeframe.  Where Member States support the uptake of efficient fossil fuel technologies or early replacement of such technology, for example  through  subsidy  schemes  or  energy  efficiency  obligation  schemes,  any  resulting  energy  savings  may  no longer  be  eligible  under  the  energy  savings  obligation.  While  energy  savings  resulting,  for  example,  from  the promotion  of  natural  gas-based  cogeneration  would  not  be  eligible  under  the  energy  savings  obligation,  the restriction would not apply for indirect fossil fuel usage, for example where the electricity production includes fossil fuel generation. Policy measures targeting behavioural changes to reduce the consumption of fossil fuels, for example through  information  campaigns  and  eco-driving,  should  remain  eligible.  Policy  measures  which  target  building renovations  may  include  measures  such  as  the  replacement  of  fossil  fuel  heating  systems  together  with  building fabric improvements. Those measures should be limited to technologies that allow the required energy savings to be achieved in accordance with the national building codes established in a Member State. Nevertheless, Member States should  promote  upgrading  heating  systems  as  part  of  deep  renovations  in  line  with  the  long-term  objective  of carbon neutrality, namely reducing the heating demand and covering the remaining heating demand with a carbonfree  energy  source.  When  accounting  for  the  savings  needed  to  achieve  a  share  of  the  energy  savings  obligation among people affected by energy poverty, Member States may take into account their climatic conditions.

- (66) Member  States'  energy  efficiency  improvement  measures  in  transport  are  eligible  to  be  taken  into  account  for achieving  their  end-use  energy  savings  obligation.  Such  measures  include  policies  that  are,  inter  alia,  dedicated  to promoting more efficient vehicles, a modal shift to cycling, walking and collective transport, or mobility and urban planning  that  reduces  demand  for  transport.  In  addition,  schemes  which  accelerate  the  uptake  of  new,  more efficient vehicles or policy measures which foster a shift to fuels with reduced levels of emissions, except schemes or policy  measures  regarding  the  use  of  direct  fossil  fuel  combustion  that  reduce  energy  use  per  kilometre,  are  also capable  of  being  eligible,  subject  to  compliance  with  the  rules  on  materiality  and  additionality  set  out  in  this Directive. Policy measures promoting the uptake of new fossil fuel vehicles should not qualify as eligible measures under the energy savings obligation.
- (67) Measures  taken  by  Member  States  pursuant  to  Regulation  (EU)  2018/842  of  the  European  Parliament  and  of  the Council ( 23 ) and  which  result  in  verifiable  and  measurable  or  estimable  energy  efficiency  improvements  can  be considered to be a cost-effective way for Member States to fulfil their energy savings obligation under this Directive.
- (68) As an alternative to requiring obligated parties to achieve the amount of cumulative end-use energy savings required under  the  energy  savings  obligation  laid  down  in  this  Directive,  it  should  be  possible  for  Member  States,  in  their obligation schemes, to permit or require obligated parties to contribute to a national energy efficiency fund, which could  be  used  to  implement  policy  measures  as  a  priority  among  people  affected  by  energy  poverty,  vulnerable customers, people in low income households and, where applicable, people living in social housing.
- (69) Member States and obligated parties should make use of all available means and technologies, except with regard to the  use  of  direct  fossil  fuel  combustion  technologies,  to  achieve  the  cumulative  end-use  energy  savings  required, including  by  promoting  smart  and  sustainable  technologies  in  efficient  district  heating  and  cooling  systems, efficient  heating  and  cooling  infrastructure,  efficient  and  smart  buildings,  electrical  vehicles  and  industries  and energy  audits  or  equivalent  management  systems,  provided  that  the  energy  savings  claimed  comply  with  this Directive. Member States should aim for a high degree of flexibility in the design and implementation of alternative policy measures. Member States should encourage actions resulting in energy savings over a long lifetime.

( 23 ) Regulation  (EU)  2018/842  of  the  European  Parliament  and  of  the  Council  of  30  May  2018  on  binding  annual  greenhouse  gas emission  reductions  by  Member  States  from  2021  to  2030  contributing  to  climate  action  to  meet  commitments  under  the  Paris Agreement and amending Regulation (EU) No 525/2013 (OJ L 156, 19.6.2018, p. 26).

EN

- (70) Long-term energy efficiency measures continue to deliver energy savings after 2020 but, in order to contribute to the Union's 2030 energy efficiency target, those measures should deliver  new savings after 2020. On the other hand, energy savings achieved after 31 December 2020 should not count towards the cumulative end-use energy savings required for the period from 1 January 2014 to 31 December 2020.
- (71) Additionality is a fundamental underlying principle of the energy savings obligation provided for in this Directive, in so far as it ensures that Member States put in place policies and measures specifically designed for  the purpose of fulfilling the energy savings obligation. New savings should be additional to 'business as usual', so that savings that would  have  occurred  in  any  event  should  not  count  towards  fulfilling  the  energy  savings  obligation.  In  order  to calculate the impact of the measures introduced, only net savings, measured as the change of energy consumption that is directly attributable to the energy efficiency measure in question implemented for the purpose of the energy savings obligation provided for in this Directive, should be counted. To calculate net savings, Member States should establish  a  baseline  scenario  of  how  the  situation  would  evolve  in  the  absence  of  the  measure  in  question.  The policy  measure  in  question  should  be  evaluated  against  that  baseline.  Member  States  should  take  into  account minimum requirements provided by the relevant legislative framework at Union level and the fact that other policy measures  may  be  carried  out  in  the  same  time  frame  which  may  also  have  an  impact  on  the  amount  of  energy savings, so that not all changes observed since the introduction of a particular policy measure can be attributed to that policy measure alone. The actions of the obligated, participating or entrusted party should in fact contribute to the achievement of the energy savings claimed in order to ensure the fulfilment of the materiality requirement.
- (72) It is important to consider, where relevant, all steps in the energy chain in the calculation of energy savings in order to  increase  the  energy  savings  potential  in  the  transmission  and  distribution  of  electricity.  Studies  and  the consultation of stakeholders have revealed a significant potential. However, the physical and economic conditions are  quite  different  among  Member  States,  and  often within  several  Member  States,  and  there  is  a  large number  of system  operators.  Those  circumstances  point  to  a  decentralised  approach,  pursuant  to  the  subsidiarity  principle. National Regulatory Authorities have the required knowledge, legal competences and the administrative capacity to promote  the  development  of  an  energy  efficient  electricity  grid.  Entities  such  as  the  European  Network  of Transmission  System  Operators  for  Electricity  (ENTSO-E)  and  the  European  Entity  for  Distribution  System Operators  can  also  provide  useful  contributions  to,  and  should  support  their  members  in,  the  uptake  of  energy efficiency measures.
- (73) Similar considerations apply for the very large number of natural gas system operators. The role of natural gas and the  rate  of  supply  and  coverage  of  the  territory  is  highly  variable  among  Member  States.  In  those  cases,  National Regulatory Authorities are best placed to monitor and steer  the system evolution towards an increased efficiency, and  entities  such  as  the  European  Network  of  Transmission  System  Operators  for  Gas  can  provide  useful contributions to, and should support their members in, the uptake of energy efficiency measures.
- (74) The role  of  ESCOs  is  important  in  developing,  designing,  building,  and  arranging  financing  for  projects  that  save energy, reduce energy costs, and decrease operations and maintenance costs in sectors such as buildings, industry and transport.
- (75) Consideration of the water-energy nexus is particularly important to address the interdependent use of energy and water  and  the  increasing  pressure  on  both  resources.  The  effective  management  of  water  can  make  a  significant contribution to energy savings yielding not only climate benefits, but also economic and social benefits. The water and wastewater sectors account for 3,5 % of electricity use in the Union and that share is expected to rise. At the same time, water leaks account for 24 % of total water consumed in the Union and the energy sector is the largest consumer of water, accounting for 44 % of consumption. The potential for energy savings through the use of smart technologies and processes across all industrial, residential and commercial water cycles and applications should be fully explored and realised whenever cost-effective, and the energy efficiency first principle should be considered. In addition,  advanced  irrigation  technologies,  rainwater  harvesting  and  water  reuse  technologies  could  substantially reduce water consumption in agriculture, buildings and industry and the energy used for treating and transporting it.

EN

- (76) In  accordance with Article 9 of  the Treaty on the Functioning of  the European Union (TFEU), the Union's energy efficiency policies should be inclusive and should therefore ensure equal access to energy efficiency measures for all consumers  affected  by  energy  poverty.  Improvements  in  energy  efficiency  should  be  implemented  as  a  priority among people affected by energy poverty, vulnerable customers and final users, people in low-income or mediumincome households, people living in social housing, older people as well as people living in rural and remote areas and in the outermost regions. In that context, specific attention should be paid to particular groups which are more at risk of being affected by energy poverty or are more susceptible to the adverse impacts of energy poverty, such as women, persons with disabilities, older  people, children, and people with a minority racial or ethnic background. Member States can require obligated parties to include social aims in energy-saving measures in relation to energy poverty, and this possibility has already been extended to alternative policy measures and national energy efficiency funds. That should be transformed into an obligation to protect and empower vulnerable customers and final users and  to  alleviate  energy  poverty,  while  allowing  Member  States  to  retain  full  flexibility  with  regard  to  the  type  of policy  measure,  its  size,  scope  and  content.  If  an  energy  efficiency  obligation  scheme  does  not  permit  measures relating to individual energy consumers, the Member State may take measures to alleviate energy poverty by means of  alternative  policy  measures  alone.  Within  their  policy  mix,  Member  States  should  ensure  that  other  policy measures do not have an adverse effect on people affected by energy poverty vulnerable customers, final users and, where applicable, people living in social housing. Member States should make best possible use of public funding investments into energy efficiency  improvement measures, including funding and financial facilities established  at Union level.
- (77) Each Member State should define the concept of vulnerable customers, which may refer to energy poverty and, inter alia, to the prohibition of disconnection of electricity to such customers in critical times. The concept of vulnerable customers may include income levels, the share of energy expenditure of disposable income, the energy efficiency of homes,  critical  dependence  on  electrical  equipment  for  health  reasons,  age  or  other  criteria.  This  allows  Member States to include people in low-income households.
- (78) According to Recommendation (EU) 2020/1563, around 34 million households in the Union were unable to keep their  home adequately warm in 2019. The European Green Deal prioritises the social dimension of the transition by  committing  to  the  principle  that  'no  one  is  left  behind'.  The  green  transition,  including  the  clean  transition, affects  women  and  men  differently  and  may  have  a  particular  impact  on  some  disadvantaged  groups  including people  with  disabilities.  Energy  efficiency  measures  must  therefore  be  central  to  any  cost-effective  strategy  to address  energy  poverty  and  consumer  vulnerability  and  are  complementary  to  social  security  policies  at  Member State  level.  To  ensure  that  energy  efficiency  measures  reduce  energy  poverty  for  tenants  sustainably,  the  costeffectiveness  of  such  measures,  as  well  as  their  affordability  to  property owners  and  tenants,  should  be  taken  into account,  and  adequate  financial  and  technical  support  for  such  measures  should  be  guaranteed  at  Member  State level.  Member States should support the local and regional level in identifying and alleviating energy poverty. The Union's building stock needs, in the long term, to be converted to nearly zero-energy buildings in accordance with the objectives of the Paris Agreement. Current building renovation rates are insufficient and buildings occupied by citizens  on  low  incomes  who  are  affected  by energy  poverty  are  the  hardest  to  reach.  The  measures  laid  down  in this Directive with regard to energy savings obligations, energy efficiency obligation schemes and alternative policy measures are therefore of particular importance.
- (79) Member States should strive to ensure that measures to promote or facilitate energy efficiency, in particular  those concerning buildings and mobility, do not lead to a disproportionate increase in the cost of services relating to such measures or to greater social exclusion.
- (80) To  tap  the  energy  savings  potential  in  certain  market  segments  where  energy  audits  are  generally  not  offered commercially, such as small and medium-sized enterprises (SMEs), Member States should develop programmes to encourage and support SMEs to undergo energy audits and to implement the recommendations arising from those energy  audits.  Energy  audits  should  be  mandatory  and  regular  for  enterprises  with  an  average  annual  energy consumption above a certain threshold, as energy savings can be significant. Energy audits should take into account relevant European or international standards, such as EN ISO 50001 (Energy Management Systems), or EN 16247-1 (Energy Audits), or, if including an energy audit, EN ISO 14000 (Environmental Management Systems) and thus be also in accordance with this Directive, which does not go beyond the requirements of  those relevant standards. A

EN

specific European standard on energy audits is currently under development. Energy audits may be carried out on a stand-alone basis or be part of a broader environmental management system or an energy performance contract. In all such cases those systems should comply with the minimum requirements laid down in this Directive. In addition, specific  mechanisms  and  schemes  established  to  monitor  emissions  and  fuel  consumption  by  certain  transport operators, for example under Union law the EU ETS, may be considered compatible with energy audits, including in energy management systems, if they comply with the minimum requirements laid down in this Directive. For those enterprises already implementing the energy audit obligation, energy audits should continue to be carried out at least every four years from the date of the previous energy audit, in accordance with this Directive.

- (81) Member States could establish guidelines for enterprises to follow in implementing measures to achieve new annual savings identified in the energy audit.
- (82) The  enterprise's  average  consumption  should  be  the  criterion  to  define  the  application  of  energy  management systems  and  of  energy  audits  in  order  to  increase  the  sensitivity  of  those  mechanisms  in  identifying  relevant opportunities for cost-effective energy savings. An enterprise that is below the consumption thresholds defined for energy management systems and energy audits should be encouraged to undergo energy audits and to implement the recommendations resulting from those audits.
- (83) Where energy audits are carried out by in-house experts, they should not be directly engaged in the activity audited in order to guarantee their independence.
- (84) Member States should promote the implementation of energy management systems and energy audits within the public administration at national, regional and local level.
- (85) The ICT sector is another important sector which receives increasing attention. In 2018 the energy consumption of data  centres  in  the  Union  was  76,8  TWh.  This  is  expected  to  rise  to  98,5  TWh  by  2030,  a  28  %  increase.  This increase in absolute terms can also be seen in relative terms: within the Union, data centres accounted for 2,7 % of electricity demand in 2018 and will reach 3,21 % by 2030 if development continues on the current trajectory. The Union's  Digital  Strategy  already  highlighted  the  need  for  highly  energy-efficient  and  sustainable  data  centres  and calls  for  transparency  measures  for  telecommunication  operators  on  their  environmental  footprint.  To  promote sustainable development in the ICT sector, particularly of data centres, Member States should require the collection and publication of data which are relevant for the energy performance, water footprint and demand-side flexibility of  data  centres,  on  the  basis  of  a  common  Union  template.  Member  States  should  require  the  collection  and publication of data only about data centres with a significant footprint, for  which appropriate design or efficiency interventions,  for  new  or  existing  installations  respectively,  can  result  in  a  considerable  reduction  of  energy  and water  consumption,  an  increase  in  systems'  efficiency  promoting  decarbonisation  of  the  grid  or  in  the  reuse  of waste heat in nearby facilities and heat networks. Data centre sustainability indicators could be established on the basis of that data collected, taking also into account already existing initiatives in the sector.
- (86) The reporting obligation applies to those data centres, which meet the threshold set out in this Directive. In all cases and specifically for onsite enterprise data centres, the reporting obligation should be understood as referring to the spaces  and  equipment  that  serve  primarily  or  exclusively  for  data-related  functions  (server  rooms),  including  the necessary associated equipment, for example, associated cooling, lighting, battery arrays, or uninterruptible power supplies.  Any  IT  equipment  placed  or  installed  in  primarily  public  access,  common  use  or  office  space  or supporting other corporate functions, such as workstations, laptops, photocopiers, sensors, security equipment, or white  goods  and  audiovisual  appliances  should  be  excluded  from  the  reporting  obligation.  The  same  exclusion should  also  apply  to  server,  networking,  storage,  and  associated  equipment  that  would  be  scattered  across  a  site such as single servers, single racks, or Wi-Fi and networking points.

EN

- (87) The collected data should be used to measure at least some basic dimensions of a sustainable data centre, namely how efficiently  it  uses  energy,  how  much  of  that  energy  comes  from  renewable  energy  sources,  the  reuse  of  any waste  heat  that  it  produces,  the  effectiveness  of  cooling,  the  effectiveness  of  carbon  usage  and  the  usage  of freshwater.  The  collected  data  and  the  sustainability  indicators  should  raise  awareness  among  data  centre  owners and operators, manufacturers of equipment, developers of software and services, users of data centre services at all levels as well as entities and organisations that deploy, use or procure cloud and data centre services. The collected data and the sustainability indicators should also give confidence about the actual improvements following efforts and measures to increase the sustainability in new or existing data centres. Finally, those data and indicators should be used as a basis for transparent and evidence-based planning and decision making. The Commission should assess the efficiency of data centres on the basis of the information communicated by the obligated data centres.
- (88) Following  an assessment, when  establishing the possible sector-specific energy  efficiency partnerships, the Commission  should  bring  together  key  stakeholders,  including  non-governmental  organisations  and  the  social partners, in sectors such as ICT, transport, finance and buildings in an inclusive and representative manner.
- (89) Lower consumer spending on energy  should  be  achieved  by  assisting  consumers  in  reducing  their  energy  use  by reducing  the  energy  needs  of  buildings  and  improvements  in  the  efficiency  of  appliances,  which  should  be combined with the availability of low-energy transport modes integrated with public transport, shared mobility and cycling. Member States should also consider improving connectivity in rural and remote areas.
- (90) It  is  crucial  to  raise  the  awareness  of  all  Union  citizens  about  the  benefits  of  increased  energy  efficiency  and  to provide them with accurate information on the ways in which it can be achieved. Citizens of all ages should also be involved  in  the  energy  transition  via  the  European  Climate  Pact  and  the  Conference  on  the  Future  of  Europe. Increased energy efficiency is also highly important for the security of energy supply of the Union through lowering its dependence on import of fuels from third countries.
- (91) The  costs  and  benefits  of  all  energy  efficiency  measures  taken,  including  pay-back  periods,  should  be  made  fully transparent to consumers.
- (92) When implementing this Directive and taking other measures in the field of energy efficiency, Member States should pay particular attention to synergies between energy efficiency measures and the efficient use of natural resources in line with the principles of the circular economy.
- (93) Taking  advantage  of  new  business  models  and  technologies,  Member  States  should  endeavour  to  promote  and facilitate the uptake of energy efficiency measures, including through innovative energy services for large and small customers.
- (94) It is necessary to provide for frequent and enhanced feedback on energy consumption where technically feasible and cost-efficient  in  view  of  the  measurement  devices  in  place.  This  Directive  clarifies  that  the  cost-efficiency  of  submetering depends on whether the related costs are proportionate to the potential energy savings. The assessment of whether  sub-metering  is  cost-efficient  may  take  into  account  the  effect  of  other  concrete,  planned  measures  in  a given building, such as any forthcoming renovation.
- (95) This Directive also clarifies that rights relating to billing, and information about billing or consumption should apply to  consumers of  heating,  cooling  or  domestic  hot  water  supplied  from  a  central  source  even where  they  have  no direct, individual contractual relationship with an energy supplier.

EN

- (96) In  order  to  achieve  the  transparency  of  accounting  for  individual  consumption  of  thermal  energy,  and  thereby facilitate the implementation of sub-metering, Member States should ensure they have in place transparent, publicly available  national  rules  on  the  allocation  of  the  cost  of  heating,  cooling  and  domestic  hot  water  consumption  in multi-apartment  and  multi-purpose  buildings.  In  addition  to  transparency,  Member  States  could  consider  taking measures  to  strengthen  competition  in  the  provision  of  sub-metering  services  and  thereby  help  ensure  that  any costs borne by the final users are reasonable.
- (97) Newly  installed  heat  meters  and  heat  cost  allocators  should  be  remotely  readable  to  ensure  cost-effective,  and frequent provision of, consumption information. The provisions of this Directive relating to metering for heating, cooling  and  domestic  hot  water;  sub-metering  and  cost  allocation  for  heating,  cooling  and  domestic  hot  water; remote reading requirement; billing and consumption information for heating and cooling and domestic hot water; the  cost  of  access  to  metering  and  billing  and  consumption  information  for  heating,  cooling  and  domestic  hot water; and the minimum requirements for billing and consumption information for heating, cooling and domestic hot  water,  are  intended  to  apply only  to  heating,  cooling  and  domestic  hot  water  supplied  from  a  central  source. Member States are free to decide whether walk-by or drive-by technologies are to be considered remotely readable or not. Remotely readable devices do not require access to individual apartments or units to be read.
- (98) Member  States  should  take  into  account  the  fact  that  the  successful  implementation  of  new  technologies  for measuring  energy  consumption  requires  enhanced  investment  in  education  and  skills  for  both  users  and  energy suppliers.
- (99) Billing information and annual statements are an important means by which customers are informed of their energy consumption. Data on consumption and costs can also convey other information that helps consumers to compare their  current  deal  with  other  offers  and  to  make  use  of  complaint-management  and  alternative  dispute-resolution mechanisms. However, considering that bill-related disputes are a common source of consumer complaints and a factor  which  contributes  to  persistently  low  levels  of  consumer  satisfaction  and  engagement  with  their  energy providers,  it  is  necessary  to  make  bills  simpler,  clearer  and  easier  to  understand,  while  ensuring  that  separate instruments,  such  as  billing  information,  information  tools  and  annual  statements,  provide  all  the  necessary information to enable consumers to regulate their energy consumption, compare offers and switch suppliers.
- (100) When designing energy efficiency improvement measures, Member States should take due account of  the need to ensure the correct functioning of the internal market and the consistent implementation of the acquis , in accordance with the TFEU.
- (101) High-efficiency cogeneration and efficient district heating and cooling have significant potential for saving primary energy  in  the  Union.  Member  States  should  carry  out  a  comprehensive  assessment  of  the  potential  for  highefficiency  cogeneration  and  efficient  district  heating  and  cooling.  Those  assessments  should  be  consistent  with Member States'  integrated  national  energy  and  climate  plans  and  their  long-term  renovation  strategies,  and  could include trajectories leading to a renewable energy and waste heat based national heating and cooling sector within a timeframe  compatible  with  the  achievement  of  the  climate  neutrality  objective.  New  electricity generation installations  and  existing  installations  which  are  substantially  refurbished  or  whose  permit  or  licence  is  updated should,  subject  to  a cost-benefit analysis showing  a  cost-benefit surplus, be  equipped  with  high-efficiency cogeneration units to recover waste heat stemming from the production of electricity. Similarly, other facilities with substantial annual average energy input should be equipped with technical solutions to deploy waste heat from the facility where the cost-benefit analysis shows a cost-benefit surplus. This waste heat could be transported where it is needed  through  district  heating  networks.  The  events  that  trigger  a  requirement  for  authorisation  criteria  to  be applied  will  generally  be  such  as  to  also  trigger  requirements  for  permits  under  Directive  2010/75/EU  and  for authorisation under Directive (EU) 2019/944.

EN

- (102) It  may  be  appropriate  for  electricity  generation  installations  that  are  intended  to  make  use  of  geological  storage permitted under Directive 2009/31/EC of  the  European Parliament and of  the Council ( 24 ) to  be  located  in  places where the recovery of waste heat, through high-efficiency cogeneration or by supplying a district heating or cooling network,  is  not  cost-effective.  Member  States  should  therefore  be  able  to  exempt  those  installations  from  the obligation to carry out a cost-benefit analysis for providing the installation with equipment allowing the recovery of waste  heat  by  means  of  a  high-efficiency  cogeneration  unit.  It  should  also  be  possible  to  exempt  peak-load  and back-up electricity generation installations which are planned to operate under 1 500 operating hours per year as a rolling average over a period of five years from the requirement to also provide heat.
- (103) It is appropriate  for  Member  States  to  encourage  the  introduction  of  measures  and  procedures  to  promote cogeneration  installations  with  a  total  rated  thermal  input  of  less  than  5  MW  in  order  to  encourage  distributed energy generation.
- (104) To  implement  national  comprehensive  assessments,  Member  States  should  encourage  the  assessments  of  the potential  for  high-efficiency  cogeneration  and  efficient  district  heating  and  cooling  at  regional  and  local  level. Member States should take steps to promote and facilitate the realisation of the identified cost-efficient potential of high-efficiency cogeneration and efficient district heating and cooling.
- (105) Requirements for efficient district heating and cooling should be consistent with long-term climate policy goals, the climate and environmental standards and the priorities of the Union, and should comply with the principle of 'do no significant  harm'  within  the  meaning  of  Regulation  (EU)  2020/852.  All  the  district  heating  and  cooling  systems should aim for  improved ability  to interact  with  other  parts  of  the  energy  system in  order  to optimise  the  use  of energy and prevent energy waste by using the full potential of buildings to store heat or cold, including the excess heat  from  service  facilities  and  nearby  data  centres.  For  that  reason,  efficient  district  heating  and  cooling  systems should ensure the increase of primary energy efficiency and a progressive integration of renewable energy and waste heat and cold as defined in Directive (EU) 2018/2001 of the European Parliament and of the Council ( 25 ). Therefore, this  Directive  introduces  progressively  stricter  requirements  for  heating  and  cooling  supply  which  should  be applicable during specific established time periods and should be permanently applicable from 1 January 2050 onwards.
- (106) The principles to calculate the share of the heat or cold from renewable energy sources in efficient district heating and  cooling  should  be  consistent  with  Directive  (EU)  2018/2001  and  Eurostat  methodologies  for  statistical reporting.  Pursuant  to  Article  7(1)  of  Directive  (EU)  2018/2001,  the  gross  final  consumption  of  energy  from renewable sources includes gross final consumption of energy from renewable sources in the heating and cooling sector.  A  gross  final  energy consumption of  heat or  cold  in  district  heating  or  cooling equals  heat or  cold  energy supply going into the network serving the final customers or energy distributors.
- (107) Heat pumps are important for the decarbonisation of the heating and cooling supply, also in district heating. The methodology established in Annex VII to Directive (EU) 2018/2001 provides rules to count energy captured by heat pumps as energy from renewable sources and prevents double counting of the electricity from renewable sources. For the purposes of calculating the share of renewable energy in a district heating network, all the heat originating from the heat pump and going into the network should be accounted as renewable energy, provided that the heat pump meets the minimum efficiency criteria set out in Annex VII to Directive (EU) 2018/2001 at the time of its installation.

( 24 ) Directive 2009/31/EC of the European Parliament and of the Council of 23 April 2009 on the geological storage of carbon dioxide and amending Council Directive 85/337/EEC, European Parliament and Council Directives 2000/60/EC, 2001/80/EC, 2004/35/EC, 2006/12/EC, 2008/1/EC and Regulation (EC) No 1013/2006 (OJ L 140, 5.6.2009, p. 114).

( 25 ) Directive  (EU)  2018/2001  of  the  European  Parliament  and  of  the  Council  of  11  December  2018  on  the  promotion  of  the  use  of energy from renewable sources (OJ L 328, 21.12.2018, p. 82).

EN

- (108) High-efficiency cogeneration has been defined by the energy savings obtained by combined production instead of separate production of heat and electricity. Requirements for high-efficiency cogeneration should be consistent with long-term  climate  policy  goals.  The  definitions  of  cogeneration  and  high-efficiency  cogeneration  used  in  Union legislation should be without prejudice to the use of different definitions in national legislation for purposes other than those of the Union legislation in question. To maximise energy savings and avoid energy saving opportunities being missed, the greatest attention should be paid to the operating conditions of cogeneration units.
- (109) To ensure transparency and allow the final customer to choose between electricity from cogeneration and electricity produced  by  other  techniques,  the  origin  of  high-efficiency  cogeneration  should  be  guaranteed  on  the  basis  of harmonised efficiency reference values. Guarantee of origin schemes do not of themselves imply a right to benefit from  national  support  mechanisms.  It  is  important  that  all  forms  of  electricity  produced  from  high-efficiency cogeneration  can  be  covered  by  guarantees  of  origin. Guarantees  of  origin should  be  distinguished from exchangeable certificates.
- (110) The specific structure of  the cogeneration and district heating and cooling sectors, which include many producers that are SMEs, should be taken into account, especially when reviewing the administrative procedures for obtaining permission  to  construct  cogeneration  capacity  or  associated  networks,  in  application  of  the  'think  small  first' principle.
- (111) Most Union businesses are SMEs. They represent an enormous energy saving potential for the Union. To help them adopt energy efficiency measures, Member States should establish a favourable framework aimed at providing SMEs with technical assistance and targeted information.
- (112) Member  States  should  establish,  on  the  basis  of  objective,  transparent  and  non-discriminatory  criteria,  rules governing  the  bearing  and  sharing  of  costs  of  grid  connections  and  grid  reinforcements  and  rules  for  technical adaptations  needed  to  integrate  new  producers  of  electricity  produced  from  high-efficiency  cogeneration,  taking into account network codes and guidelines developed in accordance with Regulations (EU) 2019/943 ( 26 ) and (EC) No  715/2009  of  the  European  Parliament  and  of  the  Council ( 27 ).  Producers  of  electricity  generated  from  highefficiency  cogeneration  should  be  allowed  to  issue  a  call  for  tender  for  the  connection  work.  Access  to  the  grid system for electricity produced from high-efficiency cogeneration, especially for small scale and micro-cogeneration units,  should  be  facilitated.  In  accordance  with  Article  3(2)  of  Directive  2009/73/EC  and  Article  9(2)  of  Directive (EU) 2019/944, it is possible for Member States to impose public service obligations, including in relation to energy efficiency, on enterprises operating in the electricity and gas sectors.
- (113) It is necessary to set out provisions relating to billing, single point of contact, out-of-court dispute settlement, energy poverty and basic contractual rights, with the aim of aligning them, where appropriate, with the relevant provisions regarding electricity pursuant to Directive (EU) 2019/944, in order  to strengthen consumer protection and enable final customers to receive more frequent, clear and up-to-date information about their heating, cooling or domestic hot water consumption and to regulate their energy use.
- (114) This Directive strengthens the protection of consumers by introducing basic contractual rights for district heating, cooling  and  domestic  hot  water,  coherent  with  the  level  of  rights,  protection  and  empowerment  that  Directive (EU)  2019/944  has  introduced  for  final  customers  in  the  electricity  sector.  Plain  and  unambiguous  information concerning their rights should be made available to consumers. Several factors impede consumers from accessing, understanding and acting upon the various sources of market information available to them. The introduction of basic  contractual  rights  can  help,  among  others,  with  a  proper  understanding  of  the  baseline  of  the  quality  of services offered in the contract by the supplier, including the quality and characteristics of  the supplied energy. In addition, it can contribute to the minimisation of hidden or extra costs that could result from the introduction of

( 26 ) Regulation  (EU)  2019/943  of  the  European  Parliament  and  of  the  Council  of  5  June  2019  on  the  internal  market  for  electricity (OJ L 158, 14.6.2019, p. 54).

( 27 ) Regulation (EC) No 715/2009 of the European Parliament and of the Council of 13 July 2009 on conditions for access to the natural gas transmission networks and repealing Regulation (EC) No 1775/2005 (OJ L 211, 14.8.2009, p. 36).

EN

20.9.2023

either upgraded or new services after the signing of the contract without a clear understanding and agreement by the customer. Those services could concern, among others, the energy supplied, metering and billing services, purchase and  installation  or  ancillary  and  maintenance  services  and  costs  relating  to  the  network,  metering  devices,  local heating or cooling equipment. The requirements will contribute to the improvement of comparability of offers and ensure the same level of basic contractual rights for all Union citizens regarding heating, cooling and domestic hot water, without restricting national competences.

- (115) In  the  case  of  planned  disconnection  from  heating,  cooling and  domestic hot  water,  suppliers  should  provide  the customers  concerned  with  adequate  information  on  alternative  measures,  such  as  sources  of  support  to  avoid disconnection,  prepayment  systems,  energy  audits,  energy  consultancy  services,  alternative  payment  plans,  debt management advice or disconnection moratoria.
- (116) Greater  consumer  protection  should  be  guaranteed  through  the  availability of  effective,  independent  out-of-court dispute  settlement  mechanisms  for  all  consumers,  such  as  an  energy  ombudsperson,  a  consumer  body  or  a regulatory authority. Member  States should, therefore, introduce speedy and effective complaint-handling procedures.
- (117) The  contribution  of  renewable  energy  communities,  pursuant  to  Directive  (EU)  2018/2001,  and  citizen  energy communities,  pursuant  to  Directive  (EU)  2019/944,  towards  the  objectives  of  the  European  Green  Deal  and  the Climate Target  Plan,  should  be  recognised  and  actively  supported.  Member  States  should,  therefore,  consider  and promote the role of renewable energy communities and citizen energy communities. Those communities can help Member States to achieve the objectives of this Directive by advancing energy efficiency at local or household level, as well as in public buildings, in cooperation with local authorities. They can empower and engage consumers and enable  certain  groups  of  household  customers,  including  in  rural  and  remote  areas,  to  participate  in  energy efficiency  projects  and  interventions  that  can  combine  actions  with  investment  in  renewable  energy.  Energy communities can have a strong role to play in educating and increasing citizens' awareness of measures designed to achieve  energy  savings.  If  properly  supported  by  Member  States,  energy  communities  can  help  fighting  energy poverty through the facilitation of energy efficiency projects, reduced energy consumption and lower supply tariffs.
- (118) Long-term  behavioural  changes  in  energy  consumption  can  be  achieved  through  the  empowerment  of  citizens. Energy communities can help deliver long-term energy savings, particularly among households, and an increase in sustainable investments from citizens and small businesses. Member States should empower such actions by citizens through support for community energy projects and organisations. In addition, engagement strategies, involving all relevant  stakeholders  at national and local level in the policy-making process, can be part of  the local or  regional decarbonisation plans or national buildings renovation plans, with the objective of increasing awareness, obtaining feedback on policies and improving their acceptance by the public.
- (119) The  contribution  of  one-stop  shops  or  similar  structures  as  mechanisms  that  can  enable  multiple  target  groups, including citizens, SMEs and public authorities, to design and implement projects and measures relating to the clean energy transition  should be recognised. The contribution of one-stop shops can be very important for  vulnerable customers,  as  they  could  receive  reliable  and  accessible  information  about  energy  efficiency  improvements.  That contribution  can  include  the  provision  of  technical,  administrative  and  financial  advice  and  assistance,  the facilitation of the necessary administrative procedures or of access to financial markets, guidance with regard to the Union and national legal frameworks, including public procurement rules and criteria, and the EU taxonomy.
- (120) The  Commission  should  review  the  impact  of  its  measures  to  support  the  development  of  platforms  or  fora, involving,  inter  alia,  the  European  social  dialogue  bodies,  on  fostering  training  programmes  for  energy  efficiency, and  should  propose  further  measures  where  appropriate.  The  Commission  should  also  encourage  the  European social  partners  in  their  discussions  on  energy  efficiency,  especially  for  vulnerable  customers  and  final  users, including those in energy poverty.

EN

- (121) A fair transition towards a climate-neutral Union by 2050 is central to the European Green Deal. The European Pillar of Social Rights, jointly proclaimed by the European Parliament, the Council and the Commission on 17 November 2017, includes energy among the essential services that everyone is entitled to access. Support for access to such services  must  be  available  for  those  in  need,  particularly  in  a  context  of  inflationary  pressure  and  significant increases in energy prices.
- (122) It  is  necessary  to  ensure  that  people  affected  by  energy  poverty,  vulnerable  customers,  people  in  low-income households  and,  where  applicable,  people  living  in  social  housing  are  protected  and,  to  that  end,  empowered  to actively participate in the energy efficiency improvement interventions, measures and related consumer protection or information  measures  that Member  States  implement.  Targeted awareness-raising campaigns  should  be developed  to  illustrate  the  benefits  of  energy  efficiency  as  well  to  provide  information  on  the  financial  support available.
- (123) Public  funding  available  at  Union  and  national  level  should  be  strategically  invested  into  energy  efficiency improvement  measures,  in  particular  for  the  benefit  of  people  affected  by  energy  poverty,  vulnerable  customers, people in low-income households and, where applicable, people living in social housing. Member States should take advantage of any financial contribution they might receive from the Social Climate Fund established by Regulation (EU) 2023/955 of the European Parliament and of the Council ( 28 ),  and  of  revenues  from  allowances from the EU ETS.  Those  revenues  will  support  Member  States  in  fulfilling  their  obligation  to  implement  energy  efficiency measures and policy measures under  the energy savings obligation as a priority among people affected by energy poverty,  vulnerable  customers,  people  in  low-income  households  and,  where  applicable,  people  living  in  social housing including those living in rural and remote regions.
- (124) National  funding  schemes  should  be  complemented  by  suitable  schemes  of  better  information,  technical  and administrative assistance, and easier access to finance that will enable the best use of the available funds especially by  people  affected  by  energy  poverty,  vulnerable  customers,  people  in  low-income  households  and,  where applicable, people living in social housing.
- (125) Member States should  empower  and  protect  all  people  equally,  irrespective  of  sex,  gender,  age,  disability,  race  or ethnic origin, sexual orientation, religion or belief, and ensure that those most affected, those put at greater risk of being affected by energy  poverty,  or  those  most exposed to the adverse impacts of energy poverty are adequately protected. In addition, Member States should ensure that energy efficiency measures do not exacerbate any existing inequalities, in particular with respect to energy poverty.
- (126) Pursuant to Article 15(2) of Directive 2012/27/EU, all Member States have undertaken an assessment of the energy efficiency potential of their gas and electricity infrastructure, and have identified concrete measures and investments for the introduction of cost-effective energy efficiency improvements in the network infrastructure, with a timetable for their introduction. The results of those actions represent a solid basis for the application of the energy efficiency first principle in their network planning, network development and investment decisions.
- (127) National  energy  regulatory  authorities  should  take  an  integrated  approach  encompassing  potential  savings  in  the energy supply and the end-use sectors. Without prejudice to security of supply, market integration and anticipatory investments  in  offshore  grids  necessary  for the deployment  of  offshore  renewable  energy,  national  energy regulatory authorities should ensure that the energy efficiency first principle is applied in the planning and decisionmaking processes and that network tariffs and regulations incentivise improvements in energy efficiency. Member States  should  also  ensure  that  transmission  and  distribution  system  operators  consider  the  energy  efficiency  first principle.  That  would  help  transmission  and  distribution  system  operators  to  consider  better  energy  efficiency solutions  for  and  incremental  costs  incurred  from  the  procurement  of  demand-side  resources,  as  well  as  the

( 28 ) Regulation (EU) 2023/955 of  the European Parliament and of  the Council of 10 May 2023 establishing a Social Climate Fund and amending Regulation (EU) 2021/1060 (OJ L 130, 16.5.2023, p. 1).

EN

environmental  and  socio-economic  impacts  of  different  network  investments  and  operation  plans.  Such  an approach requires a shift from the narrow economic efficiency perspective to maximised social welfare. The energy efficiency first principle should in particular be applied in the context of scenario building for energy infrastructure expansion where demand-side solutions could be considered as viable alternatives and need to be properly assessed, and  should  become  an  intrinsic  part  of  the  assessment  of  network  planning  projects.  Its  application  should  be scrutinised by national regulatory authorities.

- (128) A sufficient number of reliable professionals competent in the field of energy efficiency should be available to ensure the effective and timely implementation of this Directive, for instance as regards compliance with the requirements on energy audits and implementation of energy efficiency obligation schemes. Member States should therefore put in place certification or equivalent qualification, or both, and suitable training schemes for  the providers of energy services,  energy  audits  and  other  energy  efficiency  improvement  measures  in  close  cooperation  with  the  social partners,  training  providers  and  other  relevant  stakeholders.  The  schemes  should  be  assessed  every  four  years starting as  of  December 2024 and, if needed, be updated to ensure the necessary level of competences for energy services providers, energy auditors, energy managers and installers of building elements.
- (129) It is necessary to continue developing the market for energy services to ensure the availability of both the demand for and the supply of energy services. Transparency, for example by means of lists of certified energy services providers and available model contracts, exchange of best practices and guidelines greatly contribute to the uptake of energy services and energy performance contracting and can also help stimulate demand and increase the trust in energy services providers. In an energy performance contract the beneficiary of the energy service avoids investment costs by using part of the financial value of energy savings to fully or partially repay the investment carried out by a third party. That can help attract private capital which is key for increasing building renovation rates in the Union, bring expertise  into  the  market  and  create  innovative  business  models.  Therefore,  non-residential  buildings  with  the useful floor area above 750 m 2 should be required to assess the feasibility of using energy performance contracting for  renovation.  That  is  a  step  ahead  to  increase  the  trust  in  energy  services  companies  and  pave  the  way  for increasing such projects in the future.
- (130) Given  the  ambitious  renovation  objectives  over  the  next  decade  in  the  context  of  the  Renovation  Wave,  it  is necessary  to  increase  the  role  of  independent  market  intermediaries  including  one-stop  shops  or  similar  support mechanisms  in  order  to  stimulate  market  development  on  the  demand  and  supply  sides  and  to  promote  energy performance contracting for renovation of both private and public buildings. Local energy agencies could play a key role in that regard, and identify and support setting up potential facilitators or one-stop shops. This Directive should help improve  the availability of products, services and advice, including by promoting  the  potential for entrepreneurs to fill the gaps in the market and to provide for innovative ways to enhance energy efficiency, while ensuring respect for the principle of non-discrimination.
- (131) Energy performance contracting still faces important barriers in several Member States due to remaining regulatory and  non-regulatory  barriers.  It  is  therefore  necessary  to  address  the  ambiguities  of the national  legislative frameworks, lack of expertise, especially as regards tendering procedures, and competing loans and grants.
- (132) Member States should continue supporting the public sector  in the uptake of energy performance contracting by providing  model  contracts  that  take  into  account  the  available  European  or  international  standards,  tendering guidelines and the Guide to the Statistical  Treatment of Energy Performance Contracts published in May 2018 by Eurostat  and  the  European  Investment  Bank  (EIB)  on  the  treatment  of  energy  performance  contracting  in government  accounts,  which  have  provided  opportunities  for  addressing  remaining  regulatory  barriers  to  those contracts in Member States.

EN

- (133) Member States have taken measures to identify and address regulatory and non-regulatory barriers. However, there is a  need  to  increase  the  effort  to  remove  regulatory  and  non-regulatory  barriers  to  the  use  of  energy  performance contracting  and  third-party  financing  arrangements  which  help  achieve  energy  savings.  Those  barriers  include accounting rules and practices that prevent capital investments and annual financial savings resulting from energy efficiency  improvement  measures  from  being  adequately  reflected  in  the  accounts  for  the  whole  life  of  the investment.
- (134) Member  States  used  the  2014  and  2017  national  energy  efficiency  action  plans  to  report  progress  in  removing regulatory and non-regulatory barriers to energy efficiency, as regards split incentives between owners and tenants or among owners of a building or building units. Member States should continue working in that direction and tap the potential for energy efficiency in the context of the 2016 Eurostat statistics, in particular the fact that more than four out of ten Europeans live in flats and more than three out of ten Europeans are tenants.
- (135) Member States,  including  regional  and  local  authorities,  should  be  encouraged  to  make  full  use  of  the  European funds  available  under  the  multiannual  financial  framework  for  the  years  2021  to  2027  laid  down  in  Council Regulation (EU, Euratom) 2020/2093 ( 29 ) the Recovery and Resilience Facility, established by Regulation (EU) 2021/241 of the European Parliament and of the Council ( 30 ), as well as the financial instruments and technical assistance  available  under  the  InvestEU  programme,  established  by  Regulation  (EU)  2021/523  of  the  European Parliament  and  of  the  Council ( 31 ),  to  trigger  private  and  public  investments  in  energy  efficiency  improvement measures.  Investment  in  energy  efficiency  has  the  potential  to  contribute  to  economic  growth,  employment, innovation  and  a  reduction  in  energy  poverty  in  households,  and  therefore  makes  a  positive  contribution  to economic, social and territorial cohesion and green recovery. Potential areas for funding include energy efficiency measures in public buildings and housing, and providing new skills through the development of training, reskilling and upskilling of professionals, in particular in jobs related to building renovation, to promote employment in the energy  efficiency  sector.  The  Commission  will  ensure  synergies  between  the  different  funding  instruments,  in particular the funds in shared management and in direct management, such as the centrally-managed programmes Horizon Europe and LIFE, as well as between grants, loans and technical assistance to maximise their leverage effect on private financing and their impact on the achievement of energy efficiency policy objectives.
- (136) Member  States  should  encourage  the  use  of  financing  facilities  to  further  the  objectives  of  this  Directive.  Such financing  facilities  could  include  financial  contributions  and  fines  for  infringements  of  certain  provisions  of  this Directive,  resources  allocated  to  energy  efficiency  under  Article  10(3)  of  Directive  2003/87/EC,  and  resources allocated to energy efficiency in the European  funds  and  programmes,  and  dedicated  European  financial instruments, such as the European Energy Efficiency Fund.
- (137) Financing facilities could be based, where applicable, on resources allocated to energy efficiency from Union project bonds, resources allocated to energy efficiency from the EIB and other European financial institutions, in particular the  European  Bank  for  Reconstruction  and  Development  (EBRD)  and  the  Council  of  Europe  Development  Bank, resources  leveraged  in  financial  institutions,  national  resources,  including  through  the  creation  of  regulatory  and fiscal  frameworks  encouraging  the  implementation  of energy efficiency initiatives  and  programmes,  and  revenues from annual emission allocations under Decision No  406/2009/EC  of the European Parliament and of the Council ( 32 ).

( 29 ) Council Regulation (EU, Euratom) 2020/2093 of 17 December 2020 laying down the multiannual financial framework for the years 2021 to 2027 (OJ L 433 I, 22.12.2020, p. 11).

( 30 ) Regulation  (EU)  2021/241  of  the  European  Parliament  and  of  the  Council  of  12  February  2021  establishing  the  Recovery  and Resilience Facility (OJ L 57, 18.2.2021, p. 17).

( 31 ) Regulation (EU) 2021/523 of the European Parliament and of the Council of 24 March 2021 establishing the InvestEU Programme and amending Regulation (EU) 2015/1017 (OJ L 107, 26.3.2021, p. 30).

( 32 ) Decision No 406/2009/EC of the European Parliament and of the Council of 23 April 2009 on the effort of Member States to reduce their  greenhouse gas emissions to meet the Community's greenhouse gas emission reduction commitments up to 2020 (OJ L 140, 5.6.2009, p. 136).

EN

- (138) The financing facilities could in particular use contributions, resources and revenues from those resources to enable and  encourage  private  capital  investment,  in  particular  drawing  on  institutional  investors,  while  using  criteria ensuring  the  achievement  of  both  environmental  and  social  objectives  for  the  granting  of  funds;  make  use  of innovative  financing  mechanisms,  including  loan  guarantees  for  private  capital,  loan  guarantees  to  foster  energy performance  contracting,  grants,  subsidised  loans  and  dedicated  credit  lines,  third-party  financing  systems,  that reduce  the  risks  of  energy  efficiency  projects  and  allow  for  cost-effective  renovations  even  among  low-  and medium-revenue households; be linked to programmes or agencies which will aggregate and assess the quality of energy  saving  projects,  provide  technical  assistance,  promote  the  energy  services  market  and  help  to  generate consumer demand for energy services.
- (139) The financing facilities could also provide appropriate resources to support training and certification programmes which improve and accredit skills for energy efficiency, provide resources for  research on and  demonstration and acceleration of uptake of small-scale and micro technologies in the generation of energy and the optimisation of the connections  of  those  generators  to  the  grid,  be  linked  to  programmes  undertaking  action  to  promote  energy efficiency  in  all  dwellings  to  prevent  energy  poverty  and  stimulate  landlords  letting  dwellings  to  render  their property as energy-efficient as possible, and provide appropriate resources to support social dialogue and standardsetting with the aim of improving energy efficiency and ensuring good working conditions and health and safety at work.
- (140) Available Union funding programmes, financial instruments and innovative financing mechanisms should be used to  give  practical  effect  to  the  objective  of  improving  the  energy  performance  of  public  bodies'  buildings.  In  that respect, Member States may use their revenues from annual emission allocations under Decision No 406/2009/EC in the development of such mechanisms on a voluntary basis and taking into account national budgetary rules. The Commission and the Member States should provide regional and local administrations with adequate information on such Union funding programmes, financial instruments and innovative financing mechanisms.
- (141) In  the  implementation of  the energy efficiency  target, the Commission should monitor  the impact of  the relevant measures  on  Directive  2003/87/EC  in  order  to  maintain  the  incentives  in  the  EU  ETS  rewarding  low  carbon investments and to prepare the EU ETS sectors for the innovations needed in the future. It will need to monitor the impact on those industry sectors which are exposed to a significant risk of carbon leakage as listed in the Annex to Commission Decision 2014/746/EU ( 33 ), in order  to ensure that this Directive promotes and does not impede the development of those sectors.
- (142) Member State measures should be supported by well-designed and effective Union financial instruments under the InvestEU programme, and by financing from the EIB and the EBRD, which should support investments in energy efficiency  at  all  stages  of the  energy  chain  and  use  a  comprehensive  cost-benefit  analysis  with  a  model  of differentiated  discount  rates.  Financial  support  should  focus  on  cost-effective  methods  for  increasing  energy efficiency,  which would lead  to a  reduction  in  energy consumption. The EIB  and  the  EBRD  should,  together  with national  promotional  banks,  design,  generate  and  finance  programmes  and  projects  tailored  for  the  efficiency sector, including for energy-poor households.
- (143) Cross-sectoral law provides a strong basis for consumer protection for a wide range of current energy services, and is likely to evolve. Nevertheless, certain basic contractual rights of customers should be clearly established. Plain and unambiguous  information  should  be  made  available  to  consumers  concerning  their  rights  in  relation  to  the energy sector.
- (144) In order to be able to evaluate the effectiveness of this Directive, a requirement to conduct a general review of this Directive and to submit a report to the European Parliament and to the Council by 28 February 2027 should be laid down.  That  review  should  allow  necessary  alignments,  also  taking  into  account  economic  and  innovation developments.

( 33 ) Commission Decision 2014/746/EU of 27 October 2014 determining, pursuant to Directive 2003/87/EC of the European Parliament and of  the  Council, a  list  of  sectors  and  subsectors  which  are  deemed  to  be  exposed  to  a  significant  risk of  carbon  leakage, for  the period 2015 to 2019 (OJ L 308, 29.10.2014, p. 114).

EN

- (145) Local  and  regional  authorities  should  be  given  a  leading  role  in  the  development  and  design,  execution  and assessment of the measures laid down in this Directive, so that they are able properly to address the specific features of their own climate, culture and society.
- (146) Reflecting  technological  progress  and  the  growing share  of  renewable  energy  sources  in  the  electricity  generation sector,  the  default  coefficient  for  savings  in  kWh  electricity  should  be  reviewed  in  order  to  reflect  changes  in  the primary energy factor for electricity and other energy carriers. The calculation methodology is in accordance with the Eurostat energy balances and definitions, except for the allocation method of fuel input for heat and electricity in combined heat and power plants, for which the efficiency of the reference system, required for the allocation of fuel consumption, was aligned with Eurostat data for 2015 and 2020. Calculations reflecting the energy mix of the primary energy factor for electricity are based on annual average values. The 'physical energy content'  accounting method is used for nuclear electricity and heat generation and the 'technical conversion efficiency' method is used for  electricity  and  heat  generation  from  fossil  fuels  and  biomass.  For  non-combustible  renewable  energy,  the method is the direct equivalent based on the 'total primary energy' approach. To calculate the primary energy share for  electricity  in  cogeneration,  the  method  set  out  in  this  Directive  is  applied.  An  average  rather  than  a  marginal market position is used. Conversion efficiencies are assumed to be 100 % for non-combustible renewables, 10 % for geothermal power stations and 33 % for nuclear power stations. The calculation of total efficiency for cogeneration is based on the most recent data from Eurostat. The conversion, transmission and distribution losses are taken into account. Distribution losses for energy carriers other  than electricity are not considered in the calculations, due to the lack of reliable data and the complexity of the calculation. As for system boundaries, the primary energy factor is  1  for  all  energy  sources.  The  selected  coefficient  for  the  primary  energy  factor  for  electricity  is  the  average  of 2024 and 2025 values, since  a  forward-looking  primary energy  factor  will  provide  a  more  appropriate  indicator than a historical one. The analysis covers the Member States and Norway. The dataset for Norway is based on the ENTSO-E data.
- (147) Energy savings which result from the implementation of Union law should not be claimed unless they result from a measure  that  goes  beyond  the  minimum  required  by  the  Union  legal  act  in  question,  whether  by  setting  more ambitious  energy  efficiency  requirements  at  Member  State  level  or  by  increasing  the  take-up  of  the  measure. Buildings present a substantial potential for further increasing energy efficiency, and the renovation of buildings is an essential and long-term element with economies of scale in increasing energy savings. It is therefore necessary to clarify that it is possible to claim all energy savings stemming from measures promoting the renovation of existing buildings, provided that they exceed the savings that would have occurred in the absence of the policy measure and provided  that  the  Member  State  demonstrates  that  the  obligated,  participating  or  entrusted  party  has  in  fact contributed to the achievement of the energy savings claimed.
- (148) In  accordance with the communication of  the Commission of 25 February 2015 on 'A Framework Strategy for a Resilient  Energy  Union  with  a  Forward-Looking  Climate  Change  Policy'  and  the  principles  of  better  regulation, monitoring and  verification  rules  for  the  implementation  of  energy  efficiency  obligation  schemes  and  alternative policy  measures,  including  the  requirement  to  check  a  statistically  representative  sample  of  measures,  should  be given greater prominence.
- (149) Energy  generated  on  or  in  buildings  from  renewable  energy  technologies  reduces  the  amount  of  energy  supplied from  fossil  fuels.  The  reduction  of  energy  consumption  and  the  use  of  energy  from  renewable  sources  in  the buildings sector are important measures to reduce the Union's energy dependence and GHG emissions, especially in view  of  the  ambitious  climate  and  energy  objectives  set  for  2030  as  well  as  the  global  commitment  made  in  the context  of  the  Paris  Agreement.  For  the  purposes  of  their  cumulative  energy  savings  obligation,  it  is  possible  for Member  States  to  take  into  account  energy  savings  from  policy  measures  promoting  renewable  technologies  to meet  their  energy  savings  requirements  in  accordance  with  the  calculation  methodology  provided  for  in  this Directive.  Energy  savings  from  policy  measures  regarding  the  use  of  direct  fossil  fuel  combustion  should  not  be counted.

EN

20.9.2023

- (150) Some  of  the  changes  introduced  by  this  Directive  might  require  a  subsequent  amendment  to  Regulation (EU) 2018/1999 in order to ensure coherence between the two legal acts. New provisions, mainly relating to setting national contributions, gap  filling mechanisms  and  reporting  obligations,  should  be  streamlined  with  and transferred to that Regulation, once it is amended. Some provisions of Regulation (EU) 2018/1999 might also need to  be  reassessed  in  view  of  the  changes  proposed  in  this  Directive.  The  additional  reporting  and  monitoring requirements should not create any new parallel reporting systems but would be subject to the existing monitoring and reporting framework under Regulation (EU) 2018/1999.
- (151) To foster the practical implementation of this Directive at national, regional and local level, the Commission should continue  to  support  the  exchange  of  experiences  on  practices,  benchmarking,  networking  activities,  as  well  as innovative practices by means of an online platform.
- (152) Since  the  objectives  of  this  Directive,  namely  to  achieve  the  Union's  energy  efficiency  target  and  to  pave  the  way towards further energy efficiency improvements and towards climate neutrality, cannot be sufficiently achieved by the Member States but can rather, by reason of the scale and effects of the action, be better achieved at Union level, the Union may adopt measures, in accordance with the principle of subsidiarity as set out in Article 5 of the Treaty on  European  Union.  In  accordance  with  the  principle  of  proportionality  as  set  out  in  that  Article,  this  Directive does not go beyond what is necessary in order to achieve those objectives.
- (153) In order to permit adaptation to technical progress and changes in the distribution of energy sources, the power to adopt acts in accordance with Article 290 TFEU should be delegated to the Commission in respect of the review of the  harmonised  efficiency  reference  values  laid  down  on  the  basis  of  this  Directive,  in  respect  of  the  values, calculation  methods,  default  primary  energy coefficient  and  requirements  in  the  Annexes  to  this  Directive  and  in respect of supplementing this Directive by establishing a common Union scheme for rating the sustainability of data centres located  in its territory. It is of particular importance  that  the  Commission  carry  out  appropriate consultations during its preparatory  work,  including at expert level, and that those consultations be conducted in accordance  with  the  principles  laid  down  in  the  Interinstitutional  Agreement  of  13  April  2016 on  Better  LawMaking ( 34 ). In particular, to ensure equal participation in the preparation of delegated acts, the European Parliament and the Council receive all documents at the same time as Member States' experts, and their experts systematically have access to meetings of Commission expert groups dealing with the preparation of delegated acts.
- (154) Regulation  (EU)  2023/955  should  be  amended  in  order  to  take  account  of  the  definition  of  energy  poverty established  in  this  Directive.  That  would  ensure  consistency,  coherence,  complementarity  and  synergy  among different instruments and funding in particular addressing households in energy poverty.
- (155) The obligation to transpose this Directive into national law should be confined to those provisions which represent a substantive amendment as compared to the earlier Directive. The obligation to transpose the provisions which are unchanged arises under the earlier Directive.
- (156) This Directive should be without prejudice to the obligations of the Member States relating to the time-limits for the transposition into national law of the Directives set out in Part B of Annex XVI,

( 34 ) OJ L 123, 12.5.2016, p. 1.

EN

L  231/28

HAVE ADOPTED THIS DIRECTIVE:

CHAPTER I

## SUBJECT MATTER, SCOPE, DEFINITIONS AND ENERGY EFFICIENCY TARGETS

## Article 1

## Subject matter and scope

- 1. This Directive establishes a common framework of measures to promote energy efficiency within the Union in order to ensure that the Union's targets on energy efficiency are met and enables further energy efficiency improvements. The aim of  that  common  framework  is  to  contribute  to  the  implementation  of  Regulation  (EU)  2021/1119  of  the  European Parliament  and  of  the  Council ( 35 ) and  to  the  Union's  security  of  energy  supply  by  reducing  its  dependence  on  energy imports, including fossil fuels.

This Directive lays down rules designed to implement energy efficiency as a priority across all sectors, remove barriers in the  energy  market  and  overcome  market  failures  that  impede  efficiency  in  the  supply,  transmission,  storage  and  use  of energy. It also provides for the establishment of indicative national energy efficiency contributions for 2030.

This Directive contributes to the implementation of the energy efficiency first principle, thus also contributing to the Union being an inclusive, fair and prosperous society with a modern, resource-efficient and competitive economy.

- 2. The requirements laid  down in this  Directive  are  minimum  requirements  and  shall  not  prevent  any  Member  State from maintaining or introducing more stringent measures. Such measures shall comply with Union law. Where national legislation provides for more stringent measures, the Member State shall notify such legislation to the Commission.

## Article 2

## Definitions

For the purposes of this Directive, the following definitions apply:

- (1) 'energy' means energy products as defined in Article 2, point (d), of Regulation (EC) No 1099/2008 of the European Parliament and of the Council ( 36 );
- (2) 'energy efficiency first' means energy efficiency first as defined in Article 2, point (18), of Regulation (EU) 2018/1999;
- (3) 'energy system' means a system primarily designed to supply energy-services to satisfy the demand of end-use sectors for energy in the forms of heat, fuels, and electricity;
- (4) 'system efficiency' means  the  selection of energy-efficient solutions where  they  also enable a cost-effective decarbonisation pathway, additional flexibility and the efficient use of resources;
- (5) 'primary energy consumption' or 'PEC' means gross available energy, excluding international maritime bunkers, final non-energy consumption and ambient energy;
- ( 35 ) Regulation (EU) 2021/1119 of the European Parliament and of the Council of 30 June 2021 establishing the framework for achieving climate neutrality and amending Regulations (EC) No 401/2009 and (EU) 2018/1999 ('European Climate Law') (OJ L 243, 9.7.2021, p. 1).

( 36 ) Regulation (EC) No 1099/2008 of the European Parliament and of the Council of 22 October 2008 on energy statistics (OJ L 304, 14.11.2008, p. 1).

EN

- (6) 'final energy consumption' or 'FEC' means all energy supplied to industry, to transport, including energy consumption in  international  aviation,  to  households,  to  public  and  private  services,  to  agriculture,  to  forestry,  to  fishing  and  to other  end-use  sectors,  excluding  energy  consumption  in  international  maritime  bunkers,  ambient  energy  and deliveries  to  the  transformation  sector  and  to the  energy  sector,  and  losses  due  to  transmission  and  distribution  as defined in Annex A to Regulation (EC) No 1099/2008;
- (7) 'ambient energy' means ambient energy as defined in Article 2, point (2), of Directive (EU) 2018/2001;
- (8) 'energy efficiency' means the ratio of output of performance, service, goods or energy to input of energy;
- (9) 'energy  savings'  means  an  amount of  saved  energy  determined  by measuring  or  estimating  consumption,  or  both,, before and after the implementation of an energy efficiency improvement measure, whilst ensuring normalisation for external conditions that affect energy consumption;
- (10) 'energy efficiency improvement' means an increase in energy efficiency as a result of any technological, behavioural or economic changes;
- (11) 'energy service' means the physical benefit, utility or good derived from a combination of energy with energy-efficient technology  or  with  action,  which  may  include  the  operations,  maintenance  and  control  necessary  to  deliver  the service, which is delivered on the basis of a contract and in normal circumstances has proven to result in verifiable and measurable or estimable energy efficiency improvement or primary energy savings;
- (12) 'public bodies' means national, regional or local authorities and entities directly financed and administered by those authorities but not having an industrial or commercial character;
- (13) 'total useful floor area' means the floor area of a building, or part of a building, where energy is used to condition the indoor climate;
- (14) 'contracting authorities' means  contracting authorities as defined in Article 6(1) of Directive 2014/23/EU, Article 2(1), point (1), of Directive 2014/24/EU and Article 3(1) of Directive 2014/25/EU;
- (15) 'contracting entities' means contracting entities as defined in Article 7(1) of Directive 2014/23/EU and Article 4(1) of Directive 2014/25/EU;
- (16) 'energy  management  system'  means  a  set of  interrelated  or  interacting  elements  of  a  strategy  which  sets  an  energy efficiency  objective  and  a  plan  to  achieve  that  objective,  including  the  monitoring  of  actual  energy  consumption, actions taken to increase energy efficiency and the measurement of progress;
- (17) 'European  standard'  means  a  standard  adopted  by  the  European  Committee  for  Standardization,  the  European Committee for  Electrotechnical  Standardization  or  the  European Telecommunications  Standards  Institute,  which  is made available for public use;
- (18) 'international  standard'  means  a  standard  adopted  by  the  International  Organization  for  Standardization,  which  is made available for public use;
- (19) 'obligated party' means an energy distributor, retail energy sales company or transmission system operator, which is bound by the national energy efficiency obligation schemes referred to in Article 9;
- (20) 'entrusted  party'  means  a  legal  entity  with  delegated  power  from  a  government  or  other  public  body  to  develop, manage or operate a financing scheme on behalf of that government or other public body;
- (21) 'participating party' means an enterprise or public body that has committed itself to reaching certain objectives under a voluntary agreement, or that is covered by a national regulatory policy instrument;

EN

- (22) 'implementing public authority' means a body governed by public law which is responsible for  the carrying out or monitoring of energy or carbon taxation, financial schemes and instruments, fiscal incentives, standards and norms, energy labelling schemes, training or education;
- (23) 'policy  measure'  means  a  regulatory,  financial,  fiscal,  voluntary  or  information  provision  instrument  formally established  and  implemented  in  a  Member  State  to  create  a  supportive  framework,  requirement  or  incentive  for market  actors  to  provide  and  purchase  energy  services  and  to  undertake  other  energy  efficiency  improvement measures;
- (24) 'individual action' means  an  action that leads to verifiable and measurable  or estimable energy efficiency improvements and that is undertaken as a result of a policy measure;
- (25) 'energy distributor' means a natural or legal person, including a distribution system operator, who is responsible for transporting energy with a view to its delivery to final customers or  to distribution stations that sell energy to final customers;
- (26) 'distribution  system  operator'  means  distribution  system  operator  as  defined  in  Article  2,  point  (29),  of  Directive (EU) 2019/944 as regards electricity or Article 2, point (6), of Directive 2009/73/EC as regards gas;
- (27) 'retail energy sales company' means a natural or legal person who sells energy to final customers;
- (28) 'final customer' means a natural or legal person who purchases energy for own end use;
- (29) 'energy  service  provider'  means  a  natural  or  legal  person  who  delivers  energy  services  or  energy  efficiency improvement measures in a final customer's facility or premises;
- (30) 'small  and  medium-sized  enterprises'  or  'SMEs'  means  enterprises  as  defined  in  Article  2(1)  of  the  Annex  to Commission Recommendation 2003/361/EC ( 37 );
- (31) 'microenterprise' means an enterprise as defined in Article 2(3) of the Annex to Recommendation 2003/361/EC;
- (32) 'energy  audit'  means  a  systematic  procedure  with  the  purpose  of  obtaining  adequate  knowledge  of  the  energy consumption profile of a building or group of buildings, an industrial or commercial operation or  installation or a private or  public service, identifying and quantifying opportunities for cost-effective energy savings, identifying the potential for cost-effective use or production of renewable energy and reporting the findings;
- (33) 'energy performance contracting' means a contractual arrangement between the beneficiary and the provider of an energy efficiency  improvement measure,  verified and  monitored  during  the  whole  term  of  the  contract,  where  the works, supply or service in that measure are paid for  in relation to a contractually agreed level of energy efficiency improvement or another agreed energy performance criterion, such as financial savings;
- (34) 'smart metering system' means smart metering system as defined in Article 2, point (23), of Directive (EU) 2019/944 or intelligent metering system as referred to in Directive 2009/73/EC;
- (35) 'transmission system operator' means transmission system operator as defined in Article 2, point (35), of Directive (EU) 2019/944 as regards electricity or Article 2, point (4), of Directive 2009/73/EC as regards gas;
- (36) 'cogeneration'  means  the  simultaneous  generation  in  one  process  of  thermal  energy  and  electrical  or  mechanical energy;
- (37) 'economically justifiable demand' means a demand that does not exceed the needs for heating or cooling and which would otherwise be satisfied at market conditions by energy generation processes other than cogeneration;
- ( 37 ) Commission Recommendation 2003/361/EC of 6 May 2003 concerning the definition of micro, small and medium-sized enterprises (OJ L 124, 20.5.2003, p. 36).

EN

20.9.2023

- (38) 'useful heat' means heat produced in a cogeneration process to satisfy an economically justifiable demand for heating or cooling;
- (39) 'electricity  from  cogeneration'  means  electricity  generated  in  a  process  linked  to  the  production  of  useful  heat  and calculated in accordance with the general principles set out in Annex II;
- (40) 'high-efficiency cogeneration' means cogeneration meeting the criteria laid down in Annex III;
- (41) 'overall  efficiency'  means  the  annual  sum  of  electricity  and  mechanical  energy  production  and  useful  heat  output divided  by  the  fuel  input  used  for  heat  produced  in  a  cogeneration  process  and  gross  electricity  and  mechanical energy production;
- (42) 'power-to-heat  ratio'  means  the  ratio  of  electricity  from  cogeneration  to  useful  heat  when  operating  in  full cogeneration mode using operational data of the specific unit;
- (43) 'cogeneration unit' means a unit that is able to operate in cogeneration mode;
- (44) 'small-scale cogeneration unit' means a cogeneration unit with installed capacity below 1 MW ; e
- (45) 'micro-cogeneration unit' means a cogeneration unit with a maximum capacity below 50 kW ; e
- (46) 'efficient  district  heating  and  cooling'  means  a  district  heating  or  cooling  system  meeting  the  criteria  laid  down  in Article 26;
- (47) 'efficient heating and cooling' means a heating and cooling option that, compared to a baseline scenario reflecting a business-as-usual situation, measurably reduces the input of primary energy needed to supply one unit of delivered energy within a relevant system boundary in a cost-effective way, as assessed in the cost-benefit analysis referred to in this Directive, taking into account the energy required for extraction, conversion, transport and distribution;
- (48) 'efficient  individual  heating  and  cooling'  means  an  individual  heating  and  cooling  supply option  that,  compared  to efficient  district  heating  and  cooling,  measurably  reduces  the  input  of  non-renewable  primary  energy  needed  to supply one unit of delivered energy within a relevant system boundary or requires the same input of non-renewable primary energy but at a lower cost, taking into account the energy required for extraction, conversion, transport and distribution;
- (49) 'data centre' means data centre as defined in Annex A, point 2.6.3.1.16, of Regulation (EC) No 1099/2008;
- (50) 'substantial refurbishment' means a refurbishment the cost of which exceeds 50 % of the investment cost for a new comparable unit;
- (51) 'aggregator' means independent aggregator as defined in Article 2, point (19), of Directive (EU) 2019/944;
- (52) 'energy  poverty'  means  a  household's  lack  of  access  to  essential  energy  services,  where  such  services  provide  basic levels and decent standards of  living and health, including adequate heating, hot water, cooling, lighting, and energy to  power  appliances,  in  the  relevant  national  context,  existing  national  social  policy  and  other  relevant  national policies, caused by a combination of factors, including at least non-affordability, insufficient disposable income, high energy expenditure and poor energy efficiency of homes;
- (53) 'final user' means a natural or legal person purchasing heating, cooling or domestic hot water for their own end use, or  a  natural  or  legal  person  occupying  an  individual  building  or  a  unit  in  a  multi-apartment  or  multi-purpose building  supplied  with  heating,  cooling  or  domestic  hot  water  from  a  central  source,  where  such  a  person  has  no direct or individual contract with the energy supplier;

EN

- (54) 'split  incentives'  means  the  lack  of  fair  and  reasonable  distribution  of  financial  obligations  and  rewards  relating  to energy  efficiency  investments  among  the  actors  concerned,  for  example  the  owners  and  tenants  or  the  different owners of building units, or owners and tenants or different owners of multi-apartment or multi-purpose buildings.
- (55) 'engagement strategy' means a strategy that sets objectives, develops techniques and establishes the process by which to involve all relevant stakeholders at national or local level, including civil society representatives such as consumer organisations,  in  the  policy-making  process,  with  the  goal  of  increasing  awareness,  obtaining  feedback  on  such policies and improving their public acceptance.
- (56) 'statistically significant proportion and representative sample of the energy efficiency improvement measures' means such a proportion and sample which require the establishment of a subset of a statistical population of  the energy savings  measures  in  question  in  such  a  way  as  to  reflect  the  entire  population  of  all  energy  savings  measures,  and thus allow for reasonably reliable conclusions regarding confidence in the totality of the measures.

## Article 3

## Energy efficiency first principle

- 1. In accordance with the energy efficiency first principle, Member States shall ensure that energy efficiency solutions, including demand-side resources and system flexibilities, are assessed in planning, policy and major investment decisions of a value of more than EUR 100 000 000 each or EUR 175 000 000 for transport infrastructure projects, relating to the following sectors:
- (a) energy systems; and
- (b) non-energy  sectors,  where  those  sectors  have  an  impact  on  energy  consumption  and  energy  efficiency  such  as buildings, transport, water, information and communications technology (ICT), agriculture and financial sectors.
- 2. By 11 October 2027, the Commission shall carry out an assessment of the thresholds set out in paragraph 1, with the aim  of  downward  revision,  taking  into  account  possible  developments  in  the  economy  and  in  the  energy  market.  The Commission shall, by 11 October 2028, submit a report to the European Parliament and to the Council, followed, where appropriate, by legislative proposals.
- 3. In applying  this  Article,  Member  States  are  encouraged  to  take  into  account  Commission  Recommendation (EU) 2021/1749 ( 38 ).
- 4. Member  States  shall  ensure  that  the  competent  authorities  monitor  the  application  of  the  energy  efficiency  first principle, including,  where  appropriate,  sector  integration  and  cross-sectoral  impacts,  where  policy,  planning  and investment decisions are subject to approval and monitoring requirements.
- 5. In applying the energy efficiency first principle, Member States shall:
- (a) promote and, where cost-benefit  analyses  are  required,  ensure  the  application  of,  and  make  publicly  available,  costbenefit  methodologies  that  allow  proper  assessment  of  the  wider  benefits  of  energy  efficiency  solutions  where appropriate, taking into account the entire life cycle and long-term perspective, system and cost efficiency, security of supply  and  quantification  from  the  societal,  health,  economic  and  climate  neutrality  perspectives,  sustainability  and circular economy principles in transition to climate neutrality;
- (b) address the impact on energy poverty;
- ( 38 ) Commission  Recommendation  (EU)  2021/1749  of  28  September  2021  on  Energy  Efficiency  First:  from  principles  to  practice  Guidelines and examples for its implementation in decision-making in the energy sector and beyond (OJ L 350, 4.10.2021, p. 9).

EN

- (c) identify an entity or entities responsible for monitoring the application of the energy efficiency first principle and the impacts  of  regulatory  frameworks,  including  financial  regulations,  planning,  policy  and  the  major  investment decisions referred to in paragraph 1 on energy consumption, energy efficiency and energy systems;
- (d) report to the Commission, as part of their integrated national energy and climate progress reports submitted pursuant to Article 17 of Regulation (EU) 2018/1999, on how the energy efficiency first principle was taken into account in the national  and,  where  applicable,  regional  and  local  planning,  policy  and  major  investment  decisions  related  to  the national and regional energy systems including at least the following:
- (i) an assessment of the application and benefits of the energy efficiency first principle in energy systems, in particular in relation to energy consumption;
- (ii) a list of actions taken to remove any unnecessary regulatory or non-regulatory barriers to the implementation of the energy efficiency first principle and of demand-side solutions, including through the identification of national legislation and measures that are contrary to the energy efficiency first principle.
- 6. By  11  April  2024,  the  Commission  shall  adopt  guidelines  providing  a  common  general  framework  including supervision, the monitoring  and  reporting  procedure,  which  Member  States  may  use  to  design  the  cost-benefit methodologies  referred  to  in  paragraph  5,  point  (a),  for  the  purpose  of  comparability,  while  leaving  the  possibility  for Member States to adapt to national and local circumstances.

Article 4

## Energy efficiency targets

- 1. Member States shall collectively ensure a reduction of energy consumption of at least 11,7 % in 2030 compared to the projections of the 2020 EU Reference Scenario so that the Union's final energy consumption amounts to no more than 763 Mtoe. Member States shall make efforts to collectively contribute to the indicative Union primary energy consumption target amounting to no more than 992,5 Mtoe in 2030.
- 2. Each Member State shall set an indicative national energy efficiency contribution based on final energy consumption to meet, collectively, the Union's binding final energy consumption target referred to in paragraph 1 of this Article and shall make  efforts  to  contribute  collectively  to  the  Union's  indicative  primary  energy  consumption  target  referred  to  in  that paragraph. Member States shall notify those contributions to the Commission, together  with an indicative trajectory for those  contributions,  as  part  of  the  updates  of  their  integrated  national  energy  and  climate  plans  submitted  pursuant  to Article 14(2) of Regulation (EU) 2018/1999, and of their integrated national energy and climate plans notified pursuant to Article 3 and Articles 7 to 12 of that Regulation. When doing so, Member States shall also express their contributions in terms  of  an  absolute  level  of  primary  energy  consumption  in  2030.  When  setting  their  indicative  national  energy efficiency contributions, Member States shall take into account the requirements set out in paragraph 3 of this Article and explain how, and on the basis of which data, the contributions have been calculated. To that end, they may use the formula set out in Annex I to this Directive.

Member States shall provide the shares of primary energy consumption and final energy consumption of energy end-use sectors,  as  defined  in  Regulation  (EC)  No  1099/2008,  including  industry,  residential,  services  and  transport,  in  their national energy efficiency contributions. Member States shall also indicate projections for energy consumption in ICT.

- 3. In setting their indicative national energy efficiency contributions referred to in paragraph 2, Member States shall take into account:
- (a) the Union's 2030 final energy consumption target of no more than 763 Mtoe and the primary energy consumption target of no more than 992,5 Mtoe, as provided for in paragraph 1;

EN

- (b) the measures provided for in this Directive;
- (c) other measures to promote energy efficiency within Member States and at Union level;
- (d) any relevant factors affecting efficiency efforts:
- (i) early efforts and actions in energy efficiency;
- (ii) the equitable distribution of efforts across the Union;
- (iii) the energy intensity of the economy;
- (iv) the remaining cost-effective energy-saving potential;
- (e) other national circumstances affecting energy consumption, in particular:
- (i) GDP and demographic evolution and forecast;
- (ii) changes of energy imports and exports, developments in the energy mix and the deployment of new sustainable fuels;
- (iii) the development of all sources of renewable energies, nuclear energy, carbon capture and storage;
- (iv) the decarbonisation of energy intensive industries;
- (v) the level of ambition in the national decarbonisation or climate neutrality plans;
- (vi) economic energy savings potential;
- (vii) current climate conditions and climate change forecast.
- 4. When applying the requirements set out in paragraph 3, a Member State shall ensure that its contribution in Mtoe is not more than 2,5 % above what it would have been had it resulted from the formula set out in Annex I.
- 5. The Commission shall assess that the collective contribution of Member States is at least equal to the Union's binding target  for  final  energy  consumption  set  out  in  paragraph  1  of  this  Article.  Where  the  Commission  concludes  that  it  is insufficient,  as  part  of  its  assessment  of  the  draft  updated  national  energy  and  climate  plans  pursuant  to  Article  9(2)  of Regulation (EU) 2018/1999, or at the latest by 1 March 2024, taking into consideration the updated 2020 EU Reference Scenario pursuant to this paragraph, the Commission shall submit to each Member State a corrected indicative national energy efficiency contribution for final energy consumption on the basis of:
- (a) the remaining collective reduction of final energy consumption needed to achieve the Union's binding target set out in paragraph 1;
- (b) the relative GHG intensity per GDP unit in 2019 among the Member States concerned;
- (c) the GDP of those Member States in 2019.

Before applying the formula in Annex I for the mechanism established in this paragraph and at the latest by 30 November 2023, the Commission shall update the 2020 EU Reference Scenario on the basis of the latest Eurostat data reported by the Member States, in accordance with Article 4(2), point (b), and Article 14 of Regulation (EU) 2018/1999.

Notwithstanding Article 37 of this Directive, Member States that wish to update their indicative national energy efficiency contributions  pursuant  to paragraph  2  of  this  Article,  using  the  updated  2020  EU  Reference  Scenario,  shall  notify  their updated indicative national energy efficiency contribution at the latest by 1 February 2024. Where a Member State wishes to  update  its  indicative  national  energy  efficiency  contribution,  it  shall  ensure  that  its  contribution  in  Mtoe  is  not  more than 2,5 % above what it would have been had it resulted from the formula set out in Annex I with the use of the updated 2020 EU Reference Scenario.

EN

Member States to which a corrected indicative national energy efficiency contribution was submitted by the Commission shall  update  their  indicative  national  energy  efficiency  contributions  pursuant  to  paragraph  2  of  this  Article,  with  the corrected indicative national energy efficiency contribution for final energy consumption together with an update of their indicative trajectory for those contribution and, where applicable, their additional measures, as part of the updates of their integrated  national  energy  and  climate  plans  submitted  pursuant  to  Article  14(2)  of  Regulation  (EU)  2018/1999.  The Commission  shall,  in  accordance  with  that  Regulation,  require  Member  States  to  submit,  without  delay,  their  corrected indicative energy efficiency contribution and, where applicable, their additional measures to ensure the application of the mechanism set out in this paragraph.

Where a Member State has notified an indicative national energy efficiency contribution for final energy consumption in Mtoe equal to or below what it would have been had it resulted from the formula set out in Annex I, the Commission shall not amend that contribution.

When  applying  the  mechanism  set  out  in  this  paragraph,  the  Commission  shall  ensure  that  there  is  no  difference  left between the sum of the national contributions of all Member States and the Union's binding target set out in paragraph 1.

- 6. Where the  Commission  concludes,  on  the  basis  of  its  assessment  pursuant  to  Article  29(1)  and  (3)  of  Regulation (EU) 2018/1999, that insufficient progress has been made towards meeting the energy efficiency contributions, Member States  that  are  above  their  indicative  trajectories  for  final  energy  consumption  referred  to  in  paragraph  2  of  this  Article shall  ensure  that  additional  measures  are  implemented  within  one  year  of  the  date  of  receipt  of  the  Commission's assessment  in  order  to  get  back on  track  to  reach  their  energy  efficiency  contributions.  Those  additional  measures  shall include, but shall not be limited to, at least one of the following measures:
- (a) national  measures  delivering  additional  energy  savings,  including  stronger  project  development  assistance  for  the implementation of energy efficiency investment measures;
- (b) increasing the energy savings obligation set out in Article 8 of this Directive;
- (c) adjusting the obligation for public sector;
- (d) making  a  voluntary  financial  contribution  to  the  national  energy  efficiency  fund  referred  to  in  Article  30  of  this Directive  or  another  financing  instrument  dedicated  to  energy  efficiency,  where  the  annual  financial  contributions shall be equal to the investments required to reach the indicative trajectory.

Where a Member State's final energy consumption is above its indicative trajectory for final energy consumption referred to in  paragraph  2  of  this  Article,  it  shall  include  in  its  integrated  national  energy  and  climate  progress  report  submitted pursuant to Article 17 of Regulation (EU) 2018/1999 an explanation of the measures it will take to cover the gap in order to  ensure  that  it  reaches  its  national  energy  efficiency  contributions  and  the  amount  of  energy  savings  expected  to  be delivered.

The  Commission  shall  assess  whether  the  national  measures  referred  to  in  this  paragraph  are  sufficient  to  achieve  the Union's  energy  efficiency  targets.  Where  national  measures  are  deemed  to  be  insufficient,  the  Commission  shall,  as appropriate, propose measures and exercise its power at Union level in order to ensure, in particular, the achievement of the Union's 2030 targets for energy efficiency.

- 7. The Commission shall assess by 31 December 2026 any methodological changes in the data reported pursuant to Regulation (EC)  No  1099/2008,  in  the  methodology  for  calculating energy  balance,  and  in  energy  models  for  European energy  use,  and,  if  necessary,  propose  technical  calculation  adjustments  to  the  Union's  2030  targets  with  a  view  to maintaining the level of ambition set out in paragraph 1 of this Article.

EN

L  231/36

CHAPTER II

## EXEMPLARY ROLE OF PUBLIC SECTOR

Article 5

## Public sector leading on energy efficiency

- 1. Member States shall ensure that the total final  energy consumption of all public bodies combined is reduced by at least 1,9 % each year, when compared to 2021.

Member  States  may  choose  to  exclude  public  transport  or  the  armed  forces  from  the  obligation  laid  down  in  the  first subparagraph.

For the purposes of the first and second subparagraphs, Member States shall establish a baseline, which includes the final energy consumption of all public bodies, except in public transport or  the armed forces, for 2021. Energy consumption reduction of public transport and armed forces is indicative and may still count for fulfilling the obligation under the first subparagraph even if excluded from the baseline under this Article.

- 2. During a transitional period ending on 11 October 2027 the target set out in paragraph 1 shall be indicative. During that transitional period, Member States may use estimated consumption data, and, by the same date, Member States shall adjust  the  baseline  and  align  the  estimated  final  energy  consumption  of  all  public  bodies  to  the  actual  final  energy consumption of all public bodies.
- 3. The  obligation  laid  down  in  paragraph  1  shall  not  include,  until  31  December  2026,  the  energy  consumption  of public bodies in local administrative units with a population of less than 50 000 and, until 31 December 2029, the energy consumption of public bodies in local administrative units with a population of less than 5 000 inhabitants.
- 4. A Member State may take into account climatic variations within it when calculating its public bodies' final energy consumption.
- 5. Member States shall include in the updates, submitted pursuant to Article 14(2) of Regulation (EU) 2018/1999, of their national energy and climate plans, notified pursuant to Article 3 and Articles 7 to 12 of that Regulation, the amount of energy consumption reduction to be achieved by all public bodies, disaggregated by sector, and the measures that they plan  to  adopt  for  the  purpose  of  achieving  those  reductions.  As  part  of  their  integrated  national  energy  and  climate progress  reports  submitted  pursuant  to  Article  17  of  Regulation  (EU)  2018/1999,  Member  States  shall  report  to  the Commission the final energy consumption reduction achieved every year.
- 6. Member States shall ensure that regional and local authorities establish specific energy efficiency measures in their long-term  planning  tools,  such  as  decarbonisation  or  sustainable  energy  plans,  after  consulting  relevant  stakeholders, including energy agencies where appropriate, and the public, including, in particular, vulnerable groups which are at risk of being affected by energy poverty or are more susceptible to its effects.

Member States shall also ensure that the competent authorities take actions to mitigate significant negative direct or indirect impacts of energy efficiency measures on energy poor, low-income households or vulnerable groups when designing and implementing energy efficiency measures.

- 7. Member  States  shall  support  public  bodies.  Such  support  may,  without  prejudice  to  the  State  aid  rules,  include financial  and  technical  support,  for  the  purpose  of  taking  up  energy  efficiency  improvement  measures  and  encouraging public  bodies  to  take  into  account  the  wider  benefits  beyond  energy  savings,  for  example  the  quality  of  the  indoor environment,  including  at  regional  and  local  level,  by  providing  guidelines,  promoting  competence  building,  the acquisition of skills and training opportunities, and by encouraging cooperation among public bodies.

EN

- 8. Member States  shall  encourage  public  bodies  to  consider  life  cycle  carbon  emissions  as  well  as  the  economic  and social benefits of their public bodies' investment and policy activities.
- 9. Member States shall encourage public bodies to improve the energy performance of buildings owned or occupied by public bodies, including by means of the replacement of old and inefficient heaters.

## Article 6

## Exemplary role of public bodies' buildings

- 1. Without prejudice to Article 7 of Directive 2010/31/EU, each Member State shall ensure that at least 3 % of the total floor area of heated and/or cooled buildings that are owned by public bodies is renovated each year to be transformed into at least nearly zero-energy buildings or zero-emission buildings in accordance with Article 9 of Directive 2010/31/EU.

Member States may choose which buildings to include in the 3 % renovation requirement, giving due consideration to costeffectiveness and technical feasibility in the choice of buildings to renovate.

Member States may exempt social housing from the obligation to renovate referred to in the first subparagraph where such renovations would not be cost neutral or would lead to rent increases for people living in social housing unless such rent increases are no higher than the economic savings on the energy bill.

Where  public  bodies  occupy  a  building  that  they  do  not  own,  they  shall  negotiate  with  the  owner,  in  particular  when reaching a trigger point such as the renewal of rental, change of use, significant repair or maintenance work, with the aim of establishing contractual clauses for the building to become  at  least a nearly zero-energy building or zeroemission building.

The rate of at least 3 % shall be calculated on the total floor area of buildings which have a total useful floor area of over 250 m 2 , that are owned by public bodies and that, on 1 January 2024, are not nearly zero-energy buildings.

- 2. Member States may apply requirements that are less stringent than those laid down in paragraph 1 for the following categories of buildings:
- (a) buildings officially protected as part of a designated environment, or because of their special architectural or historical merit, in so far as compliance with certain minimum energy performance requirements would alter their character or appearance unacceptably;
- (b) buildings owned by the armed forces or central government and serving national defence purposes, apart from single living quarters or office buildings for the armed forces and other staff employed by national defence authorities;
- (c) buildings used as places of worship and for religious activities.

Member States may decide not to renovate any building that is not referred to in the first subparagraph of this paragraph up to the level provided for in paragraph 1 if they assess that it is not technically, economically or functionally feasible for that building to be transformed into a nearly zero-energy building. Where they so decide, Member States shall not count the renovation of that building towards the fulfilment of the requirement set out in paragraph 1.

- 3. In order to front load energy savings and to provide an incentive for early action, a Member State that renovates more than 3 % of the total floor area of its buildings in accordance with paragraph 1 in any year until 31 December 2026 may count the surplus towards the annual renovation rate of any of the following three years. A Member State that renovates more than  3  %  of  the  total  floor  area  of  its  buildings  as  of  1  January  2027 may count  the  surplus  towards  the  annual renovation rate of the following two years.

EN

- 4. Member States may count towards the annual renovation rate of buildings new buildings owned as replacements for specific public bodies' buildings demolished in any of the two previous years. This shall apply only where they would be more  cost  effective  and  sustainable  in  terms  of  the  energy  and  lifecycle  CO 2 emissions  achieved  compared  to  the renovations of such buildings. The general criteria, methodologies and procedures to identify such exceptional cases shall be clearly set out and published by each Member State.
- 5. By 11 October 2025, Member States shall, for the purposes of this Article, establish and make publicly available and accessible an inventory of heated and/or cooled buildings that are owned or occupied by public bodies and that have a total useful floor area of more than 250 m . Member States shall update that inventory at least every two years. The inventory 2 shall  be  linked  to  the  building  stock overview carried  out  in  the  framework of  the  national  building  renovation plans  in accordance with Directive 2010/31/EU and the relevant databases.

Publicly  available  and  accessible  data  about  building  stock  characteristics,  buildings  renovation  and  energy  performance may be aggregated by the EU Building Stock Observatory to ensure a better understanding of the energy performance of the building sector through comparable data.

The inventory shall contain at least the following data:

- (a) the floor area in m ; 2
- (b) the measured annual energy consumption of heat, cooling, electricity and hot water when those data are available;
- (c) the energy performance certificate of each building issued in accordance with Directive 2010/31/EU.
- 6. Member States may decide to apply an alternative approach to that set out in paragraphs 1 to 4 for the purpose of achieving,  every  year,  an  amount  of  energy  savings  in  the  buildings  of  public  bodies  which  is  at  least  equivalent  to  the amount required in paragraph 1.

For the purpose of applying that alternative approach, Member States shall:

- (a) ensure that, each year, a renovation passport is introduced, where applicable, for buildings representing at least 3 % of the  total  floor  area  of  heated  and/or  cooled  buildings  that  are  owned  by  public  bodies.  For  those  buildings,  the renovation to nearly zero-energy building shall be achieved at the latest by 2040;
- (b) estimate the energy savings that paragraphs 1 to 4 would generate by using appropriate standard values for the energy consumption  of  reference  public  bodies'  buildings  before  and  after  renovation  to  be  transformed  into  nearly  zeroenergy buildings as referred to in Directive 2010/31/EU.

Member States that decide to apply the alternative approach shall notify to the Commission, by 31 December 2023, their projected  energy  savings  to  achieve  at  least  the  equivalent  of  energy  savings  in  the  buildings  covered  by  paragraph  1 by 31 December 2030.

Article 7

## Public procurement

- 1. Member States shall ensure that contracting authorities and contracting entities, when concluding public contracts and  concessions  with  a  value  equal  to  or  greater  than  the  thresholds  laid  down  in  Article  8  of  Directive  2014/23/EU, Article 4 of Directive 2014/24/EU and Article 15 of Directive 2014/25/EU, purchase only products, services buildings and works  with  high  energy-efficiency  performance  in  accordance  with  the  requirements  referred  to  in  Annex  IV  to  this Directive, unless it is not technically feasible.

EN

Member States shall also ensure that in concluding the public contracts and concessions with a value equal to or greater than the thresholds referred to in the first subparagraph, contracting authorities and contracting entities apply the energy efficiency first  principle in  accordance with Article 3, including for  those public contracts and concessions for  which no specific requirements are provided for in Annex IV.

- 2. The obligations referred to in paragraph 1 of this Article shall not apply if they undermine public security or impede the  response  to  public  health  emergencies.  The  obligations  referred  to  in  paragraph  1  of  this  Article  shall  apply  to  the contracts  of  the  armed  forces  only  to  the  extent  that  their  application  does  not  cause  any  conflict  with  the  nature  and primary aim of  the activities  of  the  armed forces.  The obligations  shall  not  apply  to contracts  for  the  supply of  military equipment as defined in Directive 2009/81/EC of the European Parliament and of the Council ( 39 ).
- 3. Notwithstanding Article 29(4), Member States shall ensure that contracting authorities and contracting entities assess the  feasibility  of  concluding  long-term  energy  performance  contracts  that  provide  long-term  energy  savings  when procuring service contracts with significant energy content.
- 4. Without prejudice to paragraph 1 of this Article, when purchasing a product package fully covered by a delegated act adopted under Regulation (EU) 2017/1369, Member States may require that the aggregate energy efficiency take priority over  the  energy  efficiency  of  individual  products  within  that  package,  by  purchasing  the  product  package  that  complies with the criterion of belonging to the highest available energy efficiency class.
- 5. Member  States  may  require  that  contracting  authorities  and  contracting  entities,  when  concluding  contracts  as referred to in paragraph 1 of this Article, take into account, where appropriate, wider sustainability, social, environmental and  circular  economy  aspects  in  procurement  practices  with  a  view  to  achieving  the  Union's  decarbonisation  and  zero pollution  objectives.  Where  appropriate,  and  in  accordance  with  Annex  IV,  Member  States  shall  require  contracting authorities  and  contracting entities  to take  into account  Union green public procurement  criteria or  available  equivalent national criteria.

To  ensure  transparency  in  the  application  of  energy  efficiency  requirements  in  the  procurement  process,  Member  States shall  ensure  that  contracting  authorities  and  contracting  entities  make  publicly  available  information  on  the  energy efficiency impact of contracts with a value equal to or greater than the thresholds referred to in paragraph 1 by publishing that  information in the respective notices on Tenders Electronic Daily (TED), in accordance with Directives 2014/23/EU, 2014/24/EU  and  2014/25/EU,  and  Commission  Implementing  Regulation  (EU)  2019/1780 ( 40 ).  Contracting  authorities may decide to require that tenderers disclose information on the life cycle global warming potential, the use of low carbon materials and the circularity of materials used for a new building and for a building to be renovated. Contracting authorities may make that information publicly available for  the contracts, in particular for new buildings having a floor area larger than 2 000 m 2 .

Member  States  shall support  contracting authorities and  contracting entities in the uptake of energy  efficiency requirements, including at regional and local level, by providing clear rules and guidelines including methodologies on the assessment  of  life  cycle  costs  and  environment  impacts  and  costs,  setting  up  competence  support  centres,  encouraging cooperation  amongst  contracting  authorities,  including  across  borders,  and  using  aggregated  procurement  and  digital procurement where possible.

( 39 ) Directive  2009/81/EC  of  the  European  Parliament  and  of  the  Council  of  13  July  2009  on  the  coordination  of  procedures  for  the award of certain works contracts, supply contracts and service contracts by contracting authorities or entities in the fields of defence and security, and amending Directives 2004/17/EC and 2004/18/EC (OJ L 216, 20.8.2009, p. 76).

( 40 ) Commission Implementing Regulation  (EU)  2019/1780  of  23  September  2019  establishing  standard  forms  for  the  publication  of notices in the field of public procurement and repealing Implementing Regulation (EU) 2015/1986 ('eForms') (OJ L 272, 25.10.2019, p. 7)

EN

- 6. Where appropriate, the Commission may provide further guidance to national authorities and procurement officials in  the  application  of  energy  efficiency  requirements  in  the  procurement  process.  Such  support  may  strengthen  existing fora for  the purpose of supporting Member States, such as by means of concerted action, and may assist them in taking the green public procurement criteria into account.
- 7. Member  States  shall  establish  the  legal  and  regulatory  provisions,  and  administrative  practices,  regarding  public purchasing  and  annual  budgeting  and  accounting,  necessary  to  ensure  that  individual  contracting  authorities  are  not deterred  from  making  investments  in  improving  energy  efficiency  and  from  using  energy  performance  contracting  and third-party financing mechanisms on a long-term contractual basis.
- 8. Member States shall remove any regulatory or  non-regulatory barriers to energy efficiency, in particular as regards legal  and  regulatory  provisions,  and  administrative  practices,  regarding  public  purchasing  and  annual  budgeting  and accounting, with a view to ensuring that individual public bodies are not deterred from making investments in improving energy efficiency  and from using energy performance contracting and third-party financing mechanisms on a long-term contractual basis.

Member States shall report to the Commission on the measures taken to address the barriers to uptake of energy efficiency improvements as part of their integrated national energy and climate progress reports submitted pursuant to Article 17 of Regulation (EU) 2018/1999.

## CHAPTER III

## EFFICIENCY IN ENERGY USE

## Article 8

## Energy savings obligation

- 1. Member States shall achieve cumulative end-use energy savings at least equivalent to:
- (a) new savings each year from 1 January 2014 to 31 December 2020 of 1,5 % of annual energy sales to final customers by volume, averaged over the most recent three-year period preceding 1 January 2013. Sales of energy, by volume, used in transport may be excluded, in whole or in part, from that calculation;
- (b) new savings each year from 1 January 2021 to 31 December 2030 of:
- (i) 0,8 % of annual final energy consumption from 1 January 2021 to 31 December 2023, averaged over the most recent three-year period preceding 1 January 2019;
- (ii) 1,3 % of annual final energy consumption from 1 January 2024 to 31 December 2025, averaged over the most recent three-year period preceding 1 January 2019;
- (iii) 1,5 % of annual final energy consumption from 1 January 2026 to 31 December 2027, averaged over the most recent three-year period preceding 1 January 2019;
- (iv) 1,9 % of annual final energy consumption from 1 January 2028 to 31 December 2030, averaged over the most recent three-year period preceding 1 January 2019.

By way of derogation from point (b)(i) of the first subparagraph, Cyprus and Malta shall achieve new savings each year from 1 January 2021 to 31 December 2023, equivalent to 0,24 % of annual final energy consumption, averaged over the most recent three-year period prior to 1 January 2019.

By way of derogation from points (b)(ii), (iii) and (iv) of the first subparagraph, Cyprus and Malta shall achieve new savings each year from 1 January 2024 to 31 December 2030 equivalent to 0,45 % of annual FEC, averaged over the most recent three-year period preceding 1 January 2019.

EN

Member States shall decide how to phase the calculated quantity of new savings over each period referred to in points (a) and (b) of  the first subparagraph, provided that the required total cumulative end-use energy savings have been achieved by the end of each obligation period.

Member States shall continue to achieve new annual savings in accordance with the savings rate provided for in point (b)(iv) of the first subparagraph for ten-year periods after 2030.

- 2. Member  States  shall  achieve  the  amount  of  energy  savings  required  under  paragraph  1  of  this  Article  either  by establishing an energy efficiency obligation scheme as referred to in Article 9 or by adopting alternative policy measures as referred  to  in  Article  10.  Member  States  may  combine  an  energy  efficiency  obligation  scheme  with  alternative  policy measures.  Member  States  shall  ensure  that  energy  savings  resulting  from  the  policy  measures  referred  to  in  Articles  9 and 10 and Article 30(14) are calculated in accordance with Annex V.
- 3. Member States shall implement energy efficiency obligation schemes, alternative policy measures, or a combination of both, or programmes or measures financed under a national energy efficiency fund, as a priority among, but not limited to,  people  affected  by  energy  poverty,  vulnerable  customers,  people  in  low-income  households  and,  where  applicable, people living in social housing. Member States shall ensure that policy measures implemented pursuant to this Article have no adverse effect on those persons. Where applicable, Member States shall make the best possible use of funding, including public funding, funding facilities established at Union level, and revenues from allowances pursuant to Article 24(3), point (b), with the aim of removing adverse effects and ensuring a just and inclusive energy transition.

For  the  purpose  of  achieving  the  energy  savings  required  under  paragraph  1  and  without  prejudice  to  Regulation (EU)  2019/943  and  Directive  (EU)  2019/944,  Member  States  shall,  for  the  purpose  of  designing  such  policy  measures, consider and promote the role of renewable energy communities and citizen energy communities in the contribution to the implementation towards those policy measures.

Member States  shall  establish  and  achieve  a  share  of  the  required  amount  of  cumulative  end-use  energy  savings  among people affected by energy poverty, vulnerable customers, people in low-income households and, where applicable, people living in social housing. This share shall at least be equal to the proportion of households in energy poverty as assessed in their national energy and climate plans established in accordance with Article 3(3), point (d), of Regulation (EU)  2018/1999.  Member  States  shall,  in  their  assessment  of  the  share  of  energy  poverty  in  their  national  energy  and climate plans, consider the following indicators:

- (a) the inability to keep the home adequately warm (Eurostat, SILC [ilc\_mdes01]);
- (b) the arrears on utility bills (Eurostat, SILC [ilc\_mdes07]);
- (c) the total population living in a dwelling with a leaking roof, damp walls, floors or foundation, or rot in window frames or floor (Eurostat, SILC [ilc\_mdho01]);
- (d) at-risk-of-poverty rate (Eurostat, SILC and ECHP surveys [ilc\_li02]) (cutoff point: 60 % of median equivalised income after social transfers).

If a Member State has not notified the share of households in energy poverty as assessed in their national energy and climate plan,  the  share  of  the  required  amount  of  cumulative  end-use  energy  savings  among  people  affected  by energy  poverty, vulnerable customers, people in low-income households and, where applicable, people living in social housing, shall be at least equal to the arithmetic average share of  the indicators referred to in the third subparagraph for  the year 2019 or, if not available for 2019, for the linear extrapolation of their values for the last three years that are available.

EN

- 4. Member States shall include information about the indicators applied, the arithmetic average share and the outcome of  policy  measures  established  in  accordance  with  paragraph  3 of  this  Article  in  the  updates  of  their  integrated  national energy  and  climate  plans  submitted  pursuant  to  Article  14(2)  of  Regulation  (EU)  2018/1999,  in  their  subsequent integrated national energy and climate plans notified pursuant to Article 3 and Articles 7 to 12 of that Regulation, and in the related national energy and climate progress reports submitted pursuant to Article 17 of that Regulation.
- 5. Member States may count energy savings that stem from policy measures, whether introduced by 31 December 2020 or  after  that  date,  provided  that  those  measures  result  in  new  individual  actions  that  are  carried  out  after  31  December 2020. Energy savings achieved in any obligation period shall not count towards the amount of required energy savings for the previous obligation periods set out in paragraph 1.
- 6. Provided  that  Member  States  achieve  at  least  their  cumulative  end-use  energy  savings  obligation  referred  to  in paragraph 1, first subparagraph, point (b)(i), they may calculate the required amount of energy savings referred to in that point by one or more of the following means:
- (a) applying an annual savings rate on energy sales to final customers or on final energy consumption, averaged over the most recent three-year period preceding 1 January 2019;
- (b) excluding, in whole or in part, energy used in transport from the calculation baseline;
- (c) making use of any of the options set out in paragraph 8.
- 7. Where Member States make use of any of the possibilities provided for in paragraph 6 regarding the required energy savings referred to in paragraph 1, first subparagraph, point (b)(i), they shall establish:
- (a) their own annual savings rate that will be applied in the calculation of their cumulative end-use energy savings, which shall ensure that the final amount of their net energy savings is no lower than those required under that point;
- (b) their own calculation baseline, which may exclude, in whole or in part, energy used in transport.
- 8. Subject to paragraph 9, each Member State may:
- (a) carry  out  the  calculation  required  under  paragraph  1,  first  subparagraph,  point  (a),  using  values  of  1  %  in  2014 and 2015, 1,25 % in 2016 and 2017, and 1,5 % in 2018, 2019 and 2020;
- (b) exclude from the calculation all or part of  the sales of energy used, by volume, with respect to the obligation period referred  to  in  paragraph  1,  first  subparagraph,  point  (a),  or  final  energy  consumed,  with  respect  to  the  obligation period referred to in point (b)(i), of that subparagraph, by industrial activities listed in Annex I to Directive 2003/87/EC;
- (c) count towards the amount of required energy savings in paragraph 1, first subparagraph, points (a) and (b)(i), energy savings  achieved  in  the  energy  transformation,  distribution  and  transmission  sectors,  including  efficient  district heating and cooling infrastructure, as a result of implementing the requirements set out in in Article 25(4), point (a), of  Article  26(7),  and  Article  27(1),  (5)  to  (9)  and  (11).  Member  States  shall  inform  the  Commission  about  their intended policy measures under this point for the period from 1 January 2021 to 31 December 2030 as part of their integrated national energy and climate plans notified pursuant to Article 3 and Articles 7 to 12. The impact of those measures shall be calculated in accordance with Annex V and included in those plans;
- (d) count  towards  the  amount  of  required  energy  savings,  energy  savings  resulting  from  individual  actions  newly implemented since 31 December 2008 that continue to have an impact in 2020 with respect to the obligation period referred  to  in  paragraph  1,  first  subparagraph,  point  (a),  and  beyond  2020  with  respect  to  the  period  referred  to  in point (b)(i), of that subparagraph, and which can be measured and verified;

EN

- (e) count towards the amount of required energy savings, energy savings that stem from policy measures, provided that it can be demonstrated that those measures result in individual actions carried out from 1 January 2018 to 31 December 2020 which deliver savings after 31 December 2020;
- (f) exclude from the calculation of  the amount of required energy savings pursuant to paragraph 1, first subparagraph, points (a) and (b)(i),  30  %  of  the  verifiable  amount of energy  generated on or  in buildings  for own use as a result of policy measures promoting new installation of renewable energy technologies;
- (g) count towards the amount of required energy savings pursuant to paragraph 1, first subparagraph, points (a) and (b)(i), energy savings that exceed the energy savings required for the obligation period from 1 January 2014 to 31 December 2020,  provided  that  those  savings  result  from  individual  actions  carried  out  under  policy  measures  referred  to  in Articles  9  and  10,  notified  by  Member  States  in  their  national  energy  efficiency  action  plans  and  reported  in  their progress reports in accordance with Article 26.
- 9. Member States shall apply and calculate the effect of the options chosen under paragraph 8 for the period referred to in paragraph 1, first subparagraph, points (a) and (b)(i), separately:
- (a) for  the calculation of the amount of energy savings required for the obligation period referred to in paragraph 1, first subparagraph, point (a),  Member States  may make use of  the options listed in paragraph 8,  points (a)  to (d).  All  the options chosen under paragraph 8 taken together shall amount to no more than 25 % of the amount of energy savings referred to in paragraph 1, first subparagraph, point (a);
- (b) for  the calculation of the amount of energy savings required for the obligation period referred to in paragraph 1, first subparagraph, point (b)(i), Member States may make use of the options listed in paragraph 8, points (b) to (g), provided that the individual actions referred to in paragraph 8, point (d), continue to have a verifiable and measurable impact after  31  December  2020.  All  the  options  chosen  under  paragraph  8  taken  together  shall  not  lead  to  a  reduction  of more than 35 % of the amount of energy savings calculated in accordance with paragraphs 6 and 7.

Regardless of whether Member States exclude, in whole or in part, energy used in transport from their calculation baseline or make use of any of the options listed in paragraph 8, they shall ensure that the calculated net amount of new savings to be achieved in final energy consumption during the obligation period referred to in paragraph 1, first subparagraph, point (b)(i), from 1 January 2021 to 31 December 2023 is not lower than the amount resulting from applying the annual savings rate referred to in that point.

- 10. Member States shall describe in the updates of their integrated national energy and climate plans submitted pursuant to Article 14(2) of Regulation (EU) 2018/1999, in their subsequent integrated national energy and climate plans notified pursuant to Article 3 and Articles 7 to 12 of Regulation (EU) 2018/1999 and in accordance with Annex III to Regulation (EU) 2018/1999, and respective progress reports the calculation of the amount of energy savings to be achieved over the period  from  1  January  2021 to  31  December  2030 and  shall,  if  relevant,  explain  how  the  annual  savings  rate  and  the calculation  baseline  were  established,  and  how and  to what  extent  the  options  referred  to  in  paragraph  8  of  this  Article were applied.
- 11. Member States shall notify the Commission of the amount of the required energy savings referred to in paragraph 1, first  subparagraph, point (b), and paragraph 3 of  this Article, a description of  the policy measures to be implemented to achieve the required total amount of the cumulative end-use energy savings and their calculation methodologies pursuant to  Annex  V  to  this  Directive,  as  part  of  the  updates  of  their  integrated  national  energy  and  climate  plans  submitted pursuant to Article 14(2) of Regulation (EU) 2018/1999, and as part of their integrated national energy and climate plans notified pursuant to Article 3 and Articles 7 to 12 of Regulation (EU) 2018/1999. Member States shall use the reporting template provided to the Member States by the Commission.

EN

- 12. Where on the basis of  the assessment of  the integrated  national energy and climate progress reports pursuant to Article 29 of Regulation (EU) 2018/1999, or of the draft or final update of the latest notified integrated national energy and climate plan submitted pursuant to Article 14 of Regulation (EU) 2018/1999, or of the assessment of the subsequent draft  and  final  integrated  national  energy  and  climate  plans  notified  pursuant  to  Article  3  and  Articles  7  to  12  of Regulation  (EU)  2018/1999,  the  Commission  concludes  that  policy  measures  do  not  ensure  the  achievement  of  the required  amount  of  cumulative  end-use  energy  savings  by  the  end  of  the  obligation  period,  the  Commission  may  issue recommendations  in  accordance  with  Article  34  of  Regulation  (EU)  2018/1999  to  the  Member  States  whose  policy measures it deems to be insufficient to ensure the fulfilment of their energy savings obligations.
- 13. Where  a  Member  State  has  not  achieved  the  required  cumulative  end-use  energy  savings  by  the  end  of  each obligation period set out in paragraph 1, it shall achieve the outstanding energy savings in addition to the cumulative enduse energy savings required by the end of the following obligation period.

Alternatively, where a Member State has achieved cumulative end-use energy savings above the required level by the end of each obligation period set out in paragraph 1, it shall be entitled to carry the eligible amount of no more than 10 % of such surplus into the following obligation period without the target commitment being increased.

- 14. As  part  of  their  updates  of  national  energy  and  climate  plans  submitted  pursuant  to  Article  14(2)  of  Regulation (EU)  2018/1999,  their  relevant  national  energy  and  climate  progress  reports  submitted  pursuant  to  Article  17  of  that Regulation, and their subsequent integrated national energy and climate plans notified pursuant to Article 3 and Articles 7 to 12 of that Regulation, Member States shall demonstrate including, where appropriate, with evidence and calculations:
- (a) that where there is an overlap in the impact of policy measures or individual actions, there is no double counting of energy savings;
- (b) how energy savings achieved pursuant to paragraph 1, first subparagraph, point (b), of this Article, contribute to the achievement of their national contribution pursuant to Article 4;
- (c) that  policy  measures  are  established  for  fulfilling  their  energy  savings  obligation,  designed  in  compliance  with  this Article and that those policy measures are eligible and appropriate to ensure the achievement of the required amount of cumulative end-use energy savings by the end of each obligation period.

Article 9

## Energy efficiency obligation schemes

- 1. Where Member States decide to fulfil their obligations to achieve the amount of savings required under Article 8(1) by way of an energy efficiency obligation scheme, they shall ensure that the obligated parties referred to in paragraph 3 of this Article operating in each Member State's territory achieve, without prejudice to Article 8(8) and (9), their cumulative enduse energy savings requirement as set out in Article 8(1).

Where  applicable,  Member  States  may  decide  that  obligated  parties  fulfil  those  savings,  in  whole  or  in  part,  as  a contribution to the national energy efficiency fund in accordance with Article 30(14).

- 2. Where Member States decide to fulfil their obligations to achieve the amount of savings required under Article 8(1) by way  of  an  energy  efficiency  obligation  scheme,  they  may  appoint  an  implementing  public  authority  to  administer  the scheme.

EN

- 3. Member  States  shall  designate,  on  the  basis  of  objective  and  non-discriminatory  criteria,  obligated  parties  among transmission  system  operators,  distribution  system  operators,  energy  distributors,  retail  energy  sales  companies  and transport fuel distributors or  transport fuel retailers operating in their  territory. The amount of energy savings needed to fulfil  the  obligation  shall  be  achieved  by  the  obligated  parties  among  final  customers,  designated  by  the  Member  State, independently of  the  calculation  made  pursuant  to Article  8(1)  or,  if  Member  States  so  decide,  through  certified  savings stemming from other parties as set out in paragraph 11, point (a), of this Article.
- 4. Where  retail  energy  sales  companies  are  designated  as  obligated  parties  under  paragraph  3,  Member  States  shall ensure that, in fulfilling their obligation, retail energy sales companies do not create any barriers that impede consumers from switching from one supplier to another.
- 5. Member  States  may  require  obligated  parties  to  achieve  a  share  of  their  energy  savings  obligation  among  people affected by energy poverty, vulnerable customers, people in low-income households and, where applicable, people living in social  housing.  Member  States  may  also  require  obligated  parties  to  achieve  energy cost  reduction  targets,  provided  that they  result  in  end  use  energy  savings  and  are  calculated  in  accordance  with  Annex  V,  and  to  achieve  energy  savings  by promoting energy efficiency improvement measures, including financial support measures mitigating carbon price effects on SMEs and microenterprises.
- 6. Member States may require obligated parties  to work  with social  services,  regional  authorities,  local  authorities  or municipalities to promote energy efficiency improvement measures among people affected by energy poverty, vulnerable customers,  people  in  low-income  households  and,  where  applicable,  people  living  in  social  housing.  This  includes identifying  and  addressing  the  specific  needs  of  particular  groups  at  risk  of  energy  poverty  or  more  susceptible  to  its effects.  To  protect  people  affected by energy  poverty, vulnerable customers and, where applicable, people living in social housing, Member States shall encourage obligated parties to carry out actions such as renovation of buildings, including social housing, replacement of appliances, financial support and incentives for energy efficiency improvement measures in accordance  with  national  financing  and  support  schemes,  or  energy  audits.  Member  States  shall  ensure  the  eligibility  of measures for individual units located in multi-apartment buildings.
- 7. When applying paragraphs 5 and 6, Member States shall require obligated parties to report on an annual basis on the energy  savings  achieved  by  the  obligated  parties  from  actions  promoted  among  people  affected  by  energy  poverty, vulnerable customers, people in low-income households and, where applicable, people living in social housing, and shall require aggregated statistical information on their final customers, identifying changes in energy savings when compared to previously submitted information, and regarding technical and financial support provided.
- 8. Member States shall express the amount of energy savings required of each obligated party in terms of either primary energy consumption or final energy consumption. The method chosen to express the amount of energy savings required shall also be used to calculate the savings claimed by obligated parties. When converting the amount of energy savings, the net  calorific  values  set  out  in  Annex  VI  of  Commission  Implementing  Regulation  (EU)  2018/2066 ( 41 ) and  the  primary energy factor pursuant to Article 31 shall apply unless the use of other conversion factors can be justified.
- 9. Member  States  shall  establish measurement,  control  and  verification  systems  for carrying out documented verification on at least a statistically significant proportion and representative sample  of the energy efficiency improvement measures put in place by the obligated parties. The measurement, control and verification shall be carried out  independently  of  the  obligated  parties.  Where  an  entity  is  an  obligated  party  under  a  national  energy  efficiency obligation  scheme  under  Article  9  and  under  the  EU  ETS  for  buildings  and  road  transport  in  accordance  with Directive  2003/87/EC,  the  monitoring  and  verification  system  shall  ensure  that  the  carbon  price  passed  through  when releasing fuel for consumption in accordance with Directive 2003/87/EC shall be taken into account in the calculation and reporting of energy savings of the entity's energy saving measures.

( 41 ) Commission Implementing Regulation (EU) 2018/2066 of 19 December 2018 on the monitoring and reporting of greenhouse gas emissions pursuant to Directive 2003/87/EC of the European Parliament and of the Council and amending Commission Regulation (EU) No 601/2012 (OJ L 334, 31.12.2018, p. 1).

EN

- 10. Member States shall inform the Commission, as part of the integrated national energy and climate progress reports submitted pursuant to Article 17 of Regulation (EU) 2018/1999, on the measurement, control and verification systems put in place, including the methods used, the issues identified and how those issues were addressed.
- 11. Within  the  energy  efficiency  obligation  scheme,  Member  States  may  authorise  obligated  parties  to  carry  out  the following:
- (a) count  towards  their  obligation  certified  energy  savings  achieved  by  energy  service  providers  or  other  third  parties, including when  obligated  parties promote  measures  through  other  State-approved  bodies  or through  public authorities that may involve formal partnerships and may be in combination with other sources of finance;
- (b) count  savings  obtained  in  a  given  year  as  if  they  had  instead  been  obtained  in  any  of  the  four  previous  or  three following years as long as this is not beyond the end of the obligation periods set out in Article 8(1).

Where Member States so authorise, they shall ensure that the certification of energy savings referred to in point (a) of the first  subparagraph  follows  an  approval  process  that  is  put  in  place  in  the  Member  States,  that  is  clear,  transparent,  and open to all market participants, and that aims to minimise the costs of certification.

Member States shall  assess  and,  if  appropriate,  take  measures  to  minimise  the  impact  of  the  direct  and  indirect  costs  of energy  efficiency  obligation  schemes  on  the  competitiveness  of  energy-intensive  industries  exposed  to  international competition.

- 12. Member States shall, on an annual basis, publish the energy savings achieved by each obligated party, or each subcategory of obligated party, and in total under the scheme.

## Article 10

## Alternative policy measures

- 1. Where Member States decide to fulfil their obligations to achieve the savings required under Article 8(1) by way of alternative  policy  measures,  they shall  ensure,  without  prejudice  to Article  8(8)  and  (9),  that  the  energy  savings  required under Article 8(1) are achieved among final customers.
- 2. For all  measures  other  than  those  relating  to taxation,  Member  States  shall  put  in place  measurement,  control  and verification  systems  under  which  documented  verification  is  carried  out  on  at  least  a  statistically  significant  proportion and representative sample of  the  energy efficiency improvement measures put in place by the participating or entrusted parties.  The  measurement,  control  and  verification  shall  be  carried  out  independently  of  the  participating  or  entrusted parties.
- 3. Member States shall inform the Commission, as part of the integrated national energy and climate progress reports submitted pursuant to Article  17  of  Regulation  (EU)  2018/1999,  on  the  measurement,  control  and  verification  systems put in place, including methods used, issues identified and how they were addressed.
- 4. When reporting a taxation measure, Member States shall demonstrate how the effectiveness of the price signal, such as tax rate and visibility over time, has been ensured in the design of the taxation measure. Where there is a decrease in the tax rate, Member States shall justify how the taxation measures still result in new energy savings.

## Article 11

## Energy management systems and energy audits

- 1. Member States shall ensure that enterprises with an average annual consumption higher than 85 TJ of energy over the previous  three  years, taking all energy  carriers together, implement  an  energy  management  system.  The  energy management system shall be certified by an independent body, in accordance with the relevant European or international standards.

EN

Member States shall ensure that the enterprises referred to in the first subparagraph have an energy management system in place at the latest by 11 October 2027.

- 2. Member States shall ensure that enterprises with an average annual consumption higher than 10 TJ of energy over the previous three years, taking all energy carriers together, which do not implement an energy management system are subject to an energy audit.

Such energy audits shall be either:

- (a) carried  out  in  an  independent  and  cost-effective  manner  by  qualified  or  accredited  experts,  in  accordance  with Article 28; or
- (b) implemented and supervised by independent authorities under national legislation.

Member  States  shall  ensure  that  the  enterprises  referred  to  in  the  first  subparagraph  carry  out  a  first  energy  audit by 11 October 2026 and that subsequent energy audits are carried out at least every four years. Where such enterprises already carry out energy audits in accordance with the first subparagraph, they shall continue to do so at least every four years in accordance with this Directive.

The enterprises concerned shall draw up a concrete and feasible Action Plan on the basis of the recommendations arising from those energy audits. The Action Plan shall identify measures to implement each audit recommendation, where it is technically or economically feasible. The Action Plan shall be submitted to the management of the enterprise.

Member  States  shall  ensure  that  the  Action  Plans  and  the  recommendation  implementation  rate  are  published  in  the enterprise's  annual  report,  and  that  they  are  made  publicly  available,  subject  to  Union  and  national  law protecting  trade and business secrets and confidentiality.

- 3. Where, in any given year, an enterprise as referred to in paragraph 1 has an annual consumption of more than 85 TJ and where an enterprise as referred to in paragraph 2 has an annual consumption of more than 10 TJ, Member States shall ensure that that information is made available to the national authorities responsible for implementation of this Article. For that  purpose,  Member  States  may  promote  the  use  of  a  new  or  an  existing  platform  to  facilitate  the  collection  of  the required data at national level.
- 4. Member  States  may  encourage  the  enterprises  referred  to  in  paragraphs  1  and  2  to  provide  information  in  their annual report about their annual energy consumption in kWh, their annual volume of water consumption in cubic metres and a comparison of their energy and water consumption with previous years.
- 5. Member  States  shall  promote  the  availability  to  all  final  customers  of  high  quality  energy  audits  which  are  costeffective and are:
- (a) carried out in an independent manner by qualified or accredited experts in accordance with qualification criteria; or
- (b) implemented and supervised by independent authorities under national legislation.

The energy audits referred to in the first subparagraph may be carried out by in-house experts or energy auditors, provided that  the  Member  State  concerned  has  put  in  place  a  scheme  to  ensure  their  quality,  including,  if  appropriate,  an  annual random  selection  of  at  least  a  statistically  significant  percentage  of  all  the  energy  audits  carried  out  by  such  in-house experts or energy auditors.

For  the  purpose of ensuring the high quality of  the energy audits and energy management systems, Member States shall establish transparent and non-discriminatory minimum criteria for energy audits in accordance with Annex VI and taking into consideration relevant European or  international standards. Member States shall designate a competent authority or body to ensure that the timelines for conducting energy audits set out in paragraph 2 of this Article are complied with and the minimum criteria set out in Annex VI are correctly applied.

EN

Energy  audits  shall  not  include  clauses  preventing  the  findings  of  the  audit  from  being  transferred  to  any  qualified  or accredited energy service provider, provided that the customer does not object.

- 6. Member States shall develop programmes with the aim of encouraging and providing technical support to SMEs that are not subject to paragraph 1 or 2 to undergo energy audits and to subsequently implement the recommendations arising from those audits.

On the basis of transparent and non-discriminatory criteria and without prejudice to Union State aid law, Member States may set up mechanisms, such as energy audit centres for SMEs and microenterprises, provided that such mechanisms do not  compete  with  private  auditors,  to  provide  energy  audits.  They  may  also  provide  other  support  schemes  for  SMEs, including  where  such  SMEs  have  concluded  voluntary  agreements,  to  cover  the  costs  of  energy  audits  and  of  the implementation  of  highly  cost-effective  recommendations  arising  from  the  energy  audits,  if  the  measures  proposed  in those recommendations are implemented.

- 7. Member States shall ensure that the programmes referred to in paragraph 6 include support to SMEs in quantifying the  multiple  benefits  of  energy  efficiency  measures  within  their  operation,  in  the  development  of  energy  efficiency roadmaps and in the development of energy efficiency networks for SMEs, facilitated by independent experts.

Member  States  shall  bring  to  the  attention  of  SMEs,  including  through  their  respective  representative  intermediary organisations, concrete examples of how energy management systems could help their businesses. The Commission shall assist Member States by supporting the exchange of best practices in this domain.

- 8. Member States  shall  develop  programmes  to  encourage  enterprises  that  are  not  SMEs  and  that  are  not  subject  to paragraph 1 or 2 to undergo energy audits and to subsequently implement the recommendations arising from those audits.
- 9. Energy audits shall be considered to comply with paragraph 2 where they are:
- (a) carried out in an independent manner, on the basis of the minimum criteria set out in Annex VI;
- (b) implemented under voluntary agreements concluded between organisations of stakeholders and a body appointed and supervised by the Member State concerned, by another body to which the competent authorities have delegated the responsibility concerned or by the Commission.

Access of market participants offering energy services shall be based on transparent and non-discriminatory criteria.

- 10. Enterprises  that  implement an energy  performance contract shall be exempt from the requirements laid down in paragraphs 1 and 2 of  this  Article,  provided  that  the  energy  performance  contract  covers  the  necessary elements  of  the energy management system and that the contract complies with the requirements set out in Annex XV.
- 11. Enterprises that implement an environmental management system, certified by an independent body in accordance with the relevant European or international standards, shall be exempt from the requirements laid down in paragraphs 1 and  2  of  this  Article,  provided  that  the  environmental  management  system  concerned  includes  an  energy  audit  on  the basis of the minimum criteria set out in Annex VI.
- 12. Energy  audits  may  stand  alone  or  be  part  of  a  broader  environmental  audit.  Member  States  may  require  an assessment  of  the  technical  and  economic  feasibility  of  connection  to  an  existing  or  planned  district  heating  or  cooling network to be part of the energy audit.

EN

20.9.2023

Without  prejudice  to  Union  State  aid  law,  Member  States  may  implement  incentives  and  support  schemes  for  the implementation of recommendations arising from energy audits and similar measures.

## Article 12

## Data centres

- 1. By 15 May 2024 and every year thereafter, Member States shall require owners and operators of data centres in their territory with a power demand of the installed information technology (IT) of at least 500kW, to make the information set out in Annex VII publicly available, except for information subject to Union and national law protecting trade and business secrets and confidentiality.
- 2. Paragraph  1  shall  not  apply  to  data  centres  used  for,  or  providing  their  services  exclusively  with  the  final  aim  of, defence and civil protection.
- 3. The Commission shall establish a European database on data centres that includes information communicated by the obligated data centres in accordance with paragraph 1. The European database shall be publicly available on an aggregated level.
- 4. Member States shall encourage owners and operators of data centres in their territory with a power demand of the installed IT equal to or greater than 1 MW to take into account the best practices referred to in the most recent version of the European Code of Conduct on Data Centre Energy Efficiency.
- 5. By 15 May 2025, the Commission shall assess the available data on the energy efficiency of data centres submitted to it pursuant to paragraphs 1 and 3 and shall submit a report to the European Parliament and to the Council, accompanied, where  appropriate, by legislative proposals containing further measures to improve  energy  efficiency, including establishing  minimum  performance  standards  and  an  assessment  on  the  feasibility  of  transition  towards  a  net-zero emission  data  centres  sector,  in  close  consultation  with  the  relevant  stakeholders.  Such  proposals  may  establish  a timeframe within which existing data centres are to be required to meet minimum performance.

## Article 13

## Metering for natural gas

- 1. Member States  shall  ensure  that,  in  so  far  as  technically  possible,  financially  reasonable,  and  proportionate  to  the potential  energy  savings,  natural  gas  final  customers  are  provided  with  competitively  priced  individual  meters  that accurately reflect the final customer's actual energy consumption and that provide information on actual time of use.

Such a competitively priced individual meter shall always be provided when:

- (a) an  existing  meter  is  replaced,  unless  this  is  technically  impossible  or  not  cost-effective  in  relation  to  the  estimated potential savings in the long term;
- (b) a  new  connection  is  made  in  a  new  building  or  a  building  undergoes  major  renovations  within  the  meaning  of Directive 2010/31/EU.
- 2. Where,  and  to  the  extent  that,  Member  States  implement  smart  metering  systems  and  roll  out  smart  meters  for natural gas in accordance with Directive 2009/73/EC:
- (a) they shall ensure that the metering systems provide to final customers information on actual time of use and that the objectives  of  energy  efficiency  and  benefits  for  final  customers  are  fully  taken  into  account  when  establishing  the minimum functionalities of the meters and the obligations imposed on market participants;

EN

- (b) they  shall  ensure  the  security  of  the  smart  meters  and  data  communication,  and  the  privacy  of  final  customers,  in compliance with relevant Union data protection and privacy law;
- (c) they shall require that appropriate advice and information be given to customers at the time of installation of smart meters, in particular about their full potential with regard to meter reading management and the monitoring of energy consumption.

## Article 14

## Metering for heating, cooling and domestic hot water

- 1. Member  States  shall  ensure  that,  for  district  heating,  district  cooling  and  domestic  hot  water,  final  customers  are provided with competitively priced meters that accurately reflect their actual energy consumption.
- 2. Where heating, cooling or domestic hot water is supplied to a building from a central source that services multiple buildings or from a district heating or district cooling system, a meter shall be installed at the heat exchanger or point of delivery.

## Article 15

## Sub-metering and cost allocation for heating, cooling and domestic hot water

- 1. In multi-apartment and multi-purpose buildings with a central heating or central cooling source or supplied from a district  heating  or  district  cooling  system,  individual  meters  shall  be  installed  to  measure  the  consumption  of  heating, cooling  or  domestic  hot  water  for  each  building  unit,  where  technically  feasible  and  cost  effective  in  terms  of  being proportionate in relation to the potential energy savings.

Where the use of individual meters is not technically feasible or where it is not cost-efficient to measure heat consumption in each building unit, individual heat cost allocators shall be used to measure heat consumption at each radiator unless it is shown by the Member State in question that the installation of such heat cost allocators would not be cost-efficient. In those cases,  alternative  cost-efficient  methods  of  heat  consumption  measurement  may  be  considered.  The  general  criteria, methodologies and procedures to determine technical non-feasibility and non-cost effectiveness shall be clearly set out and published by each Member State.

- 2. In new multi-apartment buildings and in residential parts of new multi-purpose buildings that are equipped with a central  heating  source  for  domestic  hot  water  or  are  supplied  from  district  heating  systems,  individual  meters  shall, notwithstanding paragraph 1, first subparagraph, be provided for domestic hot water.
- 3. Where multi-apartment or multi-purpose buildings are supplied from district heating or district cooling, or  where own common heating or cooling systems for such buildings are prevalent, Member States shall ensure that they have in place transparent, publicly available national rules on the allocation of the cost of heating, cooling and domestic hot water consumption  in  such  buildings  to  ensure  transparency  and  accuracy  of  accounting  for  individual  consumption.  Where appropriate, such rules shall include guidelines on the manner in which to allocate cost for energy that is used for:
- (a) domestic hot water;
- (b) heat  radiated  from  the  building  installation  and  for  the  purpose  of  heating  the  common  areas,  where  staircases  and corridors are equipped with radiators;
- (c) heating or cooling apartments.

EN

20.9.2023

## Article 16

## Remote reading requirement

- 1. For  the  purposes  of  Articles  14  and  15,  newly  installed  meters  and  heat  cost  allocators  shall  be  remotely  readable devices. The conditions of technical feasibility and cost effectiveness set out in Article 15(1) shall apply.
- 2. Meters  and  heat  cost  allocators  which  are  not  remotely  readable  but  which  have  already  been  installed  shall  be rendered remotely readable or replaced with remotely readable devices by 1 January 2027, save where the Member State in question shows that this is not cost-efficient.

## Article 17

## Billing information for natural gas

- 1. Where final  customers  do  not  have  smart  meters  for  natural  gas  as  referred  to  in  Directive  2009/73/EC,  Member States  shall  ensure  that  billing  information  for  natural  gas  is  reliable,  accurate  and  based  on  actual  consumption,  in accordance with Annex VIII, point 1.1, where that is technically possible and economically justified.

This  obligation  may  be  fulfilled  by  a  system  of  regular  self-reading  by  the  final  customers  whereby  they  communicate readings  from  their  meter  to  the  energy  supplier.  Only  when  the  final  customer  has  not  provided  a  meter  reading  for  a given billing interval shall billing be based on estimated consumption or a flat rate.

- 2. Meters installed in accordance with Directive 2009/73/EC shall enable the provision of accurate billing information based  on  actual  consumption.  Member  States  shall  ensure  that  final  customers  have  the  possibility  of  easy  access  to complementary information on historical consumption allowing detailed self-checks.

Complementary information on historical consumption shall include:

- (a) cumulative data for at least the three previous years or the period since the start of the supply contract if this is shorter;
- (b) detailed data according to the time of use for any day, week, month and year.

The data referred to in point (a) of  the  second subparagraph shall correspond  to the  intervals for  which  frequent  billing information has been produced.

The data referred to in point (b) of the second subparagraph shall be made available to the final customer via the internet or the meter interface for the period of at least the previous 24 months or the period since the start of the supply contract if this is shorter.

- 3. Independently of whether smart meters have been installed, Member States:
- (a) shall require that, to the extent that information on the energy billing and historical consumption of final customers is available, it be made available, at the request of the final customer, to an energy service provider designated by the final customer;
- (b) shall ensure that final customers are offered the option of electronic billing information and bills and that they receive, on request, a clear and understandable explanation of how their bill was derived, especially where bills are not based on actual consumption;
- (c) shall ensure  that  appropriate  information  is  made  available  with  the  bill  to  provide  final customers  with  a comprehensive account of current energy costs, in accordance with Annex VIII;

EN

- (d) may lay down that, at the request of the final customer, the information contained in those bills shall not be considered to  constitute  a  request  for  payment.  In  such  cases,  Member  States  shall  ensure  that  suppliers  of energy  sources  offer flexible arrangements for actual payments;
- (e) shall require that information and estimates for energy costs are provided to consumers on demand in a timely manner and in an easily understandable format enabling consumers to compare deals on a like-for-like basis.

## Article 18

## Billing and consumption information for heating, cooling and domestic hot water

- 1. Where  meters  or  heat  cost  allocators  are  installed,  Member  States  shall  ensure  that  billing  and  consumption information  is  reliable,  accurate  and  based  on  actual  consumption  or  heat  cost  allocator  readings,  in  accordance  with Annex IX, points 1 and 2 for all final users.

That obligation may, where a Member State so provides, save in the case of sub-metered consumption based on heat cost allocators under Article 15, be fulfilled by a system of regular self-reading by the final customer or final user whereby they communicate readings from their meter. Only where the final customer or final user has not provided a meter reading for a given billing interval shall billing be based on estimated consumption or a flat rate.

- 2. Member States shall:
- (a) require  that,  if  information  on  the  energy  billing  and  historical  consumption  or  heat  cost  allocator  readings  of  final users is available, it be made available upon request from the final user, to an energy service provider designated by the final user;
- (b) ensure that final customers are offered the option of electronic billing information and bills;
- (c) ensure that clear and comprehensible information is provided with the bill to all final users in accordance with Annex IX, point 3;
- (d) promote cybersecurity and ensure the privacy and data protection of final users in accordance with applicable Union law.

Member States  may  provide  that,  at  the  request  of  the  final  customer,  the  provision  of  billing  information  shall  not  be considered to constitute a request for  payment. In such cases, Member States shall ensure that flexible arrangements for actual payment are offered.

- 3. Member States shall decide who is to be responsible for providing the information referred to in paragraphs 1 and 2 to final users without a direct or individual contract with an energy supplier.

## Article 19

## Cost of access to metering and billing information for natural gas

Member States shall ensure that final customers receive all their bills and billing information for energy consumption free of charge and that final customers have access to their consumption data in an appropriate manner and free of charge.

## Article 20

## Cost of access to metering and billing and consumption information for heating, cooling and domestic hot water

- 1. Member States shall ensure that final users receive all their bills and billing information for energy consumption free of charge and that final users have access to their consumption data in an appropriate manner and free of charge.

EN

20.9.2023

- 2. Notwithstanding  paragraph  1  of  this  Article,  the  distribution  of  costs  of  billing  information  for  the  individual consumption  of  heating,  cooling  and  domestic  hot  water  in  multi-apartment  and  multi-purpose  buildings  pursuant  to Article 15 shall be carried out on a non-profit basis. Costs resulting from the assignment of that task to a third party, such as a service provider or the local energy supplier, covering the measuring, allocation and accounting for actual individual consumption in such buildings, may be passed onto the final users to the extent that such costs are reasonable.
- 3. In  order  to  ensure  reasonable  costs  for  sub-metering  services  as  referred  to  in  paragraph  2,  Member  States  may stimulate  competition  in  that  service  sector  by  taking  appropriate  measures  such  as  recommending  or  otherwise promoting  the  use  of  tendering  or  the  use  of  interoperable  devices  and  systems  facilitating  switching  between  service providers.

CHAPTER IV

## CONSUMER INFORMATION AND EMPOWERMENT

## Article 21

## Basic contractual rights for heating, cooling and domestic hot water

- 1. Without  prejudice  to  Union  rules  on  consumer  protection,  in  particular  Directive  2011/83/EU  of  the  European Parliament and of  the Council ( 42 ) and Council Directive 93/13/EEC ( 43 ),  Member  States  shall  ensure  that  final  customers and, where explicitly referred to, final users, are granted the rights provided for in paragraphs 2 to 9 of this Article.
- 2. Final customers shall have the right to a contract with their supplier that specifies:
- (a) the identity, address and contact details of the supplier;
- (b) the services provided and the service quality levels included;
- (c) the types of maintenance service included in the contract without additional charges;
- (d) the  means  by  which  up-to-date  information  on  all  applicable  tariffs,  maintenance  charges  and  bundled  products  or services may be obtained;
- (e) the  duration  of  the  contract,  the  conditions  for  renewal  and  termination  of  the  contract  and  services,  including products  or  services  that  are  bundled  with  those  services,  and  whether  terminating  the  contract  without  charge  is permitted;
- (f) any compensation and the refund arrangements which apply if contracted service quality levels are not met, including inaccurate or delayed billing;
- (g) the method of initiating an out-of-court dispute-settlement procedure in accordance with Article 22;
- (h) information  relating  to  consumer  rights,  including  information  on  complaint  handling  and  all  of  the  information referred to in this paragraph, which is clearly communicated in the bill or on the enterprise's website and includes the contact details or link to the website of the single points of contact referred to in Article 22(3), point (e);

( 42 ) Directive 2011/83/EU of the European Parliament and of the Council of 25 October 2011 on consumer  rights, amending Council Directive 93/13/EEC and Directive 1999/44/EC of the European Parliament and of the Council and repealing Council Directive 85/577/EEC and Directive 97/7/EC of the European Parliament and of the Council (OJ L 304, 22.11.2011, p. 64).

( 43 ) Council Directive 93/13/EEC of 5 April 1993 on unfair terms in consumer contracts (OJ L 95, 21.4.1993, p. 29).

EN

- (i) the contact details enabling the customer to identify relevant one-stop shops as referred to in Article 22(3), point (a).

Suppliers' conditions shall be fair and shall be provided to final customers in advance. The information referred to in this paragraph  shall  be  provided  before  the  conclusion  or  confirmation  of  the  contract.  Where  contracts  are  concluded through intermediaries, that information shall also be provided before the conclusion of the contract.

Final customers and final users shall be provided with a summary of the key contractual conditions, including prices and tariffs, in a comprehensible manner and in concise and simple language.

Final customers shall be provided with a copy of the contract and clear information, in a transparent manner, on applicable prices and tariffs and on standard terms and conditions in respect of access to and use of heating, cooling and domestic hot water services.

Member States shall decide who is to be responsible for  providing the information referred to in this  paragraph to final users without a direct or individual contract with a supplier, upon request, in an appropriate manner and free of charge.

- 3. Final  customers  shall  be  given  adequate  notice  of  any  intention  to  modify  contractual  conditions.  Suppliers  shall notify their  final  customers,  in  a  transparent  and  comprehensible manner, directly of any adjustment in the supply price and of the reasons and preconditions for the adjustment and its scope, at an appropriate time no later than two weeks, or no  later  than  one  month  in  the  case  of  household  customers,  before  the  adjustment  comes  into  effect.  Final  customers shall inform final users of the new conditions without delay.
- 4. Suppliers  shall  offer  final  customers  a  wide  choice  of  payment  methods.  Such  payment  methods  shall  not  unduly discriminate between  customers.  Any difference  in  charges related to  payment  methods  or  prepayment  systems  shall  be objective, non-discriminatory and proportionate and shall not exceed the direct costs borne by the payee for the use of a specific  payment  method  or  a  prepayment  system,  in  accordance  with  Article  62  of  Directive  (EU)  2015/2366  of  the European Parliament and of the Council ( 44 ).
- 5. Pursuant  to  paragraph  4,  household  customers  who  have  access  to  prepayment  systems  shall  not  be  placed  at  a disadvantage by the prepayment systems.
- 6. Final customers and, where applicable, final users shall be offered fair and transparent general terms and conditions, which shall be provided in plain and unambiguous language and shall not include non-contractual barriers to the exercise of  customers'  rights,  such  as  excessive  contractual  documentation.  Final  users  shall  be  provided  access  to  those  general terms and conditions upon request. Final customers and final users shall be protected against unfair or misleading selling methods. Final customers with disabilities shall be provided all relevant information on their contract with their supplier in accessible formats.
- 7. Final  customers and final  users  shall  have  the  right  to  a  good  standard  of  service  and  complaint-handling  by their suppliers. Suppliers shall handle complaints in a simple, fair and prompt manner.
- 8. Competent authorities shall ensure that the consumer protection measures laid down in this Directive are enforced. The competent authorities shall act independently from any market interests.
- 9. In the case of planned disconnection, the final customers concerned shall be provided with adequate information on alternative  measures  sufficiently  in  advance,  no  later  than  one  month  before  the  planned  disconnection  and  at  no  extra cost.

( 44 ) Directive (EU) 2015/2366 of the European Parliament and of the Council of 25 November 2015 on payment services in the internal market,  amending  Directives  2002/65/EC,  2009/110/EC  and  2013/36/EU  and  Regulation  (EU)  No  1093/2010,  and  repealing Directive 2007/64/EC (OJ L 337, 23.12.2015, p. 35).

EN

20.9.2023

## Article 22

## Information and awareness raising

- 1. Member States, in cooperation with regional and local authorities, where applicable, shall ensure that information on available  energy  efficiency  improvement  measures,  individual  actions  and  financial  and  legal  frameworks  is  transparent, accessible and  widely  disseminated  to  all  relevant  market  actors,  such  as  final customers,  final  users, consumer organisations, civil society representatives, renewable energy communities, citizen energy communities, local and regional authorities,  energy  agencies,  social  service  providers,  builders,  architects,  engineers,  environmental  and  energy  auditors, and installers of building elements as defined in Article 2, point (9), of Directive 2010/31/EU.
- 2. Member States shall take appropriate measures to promote and facilitate an efficient use of energy by final customers and final users. Those measures shall be part of a national strategy, such as the integrated national energy and climate plans provided  for  in  Regulation  (EU)  2018/1999,  or  the  long-term  renovation  strategy  established  pursuant  to  Article  2a  of Directive 2010/31/EU.

For the purposes of this Article, those measures shall include a range of instruments and policies to promote behavioural change such as:

- (a) fiscal incentives;
- (b) access to finance, vouchers, grants or subsidies;
- (c) publicly  supported  energy  consumption  assessments  and  targeted  advisory  services  and  support  for  household consumers, in particular people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing;
- (d) targeted advisory services for SMEs and microenterprises;
- (e) information provision in accessible form to people with disabilities;
- (f) exemplary projects;
- (g) workplace activities;
- (h) training activities;
- (i) digital tools;
- (j) engagement strategies.
- 3. For  the purposes of  this Article, the measures referred to in paragraph 2 shall include the creation of a supportive framework for market actors such as those referred to in paragraph 1, in particular for:
- (a) the creation of one-stop shops or similar mechanisms for the provision of technical, administrative and financial advice and assistance on energy efficiency, such as energy checks for households, energy renovations of buildings, information on the replacement of old and inefficient heating systems with modern and more efficient appliances and the take-up of renewable energy and energy storage for buildings to final customers and final users, especially household and small non-household ones, including SMEs and microenterprises;
- (b) cooperation  with  private  actors  that  provide  services  such  as  energy  audits  and  energy  consumption  assessments, financing solutions and execution of energy renovations;
- (c) the communication of cost-effective and easy-to-achieve changes in energy use;
- (d) the dissemination of information on energy efficiency measures and financing instruments;

EN

- (e) the  provision  of  single  points  of  contact,  to  provide  final  customers  and  final  users  with  all  necessary  information concerning their rights, the applicable law and the dispute-settlement mechanisms available to them in the event of a dispute. Such single points of contact may be part of general consumer information points.
- 4. For  the  purpose  of  this  Article,  Member  States  shall  in  cooperation  with  competent  authorities,  and,  where appropriate, private stakeholders establish dedicated one-stop shops or similar mechanisms for the provision of technical, administrative and financial advice for energy efficiency. Those facilities shall:
- (a) advise  with  streamlined  information  on  technical  and  financial  possibilities  and  solutions  to  households,  SMEs, microenterprises, public bodies;
- (b) provide holistic support to all households, with a particular  focus on households affected by energy poverty and on worst  performing  buildings,  as  well  as  to  accredited  companies  and  installers  providing  retrofit  services,  adapted  to different housing typologies and geographical scope, and provide support covering the different stages of the retrofit project, including to facilitate the implementation of a minimum energy performance standard where such standard is provided for in a Union legislative act;
- (c) advise on energy consumption behaviour.
- 5. Dedicated one-stop shop facilities as referred to in paragraph 4 shall, where appropriate:
- (a) provide information about qualified energy efficiency professionals;
- (b) collect typology-aggregated data from energy efficiency projects, share experiences and make them publicly available;
- (c) connect potential projects with market players, in particular smaller-scale, local projects.

For  the purposes of the first subparagraph, point (b), the Commission shall assist Member States in order to facilitate the sharing of, and enhance cross-border cooperation with regard to, best practices.

- 6. The one-stop shops referred to in paragraph 4 shall offer dedicated services for  people affected by energy poverty, vulnerable customers and people in low-income households.

The Commission shall provide Member States with guidelines to develop those one-stop shops with the aim of creating a harmonised  approach  throughout  the  Union.  The  guidelines  shall  encourage  cooperation  among  public  bodies,  energy agencies and community-led initiatives.

- 7. Member States shall establish appropriate conditions for market actors to provide adequate and targeted information and advice on energy efficiency to final customers, including people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing, SMEs and microenterprises.
- 8. Member States shall ensure that final customers, final users, people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing have access to simple, fair, transparent, independent, effective and efficient  out-of-court  mechanisms  for  the  settlement  of  disputes  concerning  rights  and  obligations  provided  for  in  this Directive,  through  an  independent  mechanism  such  as  an  energy  ombudsperson  or  a  consumer  body,  or  through  a regulatory authority. Where the final customer is a consumer as defined in Article 4(1), point (a), of Directive 2013/11/EU of the European Parliament and of the Council ( 45 ), such out-of-court dispute settlement mechanisms shall comply with the requirements set out therein. Out-of-court dispute settlement mechanisms already existing in Member States may be used for that purpose, provided they are equally effective.

( 45 ) Directive 2013/11/EU of the European Parliament and of the Council of 21 May 2013 on alternative dispute resolution for consumer disputes  and  amending  Regulation  (EC)  No  2006/2004  and  Directive  2009/22/EC  (Directive  on  consumer  ADR)  (OJ  L  165, 18.6.2013, p. 63).

EN

Where necessary, Member States shall ensure that alternative dispute resolution entities cooperate to provide simple, fair, transparent,  independent,  effective  and  efficient  out-of-court  dispute  settlement  mechanisms  for  any  dispute  that  arises from products or services that are tied to, or bundled with, any product or service falling under the scope of this Directive.

The  participation  of  enterprises  in  out-of-court  dispute  settlement  mechanisms  for  household  customers  shall  be mandatory unless the Member State demonstrates to the Commission that other mechanisms are equally effective.

- 9. Without  prejudice  to  the  basic  principles  of  their  laws  on  property  and  tenancy,  Member  States  shall  take  the necessary  measures  to  remove  regulatory  and  non-regulatory  barriers  to  energy  efficiency  as  regards  split  incentives between owners and tenants, or among owners of a building or building unit, with a view to ensuring that those parties are not deterred from making efficiency-improving investments that they would otherwise have made by the fact that they will not individually obtain the full benefits or by the absence of rules for dividing the costs and benefits between them.

Measures to remove such barriers may include providing incentives, repealing or amending legal or regulatory provisions, adopting  guidelines  and  interpretative  communications,  simplifying  administrative  procedures,  including  national  rules and  measures  regulating  decision-making  processes  in  multi-owner  properties,  and  the  possibility  to  turn  to  third-party financing  solutions.  The  measures  may  be  combined  with  the  provision  of  education,  training  and  specific  information and technical assistance on energy efficiency to market actors such as those referred to in paragraph 1.

Member States shall take appropriate measures to support a multilateral dialogue among relevant partners, such as local and  regional authorities, the social partners, owners' and  tenants' organisations, consumer  organisations,  energy distributors or  retail energy sales companies, ESCOs, renewable energy communities, citizen energy communities, public authorities  and  agencies,  with  the  aim  of  setting  out  proposals  on  jointly  accepted  measures,  incentives  and  guidelines pertinent to split incentives between owners and tenants or among owners of a building or building unit.

Each  Member  State  shall  report  such  barriers  and  the  measures  taken  in  its  long-term  renovation  strategy  established pursuant to Article 2a of Directive 2010/31/EU and to Regulation (EU) 2018/1999.

- 10. The Commission shall encourage the exchange and wide dissemination of information on good energy efficiency practices and methodologies and provide technical assistance to mitigate split incentives in Member States.

## Article 23

## Partnerships for energy efficiency

- 1. By 11 October 2024, the Commission shall assess whether energy efficiency is covered by existing partnerships. If the assessment shows that energy efficiency is not sufficiently covered by existing partnerships, the Commission shall establish sector-specific energy efficiency partnerships at Union level, with sub-partnerships per missing sector, by bringing together key stakeholders, including the social partners, in sectors such as ICT, transport, finance and building, in an inclusive and representative manner.

If  a  partnership  is  established,  the  Commission  shall  appoint,  where  appropriate,  a  chair  for  each  Union  sector-specific energy efficiency partnership.

- 2. The partnerships referred to in paragraph 1 shall aim to facilitate climate and energy transition dialogues between the relevant  actors  and  encourage  sectors  to  draw  up  energy  efficiency  roadmaps  in  order  to  map  available  measures  and technological options to achieve energy savings, prepare for renewable energy and decarbonise the sectors.

EN

Such roadmaps would make a valuable contribution in assisting sectors in planning the necessary investments needed to reach  the  objectives  of  this  Directive  and  of  Regulation  (EU)  2021/1119  as  well  as  facilitate  cross-border  cooperation between actors to strengthen the internal market.

## Article 24

## Empowering and protecting vulnerable customers and alleviating energy poverty

- 1. Without prejudice to their national economic and social policies, and to their obligations under Union law, Member States shall  take  appropriate measures to empower and protect people affected by energy poverty, vulnerable customers, people in low-income households and, where applicable, people living in social housing.

In  defining  the  concept  of  vulnerable  customers  pursuant  to  Article  3(3)  of  Directive  2009/73/EC  and  Article  28(1)  of Directive (EU) 2019/944, Member States shall take into account final users.

- 2. Without prejudice to their national economic and social policies, and to their obligations under Union law, Member States shall implement  energy  efficiency  improvement  measures  and  related  consumer  protection  or  information measures, in particular those set out in Article 8(3) and Article 22 of this Directive, as a priority among people affected by energy  poverty,  vulnerable  customers,  people  in  low-income  households  and,  where  applicable,  people  living  in  social housing to alleviate energy poverty. Monitoring and reporting of those measures shall be undertaken in the framework of the existing reporting requirements set out in Article 24 of Regulation (EU) 2018/1999.
- 3. To support people affected by energy poverty, vulnerable customers, people in low-income households and, where applicable, people living in social housing, Member States shall, where applicable:
- (a) implement energy efficiency improvement measures to mitigate distributional effects from other policies and measures, such as taxation measures implemented in accordance with Article 10 of this Directive, or the application of emissions trading in the buildings and transport sector in accordance with Directive 2003/87/EC;
- (b) make the  best  possible  use  of  public  funding  available  at  Union  and  national  level,  including,  where  applicable,  the financial  contribution  that  Member  States  receive  from  the  Social  Climate  Fund  pursuant  to  Articles  9  and  14  of Regulation (EU) 2023/955, and revenues from allowance auctions from emissions trading pursuant to the EU ETS in accordance  with  Directive  2003/87/EC,  for  investments  into  energy  efficiency  improvement  measures  as  priority actions;
- (c) carry out early, forward-looking investments in energy efficiency improvement measures before distributional impacts from other policies and measures show their effect;
- (d) foster technical assistance and the roll-out of enabling funding and financial tools, such as on-bill schemes, local loanloss reserve, guarantee funds, funds targeting deep renovations and renovations with minimum energy gains;
- (e) foster technical assistance for social actors to promote vulnerable customer's active engagement in the energy market, and positive changes in their energy consumption behaviour;
- (f) ensure access to finance, grants or subsidies bound to minimum energy gains and thus facilitate access to affordable bank loans or dedicated credit lines.
- 4. Member States shall establish a network of experts from various sectors such as the health, building and social sectors, or entrust an existing network, to develop strategies to support local and national decision makers in implementing energy efficiency improvement measures, technical assistance and financial tools aiming to alleviate energy poverty. Member States shall strive to ensure that the composition of the network of experts ensures gender balance and reflects the perspectives of all people.

EN

20.9.2023

Member States may entrust the network of experts to offer advice on:

- (a) national  definitions,  indicators and  criteria  of energy  poverty,  energy  poor and  vulnerable  customers,  including  final users;
- (b) the  development or  improvement of relevant indicators and  data  sets,  pertinent  to  the  issue  of  energy  poverty,  that should be used and reported upon;
- (c) methods  and  measures  to  ensure  affordability  of  living  costs,  the  promotion  of  housing  cost  neutrality,  or  ways  to ensure  that  public  funding  invested  in  energy  efficiency  improvement  measures  benefit  both  owners  and  tenants  of buildings and building units, in particular  regarding people affected by energy poverty, vulnerable customers, people in low-income households, and, where applicable, people living in social housing;
- (d) measures to prevent or remedy situations in which particular groups are more affected or more at risk of being affected by  energy  poverty  or  are  more  susceptible  to  the  adverse  impacts  of  energy  poverty  such  as  on  the  basis  of  their income, gender, health condition or membership of a minority group, and demographics.

## CHAPTER V

## EFFICIENCY IN ENERGY SUPPLY

## Article 25

## Heating and cooling assessment and planning

- 1. As part of its integrated national energy and climate plan and its updates pursuant to Regulation (EU) 2018/1999, each Member State shall submit to the Commission a comprehensive heating and cooling assessment. That comprehensive assessment shall contain the information set out in Annex X to this Directive and shall be accompanied by the assessment carried out pursuant to Article 15(7) of Directive (EU) 2018/2001.
- 2. Member States shall ensure that stakeholders affected by the comprehensive assessment referred to in paragraph 1 are given the opportunity to participate in the preparation of heating and cooling plans, the comprehensive assessment and the policies and measures, whilst ensuring that the competent authorities do not disclose or publish trade secrets or business secrets that have been identified as such.
- 3. For  the purpose of the comprehensive assessment referred to in paragraph 1, Member States shall carry out a costbenefit  analysis  covering  their  territory  on  the  basis  of  climate  conditions,  economic  feasibility  and  technical  suitability. The cost-benefit analysis shall be capable of facilitating the identification of the most resource- and cost-efficient solutions to meeting heating and cooling needs, taking into account the energy efficiency first principle. That cost-benefit analysis may  be  part of an environmental  assessment  under  Directive 2001/42/EC  of  the  European  Parliament  and of the Council ( 46 ).

Member States shall designate the competent authorities responsible for carrying out the cost-benefit analyses, provide the detailed methodologies and assumptions in accordance with Annex XI and establish and make public the procedures for the economic analysis.

- 4. Where  the  comprehensive  assessment  referred  to  in  paragraph  1  of  this  Article  and  the  analysis  referred  to  in paragraph 3 of this Article identify a potential for  the application of high-efficiency cogeneration and/or efficient district heating  and  cooling  from  waste  heat,  whose  benefits  exceed  the  costs,  Member  States  shall  take  adequate  measures  for efficient district heating and cooling infrastructure to be developed, to encourage the development of installations for the utilisation  of  waste  heat,  including  in  the  industrial  sector,  and/or  to  accommodate  the  development  of  high-efficiency cogeneration  and  the  use  of  heating  and  cooling  from  waste  heat  and  renewable  energy  sources  in  accordance  with paragraph 1 of this Article and with Article 26(7) and (9).

( 46 ) Directive 2001/42/EC of the European Parliament and of the Council of 27 June 2001 on the assessment of the effects of certain plans and programmes on the environment (OJ L 197, 21.7.2001, p. 30).

EN

Where the comprehensive assessment referred to in paragraph 1 of this Article and the analysis referred to in paragraph 3 of  this  Article  do  not  identify  a  potential  whose  benefits  exceed  the  costs,  including  the  administrative  costs  of  carrying out the cost-benefit analysis referred to in Article 26(7), the Member State concerned, together with the local and regional authorities,  where  applicable,  may  exempt  installations  from  the  requirements  laid  down  in  paragraphs  1  and  3  of this Article.

- 5. Member States  shall  adopt  policies  and  measures  which  ensure  that  the  potential  identified  in  the  comprehensive assessments  carried  out  pursuant  to  paragraph  1  of  this  Article  is  realised.  Those  policies  and  measures  shall  include  at least the elements set out in Annex X. Each Member State shall notify those policies and measures as part of the update of its  integrated  national  energy  and  climate  plans  submitted  pursuant  to  Article  14(2)  of  Regulation  (EU)  2018/1999,  its subsequent  integrated  national  energy  and  climate  plan  notified  pursuant  to  Article  3  and  Articles  7  to  12  of  that Regulation, and the relevant national energy and climate progress reports submitted pursuant to that Regulation.
- 6. Member  States  shall  ensure  that  regional  and  local  authorities  prepare  local  heating  and  cooling  plans  at  least  in municipalities having a total population higher than 45 000. Those plans should at least:
- (a) be based on the information and data provided in the comprehensive assessments carried out pursuant to paragraph 1 and provide an estimate and mapping of the potential for increasing energy efficiency, including via low-temperature district  heating  readiness,  high  efficiency  cogeneration,  waste  heat  recovery,  and  renewable  energy  in  heating  and cooling in that particular area;
- (b) be compliant with the energy efficiency first principle;
- (c) include a strategy for the use of the identified potential pursuant to point (a);
- (d) be prepared with the involvement of all relevant regional or local stakeholders and ensure the participation of general public, including operators of local energy infrastructure;
- (e) take into account the relevant existing energy infrastructure;
- (f) consider the common needs of local communities and multiple local or regional administrative units or regions;
- (g) assess  the  role of energy  communities  and  other  consumer-led  initiatives  that  can  actively  contribute  to  the implementation of local heating and cooling projects;
- (h) include an analysis of heating and cooling appliances and systems in local building stocks, taking into account the areaspecific  potentials  for  energy  efficiency  measures  and  addressing  the  worst  performing  buildings  and  the  needs  of vulnerable households;
- (i) assess  how  to  finance  the  implementation  of  policies  and  measures  and  identify  financial  mechanisms  allowing consumers to shift to renewable heating and cooling;
- (j) include a trajectory to achieve the goals of the plans in line with climate neutrality and the monitoring of the progress of the implementation of policies and measures identified;
- (k) aim to replace old and inefficient heating and cooling appliances in public bodies with highly efficient alternatives with the aim of phasing out fossil fuels;
- (l) assess potential synergies with the plans of neighbouring regional or local authorities to encourage joint investments and cost efficiency.

Member  States  shall  ensure  that  all  relevant  parties,  including  public  and  relevant  private  stakeholders,  are  given  the opportunity to participate in the  preparation  of heating and cooling plans,  the comprehensive assessment referred to in paragraph 1 and the policies and measures referred to in paragraph 5.

EN

For  that  purpose,  Member  States  shall  develop  recommendations  supporting  the  regional  and  local  authorities  to implement policies and measures in energy efficient and renewable energy based heating and cooling at regional and local level  utilising  the  potential  identified.  Member  States  shall  support  regional  and  local  authorities  to  the  utmost  extent possible  by  any  means,  including  financial  support  and  technical  support  schemes.  Member  States  shall  ensure  that heating and cooling plans are aligned with other local climate, energy and environment planning requirements in order to avoid administrative burden for local and regional authorities and to encourage the effective implementation of the plans.

Local heating and cooling plans may be carried out jointly by a group of several neighbouring local authorities provided that the geographical and administrative context, as well as the heating and cooling infrastructure, is appropriate.

Local  heating  and  cooling  plans  shall  be  assessed  by  a  competent  authority  and,  if  necessary,  followed  by  appropriate implementation measures.

## Article 26

## Heating and cooling supply

- 1. In order  to ensure more efficient consumption of primary energy and to increase the share of renewable energy in heating  and  cooling  supply  going  into  the  network,  an  efficient  district  heating  and  cooling  system  shall  meet  the following criteria:
- (a) until 31 December 2027, a system using at least 50 % renewable energy, 50 % waste heat, 75 % cogenerated heat or 50 % of a combination of such energy and heat;
- (b) from 1 January 2028, a system using at least 50 % renewable energy, 50 % waste heat, 50 % renewable energy and waste heat, 80 % of high-efficiency cogenerated heat or at least a combination of such thermal energy going into the network where the share of renewable energy is at least  5 %  and  the  total  share  of  renewable  energy,  waste  heat  or high-efficiency cogenerated heat is at least 50 %;
- (c) from 1 January 2035, a system using at least 50 % renewable energy, 50 % waste heat or 50 % renewable energy and waste heat, or a system where the total share of renewable energy, waste heat or high-efficiency cogenerated heat is at least 80 % and in addition the total share of renewable energy or waste heat is at least 35 %;
- (d) from 1 January 2040, a system using at least 75 % renewable energy, 75 % waste heat or 75 % renewable energy and waste heat, or a system using at least 95 % renewable energy, waste heat and high-efficiency cogenerated heat and in addition the total share of renewable energy or waste heat is at least 35 %;
- (e) from 1 January 2045, a system using at least 75 % renewable energy, 75 % waste heat or 75 % renewable energy and waste heat;
- (f) from  1  January  2050,  a  system  using  only  renewable  energy,  only  waste  heat,  or  only  a  combination  of  renewable energy and waste heat.
- 2. Member States may also choose, as an alternative to the criteria set out in paragraph 1 of this Article, sustainability performance criteria based on the amount of GHG emissions from the district heating and cooling system per unit of heat or  cold  delivered  to  the  customers,  taking  into  consideration  measures  implemented  to  fulfil  the  obligation  pursuant  to Article 24(4) of Directive (EU) 2018/2001. When choosing those criteria, an efficient district heating and cooling system shall have the following maximum amount of GHG emissions per unit of heat or cold delivered to the customers:
- (a) until 31 December 2025: 200 grams/kWh;
- (b) from 1 January 2026: 150 grams/kWh;
- (c) from 1 January 2035: 100 grams/kWh;
- (d) from 1 January 2045: 50 grams/kWh;
- (e) from 1 January 2050: 0 grams/kWh.

EN

- 3. Member States  may  choose  to  apply  the  criteria  of  GHG  emissions  per  unit  of  heat  or  cold  for  any  given  period referred  to in paragraph 2, points (a) to (e), of  this  Article.  If  they choose  to do so,  they  shall  notify  the  Commission  by 11  January  2024 for  the  period  referred  to  in  paragraph  2,  point  (a),  of  this  Article  and  at  least  six  months  before  the beginning  of  the  relevant  periods  referred  to  in  paragraph  2,  points  (b)  to  (e),  of  this  Article.  Such  a  notification  shall include the measures implemented to fulfil the obligation pursuant to Article 24(4) of Directive (EU) 2018/2001 if  they have not already been notified in the latest update of their national energy and climate plan.
- 4. In order for a district heating and cooling system to qualify as efficient, Member States shall ensure that where it is built  or  its  supply  units  are  substantially  refurbished,  the  district  heating  or  cooling  system  meet  the  criteria  set  out  in paragraph  1  or  2  applicable  at  the  time  when  it  starts  or  continues  its  operation  after  the  refurbishment.  In  addition, Member States  shall  ensure  that  when  a  district  heating  and  cooling  system  is  built  or  its  supply  units  are  substantially refurbished:
- (a) there  is  no  increase  in  the  use  of  fossil  fuels  other  than  natural  gas  in  existing  heat  sources  compared  to  the  annual consumption averaged over the previous three calendar years of full operation before refurbishment; and
- (b) any  new  heat  sources  in  that  system  do  not  use  fossil  fuels,  except  natural  gas,  if  built  or  substantially  refurbished until 2030.
- 5. Member States  shall  ensure  that  as  from  1  January  2025,  and  every  five  years  thereafter,  operators  of  all  existing district heating and cooling systems with a total heat and cold output exceeding 5 MW and which do not meet the criteria set out in paragraph 1, points (b) to (e), prepare a plan to ensure more efficient consumption of primary energy, to reduce distribution  losses  and  to  increase  the  share  of  renewable  energy  in  heating  and  cooling  supply.  The  plan  shall  include measures to meet the criteria set out in paragraph 1, points (b) to (e), and shall require approval by the competent authority.
- 6. Member States shall ensure that data centres with a total rated energy input exceeding 1 MW utilise the waste heat or other waste heat recovery applications unless they can show that it is not technically or economically feasible in accordance with the assessment referred to in paragraph 7.
- 7. In order to assess the economic feasibility of increasing energy efficiency of heat and cooling supply, Member States shall ensure that an installation level cost-benefit analysis in accordance with Annex XI is carried out where the following installations are newly planned or substantially refurbished:
- (a) a  thermal electricity  generation  installation with  an  average annual  total energy input exceeding 10 MW, in order  to assess  the  cost  and  benefits  of  providing  for  the  operation  of  the  installation  as  a  high-efficiency  cogeneration installation;
- (b) an industrial installation with an average annual total energy input exceeding 8 MW in order to assess utilisation of the waste heat on-site and off-site;
- (c) a service facility with an annual average total energy input exceeding 7 MW, such as wastewater treatment facilities and LNG facilities, in order to assess utilisation of waste heat on-site and off-site;
- (d) a  data  centre  with  a  total  rated  energy  input  exceeding  1  MW  level  in  order  to  assess  the  cost  and  benefit  analysis, including,  but  not  limited  to,  technical  feasibility,  cost-efficiency  and  the  impact  on  energy  efficiency  and  local  heat demand, including seasonal variation, of utilising the waste heat to satisfy economically justified demand, and of the connection of that installation to a district heating network or an efficient/RES-based district cooling system or other waste heat recovery applications.

The analysis referred to in the first subparagraph, point (d), shall consider cooling system solutions that allow removing or capturing the waste heat at useful temperature level with minimal ancillary energy inputs.

EN

20.9.2023

Member States shall aim to remove barriers for the utilisation of waste heat and provide support for  the uptake of waste heat where the installations are newly planned or refurbished.

The  fitting  of  equipment  to  capture  carbon  dioxide  produced  by  a  combustion  installation  with  a  view  to  it  being geologically stored as provided for  in Directive 2009/31/EC shall not be considered as refurbishment for  the purpose of points (b) and (c) of this paragraph.

Member States shall require the cost-benefit analysis to be carried out in cooperation with the companies responsible for the operation of the facility.

- 8. Member States may exempt from paragraph 7:
- (a) peak load and back-up electricity generating installations which are planned to operate under 1 500 operating hours per year as a rolling average over a period of five years, based on a verification procedure established by the Member States ensuring that this exemption criterion is met;
- (b) installations that need to be located close to a geological storage site approved under Directive 2009/31/EC;
- (c) data centres whose waste heat is or will be used in a district heating network or directly for space heating, domestic hot water preparation or other uses in the building or group of buildings or facilities where it is located.

Member States may also lay down thresholds, expressed in terms of the amount of available useful waste heat, the demand for heat  or the distances  between  industrial  installations  and  district  heating  networks, for exempting  individual installations from paragraph 7, points (c) and (d).

Member States shall notify exemptions adopted under this paragraph to the Commission.

- 9. Member States shall adopt authorisation criteria as referred to in Article 8 of Directive (EU) 2019/944, or equivalent permit criteria, in order to:
- (a) take into account the outcome of the comprehensive assessment referred to in Article 25(1);
- (b) ensure that the requirements laid down in paragraph 7 are fulfilled;
- (c) take into account the outcome of the cost-benefit analysis referred to in paragraph 7.
- 10. Member States may exempt individual installations from being required, by the authorisation or equivalent permit criteria referred to in paragraph 9, to implement options whose benefits exceed their costs, if there are imperative reasons of  law, ownership or finance for doing so. In those cases the Member State concerned shall submit a reasoned decision to the  Commission within three months of  the date of  taking that decision. The Commission may issue an opinion on the decision within three months of its receipt.
- 11. Paragraphs  7,  8,  9  and  10  of  this  Article  shall  apply  to  installations  covered  by  Directive  2010/75/EU  without prejudice to the requirements laid down in that Directive.
- 12. Member States shall collect information on cost-benefit analyses carried out in accordance with paragraph 7, points (a) to (d). That information should contain at least the data on available heat supply amounts and heat parameters, number of planned operating hours every year and geographical location of the sites. Those data shall be published with due respect for their potential sensitivity.
- 13. On the basis of the harmonised efficiency reference values referred to in Annex III, point (d), Member States shall ensure that the origin of electricity produced from high-efficiency cogeneration can be guaranteed according to objective, transparent  and  non-discriminatory  criteria  laid  down  by  each  Member  State.  They  shall  ensure  that  that  guarantee  of origin complies with the requirements laid down in, and contains at least the information specified in, Annex XII. Member States  shall  mutually  recognise  their  guarantees  of  origin,  exclusively  as  proof  of  the  information  referred  to  in  this

EN

paragraph. Any refusal to recognise a guarantee of origin as such proof, in particular for reasons relating to the prevention of  fraud,  shall  be  based  on  objective,  transparent  and  non-discriminatory  criteria.  Member  States  shall  notify  the Commission of such refusal and set out the reasons for it. In the event of a refusal to recognise a guarantee of origin, the Commission  may  adopt  a  decision  to  compel  the  refusing  party  to  recognise  it,  in  particular  with  regard  to  objective, transparent and non-discriminatory criteria on which such recognition is based.

- 14. Member  States  shall  ensure  that  any  available  support  for  cogeneration  is  subject  to  the  electricity  produced originating from high-efficiency cogeneration and the waste heat being effectively used to achieve primary energy savings. Public  support  to  cogeneration  and  district  heating  generation  and  networks  shall  be  subject  to  State  aid  rules, where applicable.

## Article 27

## Energy transformation, transmission and distribution

- 1. National energy regulatory authorities shall apply the energy efficiency first principle, in accordance with Article 3 of this  Directive,  in  carrying  out  the  regulatory  tasks  provided  for  in  Directives  2009/73/EC  and  (EU)  2019/944  regarding their  decisions  on  the  operation  of  the  gas  and  electricity  infrastructure,  including  their  decisions  on  network  tariffs.  In addition  to  the  energy  efficiency  first  principle,  national  energy  regulatory  authorities  may  take  into  account  cost efficiency, system efficiency and security of supply, and market integration, while safeguarding the Union's climate targets and sustainability, as set out in Article 18 of Regulation (EU) 2019/943 and in Article 13 of Regulation (EC) No 715/2009.
- 2. Member States shall ensure that gas and electricity transmission and distribution system operators apply the energy efficiency first  principle,  in  accordance  with Article 3  of  this  Directive, in  their  network planning, network development and  investment  decisions.  National  regulatory  authorities  or  other  designated  national  authorities  shall  verify  that methodologies  used  by  transmission  system  operators  and  distribution  system  operators  assess  alternatives  in  the  costbenefit  analysis  and  take  into  account  the  wider  benefits  of  energy  efficiency  solutions,  demand-side  flexibility  and investment into assets that contribute to climate change mitigation. National regulatory authorities and other designated authorities  shall  also  verify  the  implementation  of  the  energy  efficiency  first  principle  by  the  transmission  system operators  or  distribution system  operators  when  approving,  verifying  or monitoring  their projects and  network development  plans  pursuant  to  Article  22  of  Directive  2009/73/EC  and  to  Article  32(3)  and  Article  51  of  Directive (EU) 2019/944. National regulatory authorities may provide methodologies and guidance on how to assess alternatives in the  cost-benefit  analysis  in  close  cooperation  with  the  transmission  system  operators  and  distribution  system  operators, which can share key technical expertise.
- 3. Member  States  shall  ensure  that  transmission  and  distribution  system  operators  monitor  and  quantify  the  overall volume  of  network  losses  and,  where  it  is  technically  and  financially  feasible,  optimise  networks  and  improve  network efficiency.  Transmission  and  distribution  system  operators  shall  report  those  measures  and  expected  energy  savings through  the  reduction  of  network  losses  to  the  national  energy  regulatory  authority.  Member  States  shall  ensure  that transmission  and  distribution  system  operators  assess  energy  efficiency  improvement  measures  with  regard  to  their existing gas or electricity transmission or distribution systems and improve energy efficiency in infrastructure design and operation,  especially  in  terms  of  smart  grid  deployment.  Member  States  shall  encourage  transmission  and  distribution system operators to develop innovative solutions to improve the energy efficiency of existing and future systems through incentive-based regulations in accordance with the tariff principles set out in Article 18 of Regulation (EU) 2019/943 and Article 13 of Regulation (EC) No 715/2009.
- 4. National energy regulatory authorities shall include a specific section on the progress achieved in energy efficiency improvements regarding the operation of the gas and electricity infrastructure in the annual report drawn up pursuant to Article 41 of Directive 2009/73/EC and pursuant to Article 59(1), point (i), of Directive (EU) 2019/944. In those reports, national energy regulatory authorities shall provide an assessment of the overall efficiency in the operation of the gas and electricity infrastructure, the measures  carried  out  by  transmission  and  distribution  system  operators  and,  where applicable, provide recommendations for energy efficiency improvements, including cost-efficient alternatives that reduce peak loads and overall electricity use.

EN

- 5. For  electricity,  Member  States  shall  ensure  that  network  regulation  and  network  tariffs  fulfil  the  criteria  set  out  in Annex XIII, taking into account network codes and guidelines developed pursuant to Regulation (EU) 2019/943 and the obligation  set  out  in  Article  59(7),  point  (a),  of  Directive  (EU)  2019/944  to  allow  for  necessary  investments  in  the networks to be carried out in a manner ensuring the viability of the networks.
- 6. Member  States  may  permit  components  of  schemes  and  tariff  structures  with  a  social  aim  for  net-bound  energy transmission and distribution, provided that any disruptive effects on the transmission and distribution system are kept to the minimum necessary and are not disproportionate to the social aim.
- 7. National regulatory authorities shall ensure the removal of  those incentives in transmission and distribution tariffs that are detrimental to the energy efficiency of the generation, transmission, distribution and supply of electricity and gas. Member  States  shall  ensure  efficiency  in  infrastructure  design  and  the  operation  of  the  existing  infrastructure,  in accordance with Regulation (EU) 2019/943, and that tariffs allow for demand response.
- 8. Transmission system operators and distribution system operators shall comply with Annex XIV.
- 9. Where  appropriate,  national  regulatory  authorities  may  require  transmission  system  operators  and  distribution system operators to encourage high-efficiency cogeneration to be located close to areas of heat demand by reducing the connection and use-of-system charges.
- 10. Member States may allow producers of electricity from high-efficiency cogeneration wishing to be connected to the grid to issue a call for tender for the connection work.
- 11. When reporting under Directive 2010/75/EU, and without prejudice to Article 9(2) of that Directive, Member States shall consider including information on energy efficiency levels of installations undertaking the combustion of fuels with total rated thermal input of 50 MW or more in the light of the relevant best available techniques developed in accordance with Directive 2010/75/EU.

## CHAPTER VI

## HORIZONTAL PROVISIONS

## Article 28

## Availability of qualification, accreditation and certification schemes

- 1. Member States  shall  set  up  a  network  ensuring  the  appropriate  level  of  competences  for  energy  efficiency-related professions that corresponds to market needs. Member States, in close cooperation with the social partners, shall ensure that  certification  or  equivalent  qualification  schemes,  including,  where  necessary,  suitable  training  programmes,  are available for energy efficiency-related professions including providers of energy services, providers of energy audits, energy managers,  independent experts,  installers  of  building  elements  as  referred  to  in  Directive  2010/31/EU,  and  providers  of integrated renovation works, and are reliable and contribute to national energy efficiency objectives and the overall Union decarbonisation objectives.

Member States shall ensure that providers of certification or equivalent qualification schemes, including, where necessary, suitable training programmes are accredited in accordance with Regulation (EC) No 765/2008 of the European Parliament and of the Council ( 47 ) or approved in line with converging national legislation or standards.

( 47 ) Regulation  (EC)  No  765/2008  of  the  European  Parliament  and  of  the  Council  of  9  July  2008  setting  out  the  requirements  for accreditation and repealing Regulation (EEC) No 339/93 (OJ L 218, 13.8.2008, p. 30).

EN

- 2. Member  States  shall  promote  participation  in  certification,  training  and  education  programmes  to  ensure  the appropriate level of competences for energy efficiency professions that correspond to market needs.
- 3. By 11 October 2024, the Commission shall:
- (a) in cooperation with a group of experts nominated by Member States, set up a framework for or design a campaign to attract more people to energy efficiency professions while ensuring respect for the principle of non-discrimination;
- (b) assess the viability of setting up a single point of access platform, making use of existing initiatives where possible, to provide  support  to  the  Member  States  in  setting  up  their  measures  to  ensure  the  appropriate  level  of  qualified professionals needed to keep up with the pace of progress in energy efficiency to reach the Union's climate and energy targets. The platform would gather experts from Member States, the social partners, education institutions, academia and  other relevant stakeholders to foster and  promote  best  practices of qualification schemes  and  training programmes to ensure more energy efficiency professionals and to re-skill or up-skill existing professionals in order to meet market needs.
- 4. Member  States  shall  ensure  that  national  certification,  or  equivalent  qualification  schemes,  including,  where necessary, training programmes, take into account existing European or international standards on energy efficiency.
- 5. Member States  shall  make  publicly  available  the  certification,  equivalent  qualification  schemes  or  suitable  training programmes referred to in paragraph 1, and shall cooperate among themselves and with the Commission on comparisons between, and recognition of, the schemes.

Member States shall take appropriate measures to make consumers aware of the availability of the schemes in accordance with Article 29(1).

- 6. By 31 December 2024 and at least every four years thereafter, Member States shall assess whether the schemes ensure the  necessary  level  of  competences  and  equal  access  to  all  individuals  in  accordance  with  the  principle  of  nondiscrimination for energy services providers, energy auditors, energy managers, independent experts, installers of building elements as referred to in Directive 2010/31/EU, and providers of integrated renovation works. Member States shall also assess the gap between  available and in demand  professionals. Member  States shall make  the assessment and recommendations  thereof  publicly  available  and  submit  them  through  the  e-platform  established  in  accordance  with Article 28 of Regulation (EU) 2018/1999.

## Article 29

## Energy services

- 1. Member States shall promote the energy services market and access to it for SMEs by disseminating clear and easily accessible information on:
- (a) available energy service contracts and clauses that should be included in such contracts to guarantee energy savings and final customers' rights;
- (b) financial instruments, incentives, grants, revolving funds, guarantees, insurance schemes, and loans to support energy efficiency service projects;
- (c) available energy  services  providers,  such  as  ESCOs,  that  are  qualified  or  certified and  their  qualifications or certifications in accordance with Article 28;
- (d) available monitoring and verification methodologies and quality control schemes.
- 2. Member States shall encourage the development of quality labels, inter alia, by trade associations, based on European or international standards where relevant.

EN

- 3. Member States shall make publicly available and regularly update a list of available energy service providers that are qualified or certified and their qualifications or certifications in accordance with Article 28, or provide an interface where energy service providers can provide that information.
- 4. Member States shall promote and ensure, where technically and economically feasible, the use of energy performance contracting  for  renovations  of  large  buildings  that  are  owned  by  public  bodies.  For  renovations  of  large  non-residential buildings with a total useful floor area above 750 m , Member States shall ensure that public bodies assess the feasibility of 2 using energy performance contracting and other performance-based energy services.

Member States may encourage public bodies to combine energy performance contracting with expanded energy services, including  demand  response  and  storage,  in  order  to  ensure  energy  savings  and  maintain  the  results  obtained  over  time through continuous monitoring, effective operation and maintenance.

- 5. Member  States  shall  support  the  public  sector  in  taking  up  energy  service  offers,  in  particular  for  building refurbishment, by:
- (a) providing model contracts for energy performance contracting which include at least the items listed in Annex XV and take  into  account  the  existing  European  or  international  standards,  available  tendering  guidelines  and  the  Eurostat guide to the statistical treatment of energy performance contracts in government accounts;
- (b) providing  information  on  best  practices  for  energy  performance  contracting,  including,  if  available,  a  cost-benefit analysis using a life-cycle approach;
- (c) promoting  and  making  publicly  available  a  database  of  implemented  and  ongoing  energy  performance  contracting projects that includes the projected and achieved energy savings.
- 6. Member States shall support the proper functioning of the energy services market, by taking the following measures:
- (a) identifying and publicising one or more points of contact where final customers can obtain the information referred to in paragraph 1;
- (b) removing the regulatory and non-regulatory barriers that impede the uptake of energy performance contracting and other energy efficiency service models for the identification or implementation of energy saving measures, or both;
- (c) setting up and promoting the role of advisory bodies and independent market intermediaries including one-stop shops or  similar  support  mechanisms  to  stimulate  market  development  on  the  demand  and  supply  sides,  and  making information about those support mechanisms publicly available and accessible to market actors.
- 7. For the purpose of supporting the proper functioning of the energy services market, Member States may establish an individual  mechanism  or  designate  an  ombudsperson  to  ensure  the  efficient  handling  of  complaints  and  out-of-court settlement of disputes arising from energy service and energy performance contracts.
- 8. Member States shall ensure that energy distributors, distribution system operators and retail energy sales companies refrain  from  any  activities  that  may  impede  the  demand  for  and  delivery  of  energy  services  or  energy  efficiency improvement measures,  or  hinder  the  development  of  markets  for  such  services  or  measures,  including  foreclosing  the market for competitors or abusing dominant positions.

## Article 30

## National energy efficiency fund, financing and technical support

- 1. Without  prejudice  to  Articles  107  and  108  TFEU,  Member  States  shall  facilitate  the  establishment  of  financing facilities,  or  the  use  of  existing  ones,  for  energy  efficiency  improvement  measures  to  maximise  the  benefits  of  multiple streams of financing and the combination of grants, financial instruments and technical assistance.

EN

- 2. The  Commission  shall,  where  appropriate,  directly  or  via  financial  institutions,  assist  Member  States  in  setting  up financing  facilities  and  project  development  assistance  facilities  at  national,  regional  or  local  level  with  the  aim  of increasing  investments  in  energy  efficiency  in  different  sectors  and  of  protecting  and  empowering  people  affected  by energy  poverty,  vulnerable  customers,  people  in  low-income  households  and,  where  applicable,  people  living  in  social housing, including by integrating an equality perspective so that no one is left behind.
- 3. Member States shall adopt measures that promote energy efficiency lending products, such as green mortgages and green  loans,  secured  and  unsecured,  and  ensure  that  they  are  offered  widely  and  in  a  non-discriminatory  manner  by financial  institutions  and,  are  visible  and  accessible  to  consumers.  Member  States  shall  adopt  measures  to  facilitate  the implementation  of  on-bill  and  on-tax  financing  schemes,  taking  into  account  the  Commission  guidance  provided  in accordance with paragraph 10. Member States shall ensure that banks and other financial institutions receive information on  opportunities  to  participate  in  the  financing  of  energy  efficiency  improvement  measures,  including  through  the creation of public-private partnerships. Member States shall encourage the setting up of loan guarantee facilities for energy efficiency investment.
- 4. Without  prejudice  to  Articles  107  and  108  TFEU,  Member  States  shall  promote  the  establishment  of  financial support schemes to increase the uptake of energy efficiency improvement measures for  the substantial refurbishment of individual and district heating and cooling systems.
- 5. Member States shall promote the establishment of local expertise and technical assistance, where appropriate through existing  networks  and  facilities,  to  advise  on  best  practices  with  regard  to  achieving  the  decarbonisation  of  local  district heating and cooling, such as access to dedicated financial support.
- 6. The Commission shall facilitate the exchange of best practices between the competent national or regional authorities or  bodies,  including  through  annual  meetings  of  the  regulatory  bodies,  public  databases  with  information  on  the implementation of measures by Member States, and cross-country comparisons.
- 7. In order to mobilise private financing for energy efficiency measures and energy renovation and to contribute to the achievement the Union's energy efficiency targets and of the national contributions pursuant to Article 4 of this Directive and  of  the  objectives  in  Directive  2010/31/EU,  the  Commission  shall  conduct  a  dialogue  with  both  public  and  private financial institutions, as well as relevant specific sectors in order to map out needs and possible actions it can take.
- 8. The actions referred to in paragraph 7 shall include the following elements:
- (a) mobilising capital investment into energy efficiency by considering the wider impacts of energy savings;
- (b) facilitating the implementation of dedicated energy efficiency financial instruments and financing schemes at scale to be set up by financial institutions;
- (c) ensuring better energy and finance performance data by:
- (i) examining further how energy efficiency investments improve underlying asset values;
- (ii) supporting studies to assess the monetisation of the non-energy benefits of energy efficiency investments.
- 9. For the purpose of mobilising private financing of energy efficiency measures and energy renovation, Member States shall, when implementing this Directive:
- (a) consider  ways  to  make  better  use  of  energy  management  systems  and  energy  audits  under  Article  11  to  influence decision-making;

EN

- (b) make optimal use of  the possibilities and tools available in the Union budget and proposed in the smart finance for smart buildings initiative and in Commission communication of 14 October 2020 on 'A Renovation Wave for Europe - greening our buildings, creating jobs, improving lives'.
- 10. By 31 December 2024, the Commission shall provide guidance for Member States and market actors on how to unlock private investment.

The guidance shall have the purpose of helping Member States and market actors to develop and implement their energy efficiency investments, including in the various Union programmes, and shall propose adequate financial mechanisms and innovative financing solutions, with a combination of grants, financial instruments and project development assistance, to scale up existing initiatives and use the Union programmes as a catalyst to leverage and trigger private financing.

- 11. Member States may set up a national energy efficiency fund. The purpose of this fund shall be to implement energy efficiency measures to support Member States in meeting their national energy efficiency contributions and their indicative trajectories referred to in Article 4(2). The national energy efficiency fund may be established as a dedicated fund within an already existing national facility promoting capital investments. The national energy efficiency fund may be financed with revenues from the allowance auctions pursuant to the EU ETS on buildings and transport sectors.
- 12. Where Member States set up national energy efficiency funds, as referred to in paragraph 11 of  this Article, they shall establish financing instruments, including public guarantees, to increase the uptake of private investments in energy efficiency and of the energy efficiency lending products and innovative schemes referred to in paragraph 3 of this Article. Pursuant to Article 8(3) and Article 24, the national energy efficiency fund shall support the implementation of measures as  a  priority  among  people  affected  by  energy  poverty,  vulnerable  customers,  people  in  low-income  households  and, where applicable, people living in social housing. That support shall include financing for energy efficiency measures for SMEs in order to leverage and trigger private financing for SMEs.
- 13. Member  States  may  allow  public  bodies  to  fulfil  the  obligations  set  out  in  Article  6(1)  by  means  of  annual contributions to the national energy efficiency fund equivalent to the amount of the investments required to achieve those obligations.
- 14. Member  States  may  provide  that  obligated  parties  can  fulfil  their  obligations  set  out  in  Article  8(1)  and  (4)  by contributing  every  year  to  the  national  energy  efficiency  fund  an  amount  equal  to  the  investments  required  to  achieve those obligations.
- 15. Member States may use their revenues from annual emission allocations under Decision No 406/2009/EC for the development of innovative financing for energy efficiency improvements.
- 16. The Commission shall assess the effectiveness and efficiency of energy efficiency public funding support at Union and national level and the Member States' capacity to increase the uptake of private investments in energy efficiency, while also taking into account public financing needs expressed in the national energy and climate plans. The Commission shall evaluate  whether  an  energy  efficiency  mechanism  at  Union  level,  with  the  objective  of  providing  a  Union  guarantee, technical  assistance  and  associated  grants  to  enable  the  implementation  of  financial  instruments,  and  financing  and support schemes at national level,  could  support  in  a  cost-effective  way  the  achievement of  the  Union  energy efficiency and climate targets, and, if appropriate, propose the establishment of such a mechanism.

To  that  end,  the  Commission  shall  submit  by  30  March  2024 a  report  to  the  European  Parliament  and  to  the  Council, accompanied, where appropriate, by legislative proposals.

- 17. Member States shall report to the Commission by 15 March 2025 and every two years thereafter, as part of their integrated  national  energy  and  climate  progress  reports  submitted  pursuant  to  Article  17  and  in  accordance  with Article 21 of Regulation (EU) 2018/1999, the following data:

EN

- (a) the  volume  of  public  investments  on  energy  efficiency  and  the  average  leverage  factor  achieved  by  public  funding supporting energy efficiency measures;
- (b) the volume of energy efficiency lending products, distinguishing between different products;
- (c) where relevant, national financing programmes put in place to increase uptake of energy efficiency and best practices, and innovative financing schemes for energy efficiency.

To  facilitate  the  preparation  of  the  report  referred  to  in  the  first  subparagraph  of  this  paragraph,  the  Commission  shall integrate  the  requirements  set  out  in  that  subparagraph  in  the  common  template  laid  down  in  the  implementing  acts adopted pursuant to Article 17(4) of Regulation (EU) 2018/1999.

- 18. For the purpose of fulfilling the obligation referred to in paragraph 17, point (b), and without prejudice to additional national measures, Member States shall take into consideration the existing disclosure obligations for financial institutions, including:
- (a) the disclosure rules for credit institutions under Commission Delegated Regulation (EU) 2021/2178 ( 48 );
- (b) the  ESG  risks  disclosure  requirements  for  credit  institutions  in  accordance  with  Article  449a  of  Regulation  (EU) No 575/2013 of the European Parliament and of the Council ( 49 ).

To  facilitate  the  collection  and  aggregation  of  data  on  volume  of  energy  efficiency  lending  product  for  the  purpose  of fulfilling the obligation referred to in paragraph 17, point (b), the Commission shall by 15 March 2024 provide guidance to Member States on the arrangements for accessing, collecting and aggregating data on the volume of energy efficiency lending products at national level.

## Article 31

## Conversion factors and primary energy factors

- 1. For  the  purpose  of  comparison  of  energy  savings  and  conversion  to  a  comparable  unit,  the  net  calorific  values  in Annex VI of Regulation (EU) 2018/2066 and the primary energy factors set out in paragraph 2 of this Article shall apply unless the use of other values or factors can be justified.
- 2. A  primary  energy  factor  shall  be  applicable  when  energy  savings  are  calculated  in  primary  energy  terms  using  a bottom-up approach based on final energy consumption.
- 3. For savings in kWh electricity, Member States shall apply a coefficient in order  to accurately calculate the resulting primary energy consumption savings. Member States shall apply a default coefficient of 1,9 unless they use their discretion to define a different coefficient based upon justified national circumstances.
- 4. For savings in kWh of other energy carriers, Member States shall apply a coefficient in order to accurately calculate the resulting primary energy consumption savings.
- 5. Where Member States establish their own coefficient to a default value provided pursuant to this Directive, Member States  shall  establish  that  coefficient  through  a  transparent  methodology  on  the  basis  of  national,  regional  or  local circumstances  affecting  primary  energy  consumption.  The  circumstances  shall  be  substantiated,  verifiable  and  based  on objective and non-discriminatory criteria.

( 48 ) Commission  Delegated  Regulation  (EU)  2021/2178  of  6  July  2021  supplementing  Regulation  (EU)  2020/852  of  the  European Parliament and of the Council by specifying the content and presentation of information to be disclosed by undertakings subject to Articles  19a  or  29a  of  Directive  2013/34/EU  concerning  environmentally  sustainable  economic  activities,  and  specifying  the methodology to comply with that disclosure obligation (OJ L 443, 10.12.2021, p. 9).

( 49 ) Regulation (EU) No 575/2013 of the European Parliament and of the Council of 26 June 2013 on prudential requirements for credit institutions and amending Regulation (EU) No 648/2012 (OJ L 176, 27.6.2013, p. 1).

EN

20.9.2023

- 6. Where establishing an own coefficient, Member States shall take into account the energy mix included in the update of  their  integrated  national  energy  and climate plans submitted pursuant to Article 14(2) of Regulation (EU) 2018/1999 and their subsequent integrated national energy and climate plans notified to the Commission pursuant to Article 3 and Articles 7 to 12 of  that Regulation. If  they deviate from the default value, Member States shall notify the coefficient that they use to the Commission along with the calculation methodology and underlying data in those updates and subsequent plans.
- 7. By 25 December 2026 and every four  years thereafter, the Commission shall revise the default coefficients on the basis  of  observed  data.  Those  revisions  shall  be  carried  out  taking  into  account  its  effects  on  Union  law  such  as Directive 2009/125/EC and Regulation (EU) 2017/1369.

## CHAPTER VII

## FINAL PROVISIONS

## Article 32

## Penalties

Member States shall lay down the rules on penalties applicable to infringements of national provisions adopted pursuant to this Directive and shall take all measures necessary to ensure that they are implemented. The penalties provided for shall be effective, proportionate and dissuasive. Member States shall by 11 October 2025 notify the Commission of those rules and of those measures and shall notify it without delay of any subsequent amendment affecting them.

## Article 33

## Delegated acts

- 1. The  Commission  is  empowered  to  adopt  delegated  acts  in  accordance  with  Article  34  to  review  the  harmonised efficiency reference values laid down in Regulation (EU) 2015/2402.
- 2. The  Commission  is  empowered  to adopt  delegated  acts  in  accordance  with  Article  34  to  amend  this  Directive  by adapting to technical  progress  the  values,  calculation  methods,  default primary energy coefficients  and  the  requirements referred to in Article 31 and in Annexes II, III, V, VIII to XII, and XIV.
- 3. The Commission is empowered to adopt delegated acts in accordance with Article 34 to supplement this Directive by establishing, after having consulted the relevant stakeholders, a common Union scheme for rating the sustainability of data centres  located  in  its  territory.  The  Commission  shall  adopt  the  first  such  delegated  act  by  31  December  2023.  The common  Union  scheme  shall  establish  the  definition  of  data  centre  sustainability  indicators  and  shall  set  out  the  key performance indicators and the methodology to measure them.

## Article 34

## Exercise of the delegation

- 1. The power to adopt delegated acts is conferred on the Commission subject to the conditions laid down in this Article.
- 2. The power to adopt delegated acts referred to in Article 33 shall be conferred on the Commission for a period of five years from 10 October 2023. The Commission shall draw up a report in respect of the delegation of power not later than nine  months  before  the  end  of  the  five-year  period.  The  delegation  of  power  shall  be  tacitly  extended  for  periods  of  an identical  duration,  unless  the  European  Parliament  or  the  Council  opposes  such  extension  not  later  than  three  months before the end of each period.

EN

- 3. The delegation of power referred to in Article 33 may be revoked at any time by the European Parliament or by the Council. A decision to revoke shall put an end to the delegation of the power specified in that decision. It shall take effect the  day  following  the  publication  of  the  decision  in  the Official  Journal  of  the  European  Union or  at  a  later  date  specified therein. It shall not affect the validity of any delegated acts already in force.
- 4. Before adopting a delegated act, the Commission shall consult experts designated by each Member State in accordance with the principles laid down in the Interinstitutional Agreement of 13 April 2016 on Better Law-Making.
- 5. As soon as it adopts a delegated act, the Commission shall notify it simultaneously to the European Parliament and to the Council.
- 6. A delegated act adopted pursuant to Article 33 shall enter into force only if no objection has been expressed either by the  European  Parliament  or  by  the  Council  within  a  period  of  two  months  of  notification  of  that  act  to  the  European Parliament  and  the  Council  or  if,  before  the  expiry  of  that  period,  the  European  Parliament  and  the  Council  have  both informed the Commission that they will not object. That period shall be extended by two months at the initiative of the European Parliament or of the Council.

## Article 35

## Review and monitoring of implementation

- 1. In the context of its State of the Energy Union  report submitted pursuant to Article 35  of Regulation (EU) 2018/1999, the Commission shall report on the functioning of the carbon market in accordance with Article 35(1) and Article 35(2), point (c), of that Regulation, taking into consideration the effects of the implementation of this Directive.
- 2. By 31 October 2025 and every four years thereafter, the Commission shall evaluate the existing measures to achieve energy  efficiency  increase  and  decarbonisation  in  heating  and  cooling.  The  evaluation  shall  take  into  account  all  of  the following:
- (a) energy efficiency and GHG emissions trends in heating and cooling, including in district heating and cooling;
- (b) interlinkages between measures taken;
- (c) changes in energy efficiency and greenhouse gas emissions in the heating and cooling;
- (d) existing and planned energy efficiency policies and measures and greenhouse gas reduction policies and measures at Union and national level;
- (e) measures which Member States provided in their comprehensive assessments pursuant to Article 25(1) of this Directive and notified in accordance with Article 17(1) of Regulation (EU) 2018/1999.
- By 31 October 2025 and every four years thereafter, the Commission shall submit a report to the European Parliament and to the Council on that evaluation and, if appropriate, propose measures to ensure the achievement of the Union's climate and energy targets.
- 3. Member States shall submit to the Commission before 30 April each year statistics on national electricity and heat production from high and low efficiency cogeneration, in accordance with the general principles set out in Annex II, in relation  to  total  heat  and  electricity  production.  They  shall  also  submit  annual  statistics  on  cogeneration  heat  and electricity capacities and fuels for cogeneration, and on district heating and cooling production and capacities, in relation to  total  heat  and  electricity  production  and  capacities.  Member  States  shall  submit  statistics  on  primary  energy  savings achieved by the application of cogeneration in accordance with the methodology set out in Annex III.

EN

- 4. By 1 January 2021, the Commission shall submit a report to the European Parliament and to the Council, on the basis of  an  assessment  of  the  potential  for  energy  efficiency  in  conversion,  transformation,  transmission,  transportation  and storage of energy, accompanied, where appropriate, by legislative proposals.
- 5. By 31 December 2021, the Commission shall, subject to any changes to the provisions relating to retail markets in Directive 2009/73/EC, carry out an assessment, and submit a report to the European Parliament and to the Council, on the provisions  related  to  metering,  billing  and  consumer  information  for  natural  gas,  with  the  aim  of  aligning  them,  where appropriate,  with  the  relevant  provisions  for  electricity  in  Directive  (EU)  2019/944,  in  order  to  strengthen  consumer protection and enable final customers to receive more frequent, clear and up-to-date information about their  natural gas consumption and to regulate their energy use. As soon as possible after  the submission of  that report,  the  Commission shall, where appropriate, adopt legislative proposals.
- 6. By  31  October  2022,  the  Commission  shall  assess  whether  the  Union  has  achieved  its  2020  headline  targets  on energy efficiency.
- 7. By  28  February  2027 and  every  five  years  thereafter,  the  Commission  shall  evaluate  the  implementation  of  this Directive and submit a report to the European Parliament and to the Council.

That evaluation shall include:

- (a) an assessment of the general effectiveness of this Directive and the need to further adjust the Union's energy efficiency policy in accordance with the objectives of the Paris Agreement and in light of economic and innovation developments;
- (b) a detailed assessment of the aggregated macroeconomic impact of this Directive, with an emphasis on the effects on the Union's  energy  security,  energy  prices,  minimising  energy  poverty,  economic  growth,  competitiveness,  job  creation, mobility cost and household purchasing power;
- (c) the  Union's  2030  headline  targets  on  energy  efficiency  set  out  in  Article  4(1)  with  a  view  to  revising  those  targets upwards in the event of substantial cost reductions resulting from economic or technological developments, or where needed  to  meet  the  Union's  decarbonisation  targets  for  2040  or  2050,  or  its  international  commitments  for decarbonisation;
- (d) whether  Member  States  are  to  continue  to  achieve  new  annual  savings  in  accordance  with  Article  8(1),  first subparagraph, point (b)(iv), for a ten-year periods after 2030;
- (e) whether  Member  States  are  to  continue  to  ensure  that  at  least  3  %  of  the  total  floor  area  of  heated  and/or  cooled buildings  that  are  owned  by  public  bodies  is  renovated  each  year  in  accordance  with  Article  6(1)  with  a  view  to revising the renovation rate in that Article;
- (f) whether Member States are to continue to achieve a share of energy savings among people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing, pursuant to Article 8(3) for  the ten-year periods after 2030;
- (g) whether  Member  States  are  to  continue  to  achieve  a  reduction  of  final  energy  consumption  in  accordance  with Article 5(1);
- (h) the  impacts  of  this  Directive  on  supporting  economic  growth,  increasing  industrial  output,  the  deployment  of renewables or advanced efforts to climate neutrality.

The evaluation shall also cover the effects on efforts to electrify the economy and the introduction of hydrogen, including whether  any  change  to  the  treatment  of  clean  renewable  energy  sources  might  be  justified,  and  shall  propose,  where appropriate, solutions to any potentially identified adverse effect.

EN

That report shall be accompanied by a detailed assessment of whether there is a need to amend this Directive in the interests of regulatory simplification and, where appropriate, by proposals for further measures.

- 8. By  31  October  2032,  the  Commission  shall  assess  whether  the  Union  has  achieved  its  2030  headline  targets  on energy efficiency.

## Article 36

## Transposition

- 1. Member States shall bring into force the laws, regulations and  administrative provisions necessary to comply with Articles 1, 2 and 3, Article 4(1) to (4), Article 4(5), first, second, fourth, fifth and sixth subparagraphs, Article 4(6) and (7), Articles 5 to 11, Article 12(2) to (5), Articles 21 to 25, Article 26(1), (2) and (4) to (14), Article 27, Article 28(1) to (5), Articles 29 to 32 and Annexes I, III to VII, X, XI and XV by 11 October 2025.

Member  States  shall  bring  into  force  the  laws,  regulations  and  administrative  provisions  necessary  to  comply  with Article 4(5), third subparagraph, Article 12(1), Article 26(3) and Article 28(6) by the dates referred to therein. They shall immediately communicate the text of those measures to the Commission.

When Member States adopt those measures, they shall contain a reference to this Directive or be accompanied by such a reference on the occasion of their official publication. They shall also include a statement that references in existing laws, regulations and administrative provisions to the Directive repealed by this Directive shall be construed as references to this Directive. Member States shall determine how such reference is to be made and how that statement is to be formulated.

- 2. Member States shall  communicate to the  Commission  the  text of  the  main provisions  of  national  law  which  they adopt in the field covered by this Directive.

## Article 37

## Amendment to Regulation (EU) 2023/955

In Article 2 of Regulation (EU) 2023/955, point (1) is replaced by the following:

- '(1) 'energy  poverty'  means  energy  poverty  as  defined  in  Article  2,  point  (52),  of  Directive  (EU)  2023/1791  of  the European Parliament and of the Council (*).

\_\_\_\_\_\_\_\_\_\_\_\_\_

- (*) Directive (EU) 2023/1791 of the European Parliament and of the Council of 13 September 2023 on energy efficiency and amending Regulation (EU) 2023/955 (OJ L 231, 20.9.2023, p. 1).'.

## Article 38

## Repeal

Directive 2012/27/EU, as amended by the acts listed in Part A of Annex XVI is repealed with effect from 12 October 2025, without prejudice to the obligations of the Member States relating to the time-limits for the transposition into national law of the Directives set out in Part B of Annex XVI.

References to the repealed Directive shall be construed as references to this Directive and shall be read in accordance with the correlation table in Annex XVII.

<!-- image -->

EN

20.9.2023

## Article 39

## Entry into force and application

This  Directive  shall  enter  into  force  on  the  twentieth  day  following  that  of  its  publication  in  the Official  Journal  of  the European Union .

Articles 13, 14, 15, 16, 17, 18, 19 and 20 and Annexes II, VIII, IX, XII, XIII and XIV shall apply from 12 October 2025.

Article 37 shall apply from 30 June 2024.

Article 40

## Addressees

This Directive is addressed to the Member States.

Done at Strasbourg, 13 September 2023.

For the European Parliament The President R. METSOLA

For the Council The President J. M. ALBARES BUENO

EN

L  231/76

## ANNEX I

NATIONAL CONTRIBUTIONS TO THE UNION'S ENERGY EFFCIENCY TARGETS IN 2030 IN FINAL ENERGY CONSUMPTION AND/OR PRIMARY ENERGY CONSUMPTION

- 1. The level of national contributions is calculated on the basis of the indicative formula:

FECC 2030 ¼ C EU ð 1 - Target  FEC Þ B 2030

```
PECC 2030 ¼ C EU ð 1 - Target  PEC Þ B 2030
```

Where CEU  is a correction factor, Target is the level of national-specific ambition and FEC B2030 PECB2030 is the 2020 EU Reference Scenario used as a baseline for 2030.

- 2. The following indicative formula represents the objective criteria reflecting the factors listed in Article 4(3), points (d) (i)  to (iv),  each used for defining the level of national-specific ambition in % (Target) and having the same weight in the formula (0,25):
- (a) early action dependent contribution ('F early-action ');
- (b) GDP-per-capita dependent contribution ('F wealth ');
- (c) energy intensity dependent contribution ('F intensity ');
- (d) cost-effective energy savings potential contribution ('F potential ').
- 3. Fearly-action shall  be  calculated  for  each  Member  State  as  the  product  of  its  amount  of  energy  savings  and  the improvement  in  the  energy  intensity  that  each  Member  State  achieved.  The  amount  of  energy  savings  for  each Member  State  shall  be  calculated  on  the  basis  of  the  reduction  of  energy  consumption  (in  toe)  to  the  Union's reduction  of  energy  consumption  between  the  three-year  average  for  the  period  2007-2009  and  the  three-year average  for  the  period  2017-2019.  The  improvement  in  the  energy  intensity  for  each  Member  State  shall  be calculated on the basis of the reduction of energy intensity (in toe/EUR) to the Union's reduction of energy intensity between the three-year average for the period 2007-2009 and the three-year average for the period 2017-2019.
- 4. Fwealth shall be calculated for each Member State on the basis of its three-year average Eurostat's real GDP per capita index to the Union's three-year average over the 2017-2019 period, expressed in Purchasing power parities (PPPs).
- 5. Fintensity shall be calculated for each Member State on the basis of its three-year average final energy intensity (FEC or PEC per real GDP in PPPs) index to the Union's three-year average over 2017-2019 period.
- 6. Fpotential shall  be  calculated  for  each  Member  State  on  the  basis  of  the  final  or  primary  energy  savings  under  the PRIMES  MIX  55  %  scenario  for  2030.  The  savings  are  expressed  in  relation  to  2020  EU  Reference  Scenario projections for 2030.
- 7. For  each  criteria  provided  in  point  2(a)  to  (d),  a  lower  and  upper  limit  shall  be  applied.  The  level  of  ambition  for factors F wealth Fintensity and Fpotential shall be capped at 50 % and 150 % of the Union average level of ambition under a given factor. The level of ambition for factor F early-action shall be capped at 50 % and 100 % of the Union average level of ambition.
- 8. The source of the input data used to calculate the factors is Eurostat unless stated otherwise.

EN

20.9.2023

- 9. Ftotal shall be calculated as the weighted sum of all four factors (F early-action . F wealth Fintensity and Fpotential ). The target shall be then calculated as the product of the total factor F total and the Union target.
- 10. The Commission shall calculate a primary and final energy correction factor C EU, which shall be applied to adjust the sum of the formula results for all national contributions to the respective Union targets in 2030. The factor C EU is identical for all Member States.

EN

## ANNEX II

## GENERAL PRINCIPLES FOR THE CALCULATION OF ELECTRICITY FROM COGENERATION

## Part I

## General principles

Values  used  for  calculation  of  electricity  from  cogeneration  shall  be  determined  on  the  basis  of  the  expected  or  actual operation  of  the  unit  under  normal  conditions  of  use.  For  micro-cogeneration  units  the  calculation  may  be  based  on certified values.

- (1) Electricity  production  from  cogeneration  shall  be  considered  equal  to  total  annual  electricity  production  of  the  unit measured at the outlet of the main generators if the following conditions are met:
- (a) in cogeneration units of types (2), (4), (5), (6), (7) and (8) as referred to in Part II with an annual overall efficiency set by Member States at a level of at least 75 %;
- (b) in cogeneration units of types (1) and (3) as referred to in Part II with an annual overall efficiency set by Member States at a level of at least 80 %.
- (2) In  cogeneration  units  with  an  annual  overall  efficiency  below  the  value  referred  to  in  point  (1)(a),  namely  the cogeneration units of  types  (2),  (4),  (5),  (6),  (7),  and  (8)  as  referred  to  in  Part  II,  or  with  an  annual  overall  efficiency below the value referred to in point (1)(b), namely the cogeneration units of types (1) and (3) as referred to in Part II, electricity from cogeneration is calculated according to the following formula:

ECHP =HCHP*C

where:

ECHP is the amount of electricity from cogeneration;

C is the power-to-heat ratio;

HCHP is  the  amount of useful heat from cogeneration (calculated for  this purpose as total heat production minus any heat produced in separate boilers or by live steam extraction from the steam generator before the turbine).

The calculation of electricity from cogeneration shall be based on the actual power-to-heat ratio. If the actual power-toheat  ratio  of  a  cogeneration  unit  is  not  known,  the  following  default  values  may  be  used,  in  particular  for  statistical purposes, for units of  types (1), (2), (3), (4) and (5) as referred to in Part II provided that the calculated cogeneration electricity is less or equal to total electricity production of the unit:

| Type of the unit                              | Default power to heat ratio, C   |
|-----------------------------------------------|----------------------------------|
| Combined cycle gas turbine with heat recovery | 0,95                             |
| Steam back pressure turbine                   | 0,45                             |
| Steam condensing extraction turbine           | 0,45                             |
| Gas turbine with heat recovery                | 0,55                             |
| Internal combustion engine                    | 0,75                             |

If  Member States introduce default values for  power-to-heat ratios for  units of types (6), (7), (8), (9), (10) and (11) as referred to in Part II, such default values shall be published and shall be notified to the Commission.

- (3) If a share of the energy content of the fuel input to the cogeneration process is recovered in chemicals and recycled, that share can be subtracted from the fuel input before calculating the overall efficiency used in points (1) and (2).

EN

20.9.2023

- (4) Member  States  may  determine  the  power-to-heat  ratio  as  the  ratio  of  electricity  to  useful  heat  when  operating  in cogeneration mode at a lower capacity using operational data of the specific unit.
- (5) Member States may use reporting periods other than annual reporting periods for the purpose of the calculations in accordance with points (1) and (2).

## Part II

Cogeneration technologies covered by this Directive

- (1) Combined cycle gas turbine with heat recovery
- (2) Steam back pressure turbine
- (3) Steam condensing extraction turbine
- (4) Gas turbine with heat recovery
- (5) Internal combustion engine
- (6) Microturbines
- (7) Stirling engines
- (8) Fuel cells
- (9) Steam engines
- (10) Organic Rankine cycles
- (11) Any other type of technology or combination comprising cogeneration.

When implementing and applying the general principles for the calculation of electricity from cogeneration, Member States shall use the detailed Guidelines established by Commission Decision 2008/952/EC ( ). 1

( 1 ) Commission Decision 2008/952/EC of 19 November 2008 establishing detailed guidelines for the implementation and application of Annex II to Directive 2004/8/EC of the European Parliament and of the Council (OJ L 338, 17.12.2008, p. 55).

## ANNEX III

## METHODOLOGY FOR DETERMINING THE EFFICIENCY OF THE COGENERATION PROCESS

Values used for calculation of efficiency of cogeneration and primary energy savings shall be determined on the basis of the expected or actual operation of the unit under normal conditions of use.

- (a) High-efficiency cogeneration

For the purpose of this Directive, high-efficiency cogeneration shall fulfil the following criteria:

- -  cogeneration production from cogeneration units shall provide primary energy savings calculated in accordance with point (b) of at least 10 % compared with the references for separate production of heat and electricity;
- -  production  from  small-scale  and  micro-cogeneration  units  providing  primary  energy  savings  may  qualify  as  highefficiency cogeneration;
- -  for cogeneration units that are built or substantially refurbished after the transposition of this Annex, direct emissions of the carbon dioxide from cogeneration production that is fuelled with fossil fuels, are less than 270 gCO 2 per 1 kWh of energy output from the combined generation (including heating/cooling, power and mechanical energy);
- -  cogeneration units in operation before 10 October 2023, may derogate from this requirement until 1 January 2034 provided that they have a plan to reduce progressively the emissions to meet the threshold of less than 270 gCO 2 per 1 kWh by 1 January 2034 and that they have notified this plan to relevant operators and competent authorities.

When a cogeneration unit is built or substantially refurbished, Member States shall ensure that there is no increase in the use of fossil fuels other  than natural gas in existing heat sources compared to the annual consumption averaged over the previous three calendar years of full operation before refurbishment, and that any new heat sources in that system do not use fossil fuels other than natural gas.

## (b) Calculation of primary energy savings

The amount of primary energy savings provided by cogeneration production defined in accordance with Annex II shall be calculated on the basis of the following formula:

Where:

PES is primary energy savings.

CHP Hη is the heat efficiency of the cogeneration production defined as annual useful heat output divided by the fuel input used to produce the sum of useful heat output and electricity from cogeneration.

Ref Hη is the efficiency reference value for separate heat production.

CHP Eη is the electrical efficiency of the cogeneration production defined as annual electricity from cogeneration divided by the fuel input used to produce the sum of useful heat output and electricity from cogeneration. Where a cogeneration unit generates  mechanical  energy,  the  annual  electricity  from  cogeneration  may  be  increased  by  an  additional  element representing the amount of electricity which is equivalent to that of mechanical energy. This additional element does not create a right to issue guarantees of origin in accordance with Article 26(13).

Ref Eη is the efficiency reference value for separate electricity production.

EN

- (c) Calculations of energy savings using alternative calculation

Member States may calculate primary energy savings from a production of heat and electricity and mechanical energy as indicated below without applying Annex II to exclude the non-cogenerated heat and electricity parts of the same process. Such a production can be regarded as high-efficiency cogeneration provided that it fulfils the efficiency criteria set out in point (a) of this Annex and, for cogeneration units with an electrical capacity larger than 25 MW, the overall efficiency is above  70  %.  However,  specification  of  the  quantity  of  electricity  from  cogeneration  produced  in  such  a  production,  for issuing a guarantee of origin and for statistical purposes, shall be determined in accordance with Annex II.

If  primary energy savings for a process are calculated using alternative calculation as indicated above the primary energy savings shall be calculated using the formula in point (b) of this Annex replacing: 'CHP Hη' with 'Hη' and 'CHP Eη' with 'Eη', where:

Hη means the heat efficiency of the process, defined as the annual heat output divided by the fuel input used to produce the sum of heat output and electricity output.

Eη means the electricity efficiency of the process, defined as the annual electricity output divided by the fuel input used to produce the sum of heat output and electricity output. Where a cogeneration unit generates mechanical energy, the annual electricity  from  cogeneration  may  be  increased  by an  additional  element  representing  the  amount of electricity  which  is equivalent  to  that  of  mechanical  energy.  This  additional  element  will  not  create  a  right  to  issue  guarantees  of  origin  in accordance with Article 26(13).

Member  States  may  use  reporting  periods  other  than  annual  reporting  periods  for  the  purpose  of  the  calculations  in accordance with points (b) and (c) of this Annex.

For micro-cogeneration units the calculation of primary energy savings may be based on certified data.

- (d) Efficiency reference values for separate production of heat and electricity

The harmonised efficiency reference values shall consist of a matrix of values differentiated by relevant factors, including year  of  construction  and  types  of  fuel,  and  shall  be  based  on  a  well-documented  analysis  taking  into  account,  inter  alia, data  from  operational  use  under  realistic  conditions,  fuel  mix  and  climate  conditions  as  well  as  applied  cogeneration technologies.

The efficiency  reference  values  for  separate  production  of  heat  and  electricity  in  accordance  with  the  formula  set  out  in point  (b)  shall  establish  the  operating  efficiency  of  the  separate  heat  and  electricity  production  that  cogeneration  is intended to substitute.

The efficiency reference values shall be calculated according to the following principles:

- (i) for  cogeneration  units  the  comparison  with  separate  electricity  production  shall  be  based  on  the  principle  that  the same fuel categories are compared;
- (ii) each cogeneration unit shall be compared with the best available and economically justifiable technology for separate production of heat and electricity on the market in the year of construction of the cogeneration unit;
- (iii) the efficiency reference values for cogeneration units older than 10 years shall be fixed on the reference values of units of 10 years;
- (iv) the  efficiency  reference  values  for  separate  electricity  production  and  heat  production  shall  reflect  the  climatic differences between Member States.

EN

L  231/82

## ANNEX IV

## ENERGY EFFICIENCY REQUIREMENTS FOR PUBLIC PROCUREMENT

In  award  procedures  for  public  contracts  and  concessions,  contracting  authorities  and  contracting  entities  that  purchase products, services, buildings and works, shall:

- (a) where a product is covered by a delegated act adopted under Regulation (EU) 2017/1369, Directive 2010/30/EU or by a  related  Commission  implementing  act,  purchase  only  the  products  that  comply  with  the  criterion  laid  down  in Article 7(2) of that Regulation;
- (b) where a product not covered under point (a) is covered by an implementing measure under Directive 2009/125/EC, purchase only products that comply with energy efficiency benchmarks specified in that implementing measure;
- (c) where a product or a service is covered by the Union green public procurement criteria or available equivalent national criteria, with relevance to energy efficiency of the product or service, make best efforts to purchase only products and services  that  respect  at  least  the  technical  specifications  set  at  'core'  level  in  the  relevant  Union  green  public procurement criteria  or  available  equivalent  national  criteria  including  among  others  for  data  centres,  server  rooms and cloud services, road lighting and traffic signals, computers, monitors tablets and smartphones;
- (d) purchase  only  tyres  that  comply  with  the  criterion  of  having  the  highest  fuel  energy  efficiency  class,  as  defined  in Regulation  (EU)  2020/740,  which  shall  not  prevent  public  bodies  from  purchasing  tyres  with  the  highest  wet  grip class or external rolling noise class where justified by safety or public health reasons;
- (e) require  in  their  tenders  for  service  contracts  that  service  providers  use,  for  the  purposes  of  providing  the  services  in question,  only  products  that  comply  with  points  (a),  (b)  and  (d),  when  providing  the  services  in  question.  This requirement shall apply only to new products purchased by service providers partially or  wholly for  the purpose of providing the service in question;
- (f) purchase,  or  make  new  rental  agreements  for,  buildings  that  comply  at  least  with  nearly  zero-energy  level,  without prejudice to Article 6 of this Directive, unless the purpose of the purchase is:
- (i) to undertake deep renovation or demolition;
- (ii) in the case of public bodies, to re-sell the building without using it for the public body's own purposes; or
- (iii) to  preserve  it  as  a  building  officially  protected  as  part  of  a  designated  environment,  or  because  of  its  special architectural or historic merit.

Compliance  with  the  requirements  laid  down  in  point  (f)  of  this  Annex  shall  be  verified  by  means  of  the  energy performance certificates referred to in Article 11 of Directive 2010/31/EU.

EN

20.9.2023

## ANNEX V

## COMMON METHODS AND PRINCIPLES FOR CALCULATING THE IMPACT OF ENERGY EFFICIENCY OBLIGATION SCHEMES OR OTHER POLICY MEASURES UNDER ARTICLES 8, 9 AND 10 AND ARTICLE 30(14)

- 1. Methods for calculating energy savings other than those arising from taxation measures for the purposes of Articles 8, 9 and 10 and Article 30(14).
- Obligated, participating or entrusted parties, or implementing public authorities, may use the following methods for calculating energy savings:
- (a) deemed savings, by reference to the results of previous independently monitored energy improvements in similar installations. The generic approach is termed ' ex ante ';
- (b) metered savings, whereby the savings from the installation of a measure, or package of measures, are determined by recording the actual reduction in energy use, taking due account of factors such as additionality, occupancy, production levels and the weather which may affect consumption. The generic approach is termed ' ex post ';
- (c) scaled  savings,  whereby  engineering  estimates  of  savings  are  used.  This  approach  may  be  used  only  where establishing  robust  measured  data  for  a  specific  installation  is  difficult  or  disproportionately  expensive,  for example replacing a compressor or electric motor with a different kWh rating from that for which independent information about savings has been measured, or where those estimates are carried out on the basis of nationally established  methodologies  and  benchmarks  by  qualified  or  accredited  experts  that  are  independent  of  the obligated, participating or entrusted parties involved;
- (d) when calculating the energy savings for the purpose of Article 8(3) that can be counted to fulfil the obligation in that  Article,  Member  States  may  estimate  the  energy  savings  of  people  affected  by  energy  poverty,  vulnerable customers, people in low-income households and, where applicable, people living in social housing on the basis of  engineering  estimates  using  standardised  occupancy  and  thermal  comfort  conditions  or  parameters,  such as parameters  defined  in  national  building  regulations.  The  way  comfort  is  considered  for  actions  in  buildings should be reported by the Member States to the Commission together with explanations of their calculation methodology.
- (e) surveyed savings, where consumers' response to advice, information campaigns, labelling or certification schemes or smart metering is determined. This approach shall be used only for savings resulting from changes in consumer behaviour. It shall not be used for savings resulting from the installation of physical measures.
- 2. In  determining  the  energy  savings  for  an  energy  efficiency  measure  for  the  purposes  of  Articles  8,  9  and  10  and Article 30(14), the following principles apply:
- (a) Member States shall demonstrate that one of the objectives of the policy measure, whether new or existing, is the achievement  of  end-use  energy savings pursuant  to  Article 8(1) and  shall provide  evidence and  their documentation showing that the energy savings are caused by a policy measure, including voluntary agreements;
- (b) the savings shall be shown to be additional to those that would have occurred in any event without the activity of the  obligated,  participating  or  entrusted  parties,  or  implementing  public  authorities.  To  determine  the  savings that can be claimed as additional, Member States shall have regard to how energy use and demand would evolve in  the  absence  of  the  policy  measure  in  question  by  taking  into  account  at  least  the  following  factors:  energy consumption  trends,  changes  in  consumer  behaviour,  technological  progress  and  changes  caused  by  other measures implemented at Union and national level;

EN

- (c) savings resulting from the implementation of mandatory Union law shall be considered to be savings that would have occurred in any event, and thus shall not be claimed as energy savings for the purpose of Article 8(1). By way of derogation from that requirement, savings related to the renovation of existing buildings, including the savings resulting from  the  implementation  of  minimum  energy  performance  standards  in  buildings  in accordance  with  Directive  2010/31/EU,  may  be  claimed  as  energy  savings  for  the  purpose  of  Article  8(1), provided that  the  materiality criterion  referred  to  in  point  3(h)  of  this  Annex  is  ensured.  Measures  promoting energy efficiency  improvements  in  the  public  sector  pursuant  to  Article  5  and  Article  6  may  be  eligible  to  be taken into account for  the fulfilment of energy savings required under Article 8(1), provided that they result in verifiable  and  measurable  or  estimable  end-use  energy  savings.  The  calculation  of energy  savings  shall  comply with this Annex;
- (d) end-use  energy  savings  resulting  from  the  implementation  of  energy  efficiency  improvement  measures  taken pursuant  to  emergency  regulations  under  Article  122  TFEU  may  be  claimed  for  the  purpose  of  Article  8(1), provided that they result in verifiable and measurable or estimable end-use energy savings, with the exception of those energy savings resulting from rationing or curtailment measures;
- (e) measures taken pursuant to Regulation (EU) 2018/842 can be considered material, but Member States have to show that they result in verifiable and measurable or estimable end-use energy savings. The calculation of energy savings shall comply with this Annex;
- (f) Member States shall count only end use energy savings from policy measures in sectors or installations covered by  Chapter  IVa  of  Directive  2003/87/EC  if  they  result  from  the  implementation  of  Article  9  or  10  of  this Directive and which  go  beyond  the requirements laid down  in  Directive 2003/87/EC  or  beyond  the implementation of actions linked to the allocation of free allowances under that Directive. Member States shall demonstrate that the  policy  measures  result  in  verifiable  and  measurable  or  estimable  end-use  energy  savings. The  calculation  of  energy  savings  shall  comply  with  this  Annex.  If  an  entity  is  an  obligated  party  under  a national  energy  efficiency  obligation  scheme  under  Article  9  of  this  Directive  and  under  the  EU  ETS  for buildings  and  road  transport  under  Chapter  IVa  of  Directive  2003/87/EC,  the  monitoring  and  verification system  shall  ensure  that  the  carbon  price  passed  through  when  releasing  fuel  for  consumption  under  that Chapter is taken into account when calculating and reporting the energy savings of its energy saving measures;
- (g) credit may be given, provided that it is only given for savings exceeding the following levels:
- (i) Union emission performance standards for new passenger cars and new light commercial vehicles following the implementation of Regulation (EU) 2019/631 of the European Parliament and of the Council ( ); Member 1 States must provide reasons, their assumptions and their calculation methodology to show additionality to the Union's new vehicle CO2 requirements;
- (ii) Union requirements relating to the removal from the market of certain energy related products following the implementation  of  implementing  measures  under  Directive  2009/125/EC.  Member  States  shall  provide evidence, their assumptions and their calculation methodology to show additionality;
- (h) policies  with  the  purpose  of  encouraging  higher  levels  of  energy  efficiency  of  products,  equipment,  transport systems, vehicles and fuels, buildings and building elements, processes or markets shall be permitted, except for policy measures:
- (i) regarding  the  use  of  direct  combustion  of  fossil  fuel  technologies  that  are  newly  implemented  as  from 1 January 2026; and
- (ii) subsidising the use of direct combustion of fossil fuel technologies in residential buildings as from 1 January 2026.

( 1 ) Regulation  (EU)  2019/631  of  the  European  Parliament  and  of  the  Council  of  17  April  2019  setting  CO 2 emission  performance standards  for  new  passenger  cars  and  for  new  light  commercial  vehicles,  and  repealing  Regulations  (EC)  No  443/2009  and  (EU) No 510/2011 (OJ L 111, 25.4.2019, p. 13).

EN

- (i) energy savings as a result of policy measures newly implemented as from 1 January 2024 regarding the use of direct  fossil  fuel  combustion  in  products,  equipment,  transport  systems,  vehicles,  buildings  or  works  shall  not count  towards  the  fulfilment  of  energy  savings  obligation  pursuant  to  Article  8(1)(b).  In  the  case  of  policy measures  promoting  combinations  of  technologies,  the  share  of  energy  savings  related  to  the  fossil  fuel combustion technology are not eligible as from 1 January 2024.
- (j) by way of derogation from point (i), for the period 1 January 2024 to 31 December 2030, energy savings from direct  fossil  fuel  combustion  technologies  improving  the  energy  efficiency  in  energy  intense  enterprises  in  the industry sector  may be counted as energy savings only for  the purpose of Article 8(1), points (b) and (c), until 31 December 2030, provided that:
- (i) the  enterprise  has  carried  out  an  energy  audit  pursuant  to  Article  11(2)  and  an  implementation  plan including:
- -  an overview of all cost-effective energy efficiency measures with a payback period of five years or less, on the basis of simple pay-back period methodologies provided by the Member State,
- -  a  timeframe  for  the  implementation  of  all  recommended  energy  efficiency  measures  with  a  payback period of five years or fewer,
- -  a calculation of expected energy savings resulting from the energy efficiency measures recommended, and
- -  energy  efficiency  measures  related  to  the  use  of  direct  fossil  fuel  combustion  technologies  with  the relevant information needed for:
- -  proving that the measure identified does not increase the amount of energy needed or the capacity of an installation,
- -  justifying that the uptake of sustainable, non-fossil fuel technologies is technically not feasible,
- -  showing  that  the  direct  fossil  fuel  combustion  technology  complies  with  the  most  up-to-date corresponding Union emission performance legislation and prevents technology lock-in effects by ensuring future compatibility with climate-neutral alternative non-fossil fuels and technologies.
- (ii) the  continuation  of  the  use  of  direct  fossil  fuel  technologies  is  an  energy  efficiency  measure  to  decrease energy consumption with  a  payback  period  of  five  years  or  less,  on  the  basis  of  simple  pay-back  period methodologies  provided  by  the  Member  State,  recommended  as  result  of  an  energy  audit  pursuant  to Article 11(2) and included in the implementation plan;
- (iii) the use of direct fossil fuel technologies complies with the most up-to-date corresponding Union emission performance legislation, does not lead to technology lock-in effects and ensures future compatibility with climate-neutral alternative fuels and technologies;
- (iv) the use of direct fossil fuel technologies in the enterprise does not lead to an increased energy consumption or increase the capacity of the installation in that enterprise;
- (v) evidence is provided that no alternative, sustainable non-fossil fuel solution was technically feasible;
- (vi) the  use  of  direct  fossil  fuel  technologies  result  in  verifiable  and  measurable  or  estimable  end-use  energy savings calculated in accordance with this Annex;
- (vii) evidence is published on a website or is made publicly available for all interested citizens;

EN

- (k) measures  promoting  the  installation  of  small-scale  renewable  energy  technologies  on  or  in  buildings  may  be eligible to be taken into account for  the fulfilment of energy savings required under Article 8(1), provided that they result in verifiable  and measurable or estimable end-use energy savings. The calculation of energy savings shall comply with this Annex;
- (l) measures promoting the installation of solar  thermal technologies may be eligible to be taken into account for the  fulfilment  of  energy  savings  required  under  Article  8(1)  provided  that  they  result  in  verifiable  and measurable  or  estimable  end-use  energy  savings.  The  heat  produced  by  solar  thermal  technologies  from  solar radiation can be excluded from their end-use energy consumption;
- (m) for policies that accelerate the uptake of more efficient products and vehicles, except those newly implemented as from 1 January 2024 regarding the use of direct fossil fuel combustion, full credit may be claimed, provided that it  is  shown  that  such  uptake  takes  place  before  the  expiry  of  the  average  expected  lifetime  of  the  product  or vehicle,  or  before  the  product  or  vehicle  would  usually  be  replaced,  and  the  savings  are  claimed  only  for  the period until the end of the average expected lifetime of the product or vehicle to be replaced;
- (n) in promoting the uptake of energy efficiency measures, Member States shall, where relevant, ensure that quality standards for products, services and installation of measures are maintained or introduced where such standards do not exist;
- (o) to account for climatic variations between regions, Member States may choose to adjust the savings to a standard value or to accord different energy savings in accordance with temperature variations between regions;
- (p) the calculation of energy savings shall take into account the lifetime of  the measures and the rate at which the savings decline over time. That calculation shall count the savings each individual action will achieve during the period from its date of implementation to the end of each obligation period. Alternatively, Member States may adopt  another  method  that  is  estimated  to  achieve  at  least  the  same  total  quantity  of  savings.  When  using another  method,  Member  States  shall  ensure  that  the  total  amount  of  energy  savings  calculated  using  that method does not exceed the amount of energy savings that would have been the result of their calculation when counting  the  savings  each  individual  action  will  achieve  during  the  period  from  its  date  of  implementation  to 2030.  Member  States  shall  describe  in  detail  in  their  integrated  national  energy  and  climate  plans  notified pursuant to Article 3 and Articles 7 to 12 of Regulation (EU) 2018/1999 that other method and the provisions made to ensure that the binding calculation requirement is met.
- 3. Member  States  shall  ensure  that  the  following  requirements  for  policy  measures  taken  pursuant  to  Article  10  and Article 30(14) are met:
- (a) policy measures and individual actions produce verifiable end-use energy savings;
- (b) the  responsibility  of  each  participating  party,  entrusted  party  or  implementing  public  authority,  as  relevant,  is clearly defined;
- (c) the energy savings that are achieved or are to be achieved are determined in a transparent manner;
- (d) the  amount of energy  savings  required  or  to  be  achieved  by  the  policy  measure  is  expressed  in  either  primary energy  consumption  or  final  energy  consumption,  using  the  net  calorific  values  or  primary  energy  factors referred to in Article 31;
- (e) an  annual  report  on  the  energy  savings  achieved  by  entrusted  parties,  participating  parties  and  implementing public authorities be provided and made publicly available, as well as data on the annual trend of energy savings;
- (f) monitoring of the results and taking appropriate measures if progress is not satisfactory;
- (g) the energy savings from an individual action are not claimed by more than one party;

<!-- image -->

- (h) the activities of the participating party, entrusted party or implementing public authority are shown to be material to the achievement of the energy savings claimed;
- (i) the activities of the participating party, entrusted party or implementing public authority have no adverse effects on people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing.
- 4. In determining the energy savings from taxation-related policy measures introduced under Article 10, the following principles shall apply:
- (a) credit  shall  be  given  only  for  energy  savings  from  taxation  measures  exceeding  the minimum levels  of  taxation applicable to fuels as required in Council Directive 2003/96/EC ( ) or 2006/112/EC ( ); 2 3
- (b) short-run price elasticities  for  the  calculation  of  the  impact  of  the  energy  taxation  measures  shall  represent  the responsiveness  of  energy  demand  to  price  changes,  and  shall  be  estimated  on  the  basis  of  recent  and representative  official  data  sources,  which  are  applicable  for  the  Member  State,  and,  where  applicable,  on  the basis  of  accompanying  studies  from  an  independent  institute.  If  a  different  price  elasticity  than  short-run elasticities is used, Member States shall explain how energy efficiency improvements due to the implementation of  other  Union  legislation  have  been  included  in  the  baseline  used  to  estimate  the  energy  savings,  or  how  a double-counting of energy savings from other Union legislation has been avoided;
- (c) the energy savings from accompanying taxation policy instruments, including fiscal incentives or  payment to a fund, shall be accounted separately;
- (d) short-run elasticity estimates should be used to assess the energy savings from taxation measures to avoid overlap with Union law and other policy measures;
- (e) Member States shall determine distributional effects of  taxation  and equivalent  measures  on people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing, and show the effects of the mitigation measures implemented in accordance with Article 24(1), (2) and (3);
- (f) Member States shall provide evidence, including calculation methodologies, that where there is an overlap in the impact of  energy or  carbon  taxation  measures  or  emissions  trading  in  accordance  with  Directive  2003/87/EC, there is no double counting of energy savings.

## 5. Notification of methodology

Member  States  shall,  in  accordance  with  Regulation  (EU)  2018/1999,  notify  to  the  Commission  their  proposed detailed methodology for the operation of the energy efficiency obligation schemes and alternative measures referred to  in  Articles  9  and  10,  and  Article  30(14)  of  this  Directive.  Except  in  the  case  of  taxation,  such  notification  shall include information on:

- (a) the level of the energy savings required under Article 8(1), first subparagraph, or savings expected to be achieved over the whole period from 1 January 2021 to 31 December 2030;
- (b) how the  calculated  quantity  of  new  energy  savings  required  under  Article  8(1),  first  subparagraph,  or  energy savings expected to be achieved will be phased over the obligation period;
- (c) the obligated, participating or entrusted parties, or implementing public authorities;
- (d) target sectors;
- (e) policy  measures  and  individual  actions,  including  the  expected  total  amount  of  cumulative  energy  savings  for each measure;

( 2 ) Council Directive 2003/96/EC of 27 October 2003 restructuring the Community framework for the taxation of energy products and electricity (OJ L 283, 31.10.2003, p. 51).

( 3 ) Council Directive 2006/112/EC of 28 November 2006 on the common system of value added tax (OJ L 347, 11.12.2006, p. 1).

EN

- (f) policy measures or programmes or measures financed under a national energy efficiency fund implemented as a priority among people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing;
- (g) the share and the amount of energy savings to be achieved among people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing;
- (h) where  applicable,  the  indicators  applied,  the  arithmetic  average  share  and  the  outcome  of  policy  measures established pursuant to Article 8(3);
- (i) where applicable, impacts and adverse effects of policy measures implemented pursuant to Article 8(3) on people affected by energy poverty, vulnerable customers and, where applicable, people living in social housing;
- (j) the duration of the obligation period for the energy efficiency obligation scheme;
- (k) where  applicable,  the  amount  of  energy  savings  or  cost  reduction  targets  to  be  achieved  by  obligated  parties among people affected  by energy  poverty,  vulnerable  customers  and,  where  applicable,  people  living  in  social housing;
- (l) the actions provided for by the policy measure;
- (m) the  calculation  methodology,  including  how  additionality  and  materiality  have  been  determined  and  which methodologies and benchmarks are used for deemed and scaled savings, and, where applicable, the net calorific values and conversion factors used;
- (n) the lifetimes of measures, and how they are calculated or what they are based upon;
- (o) the approach taken to address climatic variations within the Member State;
- (p) the monitoring and verification systems for measures under Articles 9 and 10 and how their independence from the obligated, participating or entrusted parties is ensured;
- (q) in the case of taxation:
- (i) the target sectors and segment of taxpayers;
- (ii) the implementing public authority;
- (iii) the savings expected to be achieved;
- (iv) the duration of the taxation measure;
- (v) the calculation methodology, including the price elasticities used and how they have been established and
- (vi) how overlaps  with  EU  ETS  in  accordance  with  Directive  2003/87/EC  have  been  avoided  and  the  risk  of double counting has been abolished.

EN

20.9.2023

## ANNEX VI

MINIMUM CRITERIA FOR ENERGY AUDITS INCLUDING THOSE CARRIED OUT AS PART OF ENERGY MANAGEMENT SYSTEMS

The energy audits referred to in Article 11 shall:

- (a) be based on up-to-date, measured, traceable operational data on energy consumption and (for electricity) load profiles;
- (b) comprise a detailed review of the energy consumption profile of buildings or groups of buildings, industrial operations or installations, including transportation;
- (c) identify energy efficiency measures to decrease energy consumption;
- (d) identify the potential for cost-effective use or production of renewable energy;
- (e) build, whenever possible, on life-cycle cost analysis instead of simple payback periods in order to take account of longterm savings, residual values of long-term investments and discount rates;
- (f) be  proportionate,  and  sufficiently  representative  to  permit  the  drawing  of  a  reliable  picture  of  overall  energy performance and the reliable identification of the most significant opportunities for improvement.

Energy audits shall allow detailed and validated calculations for the proposed measures so as to provide clear information on potential savings.

The data used in energy audits shall be storable for historical analysis and tracking performance.

EN

L  231/90

## ANNEX VII

MINIMUM REQUIREMENTS FOR MONITORING AND PUBLISHING THE ENERGY PERFORMANCE OF DATA CENTRES

The  following  minimum  information  shall  be  monitored  and  published  with  regard  to  the  energy  performance  of  data centres referred to in Article 12:

- (a) the name of the data centre, the name of the owner and operators of the data centre, the date on which the data centre started its operations and the municipality where the data centre is based;
- (b) the floor area of the data centre, the installed power, the annual incoming and outgoing data traffic, and the amount of data stored and processed within the data centre;
- (c) the performance, during the last full calendar year, of the data centre in accordance with key performance indicators about, inter alia, energy consumption, power utilisation, temperature set points, waste heat utilisation, water usage and use of renewable energy, using as a basis, where applicable, the CEN/CENELEC EN 50600-4 'Information technology Data  centre  facilities  and  infrastructures',  until  the  entry  into  force  of the  delegated  act  adopted  pursuant  to Article 33(3).

EN

20.9.2023

## ANNEX VIII

## MINIMUM REQUIREMENTS FOR BILLING AND BILLING INFORMATION BASED ON ACTUAL CONSUMPTION OF NATURAL GAS

- 1. Minimum requirements for billing

## 1.1. Billing based on actual consumption

In order to enable final customers to regulate their own energy consumption, billing should take place on the basis of actual consumption at least once a year, and billing information should be made available at least on a quarterly basis, on request or  where the consumers have opted to receive electronic billing or else twice a year. Gas used only for cooking purposes may be exempt from this requirement.

## 1.2. Minimum information contained in the bill

Member States shall ensure that, where appropriate, the following information is made available to final customers in clear and understandable terms in or with their bills, contracts, transactions, and receipts at distribution stations:

- (a) current actual prices and actual consumption of energy;
- (b) comparisons  of  the  final  customer's  current  energy  consumption  with  consumption  for  the  same  period  in  the previous year, preferably in graphic form;
- (c) contact information for final customers' organisations, energy agencies or similar bodies, including website addresses from which information may be obtained on available energy efficiency improvement measures, comparative end-user profiles and objective technical specifications for energy-using equipment.

In  addition,  wherever  possible  and  useful,  Member  States  shall  ensure  that  comparisons  with  an  average  normalised  or benchmarked final customer in the same user category are made available to final customers in clear and understandable terms, in, with or signposted to within, their bills, contracts, transactions, and receipts at distribution stations.

## 1.3. Advice on energy efficiency accompanying bills and other feedback to final customers

When sending contracts and contract changes, and in the bills customers receive or through websites addressing individual customers, energy distributors, distribution system operators and retail energy sales companies shall inform their customers in a clear and understandable manner of contact information for independent consumer advice centres, energy agencies or similar institutions, including their internet addresses, where they can obtain advice on available energy efficiency measures, benchmark profiles for their energy consumption and technical specifications of energy using appliances that can serve to reduce the consumption of those appliances.

EN

## ANNEX IX

MINIMUM REQUIREMENTS FOR BILLING AND CONSUMPTION INFORMATION FOR HEATING, COOLING AND DOMESTIC HOT WATER

- 1. Billing based on actual consumption or heat cost allocator readings

In  order  to  enable  final  users  to  regulate  their  own  energy  consumption,  billing  shall  take  place  on  the  basis  of  actual consumption or heat cost allocator readings at least once per year.

## 2. Minimum frequency of billing or consumption information

Until  31  December  2021,  where  remotely  readable  meters  or  heat  cost  allocators  have  been  installed,  billing  or consumption information based on actual consumption or heat cost allocator readings shall be provided to final users at least on a quarterly basis upon request or where final customers have opted to receive electronic billing, or else twice a year.

From 1 January 2022, where remotely readable meters or heat cost allocators have been installed, billing or consumption information  based  on  actual  consumption  or  heat  cost  allocator  readings  shall  be  provided  to  final  users  at  least  on  a monthly basis. It may also be made available via the internet and be updated as frequently as allowed by the measurement devices  and  systems  used.  Heating  and  cooling  may  be  exempted  from  that  requirement  outside  the  heating  or  cooling seasons.

## 3. Minimum information contained in the bill

Member States  shall  ensure  that  the  following  information  is  made  available  to  final  users  in  clear  and  comprehensible terms in or with their bills where those are based on actual consumption or heat cost allocator readings:

- (a) current actual prices and actual consumption of energy or total heat cost and heat cost allocator readings;
- (b) the fuel mix used and the related annual GHG emissions, including for final users supplied by district heating or district cooling, and a description of the different taxes, levies and tariffs applied;
- (c) comparisons of  the  final  users'  current  energy  consumption  with  consumption  for  the  same  period  in  the  previous year, in graphic form and climate corrected for heating and cooling;
- (d) contact information for final customers' organisations, energy agencies or similar bodies, including website addresses, from  which  information  on  available  energy  efficiency  improvement  measures,  comparative  end-user  profiles  and objective technical specifications for energy-using equipment may be obtained;
- (e) information about related complaints procedures, ombudsman services or alternative dispute resolution mechanisms, as applicable in the Member States;
- (f) comparisons with an average normalised or benchmarked final user in the same user category. In the case of electronic bills, such comparisons may instead be made available online and signposted to within the bills.

Member States may limit the scope of the requirement to provide information about GHG emissions pursuant to point (b) of the  first subparagraph  to  include  only  supplies  from  district  heating  systems  with  a  total  rated  thermal  input exceeding 20 MW.

Bills  that  are  not  based  on  actual  consumption  or  heat  cost  allocator  readings  shall  contain  a  clear  and  comprehensible explanation  of  how  the  amount  set  out  in  the  bill  was  calculated,  and  at  least  the  information  referred  to  in  points  (d) and (e).

EN

20.9.2023

## ANNEX X

## POTENTIAL FOR EFFICIENCY IN HEATING AND COOLING

The comprehensive assessment of national heating and cooling potentials referred to in Article 25(1) shall include and shall be based on the following:

Part I

## OVERVIEW OF HEATING AND COOLING

1. heating and cooling demand in terms of assessed useful energy ( ) and quantified final energy consumption in GWh 1 per year ( ) by sector: 2

(a) residential;

(b) services;

(c) industry;

(d) any other sector that individually consumes more than 5 % of total national useful heating and cooling demand;

2. the identification, or, in the case of point (a)(i), the identification or estimation, of current heating and cooling supply:

(a) by  technology,  in  GWh  per  year ( ),  within  the  sectors  referred  to  in  point  1  where  possible,  distinguishing 3 between energy derived from fossil and renewable sources:

(i) provided on-site in residential and service sites by:

-  heat only boilers;

-  high-efficiency heat and power cogeneration;

-  heat pumps;

-  other on-site technologies and sources;

(ii) provided on-site in non-service and non-residential sites by:

-  heat only boilers;

-  high-efficiency heat and power cogeneration;

-  heat pumps;

-  other on-site technologies and sources;

(iii) provided off-site by:

-  high-efficiency heat and power cogeneration;

-  waste heat;

-  other off-site technologies and sources;

(b) the identification of installations that generate waste heat or cold and their potential heating or cooling supply, in GWh per year:

(i) thermal power generation installations that can supply or can be retrofitted to supply waste heat with a total thermal input exceeding 50 MW;

(ii) heat  and  power  cogeneration  installations  using  technologies  referred  to  in  Part  II  of  Annex  II  with  a  total thermal input exceeding 20 MW;

(iii) waste incineration plants;

( 1 ) The amount of thermal energy needed to satisfy the heating and cooling demand of end-users.

( 2 ) The most recent data available should be used.

( 3 ) The most recent data available should be used.

EN

- (iv) renewable  energy  installations  with  a  total  thermal  input  exceeding  20  MW  other  than  the  installations specified under points (i) and (ii) generating heating or cooling using the energy from renewable sources;
- (v) industrial installations with a total thermal input exceeding 20 MW which can provide waste heat;
- (c) reported share of energy from renewable sources and from waste heat or cold in the final energy consumption of the district heating and cooling ( ) sector over the past 5 years, in accordance with Directive (EU) 2018/2001; 4
- 3. aggregated  data  on  cogeneration  units  in  existing  district  heating  and  cooling  networks  in  five  capacity  ranges covering:
- (a) primary energy consumption;
- (b) overall efficiency;
- (c) primary energy savings;
- (d) CO2 emission factors;
- 4. aggregated data on existing district heating and cooling networks supplied from cogeneration in five capacity ranges covering:
- (a) overall primary energy consumption;
- (b) primary energy consumption of cogeneration units;
- (c) share of cogeneration in district heating or cooling supply;
- (d) district heating system losses;
- (e) district cooling system losses;
- (f) connection density;
- (g) shares of systems per different operating temperature groups;
- 5. a map covering the entire national territory, which, while preserving commercially sensitive information, identifies:
- (a) heating  and  cooling  demand  areas  following  from  the  analysis  of  point  1,  while  using  consistent  criteria  for focusing on energy dense areas in municipalities and conurbations;
- (b) existing heating  and  cooling  supply  points  identified under  point  2(b)  and  district heating  transmission installations;
- (c) planned heating and cooling supply points of the type described under point 2(b) and identified new areas for the district heating and cooling;
- 6. a forecast of trends in the demand for heating and cooling to maintain a perspective of the next 30 years in GWh and taking into account, in particular, projections for  the next 10 years, the change in demand in buildings and different sectors  of  the  industry,  and  the  impact  of  policies  and  strategies  related  to  the  demand  management,  such  as  longterm building renovation strategies under Directive (EU) 2018/844 of the European Parliament and of the Council ( ); 5

( 4 ) The identification of 'renewable cooling' shall, after the methodology for calculating the quantity of renewable energy used for cooling and district cooling is established in accordance with Article 35 of Directive (EU) 2018/2001, be carried out in accordance with that Directive. Until then it shall be carried out according to an appropriate national methodology.

( 5 ) Directive  (EU)  2018/844  of  the  European  Parliament  and  of  the  Council  of  30  May  2018  amending  Directive  2010/31/EU  on  the energy performance of buildings and Directive 2012/27/EU on energy efficiency (OJ L 156, 19.6.2018, p. 75).

EN

20.9.2023

## Part II

## OBJECTIVES, STRATEGIES AND POLICY MEASURES

- 7. planned contribution of the Member State to its national objectives, targets and contributions for the five dimensions of the Energy Union, as laid out in Article 3(2), point (b), of Regulation (EU) 2018/1999, delivered through efficiency in heating and cooling, in particular related to Article 4, point (b), points 1 to 4 and to Article 15 (4), point (b) of that Regulation, identifying which of those elements is additional compared to the integrated national energy and climate plan notified pursuant to Article 3 and Articles 7 to 12 of that Regulation;
- 8. a  general  overview  of  the  existing  policies  and  measures  as  described  in  the  most  recent  report  submitted  in accordance with Articles 3, 20 and 21 and Article 27(a) of Regulation (EU) 2018/1999;

## Part III

## ANALYSIS OF THE ECONOMIC POTENTIAL FOR EFFICIENCY IN HEATING AND COOLING

- 9. an analysis of the economic potential ( ) of different technologies for heating and cooling shall be carried out for the 6 entire  national  territory  by  using  the  cost-benefit  analysis  referred  to  in  Article  25(3)  and  shall  identify  alternative scenarios for  more efficient  and renewable heating and cooling technologies, distinguishing between energy derived from fossil and renewable sources where applicable.
- The following technologies should be considered:
- (a) industrial waste heat and cold;
- (b) waste incineration;
- (c) high efficiency cogeneration;
- (d) renewable  energy  sources,  such  as  geothermal,  solar  thermal  and  biomass,  other  than  those  used  for  high efficiency cogeneration;
- (e) heat pumps;
- (f) reducing heat and cold losses from existing district networks;
- (g) district heating and cooling;
- 10. the analysis of economic potential shall include the following steps and considerations:
- (a) Considerations:
- (i) the cost-benefit analysis for  the purposes of Article 25(3) shall include an economic analysis that takes into consideration  socioeconomic  and  environmental  factors ( ),  and  a  financial  analysis  performed  to  assess 7 projects from the investors' point of view, both economic and financial analyses using the net present value as a criterion for the assessment;
- (ii) the baseline scenario should serve as a reference point and take into account existing policies at the time of compiling this comprehensive assessment ( ), and be linked to data collected under Part I and Part II, point 6 8 of this Annex;

( 6 ) The  analysis  of  the  economic  potential  should  present  the  volume  of  energy  (in  GWh)  that  can  be  generated  per  year  by  each technology analysed. The limitations and interrelations within the energy system should also be taken into account. The analysis may make use of models based on assumptions representing the operation of common types of technologies or systems.

( 7 ) Including the assessment referred to in Article 15 (7) of Directive (EU) 2018/2001.

( 8 ) The cut-off date for  taking into account policies for  the baseline scenario is the end of  the year  preceding to the year by the end of which the comprehensive assessment is due. That is to say, policies enacted within a year prior to the deadline for submission of the comprehensive assessment do not need to be taken into account.

EN

- (iii) alternative  scenarios  to  the  baseline  shall  take  into  account  energy  efficiency  and  the  renewable  energy objectives of Regulation (EU) 2018/1999, each scenario presenting the following elements compared to the baseline scenario:
- -  economic potential of technologies examined using the net present value as criterion;
- -  GHG emission reductions;
- -  primary energy savings in GWh per year;
- -  impact on the share of renewables in the national energy mix.

Scenarios  that  are  not  feasible  due  to  technical  reasons,  financial  reasons  or  national  regulation  may  be excluded at  an  early  stage  of  the  cost-benefit  analysis,  if  justified  on  the  basis  of  careful,  explicit  and  welldocumented considerations.

The assessment and decision-making should take into account costs and energy savings from the increased flexibility in energy supply and from a more optimal operation of the electricity networks, including avoided costs and savings from reduced infrastructure investment, in the analysed scenarios.

## (b) Costs and benefits

The costs and benefits referred to in point (a) shall include at least the following costs and benefits:

- (i) costs:
- -  capital costs of plants and equipment;
- -  capital costs of the associated energy networks;
- -  variable and fixed operating costs;
- -  energy costs;
- -  environmental, health and safety costs, to the extent possible;
- -  labour market costs, energy security and competitiveness, to the extent possible.
- (ii) benefits:
- -  value of output to the consumer (heating, cooling and electricity);
- -  external benefits such as environmental, greenhouse gas emissions and health and safety benefits, to the extent possible;
- -  labour market effects, energy security and competitiveness, to the extent possible.
- (c) Relevant scenarios to the baseline:

All  relevant  scenarios  to  the  baseline  shall  be  considered,  including  the  role  of  efficient  individual  heating  and cooling. The cost-benefit analysis may cover either a project assessment or a group of projects for a broader local, regional  or  national  assessment  in  order  to  establish  the  most  cost-effective  and  beneficial  heating  or  cooling solution against a baseline for a given geographical area for the purpose of planning.

- (d) Boundaries and integrated approach:
- (i) the geographical boundary shall cover a suitable, well-defined geographical area;
- (ii) the  cost-benefit  analyses  shall  take  into  account  all  relevant  centralised  or  decentralised  supply  resources available  within  the  system  and  geographical  boundary,  including  technologies  considered  under  Part  III, point 9, of this Annex, and heating and cooling demand trends and characteristics.
- (e) Assumptions:
- (i) Member States shall provide assumptions, for the purpose of the cost-benefit analyses, on the prices of major input and output factors and the discount rate;

<!-- image -->

EN

20.9.2023

- (ii) the  discount  rate used  in  the  economic  analysis  to calculate  net  present  value  shall  be  chosen  according  to European or national guidelines;
- (iii) Member  States  shall use national, European  or international energy  price development  forecasts, if appropriate, in their national, regional or local context;
- (iv) the prices used in the economic analysis shall reflect socio-economic costs and benefits. External costs, such as environmental and health effects, should be included to the extent possible, namely when a market price exists or when it is already included in European or national regulation.
- (f) Sensitivity analysis: a sensitivity analysis shall be included to assess the costs and benefits of a project or group of projects and be based on variable factors having a significant impact on the outcome of the calculations, such as different energy prices, levels of demand, discount rates and other.

## Part IV

## POTENTIAL NEW STRATEGIES AND POLICY MEASURES

- 11. an overview of new legislative and non-legislative policy measures ( ) to realise  the economic potential identified in 9 accordance with points 9 and 10, together with a forecast of:
- (a) greenhouse gas emission reductions;
- (b) primary energy savings in GWh per year;
- (c) impact on the share of high-efficiency cogeneration;
- (d) impact on the share of renewables in the national energy mix and in the heating and cooling sector;
- (e) links to national financial programming and cost savings for the public budget and market participants;
- (f) estimated public support measures, if any, with their annual budget and identification of the potential aid element.

( 9 ) This  overview  shall  include  financing  measures  and  programmes  that  may  be  adopted  over  the  period  of  the  comprehensive assessment, not prejudging a separate notification of the public support schemes for a State aid assessment.

EN

## ANNEX XI

## COST-BENEFIT ANALYSES

Cost-benefit  analyses  shall  provide  information  for  the  purpose  of  the  measures  referred  to  in  Article  25(3)  and Article 26(7):

If an electricity-only installation or an installation without heat recovery is planned, a comparison shall be made between the  planned  installations  or  the  planned  refurbishment  and  an  equivalent  installation  producing  the  same  amount  of electricity  or  process  heat,  but  recovering  the  waste  heat  and  supplying  heat  through  high-efficiency  cogeneration  or district heating and cooling networks, or both.

Within a given geographical boundary the assessment shall take into account the planned installation and any appropriate existing or potential heat or cooling demand points that could be supplied from it, taking into account rational possibilities, for example, technical feasibility and distance.

The system boundary shall be set to include the planned installation and the heat and cooling loads, such as building(s) and industrial process. Within this system boundary the total cost of providing heat and power shall be determined for both cases and compared.

Heat or cooling loads shall include existing heat or cooling loads, such as an industrial installation or an existing district heating  or  cooling  system,  and  also,  in  urban  areas,  the  heat  or  cooling  load  and  costs  that  would  exist  if  a  group  of buildings or part of a city were provided with or connected into a new district heating or cooling network, or both.

Cost-benefit analyses shall be based on a description of the planned installation and the comparison installation(s), covering electrical and thermal capacity, as applicable, fuel type, planned usage and the number of planned operating hours every year, location and electricity and thermal demand.

An assessment of waste heat utilisation shall take into consideration current technologies. The assessment shall take into consideration the direct use of waste heat or its upgrading to higher temperature levels, or both. In the case of waste heat recovery on-site, at least the use of heat exchangers, heat pumps, and heat to power technologies shall be assessed. In the case of waste heat recovery off-site, at least industrial installations, agriculture sites and district heating networks shall be assessed as potential demand points.

For the purpose of the comparison, the thermal energy demand and the types of heating and cooling used by the nearby heat or cooling demand points shall be taken into account. The comparison shall cover infrastructure related costs for the planned and comparison installation.

Cost-benefit  analyses  for  the  purposes  of  Article  26(7)  shall  include  an  economic  analysis  covering  a  financial  analysis reflecting actual cash flow transactions from investing in and operating individual installations.

Projects with positive cost-benefit outcome are those where the sum of discounted benefits in the economic and financial analysis exceeds the sum of discounted costs (cost-benefit surplus).

Member States shall set guiding principles for the methodology, assumptions and time horizon for the economic analysis.

Member States may require that the companies responsible for  the operation of  thermal electric generation installations, industrial  companies, district  heating and cooling networks, or other  parties influenced by the defined  system boundary and geographical boundary, contribute data for use in assessing the costs and benefits of an individual installation.

EN

20.9.2023

## ANNEX XII

## GUARANTEE OF ORIGIN FOR ELECTRICITY PRODUCED FROM HIGH-EFFICIENCY COGENERATION

- (1) Member States shall take measures to ensure that:
- (a) the guarantee of origin of the electricity produced from high-efficiency cogeneration:
- -  enables producers to demonstrate that the electricity they sell is produced from high-efficiency cogeneration and is issued to that effect in response to a request from the producer;
- -  is accurate, reliable and fraud-resistant;
- -  is issued, transferred and cancelled electronically;
- (b) the same unit of energy from high-efficiency cogeneration is taken into account only once.
- (2) The guarantee of origin referred to in Article 26(13) shall contain at least the following information:
- (a) the identity, location, type and capacity (thermal and electrical) of the installation where the energy was produced;
- (b) the dates and places of production;
- (c) the lower calorific value of the fuel source from which the electricity was produced;
- (d) the quantity and the use of the heat generated together with the electricity;
- (e) the  quantity  of  electricity  from  high-efficiency  cogeneration  in  accordance  with  Annex  III  that  the  guarantee  of origin represents;
- (f) the  primary  energy  savings  calculated  in  accordance  with  Annex  III  on  the  basis  of  the  harmonised  efficiency reference values indicated in Annex III, point (d);
- (g) the nominal electric and thermal efficiency of the plant;
- (h) whether and to what extent the installation has benefited from investment support;
- (i) whether and to what extent the unit of energy has benefited in any other way from a national support scheme, and the type of support scheme;
- (j) the date on which the installation became operational; and
- (k) the date and country of issue and a unique identification number.

The guarantee of origin shall be of the standard size of 1 MWh. It shall relate to the net electricity output measured at the station boundary and exported to the grid.

EN

L  231/100

## ANNEX XIII

ENERGY EFFICIENCY CRITERIA FOR ENERGY NETWORK REGULATION AND FOR ELECTRICITY NETWORK TARIFFS

- 1. Network  tariffs  shall  be  transparent  and  non-discriminatory,  and  shall  comply  with  Article  18  of  Regulation (EU) 2019/943 and be cost-reflective of cost-savings in networks achieved from demand-side and demand- response measures and distributed generation, including savings from lowering the cost of delivery or of network investment and a more optimal operation of the network.
- 2. Network regulation and tariffs shall not prevent network operators or energy retailers making available system services for  demand  response  measures,  demand  management  and  distributed  generation  on  organised  electricity  markets, including  over-the-counter  markets  and  electricity  exchanges  for  trading  energy,  capacity,  balancing  and  ancillary services in all timeframes, including forward, day-ahead and intra-day markets, in particular:
- (a) the  shifting  of  the  load  from  peak  to  off-peak  times  by  final  customers  taking  into  account  the  availability  of renewable energy, energy from cogeneration and distributed generation;
- (b) energy savings from demand response of distributed consumers by independent aggregators;
- (c) demand reduction from energy efficiency measures undertaken by energy service providers, including ESCOs;
- (d) the connection and dispatch of generation sources at lower voltage levels;
- (e) the connection of generation sources from closer location to the consumption; and
- (f) the storage of energy.
- 3. Network or retail tariffs may support dynamic pricing for demand response measures by final customers, such as:
- (a) time-of-use tariffs;
- (b) critical peak pricing;
- (c) real time pricing; and
- (d) peak time rebates.

EN

20.9.2023

## ANNEX XIV

ENERGY EFFICIENCY REQUIREMENTS FOR TRANSMISSION SYSTEM OPERATORS AND DISTRIBUTION SYSTEM OPERATORS

Transmission system operators and distribution system operators shall:

- (a) set up and make public their standard rules relating to the bearing and sharing of costs of technical adaptations, such as grid connections, grid reinforcements and the introduction of new grids, improved operation of the grid and rules on the  non-discriminatory  implementation  of  the  grid  codes,  which  are  necessary  in  order  to  integrate  new  producers feeding electricity produced from high-efficiency cogeneration into the interconnected grid;
- (b) provide any new producer of electricity produced from high-efficiency cogeneration wishing to be connected to the system with the comprehensive and necessary information required, including:
- (i) a comprehensive and detailed estimate of the costs associated with the connection;
- (ii) a reasonable and precise timetable for receiving and processing the request for grid connection;
- (iii) a reasonable indicative timetable for any proposed grid connection. The overall process to become connected to the  grid  should  be  no  longer  than  24  months,  bearing  in  mind  what  is  reasonably  practicable  and  nondiscriminatory;
- (c) provide  standardised  and  simplified  procedures  for the connection  of  distributed  high-efficiency  cogeneration producers to facilitate their connection to the grid.

The  standard  rules  referred  to  in  point  (a)  of  the  first  paragraph  shall  be  based  on  objective,  transparent  and  nondiscriminatory  criteria  taking  particular  account  of  all  the  costs  and  benefits  associated  with  the  connection  of  those producers to the grid. They may provide for different types of connection.

EN

## ANNEX XV

MINIMUM ITEMS TO BE INCLUDED IN ENERGY PERFORMANCE CONTRACTS OR IN THE ASSOCIATED TENDER SPECIFICATIONS

- -  Findings and recommendations set out in analyses and energy audits carried out before the contract has been concluded that cover energy use of the building with a view to implementing energy efficiency improvement measures.
- -  A clear and transparent list of the efficiency measures to be implemented or the efficiency results to be obtained.
- -  Guaranteed savings to be achieved by implementing the measures of the contract.
- -  The duration and milestones of the contract, terms and period of notice.
- -  A clear and transparent list of the obligations of each contracting party.
- -  Reference date(s) to establish achieved savings.
- -  A  clear  and  transparent  list  of  steps  to  be  performed  to  implement  a  measure  or  package  of  measures  and,  where relevant, associated costs.
- -  An  obligation  to  fully  implement  the  measures  in  the  contract  and  documentation  of  all  changes  made  during  the project.
- -  Regulations specifying the inclusion of equivalent requirements in any subcontracting with third parties.
- -  A clear and transparent display of  the  financial  implications  of  the  project  and  the  distribution  of  the  share  of  both parties in the monetary savings achieved, namely the remuneration of the service provider.
- -  A clear and transparent provisions on measurement and verification of the guaranteed savings achieved, quality checks and guarantees.
- -  Provisions  clarifying  the  procedure  to  deal  with  changing  framework  conditions  that  affect  the  content  and  the outcome of the contract, namely changing energy prices and the use intensity of an installation.
- -  Detailed information on the obligations of each contracting party and of the penalties for their breach.

<!-- image -->

## ANNEX XVI

## Part A

Repealed Directive with list of the successive amendments thereto (referred to in Article 39)

Directive 2012/27/EU of the European Parliament and of the Council (OJ L 315, 14.11.2012, p. 1)

Council Directive 2013/12/EU (OJ L 141, 28.5.2013, p. 28)

Directive (EU) 2018/844 of the European Parliament and of the Council (OJ L 156, 19.6.2018, p. 75)

only Article 2

Directive (EU) 2018/2002 of the European Parliament and of the Council (OJ L 328, 21.12.2018, p. 210)

Regulation (EU) 2018/1999 of the European Parliament and of the Council (OJ L 328, 21.12.2018, p. 1)

only Article 54

Decision (EU) 2019/504 of the European Parliament and of the Council (OJ L 85I, 27.3.2019, p. 66)

only Article 1

Commission Delegated Regulation (EU) 2019/826 (OJ L 137, 23.5.2019, p. 3)

Directive (EU) 2019/944 of the European Parliament and of the Council (OJ L 158, 14.6.2019, p. 125)

only Article 70

## Part B

Time-limits for transposition into national law (referred to in Article 39)

| Directive      | Time-limit for transposition                                                                                                                                                           |
|----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2012/27/EU     | 5 June 2014                                                                                                                                                                            |
| (EU) 2018/844  | 10 March 2020                                                                                                                                                                          |
| (EU) 2018/2002 | 25 June 2020, with the exception of points 5 to 10 of Article 1 and points 3 and 4 of the Annex 25 October 2020 as regards points 5 to 10 of Article 1 and points 3 and 4 of the Annex |
| (EU) 2019/944  | 31 December 2019 as regards point (5)(a) of Article 70 25 October 2020 as regards point (4) of Article 70 31 December 2020 as regards points (1) to (3), (5)(b) and (6) of Article 70  |

<!-- image -->

## ANNEX XVII

## Correlation Table

| Directive 2012/27/EU            | This Directive                  |
|---------------------------------|---------------------------------|
| Article 1                       | Article 1                       |
| Article 2, introductory wording | Article 2, introductory wording |
| Article 2, point 1              | Article 2, point 1              |
| -                               | Article 2, points 2, 3 and 4    |
| Article 2, point 2              | Article 2, point 5              |
| Article 2, point 3              | Article 2, point 6              |
| -                               | Article 2, point 7              |
| Article 2, point 4              | Article 2, point 8              |
| Article 2, point 5              | Article 2, point 9              |
| Article 2, point 6              | Article 2, point 10             |
| Article 2, point 7              | Article 2, point 11             |
| Article 2, point 8              | Article 2, point 12             |
| Article 2, point 9              | -                               |
| Article 2, point 10             | Article 2, point 13             |
| _                               | Article 2, points 14 and 15     |
| Article 2, point 11             | Article 2, point 16             |
| Article 2, point 12             | Article 2, point 17             |
| Article 2, point 13             | Article 2, point 18             |
| Article 2, point 14             | Article 2, point 19             |
| Article 2, point 15             | Article 2, point 20             |
| Article 2, point 16             | Article 2, point 21             |
| Article 2, point 17             | Article 2, point 22             |
| Article 2, point 18             | Article 2, point 23             |
| Article 2, point 19             | Article 2, point 24             |
| Article 2, point 20             | Article 2, point 25             |
| Article 2, point 21             | Article 2, point 26             |
| Article 2, point 22             | Article 2, point 27             |
| Article 2, point 23             | Article 2, point 28             |
| Article 2, point 24             | Article 2, point 29             |
| -                               | Article 2, point 30             |
| -                               | Article 2, point 31             |
| Article 2, point 25             | Article 2, point 32             |
| Article 2, point 26             | -                               |
| Article 2, point 27             | Article 2, point 33             |
| Article 2, point 28             | Article 2, point 34             |
| Article 2, point 29             | Article 2, point 35             |

<!-- image -->

| Directive 2012/27/EU                                    | This Directive                                                     |
|---------------------------------------------------------|--------------------------------------------------------------------|
| Article 2, point 30                                     | Article 2, point 36                                                |
| Article 2, point 31                                     | Article 2, point 37                                                |
| Article 2, point 32                                     | Article 2, point 38                                                |
| Article 2, point 33                                     | Article 2, point 39                                                |
| Article 2, point 34                                     | Article 2, point 40                                                |
| Article 2, point 35                                     | Article 2, point 41                                                |
| Article 2, point 36                                     | Article 2, point 42                                                |
| Article 2, point 37                                     | Article 2, point 43                                                |
| Article 2, point 38                                     | Article 2, point 44                                                |
| Article 2, point 39                                     | Article 2, point 45                                                |
| Article 2, point 40                                     | -                                                                  |
| Article 2, point 41                                     | Article 2, point 46                                                |
| Article 2, point 42                                     | Article 2, point 47                                                |
| Article 2, point 43                                     | Article 2, point 48                                                |
| -                                                       | Article 2, point 49                                                |
| Article 2, point 44                                     | Article 2, point 50                                                |
| Article 2, point 45                                     | Article 2, point 51                                                |
| -                                                       | Article 2, points 52, 53,54, 55 and 56                             |
| -                                                       | Article 3                                                          |
| -                                                       | Article 4(1)                                                       |
| Article 3(1), first subparagraph                        | Article 4(2), first subparagraph Article 4(2), second subparagraph |
| Article 3(1), second subparagraph, introductory wording | Article 4(3), first subparagraph, introductory wording             |
| Article 3(1), second subparagraph, points (a) and (b)   | Article 4(3), first subparagraph, points (a) and (b)               |
| Article 3(1), second subparagraph, point (c)            | -                                                                  |
| Article 3(1), second subparagraph, point (d)            | Article 4(3), first subparagraph, point (c)                        |
| Article 3(1), third subparagraph, introductory wording  | -                                                                  |
| -                                                       | Article 4(3), first subparagraph, point (d), introductory wording  |
| -                                                       | Article 4(3), first subparagraph, points (d)(i), (ii) and (iii)    |
| Article 3(1), third subparagraph, point (a)             | Article 4(3), first subparagraph, point (d)(iv)                    |
| -                                                       | Article 4(3), first subparagraph, point (e), introductory wording  |
| Article 3(1), third subparagraph, point (b)             | Article 4(3), first subparagraph, point (e)(i)                     |

<!-- image -->

| Directive 2012/27/EU                                                                                                                                                    | This Directive                                                       |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------|
| Article 3(1), third subparagraph, point (c) Article 3(1), third subparagraph, point (d) Article 3(1), third subparagraph, point (e) - Article 3(2) and (3) Article 3(4) | Article 4(3), first subparagraph, point (e)(ii)                      |
|                                                                                                                                                                         | Article 4(3), first subparagraph, point (e)(iii)                     |
|                                                                                                                                                                         | -                                                                    |
|                                                                                                                                                                         | Article 4(3), first subparagraph, point (e)(iv)                      |
|                                                                                                                                                                         | -                                                                    |
|                                                                                                                                                                         | Article 35(6)                                                        |
| Article 3(5) and (6)                                                                                                                                                    | -                                                                    |
| -                                                                                                                                                                       | Article 4(4)                                                         |
| -                                                                                                                                                                       | Article 4(5)                                                         |
| -                                                                                                                                                                       | Article 4(7) Article 5                                               |
|                                                                                                                                                                         | Article 6(1), first subparagraph                                     |
| Article 5(1), first subparagraph                                                                                                                                        |                                                                      |
| Article 5(1), second subparagraph                                                                                                                                       | Article 6(1), fifth subparagraph                                     |
| -                                                                                                                                                                       | Article 6(1), second and third subparagraph                          |
| Article 5(1), third subparagraph                                                                                                                                        | Article 6(1), fourth subparagraph                                    |
| Article 5(1), fourth and fifth subparagraph                                                                                                                             | -                                                                    |
| Article 5(2) -                                                                                                                                                          | Article 6(2) Article 6(2), second subparagraph                       |
| Article 5(3)                                                                                                                                                            | Article 6(3)                                                         |
| Article 5(4)                                                                                                                                                            | Article 6(4)                                                         |
| Article 5(5)                                                                                                                                                            | Article 6(5)                                                         |
| Article 5(5), first subparagraph, point (b)                                                                                                                             | Article 6(5), second subparagraph, point (c)                         |
| -                                                                                                                                                                       | Article 6(5), second subparagraph, point (b)                         |
| Article 5(6)                                                                                                                                                            | Article 6(6)                                                         |
| -                                                                                                                                                                       | Article 6(6), second subparagraph, point                             |
| Article 5(6), second subparagraph                                                                                                                                       | Article 6(6), second subparagraph, point (b)                         |
| Article 5(6), third subparagraph                                                                                                                                        | Article 6(6), third subparagraph                                     |
| Article 5(7)                                                                                                                                                            | -                                                                    |
| Article 6(1), first subparagraph                                                                                                                                        | Article 7(1), first subparagraph                                     |
| Article 6(1), second subparagraph                                                                                                                                       | Article 7(1), first subparagraph Article 7(1), second subparagraph - |
| Article 6(2), (3) and (4)                                                                                                                                               | Article 7(2), (3) and (4)                                            |
| -                                                                                                                                                                       | Article 7(5), (6), (7) and (8)                                       |
| - Article 7(1), introductory wording, point (a) and (b)                                                                                                                 | Article 8(1), introductory wording, point (a) and (b)                |

EN

| Directive 2012/27/EU              | This Directive                    |
|-----------------------------------|-----------------------------------|
| -                                 | Article 8(1), point (c)           |
| Article 7(1), second subparagraph | Article 8(5)                      |
| Article 7(1), third subparagraph  | Article 8(1), fifth subparagraph  |
| Article 7(1), fourth subparagraph | Article 8(1), fourth subparagraph |
| -                                 | Article 8 (3) and (4)             |
| Article 7(2)                      | Article 8(6)                      |
| Article 7(3)                      | Article 8(7)                      |
| Article 7(4)                      | Article 8(8)                      |
| Article 7(5)                      | Article 8(9)                      |
| Article 7(6)                      | Article 8(10)                     |
| Article 7(7)                      | -                                 |
| Article 7(8)                      | -                                 |
| Article 7(9)                      | -                                 |
| Article 7(10)                     | Article 8(2)                      |
| Article 7(11)                     | -                                 |
|                                   | Article 8(11), (12) and (13)      |
| Article 7a                        | 9(1)                              |
| (1)                               | Article                           |
| Article 7a(2)                     | Article 9(3)                      |
| Article 7a(3)                     | Article 9(4)                      |
|                                   | Article 9(5), (6)                 |
| -                                 | and (7)                           |
| -                                 | Article 9(10)                     |
| Article 7b (1) and (2)            | Article 10(1) and (2)             |
| -                                 | Article 10(3) and (4)             |
| -                                 | Article 11(1) and (2)             |
| -                                 | Article 11(3) and (4)             |
| Article 8(1) and (2)              | Article 11(5), (6) and (7)        |
| Article 8(3) and (4)              | -                                 |
| -                                 | Article 11(8)                     |
| Article 8(5)                      | Article 11(9)                     |
| -                                 | Article 11(10)                    |
| Article 8(6)                      | Artice 11(11)                     |
| Article 8(7)                      | Article 11(12)                    |

<!-- image -->

| Directive 2012/27/EU                                                 | This Directive                                                                                      |
|----------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|
| Article 9                                                            | Article 13                                                                                          |
| Article 9a                                                           | Article 14                                                                                          |
| Article 9b                                                           | Article 15                                                                                          |
| Article 9c                                                           | Article 16                                                                                          |
| Article 10                                                           | Article 17                                                                                          |
| Article 10a                                                          | Article 18                                                                                          |
| Article 11                                                           | Article 19                                                                                          |
| Article 12                                                           | Article 20                                                                                          |
| -                                                                    | Article 21                                                                                          |
| -                                                                    | Article 22(1)                                                                                       |
| Article 12(1)                                                        | Article 22(2)                                                                                       |
| Article 12(2), introductory wording and point (a), points (i) to (v) | Article 22(2), second subparagraph, points (a) to (g) Article 22(2), second subparagraph, point (h) |
| Article 12(2), point (b)                                             | Article 22(3), third subparagraph                                                                   |
| -                                                                    | Article 22(3), third subparagraph, points (a) and (b)                                               |
| Article 12(2), point (b), points (i) and (ii)                        | Article 22(3), third subparagraph, points (c) and (d)                                               |
| -                                                                    | Article 22(3), third subparagraph, point (e)                                                        |
| -                                                                    | Article 22 (4) to (9)                                                                               |
| -                                                                    | Article 23                                                                                          |
| -                                                                    | Article 24                                                                                          |
| Article 13                                                           | Article 32                                                                                          |
| Article 14(1)                                                        | Article 25(1)                                                                                       |
| -                                                                    | Article 25(2)                                                                                       |
| Article 14(2)                                                        | Article 25(5)                                                                                       |
| Article 14(3)                                                        | Article 25(3), first subparagraph                                                                   |
| -                                                                    | Article 25(3), second subparagraph                                                                  |
| Article 14(4)                                                        | Article 25(4)                                                                                       |
| -                                                                    | Article 25(6)                                                                                       |
| -                                                                    | Article 26(1), (2), (3), (4), (5) and                                                               |
| Article 14(5), introductory wording and point (a)                    | Article 26(7), introductory wording and point (a)                                                   |
| Article 14(5), points (b), (c) and (d)                               | -                                                                                                   |
| -                                                                    | Article 26(7), points (b), (c) and (d) and second subparagraph                                      |
| Article 14(5), second and third subparagraphs                        | Article 26(7), third and fourth subparagraphs                                                       |
| Article 14(6), point (a)                                             | Article 26(8), point (a)                                                                            |

<!-- image -->

| Directive 2012/27/EU                           | This Directive                                |
|------------------------------------------------|-----------------------------------------------|
| Article 14(6), point (b)                       | -                                             |
| Article 14(6), point (c)                       | Article 26(8), point (b)                      |
| -                                              | Article 26(8), point (c)                      |
| Article 14(6), second and third subparagraphs  | Article 26(8), second and third subparagraphs |
| Article 14(7), (8) and (9)                     | Article 26(9), (10) and (11)                  |
| -                                              | Article 26(12)                                |
| Article 14(10) and (11)                        | Article 26(13) and (14)                       |
| Article 15(1), first subparagraph              | Article 27(1)                                 |
| Article 15(1), second and third subparagraphs  | -                                             |
| -                                              | Article 27(2), (3) and (4)                    |
| Article 15(1), fourth subparagraph             | Article 27(5)                                 |
| Article 15(2) and (2a)                         | -                                             |
| Article 15(3), (4) and (5), first subparagraph | Article 27(6), (7) and (8)                    |
| Article 15(5), second suparagraph              | -                                             |
| Article 15(6), first subparagraph              | -                                             |
| Article 15(6), second subparagraph             | Article 27(9)                                 |
| Article 15(7)                                  | Article 27(10)                                |
| Article 15(9), first subparagraph              | Article 27(11)                                |
| Article 15(9), second subparagraph             | -                                             |
| Article 16(1) and (2)                          | -                                             |
| -                                              | Article 28(1), (2), (3)and (5)                |
| Article 16(3)                                  | Article 28(4)                                 |
| Article 17(1), first subparagraph              | -                                             |
| Article 17(1), second subparagraph             | Article 30(3)                                 |
| Article 17(2)                                  | Article 22(7)                                 |
| Article 17(3)                                  | -                                             |
| Article 17(4)                                  | -                                             |
| Article 17(5)                                  | Article 22(10)                                |
| Article 18(1), introductory wording            | Article 29(1), introductory wording           |
| Article 18(1), point (a), points (i) and (ii)  | Article 29(1), points (a) and (b)             |
| -                                              | Article 29(1), points (c) and                 |
| Article 18(1), point (b)                       | Article 29(2)                                 |
| Article 18(1), point (c)                       | Article 29(3)                                 |
| -                                              | Article 29(4)                                 |
| Article 18(1), point (d), points (i) and (ii)  | Article 29(5), points (a) and (b)             |

EN

| Directive 2012/27/EU                 | This Directive                                           |
|--------------------------------------|----------------------------------------------------------|
| -                                    | Article 29(5), point (c)                                 |
| Article 18(2), points (a) and (b)    | Article 29(6), points (a) and (b)                        |
| Article 18(2), point (c) and (d)     | -                                                        |
| -                                    | Article 29(6), point (c)                                 |
| -                                    | Article 29(7)                                            |
| Article 18(3)                        | Article 29(8)                                            |
| Article 19(1), point (a)             | Article 22(5), first subparagraph                        |
| Article 19(1), point (b)             | Article 7(7), first subparagraph                         |
| Article 19(1), second subparagraph   | Article 22(9), second subparagraph                       |
| Article 19(2)                        | -                                                        |
| Article 20(1) and (2)                | Article 30(1) and (2)                                    |
| -                                    | Article 30(3), (4), (5),                                 |
| Article 20(3), (3a), (3b) and (3c)   | Article 30(6), (7), (8) and (9)                          |
| Article 20(3d)                       | Article 30(10), first subparagraph                       |
| -                                    | Article 30(10), second subparagraph                      |
| Article 20(4), (5), (6) and (7)      | Article 30(11), (13), (14) and (15)                      |
| -                                    | Article 30(12)                                           |
| -                                    | Article 30(16)                                           |
| -                                    | Article 30(17) and (18)                                  |
| Article 21                           | Article 31(1)                                            |
| Annex IV, footnote 3                 | Article 31(2), (3) and (4)                               |
| -                                    | Article 31(5)                                            |
| Annex IV, footnote 3                 | Article 31(6) and (7)                                    |
| Article 22(1) and (2)                | Article 33(1) and (2)                                    |
| -                                    | Article 33(3)                                            |
| Article 23                           | Article 34                                               |
| Article 24(4a), (5) and (6)          | Article 35(1), (2) and (3)                               |
| Article 24(7), (8), (9), (10), (12)  | -                                                        |
| Article 24(13) and (14)              | Article 35(4) and (5)                                    |
| Article 24(15), introductory wording | Article 35(7), introductory wording                      |
| Article 24(15), point (a)            | -                                                        |
| Article 24(15), point (b)            | Article 35(7), point (a)                                 |
| -                                    | Article 35(7), point (b), (c), (d), (e),(f), (g) and (h) |
| -                                    | Article 35(7), second subparagraph                       |
| Article 24(8)                        | Article 35(7), third subparagraph                        |
| Article 25                           | -                                                        |
| Article 26                           | -                                                        |

<!-- image -->

| Directive 2012/27/EU                          | This Directive                    |
|-----------------------------------------------|-----------------------------------|
| Article 28                                    | Article 36                        |
| -                                             | Article 37                        |
| Article 27, first paragraph                   | Article 38, first paragraph       |
| Article 27, second paragraph                  | -                                 |
| Article 27, third paragraph                   | Article 38, second paragraph      |
| Article 28(1), first subparagraph             | Article 36(1), first subparagraph |
| Article 28(1), second subparagraph            | -                                 |
| Article 28(1), third and fourth subparagraphs | Article 36(1), secondsubparagraph |
| Article 28(2)                                 | Article 36(2)                     |
| Article 29                                    | Article 39                        |
| -                                             | Article 39, second paragraph      |
| -                                             | Article 39, third paragraph       |
| Article 30                                    | Article 40                        |
| -                                             | Annex I                           |
| Annex I                                       | Annex II                          |
| Annex II                                      | Annex III                         |
| Annex III                                     | Annex IV                          |
| Annex IV                                      | -                                 |
| Annex V                                       | Annex V                           |
| Annex VI                                      | Annex VI                          |
| Annex VII                                     | Annex VIII                        |
| Annex VIIa                                    | Annex IX                          |
| Annex VIII                                    | Annex X                           |
| Annex IX                                      | Annex XI                          |
| Annex X                                       | Annex XII                         |
| Annex XI                                      | Annex XIII                        |
| Annex XII                                     | Annex XIV                         |
| Annex XIII                                    | Annex XV                          |
| Annex XV                                      | -                                 |
| -                                             | Annex XVI                         |
| -                                             | Annex XVII                        |