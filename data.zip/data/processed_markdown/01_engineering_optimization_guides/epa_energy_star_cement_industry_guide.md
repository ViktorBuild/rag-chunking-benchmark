---
document_id: epa_cement_guide
title: "Energy Efficiency Improvement and Cost Saving Opportunities for Cement Making"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "EPA ENERGY STAR / LBNL"
year: 2013
original_file: "epa_energy_star_cement_industry_guide.pdf"
tables_detected: 87
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Energy Efficiency Improvement and Cost Saving Opportunities for Cement Making

## An ENERGY STAR® Guide for Energy and Plant Managers

August 2013

<!-- image -->

## Energy Efficiency Improvement and Cost Saving Opportunities for Cement Making

An ENERGY STAR® Guide for Energy and Plant Managers

Ernst Worrell, Utrecht University

Katerina Kermeli, Utrecht University

Christina Galitsky, Lawrence Berkeley National Laboratory

August 2013

## Disclaimer

This  document  was  prepared  for  the  United  States  Government.  While  this  document  is believed to contain correct information, neither the United States Government nor any agency thereof, nor any persons or organizations involved in its development, makes any warranty, express or implied,  or  assumes  any  legal  responsibility  for  the  accuracy,  completeness,  or usefulness of any information, apparatus, product, or process disclosed, or represents that its use would not infringe on privately owned rights. Reference herein to any specific commercial product, process, or service by its trade name, trademark, manufacturer, or otherwise, does not  necessarily  constitute  or  imply  its  endorsement,  recommendation,  or  favoring  by  the United States Government or any agency thereof, or any persons or organizations involved in its development. The views and opinions of authors expressed herein do not necessarily state or reflect those of the United States Government or any agency thereof.

## Acknowledgment

This work was funded by the U.S. Environmental Protection Agency.  The original version of this report was published in March 2008.  The limited update embodied in this version was begun under the U.S. Department of Energy Contract No. DE-AC02-05CH11231, and was completed under the U.S. Environmental Protection Contract No. EP-BPA-12-H-0012.

## ABSTRACT

The cost of energy as part of the total production costs in the cement industry is significant, typically  at  20  to  40%  of  operational  costs,  warranting  attention  for  energy  efficiency  to improve the bottom line. Historically, energy intensity has declined, although more recently energy intensity seems to have stabilized with the gains. Coal and coke are currently the primary  fuels  for  the  sector,  supplanting  the  dominance  of  natural  gas  in  the  1970s.  A variety  of  waste  fuels,  including  tires,  steadily  increase  their  share  in  fuel  use.  Between 1970 and 2010, primary physical energy intensity for cement production dropped 1.2% per year  from  7.3  MBtu/short  ton  to  4.5  MBtu/short  ton.  Carbon  dioxide  intensity  due  to  fuel consumption and raw material calcination dropped 24%, from 610 lb C/ton of cement (0.31 tC/tonne) to 469 lb C/ton cement (0.23 tC/tonne).

Despite the historic progress, there is ample room for energy efficiency improvement. The share of wet-process plants decreased from 60% in 1970 to about 7% of clinker production in 2010 in the U.S. The remaining plants suggest the existence of a considerable potential, when  compared  to  other  industrialized  countries.  We  examined  over  50  energy-efficient technologies  and  measures  and  estimated  energy  savings,  carbon  dioxide  emission savings, investment costs, and operation and maintenance costs for each of the measures. The report describes the measures and experiences of cement plants around the world with these practices and technologies.

Substantial potential for energy efficiency improvement exists in the cement industry and in individual plants. A portion of this potential will be achieved as part of (natural) modernization and expansion of existing facilities, as well as construction of new plants in particular  regions.  Still,  a  relatively  large  potential  for  improved  energy  management practices exists.

## Table of Contents

| 1. Introduction ..................................................................................................................           | 1                                                                                                         |
|----------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|
| 2. The U.S. Cement Industry............................................................................................                      | 2                                                                                                         |
| 3. Process Description .....................................................................................................                 | 5                                                                                                         |
| 3.1 Mining and Quarrying ...................................................................................................                 | 5                                                                                                         |
| 3.2 Kiln Feed Preparation...................................................................................................                 | 6                                                                                                         |
| 3.3 Clinker Production (Pyro-Processing)...........................................................................                          | 7                                                                                                         |
| 3.4 Finish Grinding..............................................................................................................            | 9                                                                                                         |
| 4. Energy Use and Carbon Dioxide Emissions in the U.S. Cement Industry.................                                                      | 10                                                                                                        |
| 4.1 Historical Energy Use and Carbon Dioxide Emission Trends.....................................                                            | 10                                                                                                        |
| 4.2 Historical Energy Intensity and Specific Carbon Dioxide Emission Trends................                                                  | 13                                                                                                        |
| 5. 2009 Baseline Energy Use and Carbon Dioxide Emissions ......................................                                              | 16                                                                                                        |
| 5.1 Raw Materials.............................................................................................................               | 17                                                                                                        |
| 5.2 Clinker Production                                                                                                                       | ...................................................................................................... 18 |
| 5.3 Finish Grinding............................................................................................................              | 18                                                                                                        |
| 5.4 Carbon Dioxide Emissions..........................................................................................                       | 18                                                                                                        |
| 6. Energy Efficiency Technologies and Measures for the U.S. Cement Industry........... 6.1 Energy Management Systems and                     | 19 Programs............................................................ 21                                |
| 6.2 Raw Materials Preparation .........................................................................................                      | 27                                                                                                        |
| 6.3 Fuel Preparation                                                                                                                         | 31                                                                                                        |
| ......................................................................................................... 6.4 Clinker production - All Kilns | ...................................................................................... 32                 |
| 6.5 Clinker Production - Wet Process Kilns .....................................................................                             | 40                                                                                                        |
| 6.6 Clinker Production - Dry Process Kilns ......................................................................                            | 42                                                                                                        |
| 6.7 Finish Grinding............................................................................................................              | 46                                                                                                        |
| 6.8 Plant-Wide Measures                                                                                                                      | ................................................................................................. 51      |
| 6.9 Product Changes........................................................................................................                  | 72                                                                                                        |
| 6.10 Feedstock Changes..................................................................................................                     | 76                                                                                                        |
| 6.11 Alternative Fuels.......................................................................................................                | 80                                                                                                        |
| 6.12 Advanced Technologies                                                                                                                   | ........................................................................................... 82            |
| 7. Summary and Conclusions ........................................................................................                          | 85                                                                                                        |
| 8. Glossary......................................................................................................................            | 91                                                                                                        |
| 9. References..................................................................................................................              | 95                                                                                                        |
| Personnel................................                                                                                                    |                                                                                                           |
| Appendix A: Basic Energy Efficiency Actions for Plant                                                                                        | 115                                                                                                       |
| Appendix B: ENERGY STAR Energy Management Assessment Matrixes ..................                                                             | 116                                                                                                       |
| Appendix C: Teaming Up to Save Energy Checklist.....................................................                                         | 122 125                                                                                                   |

## Tables

| Table 1. Heat requirements for dry kilns with different number of preheater stages..............                                                                                                                        | 8   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Table 2. 2009 Energy consumption and Specific Energy Consumption (SEC) in the U.S. cement plants by process..............................................................................................               | 17  |
| Table 3. Energy-efficient practices and technologies in cement production ........................                                                                                                                      | 20  |
| Table 4. Classification of control systems and typical energy efficiency improvement potentials ....................................................................................................................... | 26  |
| Table 5. Specific energy consumption of HPGR circuits in a variety of configurations........                                                                                                                            | 49  |
| Table 6. Performance comparison of lighting sources.........................................................                                                                                                            | 68  |
| Table 7. Energy savings and CO2 emission savings by using different decarbonated kiln feedstock ....................................................................................................................... | 78  |
| Table 8. Energy efficiency measures in dry process cement plants ....................................                                                                                                                   | 87  |
| Table 9. Energy efficiency measures in wet process cement plants....................................                                                                                                                    | 89  |
| Figures                                                                                                                                                                                                                 |     |
| Figure 1. U.S. clinker production by process, 1970 to 2010. ................................................                                                                                                            | 4   |
| Figure 2. U.S. cement and clinker production, 1970 to 2010................................................                                                                                                              | 4   |
| Figure 3. Simplified process schematic for cement making..................................................                                                                                                              | 6   |
| Figure 4. Primary energy consumption in U.S. cement production by process, 1970 to 2010                                                                                                                                 |     |
| .......................................................................................................................................                                                                                 | 12  |
| Figure 5. Final energy consumption in U.S. cement production by fuel, 1970 to 2010........                                                                                                                              | 12  |
| Figure 6. Primary energy intensity of U.S. cement and clinker production, 1970 to 2010 ...                                                                                                                              | 13  |
| Figure 7. Specific fuel and electricity consumption per ton of cement produced .................                                                                                                                        | 14  |
| Figure 8. Carbon intensity of U.S. cement and clinker production, 1970 to 2010................                                                                                                                          | 15  |
| Figure 9. Main elements of a strategic energy management program.................................                                                                                                                       | 23  |
| Figure 10. Lighting placement and controls. ........................................................................                                                                                                    | 69  |

## 1.  Introduction

As U.S. manufacturers face an increasingly competitive global business environment, they seek opportunities to reduce production costs without negatively affecting product yield or quality. Uncertain  energy  prices  in  today's  marketplace  negatively  affect  predictable earnings. For public and private companies alike, increasing energy prices are driving up costs and decreasing their value added. Successful, cost-effective investment into energy efficiency technologies and practices meet the challenge of maintaining the output of a high quality  product  despite reduced production costs. This is especially important, as energyefficient technologies often include 'additional' benefits, such as increasing the productivity of the company.

Energy efficiency is an important component of a company's environmental strategy. Endof-pipe  solutions  can  be  expensive  and  inefficient  while  energy  efficiency  can  be  an inexpensive opportunity to reduce criteria and other pollutant emissions. Energy efficiency can be an effective strategy to work towards the so-called 'triple bottom line' that focuses on  the  social,  economic,  and  environmental  aspects  of  a  business. 1   In  short,  energy efficiency investment is sound business strategy in today's manufacturing environment.

Voluntary government programs aim to assist industry to improve competitiveness through increased  energy  efficiency  and  reduced  environmental  impact.  ENERGY  STAR ® ,  a voluntary  program  operated  by  the  U.S.  Environmental  Protection  Agency,  stresses  the need  for  strategic  corporate  energy  management.  ENERGY  STAR  provides  guidance, energy  management  tools,  and  strategies  for  successful  corporate  energy  management. This guide reports on research conducted to support ENERGY STAR and its work with the cement industry. Research provides information on potential energy efficiency opportunities for  cement  plants.  Besides  technical  information,  ENERGY  STAR  has  tools  to  facilitate stronger  corporate  energy  management  practices  in  U.S.  industry,  including  plant  energy benchmarks. ENERGY STAR resources are available through www.energystar.gov/industry. Additional energy management resources specific to cement production  can  be  found  on  the  ENERGY  STAR  Industries  in  Focus  webpage 2   for  the cement industry.

This  report  reflects  an  in-depth  analysis  of  the  cement  industry,  and  identifies  energy savings  and  carbon  dioxide  emissions  reduction  potentials.  In  this  analysis,  the  cement industry  (Standard  Industrial  Classification  3241)  includes  establishments  engaged  in manufacturing  hydraulic  cements,  including  portland,  natural,  masonry,  and  pozzolanic cements.

1 The  concept  of  the  'triple  bottom  line'  was  introduced  by  the  World  Business  Council  on Sustainable Development (WBCSD). The three aspects are interconnected as society depends on the  economy  and  the  economy  depends  on  the  global  ecosystem,  whose  health  represents  the ultimate bottom line.

The  production  of  cement  is  an  energy-intensive  process.  Typically,  energy  consumption accounts  for  20-40%  of  production  costs.  In  2008,  the  U.S.  cement  industry  spent  about $1.7  billion  to  purchase  energy;  around  $0.75  billion  of  this  was  for  electricity  and  $0.9 billion for fuels. The production of cement results in the emission of carbon dioxide from both the consumption of fuels and from the calcination of limestone. This report briefly describes the various stages in the cement production process. Details on energy consumption in the U.S. cement industry in 2009 and 2010 are provided, followed by an assessment of various energy efficiency measures applicable to U.S. cement plants.

## 2.  The U.S. Cement Industry

Cement  is  an  inorganic,  non-metallic  substance  with  hydraulic  binding  properties,  and  is used as a bonding agent in building materials. It is a fine powder, usually gray in color that consists  of  a  mixture  of  the  hydraulic  cement  minerals  to  which  one  or  more  forms  of calcium sulfate have been added (Greer et al., 1992). Mixed with water it forms a paste, which hardens due to formation of cement mineral hydrates. Cement is the binding agent in concrete, which is a combination of cement, mineral aggregates and water. Concrete is a key building material for a variety of applications.

The U.S. cement industry is made up of either portland cement plants that produce clinker and  grind  it  to  make  finished  cement,  or  clinker-grinding  plants  that  intergrind  clinker obtained elsewhere, with various additives.

Clinker  is  produced  through  a  controlled  high-temperature  burn  in  a  kiln  of  a  measured blend of calcareous rocks (usually limestone) and lesser quantities of siliceous, aluminous, and  ferrous  materials.  The  kiln  feed  blend  (also  called  raw  meal  or  raw  mix)  is  adjusted depending  on  the  chemical  composition  of  the  raw  materials  and  the  type  of  cement desired. Portland and masonry cements are the chief types produced in the United States. About 97% of the cement produced in the U.S. in 2010 was portland cement, while masonry cement accounted for 3% of U.S. cement output (USGS, 2012a).

Cement  plants  are  typically  constructed  in  areas  with  substantial  raw  materials  deposits (e.g.  50  years  or  longer).  There  were  110  operating  cement  plants  in  the  U.S.  in  2010, spread across 37 states and Puerto Rico. Portland and blended cement was produced at 110  plants  in  2010,  while  masonry  cement  was  produced  at  71  plants.  Clinker  was produced  at  100  plants  (102  including  Puerto  Rico)  in  the  U.S.  in  2010.  Total  cement production of U.S. cement plants in 2010 was about 66 Mt (excluding Puerto Rico); about 4% higher than the production in 2009 (64 Mt), which was the lowest since 1983 (USGS, 2012a).  Clinker  is  produced  with  either  the  'wet'  or  'dry'  process.  These  processes  are discussed in detail in chapter 3. Modern plants are constructed in areas where high quality

See: www.energystar.gov/industry

limestone is available, and a high demand for cement exists. These new plants have large capacities.

Clinker production, cement production, and materials consumption trends are quite similar. All  three  categories  experienced  gradual  growth  between 1970 and 2008, with prominent dips in the late 1970s, early 1980s and late 2000s. Clinker production increased from 67 Mt in 1970 to 80 Mt in 2008, at an average rate of 0.4% per year, hitting a low of 55 Mt in 1982 and  a  high  of  90  Mt  in  2006  (see  Figure  1)  (USGS,  various  years).  In  2009,  clinker production dropped to 57 Mt, a decrease of 28.5% within a single year, to slightly increase to  60  Mt  in  2010.  In  2009,  several  plants  or  kilns  were  permanently  shut  down,  while multikiln  plants  had  idled  'extra'  kilns  (USGS,  2011a).  The  2010  capacity  utilization  was 55%, slightly  higher  from  the  49%  in  2009,  and  significantly  lower  from  the  73%  in  2008 (USGS, various  years).  The  type  of  facility  used  to  produce  clinker  changed  significantly between 1970 and 2010. Clinker produced with the wet process decreased at an average of 5.7% per year, falling from a 60% share of total clinker production in 1970 to a 7% share in 2010.  Clinker  produced  with  the  dry  process  increased  at  an  average  of  1.8%  per  year, increasing from a 40% share of total clinker production in 1970 to a 91% share in 2010, with the remainder being plants classified as wet or dry.

Cement production in the U.S. (including Puerto Rico) increased at 0.6% per year between 1970 and 2008, rising from 69 Mt in 1970 to 88 Mt in 2008, to drop drastically in 2009 to 65 Mt due to the economic downturn (see Figure 2). In 2010, the cement production was 67 Mt; an increase of 3.6 % from the 2009 level. The 2010 cement production was 23% lower from the  2008  production  and  33%  lower  from  the  highest  output  in  2005  (101  Mt)  (USGS, various years). Portland cement remained the dominant cement type during that time span, maintaining a share between 95% and 97%. Between 1970 and 2010, the clinker to cement ratio (expressed as clinker production divided by cement production) decreased from 0.97 to 0.90 t clinker/t cement. The number of clinker plants has decreased from 169 in 1970 to 102 in 2010 (including Puerto Rico), and the number of clinker grinding plants reduced to 4 (a total of 106 facilities in 2010). Thus, average plant capacity has increased.

According to ECRA (2009) a new state-of-the-art cement plant with capacities of 2, 1 and 0.5 million  tonnes  would  require  an  investment  of  $180,  $235,  and  $350  per  tonne  of  clinker respectively.

Figure 1. U.S. clinker production by process, 1970 to 2010 (expressed in million metric tons per year). Source: USGS, various years. For the period 1970-2003, USGS data on clinker production by process include Puerto Rico. The term 'both' accounts for plants that are not categorized as a wet or dry process plant in the USGS minerals yearbooks.

<!-- image -->

Figure 2. U.S. cement and clinker production, 1970 to 2010 (expressed in million metric tons per year). Source: USGS, various years. Clinker and cement produced in Puerto Rico is excluded.

<!-- image -->

## 3.  Process Description

## 3.1 Mining and Quarrying

The most common raw materials used for cement production are limestone, chalk and clay (Greer et al, 1992). The major component of the raw materials, the limestone or chalk, is usually extracted from a quarry adjacent to or very close to the plant. Limestone provides the  required  calcium  oxide  and  some  of  the  other  oxides,  while  clay,  shale  and  other materials provide most of the silicon, aluminum and iron oxides required for the manufacture of  Portland  cement.  The  limestone  is  most  often  extracted  from  open-face  quarries  but underground mining can be employed (Greer et al., 1992). The raw materials are selected, crushed, pre-homogenized, ground, and proportioned so that the resulting mixture has the desired fineness and chemical composition for delivery to the pyroprocessing systems (see Figure 3). It is often necessary to raise the content of silicon oxides or iron oxides by adding quartz sand and iron ore, respectively.

The quarried material is reduced in size by processing through a series of crushers. The crushed material is screened and stones are returned. In the cement industry, the primary crushing  of  raw  materials  takes  place  in  single-  or  twin-rotor  hammer  crushers  (mills)  or impact  crushers.  The  use  of  jaw  crushers  in  cement  plants  has  been  decreasing  and nowadays, they are mainly used in small cement plants in combination with roll or gyratory crushers for the crushing of hard and abrasive materials (Chatterjee, 2004). The average power consumption for crushing is estimated to range between 0.5 and 0.9 kWh/ton of raw material  (Chatterjee,  2004).  The  gyratory  crusher  has  a  power  consumption  of  0.34-0.50 kWh/ton of raw material (Chatterjee, 2004), and is currently recognized as best available technology (Worrell et al., 2008a).

Figure 3. Simplified process schematic for cement making. Limestone is the major process input. However, other raw materials such as clay, shale, sand, quartz or iron ore may be added.

<!-- image -->

Best  practices  for  the  preblending  of  raw  materials  are  considered  a  longitudinal  store system with a bridge scraper or bucket wheel reclaimer, or a circular store system with a bridge scraper reclaimer. The energy use is estimated at 0.34 kWh/ton raw material (Worrell et  al.,  2008a).  More  than  1.5  tons  of  raw  materials  are  required  to  produce  one  ton  of portland cement (Greer et al., 1992; Alsop and Post, 1995).

## 3.2 Kiln Feed Preparation

Raw material preparation is an electricity-intensive production step requiring generally about 25-35 kWh/tonne raw material (23-32 kWh/short ton), although it could require as little as 10 kWh/tonne (9 kWh/short ton) (Harder, 2010b). After primary and secondary size reduction, the  raw  materials  are  further  reduced  in  size  by  grinding.  The  grinding  differs  with  the pyroprocessing process used. In dry processing, the materials are ground into a flowable powder in horizontal ball  mills  or  in  vertical  roller  mills.  In  a  ball  (or  tube)  mill,  steel-alloy balls  (or  tubes)  are  responsible  for  decreasing  the  size  of  the  raw  material  pieces  in  a rotating  cylinder,  referred  to  as  a  rotary  mill.  Rollers  on  a  round  table  fulfill  this  task  of comminution in a roller mill. Utilizing waste heat from the kiln exhaust, clinker cooler hood, or  auxiliary  heat  from  a  stand-alone  air  heater  before  pyroprocessing  may  further  dry  the

raw materials. The moisture content in the kiln feed of the dry kiln is typically around 0.5% (0-0.7%).

When  raw  materials  are  very  humid,  as  found  in  some  countries  and  regions,  wet processing  can  be  preferable 3 .  In  the  wet  process,  raw  materials  are  ground  with  the addition  of  water  in  a  ball  or  tube  mill  to  produce  a  slurry  typically  containing  36%  water (range  of  24-48%).  Various  degrees  of  wet  processing  exist,  e.g.  semi-wet  (moisture content of 17-22%) to reduce the fuels consumption in the kiln. Clinker plants with wet kilns use  more  water  per  ton  of  cement  than  plants  with  dry  kilns.  Water  consumption  in  wet plants  lies  within  23-130  gallons/ton  clinker  (93-560  liters/tonne  cement)  (IPPC,  2010).  In contrast,  modern  state-of-the-art  plants  have  very  low  process  water  consumption  of approximately 16 gallons/ton cement (70 liters/tonne cement) (IEA-ETSAP, 2010). Except for wet  and  semi-dry  grinding,  water  is  also  used  in  some  cases  for  lowering  the temperature of exhaust gases (when the raw mill is not in operation), in flame cooling (to reduce  NOx  emissions)  and  in  enhancing  the  cooling  requirements  of  the  clinker  cooler (IPPC, 2010). In general, dry and semi-dry cement plants use only limited amounts of water, while effluent not created as water is recycled.

## 3.3 Clinker Production (Pyro Processing) -

Clinker  production  is  the  most  energy-intensive  stage  in  cement  production,  accounting  for over 90% of total industry energy use, and virtually all of the fuel use. Clinker is produced by pyroprocessing in large kilns. These kiln systems evaporate the inherent water in the raw meal, calcine the carbonate constituents (calcination), and form cement minerals (clinkerization) (Greer et al., 1992).

The main pyroprocessing kiln type used in the U.S. is the rotary kiln. In these rotary kilns a tube with a diameter up to 8 meters (25 feet) is installed at a 3-4 degree angle that rotates 1-3 times per minute. The ground raw material, fed into the top of the kiln, moves down the tube countercurrent to the flow of gases and toward the flame-end of the rotary kiln, where the  raw  meal  is  dried,  calcined,  and  enters  into  the  sintering  zone.  In  the  sintering  (or clinkering)  zone,  the  combustion  gas  reaches  a  temperature  of  1800-2000°C  (33003600°F). While many different fuels can be used in the kiln, coal has been the primary fuel in the U.S. since the 1970s.

In a wet rotary kiln, the raw meal typically contains approximately 36% moisture. These kilns were  developed  as  an  upgrade  of  the  original  long  dry  kiln  to  improve  the  chemical uniformity in the raw meal. The water (due to the high moisture content of the raw meal) is first evaporated in the kiln in the low temperature zone. The evaporation step makes a long kiln necessary. The length to diameter ratio may be up to 38, with lengths up to 230 meters

3 Originally, the wet process was the preferred process, as it was easier to mix, grind and control the size distribution of the particles in a slurry form. The need for the wet process was reduced by the development  of  improved  grinding  processes,  and  improvement  of  the  energy  efficiency  of  the pyroprocessing systems.

(252  yards).  The  capacity  of  large  units  may  be  up  to  3600  tonnes  (3970  short  tons)  of clinker per day. Energy use in wet kilns ranges between 4.9 and 8.8 MBtu/ton clinker, with a typical value of 6.0 MBtu/ton clinker (U.S. EPA, 2007a), while according to the IPPC (2010) energy use ranges between 4.3-5.5 MBtu/ton clinker.

In a dry rotary kiln, feed material with much lower moisture content (0.5%) is used, thereby reducing the need for evaporation and reducing kiln length. The first development of the dry process  took  place  in  the  U.S.  and  was  a  long  dry  kiln  without  preheating  (Cembureau, 1997).  Long  dry  kilns  have  significantly  lower  heat  requirements  than  wet  kilns,  with  an average  fuel  use  of  4.5  MBtu/ton  clinker  (U.S.  EPA,  2007a).  Later  developments  have added multi-stage suspension preheaters (i.e. a cyclone) or shaft preheaters. Although the more preheater stages lead to less energy consumed (see Table 1), when the raw materials or fuel used has a high moisture content, it can be more energy efficient to operate the kiln with fewer preheater stages and use the extra heat for drying (Bolwerk et al., 2006).

Table 1. Heat requirements for dry kilns with different number of preheater stages

| Preheater Stages   |   GJ/tonne clinker |   GJ/tonne clinker |   MBtu/ton clinker |   MBtu/ton clinker |
|--------------------|--------------------|--------------------|--------------------|--------------------|
| 3 cyclone stages   |                3.4 |                3.8 |               2.92 |               3.27 |
| 4 cyclone stages   |                3.2 |                3.6 |               2.75 |               3.09 |
| 5 cyclone stages   |                3.1 |                3.5 |               2.66 |               3.01 |
| 6 cyclone stages   |                3   |                3.4 |               2.58 |               2.92 |

Source: ECRA, 2009

Pre-calciner  technology  was  more  recently  developed  in  which  a  second  combustion chamber has been added between the kiln and a conventional pre-heater that allows for further reduction of kiln fuel requirements. Precalciner kilns have an energy consumption of about 3.3 MBtu/ton clinker (U.S. EPA, 2007a). The most efficient pre-heater, pre-calciner kilns use approximately 2.5 MBtu/ton clinker (2.9 GJ/tonne clinker) (Anon, 1994a; Somani et al.,  1997; Su, 1997; Steuch and Riley, 1993; IPPC, 2010). Alkali or kiln dust (KD) bypass systems may be required in kilns to remove alkalis, sulfates, and/or chlorides. Such systems lead to additional energy losses since sensible heat is removed with the bypass gas and dust. There are more parameters that affect energy use such as the plant size and design, kiln capacity, raw material and fuel moisture content, as well as fuel calorific value.

Once the clinker is formed in the rotary kiln, it is cooled rapidly to minimize the formation of a glass phase and ensure the maximum yield of alite (tricalcium silicate) formation, an important component for the hardening properties of cement. The main cooling technologies are either the grate cooler or the tube or planetary cooler. In the grate cooler, the clinker is transported over a reciprocating grate through which air flows perpendicular to the flow of clinker. In the

planetary  cooler  (a  series  of  tubes  surrounding  the  discharge  end  of  the  rotary  kiln),  the clinker  is  cooled  in  a  counter-current  air  stream.  The  cooling  air  is  used  as  secondary combustion air for the kiln.

In a dry kiln cement plant, electricity use is typically broken down as follows (ECRA, 2009): 38% cement grinding, 24% raw material grinding, 22% clinker production including grinding of  solid  fuels,  6%  raw  material  homogenization,  5%  raw  material  extraction,  and  5% conveying and packaging.

Among all different types of kilns, wet kilns were found to have the higher NOx emission levels (average of 9.7 lb NOx/tonne of clinker) while dry kilns with a precalciner have the lowest  with an average of 3.8 lb NOx/tonne clinker (U.S. EPA, 2007a).

## 3.4 Finish Grinding

After cooling, the clinker can be stored in either the clinker dome, silos, bins or outside. The material  handling  equipment  used  to  transport  clinker  from  the  clinker  coolers  to  storage and  then  to  the  finish  mill  is  similar  to  that  used  to  transport  raw  materials  (e.g.  belt conveyors, deep bucket conveyors, and bucket elevators) (Greer et al., 1992). To produce powdered  cement,  the  nodules  of  cement  clinker  are  ground  to  the  consistency  of  face powder.  Grinding  of  cement  clinker,  together  with  additions  (3-5%  gypsum  to  control  the setting  properties  of  the  cement)  can  be  done  in  ball  mills,  ball  mills  in  combination  with roller  presses,  roller  mills,  or  roller  presses  (Alsop  and  Post,  1995).  Currently,  most  new plants  and  plant  expansions  in  the  U.S.  adopt  the  highly  efficient  vertical  roller  mills  for grinding  cement.  Coarse  material  is  separated  in  a  classifier  that  is  recirculated  and returned  to  the  mill  for  additional  grinding  to  ensure  a  uniform  surface  area  of  the  final product.

Power consumption for grinding depends on the surface area required for the final product and the additives used. Electricity use for raw meal and finish grinding depends strongly on the  hardness  of  the  material  (limestone,  clinker,  pozzolana  extenders)  and  the  desired fineness of the cement as well as the amount of additives. Blast furnace slags are harder to grind  and  hence  use  more  grinding  power,  between  50  and  70  kWh/tonne  (45  and  64 kWh/short  ton)  for  a  3,500  Blaine 4   (expressed  in  cm 2 /g).  (COWIconsult  et  al.,  1993). Traditionally, ball mills are used in finish grinding, while many plants use vertical roller mills. In ball  or  tube  mills,  the  clinker  and  gypsum are fed into one end of a horizontal cylinder and partially ground cement exits from the other end. Modern ball mills may use between 32 and 37  kWh/tonne  (29  and  34  kWh/short  ton)  (Seebach  et  al.,  1996,  Cembureau,  1997)  for cements with a Blaine of 3,500.

4 Blaine is a measure of the total surface of the particles in a given quantity of cement, or an indicator of the fineness of cement. It is defined in terms of square centimetres per gram. The higher the Blaine, the more energy required to grind the clinker and additives (Holderbank, 1993).

Modern state-of-the-art concepts utilize a high-pressure roller mill and the horizontal roller mill (e.g. Horomill ® ) (Seebach et al., 1996) that are claimed to use 20-50% less energy than a ball mill. The roller press is a relatively new technology, and is more common in Western Europe than  in  North  America  (Holderbank,  1993).  Various  new  grinding  mill  concepts  are  under development or have been demonstrated (Seebach et al., 1996), e.g. the Horomill ®  (Buzzi, 1997),  Cemax  (Folsberg,  1997),  the  IHI  mill,  and  the  air-swept  ring  roller  mill  (Folsberg, 1997).

Finished cement is stored in silos, tested and filled into bags, or shipped in bulk in cement trucks, railcars, barges or ships. Additional power is consumed for conveyor belts and packing of cement. The total consumption for these purposes is generally low and not more than 5% of total power use (Vleuten, 1994). Total power use for auxiliaries is estimated at roughly 10 kWh/tonne  clinker  (9  kWh/short  ton  clinker)  (Heijningen  et  al.,  1992).  The  power  use  for conveyor  belts  is  estimated  at  1-2  kWh/tonne  cement  (0.8-1.8  kWh/short  ton  cement) (COWIconsult et al., 1993). Electricity use for lighting and other miscellaneous equipment is estimated at approximately 1.2% of the overall electricity use (Heijningen et al., 1992). The power consumption for packing depends on the share of cement packed in bags.

## 4.  Energy Use and Carbon Dioxide Emissions  in 5 the U.S. Cement Industry

## 4.1 Historical Energy Use and Carbon Dioxide Emission Trends

Energy  consumption  in  the  U.S.  cement  industry  declined  between  1970  and  2010  (see Figure 4). Primary energy use decreased at an average of 0.6% per year, from 555 TBtu (586 PJ) in 1970 to 442 TBtu (466 PJ) in 2008, although production increased over that time span. The further decrease in energy consumption to 332 TBtu (350 PJ) in 2010 is primarily an effect of the reduced levels in cement production. The overall energy consumption trend in  the  U.S.  cement  industry  between  1970  and  2010  shows  a  gradual  decline.  Energy consumption started to increase in the early 1990s and increased between 1992 and 2005 at an average of 2.0% per year, followed by a decrease of 4.7% per year between 2005 and 2008,  and  a  steep  decrease  of  25%  between  2008  and  2010  as  an  outcome  of  the economic  recession.  The  share  of  the  two  main  clinker-making  processes  in  energy consumption changed drastically between 1970 and 2010. While the wet process consumed 62% of total cement energy consumption in 1970, it used only 10% in 2010, while energy consumption of the dry process increased from 37% of total cement energy consumption in 1970 to 88% in 2010.

5 Carbon dioxide emissions are commonly expressed in metric tons carbon. To convert to carbon dioxide multiply by 44/12.

Since the 1980s the use of waste-derived fuels has grown in the cement industry, replacing a  portion  of  traditional  fuels.  As  Figure  5  shows,  by  2010  16%  of  all  fuels  were  waste derived  fuels,  e.g.  tires,  solid  and  liquid  wastes  (solvents).  USGS  has  collected  data  on waste fuel use starting 1992, although waste fuel use started before that time. The trend towards increased waste use will likely increase after successful tests with different wastes in Europe and North America. New waste streams include carpet and plastic wastes, filter cake,  paint  residue  and  (dewatered)  sewage  sludge.  The  energy  recovery  efficiency  in clinker  kilns  is  often  high  compared  to  alternative  thermal  waste  treatments  methods, resulting in net energy savings.

The  cement  industry  contributes  approximately  4%  to  all  industrial  carbon  dioxide  (CO ) 2 emissions  in  the  United  States  (equivalent  to  approximately  2%  of  total  U.S.  CO2 emissions). In 2009, the calcination of clinker was the second largest source (after natural gas  production)  of  CO2  emissions  not  related  to  fuel  consumption.  In  2009,  the  cement industry  was  responsible  for  35%  of  industrial  process  CO2  emissions  (equivalent  to approximately 1% of total U.S. CO2 emissions) (EIA, 2011b). 2008 CO2 emissions from fuel consumption (including CO2 emissions from alternative fuels) in the cement industry were virtually back at the level of 1975, around 10 MtC, despite a drop in the years in between, due to improvements in the pyroprocessing systems. In 2010, due to the decrease in clinker production CO2 emissions from fuel consumption dropped to 7.3 MtC. CO2 emissions from the  calcination  process  increased  from  9.3  MtC  in  1970  to  10.8  MtC  in  2008  due  to  the increased clinker production. In 2010, the low level of CO2 emissions from calcination, 8.3 MtC, was due to the lower clinker production. Hence, total carbon dioxide emissions from the  cement  industry  increased  to  20.8  MtC  in  2008,  to  decrease  in  2009  to  15.6  MtC (including emissions from power generation). Carbon dioxide emissions from fuel consumption have decreased with energy consumption, and shifting fuel use patterns have affected carbon emissions significantly as well. The largest change occurred in natural gas use, which decreased from a 44% fuel share in 1970 to a 4% (incl. landfill gas) fuel share in 2010, due to natural gas price increases and fuel diversification policies after the oil price shocks.  Natural  gas  was  commonly  substituted  by  coal  and  coke,  which  increased  fuel share from 36% in 1970 to 68% in 2010, petroleum coke (16% in 2010), tires (3% in 2010) and wastes (liquid and solid, 13% in 2010). Oil's share fell from 13% in 1970 (17% in 1973) to 0.4% in 2010. Electricity's share increased from 7% in 1970 to 12% in 2010.

Figure 4. Primary energy consumption in U.S. cement production by process, 1970 to 2010 (expressed in TBtu). Source: derived from USGS, various years. For the period 1970-2003 USGS data on energy use include Puerto Rico.

<!-- image -->

Figure 5. Final energy consumption in U.S. cement production by fuel, 1970 to 2010 (expressed in TBtu). Source: derived from USGS, various years. For the period 1970-2003 USGS data on energy use include Puerto Rico.

<!-- image -->

## 4.2 Historical Energy Intensity and Specific Carbon Dioxide Emission Trends

Primary energy intensity in the U.S. cement industry decreased between 1970 and 2010. Primary energy intensity of cement production decreased at an average rate of 2.4% per year  from  1970  to  1988,  increased  by  0.8%  per  year  from  1988  to  1999,  but  decreased again  by  1.1%  per  year  between  1999  and  2010.  Between  1970  and  2010  the  primary energy  intensity  fell  from  7.3  MBtu/ton  in  1970  to  4.5  MBtu/ton  in  2010  (see  Figure  6). Energy  intensity  of  cement  production  decreased  due  to  increased  capacity  of  the  more energy efficient dry process for clinker-making (see Figure 1), energy efficiency improvements (see Figure 7) and reduced clinker production per ton of cement produced (see Figure 2).

The average primary energy use of the U.S. cement industry decreased by 0.51 MBtu/ton clinker within a period of 10 years (1997-2008) (Boyd and Zhang, 2011). This outcome is in accordance with our estimates of 0.55 MBtu/ton clinker improvement of energy within the same period.

Figure 6. Primary energy intensity of U.S. cement and clinker production, 1970 to 2010 (expressed in MBtu/short ton, HHV). This graph excludes use of wastes as kiln fuel between 1977 and 1992, as USGS did not collect this data before 1993. Source: derived from USGS, various years. Energy intensities in the period 1970-2003 include Puerto Rico.

<!-- image -->

Figure  7  shows  the  developments  in  specific  fuel  and  electricity  consumption.  The  figure shows  a  slow  increase  in  specific  electricity  consumption,  which  is  due  to  the  increased penetration of the modern dry process (preheater/precalciner technology), but is very small in  comparison  to  fuel  consumption.  Specific  fuel  consumption  decreases  strongly  until

around 1987, slightly grows between 1991 and 2000, and slightly decreases in recent years. In 2010, the average fuel use was 3.3 MBtu/ton cement (3.8 GJ/tonne cement), very slightly higher  from  that  in  2009  (3.2  MBtu/ton  or  3.8  GJ/tonne).  Fuel  requirements  in  clinker production decreased by 1.5%, from 3.68 MBtu/ton clinker (4.28 GJ/tonne clinker) in 2009 to 3.62 MBtu/ton clinker (4.22 GJ/tonne clinker) in 2010. The decrease in the average fuel requirements for clinker production, is the result of the closure in 2009 of two cement plants that  operated  wet  kilns,  the  closure  of  the  wet  kilns  in  two  combination  plants,  and  the addition  of  a  dry  kiln  at  a  previously  wet  plant  (USGS,  2012a).  In  2010,  the  average electricity use was 0.44 MBtu/ton cement (0.52 GJ/tonne cement), decreased very slightly by  0.8%  from  that  in  2009.  The  2009  increase  in  electricity  use  reflected  disruptions  in operation (idling, repairs, upgrades), and higher clinker production volumes from dry plants (only  9%  of  clinker  was  produced  in  wet  kilns)  (USGS,  2011a).  In  general,  dry  kilns  are characterized by higher power requirements due to their more sophisticated layout.

Figure 7. Specific fuel and electricity consumption per ton of cement produced. Energy is expressed as final energy (or site energy) and excludes power generation conversion losses. Fuels include waste fuel use estimates starting in 1977 (based on PCA data, and after 1993 on USGS reported data). Energy intensities in the period 1970-2003 include Puerto Rico.

<!-- image -->

Specific carbon dioxide emissions 6  from fuel consumption declined from 352 lbC/ton cement (175  kgC/tonne)  in  1970  to  220  lbC/ton  cement  (110  kgC/tonne)  in  2010.  Total  carbon

6 Carbon dioxide emissions were calculated based on the fuels and electricity consumption as given by USGS (various years), average US power generation efficiency and fuel use as given by the EIA (various years) and clinker production data as given by USGS (various years). The emission factors used for the various commercial fuels are taken from U.S. EPA (2009) and for electricity generation from EIA (2011a).

dioxide  emissions  (including  emissions  from  limestone  calcination  for  clinker-making) decreased at 0.7% per year, on average, from 609 lbC/ton cement (305 kgC/tonne) in 1970 to 469 lbC/ton cement (234 kgC/tonne) in 2010. Carbon dioxide emissions from calcination are estimated based on a standard emission factor for limestone calcination (0.14 tC/tonne clinker) (Hanle et al., 2006). However, this factor can be lower as blast furnace slag and fly ash (noncarbonate raw materials) are used in the cement kilns as substitutes for limestone. In  2010,  about  3.7  million  tonnes  of  noncarbonate  materials  were  used  in  the  U.S.  kilns (USGS,  2012a),  decreasing  the  emissions  from  calcination  from  8.3  MtC  to  8.0  MtC;  a decrease of about 2.8%.

Like  the  energy  intensity  trend,  specific  carbon  dioxide  emissions  decreased  overall between  1970  and  2010.  The  specific  carbon  dioxide  emissions  from  the  wet  process increased between 1970 and 2010 at an average of 0.1% per year while the specific carbon dioxide  emissions  from  the  dry  process  decreased  at  an  average  rate  of  1.0%  per  year during the same period.

The  increased  dry  process  clinker  production  capacity,  improved  energy  efficiency,  and decreasing clinker/cement-production ratio reduced the specific carbon dioxide emissions, while  the  substantial  fuel  shifts  towards  more  carbon  intensive  fuels  like  coal  and  coke contributed to an increase in specific carbon dioxide emissions (see Figure 8). Overall, fuel mix  trends  were  more  than  offset  by  energy  intensity  reductions,  leading  to  an  overall decrease in specific carbon dioxide emissions.

Figure 8. Carbon intensity of U.S. cement and clinker production, 1970 to 2010 (expressed in kgC per short ton of product). This graph excludes use of wastes as kiln fuel between 1977 and 1992, as USGS did not collect this data before 1993.  Source: derived from USGS, various years.

<!-- image -->

## 5.  2009 Baseline Energy Use and Carbon Dioxide Emissions

In 2009, the U.S. cement industry consumed 259 TBtu (273 PJ) of final energy (about 2.5% of  total  U.S.  manufacturing  energy  use)  and  emitted  14.7  MtC  of  carbon  dioxide 7   (about 4.0% of total U.S. manufacturing carbon emissions). Table 2 provides an estimate of 2009 U.S. baseline energy consumption by process. The estimates are based on the throughput of the different processes, energy consumption information provided for the different processes, and the total energy consumption in the U.S. cement industry in 2009.

7 We express carbon dioxide emissions in their carbon equivalent using metric tons. To obtain carbon dioxide emissions expressed in full molecular weight multiply by 44/12.

Table 2. 2009 Energy consumption and Specific Energy Consumption (SEC) in the U.S. cement plants by process. All energy units are expressed in higher heating value (HHV). Emissions are expressed in metric units (i.e. kg and metric ton).

| Process Stage              | Fuel (Tbtu)   | Elec. (Tbtu)   | Primary Energy (Tbtu)   | Fuel SEC MBtu/st   | Elec. SEC kWh/st   | Primary SEC Mbtu/st   | Carbon Dioxide Emissions Energy Use (MMtCe)   | Carbon Dioxide Emissions Calcination (MMtCe)   | Carbon Dioxide Intensity (kgC/st)   |
|----------------------------|---------------|----------------|-------------------------|--------------------|--------------------|-----------------------|-----------------------------------------------|------------------------------------------------|-------------------------------------|
| Wet Process                |               |                |                         |                    |                    |                       |                                               |                                                |                                     |
| Kiln Feed Preparation      | 0.0           | 1.1            | 3.3                     | 0.0                | 28.4               | 0.3                   | 0.1                                           | 0.0                                            | 4.4                                 |
| Clinker Production 7       | 36.9          | 0.6            | 38.8                    | 5.8                | 29.3               | 6.1                   | 0.9                                           | 0.8                                            | 265.0                               |
| Finish Grinding            | 0.0           | 1.6            | 4.5                     | 0.0                | 61.6               | 0.6                   | 0.1                                           | 0.0                                            | 9.7                                 |
| Total Wet Process - Cement | 36.9          | 3.4            | 46.6                    | 4.9                | 130.9              | 6.2                   | 1.0                                           | 0.8                                            | 240.2                               |
| Dry Process                |               |                |                         |                    |                    |                       |                                               |                                                |                                     |
| Kiln Feed Preparation      | 0.0           | 10.6           | 30.4                    | 0.0                | 32.0               | 0.3                   | 0.5                                           | 0.0                                            | 5.0                                 |
| Clinker Production         | 190.7         | 6.2            | 208.6                   | 3.4                | 33.0               | 3.8                   | 5.0                                           | 7.0                                            | 220.6                               |
| Finish Grinding            | 0.0           | 11.3           | 32.4                    | 0.0                | 53.7               | 0.5                   | 0.5                                           | 0.0                                            | 8.4                                 |
| Total Dry Process - Cement | 190.7         | 28.2           | 271.3                   | 3.1                | 133.7              | 4.4                   | 6.0                                           | 7.0                                            | 209.0                               |
| Total All Cement           | 227.6         | 31.6           | 317.9                   | 3.3                | 133.4              | 4.6                   | 7.0                                           | 7.7                                            | 212.4                               |

## Notes:

- -To convert from Trillion  Btu  to  PJ  multiply  by  1.055.  To  convert  from  MBtu/short  ton  to  GJ/tonne  multiply  by 1.163. To convert from kgC/short ton to kgC/tonne multiply by 1.103. To convert from kgC/st to lbC/st multiply by 2.203.
- -All  energy  units  are  expressed  in  Higher  Heating  Value  (HHV),  as  is  common  in  U.S.  energy  statistics. International  energy  statistics  generally  report  energy  in  Lower  Heating  Value  (LHV).  Comparing  energy intensities in Table 2 with other countries should only be done after conversion to LHV.
- -Unfortunately, available statistics do not allow to further disaggregate energy use for dry kilns into preheater and pre-calciner kilns.
- -Components may not sum to totals because of rounding.

## 5.1 Raw Materials

In 2009, 110 Million short tons (100 Mt) of raw materials were used in the cement industry (USGS, 2011a). 8  It is assumed that 11% of raw materials were used for the wet process

8 The import of 1.4 Million tons of clinker (2009) would account for an additional 2.1 Million tons of raw  material  use.  However,  we  only  include  materials  processed  in  the  U.S.  cement  industry  to determine energy intensities.

kilns and 89% of raw materials were used for dry process kilns. Electricity use is estimated at 28 kWh/short ton raw material preparation for wet kilns and 32 kWh/short ton for dry kilns (COWIconsult et al., 1993; Jaccard and Willis, 1996).

## 5.2 Clinker Production

According to USGS (2011a) wet process clinker production was 5.36 Million short tons (4.87 Mt)  while  dry  process  production  was  55.2  Million  short  tons  (50.1  Mt).  Accounting  for production from plants with both wet and dry processes on site, USGS gives a total clinker production of 61.8 Million short tons (56.1 Mt) in that year. The average U.S. wet kiln fuel intensity in 2009 is estimated at 5.8 MBtu/short ton clinker (6.8 GJ/t) and an average dry kiln fuel intensity of 3.4 MBtu/short ton (4.0 GJ/tonne) (Holderbank, 1993; PCA, 1996; Jaccard and Willis, 1996; van Oss, 1999; IPPC, 2010). Electricity requirements of 29 kWh/short ton (32  kWh/tonne)  are  assumed  for  fuel  preparation  and  for  operating  the  kiln,  fans,  and coolers for wet kilns and 33 kWh/short ton (36 kWh/tonne) for dry kilns (COWIconsult et al., 1993; Ellerbrock and Mathiak, 1994). Although electricity use in dry kiln plants is higher than in wet kiln plants, as wet plants get older this difference is limited.

## 5.3 Finish Grinding

The amount of throughput for finish grinding is assumed to be the same as the total amount of  cement  produced  in  2009,  7.5  million  short  tons  (6.8  Mt)  for  wet  cement,  61.7  million short tons (56.0 Mt) for dry cement and 1.2 million short tons (1.1 Mt) for other processes (USGS,  2011a).  Based  on  Lowes  (1990)  and  COWIconsult  (1993),  the  average  energy requirements  for  finish  grinding  are  estimated  to  be  52  kWh/short  ton  (57  kWh/t)  for  the newer  plants  using  dry  kilns  and  60  kWh/short  ton  (66  kWh/t)  for  the  older  wet  process plants.

## 5.4 Carbon Dioxide Emissions

Carbon dioxide emissions in the cement industry are produced both through the combustion of fossil fuels and waste fuels, and the calcination of limestone. In the calcination process 0.14 tonnes of carbon (0.51 tonnes of CO2) are emitted for every tonne of clinker produced (Hanle et al., 2006). This amounts to 7.7 MtC given a production of 56.1 million tonnes of clinker (61.9 million short tons) in 2009 (USGS, 2011a). Energy consumption data is based on  the  physical  consumption  data  as  provided  by  the  U.S.  Geological  Survey.  The consumption data are multiplied with typical U.S. energy contents for the different fuels, as given  by  the  Energy  Information  Administration's  Manufacturing  Energy  Consumption Survey  (MECS)  and  the  Energy  Information  Administration's  Annual  Energy  Outlook  (for recent years) (EIA, various years). U.S. EPA (2009) is the source for 2009 carbon dioxide emission coefficients for the various commercial fuels. For electricity, the 2009 average fuel mix for electricity generation in the U.S is used (EIA, 2011a).

## 6.  Energy Efficiency Technologies and Measures for the U.S. Cement Industry

Opportunities exist within U.S. cement plants to improve energy efficiency while maintaining or enhancing  productivity. Improving energy  efficiency at a cement  plant should be approached from several directions. First, plants use energy for equipment such as motors, pumps, and compressors.  These important components require regular maintenance, good operation  and  replacement,  when  necessary.  Thus,  a  critical  element  of  plant  energy management  involves  the  efficient  control  of  crosscutting  equipment  that  powers  the production process of a plant. A second and equally important area is the proper and efficient operation of the process. Process optimization and ensuring the most efficient technology is in place is a key to realizing energy savings in a plant's operation. Finally, throughout a plant, there are many processes simultaneously. Fine-tuning their efficiency is necessary to ensure energy savings are realized.

If a corporation owns more than one plant, energy management can be more complex than just considering the needs of a single one. A corporate energy management program helps to ensure energy efficiency is achieved across the company's plants. Whether for a single plant or for an  entire  corporation,  establishing  a  strong  organizational  energy  management framework is important to implement energy efficiency measures effectively.

Several  technologies  and  measures  exist  that  can  reduce  the  energy  intensity  (i.e.  the electricity  or  fuel  consumption  per  unit  of  output)  of  the  various  process  stages  of  cement production. This section provides more detailed estimates on the technologies and measures, their  costs,  and  potential  for  implementation  in  the  U.S.  Table  3  lists  the  technologies  and measures that were considered in this analysis.

To simplify comparisons the following conversion factors were used: 0.93 tons clinker per ton of cement, 1.55 tons of raw materials per ton of cement, and 1.67 tons of raw materials per ton of clinker. All conversions were based on data reported by USGS for the year 2008 (USGS, 2010).

Table 3. Energy-efficient practices and technologies in cement production

| Raw Materials Preparation                                                                                                                                                                                                                                                                                                                                                                                                                          |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Efficient transport systems (dry process) Raw meal blending systems (dry process) Slurry blending and homogenization (wet process) Conversion to closed circuit wash mill (wet process) Advanced raw meal grinding (dry process)                                                                                                                                                                                                                   | Separate raw material grinding (dry process) Raw meal process control (dry process) High - efficiency classifiers/separators Fuel preparation: Roller mills                                                                                                                                                                                                                                                                                                                                                                                           |
| Clinker Production (Wet)                                                                                                                                                                                                                                                                                                                                                                                                                           | Clinker Production (Dry)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Energy management and process control Kiln combustion system improvements Mineralized clinker Indirect firing Oxygen enrichment Mixing air technology Seal replacement Kiln shell heat loss reduction Refractories Efficient kiln drives Conversion to modern grate cooler Optimize grate coolers Conversion to semi - dry kiln (slurry drier) Conversion to semi - wet kiln (filter press system) Conversion to pre - heater, pre - calciner kiln | Energy management and process control Kiln combustion system improvements Mineralized clinker Indirect firing Oxygen enrichment Mixing air technology Seal replacement Kiln shell heat loss reduction Preheater shell heat loss reduction Refractories Efficient kiln drives Conversion to modern grate cooler Optimize grate coolers Conversion to modern grate cooler Optimize grate coolers Low pressure drop cyclones for suspension pre - heaters Heat recovery for power generation Long dry kiln conversion to multi - stage pre - heater kiln |
| Finish Grinding                                                                                                                                                                                                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Energy management and process control Vertical roller mills Horizontal roller mills High - pressure roller presses - pre - grinding                                                                                                                                                                                                                                                                                                                | High - pressure roller presses - finish grinding High efficiency classifiers Improved grinding media (ball mills)                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| General Measures                                                                                                                                                                                                                                                                                                                                                                                                                                   |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Preventative maintenance (insulation, compressed air system, maintenance) High efficiency motors Optimization of compressed air systems                                                                                                                                                                                                                                                                                                            | High efficiency fans Efficient lighting Efficient dust collectors                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Product &Feedstock Changes                                                                                                                                                                                                                                                                                                                                                                                                                         |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| High Alkali cement Blended Cements Limestone Portland cement Reducing fineness of cement for selected uses Use of steel slag in kiln (CemStar®)                                                                                                                                                                                                                                                                                                    | Use of fly ash and blast furnace slag in kiln Use of cement kiln dust in kiln Use of calcareous oil shale in kiln Lower lime saturation factor                                                                                                                                                                                                                                                                                                                                                                                                        |
| Fuel change                                                                                                                                                                                                                                                                                                                                                                                                                                        |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Switch from coal to oil/natural gas Alternative fuels (biomass and waste)                                                                                                                                                                                                                                                                                                                                                                          | Tire derived fuel                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |

Not all measures in Table 3 will apply to all plants. Applicability will depend on the current and future  situation  in  individual  plants.  For  example,  expansion  and  large  capital  projects  are likely  to  be  implemented  only  if  the  company  has  about  50  years  of  remaining  limestone reserves onsite. Plants that have a shorter remaining supply are unlikely to implement large

capital  projects,  and  would  rather  focus  on  minor  upgrades  and  energy  management measures.

## 6.1 Energy Management Systems and Programs

Improving  energy  efficiency  should  be  approached  from  several  directions.  A  strong, corporate-wide  energy  management  program  is  essential.  Crosscutting  equipment  and technologies such as compressed air and motors, common to most plants and manufacturing industries, including cement, present well-documented opportunities for improvement. Equally important, the production process can be fine-tuned to produce even greater savings. Section 6.8 shows measures concerning these and other general crosscutting utilities that apply to the cement industry.

Although technological changes in equipment conserve energy, changes in staff behavior and attitude can also have a great impact. Energy efficiency training programs can help a company's staff incorporate energy efficiency practices into their day-to-day work routines. Personnel at all levels should be aware of energy use and company objectives for energy efficiency  improvement.  Often  such  information  is  acquired  by  lower-level  managers  but neither  passed  up  to  higher-level  management  nor  passed  down  to  staff  (Caffal,  1995). Energy  efficiency  programs  with  regular  feedback  on  staff  behavior,  such  as  reward systems, have had the best results. Though changes in staff behavior (such as switching off lights or closing windows and doors) often save only small amounts of energy at one time, taken  continuously  over  longer  periods  they  can  have  a  much  greater  effect  than  some other more costly technological improvements.

Establishing formal management structures and systems for managing energy that focus on continuous  improvement  are  important  strategies  for  helping  companies  manage  energy use and implement energy efficiency measures. The U.S. EPA's ENERGY STAR program has developed a framework for energy management based on the observed best practices of leading companies. Other management frameworks, such as ISO 14001, can be used to ensure  better  organizational  management  of  energy.  One  ENERGY  STAR  partner  noted that using energy management programs in combination with the ISO 14001 program has had a greater impact on conserving energy at its plants than any other strategy.

Improving energy efficiency in cement manufacturing should be approached from several directions. A strong, corporate-wide energy management program is essential. Ideally, such a  program  would  include  facility,  operations,  environmental,  health,  and  safety,  and management  personnel.  Energy  efficiency  improvements  to  cross-cutting  technologies, 9 such as the use of energy-efficient motors and the optimization of compressed air systems, present well-documented opportunities for energy savings. Optimizing system design and operations, such as maximizing process waste heat recovery, can also lead to significant

9 Cross-cutting  technologies  are  defined  as  equipment  that  is  commonly  used  in  many  different industries, such as boilers, pumps, motors, compressed air systems, and lighting.

reductions  in  energy  use.  In  addition,  production  processes  can  often  be  fine-tuned  to produce similar savings.

Energy  management  programs. Changing  how  energy  is  managed  by  implementing  an organization-wide  energy  management  program  is  one  of  the  most  successful  and  costeffective ways to bring about energy efficiency improvements.

Energy efficiency does not happen on its own. A strong energy management program creates a foundation for positive change and provides guidance for managing energy throughout an organization.  Energy  management  programs  also  help  to  ensure  that  energy  efficiency improvements do not just happen on a one-time basis, but rather are continuously identified and implemented in an ongoing process of continuous improvement. Furthermore, without the backing of a sound energy management program, energy efficiency improvements might not reach their full  potential  due  to  lack  of  a  systems  perspective  and/or  the  support  of  proper maintenance and follow-up.

In companies without a clear program in place, opportunities for improvement may be known but may not be promoted or implemented because of organizational barriers. These barriers may include a lack of communication among plants, a poor understanding of how to create support for an energy efficiency project, limited finances, poor accountability for measures, or organizational inertia to changes from the status quo. Even when energy is a significant cost, many companies still lack a strong commitment to improve energy management.

Figure 9. Main elements of a strategic energy management program, ENERGY STAR Guidelines for Energy Management

<!-- image -->

The  U.S.  EPA,  through  the  ENERGY  STAR  program,  works  with  many  leading  industrial manufacturers to identify the basic aspects of effective energy management programs. 10  The major elements in a strategic energy management program are depicted in Figure 9.

A successful program  in energy management  begins  with a strong organizational commitment  to  continuous  improvement  of  energy  efficiency.  This  involves  assigning oversight and management duties to an energy director, establishing an energy policy, and creating a cross-functional energy team (see the following section). Steps and procedures are  then  put  in  place  to  assess  performance  through  regular  reviews  of  energy  data, technical assessments, and benchmarking. From this assessment, an organization is able to develop a baseline of energy use and set goals for improvement. Performance goals help to shape the development and implementation of an action plan.

10 Read about strategic energy management at www.energystar.gov/industry.

An  important  aspect  for  ensuring  the  success  of  the  action  plan  is  involving  personnel throughout  the  organization.  Personnel  at  all  levels  should  be  aware  of  energy  use  and goals for efficiency. Staff should be trained in both skills and general approaches to energy efficiency  in  day-to-day  practices.  In  addition,  performance  results  should  be  regularly evaluated  and  communicated  to  all  personnel,  recognizing  high  achievement.  Some examples of simple tasks employees can do are outlined in Appendix A.

Progress evaluation involves the regular review of both energy use data and the activities carried out as part of the action plan. Information gathered during the formal review process helps in  setting  new  performance  goals  and  action  plans  and  in  revealing  best  practices. Once best practices are established, the goal of the cross-functional energy team should be to replicate these practices throughout the organization. Establishing a strong communications  program  and  seeking  recognition  for  accomplishments  are  also  critical steps. Strong communication and receiving recognition help to build support and momentum for future activities.

A  quick  assessment  of  an  organization's  efforts  to  manage  energy  can  be  made  by comparing  its  current  energy  management  program  against  the  ENERGY  STAR  Energy Program Assessment Matrix provided in Appendix B.

As  discussed  above,  internal  support  for  an  energy  management  program  is  crucial; however,  support  for  energy  management  programs  can  come  from  outside  sources  as well. Facility audits can be a particularly effective form of outside support. For example, the U.S.  Department  of  Energy  (DOE)  sponsors  26  Industrial  Assessment  Centers  (IACs)  at universities across the United States. These  IACs offer small and medium  sized manufacturing facilities free assessments of plant energy and waste management performance  and  recommend  ways  to  improve  efficiency.  Since  the  early  1980s,  IAC assessments of U.S. cement plants have identified over 160 energy efficiency improvement opportunities,  with  an  average  annual  savings  of  about  $130,000  and  an  average  simple payback of 1.4 years per recommendation (IAC, 2012).

The  U.S.  DOE  sponsors  similar  audits  for  large  manufacturing  plants  under  the  Better Buildings, Better Plants (BBBP) program, which replaced the Save Energy Now program. As of 2006, nearly 30 Save Energy Now audits were conducted for the U.S. cement industry (U.S. DOE, 2012). Appendix D provides additional information on U.S. DOE programs, as well  as  a  host  of  other  external  resources  that  can  aid  in  identifying  energy  efficiency opportunities.

Energy teams. The establishment of an energy team is an important step toward solidifying a  commitment  to  continuous  energy  efficiency  improvement. 11   The  energy  team  should primarily be responsible for planning, implementing, benchmarking, monitoring, and

11 For  a  comprehensive  overview  of  establishing,  operating,  and  sustaining  an  effective  energy management team, please consult the U.S. EPA's Teaming Up to Save Energy guide available at www.energystar.gov/energyteam (U.S. EPA, 2006).

evaluating  the  organizational  energy  management  program.  However,  its  duties  can  also include delivering training, communicating results, and providing employee recognition (U.S. EPA, 2006).

In  forming  an  energy  team,  it  is  necessary  to  establish  the  organizational  structure, designate team members, and specify roles and responsibilities. Senior management needs to perceive energy management as part of the organization's core business activities. Thus, ideally the energy team leader will be someone at the corporate level who is empowered by support from senior-level management. The energy team should also include members from each key operational area within an organization and be as multi-disciplinary as possible to ensure a diversity of perspectives. It is crucial to ensure adequate organizational funding for the energy team's activities, preferably as a line item in the normal budget cycle as opposed to a special project.

Prior to the launch of an energy team, a series of team strategy meetings should be held to consider  the  key  initiatives  to  pursue  as  well  as  potential  pilot  projects  that  could  be showcased at the program's kickoff.  The  energy  team  should  then  perform  facility  audits with  key  plant  personnel  at  each  facility  to  identify  opportunities  for  energy  efficiency improvements. As part of the facility audits, the energy team should look for best practices in  action  to  help  highlight  success  stories  and  identify  areas  for  inter-plant  knowledge transfer.

A  key  function  of  the  energy  team  is  to  develop  mechanisms  and  tools  for  tracking  and communicating progress and for transferring the knowledge gained through facility audits across  an  organization.  Examples  of  such  mechanisms  and  tools  include  best  practice databases, facility benchmarking tools, intranet sites, performance tracking scorecards, and case studies of successful projects. Corporate energy summits and employee energy fairs are also effective means of information exchange and technology transfer.

To  sustain  the  energy  team  and  build  momentum  for  continuous  improvement,  it  is important  that progress  results  and  lessons  learned  are  communicated  regularly  to managers and employees. It is also important that a recognition and rewards program is put in place.

A  checklist  of  key  steps  for  forming,  operating,  and  sustaining  an  effective  energy management team is offered in Appendix C.

Energy monitoring systems .  The use of energy monitoring and process control systems can play an important role in energy management and in reducing energy use. These may include submetering, monitoring, and control systems. They can reduce the time required to perform  complex  tasks,  often  improve  product  and  data  quality  and  consistency,  and optimize process operations. Typically, energy and cost savings are around 5% or more for many  industrial  applications  of  process  control  systems.  These  savings  apply  to  plants without  updated  process  control  systems;  many  U.S.  plants  may  already  have  modern process control systems in place to improve energy efficiency.

Although energy management systems are already widely disseminated in various industrial sectors, the performance of the systems can still be improved, which will reduce costs and increase energy savings further.

Specific energy savings and payback periods for overall adoption of energy monitoring and control  systems  vary  greatly  from  plant  to  plant  and  company  to  company.  A  variety  of process control systems are available for virtually any industrial process, and a wide body of literature is available assessing control systems in most industrial sectors. Table 4 provides an overview of classes of process control systems.

Table 4. Classification of control systems and typical energy efficiency improvement potentials

| System                                  | Characteristics                                                                           | Typical energy savings (%)                                           |
|-----------------------------------------|-------------------------------------------------------------------------------------------|----------------------------------------------------------------------|
| Monitoring and Targeting                | Dedicated systems for various industries, well established in many countries and sectors  | Typical savings 4 - 17%, average 8% , based on experiences in the UK |
| Computer Integrated Manufacturing (CIM) | Improvement of overall economics of process, e.g. stocks, productivity and energy         | > 2%                                                                 |
| Process control                         | Moisture, oxygen and temperature control, air flow control 'Knowledge based, fuzzy logic' | Typically 2 - 18% savings                                            |

Note: The estimated savings are valid for specific applications (e.g. lighting energy use). The energy saving cannot be added, due to overlap of the systems. Sources: (Caffal, 1995, Martin et al., 2000b).

Modern control systems are often not solely designed for energy efficiency, but rather for improving productivity, product quality, and the efficiency of a production line. Applications of advanced control and energy management systems are in varying development stages and  can  be  found  in  all  industrial  sectors.  Control  systems  result  in  reduced  downtime, reduced maintenance costs, reduced processing time, and increased resource and energy efficiency, as well as improved emissions control. Many modern energy-efficient technologies  depend  heavily  on  precise  control  of  process  variables,  and  applications  of process  control  systems  are  growing  rapidly.  Modern  process  control  systems  exist  for virtually any industrial process. Still, large potentials exist to implement control systems and more modern systems enter the market continuously.

Process  control  systems  depend  on  information  of  many  stages  of  the  processes.  A separate but related and important area is the development of sensors that are inexpensive to install, are reliable, and will analyze in real-time. Development aims at the use of optical, ultrasonic, acoustic,  and  microwave  systems  that  should  be  resistant  to  aggressive environments (e.g. oxidizing environments in a furnace or chemicals in chemical processes) and withstand high temperatures. Information from the sensors is used in control systems to adapt the process conditions, based on mathematical ('rule'-based) or neural networks and 'fuzzy logic' models of the industrial processes.

Neural network-based control systems have successfully been used in the cement (kilns), food (baking), non-ferrous metals (alumina, zinc), pulp and paper (paper stock, lime kiln), petroleum refineries (process, site), and steel industries (electric arc furnaces, rolling mills).

New  energy  management  systems  that  use  artificial  intelligence,  fuzzy  logic  (neural network), or rule-based systems mimic the 'best' controller, by using monitoring data and learning from previous experiences.

Process knowledge based systems (KBS) have been used in design and diagnostics, but are  still  not  widely  used  in  industrial  processes.  KBS  incorporates  scientific  and  process information  and  applies  reasoning  processes  and  rules  in  the  management  strategy.  A recent demonstration project in a sugar beet mill in the UK using model based predictive control  system  demonstrated  a  1.2%  reduction  in  energy  costs,  while  increasing  product yield  by  almost  one percent and reducing off-spec product from 11% to 4%. This system had a simple payback period of 1.4 years (CADDET 2000a).

Research for advanced sensors and controls is ongoing in all sectors, and is funded with both public and private research funds. Several projects within the Advanced Manufacturing Office (formerly known as the Industrial Technologies Program) are attempting to develop more advanced control technologies. Outside the United States, there is much attention in Japan  and  Europe  to  the  development  and  demonstration  of  advanced  controls.  Future steps include further development of new sensors and control systems, demonstrations at a commercial scale, and dissemination of the benefits of control systems in a wide variety of industrial applications.

## 6.2 Raw Materials Preparation

Efficient  Transport  Systems  (Dry  Process). Transport  systems  are  required  to  convey powdered materials such as kiln feed, kiln dust, and finished cement throughout the plant. These  materials  are  usually  transported  by  means  of  either  pneumatic  or  mechanical conveyors.  Mechanical  conveyors  use  less  power  than  pneumatic  systems.  Based  on Holderbank (1993), the average energy savings are estimated at 1.9 kWh/ton raw material (2.0  kWh/tonne)  with  a  switch  to  mechanical  conveyor  systems.  Installation  costs  for  the system are estimated at $2.7/ton raw material production based on the Holderbank study (1993). Operational costs would decrease by about $0.1/ton raw material (Hollingshead and Venta, 2009). Replacing pneumatic conveyors with high capacity bucket elevators for raw material transfer to the preheaters and the blending silos can reduce power consumption by 2/3,  while  the  investment  cost  is  estimated  at  $0.4/ton  raw  material  (Bojdys,  2002).  The replacement  of  pneumatic  conveying  systems  with  mechanical  transport  systems  for  two kiln feeds in two Indian cement plants resulted in energy savings of 0.7-1.3 kWh/ton of raw material  while  the  investment  costs  ranged  between  $0.2  and  $0.9/ton  raw  material (UNFCCC, 2008a). Conversion to mechanical conveyors is cost-effective when replacement of conveyor  systems  is  needed  to  increase  reliability  and  reduce  downtime.  As  the investment  costs  found  in  literature  vary  drastically,  to  determine  the  actual  investment costs and payback period of such a project a site specific assessment is required.

An improved dense phase pneumatic conveying pipe system has shown to offer substantial energy savings, smaller needs in dedusting equipment and lower wear (Dikty et al. 2008). The  bulk  material  is  supplied  through  feeding  devices  (i.e.  pump,  pressure  vessel)  to  a fluidized  conveying  (FLC)  line.  The  conveying  gas  coming  from  the  compressed  air generator is divided into two streams; one gas stream is supplied at the entrance of the FLC pipe, while the other gas stream travels in parallel to the FLC pipe, in a so called aeration pipe, supplying air at several points to the FLC pipe. In this way, the transferred material is raised from the bottom of the pipe and flows into the gas stream in a similar process to an air  activated  gas  conveyor  (AAGC).  The  air  flow  needs  to  be  controlled  in  order  to  avoid blockages. The use of an FLC pipe conveying system instead of a conventional pipe system in  two  cement plants resulted in 38-47% energy savings, while the dedusting air quantity decreased by 61% (Dikty, et al. 2008). Energy savings are estimated at 1.0 kWh/ton raw material.

Raw Meal Blending (Homogenizing) Systems (Dry Process). To produce a good quality product and to maintain optimal and efficient combustion conditions in the kiln, it is crucial that  the  raw  meal  is  completely  homogenized.  Quality  control  starts  in  the  quarry  and continues to the blending silo. On-line analyzers for raw mix control are an integral part of the quality control system (Fujimoto, 1993; Holderbank, 1993).

Improved raw material blending may reduce heat requirements by 0.02 MBtu/ton clinker and power requirements by 0.73 kWh/ton raw material, while production could also increase by 5% (Hollingshead and Venta, 2009). The investment cost  was estimated  at  $1.8/ton  raw material with an additional operational cost of $0.01/ton (Hollingshead and Venta, 2009).

Most  plants  use  compressed  air  to  agitate  the  powdered  meal  in  so-called  air-fluidized homogenizing  silos  (using  1-1.4  kWh/ton  raw  meal).  Older  dry  process  plants  use mechanical  systems,  which  simultaneously  withdraw  material  from  6-8  different  silos  at variable rates (Fujimoto, 1993), using 2-2.4 kWh/ton raw meal. Modern plants use gravitytype  homogenizing  silos  (or  continuous  blending  and  storage  silos)  reducing  power consumption. In these silos, material funnels down one of many discharge points, where it is mixed in an inverted cone. Gravity-type silos may not give the same blending efficiency as air-fluidized  systems.  Although  most  older  plants  use  mechanical  or  air-fluidized  bed systems,  more  and  more  new  plants  seem  to  have  gravity-type  silos,  because  of  the significant  reduction  in  power  consumption  (Holderbank,  1993).  Power  requirements  in modern gravity-type silos (inverted cone or multi outlet) range between 0.1-0.5 kWh/ton raw meal (Chatterjee, 2004; F.L.Smidth, 2007; IBAU HAMBURG, 2009). Multi outlet gravity type silos  have  the  lower  power  consumption  of  about  0.1  kWh/ton  raw  material  (Chatterjee, 2004). Silo retrofit options are cost-effective when the silo can be partitioned with air slides and  divided  into  compartments  which  are  sequentially  agitated,  as  opposed  to  the construction of a whole new silo system (Gerbec, 1999). The energy savings are estimated at  0.5-2.3  kWh/ton  raw  meal  (Fujimoto,  1993;  Holderbank,  1993;  Alsop  &amp;  Post,  1995, Cembureau, 1997; Gerbec, 1999; Chatterjee, 2004). Costs for the silo retrofit are estimated at  $3.3/ton  raw  material  (assuming  $550K  per  silo  and  an  average  capacity  of  150,000 tonnes annual capacity).

Slurry Blending and Homogenizing (Wet Process). In the wet process the slurry is blended and homogenized in a batch process. The mixing is done using compressed air and rotating stirrers. The use of compressed air may lead to relatively high energy losses because of its poor  efficiency.  An  efficiently  run  mixing  system  may  use  0.3-0.5  kWh/ton  raw  material (Cembureau, 1997). The main energy efficiency improvement measures for slurry blending systems are found in the compressed air system (see below under plant-wide measures).

Wash Mills with Closed Circuit Classifier (Wet Process). In most wet process kilns, tube mills  are  used  in  combination  with  closed  or  open  circuit  classifiers.  An  efficient  tube  mill system consumes about 13 kWh/ton (Cembureau, 1997). Replacing the tube mill by a wash mill would reduce electricity consumption to 5-7 kWh/ton (Cembureau, 1997) at comparable investment and operation costs as a tube mill system. When replacing a tube mill a wash mill should be considered as an alternative, reducing electricity consumption for raw grinding by 57 kWh/ton, or 40-60%. Water addition during raw material grinding needs to be controlled in order  to  obtain  slurry  with  a  close  to  optimum  water  content  (32-40%  water  content)  and reduce fuel consumption in the kiln (IPPC, 2010). Chemical additives may be used to reduce water use.

Advanced  Raw  Meal  Grinding  (Dry  Process). Traditional  ball  mills  used  for  grinding certain raw materials (mainly hard limestone) can be replaced by high-efficiency roller mills, by ball  mills  combined with  high-pressure  roller  presses,  or  by  horizontal  roller  mills.  The use of these advanced mills saves energy without compromising product quality. Vertical roller mills, for a medium raw material hardness and medium fineness product, require less energy than 9 kWh/ton (Harder, 2010b). Energy savings of 6 and 7 kWh/ton raw materials (Cembureau, 1997; Hollingshead and Venta, 2009) are assumed through the installation of a vertical or horizontal roller mills. An additional advantage of the inline vertical roller mills is that  they  can  combine  raw  material  drying  with  the  grinding  process  by  using  large quantities  of  low  grade  waste  heat  from  the  kilns  or  clinker  coolers  (Venkateswaran  and Lowitt, 1988). Various roller mill process designs are marketed.

Rollers  are  pressed  down  using  spring  or  hydraulic  pressure  while  hot  gas  is  supplied during  grinding  for  raw  material  drying  (Chatterjee,  2004).  These  air-swept  vertical  roller mills  can  handle  materials  containing  up  to  20%  moisture  while  ball  mills  can  handle moisture levels of about 12% (Chatterjee, 2004). In 1998, Arizona Portland cement (Rillito, Arizona) installed a roller mill for raw material grinding increasing throughput, flexibility, raw meal fineness and reducing electricity  consumption  (De  Hayes,  1999).  In  North  America, LBNL  estimates  that  over  20%  of  raw  grinding  capacity  uses  roller  mills.  Estimates  on investment costs vary widely from $5/ton raw material (Holderbank, 1993) to $24/ton raw material  (Hollingshead  and  Venta,  2009).  Operational  costs  will  decrease  by  $0.20/ton (Hollingshead and Venta, 2009). Vertical roller mills have 10-20% higher capital costs when compared to  ball  mills  (Schneider,  2008).  In  2003,  Ciment  Québec  in  Canada  increased capacity by 50 mtph and improved raw meal fineness by replacing an old vertical roller mill with  a  new  one  (Papillon  et  al.,  2004).  The  investment  cost  for  a  new  grinding  plant  is estimated at $5.6/ton raw material; however the investment cost for a new vertical roller mill (keeping the old plant foundation and peripherals) is estimated at $1.8/tonne raw material (Papillon et al., 2004).

The  use  of  roller  presses  is  limited  to  the  grinding  of  non-abrasive  materials  with  low moisture content. Energy use can be 50% lower when compared to ball mills (Schneider, 2008). According to Chatterjee (2004) with the use of roller presses in combination with a Vseparator,  energy  requirements  can  be  as  low  as  14  kWh/ton  raw  material.  At  the  TXI cement  plant  in  California,  the  replacement  of  the  highly  inefficient  ball  mills  with  highpressure roller presses increased throughput and reduced energy use from 19.1 kWh/ton to 7.8-8.1  kWh/ton  resulting  in  approximately  58%  energy  savings  (Klotz  et  al.,  2009).  The investment cost is estimated at $4.9/ton raw material (Klotz et al., 2009).

With the use of horizontal roller mills (Horomill ® ) energy use can be 50% lower than in ball mills (Schneinder, 2008). If the raw materials have high moisture levels, an external dryer will be required (Schneinder, 2008). In a cement plant in Mexico, electricity use for grinding limestone and clay in a Horomill ®  was reported to range between 6 and 7 kWh/ton of raw material (Wang and Forssbergh, 2003).

Separate Raw Material Grinding (Dry process). Different raw materials are characterized by  different  grindability.  Materials  harder  to  grind,  such  as  sand  and  blast  furnace  slag, require higher amounts of energy to reach the desired particle fineness and decrease the throughput of the combined material grinding system. It can be more efficient to grind the materials with a high proportion in the raw mix in mills with low specific energy use, and the ones harder to grind in vertical roller mills or ball mills (ECRA, 2009).

When  all  materials  are  ground  together,  softer  components  may  be  ground  finer  than required, while harder components may not be sufficiently ground. Separate raw material grinding, will allow a more  precise particle size distribution of different raw meal components,  with  favorable  effects  on  raw  mill  burnability  and  energy  use.  Electricity savings are estimated at 0.55-0.77 kWh/ton raw meal (ECRA, 2009). The investment cost is substantial when a vertical mill is replaced by a ball mill and high pressure grinding rolls, estimated by ECRA (2009) at approximately $15/ton raw material. When two ball mills are already in use, the replacement of one ball mill with high pressure rollers will require a much lower investment (ECRA, 2009). This measure is considered financially sensible when high rates of hard-to-grind materials (i.e. slag) are used.

Raw Meal Process Control (Dry process). The main difficulty with existing vertical roller mills  are  vibration  trips.  Operation  at  high  throughput  makes  manual  vibration  control difficult.  When  the  raw  mill  trips,  it  cannot  be  started  up  for  one  hour,  until  the  motor windings  cool.  A  model  predictive  multivariable  controller  maximizes  total  feed  while maintaining  a  target  residue  and  enforcing  a  safe  range  for  trip-level  vibration.  The  first application eliminated avoidable vibration trips (which were 12 per month prior to the control project). The cited increase in throughput was 6% with a corresponding reduction in specific energy consumption of 6% (Martin and McGarel, 2001b), or 0.8-1.0 kWh/ton of raw material (based on Cembureau, 1997). Vasavadatta Cement, in India, used roller presses for raw meal  grinding.  With  the  installation  of  the  Automation  Expert  System,  by  F.L.Smidth, production increased by 8% while power use decreased by 5%.

High-Efficiency Classifiers/Separators. A recent development in efficient grinding technologies  is  the  use  of  high-efficiency  (third  generation)  classifiers  or  separators. Classifiers separate the finely ground particles and recycle coarse particles back to the mill. High-efficiency  classifiers  can  be  used  in  both  the  raw  materials  mill  and  in  the  finish grinding mill.

Old, first generation classifiers did not make use of fresh air as they were equipped with an internal  fan  and  had  low  separation  efficiencies  of  50-60%.  Second  generation  classifiers (60-75%  separation  efficiency)  have  improved  air  recirculation  and  separate  centrifugal movement.  The  high-efficiency  classifiers  of  the  third  generation,  80-90%  separation efficiency,  have  an  improved  air  distribution  system  and  advanced  control  of  the  air-flow (Chatterjee, 2004).

In high-efficiency classifiers, the material stays longer in the separator, leading to sharper separation, thus reducing overgrinding. Various concepts of high-efficiency classifiers have been developed (Holderbank, 1993; Süssegger, 1993). Electricity savings through implementing high-efficiency classifiers  are  estimated  at  8%  of  the  specific  electricity  use (Holderbank, 1993).

In 1990, Tilbury Cement (Delta, British Columbia, Canada) modified a vertical roller mill with a  high-efficiency  classifier  increasing  throughput  and  decreasing  electricity  use  (Salzborn and Chin-Fatt, 1993). Case studies have shown a reduction of 2.5-3.4 kWh/ton raw material (Salzborn and Chin-Fatt, 1993; Süssegger, 1993). Replacing a conventional classifier with a high-efficiency classifier has led to 15% increases in the grinding mill capacity (Holderbank, 1993;  ECRA,  2009)  and  improved  product  quality  due  to  a  more  uniform  particle  size (Salzborn and Chin-Fatt, 1993), both in raw meal and cement. The better size distribution of the raw meal may lead to fuel savings in the kiln and improved clinker quality. Investment costs are estimated at $2.0/annual ton raw material production (Holderbank, 1993).

## 6.3 Fuel Preparation

Coal is the most widely used fuel in the cement industry. Fuels preparation is most often performed on-site. Fuels preparation may include crushing, grinding and drying of coal. Coal is  shipped  'wet'  to  prevent  dust  formation  and  fire  during  transport.  Passing  hot  gasses through the mill combines the grinding and drying. Coal is the most used fuel in the cement industry, and the main fuel for the vast majority of clinker kilns in the U.S. Most commonly a Raymond bowl mill or a roller mill is used for coal grinding. An impact mill would consume around 45-60 kWh/ton and a tube mill around 25-26 kWh/ton (total system requirements) (Cembureau, 1997). Waste heat of the kiln system (e.g. the clinker cooler) is used to dry the coal if needed.

Other advantages of a roller mill are that it is able to handle larger sizes of coal (no precrushing needed) and coal types with a higher humidity, and can manage larger variations in  throughput.  However,  tube  mills  are  preferred  for  more  abrasive  coal  types.  Currently, roller mills are the most common coal mills in the U.S. cement industry. Coal roller mills are available for throughputs of 5 to 200 tons/hour. Lehigh Portland Cement installed a vertical

roller mill for coal grinding in 1999 at the Union Bridge, Maryland plant. A vertical roller mill was ordered for the new kiln line V at the Roberta plant in Calera, Alabama with a capacity of 37.5 ton/hour.  The mill was commissioned in early 2001. Outside the US, coal grinding roller  mills  can  be  found  in  many  countries  around  the  world,  e.g.  Brazil,  Canada,  China, Denmark,  Germany,  Japan  and  Thailand.  All  major  suppliers  of  cement  technology  offer roller mills for coal grinding.

Vertical  roller  mills,  developed  for  coal  grinding  in  the  cement  industry,  have  been  widely accepted, and have achieved an 86% market share. Electricity consumption for a vertical roller mill is estimated at 16-18 kWh/ton coal (Cembureau, 1997). MPS vertical roller coal mills, currently considered best practice (Worrell et al., 2008a), have low power requirements;  9-33  kWh/ton  anthracite,  5-11  kWh/ton  pit  coal,  7-17  kWh/ton  lignite,  6-15 kWh/ton petroleum coke (Burkhard and York, 2005). The investment costs for a roller mill are typically higher than that of a tube mill or an impact mill, but the operation costs are also lower;  roughly  20%  compared  to  a  tube  mill  and  over  50%  compared  to  an  impact  mill (Cembureau,  1997).  The  replacement  of  tube  mills  with  the  highly  efficient  MPS  vertical roller  mills  will  result  in  14-21  kWh/ton  of  coal  lower  power  consumption  (Burkhard  and York, 2005).

Roller  Press  for  Coal  Grinding. Roller  presses,  like  those  used  for  cement  and  raw material  grinding,  are  generally  more  efficient  than  conventional  grinding  mills.  Roller presses  can  be  used  to  grind  raw  materials  and  coal  interchangeably,  although  coalgrinding  equipment  needs  special  protection  against  explosions.  Penetration  of  roller presses is still relatively low in the U.S.

## 6.4 Clinker production - All Kilns

Process Control &amp; Management Systems - Kilns. Heat from the kiln may be lost through non-optimal  process  conditions  or  process  management.  Automated  computer  control systems  may  help  to  optimize  the  combustion  process  and  conditions  under  a  variety  of fuels. Improved process control will also help to improve the product quality and grindability, e.g. reactivity and hardness of the produced clinker, which may lead to more efficient clinker grinding.  In  cement  plants  across  the  world,  different  systems  are  used,  marketed  by different  manufacturers.  Modern  systems  use  so-called  'fuzzy  logic'  or  expert  control,  or rule-based  control  strategies.  Expert  control  systems  do  not  use  a  modelled  process  to control process conditions, but try to simulate the best human operator, using information from various stages in the process.

One such system, called ABB LINKman, was originally developed in the United Kingdom by Blue  Circle  Industries  and  SIRA  (ETSU,  1988).  The  first  system  was  installed  at  Blue Circle's Hope Works in 1985, which resulted in a fuel consumption reduction of nearly 8% (ETSU, 1988). The LINKman system has successfully been used in both wet and dry kilns. After their first application in 1985, modern control systems now find wider application and can be found in many European plants. Other developers also market 'fuzzy logic' control systems, e.g., F.L. Smidth (Denmark) Krupp Polysius (Germany) and Mitsui Mining (Japan).

All report typical energy savings of 3-8%, while improving productivity and availability. For example Krupp Polysius reports typical savings of 2.5-5%, with similar increased throughput and increased refractory life of 25-100%. Ash Grove implemented a fuzzy control system at the Durkee (OR) plant in 1999.

An  alternative  to  expert  systems  or  fuzzy  logic  is  model-predictive  control  (MPC)  using dynamic  models  of  the  processes  in  the  kiln.  A  model  predictive  control  system  was installed at a kiln in South Africa in 1999, reducing energy needs by 4%, while increasing productivity and clinker quality. The payback period of this project is estimated at 8 months, even  with  typically  very  low  coal  prices  in  South  Africa  (Martin  and  McGarel,  2001a). Several benefits derived from the application of an MPC system on the dry precalciner of a Capitol  Cement  plant  in  Mexico.  The  product  quality  improved,  kiln  operation  stabilized, excess O2 content and NOx emissions decreased, tertiary air temperature increased while product throughput increased (Boe et al., 2005).

Additional process control systems include the use of on-line analyzers that permit operators to instantaneously determine the chemical composition of raw materials being processed in the plant, thereby allowing for immediate changes in the blend of raw materials. A uniform feed  allows  for  more  steady  kiln  operation,  thereby  saving  ultimately  on  fuel  requirements. Blue Circle's St. Marys plant (Canada) installed an on-line analyzer in 1999 in its precalciner kiln, and achieved better process management as well as fuel savings. The installation of a Pavillion process control system in the kiln of Dyckerhoff's site in Germany, increased the feed rate by 4.2%, and stabilized the use of alternative fuels in the kiln beyond 50% of fuel input.

Energy  savings  from  process  control  systems  may  vary  between  2.5%  and  10%  (ETSU, 1988; Haspel and Henderson, 1993; Ruby, 1997), and the typical savings are estimated at 2.5-5%.  According  to  ECRA  (2009),  energy  use  in  a  kiln  that  utilizes  a  process  control system  is  0.04-0.17  MBtu/ton  clinker  lower  when  compared  to  a  kiln  without  a  process control system, while electricity use may also be lower by 0-0.9 kWh/ton. The economics of advanced process control systems are very good and payback periods can be as short as 3 months  (ETSU,  1988).  The  system  at  Blue  Circle's  Hope  Works  (U.K.)  needed  an investment  of  £203,000  (1987),  equivalent  to  $0.3/annual  tonne  clinker  (ETSU,  1988), including measuring instruments, computer hardware and training. ECRA (2009) estimates an investment cost of $0.16-0.22/annual ton clinker. A payback period of 2 years or less is typical  for  kiln  control  systems,  while  often  much  lower  payback  periods  are  achieved (ETSU, 1988; Martin and McGarel, 2001a).

Process control of the clinker cooler can help to improve heat recovery, material throughput, improved control of free lime content in the clinker and reduce NOx emissions (Martin et al., 2000). Installing a Process Perfecter ®  (of Pavilion Technologies Inc.) has increased cooler throughput by 10%, reduced free lime by 30% and reduced energy by 5%, while reducing NOx emissions by 20% (Martin et al., 1999; Martin et al., 2001). The installation costs equal $0.32/annual ton of clinker, with an estimated payback period of 1 year (Martin et al., 2001).

Kiln  Combustion  System  Improvements . Fuel  combustion  systems  in  kilns  can  be contributors  to  kiln  inefficiencies  with  such  problems  as  poorly  adjusted  firing,  incomplete fuel burn-out with high CO formation, and combustion with excess air (Venkateswaran and Lowitt,  1988).  Improved  combustion systems aim to optimize the shape of the flame, the mixing of combustion air and fuel and reducing the use of excess air. Various approaches have been developed. One technique developed in the U.K. for flame control resulted in fuel savings  of  2-10%  depending  on  the  kiln  type  (Venkateswaran  and  Lowitt,  1988).  Lowes, (1990)  discusses  advancements  from  combustion  technology  that  improve  combustion through the use of better kiln control. He also notes that fuel savings of up to 10% have been demonstrated for the use of flame design techniques to eliminate reducing conditions in the clinkering zone of the kiln in a Blue Circle plant (Lowes, 1990).

The  recirculation  of  combustion  gases  from  the  end  of  the  kiln  back  to  the  flame  region improves flame stability and protects the kiln surface from burning particles (Manias, 2004). Internal recirculation can be achieved with a bluff body placed in the center of the burner nozzle or with the use of a swirl in the fuel or the primary air jet stream. Whether the swirl will be used in the primary air or the fuel will depend on the fuel fired. Effective designs of gas firing systems make use of a swirl for both primary air and fuel, typical oil firing systems make  use  of  a  swirl  only  for  primary  air,  while  solid  fuel  firing  systems  do  not  normally require  a  swirl  to  achieve  flame  stability  (Manias,  2004).  Great  care  is  required,  as  high rates  of  recirculation  can  have  adverse  effects  on  fuel  efficiency  and  create  extreme combustion conditions.

A  recent  technology  that  has  been  demonstrated  in  several  locations  is  the  Gyro-Therm technology  that  improves  gas  flame  quality  while  reducing  NOx  emissions.  Originally developed  at  the  University  of  Adelaide  (Australia),  the  Gyro-Therm  technology  can  be applied  to  gas  burners  or  gas/coal  dual  fuel.  The  Gyro-Therm  burner  uses  a  patented "precessing jet" technology. The nozzle design produces a gas jet leaving the burner in a gyroscopic-like precessing motion. This stirring action produces rapid large scale mixing in which pockets of air are engulfed within the fuel envelope without using high velocity gas or air  jets.  The  combustion  takes  place  in  pockets  within  the  fuel  envelope  under  fuel  rich conditions. This creates a highly luminous flame, ensuring good radiative heat transfer. A demonstration project at an Adelaide Brighton plant in Australia found average fuel savings between 5 and 10% as well as an increase in output of 10% (CADDET, 1997a). A second demonstration  project  at  the  Ash  Grove  plant  in  the  U.S.  (Durkee,  Oregon)  found  fuel savings  between  2.7%  and  5.7%  with  increases  in  output  between  5  and  9%  (CADDET, 1998; Videgar et al., 1997). Costs for the technology vary by installation. An average cost of $0.9/annual ton clinker capacity is assumed based on reported costs in the demonstration projects. The average payback period is estimated to less than a year (FCT, 2009).

Mineralized  Clinker. Mineralizers  and  fluxes  are  substances  used  to  improve  raw  mill burnability.  Fluxes  (i.e.  Al O   and  Fe O )  can  lower  the  viscosity  of  the  melt,  and  the 2 3 2 3 temperature at which clinker starts to form. Mineralizers (i.e. fluorine) promote the formation of  clinker.  With  the  use  of  mineralizers,  the  temperature  in  the  sintering  zone  can  be reduced,  resulting  in  less  fuel  consumption.  A  360 o F  (200 o K)  temperature  decrease  can result in 5% fuel savings. Lower sintering temperatures could also decrease the formation of

NOx emissions by 10-15%; with reductions of up to 50% being reported (IPPC, 2010). The use  of  mineralizers  requires  great  care  as  high  mineralizer  quantities  can  decrease  the setting time and the development of early compressive strength in concrete.

Fuel  savings  are  estimated  at  0.04-0.11  MBtu/ton  clinker  while  electricity  requirements could increase by 0-0.9 kWh/ton clinker (ECRA, 2009). The fuel savings can be easily offset by  the  high  costs  of  the  fluxing  agent/mineralizer.  The  use  of  alternative  fuels  with  high fluoride  content  could  be  cost-effective  but  their  availability  is  limited.  No  significant investment is required although usually weigh feeders, and pneumatic conveying equipment will have to be installed (F.L.Smidth, 1995).

In 2004, one plant in North America used fluorspar at a rate of 0.5% CaF2 in combination with potassium sulfate. The outcome was improved kiln operation, lower levels of kiln dust formation and energy savings of 0.10 MBtu/t clinker (Johansen and Bhatty, 2004). In the past, more plants in North America used mineralizers, and although they achieved marginal energy  savings,  increase  in  production  by  5-10%  and  in  some  cases  improved  clinker grindability, they also had to deal with severe coating formation and preheater blockages by volatiles and fines (Bhatty, 1996).

In Europe there are several cement plants successfully producing mineralized clinker (IPPC, 2010). Åalborg Portland, in Denmark, uses a well regulated content of fluoride and gypsum, and achieves 3% energy savings and 50% NOx emission reduction while they produce a highly  hydraulic  reactive  product  which  allows  them  to  substitute  clinker  with  filler  (ESP dust)  at  high  rates  of  up  to  20%  (Borgholm  et  al.,  1996).  Clinker  substitution  results  in significant energy and CO2 emission savings. According to F.L. Smidth energy savings of 0.05-0.11  MBtu/ton  clinker  have  been  achieved  in  several  plants,  while  in  one  case  the energy use for grinding was reduced by 40% (F.L.Smidth, 1995).

There  are  two  ways  to  profit  from  increased  raw  meal  burnability  (Johansen  and  Bhatty, 2004): i)  by  reducing  the  sintering  temperature,  and  ii)  by  maintaining  the  temperature  at previous levels and shortening the retention time. A shorter retention time is equivalent to an increase in throughput, resulting in fuel savings from the decrease in heat losses from the cooler, kiln, and preheater. Incentives for using mineralizers can come from increased production, longer refractory lifetime, preparing coarser raw mix, and the ability to use low cost  fuels  (high  sulfur  content)  (Johansen  and  Bhatty,  2004;  F.L.Smidth,  1995).  The greatest  advantage  though,  is  the  production  of  a  product  characterized  by  increased hydraulic activity that creates a significant potential for clinker substitution (Borgholm et al., 1996).

Indirect Firing. Historically the most common firing system is the direct-fired system. Coal is dried, pulverized and classified in a continuous system, and fed directly to the kiln. This can lead to high levels  of  primary  air  (up  to  40%  of  stoichiometric).  These  high  levels  of primary air limit the amount of secondary air introduced to the kiln from the clinker cooler. Primary  air  percentages  vary  widely,  and  non-optimized  matching  can  cause  severe operational problems with regard to creating reducing conditions on the kiln wall and clinker,

refractory  wear  and  reduced  efficiency  due  to  having  to  run  at  high  excess  air  levels  to ensure effective burnout of the fuel within the kiln.

In  more  modern  cement  plants,  indirect  fired  systems  are  most  commonly  used.  The majority of U.S. plants have indirect firing systems. In these systems, neither primary air nor coal is fed directly to the kiln. All moisture from coal drying is vented to the atmosphere and the  pulverized  coal  is  transported  to  storage  via  cyclone  or  bag  filters.  Pulverized  coal  is then densely conveyed to the burner with a small amount of primary transport air (Smart and  Jenkins,  2000).  As  the  primary  air  supply  is  decoupled  from  the  coal  mill  in  multichannel  designs,  lower  primary  air  percentages  are  used,  normally  between  5  and  10%. Depending on the secondary air temperature, a 5-10% primary air reduction translates into 43-69 kBtu/ton clinker energy savings in conventional cement kilns and about half of this in modern  kilns  (ECRA,  2009).  The  multi-channel  arrangement  also  allows  for  a  degree  of flame optimization. This is an important feature if a range of fuels is fired. Input conditions to the  multi-channel  burner  must  be  optimized  to  secondary  air  and  kiln  aerodynamics  for optimum  operation  (Smart  and  Jenkins,  2000).  The  optimization  of  the  combustion conditions will lead to reduced NOx emissions, better operation with varying fuel mixtures, and reduced energy losses. This technology is standard for modern plants. The investment cost for  the  retrofit  of  a  mono-channel  burner  into  a  multi-channel  burner  is  estimated  by Hollingshead and Venta (2009) at $1.20/annual ton clinker capacity. Energy savings range between  43  and  54  kBtu/ton  clinker  (ECRA,  2009;  Hollingshead  and  Venta,  2009)  while production is reported to increase by 5% (Hollingshead and Venta, 2009).

Excess  air  infiltration  is  estimated  to  result  in  heat  losses  equal  to  65  kBtu/ton  (75 MJ/tonne).  Assuming  a  reduction  of  excess  air  between  20%  and  30%  may  lead  to  fuel savings of 130-190 kBtu/ton of clinker. The advantages of improved combustion conditions will lead to a longer lifetime of the kiln refractories and reduced NOx emissions. These cobenefits may result in larger cost savings than the energy savings alone.

The disadvantage of an indirect firing system is the additional capital cost. The investment to  switch  from  a  direct  to  an  indirect  firing  system  is  estimated  at  $8.4/annual  ton  clinker capacity (Hollingshead and Venta, 2009). The result will be a reduction in fuel use by 162 kBtu/ton  clinker  and  an  increase  in  production  by  10%,  while  power  use  is  expected  to increase by 0.5 kWh/ton clinker due to the power needs of conveyor blowers, high pressure fans  and  dust  collectors  (Hollingshead  and  Venta,  2009).  In  1997  CalPortland's  plant  in Colton  (California)  implemented  an  indirect  firing  system  for  their  plant,  resulting  in  NOx emission reductions of 30-50%, using a mix of fuels including tires. The investment costs of the  indirect  firing  system  were  $5  million  for  an  annual  production  capacity  of  680,000 tonnes.

Oxygen Enrichment. Several plants in the U.S. have experimented with the use of oxygen enrichment  in  the  kiln  to  increase  production  capacity.  Several  plants  use  it  to  increase production if the local market demand for cement can justify the additional costs for oxygen purchase  or  production.  Experience  exists  with  wet  (e.g.  TXI,  Midlothian,  Texas)  and  dry process  kilns  (e.g.  CPC,  Mojave,  California;  Cemex,  Victorville,  California).  Production increases of around 3-10% have been found on the basis of annual production (Mayes, 2001;

Gotro,  2001;  Staudt,  2009a),  while  according  to  a  number  of  short  term  experiments,  an oxygen enrichment of 30-35% resulted in 25-50% increase in cement kiln capacity (ECRA, 2009). In one facility a 3-5% decrease in fuel use was reported (Staudt, 2009a). According to ECRA (2009), energy savings in the range of 86-172 kBtu/ton clinker may result, while power use is expected to increase by 9-32 kWh/ton clinker. Any energy savings will depend on the electricity  consumed  for  oxygen  generation  (approximately  0.01  kWh/scf)  (Shafer,  2001). Oxygen enrichment is unlikely to result in net energy savings. Also, if the injection process is not carefully managed higher NOx emissions may result (Mayes, 2001). The investment cost for an oxygen enrichment system, based on a 2 million tonne per year clinker capacity plant, is  estimated  at  $3.2-6.3/ton  clinker  (ECRA,  2009;  Staudt,  2009a).  Although  some  authors claim fuel savings due to oxygen enrichment (Leger and Friday, 2001), others do not report net energy savings (Shafer, 2001; Gotro, 2001).

Mixing  Air  Technology  (MAT) .  The  injection  of  a  high-pressure  air  stream  into  the  kiln results in improved mixing of the stratified gas layers created within the kiln. The result is improved burnability, reduced fuel use, lower emissions and improved kiln stability (Staudt, 2009b). Mixing air technology, developed by Cadence, can be used in combination with Mid Kiln Firing or Riser Duct Firing system. Typically, a Mid Kiln Firing system can replace about 15% of  heat  requirements  with  alternative  fuels.  Further  alternative  fuel  replacement  will lower  the  flame  temperature  and  jeopardize  the  production  of  high  quality  clinker.  When MAT is adopted, the alternative fuel substitution rate can increase by another 15% in long kilns, 8% in preheater kilns, and 4% in precalciner kilns (Cadence, 2010a; Cadence 2010b). MAT can also be beneficial without Mid Kiln Firing. MAT can decrease NOx emissions by facilitating  staged  combustion,  SO2  emissions  by  improving  oxidizing  conditions  in  areas where there is  ample  free  lime,  CO  emissions  and  CO2  emissions  as  the  kiln  output  will slightly increase. The investment cost is estimated at $1.1/ton clinker (assuming $520,000 per kiln and an average kiln capacity of 440,000 tonnes). Fixed annual costs will be similar to  that  of  a  low  NOx  burner.  Power  use  may  increase  by  0.023  kWh/ton  clinker  (Staudt, 2009b). Improved heat transfer can reduce heat demand by 5% in preheater kilns and by 01%  in  precalciner  kilns  (Cadence,  2010b).  MAT  is  mainly  installed  in  wet,  long  dry  and preheater kilns and although not very common, MAT can also be installed in precalciners to facilitate staged combustion (Staudt, 2009b).

Seals. Seals are used at the kiln inlet and outlet to reduce false air penetration, as well as heat losses. Seals may start leaking, increasing the heat requirement of the kiln. Most often pneumatic and lamella-type seals are used, although other designs are available (e.g. springtype). Although seals can last up to 10,000 to 20,000 hours, regular inspection is prudent to control leaks. Energy losses resulting from leaking seals may vary, but are generally relatively small.  Philips  Kiln  Services  reports  that  upgrading  the  inlet  pneumatic  seals  at  a  relatively modern plant in India (Maihar cement), reduced fuel consumption in the kiln by 0.4% (or 0.01 MBtu/ton clinker) (Philips Kiln Services, 2001). The payback period for improved maintenance of kiln seals is estimated at 6 months or less (Canadian Lime Institute, 2001).

Kiln Shell Heat Loss Reduction. There can be considerable heat losses through the shell of  a  cement  kiln,  especially  in  the  burning  zone.  The  use  of  better  insulating  refractories (e.g. Lytherm) can reduce heat losses (Venkateswaran and Lowitt, 1988). Refractory choice

is the function of insulating qualities of the brick and the ability to develop and maintain a coating. The coating helps to reduce heat losses and to protect the burning zone refractory bricks. Estimates suggest that the development of high-temperature insulating linings for the kiln  refractories  can  reduce  fuel  use  by  0.1-0.34  MBtu/ton  (Lowes,  1990;  COWIconsult, 1993; Venkateswaran and Lowitt, 1988). Case studies from three cement plants in China have  reported  energy  savings  of  0.35-0.54  MBtu/ton  clinker  (ITIBMIC,  2004).  Costs  for insulation systems are estimated to be $0.23/annual ton clinker capacity (Lesnikoff, 1999). Structural considerations may limit the use of new insulation materials. The use of improved kiln-refractories  may  also  lead  to  improved  reliability  of  the  kiln  and  reduced  downtime, reducing production costs considerably, and reducing energy needs during start-ups.

Preheater Shell Heat Loss Reduction. The outer part of the upper preheater vessels and the  cooler  housing  can  also  be  insulated.  The  energy  savings  are  estimated  at  about  17 kBtu/ton clinker, at an investment cost of $0.30/ton (Hollingshead and Venta, 2009).

Refractories. Refractories protect the steel kiln shell against heat, chemical and mechanical  stress.  The  choice  of  refractory  material  depends  on  the  combination  of  raw materials, fuels and operating conditions. Extended lifetime of the refractories will lead to longer operating periods and reduced lost production time between relining of the kiln, and, hence, offset the costs of higher quality refractories (Schmidt, 1998; van Oss, 2002). It will also  lead  to  additional  energy  savings  due  to  the  relative  reduction  in  start-up  time  and energy costs. An investment cost of $0.60/ton clinker is estimated to reduce energy use by 54 kBtu/ton clinker (Hollingshead and Venta, 2009).

Kiln Drives. A substantial amount of power is used to rotate the kiln. In the U.S. mostly synchronous motors are used (Regitz, 1996) up to 1,000 hp. The highest efficiencies are achieved using a single pinion drive with an air clutch and a synchronous motor (Regitz, 1996). The system would reduce power use for kiln drives by a few percent, or roughly 0.5 kWh/ton clinker at slightly higher capital costs (+6%).

More recently, the use of AC motors is advocated to replace the traditionally used DC drive. The  AC  motor  system  may  result  in  slightly  higher  efficiencies  (0.5-1%  reduction  in electricity use of the kiln drive) and has lower investment costs (Holland, 2001). Using highefficiency  motors  to  replace  older  motors  instead  of  re-winding  old  motors  may  reduce power costs by 2 to 8% (see below).

Adjustable Speed Drive for Kiln Fan. Adjustable or variable speed drives (ASDs) for the kiln fan result in reduced power use and reduced maintenance costs. The use of ASDs for a kiln fan at the Hidalgo plant of Cruz Azul Cement in Mexico resulted in improved operation, reliability  and  a  reduction  in  electricity  consumption  of  almost  40%  (Dolores  and  Moran, 2001) of the 1,000 hp motors. The replacement of the damper by an ASD was driven by control and maintenance problems at the plant. The energy savings may not be typical for all plants, as the system  arrangement  of  the fans was  different from typical kiln arrangements. For example, Fujimoto, (1994) notes that Lafarge Canada's Woodstock plant replaced their kiln fans with ASDs and reduced electricity use by 5 kWh/ton.

Conversion to Efficient Clinker Cooler Technology. Four main types of coolers are used in the cooling  of clinker: shaft, rotary, planetary,  travelling (2 nd generation)  and  modern reciprocating grate coolers (3 rd  generation. There are no longer any rotary or shaft coolers in operation in North America. However, some travelling grate coolers may still be in operation. In the U.S., planetary and grate coolers are the coolers of choice. Cembureau (1997) provides data on cooler types for U.S. cement plants. Plants that responded to the Cembureau survey (92% of plants) indicated that 6% of the industry still utilized planetary or rotary coolers.

The grate cooler is the modern variant and is used in almost all modern kilns. The advantages of  the  grate  cooler  are  its  large  capacity  (allowing  large  kiln  capacities)  and  efficient  heat recovery (the temperature of the clinker leaving the cooler can be as low as 83°C, instead of 120-200°C, which is expected from planetary coolers (Vleuten, 1994). Tertiary heat recovery (needed for  pre-calciners)  is  impossible  with  planetary  coolers  (Cembureau,  1997),  limiting heat recovery efficiency. Grate coolers recover more heat than do the other types of coolers. For large capacity plants, grate coolers are the preferred equipment. For plants producing less than 500 tonnes per day the grate cooler may be too expensive (COWIconsult et al., 1993). Replacement of planetary coolers by grate coolers is not uncommon (Alsop and Post, 1995). Grate coolers are standard technology for modern large-scale kilns.

Modern reciprocating  grate  coolers  (3 rd   generation)  have  a  higher  degree  of  heat  recovery (70-75%  heat  recuperation  efficiency)  than  existing  grate  coolers  (2 nd   generation)  (50-65% heat recuperation efficiency), while they also reduce fluctuations in recuperation efficiency (i.e. increasing  productivity  of  the  kiln)  (ECRA,  2009).  When  compared  to  planetary  or  rotary coolers, additional heat recovery is possible with grate coolers at an extra power consumption of  0.9  to  5.4  kWh/ton  clinker  (COWIconsult  et  al.,  1993;  Vleuten,  1994;  ECRA,  2009; Hollingshead  and  Venta,  2009).  The  savings  are  estimated  to  be  up  to  8%  of  the  fuel consumption in the kiln (Vleuten, 1994). Cooler conversion is generally economically attractive only when installing a precalciner, which is necessary to produce the tertiary air (see above), or when expanding production capacity. Depending on the degree of reconstruction needed (new exhaust fan, shortening of the kiln, new cooler filters) investment costs may vary widely. The cost of converting  a  planetary  cooler  into  an  efficient  reciprocating  grate  cooler  of  the latest  generation,  with  a  6,600  tons/day  capacity,  is  estimated  by  ECRA  (2009)  at  $9.412.6/ton  clinker.  Hollingshead  and  Venta  (2009)  estimate  the  investment  cost  at  $10/ton clinker.  Annual  operation  costs  increase  by  $0.5-0.2/ton  clinker  (Jaccard  and  Willis,  1996; Hollingshead and Venta, 2009; ECRA, 2009) while a 20% increase in throughput is expected (Hollingshead and Venta, 2009).

In recent years several new concepts of clinker coolers have been introduced. The Cross-Bar Cooler, 4 th generation, developed by F.L.Smidth, has a completely static grate floor and the clinker travels from the one side of the cooler to the other via moving thrust bars. Other clinker coolers based on similar principles are the Polytrack developed by Polysius, the Eta Cooler by Claudius Peters and the Pyrofloor cooler by KHD. One of the latest developments in clinker coolers, 5 th generation, was developed in 2010 by CemProTec and it consists of a revolving disc instead of traveling grates. This new type of clinker cooler, although not yet proven in fullscale, can achieve 100% transport efficiency and is characterized by lower wear.

Optimization  of  Heat  Recovery/Upgrade  Clinker  Cooler. The  clinker  cooler  drops  the clinker temperature from 1200°C down to 100°C. The most common cooler designs are of the planetary (or satellite), traveling and reciprocating grate type. In the U.S. 94% of coolers in  1994  were  grate  coolers.  All  coolers  heat  the  secondary  air  for  the  kiln  combustion process  and  sometimes  also  tertiary  air  for  the  precalciner  (Alsop  and  Post,  1995). Reciprocating grate coolers are the modern variant and are suitable for large-scale kilns (up to  10,000  tpd).  Grate  coolers  use  electric  fans  and  excess  air.  The  highest  temperature portion of the remaining air can be used as tertiary air for the precalciner. Rotary coolers (used for approximately 5% of the world clinker capacity for plants up to 2,200-5,000 tpd) and planetary coolers (used for 10% of the world capacity for plants up to 3,300-4,400 tpd) do not need combustion air fans and use little excess air, resulting in relatively lower heat losses (Buzzi and Sassone, 1993; Vleuten, 1994).

Grate coolers may recover between 1.1 and 1.4 MBtu/ton clinker sensible heat (Buzzi and Sassone, 1993). Improving heat recovery efficiency in the cooler results in fuel savings, but may  also  influence  product  quality  and  emission  levels.  Heat  recovery  can  be  improved through reduction of excess air volume (Alsop and Post, 1995), control of clinker bed depth and new grates such as ring grates (Buzzi and Sassone, 1993; Lesnikoff, 1999). Control of cooling air distribution over the grate may result in lower clinker temperatures and high air temperatures.  Additional  heat  recovery  results  in  reduced  energy  use  in  the  kiln  and precalciner,  due  to  higher  combustion  air  temperatures.  Hollingshead  and  Venta  (2009) estimate the energy savings from upgrading an old clinker cooler at 0.08 MBtu/ton clinker, corresponding  to  an  increase  in  throughput  of  4%.  The  cost  for  retrofitting  an  old  grate cooler  to  a  modern  reciprocating  grate  cooler  is  estimated  at  $0.6-1.8/annual  ton  clinker capacity (ECRA, 2009; Hollingshead and Venta, 2009).

A recent innovation in clinker coolers is the installation of a static grate section at the hot end  of  the  clinker  cooler.  This  has  resulted  in  improved  heat  recovery  and  reduced maintenance of the cooler. Modification of the cooler would result in improved heat recovery rates of 2-5% over a conventional grate cooler. In a cement plant in India, the replacement of a number of the jet ring coolers with static grate coolers achieved energy savings of 0.08 MBtu/ton clinker (Goyenka et al., 2000). Investments are estimated at $0.1-0.3/annual ton clinker capacity (Young, 2002).

## 6.5 Clinker Production - Wet Process Kilns

Wet Process Conversion to Semi-Dry Process (Slurry Drier). In modernized wet kilns, a slurry drier can be added to dry the slurry before entering the kiln using waste heat from the kiln  (Cembureau,  1997).  This  reduces  energy  consumption  considerably  and  increases productivity. This is different from a semi-wet process as a gas drier is used instead of a slurry press filter. The drier can be combined with a hammer mill for a reliable and efficient disagglomeration  and  drying  system  (Grydgaard,  1998).  Gas  suspension  driers  are  also considered, but no installation has been built yet (Grydgaard, 1998). Gas suspension driers could increase drying efficiency and potentially reduce fuel consumption in the kiln by up to 1.4 MBtu/ton clinker (Grydgaard, 1998). The principal of preheating/drying is similar to the semi-dry process (or Lepol kiln) although, in the semi-dry process dry raw meal (10-12%

water)  is  used  instead  of  slurry  (28-48%  water).  The  Lepol  kiln  uses  a  traveling  grate preheater, and uses dry raw material grinding, followed by a pelletizer that mixes water with the dry meal to form pellets that can be carried by the traveling grate into the rotary kiln. The size of the pellets also determines the size of clinker pellets. Cement plants employing the semi-dry process can be advantageous when they need to process raw materials with high moisture content or raw materials that contain high levels of sulphur that would in case of a dry  process  plant,  require  a  complex  gas  scrubbing  system  (Harder,  2010a).  The  energy needs for water evaporation in a wet process kiln are estimated at over 2 MBtu/ton clinker (Worrell  et  al.,  2001).  For  comparison,  a  Lepol  kiln  consumes  about  a  quarter  of  that  for evaporation, while increasing electricity use by approximately 5-7 kWh/ton clinker (Cembureau, 1997). Evaporation energy needs can be cut in half by adding a slurry drier, reducing fuel consumption by 1 MBtu/ton clinker. Net energy savings are estimated at 0.95 MBtu/ton.

The first plant that coupled a drier directly to the kiln was put in operation in 1982 in Sutham, England  (Grydgaard,  1998).  The  first  plant  in  the  U.S.  to  apply  the  semi-dry  process  is Lonestar's Greencastle, Indiana, plant, almost doubling its production capacity to 1.7 million tonnes  per  year  (Anon.,  2001).  No  recent  estimates  of  the  costs  of  adding  a  slurry  drier (including  waste  heat  distribution)  to  an  existing  wet  process  kiln  were  available  for  this study.

Wet Process Conversion to Semi-Wet Process (Filter Press System). In the wet process the slurry typically contains 36% water (range of 24-48%). A filter press can be installed in a wet  process  kiln  in  order  to  reduce  the  moisture  content  to  about  20%  of  the  slurry  and obtain  a  paste  ready  for  extrusion  into  pellets  (COWIconsult  et  al.,  1993;  Venkateswaran and Lowitt, 1988). In the U.S. several plants have tried slurry filters, but have not been very successful.  Additional  electricity  consumption  is  3-5  kWh/ton  clinker  (COWIconsult  et  al., 1993).  In  this  analysis  it  is  assumed  that  energy  use  increases  by  4  kWh/ton  clinker  to reduce  the  moisture  content  to  20%.  The  corresponding  fuel  savings  are  1.0  MBtu/ton (COWIconsult et al., 1993). Hollingshead and Venta (2009) estimated the energy savings at 0.64  MBtu/ton  clinker.  Jaccard  and  Willis  (1996)  estimate  the  conversion  cost  to  run $1.6/annual ton clinker capacity with increased operation costs of $0.1/ton clinker (Jaccard and Willis, 1996). In another study (Hollingshead and Venta, 2009), the investment cost for filter  presses  and  conveyer  equipment  is  estimated  at  $3.70/ton  clinker  while  $0.20/ton clinker are the additional operating costs.

Wet Process Conversion to Pre-heater/Pre-calciner Kiln. If  economically feasible a wet process  kiln  can  be  converted  to  a  state-of-the  art  dry  process  production  facility  that includes either a multi-stage preheater, or a pre-heater/pre-calciner. Average specific fuel consumption in U.S. wet kilns is estimated at 5.8 MBtu/ton clinker. Studies of several kiln conversions  in  the U.S.  in the 1980s  found  fuel  savings  of  2.9 MBtu/ton  or  less (Venkateswaran and Lowitt, 1988). In Hranice (Czech Republic) a 1,050 tonne per day wet process plant was converted to a dry kiln plant with a new kiln specific fuel consumption of 2.7 MBtu/ton clinker (Anon., 1994b). Fuel savings of 2.7 MBtu/ton clinker and an increase in power use of about 9 kWh/ton clinker (Vleuten, 1994) are assumed. In 2006, Padeswood Works (UK) replaced two wet kilns, with a preheater precalciner kiln and reduced energy

use by 1.9 MBtu/ton clinker (IPPC, 2010). Energy savings could be higher if waste was not used as fuel. The cost of converting a wet plant to a dry process plant may be high, as it involves the demolition and reconstruction of an existing facility, except for half of the kiln. Costs  may  vary  between  $50/annual  ton  clinker  capacity  and  $100/annual  ton  clinker capacity  (van  Oss,  1999;  Nisbet,  1996).  Hollingshead  and  Venta  (2009),  estimate  the investment  required  for  installing  preheaters/precalciner,  new  vertical  raw  mill  and  new cooler, at $155/ton clinker. Due to improvements in grinding (new mill), electricity use will decrease by 15 kWh/ton clinker. Clinker production is expected to increase by 50%.

## 6.6 Clinker Production - Dry Process Kilns

Low  Pressure  Drop  Cyclones  for  Suspension  Preheaters. Cyclones  are  a  basic component of plants with pre-heating systems. The installation of newer cyclones in a plant with lower pressure losses will reduce the power consumption of the kiln exhaust gas fan system. Depending on the efficiency of the fan, 0.6-0.7 kWh/ton clinker can be saved for each 50 mm W.C. (water column) the pressure loss is reduced. For older kilns this amounts to savings of 0.6-1.4 kWh/ton (Birch, 1990; ECRA, 2009). Electricity savings of 3 kWh/ton clinker and an increase in capacity of 3% have also been reported (Hollingshead and Venta, 2009). Fujimoto (1994) discussed a Lehigh Cement plant retrofit in which low-pressure drop cyclones  were  installed  in  their  Mason  City,  Iowa  plant  and  saved  4  kWh/ton  clinker (Fujimoto, 1994). Installation of the cyclones can be expensive, however, since it may often entail the rebuilding or the modification of the preheater tower, and the costs are very site specific.  Also,  new  cyclone  systems may increase overall dust loading and increase dust carryover  from  the  preheater  tower.  However,  if  an  inline  raw  mill  follows  it,  the  dust carryover problem becomes less of an issue. The investment cost for replacing 3 cyclone stages  was  estimated  by  ECRA  (2009)  at  $5.0-6.3/annual  ton  clinker  capacity  while  in another study (Hollingshead and Venta, 2009), the cost for replacing the inlet and the outer cyclones  was  estimated  at  $3.5/annual  ton  clinker.  The  replacement  of  older  preheaters with low pressure drop preheaters can be economically sensible when the preheater tower does not have to be rebuilt (ECRA, 2009).

Heat Recovery for Power Generation. Waste gas discharged from the kiln exit gases, the clinker  cooler  system,  and the kiln  pre-heater system all contain  useful  energy that  can be used for raw material and fuel drying or for power generation. Heat recovery for cogeneration can result in significant electricity savings of up to 30% and primary energy savings of up to 10% (Khurana et al., 2002; Engin and Ari, 2005; VDZ and PENTA, 2008). Cogeneration has limited application for plants with in-line raw mills, as the heat in the kiln exhaust is used for raw material drying. In addition, the excess heat availability will depend on seasonal rainfall and  geology  (IPPC,  2010).  Only  in  long-dry  kilns  is  the  temperature  of  the  exhaust  gas sufficiently high, to cost-effectively recover the heat for power generation via a conventional power generating system. 12   Steam  cogeneration  systems  can  either  be  direct  gas  turbines

12 Technically, Organic Rankine Cycles or Kalina cycles (using a mixture of water and ammonia) can be used to recover low-temperature waste heat for power production, but this is currently not economically attractive, except for locations with high power costs.

that utilize the waste heat (top cycle), or the installation of a waste heat boiler system that runs a steam turbine system (bottom cycle). Other bottom cycle cogeneration systems include the Organic Rankine Cycle (ORC) (also referred to as ORMAT energy converter [OEC]) where a refrigerant is used instead of water, with a boiling point much lower than water, and the Kalina Cycle. ORC and Kalina Cycles can operate efficiently at low and moderate heat temperatures (Börrnert, 2011; Carolyn, 2009). Steam turbine systems have been installed in many plants worldwide and have proven to be economic (Steinbliss, 1990; Jaccard and Willis, 1996; Neto, 1990).  While  electrical  efficiencies  are  still  relatively  low  (up  to  20-25%),  based  on  several case  studies  power  generation  may  vary  between  10  and  23  kWh/ton  clinker  (Scheur  &amp; Sprung, 1990; Steinbliss, 1990; Neto, 1990, ECRA, 2009); approximately 7-9 kWh/ton clinker from the cooler's waste air and 8-11 kWh/ton clinker from the kiln gases (ECRA, 2009). In China, higher power generation levels of 22-36 kWh/ton clinker are obtained with supplementary  fired  boilers  (VDZ  and  PENTA,  2008).  For  a  waste  heat  recovery  system electricity savings of 20 kWh/ton clinker are assumed. ECRA (2009) estimates the investment costs of a waste heat power generation unit for a 2 million tonne per year clinker producing facility  at  $9-16/ton  clinker.  Operational  costs  are  estimated  to  decrease  by  $0.4-1.5/ton clinker. A 4,100 tpd four stage preheater cement plant in India installed an 8 MW waste heat recovery  power  plant  with  a  capital  investment  of  $19  million  (VDZ  and  PENTA,  2008).  In 2010, 3 U.S. cement plants generated 226 million kWhs (USGS, 2012a).

The more efficient the clinker kiln, the lower temperature the waste gases will be. For a 6stage pre-heater kiln, exhaust gases can be significantly below 572 o F (300 o C) (Börrnert and Bürki, 2010). The varying temperature of grate cooler exhaust air, ranging between 330-560 o F (165-304 o C), results in complications in operation of the steam turbines. It has been observed that in order to overcome this, exhaust air temperatures are raised by adding extra fuel in the kilns, increasing the specific energy use to unacceptable levels (Bronicki, no date; Legmann and Citrin, 2004). ORC systems can operate with waste heat temperatures lower than 200 o F (93 o C) (Carolyn, 2009). An example of successful application of ORC in the cement industry is  the  Heidelberg  Cement  plant  in  Lengfurt,  Germany,  where  unused  waste  heat  from  the grate cooler 572 o F (300 o C) is used to generate 1,300 kW  of electricity, satisfying approximately 10% of the plant's electricity needs and reducing CO2 emissions by 7,000 tons per year (Bronicki, no date). A new ORC plant, is currently under construction in Switzerland, and  is  expected  to  generate  20%  of  the  plant's  electricity  requirements  by  utilizing  waste gases from the pre-heater and the clinker cooler (Börrnert,  2011).  As  reported  by  Börrnert (2011) an additional benefit will be the reduction in water use, by stopping the water spraying in the conditioning tower; pre-heater gases will now be cooled by the heat exchanger in the power  plant.  ORC  and  Kalina  Cycles  can  generate  1.3-1.7  times  more  electricity  than conventional steam  systems  (Bell, 2007) however,  they are characterized by higher investment  costs.  Investment  costs  for  Organic  Rankine  Cycle  systems  are  estimated  at $1,300-4,000/kW  and  for  Kalina  Cycle  systems  at  $1,100-3,000/kW  (Carolyn,  2009;  Bell, 2007; Mirolli,  2005).  A  Rankine cycle power plant would cost about $1,100-1,400/kW (Bell, 2007).

Dry Process Conversion to Multi-Stage Preheater Kiln. Older dry kilns may only preheat in  the  chain  section  of  the  long  kiln,  or  may  have  single-  or  two-stage  preheater  vessels.

Especially, long dry kilns may not have any preheater vessels installed at all. This leads to a low  efficiency  in  heat  transfer  and  higher  energy  consumption.  Installing  multi-stage suspension  preheating  (i.e.  four-  or  five-stage)  may  reduce  the  heat  losses  and  thus increase  efficiency.  Modern  cyclone  or  suspension  preheaters  also  have  a  reduced pressure drop, leading to increased heat recovery efficiency and reduced power use in fans (see low pressure drop cyclones above). By installing new preheaters, the productivity of the kiln will increase, due to a higher degree of pre-calcination (up to 30-40%) as the feed enters the kiln. Also, the kiln length may be shortened by 20-30% thereby reducing radiation losses  (van  Oss,  1999).  As  the  capacity  increases,  the  clinker  cooler  may  have  to  be adapted to be able to cool the large amounts of clinker.

The conversion of older kilns is attractive when the old kiln needs replacement and a new kiln  would  be  too  expensive,  assuming  that  limestone  reserves  are  adequate.  Energy savings depend strongly on the specific energy consumption of the dry process kiln to be converted as well as the number of preheaters to be installed (see Table 1). For example, cement kilns in the former German Democratic Republic were rebuilt by Lafarge to replace four dry process kilns originally constructed in 1973 and 1974. In 1993 and 1995 three kilns were equipped with four-stage suspension preheaters. The specific fuel consumption was reduced from 3.5 MBtu/ton to 3.1 MBtu/ton clinker, while the capacity of the individual kilns was increased from 1650 to 2500 tpd (Duplouy and Trautwein, 1997). In the same project, the power consumption was reduced by 25%, due to the replacement of fans and the finish grinding mill. Energy savings are estimated at 0.8 MBtu/ton clinker for the conversion which reflects the difference between the average dry kiln specific fuel consumption and that of a modern  preheater  kiln,  based  on  a  study  of  the  Canadian  cement  industry  (Holderbank, 1993).  The  study  estimates  the  specific  costs  at  $36-37  US/annual  ton  capacity  for conversion  to  a  multi-stage  preheater  kiln  while  Vleuten  (1994)  estimates  a  cost  of $25/annual ton clinker capacity for the installation of suspension pre-heaters.

Turning a long-dry kiln into a preheater kiln would result in even higher fuel savings of about 1.4  MBtu/ton  clinker  while  it  would  decrease  the  operational  and  maintenance  costs  by $0.10/ton  (Hollingshead  and  Venta,  2009).  Hollingshead  and  Venta  (2009)  estimated  the investment  costs  for  a  new  pyroline  (half  kiln)  and  minor  improvements  of  the  grinding system at $105/annual ton clinker.

Increase  the  Number  of  Preheater  Stages .  The  addition  of  a  preheater  stage  will  not always result in system energy savings. The optimum number of stages is determined by the moisture content of the fuel and raw materials that needs to be dried. When the raw materials'  moisture  content  is  above  8%,  the  drying  heat  requirements  are  high  and  it  is more cost- and energy-effective to operate the kiln with a 4 or even a 3-stage preheater (Bolwek  et  al.,  2006).  A  kiln  with  a  3-stage  preheater  will  use  over  0.2  MBtu/ton  more energy than a 5-stage preheater (see Table 1) however, by using the heat from exit gases for material drying, plant's efficiency will not be affected (Bolwek et al., 2006).

According to Hollingshead and Venta (2009) the energy savings for increasing from a 5- to a 6-stage preheater are around 0.12 MBtu/ton clinker while production will increase by 3%. The investment cost was estimated at $15/annual ton clinker, including the costs for exit

duct modifications and tower structural improvements. In another study (ECRA, 2009) the costs  for  adding  two  preheater  stages  were  estimated  at  $2-5/annual  ton  clinker  without including  the  site  specific  costs  that  concern  tower  modification  or  rebuilding  or  fan replacements. Vikram Cement in India added a sixth preheater stage to its preheater kiln and  saved  0.1  MBtu/ton  clinker  (0.111  GJ/tonne)  while  electricity  use  increased  by  1.1 kWh/ton. The capital costs were $2.6 per ton clinker (19.RMB/t clinker) (UNFCCC, 2008b). Adding  a  preheater  stage  can  be  a  considerable  rebuild  for  a  cement  plant,  and  the adoption of such an energy efficiency measure could trigger permit adaptation, require new source review and extra measures in order to meet the BACT requirements.

Installation  or  Upgrading  of  a  Preheater  to  a  Preheater/Precalciner  Kiln. An existing preheater  kiln  may  be  converted  to  a  multi-stage  preheater  precalciner  kiln  by  adding  a precalciner  and,  when  possible  an  extra  preheater.  The  addition  of  a  precalciner  will generally  increase  the  capacity  of  the  plant,  while  lowering  the  specific  fuel  consumption and  reducing  thermal  NOx  emissions  (due  to  lower  combustion  temperatures  in  the  precalciner). Using as many features of the existing plant and infrastructure as possible, special precalciners have been developed by various manufacturers to convert existing plants, e.g. Pyroclon ® -RP by KHD in Germany. Generally, the kiln, foundation and towers are used in the  new  plant,  while  cooler  and  preheaters  are  replaced.  Cooler  replacement  may  be necessary  in  order  to  increase  the  cooling  capacity  for  larger  production  volumes.  The conversion of a plant in Italy, using the existing rotary kiln, led to a capacity increase of 80100% (from 1100 tpd to 2000-2200 tpd),while reducing specific fuel consumption from 3.06 to 2.63-2.74 MBtu/ton clinker, resulting in savings of 11-14% (Sauli,1993). Fuel savings will depend strongly on the efficiency of the existing kiln and on the new process parameters (e.g. degree of precalcination, cooler efficiency).

Older calciners can also be retrofitted for energy efficiency improvement and NOx emission reduction. Retrofitting the pre-calciner at the Lengerich  plant  of Dyckerhoff  Zement (Germany)  in  1998  reduced  NOx  emissions  by  almost  45%  (Mathée,  1999).  Similar emission reductions have been found at kilns in Germany, Italy and Switzerland (Menzel, 1997).  Ash  Grove's  Durkee,  Oregon  original  1979  plant  installed  new  preheaters  and  a precalciner  in  1998,  expanding  production  from  1700  tons/day  to  2700  tons/day  (Hrizuk, 1999). The reconstruction reduced fuel consumption by 0.14-0.6 MBtu/ton clinker (Hrizuk, 1999),  while  reducing  NOx  emissions.  Capitol  Cement  (San  Antonio,  Texas)  replaced  an older in-line calciner with a new downdraft calciner to improve production capacity. This was part of a larger project replacing preheaters, installing SOx emission reduction equipment, as well as increasing capacity of a roller mill. The new plant was successfully commissioned in  1999.  Fuel  consumption  at  Capitol  Cement  was  reduced  to  2.89  MBtu/ton  of  clinker (Fraily &amp; Happ, 2001).

Average savings of new calciners can be 0.34 MBtu/ton clinker (Sauli, 1993). Sauli (1993) does not outline the investments made for the conversion project. Vleuten (1994) estimates the cost of adding a precalciner and suspension preheaters at $28 US/annual tonne annual capacity (it is not clear what is included in this estimate). Jaccard and Willis (1996) estimate a much lower cost of $8.5/ton clinker capacity. This report assumes a cost of $15/annual ton

clinker. The increased production capacity is likely to save considerably in operating costs, estimated at $1/ton (Jaccard &amp; Willis, 1996).

Conversion of Long Dry Kiln to Preheater/Precalciner Kiln. If  economically  feasible  a long dry kiln can be upgraded to the current state of the art multi-stage preheater/precalciner  kiln.  Energy  savings  are  estimated  at  1.2  MBtu/ton  clinker  for  the conversion. These savings reflect the difference between the average dry kiln specific fuel consumption  and  that  of  a  modern  preheater,  pre-calciner  kiln  based  on  a  study  of  the Canadian  cement  industry  and  the  retrofit  of  an  Italian  plant  (Holderbank,  1993;  Sauli, 1993).  The  Holderbank  study  gives  a  range  of  $21-26/ton  clinker  for  a  pre-heater,  precalciner kiln.

According to Hollingshead and Venta (2009), the throughput can increase by 40%, while clinker cooler and material grinding upgrades will need to take place in order to handle the increase  in  capacity.  Energy  savings  are  about  0.9  MBtu/ton  clinker  while  no  change  in power  consumption  is  expected.  Operation  and  maintenance  costs  are  expected  to decrease  by  $0.10/ton  clinker.  The  investment  costs  are  estimated  by  Hollingshead  and Venta  (2009)  at  $115/ton  clinker  annually,  significantly  higher  than  other  studies,  as upgrades  in  the  clinker  cooler  and  raw  grinding  systems  are  also  taken  into  account. According  to  another  study  (ECRA,  2009),  energy  use  will  be  reduced  by  0.85  MBtu/ton clinker while electricity may decrease by up to 5 kWh/ton clinker.

## 6.7 Finish Grinding

Process  Control  and  Management  -  Grinding  Mills. Control  systems  for  grinding operations are developed using the same approaches as for kilns (see above). The systems control  the  flow  in  the  mill  and  classifiers,  attaining  a  stable  and  high  quality  product. Several systems are marketed by a number of manufacturers. Expert systems have been commercially  available  since  the  early  1990's.  The  Karlstadt  plant  of  Schwenk  KG (Germany)  implemented  an  expert  system  in  a  finishing  mill  in  1992,  increasing  mill throughput  and  saving  energy.  The  payback  is  estimated  between  1.5  and  2  years  in Germany  (Albert,  1993).  Magotteaux  (Belgium)  has  marketed  a  control  system  for  mills since  1998  and  has  sold  six  units  to  plants  in  Germany  (Rohrdorfer  Zement),  Greece (Heracles  General  Cement),  SouthAfrica  (PPC  Group)  and  the  United  Kingdom  (UK) (Rugby  Group).  Experience  with  a  cement  mill  at  the  South  Ferriby  plant  of  the  Rugby Group in  the  UK  showed  increased  production  (+3.3%)  and  power  savings  equal  to  3%, while the standard deviation in fineness went down as well (Van den Broeck, 1999). Krupp Polysius markets the PolExpert system and reports energy savings between 2.5 and 10% (typically 8%), with increased product quality (lower deviation) and production increases of 2.5 -10%, after installing control systems in finishing mills (Goebel, 2001). Similar results have been achieved with model predictive control (using neural networks) for a cement ball mill at a South African cement plant (Martin and McGarel, 2001a). F.L.Smidth markets the ProcessExpert ®   system,  which  has  shown  to  increase  the  throughput  and  reduce  energy use  in  roller  presses.  At  Vasavadatta  Cement  (India),  throughput  increased  by  8%  and energy use decreased by 5% in the cement mill, while in the coal mill throughput increased by 9% and energy use decreased by 3%. Pavilion Technologies (US) has developed a new

control  system  using  neural  networks.  Pavilion  Technologies  reports  a  4-6%  throughput increase (and corresponding reduction in specific power consumption) for installing a model predictive control system in a finish ball mill (Martin et al., 2001). Titan America, with the implementation  of  Pavillions'  APC  (Advanced  Process  Control)  cement  solution  in  two facilities  in Roanoke, Virginia, achieved an annual reduction in energy costs of more than $120,000  and  a  significant  increase  in  mill  throughput,  while  it  also  improved  product quality. Electricity use decreased by 3.5 kWh/ton clinker and mill throughput increased by 4.8 and 5.7% in the two mills. In another application of Pavillions' process control system at Dyckerhoffs'  site  in  Germany,  mill  throughput  increased  by  4.5-9.3%,  while  energy  use decreased by 2.4-5.8% depending on the type of cement being ground. Payback periods are typically between 6 and 8 months (Martin and McGarel, 2001a).

A new advancement in cement grinding is the real-time particle size measurement. The online  Insitec  Fineness  Analyzer  from  Malvern  Instruments is a laser diffraction system that generates real-time particle size data. In this way cement is ground as much as required in order to meet specifications (Levonian et al., 2009). Florida Rock Industries, with the use of Pavillion's Cement  Grinding  Application  and  the  Insitec  Fineness  Analyzer,  reduced electricity use for grinding by 17% and increased 1-day strength by 15%. Based only on the energy savings the payback period was estimated to less than 2 years. Vulcan Materials Company in Alabama had prior to any advancement in process control, specific electricity consumption for cement grinding of about 41.8 kWh/ton cement. With the use of Pavillion's APC system, electricity use dropped to 39.1 kWh/ton cement. When the Insitec Fineness Analyzer was also employed, electricity use dropped to 33.3 kWh/ton cement (Levonian et al.,  2009).  The  1-day  strength  increased  by  15%  with  a  product  Blaine  10%  lower  than before. As product quality increased, C3S (alite) levels (see also the paragraph on decrease in Lime Saturation Factor) could be reduced, decreasing in this way the plant's operational costs.

Advanced Grinding Concepts. The energy efficiency of ball mills for use in finish grinding is relatively low, consuming up to 30-42 kWh/ton clinker depending on the fineness of the cement  (Marchal,  1997;  Cembureau,  1997).  Several  new  mill  concepts  exist  that  can significantly reduce power consumption in the finish mill to 18-30 kWh/ton clinker, including roller  mills,  and  roller  presses  which  can  be  used  in  combination  with  ball  mills  for  pregrinding,  or  as  stand-alone  units  for  finish  grinding  (Alsop  and  Post,  1995;  Cembureau, 1997; Seebach et al., 1996; Hendriks et al., 2004; Harder, 2010a; Harder, 2010b; Schnatz, 2009; Schneider, 2008). Some new mill concepts may lead to a reduction in operation costs of as much as 30-40% (Sutoh et al., 1992). New designs of the roller mills allow for longer operation times (&gt; 20,000 hours).

## Replace Ball Mills with Vertical Roller Mills

Roller mills employ a mix of compression and shearing, using 2-4 grinding rollers carried on hinged arms riding on a horizontal grinding table (Cembureau, 1997; Alsop and Post, 1995). Typical roller mills have capacities of 200 tph. However, high capacity, 350 tph roller mills using  4  or  more  rollers,  have  also  been  developed  (Harder,  2010b).  A  recent  off-shoot technology  which  is  not  air  swept  is  now  being  used  as  a  pre-grinding  system  in

combination with a ball mill. A variation of the roller mill is the air swept ring roller mill, which has been shown to achieve an electricity consumption of 23 kWh/ton with a Blaine of 3000 (Folsberg, 1997). The typical energy use for roller mills lies within 18 to 20 kWh/t clinker, depending  on  cement  fineness.  In  2002,  Phoenix  Cement  Company  installed  the  first vertical  roller  mill  used  for  cement  grinding  in  the  United  States,  and  decreased  power consumption by 15 kWh/ton cement (Simmons et al., 2005). In 2006, CalPortland Cement plant in Mojave replaced several ball mills with a state-of-the-art vertical roller mill system and  decreased  power  use  for  cement  grinding  by  40%  (Coppinger,  2010).  In  India,  a cement  plant  achieved  savings  in  power  consumption  of  about  15  kWh/ton  slag  cement (3400  Blaine)  (Keyssner  and  Abraham,  2005).  Power  savings  will  depend  on  cement fineness and are estimated at 9-20 kWh/t cement. In literature, investment costs vary widely from  $6.6/ton  cement  (Price  et  al.,  2009)  to  $39/ton  cement  (Hollingshead  and  Venta, 2009).  Maintenance  costs  will  increase  by  $0.17/ton  cement  (Hollingshead  and  Venta, 2009).  Although  it  has  been  indicated  that  process  advantages  cannot  justify  the  high installation costs of a vertical roller mill for a new cement grinding line, the comparison of the actual installation costs of the first vertical roller mill for cement grinding in the U.S. and a closed circuit ball mill system, is in favor of a vertical roller mill (Terembula, 2004). Vertical roller  mills  can  achieve  increased  cement  fineness;  however,  due  to  variations  in  particle size  distribution  and  therefore  cement  performance,  extra  quality  control  will  be  required (ECRA, 2009; Fortsch, 2005).

## Replace Ball Mills with Horizontal Roller Mills (Horomill ® )

A  new  mill  concept  is  the  Horomill ® ,  first  demonstrated  in  Italy  in  1993  (Buzzi,  1997). Nowadays, there are more than 40 Horomills  installed around the world mainly used for ® cement  grinding  (Harder,  2010b).  In  the  Horomill ®   a  horizontal  roller  within  a  cylinder  is driven. The centrifugal forces resulting from the movement of the cylinder cause a uniformly distributed layer to be carried on the inside of the cylinder. The layer passes the roller (with a  pressure  of  700-1,000  bar  (Marchal,  1997).  The  finished  product  is  collected  in  a  dust filter. The Horomill ®  is a compact mill that can produce a finished product in one step and hence  has  relatively  low  capital  costs.  Grinding  portland  cement  with  a  Blaine  of  3,200 cm 2 /g consumes approximately 21 kWh/ton (Buzzi, 1997) and even for pozzolanic cement with a Blaine of 4000, power use may be as low as 25 kWh/ton (Buzzi, 1997; Wang and Forssberg,  2003).  According  to  more  recent  estimates,  energy  use  lies  within  16  to  19 kWh/ton cement (Hendriks et al., 2004). Typical energy savings for replacing a ball mill with a horizontal roller mill are 30% for cement grinding and 40% for slag grinding, while for raw material  grinding  they  can  reach  up  to  50%  (Schneider,  2008).  A  recent  development  in horizontal roller mills is the BETA-mill. In a BETA-mill the bed thickness and the grinding pressure  can  be  adjusted  independently,  achieving  in  this  way  even  higher  energy efficiencies (Schneider, 2008). Main barrier to the wide acceptance of Horomills ®  is its low throughput. Currently, the largest Horomill in operation has a capacity of 120 tph (Harder, 2010b).  Equipment  wear  is  similar  to  high  pressure  roller  mills.  The  investment  cost  is estimated to be similar to high-pressure roller presses at $16/ton cement (Hollingshead and Venta, 2009).

Use High-Pressure Roller Presses With/Without Ball Mills

Today, high-pressure roller presses are most often used to expand the capacity of existing grinding mills, and are found especially in countries with high electricity costs or with poor power supply (Seebach et al, 1996). When a ball mill is already in use, the addition of highpressure roller presses, also known as high-pressure grinding rolls (HPGR), is considered the most preferable way to increase capacity and reduce energy use (Harder, 2010a). In a high-pressure roller press system, two rollers pressurize the material up to 3,500 bar (Buzzi, 1997),  improving  the  grinding  efficiency  dramatically  (Seebach  et  al.,  1996).  Several grinding system configurations can be employed such as pregrinding, hybrid grinding, semifinish  grinding  and  finish  grinding.  Depending  on  product  fineness  but  also  on  system configuration energy use can decrease by 10-50% (Harder, 2010a; Patzelt, 1992; Schnatz, 2009; Schneider, 2008, Chatterjee, 2004) while capacity can increase by 100% compared to close circuit ball mill grinding systems (Harder, 2010a; Patzelt, 1993; Schneider, 2008). In general, the higher the amount of cement ground in the roller presses, the more significant the energy savings will be (Harder, 2010a; Aydo ğ an et al. 2006). Finish grinding systems with roller presses appear to have the lowest energy consumption of 17-19 kWh/ton cement (Schnatz,  2009;  Harder,  2010b).  In  combined  grinding  circuits  the  energy  use  can  range between  22  and  34  kWh/ton  (Schnatz,  2009;  Aydo ğ an  et  al.  2006;  Benzer  et  al.,  2011). Table 5, shows the energy use of several circuit configurations using high-pressure roller presses and ball mills based on a study from Aydo ğ an et al. (2006).

Table 5. Specific energy consumption of HPGR circuits in a variety of configurations

| Configuration                                                                |   Overall circuit specific energy use (kWh/ton) | HPGR circuit specific energy use (kWh/ton)   |
|------------------------------------------------------------------------------|-------------------------------------------------|----------------------------------------------|
| Open circuit HPGR - closed circuit ball mill grinding                        |                                           34.19 | 4.05                                         |
| Open circuit HPGR with partial recycling - closed circuit ball mill grinding |                                           29.57 | 8.93                                         |
| Hybrid grinding                                                              |                                           29.85 | -                                            |
| Closed circuit HPGR - closed circuit ball mill grinding                      |                                           21.65 | 8.02                                         |
| Semi - finish grinding                                                       |                                           23.03 | 9.80                                         |

Source: Aydo ğ an et al. 2006

The  addition  of  a  pre-grinding  system  to  a  ball  mill  will  result  in  savings  of  6-20  kWh/ton cement (Cembureau, 1997; Holland et al., 1997; Scheur and Sprung, 1990). Energy savings from the addition of roller presses as a pre-grinder are estimated at 5.4-10 kWh/ton cement (Sukkar et al., 2005; Hollingshead and Venta, 2009; Benzer et al., 2011). Energy savings for replacing  ball  mills  with  roller  presses  for  finish  grinding  are  estimated  at  11-25  kWh/ton cement.  Capital  cost  estimates  for  installing  a  new  roller  press  vary  widely  in  literature, ranging  from  low  estimates  like  $2.3/annual  ton  cement  capacity  (Holderbank,  1993)  or

$3.3/annual  ton  cement  capacity  (Kreisberg,  1993)  to  high  estimates  of  $7.3/annual  ton cement  capacity  (COWIconsult  et  al.,  1993).  Hollingshead  and  Venta  (2009)  estimate  that investment costs for a roller press system used for finished grinding at $16/ton cement  while for a roller press used in combination with an existing ball mill, the changes are considered minimal,  and  investment  costs  are  estimated  at  $6.5/ton  clinker.  The  capital  costs  of  roller press  systems  are  lower  than  those  for  other  systems  (Kreisberg,  1993)  or  at  least comparable (Patzelt, 1993). With the use of roller presses the feed size of the ball mills is significantly altered, therefore several adjustments in ball size and load, compartment length and diaphragms will need to take place in order to fully utilize the benefits of roller presses (Aydo ğ an et al., 2006).

High Efficiency Classifiers/Separators. A recent development in efficient grinding technologies  is  the  use  of  high-efficiency,  third  generation,  classifiers  or  separators. Classifiers separate the finely ground particles from the coarse particles. The large particles are  then  recycled  back  to  the  mill.  Standard  classifiers  may  have  a  low  separation efficiency, which leads to the recycling of fine particles, resulting in extra power use in the grinding  mill.  In  high-efficiency  classifiers,  the  material  is  more  cleanly  separated,  thus reducing  over-grinding.  High  efficiency  classifiers  or  separators  have  had  the  greatest impact on improved product quality and reducing electricity consumption.

A  study  of  the  use  of  high  efficiency  classifiers  in  Great  Britain  found  a  reduction  in electricity use of 6 kWh/ton cement after the installation of the classifiers in their finishing mills  and  a  25%  production  increase  (Parkes,  1990).  Holderbank  (1993)  estimates  a reduction of 8% of electricity use (5 kWh/ton cement) while other studies estimate 1.7-3.9 kWh/ton cement (Salborn and Chin-Fatt, 1993; Sussegger, 1993; Hollingshead and Venta, 2009; ECRA, 2009; Simmons et al., 2005). Newer designs of high-efficiency separators aim to  improve the separation efficiency further and reduce the required volume of air (hence reducing power use), while optimizing the design. All major suppliers market new classifier designs,  e.g.  Polysius  (SEPOL),  F.L.Smidth/Fuller  and  Magotteaux  (Sturtevant  SD).  The actual savings will vary by plant and cement type and fineness required. For example, the electricity savings from installing a new high-efficiency classifier at a cement plant in OrignyRochefort  (France)  varied  between  0  and  5  kWh/ton  (Van  den  Broeck,  1998)  while  at Cementir's cement plant, in Taranto (Italy) electricity use decreased by 7 kWh/ton cement (Pottier  and  Niel,  2008).  The  replacement  of  old  classifiers  with  highly-efficient,  third generation  classifiers,  at  Phoenix  Cement,  Germany,  achieved  reliable  operation  and availability,  while  it  also  improved  product  quality  and  increased  throughput  (ZKG,  2010). The investment costs are estimated between $1.5 and $3.0/ton cement (Holdebank, 1993; ECRA, 2009; Hollingshead and Venta, 2009; ZKG, 2010; Clauser, 2010).

Improved Grinding Media. Around 60% of all mills in cement plants are ball mills (PCA, 2012).  Thus,  the  energy  savings  potential  from  improving  the  operating  parameters  of existing  ball  mills  will  be  substantial.  Although  the  market  share  of  vertical  mills  has increased, ball mills are still the type of mills most usually ordered (Harder, 2010b). Reasons are  that  i)  ball  mills  are  used  in  combination  with  roller  presses,  ii)  a  conversion  to  highefficiency separators often requires upgrading or purchasing ball mills, and iii) sometimes ball mills are purchased as stand-by mills (Harder, 2010b). Improved wear resistant materials can

be installed for grinding media, especially in ball mills. Grinding media are usually selected according to the wear characteristics of the material. Increases in the ball charge distribution and surface hardness of grinding media and wear resistant mill linings have shown a potential for reducing  wear  as  well  as  energy  consumption  (Venkateswaran  and  Lowitt,  1988). Improper  ball  size  distribution  and  filling  level  can  reduce  grinding  efficiency  by  5-20% (Longhurst, 2010), while the ball weight and the material transfer and discharge diaphragms also affect the grinding efficiency (Longhurst, 2010; Harder, 2010b). An improvement of the ball  grading  can  result  in  about  10%  energy  savings  (Harder,  2010b).  Improved  balls  and liners made of high chromium steel is one such material but other materials are also possible. The use of improved liner designs, such as grooved classifying liners, have the potential to reduce grinding energy use by 5-10% in some mills, which is equivalent to estimated savings of  1.8  kWh/ton  cement  (Venkateswaran  and  Lowitt,  1988).  However,  according  to  Fortsch (2006), it is possible that plants using classifying liners in ball mills that have installed highefficiency classifiers will not be profitable, while in some cases an increase in power use may be  observed.  The  investment  cost  to  upgrade  balls,  liners  and  diaphragm  is  estimated  at $2.44/ton cement (Hollingshead and Venta, 2009).

## 6.8 Plant Wide Measures -

## Preventative Maintenance

Preventative maintenance includes training personnel to be attentive to energy consumption and efficiency. Successful programs have been launched in a variety of industries (Caffal, 1995; Nelson, 1994). While many processes in cement production are primarily automated, there  still  are  opportunities,  requiring  minimal  training  of  employees,  to  increase  energy savings.  Also,  preventative  maintenance  (e.g.  for  the  kiln  refractory)  can  also  increase  a plant's utilization ratio, since it has less downtime over the long term, and improve process stability. Birch (1990) mentions that the reduction of false air input into the kiln at the kiln hood  has  the  potential  to  save  11  kcal/kg  clinker  or  0.04  MBtu/ton.  This  is  used  as  the estimate  of  fuel  savings.  Lang  (1994)  notes  a  reduction  of  up  to  5  kWh  for  various preventative  maintenance  and  process  control  measures  (typically  around  3  kWh/ton). Based on similar programs in other industries, annual and startup costs for implementing this training are estimated to be minimal and would be paid back in less than one year. For preventative maintenance of compressed air systems see below.

## Motor Systems

This  chapter  presents  a  number  of  energy  efficiency  measures  available  for  motors  in industrial applications. 13 Additional measures  that  are  specific to pumps,  fans,  and compressed air systems are offered in later chapters of this Energy Guide.

13 The U.S. DOE's Advanced Manufacturing Office provides a variety of resources for improving the efficiency of industrial motor systems, which can be consulted for more detailed information on many of the measures presented in this chapter. For a collection of tips, tools, and industrial case studies on  industrial motor  system  efficiency, visit the U.S. DOE's  website  for  Motor  Systems  at: http://www1.eere.energy.gov/manufacturing/tech\_deployment/motors.html. The Motor Decisions

In  the  cement industry, motors are responsible for the majority of electricity consumption. Motors  are  used  to  drive  fans  and  blowers,  rotate  the  kiln,  transport  raw  materials  and finished products, and most importantly, to grind raw material and cement. More than 500 to 700  motors  of  various  capacities  can  be  used  in  a  single  cement  plant  (Worrell  et  al., 2008b).

When  considering  energy  efficiency  improvements  to  a  facility's  motor  systems,  it  is important to take a 'systems approach.' A systems approach strives to optimize the energy efficiency  of  entire  motor  systems  (i.e.,  motors,  drives,  driven  equipment  such  as  pumps, fans, and compressors, and controls), not just the energy efficiency of motors as individual components.  A  systems  approach  analyzes  both  the  energy  supply  and  energy  demand sides  of  motor  systems  as  well  as  how  these  sides  interact  to  optimize  total  system performance, which includes not only energy use but also system uptime and productivity.

A systems approach typically involves the following steps. First, all applications of motors in a facility should be located and identified. Second, the conditions and specifications of each motor should be documented to provide a current systems inventory. Third, the needs and the actual use of the motor systems should be assessed to determine whether or not motors are properly sized and also how well each motor meets the needs of its driven equipment. Fourth,  information  on  potential  repairs  and  upgrades  to  the  motor  systems  should  be collected, including the economic costs and benefits of implementing repairs and upgrades to enable the energy efficiency improvement decision-making process. Finally, if upgrades are  pursued,  the  performance  of  the  upgraded  motor  systems  should  be  monitored  to determine the actual cost savings (SCE, 2003).

The  motor  system  energy  efficiency  measures  below  reflect  important  aspects  of  this systems approach, including matching motor speeds and loads, proper motor sizing, and upgrading system components.

Motor Management Plan. A motor management plan is an essential part of a plant's energy management  strategy.    Having  a  motor  management  plan  in  place  can  help  companies realize long-term motor system energy savings and will ensure that motor failures are handled in a quick and cost effective manner. The Motor Decisions Matter SM  Campaign suggests the following key elements for a sound motor management plan (MDM, 2012):

- 1. Creation of a motor survey and tracking program.
- 2. Development of guidelines for proactive repair/replace decisions.
- 3. Preparation for motor failure by creating a spares inventory.
- 4. Development of a purchasing specification.

Matter SM   Campaign  also  provides  a  number  of  excellent  resources  for  improving  motor  system efficiency (http://www.motorsmatter.org/).

- 5. Development of a repair specification.
- 6.  Development  and  implementation  of  a  predictive  and  preventive  maintenance program.

It  is  important  to  develop  a  selection  of  preferred  premium  efficiency  motors  to  replace existing motors at failure. Otherwise, it is likely that the motors will be replaced by less efficient alternatives.

The Motor Decisions Matter SM  Campaign's Motor Planning Kit contains further details on each of these elements (MDM, 2012).

Strategic Motor Selection. Several factors are important when selecting a motor, including motor speed, horsepower, enclosure type, temperature rating, efficiency level, and quality of power supply. When selecting and purchasing a motor, it is also critical to consider the lifecycle costs of that motor rather than just its initial purchase and installation costs. Up to 95% of  a  motor's  costs  can  be  attributed  to  the  energy  it  consumes  over  its  lifetime,  while  only around  5%  of  a  motor's  costs  are  typically  attributed  to  its  purchase,  installation,  and maintenance (MDM, 2012). Life cycle costing (LCC) is an accounting framework that allows one to calculate the total costs of ownership for different investment options, which leads to a more sound evaluation of competing options in motor purchasing and repair or replacement decisions.  A  specific  LCC  guide  has  been  developed  for  pump  systems  (Fenning  et  al., 2001), which also provides an introduction to LCC for motor systems.

The selection  of  energy-efficient  motors  can  be  an  important  strategy  for  reducing  motor system  life-cycle  costs.  Energy-efficient  motors  reduce  energy  losses  through  improved design,  better  materials,  tighter  tolerances,  and  improved  manufacturing  techniques.  With proper installation, energy-efficient motors can also run cooler (which may help reduce facility heating loads) and have higher service factors, longer bearing life, longer insulation life, and less vibration.

To  be  considered  energy  efficient  in  the  United  States,  a  motor  must  meet  performance criteria published  by  the  National  Electrical  Manufacturers  Association  (NEMA).  The Consortium  for  Energy  Efficiency  (CEE)  has  described  the  evolution  of  standards  for energy-efficient  motors  in  the  United  States,  which  is  helpful  for  understanding  'efficient' motor nomenclature (CEE, 2007):

-  NEMA Energy Efficient (NEMA EE) was developed in the mid-1980s to define the term 'energy efficient' in the marketplace for motors. NEMA Standards Publication No.  MG-1  -2011,  Table  12-11  defines  efficiency  levels  for  a  range  of  different motors (NEMA, 2012).
-  The Energy Policy Act of 1992 (EPAct) required that many commonly used motors comply with NEMA 'energy efficient' ratings if offered for sale in the United States.
-  In 1996,  the  CEE  Premium  Efficiency  Criteria  specification  was  designed  to promote  motors  with  higher  efficiency  levels  than  EPAct  required,  for  the  same

classes  of  motors  covered  by  EPAct.  The  CEE  efficiency  levels  specified  were generally  two  NEMA  efficiency  bands  (Table  12-10,  NEMA  MG-1-2011)  above those required by EPAct.

-  In 2001, the NEMA Premium Efficiency Electric Motor specification was developed to  address  confusion  with  respect  to  what  constituted  the  most  efficient  motors available  in  the  market.  This  specification  was  developed  by  NEMA,  CEE,  and other  stakeholders,  and  was  adapted  from  the  CEE  1996  criteria.  It  currently serves as the benchmark for premium energy efficient motors. NEMA Premium R also denotes a brand name for motors which meet this specification.  Specifically, this specification covers motors with the following attributes:
-  Speed: 2, 4, and 6 pole
-  Size: 1-500 horsepower (hp)
-  Design: NEMA A and B
-  Enclosure type: open and closed
-  Voltage: low and medium voltage
-  Class: general, definite, and special purpose

The  choice  of  installing  a  premium  efficiency  motor  strongly  depends  on  motor  operating conditions  and  the  life  cycle  costs  associated  with  the  investment.  In  general,  premium efficiency  motors  are  most  economically  attractive  when  replacing  motors  with  annual operation exceeding 2,000 hours/year. However, software tools such as MotorMaster+ (see Appendix D) can help identify attractive applications of premium efficiency motors based on the specific conditions at a given plant.

Sometimes, even replacing an operating motor with a premium efficiency model may have a low  payback  period.  According  to  data  from  the  Copper  Development  Association,  the upgrade  to  high-efficiency  motors,  as  compared  to  motors  that  achieve  the  minimum efficiency  as  specified  by  EPACT,  can  have  paybacks  of  less  than  15  months  for  50  hp motors (CDA, 2001). Payback times will vary based on size, load factor, running time, local energy  costs,  and  available  rebates  and/or  incentives  (see  Appendix  D).  Given  the  quick payback time, it usually makes sense to by the most efficient motor available (U.S. DOE and CAC, 2003).

NEMA and other organizations have created the Motor Decisions Matter SM  campaign to help industrial  and  commercial  customers  evaluate  their  motor  repair  and  replacement  options, promote cost-effective applications of NEMA Premium R  motors and 'best practice' repair, and support the development of motor management plans before motors fail.

In  2004,  CEMEX  (formerly  RMC  Pacific  Materials)  in  Davenport,  California,  retrofitted  the motors on cement blowers and silo pumps. With the use of DOE's MotorMaster+software tool, plant personnel identified that 13 motors with an aggregate horsepower of 2,350 hp, were less

than 80% efficient, of the wrong type, and required replacement. The specific motors were retrofitted  with  high  efficiency  (95%)  totally  enclosed  fan  cooled  (TEFC)  motors  of  similar capacity. Because of the motor retrofit, the plant managed to reduce electricity use by more than  2  million  kWh,  energy  costs  by  $168,000  and  annual  maintenance  costs  by  $30,000 (U.S. DOE, 2005a).

In some cases, it may be cost-effective to rewind an existing energy-efficient motor, instead of purchasing a new motor. As a rule of thumb, when rewinding costs exceed 60% of the costs of  a  new  motor,  purchasing  the  new  motor  may  be  a  better  choice  (MDM,  2012).  When rewinding a motor, it is important to choose a motor service center that follows best practice motor rewinding standards in order to minimize potential efficiency losses. An ANSI-approved recommended  best  practice  standard  has  been  offered  by  the  Electric  Apparatus  Service Association  (EASA)  for  the  repair  and  rewinding  of  motors  (EASA,  2006).  When  best rewinding  practices  are  implemented,  efficiency  losses  are  typically  less  than  0.5%  to  1% (EASA,  2003).  However,  poor  quality  rewinds  may  result  in  larger  efficiency  losses.  It  is therefore important to inquire whether the motor service center follows EASA best practice standards (EASA, 2006).

Maintenance. The purposes of motor maintenance are to prolong motor life and to foresee a motor  failure.  Motor  maintenance  measures  can  be  categorized  as  either  preventative  or predictive. Preventative measures, the purpose of which is to prevent unexpected downtime of motors, include electrical consideration, voltage imbalance minimization, load consideration,  and  motor  ventilation,  alignment,  and  lubrication.  The  purpose  of  predictive motor maintenance is to observe ongoing motor temperature, vibration, and other operating data  to  identify  when  it  becomes  necessary  to  overhaul  or  replace  a  motor  before  failure occurs  (Barnish  et  al.,  1997).  The  savings  associated  with  an  ongoing  motor  maintenance program are significant, and could range from 2% to 30% of total motor system energy use (Efficiency Partnership, 2004).

Properly Sized Motors. Motors that are sized inappropriately result in unnecessary energy losses.  Where  peak  loads  on  driven  equipment  can  be  reduced,  motor  size  can  also  be reduced. Replacing oversized motors with properly sized motors saves, on average for U.S. industry, 1.2% of total motor system electricity consumption (Xenergy, 1998). Higher savings can often be realized for smaller motors and individual motor systems.

To  determine  the  proper  motor  size,  the  following  data  are  needed:  load  on  the  motor, operating  efficiency  of  the  motor  at  that  load  point,  the  full-load  speed  of  the  motor  to  be replaced, and the full-load speed of the replacement motor. The U.S. DOE's BestPractices program provides a fact sheet that can assist in decisions regarding replacement of oversized and  under  loaded  motors  (U.S.  DOE,  1996a).  Additionally,  software  packages  such  as MotorMaster+ (see Appendix D) can aid in proper motor selection.

Motor  Automation . Motors  should  only  run  when  needed.  A  10%  reduction  in  motor operating  time  can  save  more  energy  than  replacing  a  conventional  motor  with  a  NEMA Premium ®  efficiency motor (U.S. DOE, 2008). Therefore, automatic shutdown of motors that would otherwise be left idling can reduce energy costs without requiring high investment. A

25  hp  non-automated  motor  running  unloaded  for  5  hours  per  day,  costs  about  $1,000 annually (Bayne, 2011).

Although  there  is  a  concern  that  often  motor  start-ups  will  negatively  affect  the  motor's lifetime, as long as the frequency of motor start-ups is not excessive, the lifetime will not be significantly  affected  (U.S.  DOE,  2008).  NEMA  (2001)  gives  the  maximum  number  of allowable  motor  start-ups  per  hour  and  the  duration  of  rest  time  between  start-ups,  for various horsepower motors and synchronous speed ratings.

Adjustable  Speed  Drives  (ASDs). 14 Adjustable-speed  drives  better  match  speed  to  load requirements for motor operations, and therefore ensure that motor energy use is optimized to a given application. Adjustable-speed drive systems are offered by many suppliers and are available worldwide. Worrell et al. (1997) provide an overview of savings achieved with ASDs in  a  wide  array  of  applications;  typical  energy  savings  are  shown  to  vary  between  7%  and 60%.  Also,  in  cement  plants  large  variations  in  load  occur  (Bösche,  1993).  The  savings depend  on  the  flow  pattern  and  loads.  The  savings  may  vary  between  7  and  60%.  ASD equipment is used more and more in cement plants (Bösche, 1993; Fujimoto, 1993), but the application may vary widely, depending on electricity costs. Within a plant, ASDs can mainly be applied for fans in the kiln, cooler, preheater, separator and mills, and for various drives.

Blue Circle's Bowmanville plant (Canada) installed a variable air inlet fan, reducing electricity and fuel use in the kiln (because of reduced inlet air volume), saving C$75,000/year in energy costs (approximately $47,000 in U.S. dollars) (CIPEC, 2001). One case study for a modern cement plant estimated potential application for 44% of the installed motor power capacity in the plant (Bösche, 1993). ASDs for clinker cooler fans have a low payback, even when energy savings are the only reason for installing ASDs (Holderbank, 1993). Energy savings strongly depend  on  the  application  and  flow  pattern  of  the  system  on  which  the  ASD  is  installed. Although  savings  are  significant  (Holderbank,  1993),  not  many  quantitative  studies  are available for the cement industry. One hypothetical case study estimates the savings at 70%, compared to a system with a throttle valve (or 37% compared with a regulated system) for the raw  mill  fan  (Bösche,  1993).  In  practice  savings  of  70%  are  unrealistic  (Young,  2002). Fujimoto, (1994) notes that Lafarge Canada's Woodstock plant replaced their kiln ID fans with ASDs and reduced electricity use by 5 kWh/ton. It is estimated the potential savings are at 15% for 44% of the installed power, or roughly equivalent to 7 kWh/ton cement. ECRA (2009) estimated electricity savings to range between 3 and 9 kWh/ton cement. The specific costs depend strongly on the size of the system. For systems over 300 kW the costs are estimated at 70 ECU/kW (75 US$/kW) or less and for the range of 30-300 kW at 115-130 ECU/kW (120140  US$/kW)  (Worrell  et  al.,  1997).  Using  these  cost  estimates,  the  specific  costs  for  a modern  cement  plant,  as  studied  by  Bösche  (1993),  can  be  estimated  at  roughly  0.8-0.9 $/annual  ton  cement  capacity.  Other  estimates  vary  between  $0.4  and  $2.7/annual  ton

14 Several terms are used in practice to describe a motor system that permits a mechanical load to be driven at variable speeds, including adjustable speed drives (ASDs), variable speed drives (VSDs), adjustable frequency drives (AFDs), and variable frequency drives (VFDs). The term ASD is used throughout this Energy Guide for consistency.

cement (Holland and Ranze, 1997; Holderbank, 1993). When the kiln is mostly operated at full capacity, electricity savings can be limited (ECRA, 2009).

Power Factor Correction. Inductive loads like transformers, electric motors, and HID lighting may  cause  a  low  power  factor.  A  low  power  factor  may  result  in  increased  power consumption, and hence increased electricity costs. In cement plants where a big number of electric motors are used the inductive power consumption can be significant (Pulkki, 2004). The  power  factor  can  be  corrected  by  minimizing  idling  of  electric  motors  (a  motor  that  is turned  off  consumes  no  energy),  replacing  motors  with  Premium  Efficiency  motors  (see above), and installing capacitors in the AC circuit to reduce the magnitude of reactive power in the system.

Minimizing  Voltage  Unbalances. A  voltage  unbalance  degrades  the  performance  and shortens  the  life  of  three-phase  motors.  A  voltage  unbalance  causes  a  current  unbalance, which will  result  in  torque  pulsations,  increased  vibration  and  mechanical  stress,  increased losses,  and  motor  overheating,  which  can  reduce  the  life  of  a  motor's  winding  insulation. Voltage unbalances may be caused by faulty operation of power factor correction equipment, an  unbalanced  transformer  bank,  or  an  open  circuit.  A  rule  of  thumb  is  that  the  voltage unbalance at the motor terminals should not exceed 1%. Even a 1% unbalance will reduce motor efficiency at part load operation, while a 2.5% unbalance will reduce motor efficiency at full load operation.

For a 100 hp motor operating 8,000 hours per year, a correction of the voltage unbalance from 2.5% to 1% will result in electricity savings of 9,500 kWh or almost $500 at an electricity rate of $0.05/kWh (U.S. DOE, 2005b).

By regularly monitoring the voltages at the motor terminal and through regular thermographic inspections of motors, voltage unbalances may be identified. It is also recommended to verify that  single-phase  loads  are  uniformly  distributed  and  to  install  ground  fault  indicators  as required. Another indicator that a voltage unbalance may be a problem is 120 Hz vibration, which should prompt an immediate check of voltage balance (U.S. DOE, 2005b). The typical payback period for voltage controller installation on lightly loaded motors in the United States is about 2 years (IAC, 2012).

Soft Starters. Soft starters are special devices which allow the gradual speed acceleration of the motor, and limit the electrical stresses associated with motor start-up (U.S. DOE, 2003). With  the  use  of  soft  starters  power  use  during  motor  start-up  can  be  reduced.  Investment costs are estimated at $0.40/ton clinker while electricity use can be reduced by 2.5 kWh/ton clinker (Hollingshead and Venta, 2009).

## Compressed Air Systems

Compressed air systems are used in different parts of the plants, i.e. mixing of slurry (in wet process plants) and in the baghouse Pulse-Jet or Plenum Pulse dust collector filters and other  parts.  Total  energy  consumption  by  compressed  air  systems  is  relatively  small  in cement  plants,  however,  it  can  amount  to  a  considerable  expense  if  the  systems  run continuously and end-uses are offline. Still, energy efficiency improvement measures may

be found in these systems. Compressed air is probably the most expensive form of energy available in a plant because of its poor efficiency. Typically overall efficiency is around 10% for compressed air (U.S. DOE and CAC, 2003). Because of this inefficiency, if compressed air  is  used,  it  should  be  of  minimum  quantity  for  the  shortest  possible  time,  constantly monitored and weighed against alternatives.

Compressed  air  systems  consist  of  a  supply  side,  which  includes  compressors  and  air treatment, and a demand side, which includes distribution and storage systems and enduse equipment. According to the U.S. DOE, a properly managed supply side will result in clean,  dry,  stable  air  being  delivered  at  the  appropriate  pressure  in  a  dependable,  costeffective manner.  A  properly  managed  demand  side  minimizes  waste  air  and  uses compressed air for appropriate applications (U.S. DOE, 2003).

System Improvements. Adding additional compressors should be considered only after a complete  system  evaluation.  In  many  cases,  compressed  air  system  efficiency  can  be managed  and  reconfigured  to  operate  more  efficiently  without  purchasing  additional compressors.  System  improvements  utilize  many  of  the  energy  efficiency  measures  for compressors  discussed  below.  Compressed  air  system  service  providers  offer  integrated services  both  for  system  assessments  and  for  ongoing  system  maintenance  needs, alleviating  the  need  to  contact  several  separate  firms.  The  Compressed  Air  Challenge ® (http://www.compressedairchallenge.org) offers extensive training on the systems approach, technical  publications,  and  free  web-based  guidance  for  selecting  the  right  integrated service provider. Also provided are guidelines for walk-through  evaluations, system assessments, and fully  instrumented  system  audits  (U.S.  DOE  and  CAC,  2003).  Even  in recently commissioned plants, energy savings of up to 30% can be achieved (Aller et al., 2006).

Rinker Materials cement plant, after performing a system evaluation, identified that the load out pressure problems were unrelated to capacity and that with an investment of $10,000 in piping changes, air pressure problems could be solved without any increase in operational costs (Aller et al., 2006). The evaluation discovered that a number of compressors were not operating at full  capacity,  compressor controls were far from optimized (even when leaks were repaired controls would not respond), several applications were using more compressed air than needed while other applications were not necessary. Also, instead of raising overall plant air pressure, several issues could be solved with a number of changes in  the  distribution  system,  resulting  in  significant  savings  in  operational  costs.  All  of  the above problems were solved, while reducing operational costs by 30%. The payback period was significantly less than 2 years (Aller et al., 2006).

A Lafarge cement plant, after a system evaluation project, decreased operational costs by $190,000  per  year  with  a  payback  period  of  13  months  (Aller  et  al.,  2006).  Initially  the compressed air system was composed of five compressors (total of 1,325 hp) while in the next  five  years,  six  more  compressors  (470  hp)  were  added.  The  study  showed  that  the capital and operational costs of the six new compressors could have been avoided as the average operational capacity could have been roughly satisfied with the existing compressors (Aller et al., 2006). Some of the actions that took place were a leak reduction

and repair project, the installation of a more efficient bag cleaning system, the permanent shut down of a 250 hp compressor and the part-time use of two more compressors.

Maintenance of Compressed Air Systems. Inadequate maintenance can lower compression  efficiency  and  increase  air  leakage  or  pressure  variability,  as  well  as  lead  to increased  operating  temperatures,  poor  moisture  control,  and  excessive  contamination. Improved  maintenance  will  reduce  these  problems  and  save  energy.  Proper  maintenance includes the following (U.S. DOE and CAC, 2003; Scales and McCulloch, 2007):

-  Keep  the  compressor  and  intercooling  surfaces  clean  and  foul-free. Blocked  filters increase pressure drop. By inspecting and periodically cleaning filters, the pressure drop may be kept low. Seek filters with just a 1 psig pressure drop over 10 years. The payback for  filter  cleaning  is  usually  under  2  years  (Ingersoll-Rand,  2001).  Fixing  improperly operating filters will also prevent contaminants from entering into tools and causing them to wear out prematurely. Generally, when pressure drop exceeds 2 to 3 psig, replace the particulate and lubricant removal elements, and inspect all systems at least annually. Also, consider adding filters in parallel that decrease air velocity, and, therefore, decrease air pressure drop. A 2% reduction of annual energy consumption in compressed air systems is projected for more frequent filter changing (Radgen and Blaustein, 2001). In an energy assessment  at  a  Cemex  cement  plant,  a  high  differential  pressure  in  two  in-line  filters negatively affected air compressor control. The high pressure drop of more than 15 psid increased energy costs, tear and wear. The replacement of filter elements would result in annual energy savings of 69,000 kWh (U.S. DOE, 2007).
-  Keep  motors  properly  lubricated  and  cleaned .  Poor  motor  cooling  can  increase  motor temperature and winding resistance, shortening motor life, in addition to increasing energy consumption.  Compressor  lubricant  should  be  changed  every  2  to  18  months  and checked to make sure it is at the proper level. In addition to energy savings, this can help avoid corrosion and degradation of the system.
-  Inspect drain traps periodically to ensure they are not stuck in either the open or closed position and are clean. Some users leave automatic condensate traps partially open at all times to allow for constant draining. This practice wastes substantial energy and should never be undertaken. Instead, install simple pressure driven valves. Malfunctioning traps should  be  cleaned  and  repaired  instead  of  left  open.  Some  auto  drains,  such  as  float switch or electronic drains, do not waste air. Inspecting and maintaining drains typically has a payback of less than 2 years (U.S. DOE, 2004a).
-  Maintain the coolers on the compressor to ensure that the dryer gets the lowest possible inlet temperature (U.S. DOE and CAC, 2003).
-  Check belts for wear and adjust them. A good rule of thumb is to adjust them every 400 hours of operation.
-  Replace  air  lubricant  separators according  to  specifications  or  sooner.  Rotary  screw compressors  generally  start  with  their  air  lubricant  separators  having  a  2  to  3  psid

pressure drop at full  load.  When  this  increases  to  10  psid,  change  the  separator  (U.S. DOE and CAC, 2003).

-  Check water cooling systems for  water quality (pH and total dissolved solids), flow, and temperature. Clean and replace filters and heat exchangers per manufacturer's specifications.
-  Applications  requiring  compressed  air  should  be checked  for  excessive  pressure, duration,  or  volume .  Applications  not  requiring  maximum  system  pressure  should  be regulated,  either  by  production  line  sectioning  or  by  pressure  regulators  on  the equipment itself. Using more pressure than required wastes energy and can also result in shorter equipment life and higher maintenance costs. Case studies have demonstrated that the payback period for this measure can be shorter than half a year (IAC, 2012).

Monitoring. In  addition to proper maintenance, a continuous monitoring system can save significant  energy  and  operating  costs  in  compressed  air  systems.  Effective  monitoring systems typically include the following (CADDET, 1997b):

-  Pressure  gauges  on  each  receiver  or  main  branch  line  and  differential  gauges across dryers, filters, etc.
-  Temperature gauges across the compressor and its cooling system to detect fouling and blockages.
-  Flow meters to measure the quantity of air used.
-  Dew point temperature gauges to monitor the effectiveness of air dryers.
-  Kilowatt-hour meters and hours run meters on the compressor drive.
-  Checking  of compressed  air distribution systems  after equipment  has been reconfigured  to  be  sure  that  no  air  is  flowing  to  unused  equipment  or  to  obsolete parts of the compressed air distribution system.
-  Checking  for  flow  restrictions  of  any  type  in  a  system,  such  as  an  obstruction  or roughness, which can unnecessarily raise system operating pressures. As a rule of thumb,  every  2  psi  pressure  rise  resulting  from  resistance  to  flow  can  increase compressor energy use by 1% (U.S. DOE and CAC, 2003). The highest pressure drops are usually found at the points of use, including undersized or leaking hoses, tubes, disconnects, filters, regulators, valves, nozzles and lubricators (demand side), as  well  as  air/lubricant  separators,  after-coolers,  moisture  separators,  dryers  and filters.
-  Checking for compressed air use outside production hours.

Reduce Leaks. Leaks can be a significant source of wasted energy. A typical plant that has not been well maintained will likely have a leak rate equal to 20 to 50% of total compressed air

production capacity (U.S. DOE and CAC, 2003). Leak maintenance can reduce this number to less than 10%. Overall, a 20% reduction of annual energy consumption in compressed air systems is projected for fixing leaks (Radgen and Blaustein, 2001).

Estimations of leaks vary with the size of the hole in the pipes or equipment. A compressor operating  2,500  hours  per  year  at  87  psi  with  a  leak  diameter  of  0.02  inches  (½  mm)  is estimated to lose 250 kWh per year; 0.04 inches (1 mm) to lose 1,100 kWh per year; 0.08 inches (2 mm) to lose 4,500 kWh per year; and 0.16 in. (4 mm) to lose 11,250 kWh per year (CADDET, 1997b). Several cement case studies suggest that the payback period for leak reduction efforts is generally shorter than four months (IAC, 2012).

In  addition  to  increased  energy  consumption,  leaks  can  make  air  tools  less  efficient  and adversely  affect  production,  shorten  the  life  of  equipment,  lead  to  additional  maintenance requirements  and  increase  unscheduled  downtime.  In  the  worst  case,  leaks  can  add unnecessary compressor capacity.

The most common areas for leaks are couplings, hoses, tubes, fittings, pressure regulators, open condensate traps and shut-off valves, pipe joints, disconnects, and thread sealants. A simple way to detect leaks is to apply soapy water to suspect areas. Another simple way is a bleed down test (Bayne, 2011). In a bleed down test the plant air system is brought to full pressure and then shut down. By recording the system pressure while compressed air is not used anywhere in the plant, any pressure losses can be attributed to existing leaks. The best way to detect leaks is to use an ultrasonic acoustic detector, which can recognize the high frequency  hissing  sounds  associated  with  air  leaks.  After  identification,  leaks  should  be tracked,  repaired,  and  verified.  Leak  detection  and  correction  programs  should  be  ongoing efforts.

Turning Off Unnecessary Compressed  Air. Equipment that is no longer using compressed air should have the air turned off completely. This can be done using a simple solenoid valve.  Compressed air distribution systems should be checked when equipment has been reconfigured to ensure that no air is flowing to unused equipment or to obsolete parts  of  the  compressed  air  distribution  system.  In  Rinker  Materials  cement  plant,  the permanent shut down of two out of nine compressors and the part time operation of two more air  compressors  achieved  $120,000  annual  savings  in  electricity  costs  (Aller  et  al., 2006).

Modification of System in Lieu of Increased Pressure. For  individual  applications  that require  a  higher  pressure,  instead  of  raising  the  operating  pressure  of  the  whole  system, special  equipment  modifications  should  be  considered,  such  as  employing  a  booster, increasing a cylinder bore, changing gear ratios, or changing operation to off peak hours.

Replacement  of  Compressed  Air  by  Alternative  Sources. Many  operations  can  be accomplished more economically and efficiently using energy sources other than compressed air (U.S. DOE 2004b, 2004c). Various options exist to replace compressed air use, including:

-  Cooling  electrical  cabinets:  air  conditioning  fans  should  be  used  instead  of  using compressed air vortex tubes.
-  Flowing  high-pressure  air  past  an  orifice  to  create  a  vacuum:  a  vacuum  pump system should be applied instead of compressed air venturi methods.
-  Cooling,  aspirating,  agitating,  mixing,  or  package  inflating:  use  blowers  instead  of compressed air.
-  Cleaning  parts  or  removing  debris:  brushes,  blowers,  or  vacuum  pump  systems should be used instead of compressed air.
-  Moving parts:  blowers,  electric  actuators,  or  hydraulics  should  be  used  instead  of compressed air.
-  Tools  or  actuators:  electric  motors  should  be  considered  because  they  are  more efficient than using compressed air (Howe and Scales, 1995). However, it has been reported  that motors  can  have  less  precision,  shorter  lives,  and  lack  safety compared to compressed air. In these cases, using compressed air may be a better choice.

Based  on  numerous  industrial  case  studies,  the  average  payback  period  for  replacing compressed air with other applications is about 1 year (IAC, 2012).

Pressure  Drop  Minimization. An  excessive  pressure  drop  will  result  in  poor  system performance and excessive energy consumption. Flow restrictions of any type in a system, such  as  an  obstruction  or  roughness,  results  in  higher  operating  pressures  than  is  truly needed. Resistance to flow increases the drive energy on positive displacement compressors by 1% of connected power for each 2 psi of differential (U.S. DOE and CAC, 2003).  The  highest  pressure  drops  are  usually  found  at  the  points  of  use,  including undersized  or  leaking  hoses,  tubes,  disconnects,  filters,  regulators,  valves,  nozzles,  and lubricators (demand side), as well as air/lubricant separators on lubricated rotary compressors and after-coolers, moisture separators, dryers, and filters (supply side).

Minimizing  pressure  drop  requires  a  systems  approach  in  design  and  maintenance.  Air treatment  components  should  be  selected  with  the  lowest  possible  pressure  drop  at specified maximum operating conditions and best performance. Manufacturers' recommendations for maintenance should be followed, particularly in air filtering and drying equipment,  which  can  have  damaging  moisture  effects  like  pipe  corrosion.  Finally,  the distance the air travels through the distribution system should be minimized. Audits of U.S. cement plants found that the payback period is typically shorter than three months for this measure (IAC, 2012).

Maximize  Allowable  Pressure  Dew  Point  at  Air  Intake. Choose  the  dryer  that  has  the maximum allowable pressure dew point, and best efficiency. A rule of thumb is that desiccant dryers consume 7 to 14% of the total energy of the compressor, whereas refrigerated dryers

consume 1 to 2% as much energy as the compressor (Ingersoll-Rand, 2001). Consider using a dryer with a floating dew point.

Improved  Load  Management. Because  of  the  large  amount  of  energy  consumed  by compressors, whether in full operation or not, partial load operation should be avoided. For example, unloaded rotary screw compressors still consume 15% to 35% of full-load power while delivering no useful work (U.S. DOE and CAC, 2003).

Air receivers can be employed near high demand areas to provide a supply buffer to meet short-term  demand  spikes  that  can  exceed  normal  compressor  capacity.  In  this  way,  the number  of required online compressors  may  be  reduced. Multi-stage compressors theoretically operate more efficiently than single-stage compressors. Multi-stage compressors save energy by cooling the air between stages, reducing the volume and work required to compress the air. Replacing single-stage compressors with two-stage compressors  typically  provides  a  payback  period  of  two  years  or  less  (Ingersoll-Rand, 2001).  Using  multiple  smaller  compressors  instead  of  one  large  compressor  can  save energy as well. Large compressors consume more electricity when they are unloaded than do  multiple  smaller  compressors  with  similar  overall  capacity.  An  analysis  of  U.S.  case studies  shows  an  average  payback  period  for  optimally  sizing  compressors  of  about  1.4 years (IAC, 2012).

In June 2004, the Canandaigua Wine Company upgraded the compressed air system at its winery in Lodi, California. Before the project began, the winery was served by two 125 hp rotary  screw  compressors  that  operated  at  full  load  only  during  the  3-month  fall  grape crushing season. During the rest of the year, however, the compressors were operated at part-load,  which  wasted  energy.  The  company  opted  to  install  a  75  hp  variable-speed compressor, which could be used to satisfy facility demand during the off-season while also providing  supplemental  power  to  the  two  125  hp  units  during  the  fall  crush  season. Additionally,  the  company  installed  a  new  compressor  control  system,  additional  storage, and started a leak reduction campaign. The total energy savings attributable to the upgrade were estimated at 218,000 kWh per year, saving the company $27,000 annually (U.S. DOE, 2005c). The simple payback period was estimated at 1.2 years.

Reducing the Inlet Air Temperature. Reducing the inlet air temperature reduces energy used by the compressor. In many plants, it is possible to reduce inlet air temperature to the compressor  by  taking  suction  from  outside  the  building.  Importing  fresh  air  can  have paybacks of 2 to 5 years (CADDET, 1997b). As a rule of thumb, each 5 F (3 C) will save   1% compressor energy use (CADDET, 1997b; Parekh, 2000). In addition to energy savings, compressor capacity is increased when cold air from outside is used. Industrial case studies have found an average payback period for importing outside air of less than 1.4 years (IAC, 2012), but costs can vary significantly depending on facility layout.

Controls. The primary objectives of compressor control strategies are to shut off unneeded compressors and to delay bringing on additional compressors until needed. Energy savings for sophisticated compressor controls have been reported at around 12% annually (Radgen and  Blaustein,  2001).  An  excellent  review  of  compressor  controls  can  be  found  in

Compressed Air Challenge ® Best Practices for Compressed Air Systems (Second Edition) (Scales  and  McCulloch,  2007).  Common  control  strategies  for  compressed  air  systems include:

-  Start/stop  (on/off)  controls ,  in  which  the  compressor  motor  is  turned  on  or  off  in response to the discharge pressure of the machine. Start/stop controls can be used for  applications  with  very  low  duty  cycles  and  are  applicable  to  reciprocating  or rotary screw compressors. The typical payback for start/stop controls is one to two years (CADDET, 1997b).
-  Load/unload  controls ,  or  constant  speed  controls,  which  allow  the  motor  to  run continuously but unloads the compressor when the discharge pressure is adequate. In most cases, unloaded rotary screw compressors still consume 15% to 35% of fullload  power  while  delivering  no  useful  work  (U.S.  DOE  and  CAC,  2003).  Hence, load/unload controls can be inefficient.
-  Modulating or throttling controls , which allow the output of a compressor to be varied to meet flow requirements by closing down the inlet valve and restricting inlet air to the  compressor.  Throttling  controls  are  applied  to  centrifugal  and  rotary  screw compressors.
-  Single master  sequencing  system  controls , which  take  individual compressor capacities  on-line  and  off-line  in  response  to  monitored  system  pressure  demand and shut down any compressors running unnecessarily. System controls for multiple compressors typically offer a higher efficiency than individual compressor controls.
-  Multi-master  controls ,  which  are  the  latest  technology  in  compressed  air  system control.  Multi-master controls are capable of handling four or more compressors and provide  both  individual  compressor  control  and  system  regulation  by  means  of  a network  of individual controllers (Martin et al., 2000). The  controllers share information, allowing the system to respond more quickly and accurately to demand changes.  One  controller  acts  as  the  lead,  regulating  the  whole  operation.  This strategy  allows  each  compressor  to  function  at  a  level  that  produces  the  most efficient overall operation. The result is a highly controlled system pressure that can be  reduced  close  to  the  minimum  level  required  (U.S.  DOE  and  CAC,  2003). According to Nadel et al. (2002), such advanced compressor controls are expected to deliver energy savings of about 3.5% where applied.

In addition to energy savings, the application of controls can sometimes eliminate the need for some existing compressors, allowing extra compressors to be sold or kept for backup. Alternatively,  capacity  can  be  expanded  without  the  purchase  of  additional  compressors. Reduced operating pressures will also help reduce system maintenance requirements (U.S. DOE and CAC, 2003).

Sizing  Pipe  Diameter  Correctly. Inadequate  pipe  sizing  can  cause  pressure  losses, increase  leaks  and  increase  generating  costs.  Pipes  must  be  sized  correctly  for  optimal performance  or  resized  to  fit  the  current  compressor  system.  Increasing  pipe  diameter

typically reduces annual energy consumption by 3% (Radgen and Blaustein, 2001). Further savings  can  be  realized  by  ensuring  other  system  components  (e.g.,  filters,  fittings,  and hoses) are properly sized.

Heat Recovery for Water Preheating. As much as 80 to 93% of the electrical energy used by an industrial air compressor is converted into heat. In many cases, a heat recovery unit can recover 50 to 90% of this available thermal energy for space heating, industrial process heating,  water  heating,  makeup  air  heating,  boiler  makeup  water  preheating,  industrial drying, industrial cleaning processes, heat pumps, laundries or preheating aspirated air for oil  burners  (Parekh,  2000).  It's  been  estimated  that  approximately  50,000  Btu/hour  of energy is available for each 100 cfm of capacity (at full load) (U.S. DOE and CAC, 2003). Paybacks are typically less than one year (Galitsky et al., 2005).

Heat recovery for space heating is not as common with water-cooled compressors because an extra stage of heat exchange is required and the temperature of the available heat is lower. However, with large water cooled compressors, recovery efficiencies of 50 to 60% are typical (U.S. DOE and CAC, 2003). Implementing this measure saves up to 20% of the energy used in compressed air systems annually for space heating (Radgen and Blaustein, 2001).

Natural  Gas  Engine-Driven  Air  Compressors. Gas  engine-driven  air  compressors  can replace electric compressors with some advantages and disadvantages. Gas engine-driven compressors are more expensive and can have higher maintenance costs, but may have lower overall operating costs depending on the relative costs of electricity and gas. Variablespeed capability is standard for gas-fired compressors, offering a high efficiency over a wide range  of  loads.  Heat  can  be  recovered  from  the  engine  jacket  and  exhaust  system. However, gas engine-driven compressors have some  drawbacks: they need more maintenance,  have  a  shorter  useful  life,  and  sustain  a  greater  likelihood  of  downtime. According  to  Galitsky  et  al.  (2005),  gas  engine-driven  compressors  currently  account  for less than 1% of the total air compressor market.

Ultra  Creative  Corporation,  a  U.S.  manufacturer  of  specialty  plastic  bags,  installed  gas engine-driven  compressors  in  its  plant  in  Brooklyn,  New  York.    The  initial  costs  were $85,000 each for two 220 hp units and $65,000 for one 95 hp unit. The company reported savings of $9,000 in monthly utilities (averaging $108,000 annually) (Audin, 1996).

Similarly, Nestlé Canada found that its gas engine-driven air compressor system was a cost effective  option  when  it  was  operated  properly.  The  company's  projected  payback  period was estimated as low as 2.6 years with a 75% efficient heat recovery system, and as high as 4.2 years without heat recovery (Audin, 1996).

## Fan Systems

As in other motor applications, considerable opportunities exist to upgrade the performance and  improve  the  energy  efficiency  of  fan  systems.  For  fans  in  particular,  concern  about failure  or  underperformance  have  led  to  many  fans  being  oversized  for  their  particular application  (U.S.  DOE  2003c).  Oversized  fans  do  not  operate  at  optimal  efficiency  and

therefore waste energy.  However, the efficiencies of fan systems vary considerably across impeller types.

High Efficiency Fans. Many old cement plants are equipped with older technology fans. Older fans have a typical efficiency of 60-65%, while new design fans can operate at 80% efficiency. We assume a decrease in electricity use of 1 kWh/ton clinker. The investment cost is estimated at $0.50/ton clinker (Hollingshead and Venta, 2009).

Maintenance .  As for most energy using systems, a proper maintenance program for fans can  improve  system  performance,  reduce  downtime,  minimize  repair  costs,  and  increase system reliability. The U.S. DOE recommends establishing a regular maintenance program for  fan  systems,  with  intervals  based  on  manufacturer  recommendations  and  experience with fans in similar applications (U.S. DOE, 2003). Additionally, the U.S. DOE recommends the  following  important  elements  of  an  effective  fan  system  maintenance  program  (U.S. DOE, 2003):

-  Belt inspection . In belt-driven fans, belts are usually the most maintenance-intensive part of the fan assembly. Belts wear over time and can lose tension, which reduces their  ability  to  transmit  power  efficiently.  Belt  inspection  and  tightening  should  be performed on a regular basis, especially for large fans because the potential size of the power loss.
-  Fan cleaning . Many fans experience a significant loss in energy efficiency due to the buildup  of  contaminants  on  blade  surfaces.  Such  build  up  can  create  imbalance problems that can reduce performance and contribute to premature wear of system components. Fans that operate in particulate-laden or high-moisture airstreams are particularly vulnerable and are therefore recommended to be cleaned regularly.
-  Leak inspection and repair. Leakage in a fan duct system will decrease the amount of  air  that  is  delivered  to  the  desired  end  use,  which  can  significantly  reduce  the efficiency of the fan system. Ductwork should be inspected on a regular basis and leaks  should  be  repaired  as  soon  as  possible.  In  systems  with  inaccessible ductwork,  the  use  of  temporary  pressurization  equipment  can  determine  if  the integrity of the system is adequate.
-  Bearing  lubrication. Worn  bearings  can  lead  to  premature  fan  failure,  as  well  as create unsatisfactory noise levels. Fan bearings should be monitored and lubricated frequently based on manufacturer recommendations.
-  Motor  replacement. Eventually,  all  fan  motors  will  wear  and  will  require  repair  or replacement. The decision to repair or replace a fan motor should be based on a life cycle costs analysis, as described in the motor's system section.

Properly Sized Fans. Conservative engineering practices often result in the installation of fans  that  exceed  system  requirements.  Such  oversized  fans  lead  to  higher  capital  costs, higher maintenance costs, and higher energy costs than fans that are properly sized for the

job (U.S. DOE, 2003). However, other options may be more cost effective than replacing an oversized fan with a smaller fan (U.S. DOE, 2002). Other options include (U.S. DOE, 2003):

-  Decreasing  fan  speed  using  different  motor  and  fan  sheave  sizes  (may  require downsizing the motor)
-  Installing an ASD or multiple-speed motor (see below)
-  Using an axial fan with controllable pitch blades

At  a  Louisiana  Pacific  Corporation  board  mill  in  Tomahawk,  Wisconsin,  a  fan  system optimization  project  was  pursued  to  resize  and  replace  fans  to  better  meet  airflow  and pressure requirements. The previous system was originally relocated from Colorado, where thinner high elevation air required greater fan speed. This system had to be modified with dampers on the combustion air, dryer, and scrubber fans when it was installed in Wisconsin. The new fan system led to electricity savings of about 2.5 million kWh per year, with annual cost savings of around $85,000. With investment costs of $44,000, the payback period was only around 6 months (U.S. DOE, 1999).

The  Roanoke  Cement  plant  upgraded  a  fan  after  a  bypass  precipitator  to  baghouse conversion. A 500 horse power fan is required to make cold starts but once the process is up to temperature, the power on the fan drops of to 300 hp utilizing a damper. In 2008, a medium voltage variable speed drive was installed and under normal running conditions the fan pulls around 80 hp. The project exceeded the estimated 2 year payback period by 15 months (Drzymala, 2012).

Adjustable Speed Drives (ASDs) and Improved Controls. Significant energy savings can be achieved by installing adjustable speed drives on fans. Savings may vary between 14% and 49% when retrofitting fans with ASDs (U.S. DOE, 2002).

High Efficiency Belts (cog belts). Belts make up a variable, but significant portion of the fan system in many plants. It is estimated that about half of the fan systems use standard V-belts, and about two-thirds of these could be replaced by more efficient cog belts (U.S. DOE, 2002). Standard V-belts tend to stretch, slip, bend and compress, which lead to a loss of efficiency. Replacing standard V-belts with cog belts can save energy and money, even as a retrofit. Cog belts run cooler, last longer, require less maintenance and have an efficiency that is about 2% higher  than  standard  V-belts.  Typical  payback  periods  will  vary  from  less  than  one  year  to three years.

Duct Leakage Repair. Duct  leakage can waste significant amounts of energy in fan and ventilation  systems.  Measures  for  reducing  duct  leakage  include  installing  duct  insulation and performing regular duct inspection and maintenance, including ongoing leak detection and repair. For example, according to studies by Lawrence Berkeley National Laboratory, repairing  duct  leaks  in  industrial  and  commercial  spaces  could  reduce  HVAC  energy consumption by up to 30% (Galitsky et al., 2005).

Because system leakage can have a significant impact on fan system operating costs, the U.S.  DOE    recommends  considering  the  type  of  duct,  the  tightness  and  quality  of  the fittings,  joints  assembly  techniques,  and  the  sealing  requirements  for  duct  installation  as part of the fan system design process as proactive leak prevention measures (U.S. DOE, 2003).

## Lighting

Energy  use  for  lighting in the cement  industry  is  very  small.  Still, energy  efficiency opportunities may be found that can reduce energy use cost-effectively. Lighting is used either to provide overall ambient lighting throughout the manufacturing, storage and office spaces or to provide low-bay and task lighting to specific areas. High-intensity discharge (HID) sources are  used  for  the  former,  including  metal  halide,  high-pressure  sodium  and  mercury  vapor lamps. Fluorescent, compact fluorescent (CFL) and incandescent lights are typically used for task lighting in offices.

Table 6 provides an overview of the typical performance and applications of various lamp types.

Table 6. Performance comparison of lighting sources

| Lamp                 | Efficacy (Lumen/watt)   | Typical Lifetime (Hours)   | Applications       |
|----------------------|-------------------------|----------------------------|--------------------|
| Incandescent         | 5-20                    | 1,000                      | Task               |
| Halogen              | <24                     | 1,000                      | Task               |
| CFL                  | 20-70                   | 8,000-15,000               | Task               |
| Fluorescent T - 12   | 60                      | 20,000                     | Any                |
| Fluorescent T - 8    | 80-100                  | 20,000                     | Any                |
| Fluorescent T - 5    | 80-105                  | 20,000                     | Any                |
| Mercury Vapor        | 30 - 50                 | 60,000                     | Hi - Bay           |
| Induction            | 80                      | 100,000                    | Exterior, Hi - Bay |
| High Pressure Sodium | 85-150                  | 10,000-50,000              | Exterior, Hi - Bay |
| Metal Halide         | 70-115                  | 20,000                     | Hi - Bay           |
| LED                  | 10-120                  | 50,000                     | Task               |

Note:  Values  are  typical  performance.  Performance  of  individual  products  may  vary.  The performance  of  fluorescent  lamps  assumes  the  use  of  an  electronic  ballast.  Technology development may change the future performance of specific lighting technologies.

Turning Off Lights in Unoccupied Areas. An easy and effective measure is to encourage personnel to turn off lights in unoccupied building spaces. An energy management program that aims to improve the awareness of personnel with regard to energy use can help staff get in the habit of switching off lights and other equipment when not in use.

Lighting Controls. Lights can be shut off during non-working hours by automatic controls, such as occupancy sensors which turn off lights when a space becomes unoccupied. Manual controls can also be used in addition to automatic controls to save additional energy in smaller areas.  Numerous  case  studies  throughout  the  United  States  suggest  that  the  average payback period for occupancy sensors is approximately 1 year (IAC, 2012). In a case study from the pharmaceutical industry, at the Merck office and storage building in Rahway, New Jersey, lighting panels were programmed to turn off automatically during expected periods of building  non-use  (override  switches  in  entrance  hallways  allowed  lights  to  be  turned  on manually during these times, if needed). Annual savings amounted to 1,310 MBtu per year, which corresponded to avoided energy-related carbon dioxide (CO2) emissions of nearly 260 tons per year (Merck, 2005).

Manual  controls  can  be  used  in  conjunction  with  automatic  controls  to  save  additional energy  in  smaller  areas.  One  of  the  easiest  measures  is  to  install  switches  to  allow occupants to control lights. Other lighting controls include daylight controls for indoor and outdoor  lights,  which  adjust  the  intensity  of  electrical  lighting  based  on  the  availability  of daylight.

An example of energy efficient lighting control is illustrated by Figure 10, which depicts five rows of overhead lights in a workspace. During the brightest part of the day, ample daylight is provided by the window and thus only row C would need to be turned on. At times when daylight levels drop, all B rows would be turned on and row C would be turned off. Only at night  or  on  very  dark  days  would  it  be  necessary  to  have  both  rows  A  and  B  turned  on (Cayless and Marsden, 1983). These methods can also be used as a control strategy on a retrofit  by  adapting  the  luminaries  already  present  (for  example,  turning  on  the  lighting  in rows farthest away from the windows during the brightest parts of the day, then turning on additional rows as needed later).

Figure 10. Lighting placement and controls.

<!-- image -->

Exit  Signs .  Energy  costs  can  be  reduced  by  switching  from  incandescent  lamps  to  light emitting diodes (LEDs) or radium strips in exit sign lighting. An incandescent exit sign uses about 40 W, while LED signs may use only about 4W to 8 W, reducing electricity use by 80% to 90%. A 1998 Lighting Research Center survey found that about 80% of exit signs being  sold  use  LEDs  (LRC,  2001).  The  lifetime  of  an  LED  exit  sign  is  about  10  years, compared to 1 year for incandescent signs, which can reduce exit sign maintenance costs considerably. In addition to exit signs, LEDs are increasingly being used for path marking and emergency way finding systems. Their long life and cool operation allows them to be embedded in plastic materials, which makes them well suited for such applications (LRC, 2001).

New LED exit signs are inexpensive, with prices typically starting at around $20. The U.S. EPA's  ENERGY  STAR  program  website  (http://www.energystar.gov)  provides  a  list  of suppliers of LED exit signs.

Tritium exit signs are an alternative to LED exit signs. Tritium signs are self-luminous and thus  do  not  require  an  external  power  supply.  The  advertised  lifetime  of  these  signs  is around 10 years and prices typically start at around $150 per sign.

Replace  Magnetic  Ballasts  with  Electronic  Ballasts. A  ballast  is  a  mechanism  that regulates the amount of electricity required to start a lighting fixture and maintain a steady output of light. Electronic ballasts can require 12% to 30% less power than their magnetic predecessors (Cook, 1998; Galitsky et al., 2005). New electronic ballasts have smooth and silent  dimming  capabilities,  in  addition  to  longer  lives  (up  to  50%  longer),  faster  run-up times,  and  cooler  operation  than  magnetic  ballasts  (Eley  et  al.,  1993;  Cook,  1998).  New electronic ballasts also have automatic switch-off capabilities for faulty or end-of-life lamps.

Replace T-12 Tubes by T-8 Tubes . In industry, typically T-12 tubes have been used. T-12 refers  to  the  diameter  in  1/8  inch  increments  (T-12  means  12/8  inch  or  3.8  cm  diameter tubes). The initial output for these lights is high, but energy consumption is also high. They also have extremely poor efficacy, lamp life, lumen depreciation, and color rendering index. Because of this, maintenance and energy costs are high. Replacing T-12 lamps with T-8 lamps (smaller diameter) approximately doubles the efficacy of the former. Typical energy savings from the replacement of a T-12 lamp by a T-8 lamp are around 30% (Galitsky et al., 2005).

High-Intensity Discharge (HID) Voltage Reduction. Reducing lighting system voltage can also  save  energy.  A  Toyota  production  facility  installed  reduced-voltage  HID  lights  and realized a 30% reduction in lighting energy consumption (Galitsky et al., 2005). Commercial products are available that attach to a central panel switch (controllable by computer) and constrict  the  flow  of  electricity  to  lighting  fixtures,  thereby  reducing  voltage  and  saving energy,  with  an  imperceptible  loss  of  light.  Voltage  controllers  work  with  both  HID  and fluorescent lighting systems and are available from multiple vendors.

Replace Mercury Lights by Metal Halide or High Pressure Sodium Lights. Where color rendition  is  critical,  metal  halide  lamps  can  replace  mercury  or  fluorescent  lamps  with  an

energy savings of 50%. Where color rendition is not critical, high pressure sodium lamps offer energy savings of 50 to 60% compared to mercury lamps (Price and Ross, 1989).

Replace Metal Halide HID with High-Intensity Fluorescent Lights. Traditional HID lighting can be replaced with high-intensity fluorescent lighting. These new systems incorporate highefficiency fluorescent lamps, electronic ballasts and high-efficacy fixtures that maximize output to  the  work  plane.  Advantages  to  the  new  system  are  many;  they  have  lower  energy consumption, lower lumen depreciation over the lifetime of the lamp, better dimming options, faster start-up and restrike capability, better color rendition, higher pupil lumens ratings and less  glare  (Martin  et  al.,  2000).  High-intensity  fluorescent  systems  yield  50%  electricity savings over standard metal halide HID. Dimming controls that are impractical in the metal halide HIDs can also save significant energy. Retrofitted systems cost about $185 per fixture, including  installation  costs  (Martin,  et  al.,  2000).  In  addition  to  energy  savings  and  better lighting qualities, high-intensity fluorescents can help improve productivity and have reduced maintenance costs.

Daylighting. Daylighting involves the efficient use of natural light in order to minimize the need for artificial lighting in buildings. Increasing levels of daylight within rooms can reduce electrical  lighting  loads  by  up  to  70%  (CADDET,  2001;  IEA,  2000).  Unlike  conventional skylights, an efficient daylighting system may provide evenly dispersed light without creating heat gains, which can reduce the need for cooling compared to skylights. Daylighting differs from other energy efficiency measures because its features are integral to the architecture of  a  building;  therefore,  it  is  applied  primarily  to  new  buildings  and  incorporated  at  the design  stage.  However,  existing  buildings  can  sometimes  be  cost-effectively  refitted  with daylighting systems.

Daylighting can be combined with lighting controls to maximize its benefits. Because of its variability,  daylighting  is  almost  always  combined  with  artificial  lighting  to  provide  the necessary  illumination  on  cloudy  days  or  after  dark  (see  also  Figure  10).  Daylighting technologies include properly placed and shaded windows, atria, clerestories, light shelves, and light ducts. Clerestories, light shelves, and light ducts can accommodate various angles of the sun and redirect daylight using walls or reflectors.

More information on daylighting can be found at the website of the Daylighting Collaborative led by the Energy Center of Wisconsin (http://www.daylighting.org/).

LED Lighting. Light Emitting Diode (LED) lights have been receiving a lot of attention as the next generation of energy efficient lighting. In typical florescent lighting, electrical arcs are  used  to  excite  mercury  and  phosphorous  compounds,  which  then  emit  light.  On  the other hand, LED lights are semiconductor diodes that use far less energy to emit the same lumens  of  light.  Several  new  LED  light  products  that  are  compatible  with  current  light fixtures, such as T-8 light fixtures are emerging on the market (Myer et al. 2009).

## Dust Control

Main sources of dust emissions in the cement industry are the kiln systems, clinker coolers, cement  mills  and  the  conveying  systems.  In  new  cement  plants  only  bag  filters  (BF)  or

electrostatic precipitators (EPs) are installed (CEMBUREAU, 1997). To ensure the proper operation of dust collectors, pulse air jets, mechanical shakers, bags and cartridges need to be inspected regularly, fabric bags need to be sized correctly and fitted properly, and all the worn fabrics should be replaced (MEMS, 2010).

Significant energy savings are expected when the motors used to drive the dust collectors shut down when not needed; see also the Motor Automation Section. Best practices for dust collectors according to Bayne (2011) can ensure efficient operation of baghouse filters at the minimum energy consumption:

-  Seal areas, as the existence of leaks will increase draft requirements.
-  Employ the minimum effective draft .  Extra  draft  employment  will  accumulate  more dust  on  the  filters  resulting  in  increased  wear  of  ducts  and  bags.  Use  dampers and/or variable speed fans to control the draft.
-  Automate dust collectors so that they don't operate when not needed.
-  Resizing  and  slowing  down  fans  that  are  too  big  will  result  in  energy  savings. Installing a variable frequency driver (VFD) will require higher capital investment but will result in more energy savings.
-  Maintain  the  differential  pressure across  the  dust  collector  (pressure  difference between the dirty and clean side of the bags) between 4 to 5 inches of water. For the efficient operation of dust collectors filters should be relatively dirty or have a dust cake.
-  Use  a differential  pressure  control  system on  your  cleaning  system.  Differential pressure  should  range  between  4  and  5  inches  of  water  when  a  fan  driven  dust collector is used.
-  When  a  compressed  air  jet  pulse  cleaning  system  is  used  employ  the minimum effective pressure which usually ranges between 60 and 70 psi, and not more than the manufacturer's recommended pressure when a pneumatic shaker is used.
-  Employ a rather short pulse to shake the extra dust off in the case of compressed air blow down systems.

## 6.9 Product Changes

Alkali Content. In North America, part of the production of the cement industry are cements with a low alkali content (probably around 20-50% of the market), a much higher share than found  in  many  other  countries  (Holderbank,  1993).  In  some  areas  in  the  U.S.,  aggregate quality may  be  such  that  low-alkali  cements  are  required  by  the  cement  company's customers. Reducing the alkali content is achieved by venting (called the by-pass) hot gases and particulates from the plant, loaded with alkali metals. The by-pass also avoids plugging in the preheaters. This becomes cement kiln dust (CKD). Disposal of CKD is regulated under the  Resource  Conservation  and  Recovery  Act  (RCRA).  Many  customers  demand  a  lower

alkali content, as it allows greater freedom in the choice of aggregates. The use of fly-ash or blast-furnace slags as aggregates (or in the production of blended cement, see below) may reduce  the  need  for  low-alkali  cement.  Savings  of  2-5  kcal/kg  per  percent  bypass  are assumed (Alsop and Post, 1995). For illustrative purposes, assume a 20%-point reduction in bypass  volume,  resulting  in  energy  savings  of  0.1-0.2  MBtu/ton  clinker.  According  to Bolwerk et al. (2006), low alkali cement production leads to higher energy consumption of about  5-10  kBtu/ton  clinker  per  percent  bypass.  Typically,  the  bypass  rates  are  15%  for chlorine bypass and 70% for sulphur bypass (IPPC, 2010). Additionally, electricity is saved due to the increased cement production, as the CKD would otherwise end up as clinker. There  are  no  investments  involved  in  this  product  change,  although  cement  users  (e.g. ready-mix producers) may need to change the type of aggregates used (which may result in costs). Hence, this measure is most successfully implemented in coordination with readymix producers and other large cement users.

Blended Cements. The production of blended cements involves the intergrinding of clinker with one or more additives (fly ash, pozzolans, granulated blast furnace slag, silica fume, and  volcanic  ash)  in  various  proportions.  The  use  of  blended  cements  is  a  particularly attractive  efficiency  option  since  the  intergrinding  of  clinker  with  other  additives  not  only allows for a reduction in the energy used (and carbon emissions) in clinker production, but also  corresponds  to  a  reduction  in  carbon  dioxide  emissions  in  calcination  as  well.  The intergrinding of one ton of additives will offset the environmental impact (NOx, SO2, CO2, PM  and  other  emissions)  of  producing  one  ton  of  Portland  cement  (about  0.95  tons  of clinker)  (Staudt,  2009b).  Blended  cement  has  been  used  for  many  decades  and  longer around the world.

Blended cements are very common in Europe, and blast furnace and pozzolanic cements account  for  about  12%  of  total  cement  production  with  portland  composite  cement accounting for an additional 59% (IPPC, 2010). Blended cement was introduced in the U.S. to  reduce  production costs  for  cement  (especially  energy  costs),  expand  capacity  without extensive capital costs, to reduce emissions from the kiln. In Europe a common standard has  been  developed  for  25  types  of  cement  (using  different  compositions  for  different applications).  The  European  standard  allows  wider  applications  of  additives.  Many  other countries  around  the  world  use  blended  cement.  Blended  cements  demonstrate  a  higher long-term strength, as well as improved resistance to acids and sulfates, while using waste materials for high-value applications. Short-term strength (measured after less than 7 days) may  be  lower,  although  cement  containing  less  than  30%  additives  will  generally  have setting times comparable to concrete based on Portland cement.

In  the  U.S.  the  consumption  and  production  of  blended  cement  is  still  limited.  Cement companies use only limited amounts of additives as grinding and flow aids. In the U.S., the concrete companies usually are the ones that add high amounts of additives. As explained by Staudt (2009b), this is probably due to the U.S. market structure, as concrete companies can  be  situated  closer  to  the  additive  sources,  thus  making  it  more  cost-effective  to  add SCMs  (Supplementary  Cementitious  Materials)  and  pozzolans  during  concrete  blending instead of cement blending (Staudt, 2009b). Another reason is that concrete companies can adjust their products according to the specific needs of the local markets (Staudt, 2009b). In

2010, 95% of granulated blast furnace slag produced (2.5 million metric tonnes), was sold for  cementitious  purposes  (USGS,  2012c).  Of  which,  70,000  metric  tonnes  were  used  in clinker  production  and  235,000  metric  tonnes  were  used  in  blended  cement  production (USGS,  2012a).  The  remaining  2.2  million  metric  tonnes  were  used  by  the  concrete industry.

In the U.S., the most prevalent blending materials are fly ash and granulated blast furnace slag. Not all slag and fly ash is suitable for cement production. It is estimated that 68% of fly ash in the U.S. conforms to ASTM C618 (VDZ and PENTA, 2008). Currently, only a small part of the blast furnace slag is produced as granulated slag, while the majority is air-cooled. Air-cooled  slag  cannot  be  used  for  cement  production,  and  is  of  lesser  value.  However, investments in slag processing by slag processors and cement companies will increase this fraction.  ASTM  Standards  exist  for  different  types  of  blended  cements,  i.e.  C989  (slag cement), C595 and C1157. U.S. EPA (2000) has issued procurement guidelines to support the use of blended cement in (federal) construction projects.

An analysis of the U.S. situation cited an existing potential of producing 34 million tons of blended cement in 2000 using both fly ash and blast furnace slag, or 36% of U.S. capacity (PCA,  1997).  This  analysis  was  based  on  estimates  of  the  availability  of  intergrinding materials and surveying ready-mix companies to estimate feasible market penetration.

The blended cement produced would have, on average, a clinker/cement ratio of 65% or would result in a reduction in clinker production of 10.3 million tons. The reduction in clinker production corresponds to a specific fuel savings of 0.9 MBtu/ton (the calculation was based on the clinker content (88%) and average fuel use (3.3 MBtu/ton cement) in 2009, in the U.S. There is an increase in fuel use of 0.08 MBtu/ton for drying of the blast furnace slags but a corresponding energy savings of 0.17 MBtu/ton for reducing the need to use energy to bypass  kiln  exit  gases  to  remove  alkali-rich  dust.  Energy  savings  are  estimated  at  4-10 Btu/lb per percent bypass (Alsop and Post, 1995). The bypass savings are due to the fact that blended cements offer an additional advantage in that the interground materials have also lower alkali-silica reactivity (ASR) thereby allowing a reduction in energy consumption needed to remove the high alkali  content  kiln  dusts.  In  practice,  bypass  savings  may  be minimal to avoid plugging of the preheaters, requiring a minimum amount of bypass volume. This  measure  results  in  total  fuel  savings  of  1.0  MBtu/ton  blended  cement.  Electricity consumption  however  is  expected  to  increase  due  to  the  added  electricity  consumption associated  with  grinding  blast  furnace  slag  (as  other  materials  are  more  or  less  fine enough).

The costs of applying additives in cement production may vary. Capital costs are limited to extra storage capacity for the additives. However, blast furnace slag may need to be dried before use in cement production. This can be done in the grinding mill, using exhaust from the  kiln,  or  supplemental  firing,  either  from  a  gas  turbine  used  to  generate  power  or  a supplemental  air  heater.  The  operational  cost  savings  will  depend  on  the  purchase

(including  transport)  costs  of  the  additives 15 ,  the  increased  electricity  costs  for  (finer) grinding, the reduced fuel costs for clinker production and electricity costs for raw material grinding and kiln drives, as well as the reduced handling and mining costs. These costs will vary  by  location,  and  would  need  to  be  assessed  on  the  basis  of  individual  plants.  An increase  in  electricity  consumption  of  15  kWh/ton  (Buzzi,  1997)  is  estimated  while  an investment cost of $0.65/ton cement capacity, which reflects the cost of new delivery and storage  capacity  (bin  and  weigh-feeder)  is  assumed.  According  to  another  study,  the investment  cost  for  receiving,  metering  and  storing  the  additives  is  estimated  at  $4.1/ton clinker (Hollingshead and Venta, 2009).

ECRA (2009) estimated the reduction in energy use from using 30-70% by mass granulated blast  furnace  slag  (GBFS),  at  0.4-1.6  MBtu/ton  cement  (the  average  European  clinker  to cement  ratio  at  the  time  of  the  study  was  75%).  Electricity  was  not  estimated  to  be significantly influenced. The U.S. clinker to cement ratio (88%) is higher than the European. Therefore, the use of 70% (by mass) GBFS in the U.S cement industry would result in even higher  energy  savings,  estimated  at  2.3  MBtu/ton  cement.  ECRA  (2009)  estimated  the investment cost for a new silo for storing the new cements (blast furnace slag can be stored outside)  and  for  the  slag  handling  and  drying  equipment  to  range  between  $7-14  million. When fly ash or pozzolans are used the investment costs are estimated at about $11-17 millions, since extra investment is required for storing (ECRA,  2009). The  above investments  were  based  on  a  2  million  tonne  per  year  clinker  capacity  facility.  The availability of blast furnace slag and fly ash can be limited for cement companies situated away from the generation sources of these materials.

Limestone Portland Cement . Similar to blended cement, ground limestone is interground with clinker to produce cement, reducing the needs for clinker-making and calcination. This reduces energy use in the kiln and clinker grinding and CO2 emissions from calcination and energy use. According to the ASTM C150 standard specification for portland cement, the limestone content cannot be higher than 5%. In European and other countries the limestone content in cement can be much higher. Addition of up to 5% limestone has shown to have no negative impacts on the performance of portland cement, while an optimized limestone cement  would  improve  the  workability  slightly  (Detwiler  and  Tennis,  1996).  Adding  5% limestone  would  reduce  fuel  consumption  by  5%  (or  on  average  0.2  MBtu/ton  clinker), power consumption for grinding by 3.0 kWh/ton cement, and CO2 emissions by almost 5%. Limestone is an easily available material for cement producers. The additional costs would be minimal, limited to material storage and distribution, while reducing kiln operation costs by 5%.

15 The  average  cost  of  granulated  blast  furnace  slag  is  about  $75/ton  (in  2010  dollars)  (USGS, 2012c). This figure may not include shipping costs, which in case the slag source is not close to the facility, operational costs can increase to prohibitive levels (Staudt, 2009b). The price for high-quality fly ash in 1997 was about $25-30/ton, excluding transportation costs which can range between $0.100.13/ton-mile  (1997  prices)  (Robl  et  al.,  1997).  In  2010,  the  price  of  natural  pozzolans  for  cement manufacture like diatomite was less than $9/ton (fob plant), and for common clays about $13/ton (fob plant) (USGS, 2011c; USGS, 2011b).

Reducing  the  Fineness  for  Particular  Applications. Cement  is  normally  ground  to  a uniform fineness. However, the applications of cement vary widely, and so does the optimal fineness. The grinding of the cement to the desired fineness could reduce the energy demand for grinding. Holderbank (1993) suggests that cement in Canada and the U.S. is ground finer (on average) than in Western Europe, which suggests that energy savings could be achieved. The exact savings will depend on the grindability of the clinker. As a rule of thumb, for each 100  additional  Blaine  points,  grinding  power  requirements  increase  by  5%  (Holderbank, 1993). Holderbank (1993) reviewed 23 European and 20 North-American plants and found that the European plants use on average 14 kWh/ton less for cement grinding than the NorthAmerican plants. Note that finer cement may reduce the amount of concrete needed for a structure, due to the higher strength. It is hard to estimate the total savings due to the many factors  affecting  strength  of  concrete  and  grinding  energy  requirements.  Also,  without  a detailed assessment of the market and applications of cement, it is difficult to estimate the total  potential  contribution  of  this  measure  to  potential  energy  savings  in  the  U.S.  cement industry.

## 6.10 Feedstock Changes

The use of decarbonated feedstock material (i.e. electric arc furnace slag, granulated blast furnace  slag,  fly  ash,  and  cement  kiln  dust)  as  kiln  feedstock  instead  of  limestone  will reduce the energy use and the CO2 emissions from calcination and from the reduced fuel use (Bhatty and Gajda, 2004).

Steel Slag, CemStar ® . Texas Industries (Midlothian, Texas) in 1994 developed a system to use electric arc furnace (EAF) slags of the steel industry as input in the kiln, reducing the use of limestone. The slag contains C3S, which can more easily be converted to free lime than  limestone.  The  slags  replace  limestone  (approximately  1.6  times  the  weight  in limestone). EAFs produce between 110 and 420 pounds of slag per ton of steel (on average 232 lbs/ton) (U.S. DOE-OIT, 1996). EAF steel production is estimated at almost 54 million tons  (2010)  (49  million  tonnes).  EAF-slag  production  is  estimated  at  8.2  million  tons, potentially  replacing  an  equal  amount  of  clinker  (USGS,  2012b;  USGS,  2012c).  The CemStar  process allows replacing 10-15% of the clinker by EAF-slags, reducing energy ® needs for calcination. The advantage of the CemStar  process is the lack of grinding the slags, but adding them to the kiln in 2 inch lumps. Depending on the location of injection it may  also  save  heating  energy.  Calcination  energy  is  estimated  at  1.6  MBtu/ton  clinker (Worrell et al., 2001). Because the lime in the slag is already calcined, it also reduces CO2 emissions  from  calcination, while the reduced  combustion  energy  and  lower  flame temperatures  lead  to  reduced  NOx  emissions  (Battye  et  al.,  2000;  Staudt,  2009b).  For illustrative purposes alone, using a 10%  injection of slags would reduce energy consumption by 0.16 MBtu/ton of clinker, while reducing CO2 emissions by roughly 11%. Energy  savings  can  be  higher  in  wet  kilns  due  to  the  reduced  evaporation  needs. Reductions in NOx emissions vary by kiln type and may be between 9 and 60%, based on several measurements (Battye et al., 2000; Staudt, 2009b). Equipment costs are mainly for material handling and  vary between  $200,000  and  $500,000  per  installation. Total investments are approximately double the equipment costs. The total capital investment for

a  45  ton/hr  wet  kiln  was  estimated  by  Staudt  (2009b)  at  $1.5  million  (2005  dollars). Hollingshead  and  Venta  (2009)  estimated  the  investment  cost  for  a  slag  hopper  with  a regulated  withdrawal  system  and  conveyors  to  feed  the  kiln  at  $0.9/ton  clinker,  while  the additional operating costs were estimated at $0.1/ton clinker. According to the same study, with the addition of steel slag, production can increase by 5%, with corresponding energy savings of 0.05 MBtu/ton clinker and electricity savings of 3 kWh/ton clinker. Energy and CO2  savings  depend  on  the  CemStar ® royalty  fee  charges  (Battye  et  al.,  2000).  Costs savings consist of increased income from additional clinker produced (steel slag ($5-15/ton) costs less than clinker ($73/ton) (Staudt, 2009b)) without increase in operation and energy costs, as well as reduced iron ore purchases ($0.5-1.0/ton clinker) (as the slag provides part of  the  iron  needs  in  the  clinker).  The  iron  content  needs  to  be  balanced  with  other  iron sources  such  as  tires  and  iron  ore.  U.S.  EPA  awarded  the  CemStar ® process  special recognition in 1999 as part of the ClimateWise program.

The Davenport cement plant in California, introduces 2-5% steel slag directly into the kiln in a  patented  process.  Energy  savings  of  2-5%  reduction  and  a  small  reduction  in  NOx emissions have been reported (Renfrew et al., 2004). The Davenport plant has been closed since 2010.

Fly Ash and Blast Furnace Slag. Other sources of calcium that do not require calcination are fly ash and blast furnace slag. Class F and Class C are the two main fly ash classes specified in the ASTM C 168. Class F fly ash is usually produced from burning anthracite or bituminous coal while Class C fly ash is usually produced from burning coal and lignite. In 2009, 63 million  tonnes  of  fly  ash  where  produced  in  the  U.S.,  of  which  about  10  million tonnes were used in concrete facilities to replace Portland cement and 2.4 million tonnes were  used  in  the  cement  industry  either  as  kiln  feed  or  as  substitute  for  clinker  in  the production of blended cements (ACAA, 2011). The capital required is for material handling equipment.  According  to  Staudt  (2009a),  the  price  of  fly  ash  for  limestone  substitution  is significantly lower than the fly ash price for use in the production of blended cements, and it is estimated to range between $5-10/ton and less. As can be seen in Table 7, the use of 1 ton of Class C fly ash in the kiln will substitute 0.45 tons of limestone, it will reduce CO2 emissions  from  calcination  by  0.2  tons,  while  energy  use  will  be  reduced  by  0.6  MBtu (Staudt,  2009a).  According  to  USGS  (2012a),  in  2010,  2.4%  of  raw  materials  used  to produce clinker was fly ash. A 10% kiln feed substitution (based on Cao content) will result in 0.16 MBtu/ton clinker energy savings, while at the same time reduce CO2 emissions by roughly the same percentage.

The energy savings from replacing one ton of kiln feed with blast furnace slag, as can be seen in Table 7, are 1.10 MBtu while the CO2 emission savings from calcination are 0.35 tons. The price of blast furnace slag used as kiln feed is lower compared to when used in blended  cement  production.  According  to  USGS  (2012c),  the  2010  average  price  for  aircooled  blast  furnace  slag  was  $7.5/ton,  while  for  granulated  blast  furnace  slag  ranged between $17-103/ton. For use as a kiln feed the lower end of the price range is probably more representative (Staudt, 2009a).

For illustration purposes, a 15% kiln feed substitution (based on CaO content) will result in energy savings of 0.24 MBtu/ton clinker. According to ECRA (2009) 15% replacement of kiln feed with Granulated Blast Furnace Slag (GBFS) will result in energy savings of 0.090.34 MBtu/ton clinker. A cement plant, in order to meet the extra demand, replaced 7% of kiln feed with Blast Furnace Slag (BFS) and as a result, energy use decreased by nearly the same amount (Lesniak, 2009). Investment costs for handling and storing BFS are estimated at $0-3.5/ton cement (ECRA, 2009).

Table 7. Energy savings and CO2 emission savings by using different decarbonated kiln feedstock

| Kiln Feed Substitutes    | %CaO   |   Limestone equivalence ratio 1 |   Clinker equivalence ratio 2 |   Calcination CO 2 avoided/ton material |   MBtu fuel saved/ton material |
|--------------------------|--------|---------------------------------|-------------------------------|-----------------------------------------|--------------------------------|
| Blast Furnace Slag (BFS) | 45%    |                            0.8  |                          0.69 |                                    0.35 |                           1.1  |
| Steel Slag               | 65%    |                            1.16 |                          1    |                                    0.51 |                           1.59 |
| Class C Fly Ash          | 25%    |                            0.45 |                          0.38 |                                    0.2  |                           0.61 |
| Class F Fly Ash          | 3%     |                            0.05 |                          0.05 |                                    0.02 |                           0.07 |

1. tons of limestone that provide same CaO as one ton of decarbonated material.

2. clinker produced per ton of material used based on CaO content.

Source: Staudt, 2009a

Cement Kiln Dust. Cement  Kiln  Dust  (CKD)  produced  during  calcination  is  collected  by baghouses and electrostatic precipitators. CKD is a partially calcined material with a high CaCO3 content (55.5%) that can be used to substitute kiln feed and at the same time reduce CO2 emissions from calcination. Cement plants that do not recycle CKD have a higher raw material to clinker ratio. CKD disposal decreased dramatically from 54 kg CKD/ton clinker in 1990,  to  15  kg  CKD/tonne  clinker  in  2006  (Adaska  and  Taubert,  2008).  In  dry  process plants,  when  the  kiln  dust  does  not  contain  compounds  in  levels  that  could  affect  kiln operation and product quality, CKD is usually returned to the kiln (VDZ and PENTA, 2008). In wet kilns, kiln dust recirculation may not be possible, as partially calcined CKD tends to cause blockages. A few wet plants have solved this problem with the insufflation 16  of kiln dust  into  the  burning  zone  (VDZ  and  PENTA,  2008).  When  the  insufflation  method  is adopted, the CKD content of the kiln feed is limited to about 15%, as it decreases the flame temperature (U.S. EPA, 1994). Ash Grove Cement Company invested $100,000 (in 1993

16 Insufflation is the practice of injecting cement kiln dust into the kiln flame. In this way, cement kiln dust can be returned to the kiln with a maximum chance of incorporation into the clinker (Alsop et al., 2007), avoiding fine dust recirculation and blockages.

dollars)  in  a  CKD  returning  system  in  order  to  recycle  80-90  tons  of  CKD  per  day  that otherwise would have required disposal (U.S. EPA, 1994). According to Hollingshead and Venta (2009), the investment cost for CKD returning equipment is estimated at $0.10/ton clinker. Clinker production is expected to increase by 2% while electricity and fuel use will increase  by  1  kWh/ton  clinker  and  0.018  MBtu/ton  clinker  respectively  (Hollingshead  and Venta, 2009). Assuming that a 2% increase in throughput translates into 2% less fuel use per ton of product, and taking into account that 0.018 MBtu/ton clinker extra fuel is required, we estimate the energy savings for a dry kiln plant at 0.05 MBtu/ton clinker.

CKD contains  alkali  compounds  that  can  negatively  affect  the  operation  of  the  kiln.  The Fuller  fluidized  process  and  the  Passamaquoddy  Recovery  Scrubber TM   technology  have been developed for CKD treatment. Both technologies are capital intensive with a payback period estimated to be 6 and 3 years respectively (U.S. DOE-NETL, 2001; U.S. EPA, 1994). A cement plant in Thomaston, Maine, installed a recovery scrubber technology, and it not only recovers 100% of the generated CKD but it also recycles the CKD produced during the last 100 years of the plant's operation that was stored at its on-site stockpile (Adaska and Taubert, 2008). The quantity and quality of CKD that can be recycled to the kiln is limited by product  specifications  and  local  market  demands.  In  some  markets,  only  CKD  with  alkali levels within specified limits can be directly returned to the kiln.

Calcareous Oil Shale. Some oil shale deposits contain calcareous material that is partially decarbonated. Calcareous oil shale can serve as kiln feed substitute in clinker production and reduce CO2 emissions from calcination. Calcareous oil shale may also have a calorific value  that  can  be  utilized  either  in  the  calcination  process  or  in  a  furnace  for  power generation (VDZ and Penta, 2008). In case the oil shale is burned separately in a calciner or furnace, the generated ash could then be used in the kiln. Kiln feed with an oil shale content of  8%  has  an  energy  contribution  of  about  72  kBtu/ton  clinker  (Hollingshead  and  Venta, 2009). The investment costs for a new feeding system are estimated at $1/ton clinker with additional operational costs of $0.10/ton clinker (Hollingshead and Venta, 2009). The CO2 reduction  potential  is  estimated  at  0.011  lb  CO /ton  clinker  (0.005  kg  CO /ton  clinker) 2 2 (Hollingshead  and  Venta,  2009).  CO2  reduction  will  be  lower  if  the  oil  shale  needs  to  be processed.

Calcareous oil shale has been used as kiln feed substitute in cement plants in Russia and Germany (Bhatty and Gajda, 2004). At Rohrbach Zement, Germany, oil shale with CaCO3 content of 43% has been used successfully for more than 60 years (Hilger, 2003). Oil shale is used in the precalciner, providing approximately 20% of energy and 10% of raw mineral requirements. However, the majority of oil shale is used in fluidized bed for the production of burnt shale which is then used in the manufacture of blended cements. Finely ground burnt shale is characterized by hydraulic properties similar to that of Portland cement. Rohrbach Zement manufactures blended  cements  with  a  burnt  shale  content  of  up  to  35%.  Waste heat  from  fluidized  beds  is  used  to  generate  electricity  which  exceeds  the  plant's  power requirements  (Hilger,  2003).  The  electricity  use  for  grinding  blended  cement  with  a  27% burnt  shale  content,  is  50%  lower  than  the  electricity  use  for  grinding  Portland  cement (Hilger, 2003).

Reduce the Lime Saturation Factor (LSF). Lime  Saturation  Factor  (LSF)  is  the  ratio  of calcium  oxide  (CaO)  to  the  other  oxides  (SiO ,  Al O   and  Fe O )  and  it  determines  the 2 2 3 2 3 maximum amount of lime that can be combined with the various oxides (Lawrence, 1998; Taylor, 1997). For Ordinary Portland Cement (OPC) the LSF ranges between 90 and 102 (ECRA, 2009). Cements with low LSFs are produced with less limestone in the raw meal. Change in the LSF of 1 is translated into a 0.2-0.4% by mass change of the clinker CaO content. The use of less limestone in the kiln will reduce CO2 emissions from calcination. Also,  due  to  better  raw  meal  burnability,  clinker  can  be  burned  at  lower  temperatures, reducing fuel consumption and CO2 emissions. The production of low LSF cements allows the use of raw materials with lower limestone content. However, low LSF cements have a reduced alite content which results in slow setting times and low early strength development.  Finer  ground  cement  can  outweigh  these  drawbacks  but  only  to  a  limited extend. The strength development of finely ground low LSF cements, composed of more than one constituent can be unpredictable (ECRA, 2009). A decrease of the LSF by 10 will result  in  fuel  savings  of  86  kBtu/ton  clinker  while  electricity  use  will  increase  by  10-20 kWh/ton clinker due to finer cement grinding (ECRA, 2009). The overall CO2 emissions are expected to decrease by 35-26 kg CO2/tonne clinker. No capital investment is required. The Golden  Bay  Cement  plant,  in  New  Zealand,  used  additives  (CBA ®   quality  improver)  and reduced  the  LSF  from  98  to  95  without  affecting  the  cement  performance  (Wray  et  al., 1999). This allowed the plant to use locally mined lower cost raw materials. Fuel use was reported to decrease by 90-108 kBtu/ton clinker (Wray et al., 1999).

## 6.11 Alternative Fuels

Fuel Switching . CO2 emissions from combustion account for about one third of the overall CO2 emissions from cement manufacture. The switch from more carbon intensive to less carbon intensive fossil fuels can have a substantial effect on the abatement of greenhouse gases.  The  CO2  abatement  potential  for  switching  from  coal  0.22  lb  CO2/kBtu  (95  kg CO2/GJ) to heavy oil 0.18 lb CO2/kBtu (78 kg CO2/GJ) is 18%, while for switching to natural gas 0.13 lb CO2/kBtu (56 kg CO2/GJ) is 40%.  Based on the GNR data, in 2009, the U.S. cement industry covered 86% of its fuel demand with fossils fuels, mainly coal and petcoke, 13% with fossil fuels and waste, and 1.3% with biomass (CSI, 2011). From a technical point of view, cement kilns can operate on 100% oil or natural gas. Currently, the cement industry burns coal and petcoke, fuels that are rich in coal ash which becomes a part of the product and provides an additional benefit to cement manufacturers. According to ECRA (2009), the capital cost for fuel switching is estimated at $1.5-4.5/ton clinker. Fuel use can change from an increase of 0.26 to a decrease of 0.17 MBtu/ton clinker. Electricity use can increase by 0-2.5 kWh/ton clinker (ECRA, 2009). Any fuel switch scenario needs to take into account whether other pollutants,  such  as  NOx  emissions,  will  increase  as  a  result  of  the  switch. Whether it is economically attractive or not to switch from coal and petcoke to oil and natural gas, will depend on the fuel prices.

Alternative Fuels - Biomass and Waste. A wide range of alternative fuels can be used in cement kilns. Alternative fuels usually derive from various waste sources and cost less than conventional fuels. The revenues from waste intake have helped to reduce the production

costs of all waste burning cement kilns, and especially of wet process kilns. The use results in  reduced waste disposal in landfills, conservation of natural resources, and greenhouse gas emission abatement. The CO2 emission reduction from switching to alternative fuels will depend on the carbon intensity of the alternative fuel related to its calorific value. Biomass fuels include animal meal, waste wood products, sawdust and waste sewage sludge, but it can also be biofuel cultivated specifically for fuel use, such as wood, and grass. The latter will generally be more expensive than coal. Other alternative fuels that have been used in cement  kilns  are:  automobile  shredder  residue  (ASR),  plastics,  refinery  spent  catalyst, clarified  soil  oil  sediments  (CSOS),  scrap  carpet,  scrap  paper  and  wood,  and  scrap  tires (U.S. EPA,  2008).  High  raw material temperatures  (about 1,450 o C), high kiln gas temperatures (about 2,000 o C) and long retention periods (8 seconds or more), can insure the complete breakdown of organic waste (WBCSD/SINTEF, 2006) and efficient dust filters may reduce any potential emissions to safe levels (Holderbank et al., 1999; Cembureau, 1997).

In theory, cement kilns can operate on 100% biomass, but there are certain limitations such as the calorific and moisture content but also the content in trace compounds (i.e. chlorine) of the specific fuel. Most organic materials have low calorific values of about 9-16 MBtu/ton. Cement  kilns  require  fuels  with  high  calorific  values  (19-21  MBtu/ton),  thus  the  use  of biomass should be in combination with other fuels. Up to 60% of the precalciner fuel can be of low calorific value (ECRA, 2009; Tokheim, 2006). When low calorific value fuels with high chlorine compounds (requiring chlorine by-pass system) are used in a kiln, the fuel energy consumption  will  increase.  When  utilizing  high  waste  fuel  rates,  clinker  capacity  may  be reduced, as cement kiln operation with a 60-80% waste substitution rate differs drastically from the operation with 100% fossil fuels. Fuel use for using biomass may increase by 0260 kBtu/ton clinker while electricity use may also increase by 0-2.7 kWh/ton clinker (ECRA, 2009). The capital cost investment was estimated at $1.6-4.9/ton clinker, while operational costs  (based  only  on  fuel  costs)  will  decrease  by  $2.5-10/ton  clinker  (ECRA,  2009). According to another study (Hollingshead and Venta; 2009), when a low substitution rate is employed,  major  firing  system  conversions  are  not  required  and  were  estimated  at $1.60/ton  clinker.  Operational  costs  will  increase  by  $0.10/ton  clinker  (Hollingshead  and Venta,  2009),  power  use  will  not  change  while  fuel  use  may  increase  by  0-72  kBtu/ton clinker  (Hollingshead  and  Venta,  2009;  Kääntee  et  al.,  2004).  Investment  costs  can  vary drastically  depending  on  the  chemical  composition  and  trace  contents  of  various  fuels (ECRA, 2009).

A cement plant in Norway, Norcem Brevik, installed a so called 'hot combustion chamber' in order to ensure sufficient residence time, a chlorine by-pass system, and a bigger capacity fuel  feeding  system  (Skjeggerud  et  al.,  2009;  Tokheim,  2006).  As  a  result,  it  achieved  a traditional fuel substitution rate of 60%, and maintained clinker capacity at previous levels. Energy costs decreased substantially while energy use increased by 0.32 MBtu/ton clinker (Skjeggerud et al., 2009).

Any future increase in alternative  fuel  prices  will  limit  the  savings  in  operational  costs.  In addition  to  the  capital  required  for  equipment  modifications,  performance  testing  poses another  significant  cost,  ranging  from  $50,000  per  kiln  for  the  co-processing  of  non-

hazardous alternative fuels (i.e. biosolids) to up to $500,000 in the case of hazardous fuel (i.e.  CSOS) (U.S. EPA, 2008). In case a cement plant does not have CEMS (Continuous Emissions Monitoring Systems) and is planning to initiate the use of alternative fuels, it will have to install it. Increasing fuel prices offer a big incentive to cement producers to move towards  alternative  fuels  while  even  with  loss  in  clinker  capacity,  this  measure  is  often financially attractive (Shenk and Jensen, 2009). However, in order to be able to justify the high capital investment, stable kiln operation and long-term alternative fuel supply needs to be assured.

Tire  Derived  Fuel  (TDF). The use of  scrap  tires  has  increased  drastically  over  the  past years.  In  2005,  47  cement  plants  used  TDF  (U.S.  EPA,  2008).  Scrap  tires  have  a  high calorific  value  (14,000 Btu/ton) and provide raw materials which are necessary in cement manufacturing.  When  one  ton  of  TDF  is  used,  approximately  770  lb  Fe  (350  kg)  are recovered (U.S. EPA, 2008). Coal can be substituted by whole tires with an average rate of 15%.  According  to  U.S.  EPA  (2007b)  kilns  cannot  use  more  than  25%  TDF  as  the  zinc content  slows  down  the  setting  time.  Some  cement  kilns  however,  use  as  much  as  30% (Hollingshead and Venta, 2009). The TDF emission factor is 0.19 lb CO2/kBtu while for coal it is  0.22  lb  CO /kBtu.  Typically,  1.05-1.10  tons  of  TDF  can  replace  one  ton  of  coal 2 (Hollingshead  and  Venta,  2009).  When  TDF  is  used,  net  CO2  emissions  will  increase  as TDF  is  not  considered  a  CO2  neutral  fuel  and  electricity  use  will  also  increase.  The  St. Lawrence  Cement  Factory  in  Joliette,  Quebec  completed  a  project  in  1994  where  they installed an automated tire feed system to feed whole tires into the mid-section of the kiln, which replaced about 20% of the energy (CADDET, 1996). Costs for the installation of the Joliette system ran about $3.40/annual ton clinker capacity. Costs for less complex systems where  the  tires  are  fed  as  input  fuel  are  $0.1-$1/annual  ton  clinker.  Other  plants  have experience injecting solid and fluid wastes, as well as ground plastic wastes. A net reduction in  operating  costs  (CADDET,  1995;  Gomes,  1990,  Venkateswaran  and  Lowitt,  1988)  is assumed. Investment costs are estimated at $1/annual ton clinker for a storage facility for the waste-derived fuels and retrofit of the burner (if needed). For a 15% substitution rate, power use will increase by 1.5 kWh/ton clinker and there will be additional operating costs of $0.10/ton  clinker  (Hollingshead  and  Venta,  2009).  In  a  Lafarge  plant,  a  disruption  in  the chipped tire supply forced them to install a kiln chute in order to be able to use whole tires. The  investment  cost  was  $4  million,  excluding  performance  testing  and  permitting  (U.S. EPA, 2008). Depending on which part of the kiln the tires will be fed (Cembureau, 2009) their use can lead to NOx emission reduction (U.S. EPA, 2008). The ongoing conversion of wet to dry kilns may reduce the number of facilities utilizing whole tires, as short dry kilns cannot process whole tires as easily as other types of kilns (i.e. long wet kilns) (U.S. EPA, 2008).

## 6.12 Advanced Technologies

In this section several advanced technologies for cement production are discussed. As our study focuses on commercially available technologies, the advanced technologies are not included  in  the  analysis  of  the  cost-effective  potential  for  energy  efficiency  improvement. They are discusses for completeness of the technical analysis.

Fluidized Bed Kiln. The Fluidized Bed Kiln (FBK) is a newer concept to produce clinker. Developments in FBK technology started as early as the 1950s (Venkateswaran and Lowitt, 1988). Today, developments mainly take place in Japan (Kawasaki Heavy Industries) and the  U.S.  (Fuller  Co.)  (Cohen,  1995;  Van  Kuijk  et  al.,  1997).  In  an  FBK,  the  rotary  kiln  is replaced by a stationary vertical cylindrical vessel, in which the raw materials are calcined in a fluidized bed. An overflow at the top of the reactor regulates the transfer of clinker to the cooling  zone.  The  (expected)  advantages  of  FBK  technology  are  lower  capital  costs because of smaller equipment, lower temperatures resulting in lower NOx-emissions and a wider  variety  of  the  fuels  that  can  be  used,  as  well  as  lower  energy  use.  The  Kawasaki design uses cyclone preheaters, a precalciner kiln and a fluidized bed kiln. Energy use is expected to be 10-15% lower compared to conventional rotary kilns (Vleuten, 1994), and 10-12% lower compared to suspension preheater kilns equipped with grate cooler (IPPC, 2010). The Fuller Co. stood at the basis of the U.S. development of a fluidized bed kiln for clinker making. Early developments did not prove to be commercially successful due to the high clinker recycling rate (Cohen, 1992) and were commercialized for alkali dust recycling only  (Cohen,  1993).  The  technology  was  also  used  in  the  development  of  the  advanced cement furnace  (CAF).  CAF  uses  a  preheated  pellet  feed,  using  primarily  natural  gas  or liquid  fuels  (Cohen,  1993).  A  pilot  plant  was  built  and  used  to  produce  clinker.  The  NOx emissions were reduced to 1.7 lbs/ton clinker, compared to 4.6-5.8 lbs/ton for conventional plants  due  to  lower  combustion  temperatures  (Cohen,  1993).  Currently,  a  plant  is  being constructed  in  China  with  a  capacity  of  1,000  tpd,  but  it  is  not  yet  in  operation  (ECRA, 2009). The future fuel consumption is estimated at 2.52-2.9 MBtu/ton clinker (Cohen, 1995). ECRA (2009) estimated energy savings of up to 0.26 MBtu/ton clinker. The fuel use of the FBK may be lower than that of conventional rotary kilns, although modern precalciner rotary kilns have shown fuel use of 2.6-2.7 MBtu/ton clinker. No data are available on the expected power use for the FBK. The use of the FBK may result in lower alkali-content of the clinker (Cohen, 1992). FBK needs less space and also has a higher flexibility with respect to raw material feed.

Advanced  Comminution  Technologies. Grinding  is  an  important  power  consumer  in modern cement-making. However, current grinding technologies are highly inefficient. Over 95% of the energy input in the grinding process is lost as waste heat, while only 1-5% of the energy input is used to create new surface area (Venkateswaran and Lowitt, 1988). Some of the heat may be used to dry the raw materials, for example in finish grinding or the grinding of limestone.  Current  high-pressure  processes  already  improve  the  grinding  efficiency  in comparison  with  conventional  ball  mills  (see  above).  In  the  longer  term,  further  efficiency improvements can be expected when  non-mechanical "milling" technologies become available (OTA, 1993). Non-mechanical systems may be based on ultrasound (Suzuki et al., 1993), laser, thermal shock, electric shock or cryogenics. However, non-mechanical grinding technologies have not been demonstrated yet and will not be commercially available in the next decades. Although the theoretical savings of non-mechanical comminution are large, no estimate of the expected savings can be given at this stage of fundamental research.

Geopolymers. Clinker is made by calcining calcium carbonate (limestone), which releases CO2 into  the  atmosphere.  Geopolymers,  or  else  called  inorganic  polymers,  can  be  made

from inorganic alumino-silicate compounds. An inorganic polycondensation reaction results in a three-dimensional structure, like that of zeolites. It can be produced by blending three elements,  i.e.  calcined  alumino-silicates  (from  clay),  alkali-disilicates  and  granulated  blast furnace slag or fly-ash (Davidovits, 1994a). Geopolymer  cements  harden  at  room temperatures and provide compressive strengths of 20 MPa after 4 hours and up to 70-100 MPa after 28 days, while they also have high fire resistance (Davidovits, 1994a; Zongrijn et al.,  2004).  The  zeolite-like  matrix  results  in  the  immobilization  of  materials,  e.g.  wastes. Despite  the  high  alkali  content,  geopolymers  do  not  show  alkali  aggregate  reactions (Davidovits, 1993). Research on geopolymers was already going on in Eastern Europe and the  U.S  in  the  early  1980s.  Geopolymer  cements  use  hydroxide  or  sodium  silicates  as activators instead of lime, therefore eliminating process CO2 emissions, and require lower kiln temperatures of about 1,400°F (750 o C) when  compared to ordinary cements (Davidovits, 1994a; Davidovits, 2002; Müller and Harnisch, 2008). Davidovits et al. (1994b) estimated that geopolymer production will consume 3/5 less energy than the production of Portland  cement.  The  first  industrial  geopolymer  plant  is  currently  being  built  in  Australia, Zeobond Pty Ltd. Production costs are expected to be 20% higher than OPC cement (von Weizsäcker et al, 2009). The production of Zeobond geopolymer binder does not require big amounts  of  energy  intensive  activators,  and  it  relies  on  waste  products  from  other manufacturing  industries;  CO2  emissions  can  be  as  low  as  10-20%  of  those  of  Portland cement binders (Duxson et al., 2007; Net Balance Foundation, 2007). The CO2 emissions from geopolymer production are estimated at 300 kg CO2/tonne of product (ECRA, 2009; IEA, 2009). However, the above figure does not take into account emissions from the production of activators. Water consumption in the manufacture and use of geopolymers is similar to OPC (von Weizsäcker et al, 2009). The use of geopolymers results in the immobilization of solid wastes in the matrix (Davidovits, 1991). The availability of raw materials, such as fly ash and blast  furnace  slag,  is  limited  and  in  some  cases  expensive  (e.g.  natural  alumino-silicate metakaolin), therefore it is more likely that geopolymer cement production will not be widely practiced.  In  regard  to  capital  investment,  geopolymer  facilities  will  require  lower  capital investment than conventional cement plants (IEA, 2009).

Belite and Other Low Energy Clinker. Ordinary Portland Cement (OPC) has an alite (C3S) content of 40-80%. Belite clinkers contain up to 90% belite (C2S) and no to small quantities of alite. The production of belite clinkers has the potential to decrease CO2 emissions from both calcination and fuel combustion (Lawrence, 1998). This is achieved due to the low lime content in the raw meal (Lime Saturation Factor LSF of about 0.80) and due to the lower kiln temperatures  (1,350 o C)  (belite  clinkers  have  better  burnability  than  alite  clinkers).  Belite clinkers  with  0.80-0.85  LSF,  have  10%  less  energy  demand  and  require  300 o F  (150 o C) lower kiln temperature than conventional alite clinkers (Lawrence, 1998). The production of low LSF cements can limit the use of materials with high lime content and enhance the use of supplementary cementitious materials (i.e. slags and fly ash). Major drawback is the low hydraulic  reactivity.  Cements  with  LSFs  below  0.84  are  characterized  by  low  strength development  which  cannot  be  compensated  by  increased  cement  fineness  or  increased sulphate levels (Lawrence, 1998). In order to improve belite cement performance, ground alite  or  OPC  should  be  added;  minimum  alite  content  of  15%  (Lawrence,  1998).  Belite cement reactivity and strength development can be enhanced by i) rapid clinker quenching

ii) the addition of impurity ions (i.e. sulphates) and iii) the addition of OPC clinker (Lawrence, 1998).  Rapid  cooling  of  belite  clinkers  has  shown  to  improve  the  hydraulic  activity considerably.  However,  this  method  will  increase  heat  losses  and  limit  energy  savings. According to ECRA (2009), fuel savings are limited to 5%. In addition, belite clinkers are harder to grind (Hills, 2007), increasing electricity use by 20-40 kWh/ton of clinker (ECRA, 2009).  Investment  costs  for  storage,  handling  and  drying  of  the  new  materials  were estimated by ECRA (2009) at $5-7.6/ton clinker.

Other promising alternatives to regular cements are belite cements that contain hydraulically active  sulfoaluminate  or  ferrite  phases.  These  types  of  cements  have  shown  to  have  low setting times and develop good early and late strengths. However, several problems have been indicated due to strength loss after a number of years (Lawrence, 1998). Nowadays, their application  is  limited  to  Japan  and  China  (ECRA,  2009;  Lawrence,  1998).  An innovative cement, Aether TM , which is being developed, is composed of 40-75% belite, 1535% calcium sulfoaluminate (yeelemite), and 5-25% ferrite, is expected to reduce energy consumption of cement manufacture by 15% and CO2 emissions by 25-30% (Morin et al., 2011). Aether TM  could be produced in a traditional cement plant after a few modifications. Research is still ongoing on the manufacturing process, hydration and durability.

## 7.  Summary and Conclusions

The historic trends for energy efficiency in the U.S. cement industry and the cost-effective energy and carbon dioxide savings that can be achieved in the near future are analyzed in this report. The report focuses on the detailed analysis of energy use and carbon dioxide emissions  by  process,  specific  energy  efficiency  technologies  and  measures  to  reduce energy  use  and  carbon  dioxide  emissions,  and  the  energy  efficiency  and  carbon  dioxide emissions reduction potential for cement production.

The cost of energy as part of the total production costs in the cement industry is significant, ranging from 20-40%, warranting attention for energy efficiency to improve the bottom line. Historically,  energy  intensity  has  been  reducing,  although  more  recently  energy  intensity seems to have stabilized with little improvement. Coal and coke are currently the primary fuels  for  the  sector,  supplanting  the  dominance  of  natural  gas  in  the  1970s.  A  variety  of waste  fuels,  including  tires,  steadily  increase  their  share  in  fuel  use.  Between  1970  and 2010, primary physical energy intensity for cement production dropped 1.2% per year from 7.3 MBtu/short ton to 4.5 MBtu/short ton. Carbon dioxide intensity due to fuel consumption and raw material calcination dropped 24%, from 610 lb. C/ton of cement (0.31 tC/tonne) to 469 lb. C/ton cement (0.23 tC/tonne).

Despite the historic progress, there is ample room for energy efficiency improvement. Over 50  energy-efficient  technologies  and  measures  and  estimated  energy  savings,  carbon dioxide  savings,  investment  costs,  and  operation  and  maintenance  costs  for  each  of  the measures were examined. In

Table

8

and

Table 9 ,  the efficiency measures and estimated savings for the dry and wet process plants respectively are summarized.

Substantial potential for energy efficiency improvement exist in the cement industry, and in individual plants. However, part of this potential may only be achieved as part of (natural) stock  turnover  and  expansion  of  existing  facilities.  Still,  a  relatively  large  potential  for improved energy management practices exists.

Table 8. Energy efficiency measures in dry process cement plants. The estimated savings and payback periods are averages for indication, based on the average performance of the U.S. cement industry (e.g. clinker to cement ratio). The actual savings and payback period may vary by project based on the specific conditions in the individual plant. More information can be found in the description of the measures above.

| Energy Efficiency Measure                                                   | Specific Fuel Savings (MBtu/ton cement)   | Specific Electricity Savings (kWh/ton cement)   | Estimated Payback Period (1) (2) (years)   |
|-----------------------------------------------------------------------------|-------------------------------------------|-------------------------------------------------|--------------------------------------------|
| Raw Materials Preparation                                                   |                                           |                                                 |                                            |
| Mechanical Transport Systems                                                | -                                         | 1.0 - 3.0                                       | >3 (1)                                     |
| Improved Pneumatic Systems                                                  | -                                         | 1.6                                             | N/A (1)                                    |
| Improved Raw Mill Blending                                                  | 0.00 - 0.02                               | 0.7 - 2.3                                       | >10                                        |
| Use of Vertical Roller Mills                                                | -                                         | 9.2 - 10.9                                      | >10                                        |
| Use of High - Pressure Roller Presses                                       | -                                         | 16.9 - 17.5                                     | 7 - 8 (1)                                  |
| High Efficiency Classifiers                                                 | -                                         | 3.9 - 5.3                                       | >10 (1)                                    |
| Separate Raw Material Grinding                                              | -                                         | 0.8 - 1.2                                       | >10 (1)                                    |
| Raw Meal Process Control                                                    | -                                         | 1.2 - 1.6                                       | 1                                          |
| Fuel Preparation                                                            | -                                         | 0.6 - 1.9                                       | N/A (1)                                    |
| Clinker Making                                                              |                                           |                                                 |                                            |
| Energy Management and Control Systems                                       | 0.08 - 0.16                               | 0 - 3.9                                         | <2                                         |
| Kiln Combustion System Improvements                                         | 0.06 - 0.32                               | -                                               | <1                                         |
| Mineralized Clinker                                                         | 0.00 - 0.14                               | 0 - - 0.8                                       | N/A                                        |
| Indirect Firing                                                             | 0.12 - 0.18                               | 0 - - 0.5                                       | >10 (1)                                    |
| Oxygen Enrichment                                                           | 0.0 - 0.16                                | - 9 - - 32                                      | N/A(1)                                     |
| Mixing Air Technology (PH kilns)                                            | 0.16                                      | 0.02                                            | 2 (1)                                      |
| Seal Replacement                                                            | 0.01                                      | -                                               | <1                                         |
| Kiln Shell Heat Loss Reduction                                              | 0.09 - 0.50                               | -                                               | <1                                         |
| Preheater Shell Heat Loss Reduction                                         | 0.02                                      | -                                               | 6                                          |
| Refractories                                                                | 0.05                                      | -                                               | 4                                          |
| Conversion to Grate Cooler                                                  | 0.25                                      | - 3.0 - - 5.0                                   | >18                                        |
| Optimize Grate Cooler                                                       | 0.04 - 0.13                               | 0.0 - - 1.7                                     | 2 - 7                                      |
| Low - Pressure Drop Suspension Preheaters                                   | -                                         | 0.5 - 3.7                                       | >10 (1) 2                                  |
| Heat Recovery for Power Generation                                          | -                                         | 18.0                                            | - 14 (1)                                   |
| Conversion of Long Dry to Preheater Increase Preheater Stages (from 5 to6 ) | 0.60 - 1.30 0.10                          | - -                                             | >10 >7 (1)                                 |
|                                                                             |                                           | -                                               | >10 (1)                                    |
| Addition of Precalciner or Upgrade                                          | 0.12 - 0.54                               |                                                 |                                            |
| Conversion of Long Dry Kiln to Preheater Precalciner                        | 0.84 - 1.11                               | -                                               | >10 (1)                                    |
| Efficient Mill Drives                                                       | -                                         | 0.8 - 3.2                                       | 1                                          |
| Finish Grinding                                                             |                                           |                                                 |                                            |
| Energy Management and Process Control                                       | -                                         | 1.6 - 8.5                                       | <2                                         |
| Vertical Roller Mills                                                       | -                                         | 9.0 - 20                                        | >8 (1)                                     |
| Horizontal Roller Mills                                                     | -                                         | 15.6                                            | >10 (1)                                    |
| High - Pressure Roller Presses - pre - grinding                             | -                                         | 5.0 - 10.0                                      | >10 (1)                                    |
| High - Pressure Roller Presses - finish grinding                            | -                                         | 11.0 - 25.0                                     | >10 (1)                                    |
| Improved Grinding Media                                                     | -                                         | 1.8                                             | >10 (1)                                    |
| High - Efficiency Classifiers                                               | -                                         | 1.7 - 6.0                                       | >10 (1)                                    |
| Plant Wide Measures                                                         |                                           |                                                 |                                            |
| Preventative Maintenance                                                    | 0.04                                      | 0.0 - 5.0                                       | <1                                         |
| High Efficiency Motors                                                      | -                                         | 0.0 - 5.0                                       | <1                                         |
| Adjustable Speed Drives                                                     | -                                         | 5.5 - 9.0                                       | 1 - 3                                      |
| Optimization of Compressed Air Systems                                      | -                                         | 0.0 - 2.0                                       | <3                                         |
| High Efficiency Fans                                                        | -                                         | 0.9                                             | N/A                                        |
| Efficient Lighting                                                          | -                                         | 0.0 - 0.5                                       | N/A                                        |
| Product Change                                                              |                                           |                                                 |                                            |
| Higher Alkali Cement                                                        | 0.10 - 0.33                               | N/A                                             | Immediate                                  |
| Blended Cement                                                              | 0.90                                      | - 15.00                                         | 1 - 3                                      |
| Limestone Portland Cement                                                   | 0.17                                      | 3.0                                             | <1                                         |
| Reducing Fineness                                                           | -                                         | 0.0 - 14.0                                      | Immediate                                  |
| Feedstock Change                                                            |                                           |                                                 |                                            |
| Use of Steel Slag in Clinker (CemStar) (10% substitution)                   | 0.15                                      | -                                               | 1 - 2                                      |
| Use of Fly Ash, Blast Furnace Slag in Clinker (15%                          | 0.24                                      | 0.0 - - 1.7                                     | <7 (1)                                     |
| Use of Cement Kiln Dust in Clinker                                          | 0.05                                      | - 0.9                                           | <2                                         |
| Use of Calcareous Oil Shale in Clinker (8% oil shale)                       | 0.07                                      | -                                               | 10 (1)                                     |
| Reduce the Lime Saturation Factor                                           | 0.08 - 0.10                               | - 9 - - 18                                      | N/A                                        |
| Alternative Fuels                                                           |                                           |                                                 |                                            |
| Fuel Switching                                                              | 0.16 - - 0.28                             | 0.0 - - 2.5                                     | N/A                                        |
| Biomass and Waste Tire Derived Fuel                                         | 0.00 - - 0.43 -                           | 0.0 - - 2.5 - 1.50                              | <4 N/A                                     |

(1) Payback periods are calculated on the basis of energy savings alone. In reality this investment may be driven by other considerations than energy efficiency (e.g. productivity, product quality), and will happen as part of the normal business  cycle  or  expansion  project.  Under  these  conditions  the  measure  will  have  a  lower  payback  period depending on plant-specific conditions.

- (2) Fuel and electricity costs used in the calculation of the payback periods are based on the U.S. cement industry's energy expenditures as reported by the U.S. Energy Information Administration in the 2006 Manufacturers Energy Consumption Survey. The cost of electricity is $0.058/kWh and the cost of fuel is $2.61/MBtu.

Table 9. Energy efficiency measures in wet process cement plants. The estimated savings and payback periods are averages for indication, based on the average performance of the U.S. cement industry (e.g. clinker to cement ratio). The actual savings and payback period may vary by project based on the specific conditions in the individual plant. More information can be found in the description of the measures above.

| Energy Efficiency Measure                        | Specific Fuel Savings (Mbtu/ton cement)   | Specific Electricity Savings (kWh/ton cement)   | Estimated Payback Period (3) (4) (years)   |
|--------------------------------------------------|-------------------------------------------|-------------------------------------------------|--------------------------------------------|
| Raw Materials Preparation                        |                                           |                                                 |                                            |
| Slurry Blending and Homogenizing                 | -                                         | 0.1 - 0.6                                       | <3                                         |
| Wash Mills with Closed Circuit Classifier        | -                                         | 8.0 - 11.0                                      | >10 (1)                                    |
| High Efficiency Classifiers                      | -                                         | 3.9 - 5.3                                       | >10 (1)                                    |
| Fuel Preparation                                 | -                                         | 0.8 - 2.4                                       | N/A (1)                                    |
| Clinker Making                                   |                                           |                                                 |                                            |
| Energy Management and Control Systems            | 0.14 - 0.27                               | 0.0 - 3.9                                       | <1                                         |
| Kiln Combustion System Improvements              | 0.11 - 0.54                               | -                                               | <1                                         |
| Mineralized Clinker                              | 0.00 - 0.14                               | 0.0 - - 0.8                                     | N/A                                        |
| Indirect Firing                                  | 0.12 - 0.18                               | 0.0 - - 0.5                                     | >10 (1)                                    |
| Oxygen Enrichment                                | 0.0 - 0.27                                | - 9.0 - - 32.0                                  | N/A(1)                                     |
| Mixing Air Technology                            | 0.27                                      | 0.02                                            | 1 (1)                                      |
| Seal Replacement                                 | 0.02                                      | -                                               | <1                                         |
| Kiln Shell Heat Loss Reduction                   | 0.09 - 0.50                               | -                                               | <1                                         |
| Refractories                                     | 0.05                                      | -                                               | 4                                          |
| Conversion to Grate Cooler                       | 0.43                                      | - 3.0 - - 5.0                                   | 9 - 12                                     |
| Optimize Grate Cooler                            | 0.04 - 0.13                               | 0.0 - - 1.7                                     | 2 - 7                                      |
| Conversion to Semi - Dry Process Kiln            | 0.93 - 1.30                               | - 4.7 - - 6.5                                   | >10 (1)                                    |
| Conversion to Semi - Wet Process Kiln            | 0.60 - 0.90                               | - 3.7                                           | 1 - 3                                      |
| Conversion to Dry precalciner Kiln               | 1.70 - 2.70                               | - 8.4                                           | >7 (1)                                     |
| Efficient Mill Drives                            | -                                         | 0.8 - 3.2                                       | 1                                          |
| Finish Grinding                                  |                                           |                                                 |                                            |
| Energy Management and Process Control            | -                                         | 1.6 - 8.5                                       | <2                                         |
| Vertical Roller Mills                            | -                                         | 9.0 - 20                                        | >8 (1)                                     |
| Horizontal Roller Mills                          | -                                         | 15.6                                            | >10 (1)                                    |
| High - Pressure Roller Presses - pre - grinding  | -                                         | 5.0 - 10.0                                      | >10 (1)                                    |
| High - Pressure Roller Presses - finish grinding | -                                         | 11.0 - 25.0                                     | >10 (1)                                    |
| Improved Grinding Media                          | -                                         | 1.8                                             | >10 (1)                                    |
| High - Efficiency Classifiers                    | -                                         | 1.7 - 6.0                                       | >10 (1)                                    |
| Plant Wide Measures                              |                                           |                                                 |                                            |
| Preventative Maintenance                         | 0.04                                      | 0.0 - 5.0                                       | <1                                         |
| High Efficiency Motors                           | -                                         | 0.0 - 5.0                                       | <1                                         |
| Adjustable Speed Drives                          | -                                         | 5.5 - 9.0                                       | 1 - 3                                      |
| Optimization of Compressed Air Systems           | -                                         | 0.0 - 5.0                                       | <3                                         |
| High Efficiency Fans                             | -                                         | 0.9                                             | N/A                                        |
| Efficient Lighting                               | -                                         | 0.0 - 0.5                                       | N/A                                        |
| Product Change                                   |                                           |                                                 |                                            |
| Higher Alkali Cement                             | 0.10 - 0.33                               | N/A                                             | Immediate                                  |
| Blended Cement                                   | 1.39                                      | - 15.0                                          | 1 - 2                                      |
| Limestone Portland Cement                        | 0.29                                      | 3.0                                             | <1                                         |
| Reducing Fineness                                | -                                         | 0.0 - 14.0                                      | Immediate                                  |
| Feedstock Change                                 |                                           |                                                 |                                            |
| Use of Steel Slag in Clinker (CemStar)           | 0.15                                      | -                                               | 1 - 2                                      |
| Use of Fly Ash, Blast Furnace Slag in Clinker    | 0.24                                      | 0.0 - - 1.7                                     | <7 (1)                                     |
| Use of Calcareous Oil Shale in Clinker           | 0.07                                      | -                                               | 10 (1)                                     |
| Reduce the Lime Saturation Factor                | 0.08 - 0.10                               | - 9 - - 18                                      | N/A                                        |
| Alternative Fuels                                |                                           |                                                 |                                            |
| Fuel Switching                                   | 0.16 - - 0.28                             | 0.0 - - 2.5                                     | N/A                                        |
| Biomass and Waste                                | 0.00 - - 0.43                             | 0.0 - - 2.5                                     | <4                                         |
| Tire Derived Fuel                                | -                                         | - 1.50                                          | N/A                                        |

(3) Payback periods are calculated on the basis of energy savings alone. In reality this investment may be driven by other considerations than energy efficiency (e.g. productivity, product quality), and will happen as part of the normal business  cycle  or  expansion  project.  Under  these  conditions  the  measure  will  have  a  lower  payback  period depending on plant-specific conditions.

(4) Fuel and electricity costs used in the calculation of the payback periods are based on the U.S. cement industry's energy expenditures as reported by the U.S. Energy Information Administration in the 2006 Manufacturers Energy Consumption Survey. The cost of electricity is $0.058/kWh and the cost of fuel is $2.61/MBtu.

## Acknowledgements.

Many people have been very helpful in the data collection and review of earlier versions of this report. We especially would like to thank Alexander Goebel (Krupp Polysius, Germany), Steve  McGarel,  Tom  Evans,  Amy  George  and  Greg  Martin  (Pavilion  Technologies  Inc., Texas) for providing data for previous studies. We thank the following people for reviewing the draft of the earlier version of this report: John Chadbourne (Essroc), Steve Coppinger (CalPortland Company), Joel Fleming (Lafarge North America), Greg Galvin (RMC Pacific), Ted Jones (Consortium for Energy Efficiency), John Malinowski (Baldor Electric Company), Ilene  Mason  (Consortium  for  Energy  Efficiency),  Aimee  McKane  (Lawrence  Berkeley National Laboratory), Greg Miller (CTL, IL), Robert Miller (Metso Minerals), Linda Raynes (Electrical  Apparatus  Service  Association),  Robin  Riester  (FLS  Automation),  Hendrik  van Oss (USGS), Dan Willis (Trinity  Consultants, TX),  Ray  Worthington  (BMH  Americas  Inc.) and  Gerald  Young  (Penta  Engineering)  and  the  following  people  who  reviewed  the  draft version  of  this  updated  report:  Steve  Coppinger  (CalPortland  Company)  and  Steven Drzymala (Titan America).

Also, we would like to thank Ann Dougherty and Gregg Miller (Portland Cement Association, Skokie,  IL),  George  Lesnikoff  (Hanson  Cement,  Cupertino,  CA),  Chris  Bayne  (Titan America),  and  Michael  Nisbet  (JAN  Consultants,  Montreal,  Canada)  for  reviewing  earlier reports  on  which  this  report  is  based  and  providing  technical  information.  Unfortunately, Michael  Nisbet  passed  away  too  early,  and  before  the  earlier  version  of  this  report  was finished. Despite all their efforts any errors remaining are those of the authors.

## 8. Glossary

| AAGC     | Air Activated Gas Conveyor                                             |
|----------|------------------------------------------------------------------------|
| AC       | Alternating Current                                                    |
| ACAA     | American Coal Ash association                                          |
| Al 2 O 3 | Aluminium Oxide                                                        |
| APC      | Advanced Process Control                                               |
| ASDs     | Adjustable speed drives                                                |
| ASR      | Alkali-Silica Reactivity                                               |
| ASR      | Automobile Shredder Residue                                            |
| ASTM     | American Society for Standards and Materials                           |
| BBBP     | Better Buildings, Better Plants                                        |
| BF       | Bag Filter                                                             |
| BFS      | Blast Furnace Slag                                                     |
| Btu      | British Thermal Unit                                                   |
| C        | Carbon                                                                 |
| C 2 S    | Belite                                                                 |
| C 3 S    | Alite                                                                  |
| CAC      | Compressed Air Challenge ®                                             |
| CaCO 3   | Calcium Carbonate                                                      |
| CAF      | Cement Advanced Furnace                                                |
| CaF 2    | Calcium Fluoride                                                       |
| CADDET   | Centre for the Analysis and Dissemination of Demonstrated Technologies |
| CaO      | Calcium oxide (lime)                                                   |
| CDA      | Copper Development Association                                         |
| CEE      | Consortium of Energy Efficiency                                        |
| CEMS     | Continuous Emissions Monitoring Systems                                |
| CFL      | Compact fluorescent lamp                                               |
| CIM      | Computer Integrated Manufacturing                                      |
| CIPEC    | Canadian Industry Program for Energy Conservation                      |
| CKD      | Cement Kiln Dust                                                       |

cm centimeter

Program

| CO        | Carbon monoxide                                                |
|-----------|----------------------------------------------------------------|
| CO 2      | Carbon dioxide                                                 |
| CSI       | Cement Sustainability Initiative                               |
| CSOS      | Clarified Soil Oil Sediments                                   |
| DC        | Direct Current                                                 |
| EAF       | Electric Arc Furnace                                           |
| EASA      | Electric Apparatus Service Association                         |
| ECRA      | European Cement Research Academy                               |
| ECU       | European Currency Unit                                         |
| EIA       | Energy Information Administration (U.S. Department of Energy)  |
| EP        | Electrostatic Precipitator                                     |
| EPAct     | Energy Policy Act                                              |
| FBK       | Fluidized Bed Kiln                                             |
| Fe        | Iron                                                           |
| Fe 2 O 3  | Iron Oxide                                                     |
| FLC       | Fluidized Conveying                                            |
| fob       | Free on Board or Freight on Board                              |
| GBFS      | Granulated Blast Furnace Slag                                  |
| GJ        | Gigajoule                                                      |
| GNR       | Getting the Numbers Right                                      |
| GWh       | Gigawatt-hour                                                  |
| HHV       | High Heating Value                                             |
| HID       | High Intensity-discharge                                       |
| hp        | horsepower                                                     |
| HPGR      | High-Pressure Grinding Rolls                                   |
| HVAC      | Heating, ventilation, and air-conditioning                     |
| Hz        | Hertz                                                          |
| IAC       | Industrial Assessment Center                                   |
| IEA       | International Energy Agency                                    |
| IEA-ETSAP | International Energy Agency-Energy Technology Systems Analysis |

| IPPC    | Integrated Pollution Prevention Control                                         |
|---------|---------------------------------------------------------------------------------|
| ISO     | International Organization for Standardization                                  |
| ITIBMIC | Institute of Technical Information for the Building Materials Industry of China |
| KBS     | Knowledge Based Systems                                                         |
| kBtu    | Thousand British Thermal Unit                                                   |
| kcal    | kilocalorie                                                                     |
| KD      | Kiln Dust                                                                       |
| kg      | kilogram                                                                        |
| kWh     | kilowatt-hour                                                                   |
| lb      | pound                                                                           |
| LBNL    | Lawrence Berkeley National Laboratory                                           |
| LCC     | Life Cycle Costing                                                              |
| LED     | Light-emitting diode                                                            |
| LHV     | Low Heating Value                                                               |
| LRC     | Lighting Research Center                                                        |
| LSF     | Lime Saturation Factor                                                          |
| MAT     | Mixing Air Technology                                                           |
| MBtu    | Million British Thermal Unit                                                    |
| MDM     | Motor Decisions Matter SM                                                       |
| MECS    | Manufacturing Energy Consumption Survey                                         |
| mm      | millimeter                                                                      |
| MPa     | Mega Pascal                                                                     |
| MPC     | Model-Predictive Control                                                        |
| MtC     | Million tonnes Carbon                                                           |
| Mtph    | million tonnes per hour                                                         |
| NEMA    | National Electrical Manufacturers Association                                   |
| NEMA EE | National Electrical Manufacturers Association Energy Efficiency                 |
| NOx     | Nitrogen Oxides                                                                 |
| O 2     | Oxygen                                                                          |
| OEC     | ORMAT Energy Converter                                                          |
| OPC     | Ordinary Portland Cement                                                        |

| ORC          | Organic Rankine Cycle                                                |
|--------------|----------------------------------------------------------------------|
| PCA          | Portland Cement Association                                          |
| pH           | potential of Hydrogen                                                |
| PJ           | Petajoule                                                            |
| PM           | Particulate Matter                                                   |
| psi          | pound per square inch                                                |
| psid         | pound per square inch (differential)                                 |
| psig         | pound per square inch (gauge)                                        |
| RCRA         | Resource Conservation and Recovery Act                               |
| RMB          | Renminbi (Chinese currency)                                          |
| scf          | standard cubic feet                                                  |
| SCMs         | Supplementary Cementitious Materials                                 |
| SEC          | Specific Energy Consumption                                          |
| SiO 2        | Silicon Dioxide                                                      |
| SO 2         | Sulfur Dioxide                                                       |
| tpd          | tonnes per day                                                       |
| TBtu         | trillion British Thermal Unit                                        |
| TDF          | Tire Derived Fuel                                                    |
| TEFC         | Totally Enclosed Fan Cooled                                          |
| UNFCCC       | United Nations Framework Convention on Climate Change                |
| U.S. DOE     | United States Department of Energy                                   |
| U.S. DOE-OIT | United States Department of Energy-Office of Industrial Technologies |
| U.S. EPA     | United States Environmental Protection Agency                        |
| USGS         | United States Geological Survey                                      |
| VSDs         | Variable speed drives                                                |
| WBCSD        | World Business Council on Sustainable Development                    |
| W.C.         | Water column                                                         |
| ZKG          | Zement Kalk Gips                                                     |

## 9. References

Adaska, W.S. and Taubert, D.H, 2008. 'Beneficial Uses of Cement Kiln Dust,' Proc. 2008 IEEE Cement Industry Technical Conference Record, Miami, FL, May 18-22, 2008, Institute of Electrical and Electronic Engineers Inc. New York, NY, USA (pp.210-228).

Alsop,  P.A.,  H.  Chen,  H.  Tseng.  2007. The  Cement  Plant  Operations  Handbook ,  Fifth Edition, Tradeship Publications Ltd., Surrey, UK.

American Coal Ash Association (ACAA), 2011. Corrected 2009 Coal Combustion Product (CCP) Production &amp; Use Survey. http://acaa.affiniscape.com/associations/8003/files/2009\_CCP\_Production\_Use\_Survey\_Co rrected\_020811.pdf

Albert, O., 1993. 'MCE - An Expert System for Mill Plant Control,' Krupp Polysius, Germany.

Aller, M., D. Stinson, P. Edwards, 2006. 'The Financial Impact of Compressed Air Projects.' 2006 IEEE Cement Industry Technical Conference Record ,  Phoenix, Arizona, USA, April 914, 2006, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.156167).

Alsop, P.A. and J.W. Post, 1995. The Cement Plant Operations Handbook, (First edition), Tradeship Publications Ltd., Dorking, UK

Anonymuous, 1994a. 'Die Zementindustrie Taiwans - Rückblick und gegenwärtiger Stand,' Zement-Kalk-Gips 1 47: pp.47-50 (1994).

Anonymous, 1994b. 'Cement Plant Modernization in Central Europe,' World Cement (November)  35-38 (1994). :

Anonymous, 2001. 'Greencastle Cement Expands, Uses New production Process' Mining Engineering 1, 53 pp.31-33 (January 2001).

Audin,  L.,  1996.  Natural  Gas  Engine-Driven  Air  Compressors,  New  Money-Saving  Option Requires Careful Analysis. E-Source Tech Update. July

Aydo an,  N.  A.,  L.  Ergün,  H.  Benzer,  2006.  'High  Pressure  Grinding  Rolls  (HPGR) ğ Applications in the Cement Industry.' Minerals Engineering , 19 (2006), pp.130-139.

Barnish, T. J., M. R. Muller, and D. J. Kasten, 1997. Motor Maintenance: A Survey of Techniques and Results. Proceedings of the 1997 ACEEE Summer Study on Energy Efficiency in Industry. American Council for an Energy-Efficient Economy, Washington, D.C.

Battye,  R.,  S.  Waslh,  J.  Lee-Greco,  2000.  'NOx  Control  Technologies  for  the  Cement Industry,' Prepared for U.S.Environmental Protection Agency, Triangle Park, NC.

Bayne, C. 2011. Titan America. Personal Communication.

Bell. J., 2007. 'Concrete Energy Savings, On-Site Power for the World's Cement Industry.' Cogeneration and On-Site Power Production , May-June 2007, pp.105-112.

Benzer, H., N. Aydogan, H. Dundar, A. J. Lynch, 2011. 'Reducing the Energy Use in Grinding Clinker  to Cement  -  Some  Case  Studies.' Metallurgical  Plant  Design  and  Operating Strategies 2011 , August 8-9, Perth, WA.

Bhatty,  J.I.,  1996. Use  of  Fluxes  and  Mineralizers  in  the  Cement  Industry:  A  Survey . Portland Cement Association R&amp;D Serial No. 2045.

Bhatty, J.I. and Gajda, J., 2004. Use of Alternative Materials in Cement Manufacturing. In: Bhatty,  J.I.,  Miller,  F.M.,  Kosmatka,  S.H.  eds.  2004. Innovations  in  Portland  Cement Manufacturing. SP400, Portland Cement Association (PCA). Skokie, Illinois, U.S.A.

Birch, E., 1990. 'Energy Savings in Cement Kiln Systems' Energy Efficiency in the Cement Industry (Ed. J. Sirchis), London, England: Elsevier Applied Science (pp.118-128).

Body, J.,  G.  Zhang, 2011.  Measuring Improvement in the Energy Performance of the U.S. Cement Industry. Department of Economics, Duke University.

Boe,  E.,  S.J.  Mc  Garel,  T.  Spaits,  T.  Guiliani,  2005.  'Predictive  Control  and  Optimization Applications in a Modern Cement Plant.' 2005 IEEE Cement Industry Technical Conference Record , Kansas City, Missouri, USA, May 15-20, 2005, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.1-10).

Bojdys,  M.,  2002.  Assessment  of  Energy  Savings.  Benefits  of  Mechanical  Preheater  and Blending Silo Feeding with Bucket Elevators. AUMUND Fördertechnik, Germany.

Bolwerk,  R.,  G.  Ebertsch,  M.  Heinrich,  S.  Plickert,  M.  Oerter,  2006.  Part  II:  Cement Manufacturing Industries. German Contribution to the Review of the Reference Document on Best Available Techniques in the Cement and Lime Manufacturing Industries.

Borgholm,  H.E.,  D.  Hertford,  S.  Rasmussen.,  1996.  'A  New  Blended  Cement  Based  on Mineralized Clinker'. Emerging Technologies Symposium on Cements for the 21 st  Century. SP206. Portland Cement Association (PCA), pp. 95-115.

Börrnert T. and Bürki T., 2010. 'Waste Heat Conversion into Electricity.' 2010 IEEE-IAS/PCA Cement  Industry  Technical  Conference  Record ,  Colorado  Springs,  CO,  March  28-April  1, 2010, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.1-8).

Börrnert T., 2011. 'Organic Rankine Cycle (ORC) Based Power Plant to Utilize Low-Grade Waste Heat Sources.' 2011 IEEE-IAS/PCA Cement Industry Technical Conference Record , St.  Louis,  MO,  May  22-26,  2011,  Institute  of  Electrical  and  Electronics  Engineers  Inc.  New York, NY, USA (pp.1-10).

Bösche,  A.,  1993.  'Variable  Speed  Drives  in  Cement  Plants,' World  Cement 6,  24  pp.2-6 (1993).

Bronicki,  L.Y.,  No  date.  Organic  Rankine  Cycle  Power  Plant  for  Waste  Heat  Recovery. http://www.ormat.com/FileServer/e008778b83b2bdbf3a8033b23928b234.pdf

Burkhard, K. and York, R. 2005. 'Grinding of Solid Fuels Using MPS Vertical Roller Mills.' ZKG International 11 58 pp. 36-47.

Buzzi,  S., 1997.  'Die  Horomill®  -  Eine  Neue  Mühle  für  die  Feinzerkleinerung,' ZKG International 3, 50 pp.127-138 (1997).

Buzzi,  S.  and  G.  Sassone,  1993.  'Optimization  of  Clinker  Cooler  Operation,' Proc.  VDZ Kongress 1993: "Verfahrenstechnik der Zementherstellung" Bauverlag, Wiesbaden, Germany (pp.296-304).

Cadence. 2010a. Mid-Kiln Fuel Injector/Mixing Air. Proven Technology Reduces Fuel Costs and Emissions in Long Kilns. Technical Bulletin. http://www.cadencerecycling.com/Resources/TechnicalBulletin%20MA-MKT.pdf

Cadence.  2010b.  Mixing  Air  Technology.  Proven  Technology  Reduces  Fuel  Costs  and Emissions for PH/PC Kilns. Technical Bulletin. http://www.cadencerecycling.com/Resources/TechnicalBulletin-MixAir.pdf

Caffal, C. 1995. 'Energy Management in Industry,' CADDET Analyses Series 17 , Sittard, the Netherlands: CADDET.

Canadian Lime Institute,  2001.  'Energy  Efficiency  Opportunity  Guide  in  the  Lime  Industry,' Office of Energy Efficiency, Natural Resources Canada, Ottawa, ON.

Carolyn,  J.  2009.  An  Overview  of  Industrial  Waste  Heat  Recovery  Technologies  for Moderate Temperatures Less than 1000 o F. Northwest CHP Application Center.

Cayless,  M.  A.  and  A.  M.  Marsden  (Eds.).  1983.  Lamps  and  Lighting.  Edward  Arnold, London.

Cembureau, 1997. 'Best Available Techniques for the Cement Industry,' Brussels: Cembureau.

Cembureau, 2009. Sustainable Cement Production. Co-Processing of Alternative Fuels and Raw Materials in the European Cement Industry . Brussels, Belgium.

Cement Kiln Recycling Coalition (CKRC), 2002. 'Volume of Hazardous Wastes Used as Fuel in Cement Kilns' Washington, DC (http://www.ckrc.org/infocen.html).

Centre for the Analysis and Dissemination of Demonstrated Energy Technologies (CADDET), 1996.  'Tyres  used  as  fuel  in  cement  factory,'  International  Energy  Agency,  Sittard,  the Netherlands: CADDET.

Centre for the Analysis and Dissemination of Demonstrated Energy Technologies (CADDET). 1997a.  'Revolutionary  low-NOx  high-efficiency  gas  burner,'  International  Energy  Agency, Sittard, the Netherlands: CADDET.

Centre for the Analysis and Dissemination of Demonstrated Energy Technologies (CADDET), 1997b. 'Saving Energy with Efficient  Compressed Air  Systems,'  International Energy Agency, Maxi Brochure 06, Sittard, The Netherlands.

Centre for the Analysis and Dissemination of Demonstrated Energy Technologies (CADDET),  2001.  Saving  Energy  with  Daylighting  Systems.  Centre  for  the  Analysis  and Dissemination  of  Demonstrated  Energy  Technologies  (CADDET).  Maxi  Brochure  14, Sittard, the Netherlands.

Chatterjee,  A.K.,  2004.  Materials  Preparation  and  Raw  Milling.  In:  Bhatty,  J.I.,  M.F. MacGregor, S.H. Kosmatka, editors, 2004. Innovations in Portland Cement Manufacturing . SP400, Portland Cement Association (PCA), Skokie, Illinois, U.S.A., 2004, 1404 pages.

CIPEC, 2001. 'Blue Circle Cement Fires Up Energy savings at Ontario Plants,' Heads Up CIPEC 5,  21  pp.1-2  (2001).  Published  by  Office  of  Energy  Efficiency,  Natural  Resources Canada, Ottawa, ON, Canada.

Clauser, S., 2010. 1.2 Million Euro fur Neuen Sichter. Die Clocke . Samstad 31 Juli 2010.

Cohen,  S.M.,  1992.  'Fluid  Bed  Cement  Clinker  Applications,' Proc.  1992  IEEE  Cement Industry Technical Conference XXXIV , Dallas, TX, May 10-14, 1992, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.279-301).

Cohen,  S.M.,  1993.  'Fluid-Bed  Cement  Clinker  Applications,' Proc.  VDZ  Kongress  1993: "Verfahrenstechnik der Zementherstellung" Bauverlag, Wiesbaden, Germany (pp.342-351).

Cohen, S.M., 1995."Anwendungsmöglichkeiten der Wirbelschicht bei der Zementherstellung" Zement-Kalk-Gips 1, 48 pp.8-16 (1995).

Consortium  for  Energy  Efficiency  (CEE),  2007.    Energy-Efficiency  Incentive  Programs: Premium-Efficiency  Motor  &amp;  Adjustable  Speed  Drives  in  the  U.S.  and  Canada.  Boston, Massachusetts. May.

Cook, B., 1998. 'High-efficiency Lighting in Industry and Commercial Buildings.' Power Engineering Journal . October: 197-206.

Copper Development Association (CDA), 2001. High-Efficiency Copper-Wound Motors Mean Energy and Dollar Savings. New York, New York.

http://energy.copper.org/motorad.html.

Coppinger,  S.J.,  2010.  'Developing  a  Corporate-Wide  Strategic  Energy  Management Program.' 2010 IEEE-IAS/PCA  52 nd Cement  Industry Technical Conference Record , Colorado  Springs,  CO,  March  28  -  April  1,  2010,  Institute  of  Electrical  and  Electronics Engineers Inc. New York, NY, USA (pp.1-8).

COWIconsult,  March  Consulting  Group  and  MAIN,  1993.  'Energy  Technology  in  the Cement Industrial Sector', Report prepared for CEC - DG-XVII, Brussels, April 1992.

Davidovits, J., 1991. "Geoploymers: Inorganic Polymeric New Materials" Journal of Thermal Analysis, 37 pp.1633-1656 (1991).

Davidovits, J., 1993.  "Geoploymer  Cements  to  Minimize  Carbon-Dioxide  GreenhouseWarming" in: M. Moukwa, S.L. Sarkar, K. Luke and M.W. Grutzeck (eds.) "Cement Based Materials: Present, Future, and Environmental Aspects", Ceramic Transactions, 37 pp. 165182 (1993).

Davidovits,  J.,  1994a.  "Global  Warming  Impact  on  the  Cement  and  Aggregates  Industries" World Resource Review 2, 6 pp.263-278 (1994).

Davidovits, J. 1994b.  Properties   of   Geopolymer   Cements.   Alkaline   Cements   and Concretes, KIEV Ukraine, 1994, 9.

Davidovits,  J.  2002.  '30  years  of  successes  and  failures  in  geopolymer  applications  Market trends and potential breakthroughs', Geopolymer 2002 Conference, 28-29 October, Melbourne, Australia.

De Hayes, L.J., 1999. 'Flexibility, Availability and Maintenance Concept for the Quadropol ,' Polysius Teilt Mit No. 208, pp.33-38, Krupp Polysius, Germany.

Detwiler, R.J. and P.D. Tennis, 1996. 'The Use of Limestone in Portland Cement: a State-ofthe-Art Review,' Skokie, IL: Portland Cement Association.

Dikty,  M.,  P.  Hilgraf,  R.  Worthington.,  2008.  'Energy  Saving  Pneumatic  Conveying  Pipe System.' 2008 IEEE Cement Industry Technical Conference Record , Miami, FL, May 18-22, 2008, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.229-240).

Dolores, R. and M.F. Moran, 2001. 'Maintenance and Production Improvements with ASDs' Proc.2001  IEEE-IAS/PCA Cement Industry Technical Conference , pp. 85-97.

Drzymala, S. 2012. Titan America LLC. Personal Communication.

Duplouy, A. and J. Trautwein, 1997. "Umbau und Optimierung der Drehofenanlagen im Werk Karsdorf der Lafarge Zement Gmbh." ZKG International 4, 50 pp.190-197 (1997).

Duxson, P., Provis, J., Lukey, G.,  van  Deventer,  J.,  2007.  'The  role  of  inorganic  polymer technology in the development of green concrete', Cement and Concrete Research , vol 37, pp1590-1597.

Efficiency  Partnership,  2004.  Industrial  Product  Guide  -  Manufacturing  and  Processing Equipment: Compressed Air Equipment. Flex Your Power, San Francisco, California.

Electric  Apparatus  Service  Association  (EASA),  2003.  The  Effect  of  Repair/Rewinding  on Motor Efficiency. St. Louis, Missouri.

Electric Apparatus Service Association (EASA), 2006. ANSI/EASA Standard AR100-2006. Recommended Practice for the Repair of Rotating Electrical Apparatus. St. Louis, Missouri.

Eley, C, et al., 1993. Advanced Lighting Guidelines: 1993. California Energy Commission, Sacramento, California.

Ellerbrock, H. G., and H. Mathiak., 1994. 'Comminution Technology and Energy Management' Zement-Kalk-Gips 47   630-647 (1994). :

Energy Information Admininstration (EIA), U.S. Department of Energy, 2011a . Electric Power Annual 2010 Washington, DC: Energy Information Administration.

Energy Information Admininstration (EIA), U.S. Department of Energy, 2011b .  Emissions of Greenhouse  Gases  in  the  United  States,  2009. Washington,  DC:  Energy  Information Administration.

Energy Information Admininstration (EIA), U.S. Department of Energy, various years . Annual Energy Outlook, various years . Washington, DC: Energy Information Administration.

Energy  Technology  Support  Unit  (ETSU),  1988.  'High  Level  Control  of  a  Cement  Kiln,' Energy  Efficiency  Demonstration  Scheme,  Expanded  Project  Profile  185,  Harwell,  United Kingdom.

Engin T. and Ari  V.,  2005.  'Energy  Auditing  and  Recovery  for  a  Dry  Type  Cement  Rotary Kilns System - A Case Study.' Energy Conversion and Management, 46, pp.551-562.

European Cement Research Academy (ECRA), Cement Sustainability Initiative (CSI), 2009. 'Development of  State  of  the  Art  -  Techniques  in  Cement  Manufacturing:  Trying  to  Look Ahead'. Düsseldorf, Germany.

European  Commission  JRC-IPTS,  2010.  IPPC  Reference  Document  on  Best  Available Techniques  (BREF)  in  the  Cement,  Lime  and  Magnesium  Oxide  Manufacturing  Industries, May 2010. http://eippcb.jrc.ec.europa.eu/reference/

Fenning, L. et al. (Eds.) 2001. Pump Life Cycle Costs: A Guide to LCC Analysis for Pumping Systems. Hydraulic Institute/Europump/ United States Department of Energy. ISBN: 1-880952-58-0.

F.L.Smidth, 1995. Mineralized Clinker Technology. http://www.flsmidth.com/~/media/Brochures/Brochures%20for%20plant%20service%20and %20spares/mineralklinker.ashx

F.L.Smidth, 2007. Blending Silo Techniques for Bulk Material Handling Systems. http://catalog.conveyorspneumatic.com/Asset/Blending-SiloTechniques.pdf

Folsberg, J., 1997. 'The Air-Swept Ring Roller Mill for Clinker Grinding' Proc.1997 IEEE/PCA Cement Industry Technical Conference XXXIX Conference Record , Institute of Electrical and Electronics Engineers: New Jersey.

Folsberg, J., 1997. "Future Grinding" Asian Cement, January 1997, pp.21-23 (1997).

Fortsch, D.S., 2005. 'Wear Impacts In Slag Grinding In Various Grinding Technologies.' 2005 IEEE Cement Industry Technical Conference Record ,  Kansas City, Missouri, USA, May 1520, 2005, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.177191).

Fortsch,  D.S.,  2006.  'Ball  Charge  Loading  -  Impact  On  Specific  Power  Consumption  and Capacity.' 2006  IEEE  Cement  Industry  Technical  Conference  Record ,  Phoenix,  Arizona, USA, April 9-14, 2006, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.62-72).

Frailey, M.L. and K.R. Happ, 2001. 'Capitol Cement's Project 2000,' Proceedings IEEE 2001 Cement Industry Technical Conference , May 2001.

FCT  International,  2009.  Gyro-Therm  Burners  -  Revolutionary  Low  NOx  High  Efficiency Gas Burners, December 2009. http://www.fctinternational.com/

Fujimoto, S., 1993. 'Modern Technology Impact on Power Usage in Cement Plants,' Proc. 35th IEEE Cement Industry Technical Conference , Toronto, Ontario, Canada, May 1993.

Fujimoto,  S.,  1994.  'Modern  Technology  Impact  on  Power  Usage  in  Cement  Plants,' Ieee Transactions on Industry Applications , Vol. 30, No. 3., June.

Galitsky, C., S.C. Chang, E. Worrell, and E. Masanet, 2005. Energy Efficiency Improvement and Cost Saving Opportunities for the Pharmaceutical Industry: An ENERGY STAR Guide for Energy  and  Plant  Managers.  Lawrence  Berkeley  National  Laboratory,  Berkeley,  California. Report LBNL-57260.

Gerbec, R., 1999. Fuller Company. Personal Communication.

Goebel, A., 2001. Personal communication with Alexander Goebel, Krupp Polysius, Beckum, Germany, December 20 th , 2001.

Gomes,  A.  S.,  1990.  'Energy  Saving  and  Environmental  Impact  in  the  Cement  Industry,' Energy Efficiency in the Cement Industry (Ed. J. Sirchis), London, England: Elsevier Applied Science (pp 23-26).

Gotro,  C.A.,  2001.  'Oxygen  Enrichment  at  Cemex's  Victorville  Plant' Proc.2001  IEEEIAS/PCA Cement Industry Technical Conference pp. 281-287

Goyenka,  P.K.,  B.L.  Saini,  A.  Gupta,  2000.  Energy  Audit  and  Process  Optimization. Vasavadatta Cement India.

http://www.energymanagertraining.com/Journal/24032006/EnergyAuditandProcessOptimisa tion.pdf

Greer, W. L., Johnson, M. D., Morton, E.L., Raught, E.C., Steuch, H.E. and Trusty Jr., C.B., 1992.  'Portland  Cement,'  in Air  Pollution  Engineering  Manual, Anthony  J.  Buonicore  and Waynte T. Davis (eds.). New York: Van Nostrand Reinhold.

Grydgaard, P., 1998. 'Get out of the Wet,' International Cement Review , April 1998.

Hanle,  L.,  P.  Maldonado,  E.  Onuma,  M.  Tichy,  H.G.  van  Oss,  2006.  Mineral  Industry Emissions. In: S. Eggleston, L. Buendia, K. Miwa, T. Ngara, K. Tanabe (eds.). 2006 IPCC Guidelines for National Greenhouse Gas Inventories , Volume 3, Industrial Processes and Product Use .

Harder,  J.,  2010a.  'Current  Modernization  and  Maintenance  Concepts  in  the  Cement Industry .' ZKG International , 5 (2010), pp.24-38.

Harder, J., 2010b. 'Grinding Trends in the Cement Industry.' ZKG International , 4 63 (2010), pp. 46-58.

Haspel, D. and W. Henderson, 1993. 'A New Generation of Process Optimisation Systems,' International Cement Review , June 1993, pp.71-73 (1993).

Heijningen, R.J.J., J.F.M. Castro, and E. Worrell (eds.), 1992. 'Energiekentallen in Relatie tot Preventie  en  Hergebruik  van  Afvalstromen,'NOVEM/RIVM,  Utrecht/Bilthoven,  The Netherlands.

Hendriks, C. A., Worrell, E., de Jager, D., Blok, K., Riemer, P. 2004. Emission Reduction of Greenhouse Gases from the Cement Industry. Greenhouse Gas Technologies Conference Paper - Cement.

Hilger, J., 2003. 'Combined Utilization of Oil Shale Energy and Oil Shale Minerals within the Production for Cement and other Hydraulic Binders'. Oil Shale . Vol 20, 3, pp.347-355.

Hills, L.M.  2007. Clinker  Microstructure  and  Grindability:  Updated  Literature  Review , SN2967, Portland Cement Association, Skokie, Illinois, USA.

Holderbank Consulting, 1993.  'Present  and  Future  Energy  Use  of  Energy  in  the  Cement and Concrete Industries in Canada,' CANMET, Ottawa, Ontario, Canada.

Holland,  M.,  vo  Seebach,  M.,  and  Ranze,  W.,  1997.  'Variable  Speed  Drives  for  Roller Presses.' Proc.1997 IEEE/PCA Cement Industry Technical Conference XXXIX Conference Record , Institute of Electrical and Electronics Engineers: New Jersey.

Holland,  M.,  2001.  'AC  DC  Kilns,' Proc.  2001  IEEE-IAS/PCA  Cement  Industry  Technical Conference, pp. 75- 84.

Hollingshead A.F. and Venta G.J., 2009. 'Carbon Dioxide Reduction Technology Effectiveness  Assessment  -  Initial  Evaluation'.  Portland  Cement  Association  (PCA),  PCE R&amp;D SN3125.

Howe, B. and B. Scales, 1995. 'Assessing Processes for Compressed Air Efficiency,' ESource Tech Update . November 1995.

Hrizuk, M.J., 1999. 'Expansion is Key at Durkee,' International Cement Review , May 1999.

IBAU HAMBURG, 2009. Central Cone Blending Silo. http://www.ibauhamburg.de/pdf/central-cone-blending-silo.pdf

Industrial Assessment  Centers  (IAC).  2012.  Industrial Assessment  Centers  Database. Rutgers University, New Brunswick, New Jersey. Accessed July 4, 2012. http://iac.rutgers.edu/database

International Energy Agency (IEA), 2000. Daylight in Buildings: A Sourcebook on Daylighting Systems and Components. Paris, France.

International  Energy  Agency  (IEA),  2009.  'Energy  technology  Transitions  for  Industry  Strategies for the Next Industrial Revolution.' International Energy Agency Publications. Paris, France.

International  Energy  Agency  -  Energy  Technology  Systems  Analysis  Programme  (IEAETSAP), 2010. Cement  Production -Highlights. Technology Brief 103, June 2010. http://www.iea-etsap.org/web/E-TechDS/PDF/I03\_cement\_June%202010\_GS-gct.pdf

Institute  of  Technical  Information  for  Building  Materials  Industry  (ITIBMIC),  2004.  'Final Report  on  Cement  Survey.'  Prepared  for  the  United  Nations  Industrial  Development Organization (UNIDO) for the Contract Entitled: Cement Sub-sector Survey for the Project Energy Conservation and GHG Emissions Reduction in Chinese TVEs-Phase II .  Contract no. 03/032/ML, P.O. No. 16000393, September 9.

Ingersoll  Rand,  2001.  'Air  Solutions  Group  -  Compressed  Air  Systems  Energy  Reduction Basics,'http://www.air.ingersoll-rand.com/NEW/pedwards.htm.

Jaccard, M.K. &amp; Associates and Willis Energy Services Ltd., 1996. Industrial Energy End-Use Analysis and Conservation Potential in Six Major Industries in Canada .  Report prepared for Natural Resources Canada, Ottawa, Canada.

Johansen V., J.I. Bhatty. 2004. Fluxes and Mineralizers in Clinkering Process. In: Bhatty, J.I., M.F. MacGregor, S.H. Kosmatka, editors, 2004. Innovations in Portland Cement Manufacturing .  SP400, Portland Cement Association (PCA), Skokie, Illinois, U.S.A., 2004, 1404 pages.

Kääntee U., R. Zevenhoven, R. Backman, M. Hupa, 2004. 'Cement Manufacturing Using Alternative Fuels and the Advantages of Process Modeling'. Fuel Processing Technology . Vol. 85, pp.293-301.

Keyssner, M. and Abraham, P. C. 2005. 'A Decade of VRM Progress for Loesche.' Published In: Global Cement Technology (GCM), http://www.loescheindia.com/publications.aspx

Khurana  S.,  R.  Banerjee,  U.  Gaitonde,  2002.  'Energy  Balance  and  Cogeneration  for  a Cement Plant.' Applied Thermal Engineering , 22, pp.485-494.

Klotz, B., C. Claussnitzer, D. Longhurst. 2009. 'TXI, ORO GRANDE Plant Modernization Raw Meal Production with a High Pressure Grinding Roll' 2009 IEEE Cement Industry Technical Conference  Record ,  Palm  Springs,  CA,  May  29-June  5,  2009,  Institute  of  Electrical  and Electronics Engineers Inc. New York, NY, USA (pp.1-8).

Kreisberg, A., 1993. "Selection and Application of Roller Press for Raw Meal Preparation at Alpena" Proc.  KHD  Symposium  '92,  Volume  1  "Modern  Roller  Press  Technology" ,  KHD Humboldt Wedag, Cologne, Germany (1993).

Lang, T.A., 1994. 'Energy Savings Potential in the Cement Industry and Special Activities of the 'Holderbank' Group,' in Industrial Energy Efficiency: Policies and Programmes Conference  Proceedings (May  26-27,  1994).  Paris:  International  Energy  Agency  and  U.S. Department of Energy.

Lawrence,  C.D.  1998.  'The  Production  of  Low-Energy  Cements'.  In:  P.  C.  Hewlett  (Ed.) Lea's Chemistry of Cement and Concrete . 4 th ed, Arnold, London, 1998.

Leger, C.B., and J.G. Friday, 2001. 'Oxygen Enrichment for Cement Kiln Firing' Proc. 2001 IEEE-IAS/PCA Cement Industry Technical Conference, pp.271-278.

Legmann,  H.  and  D.  Citrin,  2004.  Recovery  of  Low-Grade  Heat  by  Means  of  the  ORC Process in the Cement Industry. Reprinted from World Cement, April 2004.

Lesniak, T., 2009. 'Slag as a Raw Material: Assessing the Economics.' 2009 IEEE Cement Industry Technical Conference Record , Palm Springs, CA, May 29-June 5, 2009, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.1-10).

Lesnikoff, G. 1999. Hanson Cement, Cupertino, CA, personal communication.

Levonian D., J. Moore, J. Murphy, 2009. Reducing Costs. Pre-printed from World Cement, July 2009. http://www.malvern.com/common/downloads/campaign/MRK1249-01.pdf

Longhurst, D.A., 2010. 'Economics and Methodology of Ball Mill Media Maintenance.' 2010 IEEE-IAS/PCA Cement Industry Technical Conference Record , Colorado Springs, CO, March 28-April  1,  2010,  Institute  of  Electrical  and  Electronics  Engineers  Inc.  New  York,  NY,  USA (pp.1-20).

Lowes,  T.M.  and  Bezant,  K.W.,  1990.  'Energy  Management  in  the  UK  Cement  Industry' Energy Efficiency in the Cement Industry (Ed. J. Sirchis), London, England: Elsevier Applied Science.

Lighting Research  Center  (LRC),  2001.  Lighting  Futures.  LEDs:  From  Indicators  to Illuminators? Rensselaer Polytechnic Institute, Troy, New York. http://www.lrc.rpi.edu/index.asp

Manias, C.G., 2004. Kiln Burning Systems. In: Bhatty, J.I., Miller, F.M., Kosmatka, S.H. eds. 2004. Innovations in Portland Cement Manufacturing. SP400, Portland Cement Association (PCA). Skokie, Illinois, U.S.A.

Marchal,  G.  1997.  'Industrial  Experience  with  Clinker  Grinding  in  the  Horomill' Proc.1997 IEEE/PCA  Cement  Industry  Technical  Conference  XXXIX  Conference  Record ,  Institute  of Electrical and Electronics Engineers: New Jersey.

Martin, G., T. Lange, and N. Frewin, 2000. 'Next Generation Controllers for Kiln/Cooler and Mill Applications based on Model predictive Control and Neural Networks,' Proceedings IEEEIAS/PCA 2000 Cement Industry Technical Conference ,  Salt  Lake  City,  UT,  May  7 th -  12 th , 2000.

Martin, G. and S. McGarel, 2001a. 'Automation Using Model Predictive Control in the Cement Industry' Pavillion Technologies, Inc., Austin, TX (based on a paper published in International Cement Review , February 2001, pp.66-67). http://www.pavtech.com/

Martin,  N.,  N.  Anglani,  D.  Einstein,  M.  Khrushch,  E.  Worrell,  and  L.K.  Price,  2000b. Opportunities to Improve Energy Efficiency and Reduce Greenhouse Gas Emissions in the U.S. Pulp and Paper Industry. Lawrence Berkeley National Laboratory, Berkeley, California. Report LBNL-46141.

Martin,  G.  and  S.  McGarel,  2001b.  'Automated  Solution,' International  Cement  Review , February 2001, pp.66-67.

Martin, G., S. McGarel, T. Evans, and G. Eklund, 2001. 'Reduce  Specific Energy Requirements while Optimizing NOx Emissions Decisions in Cement with Model Predictive Control,'  Personal  Communication  from  Pavilion  Technologies,  Inc.,  Austin,  TX,  December 3 rd , 2001.

Martin, N., M. Ruth, and L. Price, R. N. Elliott, A. M. Shipley, and J. Thorne, 2000. 'Emerging EnergyEfficient Industrial Technologies,' Berkeley: Lawrence Berkeley National Laboratory/Washington, DC: ACEEE.

Mathée, H., 1999. 'NOx Reduction with the Prepol MSC Process at the Lengerich Plant of Dyckerhoff Zement GmbH,' Polysius Teilt Mit No. 208, pp.53-55, Krupp Polysius, Germany.

Mayes, G., 2001. 'Oxygen Enrichment at the TXI Midlothian Cement Plant' Proc.2001 IEEEIAS/PCA Cement Industry Technical Conference, pp.289-292.

Menzel, K., 1997. 'Experience with the Prepol-MSC Calciner and a Review of the Possibilities it Offers,' Polysius Teilt Mit No. 198, pp.29-33, Krupp Polysius, Germany.

Merck and Company, Inc., 2005. Personal communication with Helene Ferm, Rahway Site Energy Team, Rahway, New Jersey, September 7th.

Millennium EMS Solutions Ltd. (MEMS), 2010. Guide to the Code of Practice for the BC Concrete and Concrete Products Industry . Version 6. BC  Ready  Mixed Concrete Association.

Mirolli, M.D., 2005. 'The Kalina Cycle for Cement Kiln Waste Heat Recovery Plants.' Proc . 2005  IEEE-IAS  Cement  Industry  Technical  Conference  Record , Kansas  City,  Missouri, USA, May 15-20, 2005, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA, pp.330-336.

Motor  Decisions  Matter  (MDM),  2012.  Motor  Planning  Kit.    Boston,  Massachusetts. http://www.motorsmatter.org/tools/mpkv22.pdf

Morin  V.,  G.  Walenta,  E.  Gartner,  P.  Termkhajomkit,  I.  Baco,  J.  M.  Casabonne,  2011. Hydration of Belite Calcium Sulfo-Aluminate Cement Aether TM . ICCC Madrid, July 4 th , 2011, http://www.aether-cement.eu/

Müller,  N.  and  J.  Harnsich,  2008.  A  Blueprint  for  a  Climate  Friendly  Cement  Industry. Ecofys, Germany GmbH, Nürnberg.

Myer, M., M.L. Paget, R.D. Ringard., 2009. Performance of T12 and T8 Fluorescent Lamps and Troffers and  LED Linear Replacement Lamps CALiPER Benchmark Report: Medium: ED; Size: PDFN. Report # PNNL-18076; Other: BT0301000

Nadel,  S.,  M.  Shepard,  S.  Greenberg,  G.  Katz  and  A.  de  Almeida,  1992.  "Energy  Efficient Motor  Systems:  A  Handbook  on  Technology,  Program  and  Policy  Opportunities"  ACEEE, Washington, D.C., USA.

National Electrical Manufacturers Association (NEMA), 2001. NEMA Standards Publication No. MG-10 2001, Energy Management Guide For Selection and Use of Fixed Frequency Medium AC Squirrel-Cage Polyphase Induction Motors . Rosslyn, Virginia.

National Electrical Manufacturers Association (NEMA), 2012. American National Standard Motors and Generators. . American National Standards Institute, Rosslyn, Virginia.

Nelson, K., 1994. 'Finding and Implementing Projects that Reduce Waste,' in R. Socolow, C. Andrews, F. Berkhout and V.  Thomas, Industrial  Ecology  and  Global  Change ,  Cambridge, UK: Cambridge University Press.

Net  Balance  Foundation,  2007.  Zeobond  Carbon  Emission  Life  Cycle  Assessment  of Geopolymer Concrete, Final Report. Melbourne, Australia.

Neto,  M.,  1990.  'Waste  Gas  Heat  Recovery  in  Cement  Plants' Energy  Efficiency  in  the Cement Industry (Ed. J. Sirchis), London, England: Elsevier Applied Science.

Nisbet,  M.,  1996.  'The  Effects  of  New  Climate  change  Commitments  on  Energy  Intensive Industries: The Cement Industry,' in The Impact of High Energy Price scenarios on EnergyIntensive Sectors: Perspectives from Industry Workshops (1997) by Sutherland, R., Richards, N., Nisbet, M., Steinmeyer, D., Slinn, R. Tallet, M., Fruehan, R.J.

Office of Technology Assessment, 1993. "Industrial Energy Efficiency" (OTA Report E-560), Washington, D.C., USA.

Papillon  L.,  D.  Cagnon,  C.  Oesch,  2004.  'A  New  Vertical  Roller  Mill  Installation  Concept.' 2004 IEEE-IAS/PCA Cement Industry Technical Conference Record , Chattanooga, TN, April 25-30, 2004, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.6978).

Parekh, P., 2000. 'Investment Grade Compressed Air System Audit, Analysis, and Upgrade,' In: Proceedings  22nd  National  Industrial  Energy  Technology  Conference  Proceedings. Houston, Texas. April 5-6: pp 270-279.

Parkes, F.F., 1990. 'Energy Saving by Utilisation of High Efficiency Classifier for Grinding and Cooling  of Cement  on  Two  Mills  at  Castle  Cement  (Ribblesdale)  Limited,  Clitheroe, Lancashire, UK' Energy Efficiency in the Cement Industry (Ed. J. Sirchis), London, England: Elsevier Applied Science.

Patzelt, N., 1993. "Finish Grinding of Slag" World Cement 10, 24 pp.51-58 (1993).

Philips  Kiln  Services,  2001.  'Philips  Enviro-Seal,  Case  Study  -  M/S  Maihar  cement',  URL: http://www.kiln.com, accessed November 2001.

Portland Cement Association (PCA), Economic Research Department, 1996. 'U.S. Cement Industry Fact Sheet, Fourteenth Edition.' Skokie, IL: Portland Cement Association.

Portland  Cement  Association  (PCA),  1997. Blended  Cement  Potential  Study .  Skokie,  IL: Portland Cement Association.

Portland  Cement  Association  (PCA),  2012.  Vertical  Roller  Mills  for  Cement  Grinding. http://www.cement.org/manufacture/man\_vrm.asp

Pottier,  L.  and  Niel,  P.,  2008.  Optimization  with  TSV.  Separator  Technology,  December 2008.

Price, A. and M.H. Ross, 1989. 'Reducing Industrial Electricity Costs - an Automotive Case Study,' The Electricity Journal . July: 40-51.

Price, L., A. Hasanbeigi, H. Lu, W. Lan, 2009. Analysis of Energy-Efficiency Opportunities for the  Cement  Industry  in  Shandong  Province,  China . Lawrence  Berkeley  National Laboratory, LBNL-2751E-Rev.

Pulkki, P., 2004. 'Not Just Speed Control.' 2004 IEEE-IAS/PCA Cement Industry Technical Conference Record , Chattanooga, TN, April 25-30, 2004, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.169-184).

Radgen,  P.  and  E.  Blaustein  (eds.),  2001.  'Compressed  Air  Systems  in  the  European Union,  Energy,  Emissions,  Savings  Potential  and  Policy  Actions,'.Fraunhofer  Institute  for Systems Technology and Innovation, Karlsruhe, Germany.

Regitz, J., 1996.  'Evaluation of Mill Drive Options' IEEE  Transactions  on  Industry Applications 3, 32,   pp. 653.

Renfrew,  S.,  R.E.  Shenk,  S.W.  Miller,  2005.  'Environmental  Challenges  at  CEMEXDavenport,  CA' 2005  IEEE  Cement  Industry  Technical  Conference  Record ,  Kansas  City, Missouri, USA, May 15-20, 2005, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.192-202).

Robl, T.L., L. Kentucky, C.J. McCormick, 1997. 'We are running out of fly ash: The problem of regional supply problems.' Third Annual Conference on Unburned Carbon on Utility Fly Ash . http://www.netl.doe.gov/publications/proceedings/97/97ub/robl.pdf

Ruby, C.W., 1997. 'A New Approach to Expert Kiln Control.' Proc.1997 IEEE/PCA Cement Industry Technical Conference  XXXIX  Conference  Record , Institute of Electrical and Electronics Engineers: New Jersey.

Salzborn, D. and A. Chin-Fatt, 1993. "Operational Results of a Vertical Roller Mill Modified with  a  High  Efficiency  Classifier" Proc.  35th  IEEE  Cement  Industry  Technical  Conference , Toronto, Ontario, Canada, May 1993.

Sauli,  R.S.,  1993.  "Rotary  Kiln  Modernization  and  Clinker  Production  Increase  at  Testi Cement Plant of S.A.C.C.I. Spa., Italy" Proc. KHD Symposium '92, Volume 2 "Modern Burning Technology" , KHD Humboldt Wedag, Cologne, Germany.

Scales, W. and D.M. McCulloch, 2007. Best Practices for Compressed Air Systems- Second Edition, Compressed Air Challenge®. Washington, DC. http://www.compressedairchallenge.org/

Scheuer,  A.  and  Sprung,  S.,  1990.  'Energy  Outlook  in  West  Germany's  Cement  Industry' Energy Efficiency in the Cement Industry (Ed. J. Sirchis), London, England: Elsevier Applied Science.

Schmidt,  H-J.,  1998.  'Chrome  Free  Basic  Bricks  -  A  Determining  Factor  in  Cement Production' Proc.1998  IEEE-IAS/PCA Cement Industry Technical Conference, pp.155-167.

Schnatz, R., 2009. Upgrading of Ball Mill Cement Grinding Systems with Polycom ® . Green Cementech, May 7-8.

Schneider,  M.,  2008.  Innovation  and  Optimization  in  Cement  Grinding.  European  Cement Research Academy (ECRA). New Delhi , 19/20 September 2008.

Seebach, H.M. von, E. Neumann and L. Lohnherr, 1996. "State-of-the-Art of Energy-Efficient Grinding Systems" ZKG International 2 49 pp.61-67 (1996).

Shafer,  B.,  2001.  'Oxygen  Enrichment  at  California  Portland  Cement  Company's  Mojave Plant' Proc 2001. IEEE-IAS/PCA Cement Industry Technical Conference , pp.293-299.

Shenk R.E., L.S. Jensen, 2009. 'Calciner Burner Design for Alternative Fuels'. Proc. 2009 IEEE  Cement  Industry  Technical  Conference  Record ,  Palm  Springs,  California  USA,  31 May-4 June, 2009, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.1-7).

Simmons, M., L. Gorby, J. Terembula, 2005. 'Operational Experience from the United States' First Vertical  Roller  Mill  for  Cement  Grinding.' 2005  IEEE  Cement  Industry  Technical Conference Record , Kansas City, Missouri, USA, May 15-20, 2005, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.241-249).

Skjeggerud K., A. Hand, N. Streit, 2009. 'Results from Burning Alternate Fuels'. Proc . 2009 IEEE  Cement  Industry  Technical  Conference  Record ,  Palm  Springs,  California  USA,  31 May-4 June, 2009, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.1-7).

Smart, J. and B. Jenkins, 2000. 'Combustion in the Rotary Kiln', The Combustion Institute, Leeds, UK http://www.chemeng.ucl.ac.uk/research/combustion/nl2000\_1/nl00\_1\_9.html

Somani,  R.A.,  S.S.  Kothari,  1997.  'Die  Neue  Zementlinie  bei  Rajashree  Cement  in Malkhed/Indien' ZKG International 8 50 pp.430-436 (1997).

Southern California Edison (SCE), 2003. Southern California Edison Educational Publication: Saving Money with Motors in Pharmaceutical Plants. Rosemead, California.

Staudt,  J.,  2009a.  Memorandum  to  Ravi  Srivastava,  Nick  Hutson,  Samudra  Vijay,  and Elineth Torres, 'GHG Mitigation Methods for Cement,' Andover Technology Partners, July 10, 2009.

Staudt,  J.,  2009b.  Memorandum  to  Ravi  Srivastava,  Samudra  Vijay,  and  Elineth  Torres, 'Costs  and  Performance  of  Controls  -  revised  from  comments,'  Andover  Technology Partners, March 10, 2009.

Steinbliss, E., 1990. 'Traditional and Advanced Concepts of Waste Heat Recovery in Cement Plants' Energy Efficiency in the Cement Industry (Ed. J. Sirchis), London, England: Elsevier Applied Science.

Steuch, H.E. and Riley, P., 1993. 'Ash Grove's New 2200 tpd Seattle Plant Comes on Line,' World Cement , April 1993.

Su, L-H., 1997. 'TPI Polene, An Operational View' International Cement Review , December 1997, pp.28-40.

Sukkar, M. N.,K. Happ, A. Shahid, 2005. 'Experience With Roller Press Systems at Southern Province  Cement  Company.' 2005  IEEE  Cement  Industry  Technical  Conference  Record , Kansas  City,  Missouri,  USA,  May  15-20,  2005,  Institute  of  Electrical  and  Electronics Engineers Inc. New York, NY, USA (pp.250-259).

Süssegger, A., 1993. "Separator-Report '92" Proc. KHD Symposium '92, Volume 1 "Modern Roller Press Technology" , KHD Humboldt Wedag, Cologne, Germany (1993).

Sutoh,  K.,  M.  Murata,  S.  Hashimoto,  I.  Hashimoto,  S.  Sawamura  and  H.  Ueda,  1992. "Gegenwärtiger  Stand  der  Vormahlung  von  Klinker  und  Zement-rohmaterialien  nach  dem CKP-System" ZKG 1, 45 pp.21-25 (1992).

Suzuki,  K.,  H.  Tochinai,  T.  Uematsa,  and  S.  Mishiro,  1993.  "A  New  Grinding  Method  for Ceramics  Uisng  a  Biaxially  Vibrated  Nonrotational  Ultrasonic  Tool" CIRP  Annuals 1, 42 pp.375-378 (1993).

Taylor, H.F.W., 1997. Cement Chemistry, second ed. Thomas Telford, London.

Terembula,  J.W.,  2004.  'Installed  Cost  Comparison  for  Cement  Grinding  Systems.' 2004 IEEE-IAS/PCA Cement Industry Technical Conference Record , Chattanooga, TN, April 25-30, 2004, Institute of Electrical and Electronics Engineers Inc. New York, NY, USA (pp.131-138).

Tokheim, L.A., 2006. 'Burning Chamber Installation for Increased Use of Alternative Fuels at Norcem, Brevik, Norway'. Based on paper published in World Cement . No11. 2005.

United Nations Framework Convention on Climate Change (UNFCCC), 2008a. CDM Project 1068 : Energy Efficiency Measures at Cement Production Plant, http://cdm.unfccc.int/Projects/DB/SGS-UKL1175340468.27/view

United Nations Framework Convention on Climate Change (UNFCCC), 2008b. CDM Project 1070: Vikram Cement (VC): Energy Efficiency Improvement by Gradation of Preheater in Cement Manufacturing.  http://cdm.unfccc.int/Projects/DB/SGS-UKL1175350601.7/view

United States Department of Energy, Office of Industrial Technologies (U.S.DOE-OIT), 1996. 'Energy  and  Environmental  Profile  of  the  U.S.  Iron  and  Steel  Industry,'  Washington,  DC: U.S.DOE-OIT.

United  States  Department  of  Energy  (DOE),  1999.  Forest  Products,  Project  Fact  Sheet. Improving Several Fan-driven Systems in an Oriented-Strand Board Manufacturing Facility. A  Motor  Challenge  Technical  Case  Study.  Office  of  Energy  Efficiency  and  Renewable Energy, Industrial Technologies Program, Washington, D.C. DOE/GO-10099.

United States Department of Energy (DOE), 2002. United States Industrial Electric Motor Systems Market Opportunities Assessment. Office of Industrial Technologies, Washington, D.C.

United States Department of Energy (DOE), 2003. Improving Fan System Performance. A Sourcebook  for  Industry.  Office  of  Energy  Efficiency  and  Renewable  Energy,  Industrial Technologies Program, Washington, D.C. DOE/GO-102003-1824.

United  States  Department  of  Energy  (DOE),  2004a.  Energy  Tips  -  Compressed  Air: Remove  Condensate  with  Minimal  Air  Loss.  Office  of  Energy  Efficiency  and  Renewable

Energy,  Industrial  Technologies  Program,  Washington,  D.C.    Compressed  Air  Tip  Sheet #13.

United  States  Department  of  Energy  (DOE),  2004b.  Energy  Tips  -  Compressed  Air: Eliminate Inappropriate Uses of Compressed  Air. Office of Energy Efficiency and Renewable Energy, Industrial Technologies Program, Washington, D.C.  Compressed Air Tip Sheet #2.

United  States  Department  of  Energy  (DOE),  2004c.  Energy  Tips  -  Compressed  Air: Alternative Strategies for Low-Pressure  End  Uses.  Office  of  Energy  Efficiency  and Renewable Energy, Industrial Technologies Program, Washington, D.C.  Compressed Air Tip Sheet #11.

United States Department of Energy (DOE). 2005a. CEMEX: Cement Manufacturer Saves 2.1 kWh  Annually With a Motor Retrofit Project. Industrial Technologies Program. Washington, D.C.

United States Department of Energy (DOE), 2005b. Energy Tips -Motor Systems. Eliminate Voltage Unbalance. Office of Energy Efficiency and Renewable Energy, Industrial Technologies Program, Washington, D.C. DOE/GO-102005-2061.

United States Department of Energy (DOE), 2005c. Canandaigua Wines: Compressed Air System Upgrade Saves Energy and Improves Performance at a Winery. Office of Energy Efficiency  and  Renewable  Energy,  Industrial  Technologies  Program,  Washington,  D.C. Report DOE/GO-102005-0121.

United  States  Department  of  Energy  (DOE),  2007.  CEMEX  Louisville  Plant  Company Energy  Savings  Assessment.  Advanced  Manufacturing  Office,  Technology  Deployment. http://www1.eere.energy.gov/manufacturing/tech\_deployment/partners/pdfs/esa-243-2.pdf

United  States  Department  of  Energy,  Energy  Efficiency  and  Renewable  Energy  (DOE), 2008. Improving  Motor  and  Systems  Performance:  A  Sourcebook  for  Industry. Office  of Energy Efficiency and Renewable Energy, Washington, D.C.

United States Department of Energy (DOE), 2012. Save Energy Now: Participating Plants. Office  of  Energy  Efficiency  and  Renewable  Energy,  Industrial  Technologies  Program, Washington, D.C.

http://apps1.eere.energy.gov/industry/saveenergynow/partners/participating\_plants.cfm

United States Department of Energy (DOE) and Compressed Air Challenge (CAC), 2003. Improving  Compressed  Air  System  Performance  -  A  Sourcebook  for  Industry.  Office  of Industrial Technologies, Washington, D.C.

United States Department of Energy, National Energy Technology Laboratory (U.S. DOENETL),  2001.  Cement  Kiln  Flue  Gas  Recovery  Scrubber  Project:  A  DOE  Assessment. DOE/NETL-2002/1163.

United States Environmental Protection Agency (U.S. EPA), 1994. Report to Congress on Cement Kiln Dust. 59-FR 709.

Environmental  Protection  Agency  (EPA),  2001.  'Green  Lights  Program  (Part  of  the ENERGY STAR Program),' http://es.epa.gov/partners/green/green.html.

United  States  Environmental  Protection  Agency  (U.S.  EPA),  2000a.  '2000  Buy  Recycled Products: Construction Products', U.S.EPA, Washington, D.C. http://www.epa.gov/epaoswer/non-hw/procure/pdf/const-00.pdf

United  States  Environmental  Protection  Agency  (U.S.  EPA),  2006. Teaming  Up  to  Save Energy -Protect Our Environment Through Energy Efficiency. Prepared by ICF International. Washington, D.C.

United  States  Environmental  Protection  Agency  (U.S.  EPA),  2007a.  Alternative  Control Techniques Document Update -NOx  Emissions from New Cement Kilns. Control Technologies for the Cement Industry: Final Report, U.S. EPA, Washington, DC.

United  States  Environmental  Protection  Agency  (U.S.  EPA),  2007b. Energy  Trends  in Selected Manufacturing Sectors: Opportunities and Challenges for Environmentally Preferable Energy Outcomes. Prepared by ICF International.

United States Environmental Protection Agency (U.S. EPA), 2008. Trends in Beneficial Use of  Alternative  Fuels  and  Raw  Materials.  Cement  Sector .  Revised  Draft.  October  2008. Washington, D.C.

United  States  Environmental  Protection  Agency  (U.S.  EPA),  2009. Mandatory Reporting of Greenhouse Gases, Final Rule . Federal Register/Vol. 74, No. 209, 30 October, 2009.

United  States  Geological  Survey  (USGS),  2010. 2008  Minerals  Yearbook  -  Cement [Advance Release] , Washington, D.C., USGS, http://minerals.er.usgs.gov/minerals/

United  States  Geological  Survey  (USGS),  2011a. 2009  Minerals  Yearbook  -  Cement [Advance Release] , Washington, D.C., USGS, http://minerals.er.usgs.gov/minerals/

United States Geological Survey (USGS), 2011b. Mineral Commodity Summaries - Clays, Washington, D.C., USGS, http://minerals.er.usgs.gov/minerals/

United States Geological Survey  (USGS),  2011c. Mineral Commodity  Summaries  Diatomite , Washington, D.C., USGS, http://minerals.er.usgs.gov/minerals/

United  States  Geological  Survey  (USGS),  2012a. 2010  Minerals  Yearbook  -  Cement [Advance Release] , Washington, D.C., USGS, http://minerals.er.usgs.gov/minerals/

United States Geological Survey (USGS), 2012b. 2010 Minerals Yearbook - Iron and Steel [Advance Release] , Washington, D.C., USGS, http://minerals.er.usgs.gov/minerals/

United States Geological Survey (USGS), 2012c. 2010 Minerals Yearbook - Slag Iron and Steel [Advance Release] , Washington, D.C., USGS, http://minerals.er.usgs.gov/minerals/

United  States  Geological  Survey  (USGS),  various  years, Minerals  Yearbook  -  Cement [Advance Release] , Washington, D.C., USGS, http://minerals.er.usgs.gov/minerals/

van  den  Broeck,  M.,  1998.  'A  SD100  Sturtevant  High-Efficiency  Classifier  for  OrignyRochefort,' International Cement Journal 2 pp.39-45 (1998).

van den Broeck, M., 1999. 'GO Control Goes 'Multi-Circuit'' International Cement Journal 1, pp.35-37 (1999).

van Oss, H., 1999. Personal Communication. U.S. Geological Survey, February 9 th.

van Oss, H., 2002. Personal Communication. U.S. Geological Survey, March - May 2002

Van  Kuijk,  A.H.J.,  A.M.  Schakel  and  P.  Vissers,  1997.  "Dutch  Notes  on  BAT  for  the Production of Cement Clinker", Ministry of Housing, Spatial Planning and the Environment, The Hague, The Netherlands.

VDZ Research Institute of the Cement industry and PENTA Engineering Corp., 2008. Carbon Dioxide Control Technology Review ,  SN3001, Portland Cement Association (PCA), Skokie, Illinois USA.

Venkateswaran,  S.R.  and  H.E.  Lowitt,  1988.  "The  U.S.  Cement  Industry,  An  Energy Perspective", U.S. Department of Energy, Washington D.C., USA.F

Videgar, R., Rapson, D. and Dhanjal, S., 1997. 'Gyro-therm Technology Boosts Cement Kiln Output, Efficiency and  Cuts NOx  Emissions.' Proc.1997  IEEE/PCA  Cement  Industry Technical  Conference  XXXIX  Conference  Record , Institute  of  Electrical  and  Electronics Engineers: New Jersey.

Vleuten, F.P. van der, 1994. 'Cement  in Development: Energy and Environment' Netherlands Energy Research Foundation, Petten, The Netherlands.

von Weizsäcker, E., K. Hargroves, M.S. Smith, C. Desha, P. Stasinopoulos, 2009 .  Factor Five -Transforming  the  Global  Economy  through  80%  Improvements  in  Resource Productivity . Malta: Gutenberg Press.

Wang,  Y.  and  Forssberg,  E.,  2003.  'International  Overview  and  Outlook  on  Comminution Technology.' Föringen  Mineralteknisk  Forskning/  Swedish  Mineral  Processing  Research Association .

WBCSD Cement Sustainability Initiative (CSI), 2011. Getting the Numbers Right (GNR), a global cement database,  http://www.wbcsdcement.org/GNR-2009/index.html

Weinhart, K-H., Gladbach, B., 1990. 'Utilisation of Waste Heat from the Cement Rotary Kiln' Energy Efficiency in the Cement Industry (Ed. J. Sirchis), London, England: Elsevier Applied Science.

World Business Council for Sustainable Development (WBCSD), SINTEF, 2006. Formation and Release of POPs in the Cement Industry . 2 nd edition.

Worrell,  E.,  J.W.  Bode,  J.G.  de  Beer,  1997.  "Energy  Efficient  Technologies  in  Industry  Analysing Research and Technology Development Strategies - The 'Atlas' Project", Dept. of Science, Technology &amp; Society, Utrecht University, Utrecht, The Netherlands.

Worrell  E.,  L.  Price,  N.  Martin,  C.  Galitsky,  Z.  Nan,  2008a. World  Best  Practice  Energy Intensity  Values  for  Selected  Industrial  Sectors .  Lawrence  Berkeley  National  Laboratory, LBNL-62806.

Worrell, E., Galitsky, C., and Price, L., 2008b. Energy Efficiency Improvement Opportunities for the Cement Industry. Berkeley, CA: Lawrence Berkeley National Laboratory, http://ies.lbl.gov/node/402

Worrell, E., L. Price, N. Martin, C. Hendriks and L. Ozawa Meida, 2001. 'Carbon Dioxide Emissions from the Global Cement  Industry,' Annual Review of Energy and the Environment 26 pp.303-329.

Wray,  J.,  P.  Sandberg,  W.  South,  C.  Mercer,  1999.  'Energy  savings  by  Lowering  LSF: Application of CBA ®  Technology,' International Cement Journal 1, pp.39-42.

Xenergy, Inc., 1998. United States Industrial Electric Motor Systems Market Opportunities Assessment.  Prepared  for  the  United  States  Department  of  Energy's  Office  of  Industrial Technology and Oak Ridge National Laboratory. Burlington, Massachusetts.

Young, G., 2002. Personal communication from Gerald I. Young, Penta Engineering Corp., St. Louis Missouri, March 2002.

Zement Kalk Gips (ZKG). 2010. New High-Efficiency Separator for Phoenix Cement. Issue 09/2010. http://www.zkg.de/en/artikel/zkg\_2010-09\_New\_high-efficiency\_separator\_for\_Phoenix\_Cement\_990315.html

Zongrjin, Li., Ding, Z. Shang,  Y., 2004.  'Development  of  Sustainable  Cementitious Materials', in Proceedings of the International Workshop on Sustainable Development and Concrete Technologies, Beijing, China, pp.55-76.

## Appendix A: Basic Energy Efficiency Actions for Plant Personnel

Personnel at all levels should be aware of energy use and organizational goals for energy efficiency. Staff should be trained in both skills and general approaches to energy efficiency in day-to-day practices. In addition, performance results should be regularly evaluated and communicated to all personnel, recognizing high achievement. Some examples of simple tasks employees can do are outlined below (Caffal, 1995).

-  Eliminate  unnecessary  energy  consumption  by  equipment.  Switch  off  motors, fans, and machines when they are not being used, especially at the end of the working  day  or  shift,  and  during  breaks,  when  it  does  not  affect  production, quality, or safety. Similarly, turn on equipment no earlier than needed to reach the correct settings (temperature, pressure) at the start time.
-  Switch off unnecessary lights; rely on daylighting whenever possible.
-  Use  weekend  and  night  setbacks  on  HVAC  in  offices  or  air  conditioned buildings.
-  Report  leaks  of  water  (both  process  water  and  dripping  taps),  steam,  and compressed air.  Ensure  they  are  repaired  quickly.  The  best  time  to  check  for leaks is a quiet time like the weekend.
-  Look  for  unoccupied  areas  being  heated  or  cooled,  and  switch  off  heating  or cooling.
-  Check that heating controls are not set too high or cooling controls set too low. In  this  situation,  windows  and  doors  are  often  left  open  to  lower  temperatures instead of lowering the heating.
-  Check to make sure the pressure and temperature of equipment is not set too high.
-  Prevent drafts from badly fitting seals, windows and doors, and hence, leakage of cool or warm air.
-  Carry out regular maintenance of energy-consuming equipment.
-  Ensure that the insulation on process heating equipment is effective.

## Reference

Caffal, C., 1995. Energy Management in Industry. Centre for the Analysis and Dissemination of Demonstrated Energy Technologies (CADDET),  The Netherlands. Analysis Series 17, December.

## Appendix B: ENERGY STAR Energy Management Assessment Matrixes

The assessment matrixes on the following pages are designed to help organizations and energy managers compare their energy management practices to those outlined in the Guidelines for Energy Management.

## How to use the Assessment Matrixes

The matrixes outline the key activities identified in the ENERGY STAR Guidelines for Energy Management and three levels of implementation:

-  Where there is no evidence
-  Where some elements of a program are in place
-  Where an energy management program is fully implemented

To apply this tool to your organization:

- 1. Compare your program or facility to the Guidelines by identifying the degree of implementation that most closely matches your organization's program.
- 2. Use a highlighter to fill in the cell that best characterizes the level of implementation of your program or at your facility. You will now have a visual comparison of your program to the elements of the ENERGY STAR Guidelines for Energy Management.
- 3. Identify the steps needed to fully implement the energy management elements and record these in the Next Steps column.

In addition to the static Assessment Matrixes printed below, interactive versions are available on the U.S. EPA website by following these links.

ENERGY STAR Energy Program Assessment Matrix

ENERGY STAR Facility Assessment Matrix

ENERGY STAR Small/Medium Manufacturer Energy Management Assessment

## ENERGY STAR ®   Energy Management Assessment Matrix

|                                           | Little or no evidence                                          | Some elements                                         | Fully implemented                                                         | Next Steps                                |
|-------------------------------------------|----------------------------------------------------------------|-------------------------------------------------------|---------------------------------------------------------------------------|-------------------------------------------|
| Make Commitment to Continuous Improvement | Make Commitment to Continuous Improvement                      | Make Commitment to Continuous Improvement             | Make Commitment to Continuous Improvement                                 | Make Commitment to Continuous Improvement |
| Energy Director                           | No central or organizational resource Decentralized management | Central or organizational resource not empowered      | Empowered central or organizational leader with senior management support |                                           |
| Energy Team                               | No company energy network                                      | Informal organization                                 | Active cross-functional team guiding energy program                       |                                           |
| Energy Policy                             | No formal policy                                               | Referenced in environmental or other policies         | Formal stand-alone EE policy endorsed by senior mgmt.                     |                                           |
| Assess Performance and Opportunities      | Assess Performance and Opportunities                           | Assess Performance and Opportunities                  | Assess Performance and Opportunities                                      | Assess Performance and Opportunities      |
| Gather and Track Data                     | Little metering/no tracking                                    | Local or partial metering/tracking/ reporting         | All facilities report for central consolidation/analysis                  |                                           |
| Normalize                                 | Not addressed                                                  | Some unit measures or weather adjustments             | All meaningful adjustments for organizational analysis                    |                                           |
| Establish baselines                       | No baselines                                                   | Various facility-established                          | Standardized organizational base year and metric established              |                                           |
| Benchmark                                 | Not addressed or only same site historical comparisons         | Some internal comparisons among company sites         | Regular internal & external comparisons & analyses                        |                                           |
| Analyze                                   | Not addressed                                                  | Some attempt to identify and correct spikes           | Profiles identifying trends, peaks, valleys & causes                      |                                           |
| Technical assessments and audits          | Not conducted                                                  | Internal facility reviews                             | Reviews by multi-functional team of professionals                         |                                           |
| Set Performance Goals                     | Set Performance Goals                                          | Set Performance Goals                                 | Set Performance Goals                                                     | Set Performance Goals                     |
| Determine scope                           | No quantifiable goals                                          | Short term facility goals or nominal corporate goals  | Short & long term facility and corporate goals                            |                                           |
| Estimate potential for improvement        | No process in place                                            | Specific projects based on limited vendor projections | Facility & organization defined based on experience                       |                                           |

| Establish goals                    | Not addressed                                        | Loosely defined or sporadically applied             | Specific & quantifiable at various organizational levels    |                        |
|------------------------------------|------------------------------------------------------|-----------------------------------------------------|-------------------------------------------------------------|------------------------|
| Create Action Plan                 | Create Action Plan                                   | Create Action Plan                                  | Create Action Plan                                          | Create Action Plan     |
| Define technical steps and targets | Not addressed                                        | Facility-level consideration as opportunities occur | Detailed multi-level targets with timelines to close gaps   |                        |
| Determine roles and resources      | Not addressed or done on ad hoc basis                | Informal interested person competes for funding     | Internal/external roles defined & funding identified        |                        |
| Implement Action Plan              | Implement Action Plan                                | Implement Action Plan                               | Implement Action Plan                                       | Implement Action Plan  |
| Create a communication plan        | Not addressed                                        | Tools targeted for some groups used occasionally    | All stakeholders are addressed on regular basis             |                        |
| Raise awareness                    | No promotion of energy efficiency                    | Periodic references to energy initiatives           | All levels of organization support energy goals             |                        |
| Build capacity                     | Indirect training only                               | Some training for key individuals                   | Broad training/certification in technology & best practices |                        |
| Motivate                           | No or occasional contact with energy users and staff | Threats for non- performance or periodic reminders  | Recognition, financial & performance incentives             |                        |
| Track and monitor                  | No system for monitoring progress                    | Annual reviews by facilities                        | Regular reviews & updates of centralized system             |                        |
| Evaluate Progress                  | Evaluate Progress                                    | Evaluate Progress                                   | Evaluate Progress                                           | Evaluate Progress      |
| Measure results                    | No reviews                                           | Historical comparisons                              | Compare usage & costs vs. goals, plans, competitors         |                        |
| Review action plan                 | No reviews                                           | Informal check on progress                          | Revise plan based on results, feedback & business factors   |                        |
| Recognize Achievements             | Recognize Achievements                               | Recognize Achievements                              | Recognize Achievements                                      | Recognize Achievements |
| Provide internal recognition       | Not addressed                                        | Identify successful projects                        | Acknowledge contributions of individuals, teams, facilities |                        |
| Get external recognition           | Not sought                                           | Incidental or vendor acknowledgement                | Government/third party highlighting achievements            |                        |

## ENERGY STAR ®  Facility Energy Management

## Assessment Matrix

| Company Name:                        | Assessment Date:                                                                             | Assessment Date:                                                                                        | Assessment Date:                                                                                                      |                                      |
|--------------------------------------|----------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|--------------------------------------|
|                                      | Little or no evidence                                                                        | Some elements/degree                                                                                    | Fully implemented                                                                                                     | Next Steps                           |
| Commit to Continuous Improvement     | Commit to Continuous Improvement                                                             | Commit to Continuous Improvement                                                                        | Commit to Continuous Improvement                                                                                      | Commit to Continuous Improvement     |
| Site Energy Leader                   | None assigned.                                                                               | Assigned responsibilities but not empowered. 20-40% of time is devoted to energy.                       | Recognized and empowered leader having site manager and senior energy manager support.                                |                                      |
| Site Energy Champion                 | None identified.                                                                             | Senior manager implicitly supports the energy program.                                                  | Senior manager actively supports the energy program and promotes energy efficiency in all aspects of site operations. |                                      |
| Site Energy Team                     | No site energy team.                                                                         | Informal organization with sporadic activity.                                                           | Active cross-functional team guiding site energy program.                                                             |                                      |
| Energy Policy                        | No energy policy or awareness of organizational policy.                                      | Organizational policy in place. Little awareness by site energy team and limited application of policy. | Organizational policy supported at site level. All employees aware of goals and responsibilities.                     |                                      |
| Site Energy Plan                     | No written plan.                                                                             | Informal plan not widely known.                                                                         | Written formal plan endorsed, distributed, and verified.                                                              |                                      |
| Accountability                       | No energy budgeting and accountability.                                                      | Estimates used for allocating energy budgets.                                                           | Key users are metered separately. Each entity has total accountability for their energy use.                          |                                      |
| Participation Levels                 | No reporting of energy performance data internally or involvement in external organizations. | Some participation, sharing, mentoring, and professional memberships. Annual reporting of performance.  | Participates in energy network/organizations. Shares best practices/mentors other sites. Reports usage quarterly.     |                                      |
| Assess Performance and Opportunities | Assess Performance and Opportunities                                                         | Assess Performance and Opportunities                                                                    | Assess Performance and Opportunities                                                                                  | Assess Performance and Opportunities |
| Track & Analyze Data                 | Limited metering or tracking. No demand analysis or billing evaluation.                      | Some metering, tracking, analyzing, and reporting. Energy bills verified for accuracy.                  | Key loads metered, tracked, analyzed, and reported. Facility peak demand analyzed. Adjusts for real-time demand.      |                                      |

| Documentation         | No manuals, plans, designs, drawings, specs, etc. for building and equipment available.   | Some documentation and records available. Some review of equipment commissioning specs conducted.            | Critical building and equipment documentation available and used for load surveys/recommissioning/efficienc y goals.       |                       |
|-----------------------|-------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|-----------------------|
|                       | Energy performance of systems and facilities not benchmarked.                             | Limited comparisons of specific functions, or only same-site historical comparisons.                         | Key systems/sites benchmarked using comparison tools like Portfolio Manager/Energy Performance Indicators.                 | Benchmarking          |
| Technical Assessments | No formal or external reviews.                                                            | Limited review by vendors, location, or organizational and corporate energy managers.                        | Extensive regular reviews by multi- functional team of internal and external professionals. Full assessment every 5 years. |                       |
| Best                  | None identified.                                                                          | Ad hoc or infrequent monitoring of trade journals, internal databases, and other facilities' best practices. | Regular monitoring of trade journals, internal databases, and other facilities. Best practices shared and implemented.     | Practices             |
| Set Performance Goals | Set Performance Goals                                                                     | Set Performance Goals                                                                                        | Set Performance Goals                                                                                                      | Set Performance Goals |
|                       | Energy reduction goals not established.                                                   | Loosely defined. Little awareness of energy goals by others outside of site energy team.                     | Potential defined by experience or assessments. Goals roll up to unit/site/ organization and status posted prominently.    | Goals/Potential       |
| Career Development    | No career development. No opportunities available.                                        | Exposure to other energy programs. Some temporary or project assignments available elsewhere.                | Energy professionals have established career paths that are reviewed annually. Opportunities for growth encouraged.        |                       |
| Energy Incentives     | No ties between energy efficiency improvement and compensation.                           | Spot awards or luncheons for employees on a project.                                                         | Accountability tied to performance reviews, compensation, and personal and plant bonuses.                                  | Team                  |
| Create Action Plan    | Create Action Plan                                                                        | Create Action Plan                                                                                           | Create Action Plan                                                                                                         | Create Action Plan    |
| Improvement Planning  | No upgrade plan.                                                                          | Upgrades implemented sporadically. Some compliance with organizational goals and standards.                  | Upgrade plans established; reflect assessments. Full compliance with organizational EE design guidelines and goals.        |                       |
| Roles and Resources   | Not addressed, or addressed on ad hoc basis only.                                         | Informal interested person competes for funding. Little support from organizational program.                 | Internal/external roles defined and funding identified. Organizational or corporate program support secured.               |                       |
| Site                  | Impact on energy from changes not considered.                                             | Decisions impacting energy considered on first-cost basis only.                                              | Projects/contracts include energy analysis. Energy projects evaluated with other investments. Lifecycle costing applied.   | Planning Integration  |

| Implement Action Plan      | Implement Action Plan                               | Implement Action Plan                                                                           | Implement Action Plan                                                                                                                    | Implement Action Plan   |
|----------------------------|-----------------------------------------------------|-------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|-------------------------|
| Communication              | Site plan not developed.                            | Periodic communications for projects. Some reporting of energy use information.                 | All stakeholders are addressed on regular basis.                                                                                         | Plan                    |
| Energy Awareness           | None conducted.                                     | Occasional energy efficiency awareness campaigns. Some communication of energy costs.           | Planned outreach and communications. Support organizational initiatives. Employees aware of site energy costs.                           |                         |
| Building Staff Capacity    | No training offered.                                | Some vendor training for key individuals and operators.                                         | Broad training/certification in technology and best practices. Networking opportunities actively pursued.                                |                         |
| Contract Management        | Contracts are renewed automatically without review. | Occasional review of supplier contracts.                                                        | Energy-efficient procurement policy in place. Vendors for replacements on standby. Regular review of suppliers.                          |                         |
| Incentives and Rebates     | Not researched or pursued.                          | Occasional communication with utility representatives. Limited knowledge of incentive programs. | Researches rebates and incentives offered regionally and nationally. Communicates often with utility representatives.                    |                         |
| Evaluate Progress          | Evaluate Progress                                   | Evaluate Progress                                                                               | Evaluate Progress                                                                                                                        | Evaluate Progress       |
| Measuring Results          | No reviews.                                         | Historical comparisons. Some reporting of results.                                              | Compare usage & costs vs. goals, plans, other sites. Results reported to site and organizational or corporate management.                |                         |
| Reviewing Action Plan      | No reviews.                                         | Informal check on progress.                                                                     | Revise plan based on results, feedback and business factors. Best practices shared with other sites / organization or corporate program. |                         |
| Recognize Achievements     | Recognize Achievements                              | Recognize Achievements                                                                          | Recognize Achievements                                                                                                                   | Recognize Achievements  |
| Site Recognition           | Not addressed.                                      | Occasional recognition of projects and people.                                                  | Recognition system in place. Awards for projects pursued by operators.                                                                   |                         |
| Organizational Recognition | Not sought.                                         | Occasionally when prompted by senior management.                                                | Senior management acknowledges site successes.                                                                                           |                         |
| External Recognition       | Not sought.                                         | Occasional trade magazine and vendor recognition.                                               | Government and third-party recognition highlighting achievements sought. ENERGY STAR awarded annually.                                   |                         |

## Appendix C: Teaming Up to Save Energy Checklist

The following checklist can be used as a handy reference to key tasks for establishing and sustaining  an  effective  energy  team.    For  more  detailed  information  on  energy  teams, consult the U.S. EPA's Teaming Up to Save Energy (U.S. EPA, 2006), and other resources available at www.energystar.gov/.

| ORGANIZE YOUR ENERGY TEAM    | ORGANIZE YOUR ENERGY TEAM                                                                                                                                                                                            |    |
|------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Energy Director              | Able to work with all staff levels from maintenance to engineers to financial officers. Senior-level person empowered by top management support                                                                      |     |
| Senior Management            | Energy director reports to senior executive or to a senior management council. Senior champion or council provides guidance and support                                                                              |     |
| Energy Team                  | Members from business units, operations/engineering, facilities, and regions. Energy networks formed. Support services (PR, IT, HR).                                                                                 |     |
| Facility Involvement         | Facility managers, electrical personnel. Two-way information flow on goals and opportunities. Facility-based energy teams with technical person as site champion.                                                    |     |
| Partner Involvement          | Consultants, vendors, customers, and joint venture partners. Energy savings passed on through lower prices.                                                                                                          |     |
| Energy Team Structure        | Separate division and/or centralized leadership. Integrated into organization's structure and networks established.                                                                                                  |     |
| Resources & Responsibilities | Energy projects incorporated into normal budget cycle as line item. Energy director is empowered to make decisions on projects affecting energy use. Energy team members have dedicated time for the energy program. |     |
| STARTING YOUR ENERGY TEAM    | STARTING YOUR ENERGY TEAM                                                                                                                                                                                            |    |
| Management                   | Senior management briefed on benefits, proposed approach, and                                                                                                                                                        |     |

| Briefing                 | potential energy team members.                                                                                                                                                          |    |
|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----|
| Planning                 | Energy team met initially to prepare for official launch.                                                                                                                               |    |
| Strategy                 | Energy team met initially to prepare for official launch.                                                                                                                               |    |
| Program Launch           | Organizational kickoff announced energy network, introduced energy director, unveiled energy policy, and showcased real- world proof.                                                   |    |
| Energy Team Plans        | Work plans, responsibilities, and annual action plan established.                                                                                                                       |    |
| Facility Engagement      | Facility audits and reports conducted. Energy efficiency opportunities identified.                                                                                                      |    |
| BUILDING CAPACITY        | BUILDING CAPACITY                                                                                                                                                                       |   |
| Tracking and Monitoring  | Systems established for tracking energy performance and best practices implementation.                                                                                                  |    |
| Transferring Knowledge   | Events for informal knowledge transfer, such as energy summits and energy fairs, implemented.                                                                                           |    |
| Raising Awareness        | Awareness of energy efficiency created through posters, intranet, surveys, and competitions.                                                                                            |    |
| Formal Training          | Participants identified, needs determined, training held. Involvement in ENERGY STAR Web conferences and meetings encouraged. Professional development objectives for key team members. |    |
| Outsourcing              | Use of outside help has been evaluated and policies established.                                                                                                                        |    |
| Cross-Company Networking | Outside company successes sought and internal successes shared. Information exchanged to learn from experiences of others.                                                              |    |
| SUSTAINING THE TEAM      | SUSTAINING THE TEAM                                                                                                                                                                     |   |
| Effective Communications | Awareness of energy efficiency created throughout company. Energy performance information is published in company reports and communications.                                           |    |
| Recognition and          | Internal awards created and implemented. Senior management is                                                                                                                           |    |

<!-- image -->

| Rewards              | involved in providing recognition.                                                                                                               |    |
|----------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|----|
| External Recognition | Credibility for your organization's energy program achieved. Awards from other organizations have added to your company's competitive advantage. |    |
| MAINTAINING MOMENTUM | MAINTAINING MOMENTUM                                                                                                                             |   |
| Succession           | Built-in plan for continuity established. Energy efficiency integrated into organizational culture.                                              |    |
| Measures of Success  | Sustainability of program and personnel achieved. Continuous improvement of your organization's energy performance attained.                     |    |

## Appendix D: Support Programs for Industrial Energy Efficiency Improvement

This  appendix  provides  a  list  of  energy  efficiency  support  available  to  industry.  A  brief description of the program or tool is given, as well as information on its target audience and the URL for the program.  Included are federal and state programs. Use the URL to obtain more information from each of these sources. An attempt was made to provide as complete a list as possible; however, information in this listing may change with the passage of time.

## Tools for Self-Assessment

## Steam System Assessment Tool

Description:

Software  package  to  evaluate  energy  efficiency  improvement  projects  for steam systems. It includes an economic analysis capability.

Target Group: Any industry operating a steam system

Format:

Downloadable software package (13.6 MB)

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/manufacturing/tech\_deployment/software\_ssat.html

## Steam System Scoping Tool

Description:

Spreadsheet tool for plant managers to identify energy efficiency opportunities in industrial steam systems.

Target Group: Any industrial steam system operator

Format:

Downloadable software (Excel)

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/manufacturing/tech\_deployment/software\_ssat.html

## 3E Plus ® : Insulation Thickness Computer Program

Description:

Downloadable software to determine whether boiler systems can be optimized through the insulation of boiler steam lines. The program calculates the most economical thickness of industrial insulation for a variety

of  operating  conditions.  It  makes  calculations  using  thermal  performance relationships of generic insulation materials included in the software.

Target Group: Energy and plant managers

Format:

Downloadable software

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/manufacturing/tech\_deployment/software\_ssat.html

## MotorMaster+

Description:

Energy efficient motor selection and management tool, including a catalog of over  20,000  AC  motors.  It  contains  motor  inventory  management  tools, maintenance  log  tracking,  efficiency  analysis,  savings  evaluation,  energy accounting, and environmental reporting capabilities.

Target Group: Any industry

Format:

Downloadable software (can also be ordered on CD)

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/manufacturing/tech\_deployment/software\_motormaster.html

## The 1-2-3 Approach to Motor Management

Description:

A step-by-step motor management guide and spreadsheet tool that can help motor service centers, vendors, utilities, energy-efficiency organizations, and others convey the financial benefits of sound motor management.

Target Group: Any industry

Format:

Downloadable Microsoft Excel spreadsheet

Contact:

Consortium for Energy Efficiency (CEE), (617) 589-3949

URL:

http://www.motorsmatter.org/tools/123approach.html

## AirMaster+: Compressed Air System Assessment and Analysis Software

Description:

Modeling tool that maximizes the efficiency and performance of compressed air systems through improved operations and maintenance practices.

Target Group: Any industry operating a compressed air system

Format:

Downloadable software

Contact:

U.S. Department of Energy

URL:               http://www1.eere.energy.gov/manufacturing/tech\_deployment/software\_airmaster.html

## Fan System Assessment Tool (FSAT)

Description:

The  Fan  System  Assessment  Tool  (FSAT)  helps  to  quantify  the  potential benefits of optimizing a fan system. FSAT calculates the amount of energy used  by  a  fan  system,  determines  system  efficiency,  and  quantifies  the savings potential of an upgraded system.

Target Group: Any user of fans

Format:

Downloadable software

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/manufacturing/tech\_deployment/software\_fsat.html

## Combined Heat and Power Application tool (CHP)

Description:

The Combined Heat and Power Application Tool (CHP) helps industrial users evaluate  the  feasibility  of CHP  for  heating  systems  such  as  fuel-fired furnaces, boilers, ovens, heaters, and heat exchangers.

Target Group: Any industrial heat and electricity user

Format:

Downloadable software

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/manufacturing/tech\_deployment/software\_chp.html

## Pumping System Assessment Tool (PSAT)

Description:

The  tool  helps  industrial  users  assess  the  efficiency  of  pumping  system operations.  PSAT  uses  achievable  pump  performance  data  from  Hydraulic Institute  standards  and  motor  performance  data  from  the  MotorMaster+ database to calculate potential energy and associated cost savings.

Target Group: Any industrial pump user

Format:

Downloadable software

## Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/manufacturing/tech\_deployment/software\_psat.html

## Plant Energy Profiler/Integrated Tool Suite

Description:

The Plant Energy Profiler, or ePEP (formerly called  Quick PEP), is an online software tool  provided  by  the  U.S.  Department  of  Energy  to  help  industrial plant managers in the United States identify how energy is being purchased and  consumed  at  their  plant  and  also  identify  potential  energy  and  cost savings. ePEP is designed so that the user can complete a plant profile in about  an  hour.  The  ePEP  online  tutorial  explains  what  plant  information  is needed to complete an ePEP case.

Target Group: Any industrial plant

Format:

Online software tool

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/manufacturing/tech\_assistance/printable\_versions/software\_epep.html

## ENERGY STAR Portfolio Manager

Description:

Online software tool helps to assess the energy performance of buildings by providing a 1-100 ranking of a building's energy performance relative to the national building market. Measured energy consumption forms the basis of the ranking of performance.

Target Group: Any building user or owner

Format:

Online software tool

Contact:

U.S. Environmental Protection Agency

URL:

http://www.energystar.gov/index.cfm?c=evaluate\_performance.bus\_portfoliomanager

## Assessment and Technical Assistance

## Industrial Assessment Centers

Description:

Small- to medium-sized manufacturing facilities can obtain a free energy and waste assessment. The audit is performed by a team of engineering faculty

and students from 30 participating universities in the U.S. and assesses the plant's performance and recommends ways to improve efficiency.

Target Group: Small-  to  medium-sized  manufacturing  facilities  with  gross  annual  sales below $75 million and fewer than 500 employees at the plant site.

Format:

A team of engineering faculty and students visits the plant and prepares a written report with energy  efficiency, waste  reduction and  productivity recommendations.

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/industry/bestpractices/iacs.html

## Energy Assessments

Description:

The  U.S.  DOE  conducts  plant  energy  assessments  to  help  manufacturing facilities  across  the  nation  identify  immediate  opportunities  to  save  energy and  money,  primarily  by  focusing  on  energy-intensive  systems,  including process heating, steam, pumps, fans, and compressed air.

Target Group: Large plants

Format:

Online request

Contact:

U.S. Department of Energy

URL:               http://www1.eere.energy.gov/manufacturing/tech\_deployment/energy\_assessment.html

## Better Building, Better Plants (BBBP)

Description:

The Better Building, Better Plants program is a national partnership initiative to  drive  a  25%  reduction  in  industrial  energy  intensity  in  10  years  while decreasing carbon emissions and enhancing U.S. competitiveness. Leaders of industrial companies are invited to take a corporate-wide voluntary Pledge to reduce the energy intensity of their industrial operations by 25% or more in 10 years. Companies in partnership with the U.S. DOE, will work to improve energy management and identify the most cost-effective options for energy and carbon savings.

Target Group: Building and industry

Contact:

U.S. Department of Energy

URL:                http://www4.eere.energy.gov/challenge/home

## Manufacturing Extension Partnership (MEP)

Description:

MEP is a nationwide network of not-for-profit centers in over 400 locations providing small- and medium-sized manufacturers with technical assistance. A  center  provides  expertise  and  services  tailored  to  the  plant,  including  a focus on clean production and energy-efficient technology.

Target Group: Small- and medium-sized plants

Format:

Direct contact with local MEP Office

Contact:

National Institute of Standards and Technology, (301) 975-5020

URL:

http://www.nist.gov/mep/

## Small Business Development Center (SBDC)

Description:

The U.S Small Business Administration (SBA) administers the Small Business Development Center Program to provide management assistance to small businesses through 58 local centers. The SBDC Program provides counseling,  training  and  technical  assistance  in  the  areas  of  financial, marketing, production, organization, engineering and technical problems and feasibility studies, if a small business cannot afford consultants.

Target Group: Small businesses

Format:

Direct contact with local SBDC

Contact:

Small Business Administration, (800) 8-ASK-SBA

URL:

http://www.sba.gov/sbdc/

## ENERGY  STAR  -  Selection  and  Procurement  of  Energy-Efficient  Products  for Business

Description:

ENERGY STAR identifies and labels energy-efficient office equipment.  Look for products that have earned the ENERGY STAR. They meet strict energy efficiency guidelines set by the EPA. Office equipment included such items as computers,  copiers,  faxes, monitors, multifunction devices, printers, scanners, transformers and water coolers.

Target Group: Any user of labeled equipment.

Format:

Website

Contact:

U.S. Environmental Protection Agency

URL:

http://www.energystar.gov/index.cfm?c=bulk\_purchasing.bus\_purchasing

## Training

## ENERGY STAR

Description:

As part of ENERGY STAR's work to promote superior energy management systems,  energy  managers  for  the  companies  that  participate  in  ENERGY STAR are offered the opportunity to network with other energy managers in the partnership. The networking meetings are held monthly and focus on a specific  strategic  energy  management  topic  to  train  and  strengthen  energy managers  in  the  development  and  implementation  of  corporate  energy management programs.

Target Group: Corporate and plant energy managers

Format:

Web-based teleconference

Contact:

Climate  Protection  Partnerships  Division,  U.S.  Environmental  Protection Agency

URL:

http://www.energystar.gov/

## Workforce Development and Training

Description:

The U.S. DOE  provides training and training materials to support the efforts of the program in efficiency improvement of utilities (compressed air, steam) and  motor  systems  (including  pumps).  Training  is  provided  regularly  in different  regions.  One-day  or  multi-day  trainings  are  provided  for  specific elements  of  the  above  systems.  The  U.S.  DOE  also  provides  training  on other industrial energy equipment, often in coordination with conferences.

Target Group: Technical support staff, energy and plant managers

Format:

Various training workshops (one day and multi-day workshops)

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/industry/bestpractices/training.html

## Compressed Air Challenge ®

Description:

The not-for-profit Compressed Air Challenge ®  develops and provides training on  compressed  air  system  energy  efficiency  via  a  network  of  sponsoring organizations in the United States and Canada. Three levels of training are available: (1) Fundamentals (1 day); (2) Advanced (2 days); and (3) Qualified Specialist (3-1/2 days  plus  an  exam).  Training  is  oriented  to  support implementation of an action plan at an industrial facility.

Target Group: Compressed air system managers, plant engineers

Format:

Training workshops

Contact:

Compressed Air Challenge: Info@compressedairchallenge.org

URL:

http://www.compressedairchallenge.org/

## Financial Assistance

Below major federal programs are summarized that provide assistance for energy efficiency investments.  Many  states  also  offer  funds  or  tax  benefits  to  assist  with  energy  efficiency projects (see below for State Programs). However, these programs can change over time, so  it  is  recommended  to  review  current  policies  when  making  any  financial  investment decisions.

## Energy Efficiency and Renewable Energy (EERE) Financial Opportunities

Description:

The Office of EERE works with business, industry, universities, and others to increase  the  use  of  renewable  energy  and  energy  efficiency  technologies. One way EERE encourages the growth of these technologies is by offering financial assistance opportunities for their development and demonstration.

Target Group: Business,

industry, universities, consumers, federal energy managers, inventors, and states.

Format:

Solicitations

Contact:

U.S. Department of Energy

URL:

http://www1.eere.energy.gov/financing/business.html

## Small Business Administration (SBA)

Description:

The Small Business Administration provides several loan and loan guarantee programs for investments (including energy-efficient process technology) for small businesses.

Target Group: Small businesses

Format:

Direct contact with SBA

Contact:

Small Business Administration

URL:

http://www.sba.gov/

## State and Local Programs

Many  state  and  local  governments  have  general  industry  and  business  development programs that can be used to assist businesses in assessing or financing energy-efficient process  technology  or  buildings.  Please  contact  your  state  and  local  government  to determine what tax benefits, funding grants, or other assistance they may be able to provide your organization. This list should not be considered comprehensive but instead merely a short list  of  places  to start  in  the  search  for  project  funding.  These  programs can change over  time,  so  it  is  recommended  to  review  current  policies  when  making  any  financial investment decisions.

## Database of State Incentives for Renewables &amp; Efficiency (DSIRE)

Description:

DSIRE is a comprehensive source of information on state, local, utility, and federal  incentives  and  policies  that  promote  renewable  energy  and  energy efficiency. Established in 1995, DSIRE is an ongoing project of the NC Solar Center  and  the  Interstate  Renewable  Energy  Council  funded  by  the  U.S. Department of Energy.

Target Group: Any industry

URL:

http://www.dsireusa.org/

## Summary of Motor and Drive Efficiency Programs by State

Description:

A report that provides an overview of state-level programs that support the use of NEMA Premium ®  motors, ASDs, motor management services, system optimization and other energy management strategies.

## Target Group: Any industry

Contact:

Consortium for Energy Efficiency (CEE), (617) 589-3949

URL:

http://www.cee1.org/ind/programsummary/index.php

## California - Public Interest Energy Research (PIER)

Description:

PIER  provides  funding  for  energy  efficiency,  environmental  and  renewable energy  projects  in  the  state  of  California.  Although  there  is  a  focus  on electricity, fossil fuel projects are also eligible.

Target Group: Targeted industries (e.g. food industries) located in California

Format:

Solicitation

Contact:

California Energy Commission, (916) 654-4637

URL:

http://www.energy.ca.gov/contracts/index.html

## California - Energy Innovations Small Grant Program (EISG)

Description:

EISG provides small grants for development of innovative energy technologies in California. Grants are limited to $95,000.

Target Group: All businesses in California

Format:

Solicitation

Contact:

California Energy Commission, (619) 594-1049

URL:

http://www.energy.ca.gov/research/innovations/index.html

## California - Savings By Design

Description:

Design assistance is available to building owners and to their design teams for  energy-efficient  building  design.  Financial  incentives  are  available  to owners when the efficiency of the new building exceeds minimum thresholds, generally  10%  better  than  California's  Title  24  standards.  The  maximum owner  incentive  is  $150,000  per  free-standing  building  or  individual  meter. Design  team  incentives  are  offered  when  a  building  design  saves  at  least 15%. The maximum design team incentive per project is $50,000.

Target Group: Nonresidential new construction or major renovation projects

Format:

Open year round

URL:

http://www.savingsbydesign.com/

## Iowa - Alternate Energy Revolving Loan Program

Description:

The  Alternate  Energy  Revolving  Loan  Program  (AERLP)  was  created  to promote  the  development  of  renewable  energy  production  facilities  in  the state.

Target Group: Any potential user of renewable energy

Format:

The Energy Center provides loan funds equal to 50% of the total financed cost of a project (up to $1 million) at 0% interest. Proposals under $50,000 are  accepted  year-round.  Larger  proposals  are  accepted  on  a  quarterly basis.

Contact:

Iowa Energy Center, (515) 294-3832

URL:

http://www.iowaenergycenter.org/alternate-energy-revolving-loan-program- aerlp/

## New York - Industry Research and Development Programs

Description:

The New York State Energy Research &amp; Development Agency (NYSERDA) operates  various  financial  assistance  programs  for  New  York  businesses. Different  programs  focus  on  specific  topics,  including  process  technology, combined heat and power, peak load reduction and control systems.

Target Group: Industries located in New York

Format:

Solicitation

Contact:

NYSERDA, (866) NYSERDA

URL:

http://www.nyserda.ny.gov/en/Funding-Opportunities.aspx

## Oregon - Energy Trust Production Efficiency Program

Description:

Incentives for  energy  efficiency  projects  are  offered  for  Oregon  businesses that  are  serviced  by  either  Pacific  Power  or  Portland  General  Electric. Current incentive levels are $0.25/kWh saved up to 60% of the project cost. Lighting incentives are treated differently. There are standard incentive levels for  specific  fixture  replacements  (exp.  $30/fixture).  If  a  fixture  replacement

does not qualify for a standard incentive, but it does save energy, a custom incentive can be calculated using $0.17/kWh saved up to 35% of the project cost. Premium efficiency motor rebates are also offered at $10/hp from 1 to 200 hp motors. Over 200 hp, the current incentive levels of $0.25/kWh saved up to 60% of the project cost are used to calculate an incentive.

Target Group: Commercial and industrial companies in Oregon

Contact:

Energy Trust of Oregon

URL:

http://energytrust.org/industrial-and-ag/

## Wisconsin - Focus on Energy

Description:

Energy  advisors  offer  free  services  to  identify  and  evaluate  energy-saving opportunities,  recommend  energy  efficiency  actions,  develop  an  energy management  plan  for  business;  and  integrate  elements  from  national  and state programs. It can also provide training.

Target Group: Industries in Wisconsin

Format:

Open year round

Contact:

Wisconsin Department of Administration, (800) 762-7077

URL:

http://www.focusonenergy.com/