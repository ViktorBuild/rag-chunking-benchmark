---
document_id: doe_pump_sourcebook
title: "Improving Pumping System Performance: A Sourcebook for Industry"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_pumping_system_sourcebook.pdf"
tables_detected: 11
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

<!-- image -->

<!-- image -->

## Acknowledgements

This second edition of Improving Pumping System Performance: A Sourcebook for Industry was developed by the U.S. Department of Energy's Industrial Technologies Program (ITP) and the Hydraulic Institute (HI). ITP undertook this project as part of a series of sourcebook publications on industrial equipment. Other topics in this series include compressed air systems, fan and blower systems, motors and drives, steam systems, and process heating systems. For more information about ITP and HI, see Section 4, 'Where to Find Help.'

The Department of Energy, Lawrence Berkeley National Laboratory, the Alliance to Save Energy, and Resource Dynamics Corporation wish to thank staff at the many organizations that so generously assisted in the collection of data for this sourcebook. In addition, we would like to particularly recognize the following for their input and reviews of the first and second editions of this sourcebook:

Stefan M. Abelin, ITT Flygt Corporation

Robert Asdal, Hydraulic Institute

William Beekman, Floway Pumps

Heinz Block, P.E., Process Machinery Consulting

Steve Bolles, Process Energy Services

Karl Buscher, ITT Fluid Handling - Bell &amp; Gossett

Don Casada, Diagnostic Solutions, LLC

Mick Cropper, Sulzer Pumps U.S. Inc.

Barry Erickson, Flowserve Corp.

Gunnar Hovstadius, Gunnar Hovstadius Consulting, LLC

Al Iseppon, Pentair Water

Steve Kratzke

Ross C. Mackay, Ross Mackay Associates Ltd.

William Marscher, Mechanical Solutions, Inc.

J. P. Messina, P.E.

Michael Pemberton, ITT IPG PumpSmart Control Solutions

Gregg Romanyshyn, Hydraulic Institute

Arnold Sdano, Fairbanks Morse Pump Company

Michael W. Volk, Volk Associates, Inc.

Trey Walters, Applied Flow Technology

Second Edition, May 2006

Prepared for the United States Department of Energy Office of Energy Efficiency and Renewable Energy Industrial Technologies Program

By

Lawrence Berkeley National Laboratory Berkeley, California

Resource Dynamics Corporation Vienna, Virginia

Alliance to Save Energy Washington, D.C.

In cooperation with the Hydraulic Institute Parsippany, New Jersey

Produced by the National Renewable Energy Laboratory

Golden, Colorado

Cover photo credit:  Diagnostic Solutions, LLC, and Blacksburg, Christiansburg, VPI Water Authority, NREL/PIX13296

## Contents

| Acknowledgements                                                                         | inside cover     |
|------------------------------------------------------------------------------------------|------------------|
| Table of Contents                                                                        | i                |
| List of Figures                                                                          | ii               |
| Quick Start Guide                                                                        | 1                |
| Section 1: Pumping System Basics                                                         | 3                |
| Overview                                                                                 | 3                |
| Pumping System Components                                                                | 3                |
| Pumping System Principles                                                                | 6                |
| Section 2: Performance Improvement Opportunity Roadmap                                   | 11               |
| Overview                                                                                 | 11               |
| The Fact Sheets                                                                          | 11               |
| Assessing Pumping System Needs                                                           | 13               |
| Common Pumping System Problems                                                           | 19               |
| Indications of Oversized Pumps                                                           | 25               |
| Piping Configurations to Improve Pumping System Efficiency                               | 29               |
| Basic Pump Maintenance                                                                   | 33               |
| Centrifugal Pumps                                                                        | 37               |
| Positive Displacement Pump Applications                                                  | 41               |
| Multiple Pump Arrangements                                                               | 43               |
| Pony Pumps                                                                               | 47               |
| Impeller Trimming                                                                        | 49               |
| Controlling Pumps with Adjustable Speed Drives                                           | 51               |
| Section 3: The Economics of Improving Pumping Systems                                    | 55               |
| Overview                                                                                 | 55               |
| Conduct a Systems Assessment                                                             | 55               |
| Analyze Life-Cycle Costs Before Making a Decision                                        | 62               |
| Sell Your Projects to Management                                                         | 64               |
| Section 4: Where to Find Help                                                            | 69               |
| Overview DOE Industrial                                                                  | 69               |
|                                                                                          | BestPractices 69 |
| Hydraulic Institute                                                                      | 73               |
| Directory of Contacts                                                                    | 75               |
| Resources and Tools                                                                      | 76               |
|                                                                                          | 93               |
| Appendices Appendix A: Glossary                                                          | 95               |
| Appendix B: Pumping System Assessment Tool (PSAT) Appendix C: Pumping Systems Tip Sheets | 99               |
| Appendix D: Guidelines for Comments                                                      | 101              |
|                                                                                          | 117              |

## List of Figures

91

| Figure 1.   | Typical Pumping System Components                                  |   4 |
|-------------|--------------------------------------------------------------------|-----|
| Figure 2.   | Key to the Fact Sheets                                             |  12 |
| Figure 3.   | Illustration of the Sensitivity of Flow to Changes in Backpressure |  15 |
| Figure 4.   | Drooping Performance Curve                                         |  15 |
| Figure 5.   | Cavitation in a Centrifugal Pump                                   |  20 |
| Figure 6.   | Two Types of Sealing Methods: Packing and Mechanical Seals         |  21 |
| Figure 7.   | Common Pipe Configuration Problems and How To Correct Them         |  30 |
| Figure 8.   | Flow Straighteners                                                 |  31 |
| Figure 9.   | Proper Support of Suction and Discharge Piping                     |  31 |
| Figure 10.  | Centrifugal Pump Performance Curves                                |  37 |
| Figure 11.  | Family of Pump Performance Curves                                  |  38 |
| Figure 12.  | Performance Curves for Different Impeller Sizes                    |  38 |
| Figure 13.  | Performance Curves for a 4x1.5-6 Pump Used for Water Service       |  39 |
| Figure 14.  | Multiple Pump Operation                                            |  44 |
| Figure 15.  | Multiple-Speed Pump Performance Curves                             |  45 |
| Figure 16.  | Typical Tank Level Control                                         |  48 |
| Figure 17.  | Effect of Impeller Trimming on Pump Performance                    |  49 |
| Figure 18.  | Effects of Reducing Speed on a Pump's Operating Characteristics    |  52 |
| Figure 19.  | Power Lost through a Bypass Line                                   |  52 |
| Figure 20.  | Fluid Power Lost across a Throttle Valve                           |  52 |
| Figure 21.  | Using a Pump Performance Curve To Determine Power Draw             |  60 |

## Quick Start Guide

This sourcebook is designed to provide pumping system users with a reference that outlines opportunities for improving system performance. It is not meant to be a comprehensive technical text on pumping systems; rather, it provides practical guidelines and information to make users aware of potential performance improvements. Guidance on how to find more information and assistance is also included.

Throughout this sourcebook, performance and efficiency improvements are described in terms of a 'systems approach.' For cost-effective operation and maintenance of pumping systems, attention must be paid not just to individual pieces of equipment but to the system as a whole. A systems approach to optimizing a pumping system analyzes both the supply and demand sides of the system and how they interact, shifting the focus from individual components to total system performance.

Often, operators are so focused on the immediate demands of equipment that they overlook the broader question:  How do the system's parameters affect this equipment? For example, frequently replacing pump seals and bearings can keep a maintenance crew so busy that they overlook the system operating conditions that are causing most (or all) of the problems.

A systems approach involves the following types of interrelated actions:

- ■ Establish current conditions and operating parameters
- ■ Determine present and estimate future process production needs
- ■ Gather and analyze operating data and develop load duty cycles
- ■ Assess alternative system designs and improvements
- ■ Determine the most technically and economically sound options, taking into consideration all of the subsystems
- ■ Implement the best option
- ■ Assess energy consumption with respect to performance
- ■ Continue to monitor and optimize the system
- ■ Continue to operate and maintain the system for peak performance.

To use a systems approach effectively, a pumping system designer needs to understand system fundamentals, know where opportunities for improvements are commonly found, and have a list of key resources that can help to identify and implement successful projects. Therefore, this sourcebook is divided into four main sections, as outlined below.

##  Section 1. Pumping System Basics

If you are not familiar with the basics of pumping systems, the first section provides a brief discussion of terms, relationships, and important system design considerations. It describes key factors involved in pump selection and system design; it also provides an overview of different types of pumps and their general applications. Key terms and parameters used in selecting pumps, designing systems, and controlling fluid flow are discussed. If you are already familiar with pumping systems, you might want to skip this section and go straight to the next one.

##  Section 2. Performance Improvement Opportunity Roadmap

This section describes the key components of a pumping system and opportunities to improve the system's performance. Also provided is a figurative system diagram identifying pumping system components and performance improvement opportunities. A set of fact sheets describing

these opportunities in greater detail follows the diagram; they discuss the following:

- 1. Assessing Pumping System Needs
- 2. Common Pumping System Problems
- 3. Indications of Oversized Pumps
- 4. Piping Configurations to Improve Pumping System Efficiency
- 5. Basic Pump Maintenance
- 6. Centrifugal Pumps
- 7. Positive Displacement Pump Applications
- 8. Multiple Pump Arrangements
- 9. Pony Pumps
- 10. Impeller Trimming
- 11. Controlling Pumps with Adjustable Speed Drives

##  Section 3. The Economics of Improving Pumping Systems

Section 3 describes key considerations in determining the life-cycle costs of pumping systems. Understanding life-cycle costs is essential to identifying and prioritizing improvement projects and presenting these projects in terms that will gain management support. Therefore, this section discusses life-cycle cost components, ways to measure these costs, and key success factors in prioritizing and proposing improvement projects.

##  Section 4. Where To Find Help

Section 4 describes useful sources of assistance that can help you learn more about pumping systems and ways to improve their performance and efficiency. Included in this section are descriptions of resources within the U.S. Department of Energy (DOE) Industrial Technologies Program (ITP) and the Hydraulic Institute and a directory of associations and other organizations involved in the pump marketplace. This section also provides lists of helpful resources, such as tools, software, videos, and workshops.

##  Appendices

This sourcebook on improving pumping systems includes four appendices. Appendix A is a glossary of terms used throughout the pumping system industry (and printed in bold type in parts of this sourcebook). Appendix B describes the Pumping System Assessment Tool (PSAT), which can help you identify and prioritize energy improvement projects for pumping systems. Appendix C contains a series of pumping system tip sheets. Developed by DOE, these tip sheets are brief summaries of opportunities for improving the efficiency and performance of pumping systems. Appendix D includes a form for submitting suggested improvements to this sourcebook.

## Section 1:  Pumping System Basics

## Overview

Pumps are used widely in industry to provide cooling and lubrication services, to transfer fluids for processing, and to provide the motive force in hydraulic systems. In fact, most manufacturing plants, commercial buildings, and municipalities rely on pumping systems for their daily operation. In the manufacturing sector, pumps represent 27% of the electricity used by industrial systems. In the commercial sector, pumps are used primarily in heating, ventilation, and air-conditioning (HVAC) systems to provide water for heat transfer. Municipalities use pumps for water and wastewater transfer and treatment and for land drainage. Since they serve such diverse needs, pumps range in size from fractions of a horsepower to several thousand horsepower.

In addition to an extensive range of sizes, pumps also come in several different types. They are classified by the way they add energy to a fluid: positive displacement pumps 1 squeeze the fluid directly; centrifugal pumps (also called 'rotodynamic pumps') speed up the fluid and convert this kinetic energy to pressure. Within these classifications are many different subcategories. Positive displacement pumps include piston, screw, sliding vane, and rotary lobe types; centrifugal pumps include axial (propeller), mixed-flow, and radial types. Many factors go into determining which type of pump is suitable for an application. Often, several different types meet the same service requirements.

Pump reliability is important-often critically so. In cooling systems, pump failure can result in equipment overheating and catastrophic damage. In lubrication systems, inadequate pump performance can destroy equipment. In many petrochemical and power plants, pump downtime can cause a substantial loss in productivity.

1 Terms in bold type are defined in the glossary in Appendix A.

Pumps are essential to the daily operation of many facilities. This tends to promote the practice of sizing pumps conservatively to ensure that the needs of the system will be met under all conditions. Intent on ensuring that the pumps are large enough to meet system needs, engineers often overlook the cost of oversizing pumps and err on the side of safety by adding more pump capacity. Unfortunately, this practice results in higher-than-necessary system operating and maintenance costs. In addition, oversized pumps typically require more frequent maintenance than properly sized pumps. Excess flow energy increases the wear and tear on system components, resulting in valve damage, piping stress, and excess system operation noise.

## Pumping System Components

Typical pumping systems contain five basic components: pumps, prime movers, piping, valves, and end-use equipment (e.g., heat exchangers, tanks, and hydraulic equipment). A typical pumping system and its components are illustrated in Figure 1 on page 4.

##  Pumps

Although pumps are available in a wide range of types, sizes, and materials, they can be broadly classified into the two categories described earlier-positive displacement and centrifugal. These categories relate to the manner in which the pumps add energy to the working fluid. Positive displacement pumps pressurize fluid with a collapsing volume action, essentially squeezing an amount of fluid equal to the displacement volume of the system with each piston stroke or shaft rotation. Centrifugal pumps work by adding kinetic energy to a fluid using a spinning impeller . As the fluid slows in the diffuser section of the pump, the kinetic energy of the fluid is converted into pressure.

Figure 1. Typical Pumping System Components

<!-- image -->

Although many applications can be served by both positive displacement and centrifugal pumps, centrifugal pumps are more common because they are simple and safe to operate, require minimal maintenance, and have characteristically long operating lives. Centrifugal pumps typically suffer less wear and require fewer part replacements than positive displacement pumps. Although the packing or mechanical seals must be replaced periodically, these tasks usually require only a minor amount of downtime. Centrifugal pumps can also operate under a broad range of conditions. The risk of catastrophic damage due to improper valve positioning is low, if precautions are taken.

Centrifugal pumps have a variable flow/pressure relationship. A centrifugal pump acting against a high system pressure generates less flow than it does when acting against a low system pressure.

A centrifugal pump's flow/pressure relationship is described by a performance curve that plots the flow rate as a function of head (pressure). Understanding this relationship is essential to properly sizing a pump and designing a system that performs efficiently. For more information, see the fact sheet in Section 2 titled Centrifugal Pumps.

In contrast, positive displacement pumps have a fixed displacement volume. Consequently, the flow rates they generate are directly proportional to their speed. The pressures they generate are determined by the system's resistance to this flow. Positive displacement pumps have operating advantages that make them more practical for certain applications. These pumps are typically more appropriate for situations in which the following apply:

A

- ■ The working fluid is highly viscous
- ■ The system requires high-pressure, low-flow pump performance
- ■ The pump must be self-priming
- ■ The working fluid must not experience high shear forces
- ■ The flow must be metered or precisely controlled
- ■ Pump efficiency is highly valued.

A disadvantage is that positive displacement pumps typically require more system safeguards, such as relief valves. A positive displacement pump can potentially overpressurize system piping and components. For example, if all the valves downstream of a pump are closed-a condition known as deadheading -system pressure will build until a relief valve lifts, a pipe or fitting ruptures, or the pump motor stalls. Although relief valves are installed to protect against such damage, relying on these devices adds an element of risk. In addition, relief valves often relieve pressure by venting system fluid, which may be a problem for systems with harmful or dangerous system fluids. For more information on this type of pump, see the fact sheet in Section 2 titled Positive Displacement Pump Applications.

##  Prime Movers

Most pumps are driven by electric motors. Although some pumps are driven by direct current (dc) motors, the low cost and high reliability of alternating current (ac) motors make them the most common type of pump prime mover. In recent years, partly as a result of DOE's efforts, the efficiencies of many types of ac motors have improved. A section of the Energy Policy Act (EPAct) of 1992 that set minimum efficiency standards for most common types of industrial motors went into effect in October 1997. EP Act has provided industrial end users with greater selection and availability of energy-efficient motors.

In addition, the National Electrical Manufacturers Association (NEMA) has established the NEMA Premium TM energy efficiency motors program, which is endorsed by the Hydraulic Institute; the program defines premium efficiency motors with higher efficiency levels than those established by EPAct. In high-run-time applications, improved motor efficiencies can significantly reduce operating costs. However, it is often more effective to take a systems approach that uses proper component sizing and effective maintenance practices to avoid unnecessary energy consumption.

A subcomponent of a pump motor is the motor controller. The motor controller is the switchgear that receives signals from low-power circuits, such as an on-off switch, and connects or disconnects the high-power circuits to the primary power supply from the motor. In dc motors, the motor controller also contains a sequence of switches that gradually builds up the motor current during start-ups.

In special applications, such as emergency lubricating oil pumps for large machinery, some pumps are driven by an air system or directly from the shaft of the machine. In the event of a power failure, these pumps can still supply oil to the bearings long enough for the machine to coast to a stop. For this same reason, many fire service pumps are driven by diesel engines to allow them to operate during a power outage.

##  Piping

Piping is used to contain the fluid and carry it from the pump to the point of use. The critical aspects of piping are its dimensions, material type, and cost. Since all three aspects are interrelated, pipe sizing is an iterative process. The flow resistance at a specified flow rate of a pipe decreases as the pipe diameter gets larger; however, larger pipes are heavier, take up more floor space, and cost more than smaller pipe. Similarly, in systems that operate at high pressures (for example, hydraulic systems), small-diameter pipes can have thinner walls than large-diameter pipes and are easier to route and install.

Small-diameter pipes restrict flow, however, and this can be especially problematic in systems with

surging flow characteristics. Smaller pipes also operate at higher liquid velocity, increasing erosion effects, wear, and friction head. Increased friction head affects the energy required for pumping.

##  Valves

The flow in a pumping system may be controlled by valves . Some valves have distinct positions, either shut or open, while others can be used to throttle flow. There are many different types of valves; selecting the correct valve for an application depends on a number of factors, such as ease of maintenance, reliability, leakage tendencies, cost, and the frequency with which the valve will be open and shut.

Valves can be used to isolate equipment or regulate flow. Isolation valves are designed to seal off a part of a system for operating purposes or maintenance. Flow-regulating valves either restrict flow through a system branch (throttle valve) or allow flow around it (bypass valve). A throttle valve controls flow by increasing or decreasing the flow resistance across it. In contrast, a bypass valve allows flow to go around a system component by increasing or decreasing the flow resistance in a bypass line. A check valve allows fluid to move in only one direction, thus protecting equipment from being pressurized from the wrong direction and helping to keep fluids flowing in the right direction. Check valves are used at the discharge of many pumps to prevent flow reversal when the pump is stopped.

##  End-Use Equipment (Heat Exchangers, Tanks, and Hydraulic Equipment)

The essential purpose of a pumping system may be to provide cooling, to supply or drain a tank or reservoir, or to provide hydraulic power to a machine. Therefore, the nature of the enduse equipment is a key design consideration in determining how the piping and valves should be configured. There are many different types of end-use equipment; the fluid pressurization needs and pressure drops across this equipment vary widely. For heat exchangers, flow is the critical performance characteristic; for hydraulic machinery, pressure is the key system need. Pumps and pumping system components must be sized and configured according to the needs of the end-use processes.

## Pumping System Principles

##  Design Practices

Fluid system designs are usually developed to support the needs of other systems. For example, in cooling system applications, the heat transfer requirements determine how many heat exchangers are needed, how large each heat exchanger should be, and how much flow is required. Pump capabilities are then calculated based on the system layout and equipment characteristics. In other applications, such as municipal wastewater removal, pump capabilities are determined by the amount of water that must be moved and the height and pressure to which it must be pumped. The pumps are sized and configured according to the flow rate and pressure requirements of the system or service.

After the service needs of a pumping system are identified, the pump/motor combination, layout, and valve requirements must be engineered. Selecting the appropriate type of pump and its speed and power characteristics requires an understanding of its operating principles.

The most challenging aspect of the design process is cost-effectively matching the pump and motor characteristics to the needs of the system. This process is often complicated by wide variations in flow and pressure requirements. Ensuring that system needs are met during worst-case conditions can cause designers to specify equipment that is oversized for normal operation. In addition, specifying larger than necessary pumps increases material, installation, and operating costs. Designing a system with larger piping diameters might reduce pumping energy costs, however. See the fact sheet titled Piping Configurations To Improve Pumping System Efficiency in Section 2 and the tip sheet in Appendix C titled Reduce Pumping Costs Through Optimum Pipe Sizing.

##  Fluid Energy

For practical pump applications, the energy of a fluid is commonly measured in terms of head . Head is usually expressed in feet or meters, which refers to the height of a column of system fluid that has an equivalent amount of potential energy. This term is convenient because it incorporates density and pressure, which allows centrifugal pumps to be evaluated over a range of system fluids. For example, at a given flow rate, a centrifugal pump will generate two different discharge pressures for two differentdensity fluids, but the corresponding head for these two conditions is the same.

The total head of a fluid system consists of three terms or measurements: static pressure (gauge pressure), height (or potential energy), and velocity head (or kinetic energy).

Static pressure, as the name indicates, is the pressure of the fluid in the system. It is the quantity measured by conventional pressure gauges. The height of the fluid level has a substantial impact on the static pressure in a system, but it is itself a distinct measurement of fluid energy. For example, a pressure gauge on a vented tank reads atmospheric pressure. If this tank is located 50 feet (ft) above the pump, however, the pump would have to generate at least 50 ft of static pressure (for tap water, the gauge would have to read 21.7 pounds per square inch [psi]) to push water into the tank.

Velocity head (also known as 'dynamic head') is a measure of a fluid's kinetic energy. In most systems, the velocity head is small in comparison to the static head. For example, the flow velocity in cooling systems does not typically exceed 15 ft per second, which is roughly equivalent to 3.5 ft of head (if the system fluid is water, this velocity head translates to about 1.5 psi gauge [psig]). The velocity head of a fluid must be considered when siting pressure gauges, when designing a system, and when evaluating a reading from a pressure gauge, especially when the system has varying pipe sizes. A pressure gauge downstream of a pipe reduction will read lower than one upstream of the reduction, although the distance may only be a few inches.

##  Fluid Properties

In addition to being determined by the type of system being serviced, pump requirements are influenced greatly by fluid characteristics such as viscosity , density, particulate content, and vapor pressure . Viscosity is a property that measures the shear resistance of a fluid. A highly viscous liquid consumes more energy during flow because its shear resistance creates heat. Some fluids, such as cold lubricating oil (at less than 60°F), are sufficiently viscous that centrifugal pumps cannot move them effectively. As a result, the range of fluid viscosities over the operating temperatures of a system is a key system design factor. A pump/ motor combination that is appropriately sized for oil at a temperature of 80°F may be undersized for operation at 60°F.

The quantities and properties of particulates in a system fluid also affect pump design and selection. Some pumps cannot tolerate much debris. And the performance of some multistage centrifugal pumps degrades significantly if seals between stages become eroded. Other pumps are designed for use with high-particulate-content fluids. Because of the way they operate, centrifugal pumps are often used to move fluids with high particulate content, such as coal slurries.

The difference between the vapor pressure of a fluid and the system pressure is another fundamental factor in pump design and selection. Accelerating a fluid to high velocities-a characteristic of centrifugal pumps-creates a drop in static pressure. This drop can lower the fluid pressure to the fluid's vapor pressure or below. At this point, the fluid 'boils,' changing from a liquid to a vapor. Known as cavitation, this effect can severely impact a pump's performance. As the fluid changes phase during cavitation, tiny bubbles form. Since vapor takes up considerably more volume than fluid, these bubbles decrease flow through the pump.

The damaging aspect of cavitation occurs when these vapor bubbles return to liquid phase in a violent collapse. During this collapse, highvelocity water jets impinge onto surrounding surfaces. The force of this impingement often exceeds the mechanical strength of the impacted surface, which leads to material loss. Over time, cavitation can create severe erosion problems in pumps, valves, and pipes.

Other problems that cause similar damage are suction and discharge recirculation. Suction recirculation is the formation of damaging flow patterns that result in cavitation-like damage in the suction region of an impeller. Similarly, discharge recirculation is the formation of damaging flow patterns in the outer region of an impeller. These recirculation effects usually result from operating a pump at a flow rate that is too low. To avoid this type of damage, many pumps are listed with a minimum flow rating.

##  System Types

Like pumps, pumping system characteristics and needs range widely, but they can be classified in general as either closed-loop or open-loop systems. A closed-loop system recirculates fluid around a path with common beginning and end points. An open-loop system has an input and an output, as fluid is transferred from one point to another. Pumps that serve closed-loop systems, such as a cooling water system, typically do not have to contend with static head loads unless there are vented tanks at different elevations. In closedloop systems, the frictional losses of system piping and equipment are the predominant pump load.

In contrast, open-loop systems often require pumps to overcome static head requirements as a result of elevation and tank pressurization needs. A mine dewatering system is one example; it uses pumps to move water from the bottom of a mine up to the surface. In this case, static head is often the dominant pump load.

##  Principles of Flow Control

Flow control is essential to system performance. Sufficient flow ensures that equipment is properly cooled and that tanks are drained or filled quickly. Sufficient pressure and flow must be guaranteed to satisfy system requirements; this creates a tendency to oversize pumps and the motors that run them. Because systems are designed with flow control devices to regulate temperature and protect equipment from overpressurization, oversizing system pumps can burden these flow control devices with high energy dissipation loads.

There are four primary methods for controlling flow through a system or its branches: throttle valves, bypass valves, pump speed control, and multiple pump arrangements. The appropriate flow control method depends on the system size and layout, fluid properties, the shape of the pump power curve, the system load, and the system's sensitivity to flow rate changes.

A throttle valve chokes fluid flow so that less fluid can move through the valve, creating a pressure drop across it. Throttle valves are usually more efficient than bypass valves, because as they are shut, they maintain upstream pressure that can help push fluid through parallel branches of the system.

Bypass lines allow fluid to flow around a system component. A major drawback of bypass valves is their detrimental impact on system efficiency. The power used to pump the bypassed fluid is wasted. In static-head-dominated systems, however, bypass valves could be more efficient than throttle valves or systems with adjustable speed drives (ASDs).

Pump speed control includes both mechanical and pump to the flow/pressure demands of the system.

electrical methods of matching the speed of the ASDs, multiple-speed pumps, and multiple pump configurations are usually the most efficient flow control options, especially in systems that are dominated by friction head, because the amount of fluid energy added by the pumps is determined directly from the system demand. Pump speed control is especially appropriate for systems in which friction head predominates.

Both ASDs and multiple-speed motors provide efficient system operation by driving pumps at

different speeds according to system needs. During a period of low system demand, the pump is operated at low speeds. The primary functional difference between ASDs and multiple-speed motors is the degree of speed control available. ASDs typically modify the speed of a single-speed motor through mechanical or electrical methods, while multiple-speed motors contain a different set of windings for each speed. ASDs are practical for applications in which flow demands change continuously. For more information, see the fact sheet in Section 2 titled Controlling Pumps with Adjustable Speed Drives .

Multiple-speed motors are practical for systems in which the flow demands change between distinct, discrete levels that feature lengthy periods of operation. One of the drawbacks to multiple-speed motors is the added cost of equipment. Since each speed has its own set of motor windings, multiplespeed motors are more expensive than singlespeed motors. Also, multiple-speed motors are slightly less efficient than single-speed ones.

Multiple pump arrangements typically consist of pumps placed in parallel in one of two basic configurations: a large pump/small pump configuration, or a series of identical pumps placed in parallel. In the large pump/small pump case, the small pump, often called the ' pony pump ,' operates during normal conditions. The large pump is used during periods of high demand. Because the pony pump is sized for normal system operation, this configuration operates more efficiently than a system would that relies on the large pump to handle loads far below its optimum capacity. For more information on this type of pump, see the Section 2 fact sheet titled Pony Pumps .

With a series of identical pumps placed in parallel, the number of operating pumps can be changed according to system demands. Because the pumps are the same size they can operate together, serving the same discharge header. If the pumps were different sizes, the larger pumps would tend to dominate the smaller pumps and could cause them to be inefficient. If the proper pumps are selected, each pump can operate closer to its highest efficiency point. An added flow control benefit of parallel pumps is that a system curve remains the same whether one or several pumps are operating; what changes is the operating point along this system curve.

Multiple pumps in parallel are well suited for systems with high static head. Another advantage is system redundancy; one pump can fail or be taken off line for maintenance while the other pumps support system operation. When identical parallel pumps are used, the pump curves should remain matched; therefore, operating hours should be the same for each pump, and reconditioning should be done at the same time for all of them. For more information on this configuration, see the fact sheet in Section 2 titled Multiple Pump Arrangements .

##  System Operating Costs

The amount of fluid power that a system consumes is a product of head and flow, according to this equation:

<!-- formula-not-decoded -->

where

H =  head (ft) Q =  flow rate (gallons  per minute [gpm]) s.g. = specific gravity of the fluid 3,960 is a units conversion to state fluid power in terms of horsepower.

The motor power required to generate these head and flow conditions is somewhat higher, because of motor and pump inefficiencies. The efficiency of a pump is measured by dividing the fluid power by the pump shaft power; for directly coupled pump/motor combinations, this is the brake horsepower (bhp) of the motor.

Pumps have varying efficiency levels. The operating point of centrifugal pumps at which their efficiency is highest is known as the best efficiency point (BEP). Efficiencies range widely, from 35% to more than 90%, and they are a function of many design characteristics. Operating a pump at or near its BEP not only minimizes

energy costs, it also decreases loads on the pump and maintenance requirements.

Systems with significant annual operating hours incur high operating and maintenance costs relative to initial equipment purchase costs. Inefficiencies in high-run-time, oversized systems can add significantly to annual operating costs; however, costly inefficiencies are often overlooked when ensuring system reliability. For more information on oversized pumps, see the fact sheet in Section 2 titled Indications of Oversized Pumps . The Pumping System Assessment Tool (see Appendix B) provides assistance in identifying and prioritizing projects to reduce the amount of energy used by pumping systems.

The cost of oversizing pumps extends beyond energy bills. Excess fluid power must be dissipated by a valve, a pressure-regulating device, or the system piping itself, which increases system wear and maintenance costs. Valve seat wear, which results from throttling excess flow and from cavitation, creates a significant maintenance problem and can shorten the interval between valve overhauls. Similarly, the noise and vibration caused by excessive flow creates stress on pipe welds and piping supports; in severe cases, this can erode pipe walls.

Note that, when designers try to improve a pumping system's reliability by oversizing equipment, usually the unanticipated result is less system reliability. This is caused by both the additional wear on the equipment and lowefficiency operation.

## Section 2:  Performance Improvement Opportunity Roadmap

## Overview

## The Fact Sheets

Cost-effective operation and maintenance of a pumping system require attention to the needs of both individual equipment and the entire system. Often, operators are so focused on the immediate demands of the equipment that they forget to step back and notice how certain system parameters are affecting this equipment.

A systems approach analyzes both supply and demand sides of the system and how they interact, shifting the focus from individual components to total system performance. This approach usually involves the following types of interrelated actions:

- ■ Establish current conditions and operating parameters
- ■ Determine present process production needs and estimate future ones
- ■ Gather and analyze operating data and develop load duty cycles
- ■ Assess alternative system designs and improvements
- ■ Determine the most technically and economically sound options, taking into consideration all subsystems
- ■ Implement the best option
- ■ Assess energy consumption with respect to performance
- ■ Continue to monitor and optimize the system
- ■ Continue to operate and maintain the system for peak performance.

The rest of this section contains 11 fact sheets that address both component and system issues. Each fact sheet describes in detail a specific opportunity to improve the performance of an industrial pumping system. The fact sheets are as follows:

- 1.  Assessing Pumping System Needs
- 2.  Common Pumping System Problems
- 3.  Indications of Oversized Pumps
- 4.  Piping Configurations to Improve Pumping System Efficiency
- 5.  Basic Pump Maintenance
- 6.  Centrifugal Pumps
- 7.  Positive Displacement Pump Applications
- 8.  Multiple Pump Arrangements
- 9.  Pony Pumps
- 10.  Impeller Trimming
- 11.  Controlling Pumps with Adjustable Speed Drives

<!-- image -->

## Key

- A Piping	Configurations	to	Improve	Pumping	System	Efficiency
- B Controlling	Pumps	with	Adjustable	Speed	Drives
- C Basic	Pump	Maintenance
- D Common	Pumping	System	Problems
- E General	Pump	Fact	Sheets:	Assessing	Pumping	System	Needs, Indications	of	Oversized	Pumps,	Positive	Displacement	Pump Applications,	Centrifugal	Pumps,	Impeller	Trimming

## Figure 2. Key to the Fact Sheets

## Assessing Pumping System Needs

There are three principal points in the life cycle of a system that present opportunities to improve pumping system performance:

- ■ During initial system design and pump selection
- ■ During troubleshooting to solve a system problem
- ■ During a system capacity change.

##  Analyzing System Requirements

A key to improving system performance and reliability is to fully understand system requirements (peak demand, average demand, and the variability of demand) with respect to time of day and time of year. It is much simpler to design and operate systems with relatively consistent requirements than to have to account for wide variations in demand.

Problems with oversized pumps often develop because the system is designed for peak loads, while normal operating loads are much smaller. Excess flow energy is then forced into the system. In addition to increasing operating costs, this excess flow energy creates unnecessary wear on components such as valves, piping, and piping supports.

Often, system operators do not realize the impact of running a system at higher-than-necessary levels of flow and pressure. Pumps and valve lineups are set to meet the worst-case demandfor example, a cooling system might be aligned to handle the largest heat load but is not readjusted during periods of lower demand.

The operating cost and reliability of many systems can be improved by recognizing the variability of system demand and by matching flow and pressure requirements more closely to system needs.

Appendix B describes the Pumping System Assessment Tool (PSAT), a software tool that helps determine how well an existing pump is

## Related Tip Sheet

A	summary	of	the	key	issues	in	this	fact	sheet is	available	in	an	ITP	BestPractices	Tip	Sheet titled Conduct an In-Plant Pumping System Survey. Tip	sheets	can	be	found	in	Appendix C,	accessed	on	the	Web	at www.eere.energy. gov/industry/bestpractices ,	or	obtained	by contacting	the	EERE	Information	Center	at 877-337-3463.

matched to its system. This tool provides guidelines, a checklist, and data collection sheets to assist system operators in identifying and prioritizing opportunities for reducing energy use in pumping systems.

##  Initial Pump Selection

Pump selection starts with a basic knowledge of system operating conditions: fluid properties, pressures, temperatures, and system layout. These conditions determine the type of pump that is required to meet certain service needs. There are two basic types of pumps: positive displacement and centrifugal. Although axial-flow pumps are frequently classified as a separate type, they have essentially the same operating principles as centrifugal pumps.

Positive displacement pumps pressurize a fluid by squeezing it in a collapsing volume, such as by a piston in a cylinder. Centrifugal and axial pumps impart kinetic energy to a fluid and rely on the conversion of this kinetic energy to potential energy to increase fluid pressure. In general, positive displacement and centrifugal pumps serve different applications.

Positive displacement pumps are used in low-flow, high-head applications and with high-viscosity fluids. In contrast, centrifugal pumps are used typically in high-flow, low-head applications in which fluid viscosity is not prohibitively high.

However, there are many exceptions to these guidelines. For more information on the factors that govern the use of positive displacement and centrifugal pumps, see Section 1 and the fact sheets in this section titled Centrifugal Pumps and Positive Displacement Pump Applications.

Pumps are usually selected on a 'best fit' basis rather than designed specifically for a particular application. A pump is chosen from a wide range of types and models, based on its ability to meet the anticipated demands of a system. Pumps have two mutually dependent outputs: flow rate and head. The variability of these outputs and other factors-such as efficiency, suction inlet conditions, operating life, and maintenancecomplicate the pump selection process.

Centrifugal pumps are by far the most popular type of pump because they are typically low in cost and have low maintenance requirements and long operating lives. Despite their extensive use, selecting a centrifugal pump is complex, and this creates a tendency to oversize it. To try to accommodate uncertainties in system design, fouling effects, or future capacity increases, designers often select larger-than-necessary pump/motor assemblies. Designers also tend to oversize a pump to prevent being responsible for inadequate system performance.

Unfortunately, oversizing a pump increases the cost of operating and maintaining a pumping system and creates a different set of operating problems-including excess flow noise, inefficient pump operation, and pipe vibrations. The energy cost alone of using an oversized pump is substantial. For more information on this problem, see the fact sheet in this section titled Indications of Oversized Pumps.

##  Troubleshooting a System Problem

Some pumping system problems are sufficiently expensive to justify a system assessment. Examples of these problems include inefficient operation, cavitation, poor flow control, and high maintenance.

Inefficient Operation. Inefficient system operation can be caused by a number of problems, such as improper pump selection, poor system design, excessive wear-ring clearances, and wasteful flow control practices. Indications of inefficient system operation include high energy costs, excessive noise in the pipes and across valves, and high maintenance requirements.

Each centrifugal pump has a best efficiency point (BEP) at which its operating efficiency is highest and its radial bearing loads are lowest (except for pumps with concentric case designs). At its BEP, a pump operates most cost-effectively in terms of both energy efficiency and maintenance. In reality, continuously operating a pump at its BEP is difficult because systems usually have changing demands. However, selecting a pump with a BEP that is close to the system's normal operating range can result in significant operating cost savings.

Cavitation. Centrifugal pumps are susceptible to a damaging and performance-degrading effect known as cavitation. Cavitation occurs when the static pressure in the pump drops below the vapor pressure of a fluid. The liquid vaporizes in the form of tiny bubbles; then, when the surrounding pressure increases, the fluid returns to liquid as these tiny bubbles collapse violently. The collapse of the bubbles sends high-velocity water jets into surrounding surfaces, which can damage the impeller and erode the pump casing and piping surfaces. When a pump experiences cavitation, the result is accelerated bearing and seal wear and poor system performance.

Cavitation usually occurs at high flow rates, when a pump is operating at the far right portion of its performance curve. However, cavitation-like damage can also occur at low flow rates, when damaging vortices develop in the pump. Cavitation is indicated by crackling and popping noises, similar to the sound of marbles flowing through a pipe. If uncorrected, cavitation can lead to expensive repairs. For more information on cavitation, see the fact sheet in this section titled Common Pumping System Problems.

Figure 3. Illustration of the Sensitivity of Flow to Changes in Backpressure

<!-- image -->

Internal Recirculation. Internal recirculation is another performance-degrading effect that damages pumps in much the same way that cavitation does. Internal recirculation tends to occur at low flow rates when fluid leaving the impeller forms damaging vortices. To avoid this problem, manufacturers list the minimum flow rates for their pumps. Operators should be aware of this minimum flow requirement and avoid overly restricting pump output.

Poor Flow Control. Poor flow control can result from several conditions, including improper pump selection and poor system design. The performance curve characteristics of some pumps indicate the need for careful consideration of the variability in operating requirements. Performance curves that are relatively flat, or curves that 'droop' at low flow rates, mean that the designer should be aware of all the operating demands on the pump when selecting one.

Generally, head curves arc downward from the zero-flow condition-that is, as the backpressure on the pump decreases, the flow increases. The specific slope and shape of the curve depend largely on the shape of the impeller vanes and the pump speed.

The slope of the pump curve demonstrates the response of the pump's output to changes in backpressure. A flat pump curve shows that the response to a small decrease in backpressure is a large increase in flow. This sensitivity can lead to system instability, especially in systems that have substantial changes in throttle or bypass valve positions. For example, in the pump curve of Figure 3, at 160 feet (ft) of head and 250 gallons per minute (gpm) flow, a 10-ft increase in system backpressure results in a 100-gpm drop-off in pump flow.

The performance curves of some pumps droop at low flow rates. This characteristic applies primarily to pumps with low specific speeds. As shown in Figure 4 (which is illustrative and does not represent an actual pump curve), the performance curves of these pumps point upward at low flow rates. Since system curves also point upward, the system curve and the pump curve can intersect at more than one point, occasionally leading to instability. In some cases, a pump operating in this range will 'hunt,' that is, repeatedly adjust its output as it searches for a stable operating point. Although most manufacturers publish a minimum flow requirement to prevent a design engineer from specifying a pump that operates in this region, pumps can wear out, allowing their operating points to drift into this region. Operators should be aware that surging pump operation may be the combined result of a deteriorating pump and a drooping head curve. On the positive side, pumps with drooping head curves tend to be more efficient.

Figure 4. Drooping Performance Curve

<!-- image -->

Excessive Maintenance. All pumping systems require some maintenance; however, systems with unusually high maintenance requirements are often the result of improper design and operation. Problems such as cavitation, frequent energizing and de-energizing of a pump motor, and valve seat leakage can decrease the length of time between repairs.

A system's maintenance requirements can be measured by the mean time between failure (MTBF) for its components. Since systems operate in a broad range of service environments, it is difficult to characterize the MTBF for each system component; however, seal and bearing manufacturers often provide an estimated MTBF for a particular product. If the actual time to failure is much less than the manufacturer's recommended interval, the cause of the failure should be assessed.

Bearing Replacement. There are two principal types of bearings in centrifugal pumps: thrust and radial. Operating conditions have a large impact on the amount of load each type of bearing sees and the rate at which the bearings wear. To assess whether bearings are holding up comparatively well, the histories of other pumps in similar environments should be evaluated. If bearings need to be replaced every few months, then the system operating conditions or the design criteria for the bearings should be evaluated.

Factors that accelerate bearing wear are high loads, poor lubrication, high operating temperature, and vibration. Preventive maintenance techniques-such as vibration analysis, temperature checks, and oil analysis-can improve the effectiveness of scheduling bearing replacements. For more information, see the fact sheet in this section titled Common Pumping System Problems.

Packing/Mechanical Seal Replacement. Packing and mechanical seals are methods of sealing around the area where the pump shaft penetrates into the pump casing, to stop or prevent leaks. Packing is less expensive; it is used when leakage from the pump is not costly or otherwise problematic. Mechanical seals, used in the majority of pumps sold today, are more effective at sealing fluid, but they are more expensive and require additional maintenance.

Packing squeezes against the pump shaft and requires frequent adjustment to maintain the proper amount of cooling and lubrication leakage. Packing life depends on service conditions, the quality of the packing material, and on the care with which it is installed and adjusted.

Assessing and troubleshooting the performance of mechanical seals is complicated by the wide range of factors that impact the function and operating life of these seals. Since there are many different types of mechanical seals for many different applications, it is difficult to state how long a seal should last. Common causes of seal problems include contamination of the seal faces, overheating due to inadequate lubrication, and improper installation. For more information on mechanical seal and packing problems, see the fact sheet in this section titled Common Pumping System Problems.

Wear-Ring Clearances. Wear rings are used in centrifugal pumps to establish clearances between impellers and pump casings or other impellers. As pumps operate over time, erosion caused by abrasive particles or fluid squeezing through gaps can increase these clearances. The consequence is greater leakage within the pump. That is, more fluid passes from the high-pressure side of an impeller to its low-pressure side, which reduces the pump's efficiency.

The gaps in the wear ring should be set in accordance with the manufacturer's instructions during the initial installation. Note that the design of the wear rings will determine the way in which clearances are set. Some pump designs require the impeller to be positioned axially to provide proper clearance. The engineer can consult the product instruction manual for the proper setting of the wear ring clearance. The gaps need to be reset properly during major pump overhauls or if the pump's performance declines.

Electrical System Wear. The stress on a motor and its supporting electrical equipment is minimized when a motor is started under its lowest mechanical load. For a radial centrifugal pump , the brake horsepower (bhp) curve is typically a constantly increasing line on the performance curve, indicating that the motor current increases as the flow rate goes up.

A practical implication of a constantly rising bhp line on the performance curve is that the pump's mechanical load is smallest at zero flow, that is, when all valves downstream of the pump are closed. Consequently, starting a centrifugal pump while it is deadheaded and then opening the valves soon after the pump comes up to speed can reduce electrical stresses on the motor and the motor controller.

For an axial pump , this relationship between flow and power is reversed. In an axial pump, power decreases as flow increases. Consequently, when soft-starting axial pumps, the operator must ensure that downstream valves are open until the pump is up to speed.

In some pumping systems, the effect of pump starts on the fluid system itself is a larger concern than their impact on the electrical system. For example, rapid acceleration of large volumes of fluid can create damaging water hammers. However, as far as the electrical system is concerned, start-up practices and, in some cases, special softstarting switchgears that minimize electrical surges and high starting currents can extend the operating life of the system and improve overall system reliability.

##  System Capacity Increases

When a system needs to be modified or upgraded, the available pumping capacity should also be assessed. Unless the existing pump is considerably overdesigned, adding a branch to a system or increasing the flow to an existing component means that a larger pump or an additional pump must be installed. Usually, the same type of pump can be installed as the existing pump. However, the size of the new pump or pumps can vary according to service needs.

In some cases, a large pump capable of handling the highest system demand can be equipped with an adjustable speed drive (ASD) to ensure that it operates efficiently over a wide range of system conditions (depending on the system curve). ASDs are especially practical for systems that are dominated by frictional resistance; however, they must be evaluated carefully for use in systems that have high static head. In highstatic-head systems, reducing the pump speed can cause a pump to operate close to shut-off head conditions; this generally leads to poor performance or, in severe cases, damage. For more information, see the fact sheet in this section titled Controlling Pumps with Adjustable Speed Drives .

Alternatively, expanding pumping system capacity can be accomplished using multiple pump arrangements. Multiple pump arrangements allow several pumps to be available to serve a system. System flow requirements dictate the number of pumps energized at any particular time. The principal benefit of this alternative is to keep each pump operating closer to its BEP, rather than requiring one large pump to operate over a wide range of conditions.

Multiple pump arrangements are well suited for systems that have high static heads and low friction losses. Unlike alternatives that reduce pump speed, the use of multiple pumps in parallel avoids the danger of operating a pump near shut-off head if the pumps are properly matched, and this can allow each pump to operate more efficiently. For more information, see the fact sheet in this section titled Multiple Pump Arrangements .

Another multiple pump application is the use of two different-sized pumps: a small one, known as the pony pump , to handle normal loads, and a large one to handle worst-case loads. The advantage of using a pony pump is that the smaller pump can be sized for efficient operation during normal conditions, which then results in lower operating and maintenance costs. For more information, see the fact sheet in this section titled Pony Pumps .

## Common Pumping System Problems

Poor design and improper system operation can create problems in both pumps and pumping systems. As rotating equipment, pumps are subject to wear, erosion, cavitation, and leakage. Many pumping system problems can result from improper pump selection and operation. If they are not selected or operated properly, pumps can require considerable maintenance.

## Related Tip Sheets

##  System Problems

Many pumping system components are not dynamic. That is, these components allow fluid or heat transfer but, aside from thermal expansion or structural vibration, they do not move and do not have dynamic surfaces that wear out. (Hydraulic systems are a notable exception, but they have a unique set of operating problems.) The most common types of problems in these components are leakage, fouling,  valve failure, and cracks 2 in pipe supports.

Leakage. In most systems, leakage first occurs at mechanical joints. Once they have been hydrostatically tested (pressurized higher than system operating pressure and inspected for leaks), solid pipe and welded joints do not typically develop leaks unless the pipe walls erode and/or corrode. Mechanical joints rely on fastener tension to ensure tightness. Over time, these joints can loosen or the gasket material can degrade. Repairing a leaking mechanical joint can be as simple as tightening the joint fasteners or as difficult as disassembling the joint and replacing the gaskets or O-rings.

Causes of mechanical joint leakage include sagging pipes, the result of inadequate support; thermal strain; and fluid-borne and structureborne vibrations. Since improper pump selection and operation can induce high levels of vibration in a system, a pump problem can quickly become a pumping system problem, and vice versa.

2 Fouling can also increase the pressure drop.

Related	information	is	available	in	two	ITP BestPractices	Tip	Sheets	titled Select an Energy-Efficient Centrifugal Pump and Test for Pumping System Efficiency .	Tip	sheets can	be	found	in	Appendix	C,	accessed	on	the Web	at www.eere.energy.gov/industry/ bestpractices, or	obtained	by	contacting	the EERE	Information	Center	at	877-337-3463.

Valve Problems. Valves are susceptible to wear and leakage, and they require a considerable amount of maintenance. Depending on the service environment, they must occasionally be overhauled. Valves are often installed in a pumping system using bolted flange connections. These valves can experience the same leakage problems as mechanical joints. Valve packing can also develop leaks. Much like the packing used in pumps, valve packing controls leakage around a valve stem. However, leakage can result from improper installation or degradation of the packing.

In some systems, a little leakage from around valve stems is not a problem. In other systems, such as those with toxic fluids, such leakage requires immediate attention. In many systems, valve packing leakage is allowed during initial operation, until the valves have been opened and shut enough times to break in the packing. Also, in high-temperature systems such as steam systems, valve packing may leak at low temperatures and then seal at high temperatures, as the valve heats up and expands.

Adjustments to valve packing should be made cautiously. Overtightening a valve packing gland can significantly increase the amount of torque required to operate a valve. If packing is too tight, the valve's handwheel torque may be too high to turn by hand, posing a potential safety problem.

Valve seat wear is another problem that can be made worse by improper pump selection. Valve seats form the seal that allows a valve to stop flow. The internal surfaces of these seats are classified as 'soft' or 'hard,' depending on the type of material used. Soft-seated valves usually have some sort of polymer coating on the seating surface; hard-seated valves are usually characterized by metal-to-metal contact. Soft-seated valves tend to seal more tightly but wear more quickly than hard-seated valves.

Valve seats experience wear problems caused by erosive fluids and high-velocity flow. Oversizing a pump can create high pressure drops across throttle valves and high flow rates through bypass valves. In both cases, the valve seats may wear quickly, shortening the interval between valve overhauls.

## Pipe Supports and Equipment Foundations . In

general, unless a system is poorly designed, the hangers that hold piping and the foundations that support system equipment should last throughout the life of the system. However, high vibration levels can create fatigue loads that cause structural members to yield or crack. Pumps that are substantially oversized can induce such vibrations.

##  Centrifugal Pump Problems

Some of the benefits of centrifugal pumps are that they are simple to operate, reliable, and longlasting. In order to realize these benefits, however, certain problems must be prevented, such as cavitation, internal recirculation, seal or packing wear, poor material selection, and improper shaft loading.

## Cavitation and Internal Recirculation. Cavitation

is a damaging condition that erodes pump impellers, shortening their operating lives and accelerating the wear rate of bearings and seals in the process. As illustrated in Figure 5, cavitation is both a problem itself and an indication of poor system performance.

Cavitation occurs when the fluid's static pressure at a given flow rate falls below the fluid's vapor

<!-- image -->

pressure at a certain temperature. In centrifugal pumps, the acceleration of fluid into the impeller causes the fluid pressure to drop. If this pressure drop is sufficient, the liquid vaporizes, forming tiny bubbles that are unstable and prone to violent collapse. These violent bubble collapses can throw tiny, destructive water jets onto impeller surfaces.

Crackling and popping noises that often sound like marbles passing through the pump are indications of cavitation. Not selecting the right pump-or operating the system at either higherthan-design temperatures or lower-than-design suction pressure-can be a cause of cavitation. Cavitation usually occurs at high flow rates, when a pump is operating far to the right along its performance curve; however, under certain conditions, cavitation damage can occur at low flow rates as well.

Cavitation damage can also result when the pump suction is starved because of the formation of air pockets or fouling of pipes. The most important effects of sustained cavitation are reductions in pump performance and erosion of the pump impeller. Cavitation degrades pump performance because the vapor in the pump restricts flow and lowers the generated head.

If cavitation causes enough loss of material in the impellers, they can become unbalanced, creating alternating bearing loads that accelerate bearing wear. Because it dramatically shortens pump life, cavitation is a serious threat to system reliability. Cavitation also increases other maintenance requirements by inducing vibrations that stress pump foundations and connected piping.

Cavitation-like damage can also occur as a result of internal recirculation. Operating the system at low flow rates can establish damaging flow patterns in either the suction or discharge regions of an impeller.

For applications in which cavitation is to some extent unavoidable, high-tensile-strength materials should be specified for the impeller. Tougher materials can withstand higher energy cavitation. However, use caution when sourcing materials to ensure that they are compatible with the system fluid.

To prevent cavitation, centrifugal pumps must operate with a certain amount of pressure at the inlet. This pressure is known as the net positive suction head, or NPSH, which is discussed in the fact sheet in this section titled Centrifugal Pumps.

##  Seal and Packing Problems

The point at which the shaft penetrates the pump casing, known as the stuffing box, provides a leak path that must be sealed. This area is normally sealed using packing or mechanical seals (see Figure 6). For systems in which fluid leakage is not a significant concern, packing is usually used because it is much less expensive and requires less sophisticated maintenance skills. Mechanical seals provide superior sealing, but they are typically more expensive and harder to repair or replace. Most pumps sold today are provided with mechanical seals.

Packing. There are two basic types of packing problems: overtightening and improper install-

Figure 6. Two Types of Sealing Methods: Packing and Mechanical Seals

<!-- image -->

ation. Packing typically requires some leakage in order to remain lubricated and cooled. If packing rings are overtightened, friction between the packing and shaft will generate excessive heat, which can destroy the packing and possibly damage the shaft.

Since packing comes in direct contact with the pump shaft, it wears over time, increasing the leakage rate. Consequently, the packing gland must be periodically tightened to squeeze the packing against the shaft and keep leakage to an acceptable level. Improper packing installation leads to uneven compression of the packing rings (overtightening of one, insufficient tightening of others) or an overly loose fit between the packing and shaft. This often results in excessive leakage, which in turn can cause housekeeping problems (such as wet floors), high ambient moisture levels, and, if the fluid is toxic, contamination problems. If the fluid is expensive, leakage also has a direct economic cost.

If the fluid pressure at the stuffing box is below atmospheric pressure, then improperly installing the packing seal can allow air to enter the system. Pulling air into the suction region can degrade pump performance 3% or more. Also, for systems that require precise fluid chemistries, especially those that are sensitive to oxygen content, pulling in air can contaminate the system. Excess air leakage can keep pumps from staying primed and prevent self-priming pumps from repriming on start-up.

Mechanical Seals. Mechanical seals are typically used in applications that call for superior sealing. The effectiveness of mechanical seals is highly dependent on correct installation and a continuously clean operating environment. Mechanical seals have two primary failure mechanisms: degradation of the face material and loss of spring or bellows tension, which allows the faces to separate more easily. Degradation of the seal face is usually caused by debris that wedges into a seal face and causes damage. To minimize the risk of this type of damage, mechanical seals are often serviced by special flushing lines that have filters to catch debris.

Seal faces are held together by a force that is usually provided by springs or bellows. However, compressive properties are often lost because of fatigue, fouling, and/or corrosive environments, which degrade spring and bellows materials. To minimize fatigue loads on mechanical seals, the seal must be precisely aligned so that spring movement is minimal during each shaft revolution. In systems with highly corrosive fluids, mechanical seals with external springs are recommended.

The face materials require alignment, with tolerances on the order of microns (one-millionth of a meter). The precise flatness and proper alignment of the seals are important because these faces must remain in constant contact as the pump shaft spins. Since pumps often rotate at 1,800 or 3,600 revolutions per minute (rpm), even slight variations in the contact between two seal faces can quickly destroy a seal's effectiveness.

Shaft Deflection. Shaft deflection is a problem among long-shafted centrifugal pumps. Shaft deflection is caused by the force resulting from an unequal pressure distribution around an impeller. The side of the impeller that is nearest the pump discharge connection sees a higher pressure than the other side of the impeller, creating a radial force on the shaft. Some pumps are equipped with multiple volutes to minimize this imbalance.

In general, shaft deflection is most problematic when a pump is operated at low flow conditions. The consequences of severe shaft deflection include high wear rate on bearings, shaft seal leakage, and fatigue bending of the pump shaft. Although pump shafts are typically designed to last the life of the pump, severe shaft deflections can load shafts in ways that they were not designed to handle. If they are sustained for extended periods, severe shaft deflections can result in catastrophic failure of a pump shaft. Pump shaft failure is costly; at times, it requires the replacement of the entire pump. The risk of shaft failure is particularly prevalent in pumps with relatively long distances and small shaft diameters between shaft bearings. Operating

these pumps at or near their minimum flow conditions for extended periods greatly increases the chances of pump shaft failure.

##  Positive Displacement Pump Problems

Positive displacement pumps can experience many of the same problems described earlier in regard to centrifugal pumps, and they can experience some problems of their own. In many positive displacement pumps, the cyclical nature of the pumping action causes fatigue in components such as bearings and diaphragms.

Also, since their flow rate is essentially independent of backpressure, with positive displacement pumps there is an inherent risk of overpressurizing the discharge piping. If valves in the pumping system are aligned so that all the discharge lines downstream of a pump are closed while the pump is operating, overpressure conditions can occur quickly. In such cases, if a pressure relief mechanism is not activated, the pump motor will either reach its lockout torque or the pressure will build until some part of the system fails or ruptures. Because of these dangers, pressure relief valves need to be installed and maintained. If these valves fail to operate properly, catastrophic system damage can occur. Therefore, a regular maintenance program to check these valves should be strictly followed.

A characteristic of many positive displacement pumps is pulsating flow. The fluid-borne and structure-borne vibrations resulting from these pulsations can create load conditions that hasten the degradation of piping, valves, and piping supports. Consequently, pumping systems that are not designed to handle the vibration loads of positive displacement pumps may experience severe operating and maintenance problems.

In addition, positive displacement pumps are very susceptible to wear from abrasives in the fluid being pumped.

## Indications of Oversized Pumps

Conservative engineering practices often result in the specification, purchase, and installation of pumps that exceed process requirements. Engineers often decide to include a margin of safety in sizing pumps to compensate for uncertainties in the design process. Anticipated expansions in system capacity and potential fouling effects add to the tendency to source pumps that are 'one size up' from those that meet system requirements.

Unfortunately, oversizing pumps adds to system operating costs in terms of both energy and maintenance requirements; these costs are often overlooked during the system specification process. Since many of these operating and maintenance costs are avoidable, correcting an oversized pump can be a cost-effective system improvement.

Appendix B, Pumping System Assessment Tool, describes a useful DOE-developed software tool that can help engineers identify and prioritize opportunities to optimize pumping systems. Many of the principles discussed here can also help to indicate whether a pump is operating efficiently relative to the needs of its system.

##  Common Indications of Oversizing

There are five common indications that a pump is oversized: excessive flow noise, highly throttled flow control valves, heavy use of bypass lines, frequent replacements of bearings and seals, and intermittent pump operation.

Excessive Flow Noise. Oversized pumps tend to cause excessive levels of noise. These problems are frequently disregarded as normal system operating characteristics as the operators simply get used to the system's acoustic levels. Unless the noise levels worsen, the system is assumed to be performing normally. However, the cumulative damage that results from flow-induced pipe vibrations can significantly accelerate system wear.

Pipe vibrations tend to loosen flanged connections and other mechanical joints. These vibrations also

## Related Tip Sheets

Related	information	is	available	in	two	ITP BestPractices	Tip	Sheets	titled Select an Energy-Efficient Centrifugal Pump and Test for Pumping System Efficiency .	Tip	sheets can	be	found	in	Appendix	C,	accessed	on	the Web	at www.eere.energy.gov/industry/ bestpractices, or	obtained	by	contacting	the EERE	Information	Center	at	877-337-3463.

create fatigue loads on welds in both the pipes and piping supports.

## Highly Throttled Flow Control Valves. Throttle valves affect system flow in two principal ways:

- ■ Shifting system flow balance, forcing flow rates in different system branches to increase or decrease
- ■ Changing the overall system backpressureessentially causing the pump to 'see' a different system, which shifts its operating point along its performance curve.

Both these effects occur concurrently to an extent that depends on the system's configuration. In systems with oversized pumps, valves tend to remain in restrictive positions, and this forces the pump to operate against a high backpressure. Since this backpressure is typically higher than the pressure associated with the pump's best efficiency point (BEP), the pump operates inefficiently and is susceptible to higher-than-normal bearing wear.

Many control valves are oversized to ensure adequate flow. Unknowns such as pump performance, pipeline fouling and scaling, and future production rates all tend to create a bias toward oversizing. Many control valves normally operate at less than 50% open. Appropriate valve characterization is often not applied. This results in a high degree of nonlinearity and thus inconsistent control performance.

Highly throttled control valves can also impact process control loops. Control valve backlash and stiction , or static friction, are major contributors to process variability. The tendency to oversize the control valve also exacerbates the negative impact of backlash and stiction. Proper sizing of the pump and control valve provides a more uniform response to flow changes and reduces process variability.

Heavy Use of Bypass Lines. In some systems, excess flow is handled by bypass lines around system equipment. Bypass lines prevent the buildup of damaging pressure differentials, and they are used for temperature control in many heat exchangers. Bypass lines may allow pump(s) to operate closer to the BEP and improve reliability, although the energy needed to push fluid through bypass lines is wasted. When a system normally operates with a large number of open bypass valves, this indicates that the system is performing inefficiently because of improper balancing, oversized pumps, or both.

## Frequent Replacement of Bearings and Seals.

The penalties for excess system flow can extend beyond high energy costs to include frequent pump maintenance. Since oversized pumps generate high backpressures, they often operate far to the left of their BEP and tend to experience greater bearing and seal wear. The higher backpressure caused by increased flow velocity creates high radial-bearing and thrust-bearing loads, and it exerts greater pressure on mechanical seals and packing glands.

Intermittent Pump Operation. Pumps are often used to maintain fluid levels in tanks, either by filling or draining them, as needed. Many systems rely on a level control system to activate the pumps automatically. The cumulative effect of energizing and de-energizing a pump shortens the lives of the motor controller and the pump assembly. In addition, an oversized pump generates higher friction losses during operation, because it pushes fluid through the piping at higher velocities.

##  Corrective Measures

In systems served by oversized pumps, several corrective measures can be taken to lower system operating costs and extend equipment maintenance intervals. The correct measure to choose depends on the system and on the particular indicator that points to the oversized pump problem. An obvious remedy is to replace the pump/motor assembly with a downsized version; however, this is costly and may not be feasible in all situations.

Alternatives to replacing the entire pump/motor assembly include these:

- ■ Replace the impeller of the existing pump with a smaller impeller
- ■ Reduce the outside diameter of the existing impeller
- ■ Install an adjustable speed drive (ASD) to control the pump if flow varies over time
- ■ Add a smaller pump to reduce the intermittent operation of the existing pump.

Adjust the Impeller. Most pumps can be assembled using more than one impeller diameter. Pump manufacturers standardize their pump models as much as possible to lower production costs; consequently, casings and pump shafts can accommodate impellers of different sizes. This characteristic often allows a smaller impeller to be used when the existing impeller is generating excessive flow or head.

When a smaller impeller is not available or the performance of the next smallest impeller is insufficient, impeller trimming can be an alternative. Impeller trimming reduces the impeller diameter-and thus the impeller tip speed-so that the same constant-speed pump motor can be used. Since the head generated by a pump is a function of its tip speed, impeller trimming shifts the entire performance curve of the pump downward and to the left. For more information on this performance improvement opportunity, see the fact sheet in this section titled Impeller Trimming.

Use Variable Frequency Drives. Pumps that experience highly variable demand conditions are often good candidates for ASDs. The most popular type of ASD is the variable frequency drive (VFD). VFDs use electronic controls to regulate motor speed, which, in turn, adjusts the pump's output. The principal advantage of VFDs is better matching between the fluid energy that the system requires and the energy that the pump delivers to the system. As system demand changes, the VFD adjusts the pump speed to meet this demand, reducing the energy lost to throttling or bypassing excess flow. The resulting energy and maintenance cost savings often justify the investment in the VFD. However, VFDs are not practical for all applications-for example, systems that operate high static head and those that operate for extended periods under low-flow conditions. For more information, see the fact sheet in this section titled Controlling Pumps with Adjustable Speed Drives.

## Use Smaller Pumps to Augment Larger Pumps.

Pumps that maintain fluid levels in tanks or reservoirs are often sized according to worst-case or peak service conditions. Since the requirements of worst-case conditions are often significantly higher than those of normal operating conditions, many pumps are oversized relative to the demands of their application for most of their operating lives. The penalties of using an oversized pump include frequent energizing and de-energizing of the motor, operation away from the pump's BEP, and high friction losses-all of which add to energy and maintenance costs.

Adding a smaller pump to handle normal system demand relieves the burden on the larger pump, which can be energized as needed during high load conditions. A smaller pump can operate more efficiently and require less maintenance. For more information, see the fact sheet in this section titled Pony Pumps.

## Piping Configurations To Improve Pumping System Efficiency

There are several steps involved in optimizing the configuration of a pumping system. These include determining the proper pipe size, designing a piping system layout that minimizes pressure drops, and selecting low-loss components. To determine the proper pipe size, designers must balance the initial cost of the pipe against the cost of pushing fluid through it. Larger pipes create less friction loss for a given flow rate; however, larger pipes also have higher material and installation costs. Unfortunately, designers often overlook the energy costs of using small piping and focus on the initial cost when sizing system piping.

Similarly, system piping should be configured with an awareness of the energy costs associated with poor flow profiles. Although piping system layouts are usually dictated by space constraints, there are often opportunities to minimize unnecessary pressure drops by avoiding sharp bends, expansions, and contractions and by keeping piping as straight as possible. For example, orienting valves and system equipment so that they are in line with the pipe run is one useful rule of thumb.

Low-loss components provide another opportunity to minimize life-cycle costs during system design. As with pipe sizing, it is necessary to balance initial costs with future energy costs. For example, system components such as valves can be cost-effective when life-cycle costs are taken into consideration.

In many cases, the selection of a particular type of valve is guided by service requirements such as sealing capability under various pressures, the number of times a valve is opened and closed, handwheel torque, and the consequences of valve stem leakage. However, for applications in which service requirements are comparatively light, the valve is selected on a first-cost basis at the expense of high flow loss. For example, globe valves are usually selected because of their low cost and simplicity. However, these valves have a relatively high flow loss coefficient caused by the

## Related Tip Sheet

Related	information	is	available	in	an	ITP BestPractices	Tip	Sheet	titled Reduce Pumping Costs Through Optimum Pipe Sizing .	Tip	sheets can	be	found	in	Appendix	C,	accessed	on	the Web	at www.eere.energy.gov/industry/ bestpractices, or	obtained	by	contacting	the EERE	Information	Center	at 877-337-3463.

flow path through the valve. Thus, one way designers can improve system life-cycle costs is to consider the cost of flow losses.

Valves are often sized incorrectly. Designers often specify a pressure drop across the valve at the design point that is larger than necessary. This results in an undersized valve and energy loss. Further, process designers sometimes specify a maximum system flow that is much greater than normal flow. This also results in an excessive pressure drop across the valve at normal operating conditions.

##  Pump Concerns

Since centrifugal pumps operate most effectively when the inlet flow has a uniform profile, systems should be designed to avoid nonuniform flow at the pump inlet. In centrifugal pumps, as fluid moves from the suction piping into the eye of the impeller, it gets caught by an impeller vane and then accelerates to the tip. If the flow into the eye is uneven, the impeller will transfer energy to the fluid less efficiently. In addition, uneven flow at the pump suction promotes excessive vibrations, which shorten pump life and weaken pipe welds and mechanical joints.

An improper flow profile, vapor collection, and vortex formation are three common pipe configuration problems that result in poor pump performance. Figure 7 depicts some common piping installation problems and shows the corresponding proper arrangements.

<!-- image -->

Poor Flow Profile. Piping configurations often promote uneven flow. Elbows and valves that are placed just before the pump disrupt fluid flow and degrade pump performance. This problem is particularly significant when the flow velocity is high and the suction pressure is low. Under these conditions, a dramatic redirection in flowcommonly created by a small-radius elbow or a globe valve-results in a highly turbulent flow that diminishes pump performance.

Vapor Collection. Vapor entrapment can be another consequence of a poor piping layout. If the suction piping leading to the pump does not have a constant slope, vapor can collect at the high points. Vapor pockets limit flow through the pipe and cause pressure pulsations that degrade the pump's performance. Figure 7 shows examples of piping installations that encourage vapor collection.

Vortex Formation. In tank applications, if a fluid surface drops close to the suction inlet, a vortex can form, potentially creating a loss of suction head or allowing air into the pump. In severe cases, the pump will lose its prime, which can cause severe degradations in performance and even damage to the pump. A centrifugal pump is not designed to run without fluid; mechanical seals, packing, and impeller wearing rings are susceptible to damage if they are not lubricated. Most centrifugal pumps are not self-priming; if a pump loses its prime, it must be filled and vented to be restarted. The centrifugal pumps that are self-priming tend to be less efficient than conventional centrifugal pumps and should be used only when necessary.

##  Rules of Thumb for Improving Pipe Configurations

There are two primary rules of thumb for improving pipe configurations. First, to establish a uniform-velocity flow profile upstream of the pump, the operator should make sure that a straight run of pipe leads into the pump inlet. If space constraints require an elbow just upstream of the pump, a long radius elbow should be selected. In some cases, a flow straightener, such as a baffle plate or a set of turning vanes, should be installed with an elbow to correct any disruption in flow (see Figure 8). By smoothing out the flow, a flow straightener creates a more even velocity profile. Care must be taken, however, to ensure that the pressure drop across the straightener does not cause cavitation.

<!-- image -->

In addition, installers should make sure that transition pieces and joints between pipes or fittings are kept as smooth as possible. Burrs or misaligned pipes create trip points that disrupt flow. Figure	8.	Flow	Straighteners

Suction and discharge piping close to the pump should be properly supported (see Figure 9). Many pump/motor problems are caused by pipe

Figure 9. Proper Support of Suction and Discharge Piping

<!-- image -->

reactions that pull the pump out of alignment. For example, when a pump is installed, the connecting piping is rarely aligned perfectly with the pump; rather, some amount of mechanical correction is needed to make the connections. If the piping is pulled too far from its relaxed position to make the fit, it can force the pump and motor out of alignment, excessively straining the pump casing.

Properly supporting the piping near the pump allows the pipe reaction to be carried by the pipe hangers rather than by the pump itself. Also, proper support of the piping near the pump stiffens the system, and this can reduce system vibrations.

## Basic Pump Maintenance

Centrifugal pumps are widely used because of their low maintenance requirements. However, like all machinery, they still require periodic maintenance. Common maintenance tasks on centrifugal pumps include the following:

- ■ Bearing lubrication and replacement
- ■ Mechanical seal replacement
- ■ Packing tightening and replacement
- ■ Wear ring adjustment or replacement
- ■ Impeller replacement
- ■ Pump/motor alignment
- ■ Motor repair or replacement.

##  Common Failures

The most costly consequence of improper pump maintenance is unscheduled downtime. Causes of this downtime vary according to the demands of the application. In corrosive or hazardous fluid systems, mechanical seal leaks often require shutting down the system for safety reasons. In other systems, such leaks can be tolerated. And in some systems, problems such as bearing seizures may pose the greatest threat to continuous system operation. Since each system places particular demands on its pump/motor equipment, maintenance requirements vary widely.

##  Preventive Maintenance and Schedules

To minimize unscheduled downtime, basic system maintenance should be performed at predetermined intervals. Factors that must be weighed in setting this schedule include the cost of downtime; the cost and risk of catastrophic failure; the expected mean time between repair (MTBR) for motors, bearings, and seals; and the availability of backup equipment. Hours of operation or calendar intervals -e.g., quarterly or semiannually-can help determine the schedule. See, for example, the basic maintenance checklist sample in this fact sheet.

Operators can base decisions about the frequency of maintenance on the manufacturer's recom-

## Related Tip Sheet

A	summary	of	key	issues	presented	here	is available	in	an	ITP	BestPractices	Tip	Sheet titled Maintain Pumping Systems Effectively. Tip sheets	can	be	found	in	Appendix	C,	accessed on	the	Web	at www.eere.energy.gov/industry/ bestpractices, or	obtained	by contacting	the	EERE	Information	Center	at 877-337-3463.

mendations and on their own experience with pumps in similar applications. In systems that do not have abnormally severe operating demands, a typical maintenance schedule like the one shown here could be followed.

## Packing and Mechanical Seal Adjustments.

Packing and mechanical seal adjustments should be done weekly, taking into consideration the following:

- ■ For packing, adjust the tightness of the gland bolts to obtain the cooling flow leakage rate allowed by the pump manufacturer (usually 2 to 60 drops per minute). Do not overtighten the bolts-this will burn up the packing and require repacking of the stuffing box. As the packing wears, add more packing rings. Eventually, the stuffing box will need all new packing rings. When repacking the box, clean and lubricate the gland bolts.
- ■ For mechanical seals, check the performance of the seal and measure leakage.

Bearing Lubrication. Bearings should be lubricated semiannually or annually. Operators should pay particular attention to the following:

- ■ For grease-lubricated bearings, add grease as described in the technical manual for the pump. Be careful not to overgrease bearings, because this interferes with the ball or roller motion and might cause overheating.

- ■ Check the quality of the grease and, if necessary, repack the bearings.
- ■ For oil-lubricated bearings, check the level and quality of the oil. If necessary, add or replace oil. Do not overfill the oil reservoir.

Motor/Pump Alignment. Since shifting of the pump foundation feet or piping can cause pump/ motor misalignment, check the alignment periodically. Alignment is typically measured by using a dial indicator and reading the total indicated runout , or TIR-also known as full indicator movement , or FIM-of a pump/motor coupling. Regularly scheduled vibration readings can reveal changes in the status of a bearing.

For pumps requiring unusually precise alignments, laser measurement systems provide higher accuracy than some other types. Alignment requirements can usually be found in the technical manual for the pump.

##  Repair Items

Repair items that typically have to be replaced regularly include mechanical seals and bearings, packing, wear rings, motors, and impellers.

## Replace Mechanical Seals and Bearings.

Although seals and bearings are normal maintenance items, they sometimes fail catastrophically. Worn bearings can cause an unsatisfactory amount of noise or even seize. Occasionally, a bearing or a mechanical seal seizure scores its corresponding shaft sleeve, which necessitates removal of the pump shaft and installation of a new sleeve.

Mechanical seals are typically used in applications that require a better seal than packing can provide. Although mechanical seals are more expensive, they experience less friction and exhibit superior sealing capabilities in comparison to packing. Mechanical seals rely on a precisely fit contact between their dynamic surfaces. Contaminants can quickly degrade a seal. However, mechanical seals can last thousands of hours if they are properly installed, kept clean, and flushed as required.

## Basic Maintenance Checklist

- ■ Packing. Check	for	leakage	around	the packing	and	adjust	it	according	to	the instructions	of	the	pump	and	packing manufacturers.	Allowable	leakage	is	usually between	2	and	60	drops	per	minute.	Add packing	rings	or,	if	necessary,	replace	all	the packing.
- ■ Mechanical Seals. Check	for	leakage. If	leakage	exceeds	the	manufacturer's specifications,	replace	the	seal.
- ■ Bearings. Determine	the	condition	of	the bearing	by	listening	for	noises	that	indicate excessive	wear,	measuring	the	bearing's operating	temperature,	and	using	a predictive	maintenance	technique	such	as vibration	analysis	or	oil	analysis.	Lubricate bearings	according	to	the	pump	manufacturer's	instructions;	replace	them if	necessary.	A	vibration	analysis	can	also indicate	the	status	of	bearings.
- ■ Motor/Pump Alignment. Determine	if	motor pump	alignment	is	within	the	service	limits of	the	pump.
- ■ Motor Condition. Check	the	integrity	of motor	winding	insulation.	These	tests	usually measure	insulation	resistance	at	a	certain voltage,	or	measure	the	rate	at	which	an applied	voltage	decays	across	the	insulation. A	vibration	analysis	can	also	indicate	certain conditions	within	motor	windings	and	lead	to early	detection	of	developing	problems.

Replace Packing. Packing is a soft, malleable, rope-like material that, when compressed by the packing gland, forms a seal between the pump and the motor shaft. Since packing contacts the rotating shaft directly, it relies on the system fluid for cooling and lubrication. As the packing wears, it must be compressed by tightening the gland nuts. Over time, however, the packing loses its ability to seal and must be replaced.

Packing typically comes in rolls; it must be cut into sections that are then wrapped around the shaft. Cutting packing rings accurately is difficult, but it is essential to ensure proper sealing. Many mechanics facilitate this job by using a piece of pipe or bar stock that is machined to the precise diameter of the pump shaft. Using this mockup shaft allows the mechanic to cut the rings to fit directly without having to measure the packing first and then cut it. Since packing is usually stretchy, the measure/cut method often leads to a poor fit-up.

Replace Wear Rings. Wear rings are fastened to an impeller or a casing (or both) to act as the wear surface between different impeller stages or between an impeller and a pump casing. Wear rings are sized to establish a certain gap between the high- and low-pressure sides of an impeller. If this gap becomes too large, fluid slips back into the suction side of the pump, creating an efficiency loss. Some wear rings have an axial gap that could compensate for wear, and some  pump designs use adjustable wear plates. A key indication that wear rings need to be replaced is a substantial decline in the pump's performance. Unfortunately, pumps must be disassembled in order to replace wear rings.

Replace Motors. Even properly maintained motors have a finite life. Over time, winding insulation breaks down. When a motor's winding temperatures exceed rated values for long periods of time, its insulation tends to break down more quickly. In motor applications below 50 horsepower (hp), the most common option is simply to replace the motor with a new one; however, in larger applications, it is often more economical to rewind an existing motor. Although motor rewinds are typically a costeffective alternative, rewound motors can lose even more efficiency during subsequent rewinds.

For motor rewinds, operators should ensure that the repair facility has a proper quality assurance program, since poor quality motor rewinds can compromise motor efficiency. For more information on motor repair, see www.eere.energy.gov/ industry/bestpractices or contact the EERE Information Center at 877-337-3463.

For motor replacements, high-efficiency motors should be considered. High-efficiency motors are generally 3% to 8% more efficient than standard ones. In high-use applications, this efficiency advantage often provides an attractive payback period. The Energy Policy Act (EPAct) of 1992 set minimum efficiency standards that went into effect in 1997 for most general-purpose motors from 1 to 200 hp. In addition, the National Electrical Manufacturers Association's NEMA Premium TM energy efficiency motors program describes premium efficiency motors as those with even higher efficiencies than the levels established by EPAct. Premium efficiency motors can be cost effective for pumps having high hours of operation.

DOE's MotorMaster+ software tool can be a valuable tool in selecting energy-efficient motors. The program also allows users to compare motors and estimate energy costs and savings along with life-cycle costs. It is available through the EERE Information Center and can be downloaded from the Web site at www.eere.energy.gov/industry/bestpractices . Additional information can be found in the Energy-Efficient Motor Selection Handbook , which is available from the EERE Information Center.

Replace Impellers. Impellers often last the life of the pump. However, severe cavitation or erosion can degrade an impeller, reducing pump performance and efficiency. Impeller replacement is similar to wear-ring replacement in that the pump must first be disassembled.

##  Predictive Maintenance

In many applications, pump maintenance is reactive. For example, bearing noises indicate the need for lubrication or replacement, excessive packing or seal leakage indicates the need for repair or replacement, and poor pump performance may indicate excessive wear ring degradation. Fortunately, recent improvements in instrumentation and signal analysis software have increased the availability of vibration testing equipment; this has helped to improve the planning of pump/motor maintenance. Vibration analysis equipment is

essentially a refined extension of the human ear. By 'listening' to the vibrations of a motor or similar piece of machinery, the instrumentation can detect the beginnings of bearing problems, motor winding problems, or other dynamic imbalances.

Vibration analysis equipment uses accelerometers to measure the vibration response of machinery during operation and records the data on an amplitude/frequency graph. These measured vibrations are compared with a baseline set of data, usually taken when the machinery was first operated. Identifying problems before they become larger allows operators to schedule the needed repairs and significantly reduce the risk of catastrophic failure.

Predictive maintenance thus allows operators to plan for equipment repairs. Two different signatures can be compared to determine the rate at which a problem is developing. This information can be useful in that a repair may be postponed with greater confidence until a convenient downtime.

Another predictive maintenance technique involves oil monitoring and analysis. For pumps with oil-lubricated bearings, analyzing oil quality provides another insight into the operating condition of the bearings and seals. An oil analysis can indicate whether a pump has operated at high temperatures, whether system fluid is leaking into the oil, and whether the bearings are nearing the end of their operating life.

An oil analysis can also increase the confidence with which oil change-outs are planned and eliminate unnecessary oil replacements. It can also provide substantial cost savings, especially if the oil is expensive-for example, a synthetic type with sophisticated additives. At approximately $1,000 per analysis, oil monitoring is not economical for all pump applications; however, it can provide some facilities with worthwhile intelligence regarding the condition of their plant equipment.

In addition, thermography, or infrared (IR) scanning, can be used. IR scans provide early detection of a hot spot and can help avoid an unexpected shutdown. With pump motors, IR scans offer a means of identifying developing problems-for example, a hot-running bearing or deteriorating winding insulation.

## Centrifugal Pumps

Centrifugal pumps (also known as rotodynamic pumps) have variable flow rates even when rotating at a constant speed-unlike positive displacement pumps, which push a certain volume of fluid with each stroke or rotation. Centrifugal pumps use an impeller, which is basically a rotating wheel, to add energy to a fluid. The highvelocity fluid coming off the impeller tip is sent into a diffuser-a chamber that feeds directly into discharge piping. The fluid slows as it enters the diffuser, and the kinetic energy of the fluid converts to higher pressure.

The performance of a centrifugal pump is typically described by a graph plotting the pressure generated by the pump (measured in terms of head) over a range of flow rates. Figure 10 shows a performance curve for a typical centrifugal pump.

The amount of fluid that a centrifugal pump moves depends on pump differential pressure. As the pump differential pressure increases, the flow rate decreases. The rate of this decrease is a function of the pump design. Understanding this relationship is essential to designing, sourcing, and operating a centrifugal pump system.

Also included on a typical pump performance curve are its efficiency and brake horsepower (bhp), both of which are plotted with respect to flow rate. The efficiency of a pump is the ratio of the pump's fluid power to the pump shaft horsepower, which, for direct-coupled pump/ motor combinations, is the motor bhp.

##  Best Efficiency Point

An important characteristic of the head/flow curve is the best efficiency point (BEP). At the BEP, the pump operates most cost-effectively in terms of both energy efficiency and maintenance. BEP is explained further in the fact sheet titled Multiple Pump Arrangements .

Operating a pump at a point well away from its BEP may accelerate wear in bearings, mechanical seals, and other parts. In practice, it is difficult to

## Related Tip Sheet

A	summary	of	key	issues	presented	in	this fact	sheet	is	available	in	an	ITP	BestPractices Tip	Sheet	titled Select an Energy-Efficient Centrifugal Pump. Tip	sheets	can	be	found in	Appendix	C,	accessed	on	the	Web	at www.eere.energy.gov/industry/bestpractices, or	obtained	by	contacting	the	EERE	Information Center	at	877-337-3463.

Figure 10. Centrifugal Pump Performance Curves

<!-- image -->

Figure 10. Centrifugal Pump Performance Curves keep a pump operating consistently at this point because systems usually have changing demands. However, keeping a pump operating within a reasonable range of its BEP lowers overall system operating costs.

Family of Pump Curves. Manufacturers use a coverage chart to describe the performance characteristics of a family of pumps. This type of chart, shown in Figure 11 on page 38, is useful in selecting the appropriate pump size for a particular application. The pump designation numbers in Figure 11 refer to the pump inlet size, the pump outlet size, and the impeller size, respectively. There is significant overlap among these various pump sizes, which is attributable to the availability of different impeller sizes within a particular pump size.

Figure 11. Family of Pump Performance Curves

<!-- image -->

Figure 11. Family of Pump Performance Curves

## Pump Curves for Multiple Impeller Sizes.

Once a pump has been selected as roughly meeting the needs of the system, the specific performance curve for that pump must be evaluated. Often, impellers of several different sizes can be installed with it, and each impeller has a separate, unique performance curve. Figure 12 displays performance curves for each size of impeller. Also illustrated are iso-efficiency lines, which indicate how efficient the various impellers are at different flow conditions.

Sizing the impeller and the pump motor is an iterative process that uses the curves shown in Figure 12 to determine pump efficiency and performance over its anticipated operating range. For more information, see the fact sheet in this section titled Impeller Trimming.

##  Net Positive Suction Head

To prevent cavitation, centrifugal pumps must operate with a certain amount of pressure at the inlet. This pressure is defined as the net positive suction head (NPSH). There are two principal references to NPSH: (1) the available system pressure (NPSHA) at the inlet, which is a function of the system and the flow rate, and (2) the required pressure (NPSHR), which is a function of the pump and the flow rate. NPSHR is typically included on pump performance curves. If the NPSHA is sufficiently above the NPSHR, then the pump should not cavitate.

<!-- image -->

Figure 12.

Excessive cavitation affects pump efficiency and can potentially damage the pump.

As defined by the Hydraulic Institute, NPSHR is determined and plotted when the pump total head (or the first-stage head of a multistage pump) is reduced by 3% as a result of cavitation. Recently, the Hydraulic Institute has adopted the term NPSH3 to define the NPSHR qualified by this criterion. Further information can be found in ANSI/HI 1.6-2000-Centrifugal Tests (see Section 4). Most pumps can operate satisfactorily with a minimum margin above the NPSH3 value when operating near the BEP. But they will require a much higher NPSH margin to suppress all cavitation when operated at flow rates away from the BEP.

For satisfactory operation, the NPSHA margin over NPSHR must be provided by the system. A common rule in system design is to ensure that NPSHA is 25% higher than NPSHR for all expected flow rates. When oversized pumps operate in regions far to the right of their design points, the difference between NPSHA and NPSHR can become dangerously small.

##  Pump Speed Selection

Pump speed is usually an important consideration in system design. The pump speed is perhaps best determined by evaluating the effectiveness of similar pumps in other applications. In the absence

of such experience, pump speed can be estimated by using a dimensionless pump performance parameter known as specific speed. Specific speed can be used in two different references: impeller specific speed and pump suction specific speed. The impeller specific speed (N s ) is used to evaluate a pump's performance using different impeller sizes and pump speeds.

Specific speed is an index that, in mechanical terms, represents the impeller speed necessary to generate 1 gallon per minute at 1 foot of head. The equation for impeller specific speed is as follows:

<!-- formula-not-decoded -->

where

Ns =  specific speed

n =  pump rotational speed (rpm)

Q =  flow rate (gpm)

H =  total head per stage (ft).

For standard impellers, specific speeds range from 500 to 10,000. Pumps with specific speed values between 2,000 and 3,000 usually have the highest efficiency.

##  Example of Pump Selection

The data required to size and source a pump include system flow demands and the system's resistance curve. To determine the system curve, the required data include the system configuration, the total pipe length, the pipe size, and the number of elbows, tees, fittings, and valves. A designer can use these data-along with known fluid properties and the head available from the suction source-to estimate the system's head loss and its NPSHA at the pump suction.

At this point, the designer must review the manufacturers' data to find pumps that can meet system requirements. Unfortunately, this process requires repeated evaluations of many different pump characteristics, including the BEP, pump speed, NPSHR, and pump type. Using the expected system operating range, a designer must evaluate the family of performance curves, similar

Figure 13. Performance Curves for a 4x1.5-6 Pump Used for Water Service

<!-- image -->

to that shown in Figure 11, for each pump manufacturer to identify pumps that meet the service needs.

The next step is to evaluate the performance curves of each pump selected. Each pump usually has a range of performance curves for each impeller size offered with that pump. In addition to different stock impeller sizes, an impeller can be trimmed to further 'fine tune' a pump's performance (see the Impeller Trimming fact sheet).

In Figure 13, a 4x1.5-6 pump is used as an example. The design point is just below the curve for the 6-inch impeller. For this particular pump size, at these operating conditions, the pump efficiency is 74%, and the 5-hp motor appears strong enough to meet service requirements. The pump's BEP is just slightly to the right of the design point and the NPSHR is 6 ft. If the NPSHA is more than 7.5 ft, or at least 25% higher than the NPSHR, the 4x1.5-6 pump should be suitable.

##  Pump Manufacturer's Software

The complexity of pump selection has motivated most pump manufacturers to develop electronic selection catalogs. Using specific system requirements, these catalogs help designers identify pumps capable of meeting the end user's service needs.

Prospective customers enter known system characteristics such as head, flow, pipe size, NPSHA, and key fluid properties and the software generates a list of pumps suitable for the application.

The software contains performance data on each of the manufacturer's pumps for further analysis. Pump constraints, such as required pump speed, can also be used to further refine the list of candidate pumps. Although system performance concerns such as head/flow curve sensitivity and multiple pump configurations still require sound engineering judgment, the use of a pump manufacturer's software can simplify the pump selection process.

## Positive Displacement Pump Applications

The term positive displacement refers to the way in which these pumps pressurize and move fluid. Positive displacement pumps squeeze fluid by decreasing the volume that contains it. One type of positive displacement pump is a piston pump: every stroke pushes along a certain amount of fluid. An example of a rotary displacement pump is a screw pump, which uses two parallel, overlapping screws to push along a certain volume with each revolution.

##  Applications

Although positive displacement pumps have higher maintenance requirements than other types, they are inherently better suited for certain applications. These applications include the following:

- ■ High-Pressure/Low-Flow Applications. Positive displacement pumps are usually more effective in generating high pressures in low-flow applications. Although centrifugal pumps can be designed to generate high pressures-usually through the use of multiple stages-these special pumps tend to be comparatively expensive.
- ■ High-Fluid-Viscosity Applications. Positive displacement pumps are more effective than centrifugal pumps in moving viscous fluids. By directly pressurizing the fluids, positive displacement pumps lose less energy to the high shear stresses that are inherent in viscous fluids.
- ■ Accurately Controlled Flow Applications. Since each stroke or revolution generates a certain amount of flow, positive displacement pumps are typically used in applications requiring precise flow control. By controlling the number of pump cycles, positive displacement pumps are well suited for metered-flow applications.

In addition, many positive displacement pumps have certain unique characteristics that make them attractive. For example, positive displacement pumps are usually self-priming and can operate

## Related Tip Sheet

Related	information	is	available	in	an	ITP BestPractices	Tip	Sheet	titled Pump Selection Considerations .	Tip	sheets	can	be	found	in Appendix	C,	accessed	on	the	Web	at www.eere.energy.gov/industry/ bestpractices, or	obtained	by	contacting	the EERE	Information	Center	at	877-337-3463.

with entrained gases in the suction line. This feature allows system designers to place these pumps above the fluid level, which can simplify the system layout. Centrifugal pumps often require special system equipment to remove gases and prime the impeller. Although some centrifugal pumps are designed to be self-priming, they are also expensive, less reliable, and less efficientand gas must still be removed.

Certain positive displacement pumps-such as diaphragm and peristaltic types-do not require seals and thus do not leak. In systems that handle corrosive or hazardous fluids, eliminating the need for seal maintenance can yield substantial cost savings.

##  Special Considerations

Positive displacement pumps are usually installed with pressure relief valves. In fact, in many of these pumps, relief valves are internal to the pump. This protection is needed because the pumps push fluid into the discharge line irrespective of backpressure. Consequently, if the system flow becomes completely obstructed downstream of the pump, fluid pressure builds until the motor torque reaches an overload condition or until the piping or other equipment ruptures. Although relief valves are designed to protect against such damage, they require periodic testing and maintenance. A relief valve that fails to operate properly can cause costly system damage.

Positive displacement pumps also typically have pulsating flow characteristics. In some systems, these pulsations can create vibration problems, especially if the pulse rate has a harmonic component that coincides with the natural frequency of any piping or structure. Flow-induced piping vibrations create cyclic loading on piping welds and piping supports; they can also accelerate the loosening of mechanical joints. These vibrations can be dampened by using accumulators to absorb some of the vibrational energy.

Another consideration is the need for storage of spare parts. Because of the relatively high number of moving parts associated with many positive displacement pumps, some facilities have to maintain a large spare parts inventory. For example, mating surfaces on the internal valves of many reciprocating pumps are susceptible to wear and require periodic replacement.  Although these parts can be obtained from a manufacturer or parts supplier, plants often prefer to keep common replacement parts on hand to minimize downtime. Consequently, using pumps with a large number of moving parts can increase a plant's maintenance workload and inventory holding costs.

## Multiple Pump Arrangements

An alternative to using one pump to serve the requirements of a system is to use several smaller pumps in combination (parallel operation).

Wide variations in system demand preclude a single pump from consistently operating close to its best efficiency point (BEP). Operating a pump away from its BEP can result in higher operating and maintenance costs. In some systems, especially those with high static head requirements, energizing or de-energizing multiple pumps to meet demand changes allows each pump to operate more efficiently, improving overall system efficiency. However, this efficiency advantage depends on the pump curves, the system curve, and the demand change that is being met.

Some of the advantages of multiple pump arrangements are flexibility, redundancy, and the ability to meet changing flow needs efficiently in systems with high static head components. In systems with high-friction components, alternatives such as adjustable speed motors tend to be more efficient solutions to variable demand requirements.

Multiple pumps are usually parallel combinations of the same pump model. Placing an additional pump on line adds flow to the system and shifts the operating point to the right along the system curve (see Figure 14 on page 44).

Parallel pumps are usually identical, to provide balanced load-sharing when all the pumps are operating at the same time. Using different-sized pumps could result in a condition in which the largest pump dominates the system, forcing other pumps to operate below their minimum flow ratings. If different-sized pumps must be configured in parallel, their performance curves should be carefully reviewed to ensure that no pump operates below its minimum flow requirement.

##  Best Efficiency Point

Design characteristics for both performance and service life are optimized around a capacity designated as the best efficiency point (BEP).

## Related Tip Sheet

Related	information	is	available	in	an	ITP BestPractices	Tip	Sheet	titled Optimize Parallel Pumping Systems .	Tip	sheets	can	be	found	in Appendix	C,	accessed	on	the	Web	at www. eere.energy.gov/industry/bestpractices ,	or obtained	by	contacting	the	EERE	Information Center	at	877-337-3463.

Every centrifugal pump has a BEP-the point at which its operating efficiency is highest and its radial bearing loads are lowest. A pump's BEP is a function of its inlet configuration, impeller design, casing design, and pump speed. At the BEP, the hydraulic efficiency is at its maximum, and the liquid enters the impeller vanes, casing diffuser (discharge nozzle), or vaned diffuser in a shockless manner. Flow through the impeller and diffuser vanes (if the pump is so equipped) is uniform, free of separation, and well controlled. The flow remains well controlled within a range of capacities designated as the preferred operating region (POR) . Within this region, the service life of the pump will not be affected significantly by hydraulic loads, vibration, or flow separation. The allowable operating region (AOR) defines the precise limits for minimum and maximum flow in a pump.

Most centrifugal pumps are equipped with roller or ball bearings. Since the operating life of these types of bearings is an inverse function of the cube of the load, selecting a pump with a BEP that is close to the system's normal operating range significantly extends the interval between bearing replacements.

##  Advantages of Multiple Pump Arrangements

There are many advantages to using combinations of smaller pumps rather than a single large one. These advantages include operating flexibility, redundancy in case of a pump failure, lower maintenance requirements, and higher efficiency.

Operating Flexibility. As shown in Figure 14, using several pumps in parallel broadens the range of flow that can be delivered to the system. (Note that Figure 14 is illustrative and does not represent actual pump curves.) In addition, energizing and de-energizing pumps keeps the operating point of each one closer to its BEP (for systems with flat curves). Operators should use caution when operating parallel pumps, however, to ensure that the minimum flow requirement is met for each pump.

<!-- image -->

Redundancy. With a multiple pump arrangement, one pump can be repaired while others continue to serve the system. Thus, the failure of one unit does not shut down the entire system.

Maintenance. Multiple pump configurations allow each pump to be operated close to its BEP (for systems with flat curves), which reduces bearing wear and permits the pumps to run more smoothly. Other benefits include less reliance on energy-dissipating flow control options such as bypass lines and throttle valves. The use of a single, large pump during low-flow demand conditions forces the excess flow to be throttled or bypassed. Throttling the flow wears the throttle valves and creates energy losses. Similarly, bypassing the flow is highly inefficient, since all the energy used to push the excess flow through the bypass lines is wasted. Variable speed drives can also be an efficient solution.

Efficiency. A potential advantage of using multiple pumps is higher overall efficiency, since each pump can operate close to its BEP (for systems with flat curves). Energizing or de-energizing pumps as needed to meet changes in system demand allows each pump to operate over a smaller region of its performance curve-ideally, around the BEP. A single pump would have to operate over a larger range, and thus farther away from its BEP at times.

At a given head and flow, high-speed pumps tend to be more efficient than low-speed pumps. Pumps with specific speed values greater than 3,000 are the exception; they tend to be less efficient at higher speeds. However, this is not typical of most pumps. Since smaller pumps require smaller motors, the use of multiple highspeed pumps can provide an efficiency advantage over a single, low-speed pump. However, this efficiency advantage should be balanced against the tendency of high-speed machines to require more maintenance.

##  Other Options

Other system designs that can be used to handle widely varying operating conditions include pony pumps, multiple-speed pumps, and variable frequency drives (VFDs). For more information on pony pumps, see the fact sheet titled Pony Pumps . Information on VFDs is found in the fact sheet in this section titled Controlling Pumps with Adjustable Speed Drives .

Multiple-speed pumps can be used in similar ways, in that the fluid power generated can be matched to the demands of the system. Shifting a pump to higher or lower speeds moves the entire performance curve up or down, respectively, as shown in Figure 15. (Note that Figure 15 is illustrative and does not represent an actual pump curve.)

Although multiple-speed pumps tend to perform less efficiently at any given operating point than

Figure 15. Multiple-Speed Pump Performance Curves

<!-- image -->

single-speed pumps do, their ability to operate over a wide range of conditions is a key advantage. Multiple-speed pumps are also space-savers; their compact operating package avoids the additional piping and valves required for parallel pumps.

## Pony Pumps

Pumping systems have a wide range of flow needs. In many applications, there is a large difference between the flow required during normal system operation and that required during peak load conditions. For example, some cooling system and rainwater collection applications require a relatively low flow rate. Occasionally, however, a heavy storm or a large heat load caused by a sudden increase in production demand creates a need for greater pumping capacity.

If pumps are sized to handle a peak flow or worstcase conditions, they could operate at substantially less efficient levels for long periods during times of high demand. Oversized pumps in applications like these tend to waste energy, and they require frequent maintenance because they operate far from their best efficiency points.

In applications such as sewage treatment plants, the normal operating demands on pumps may be relatively low. During storms, however, the amount of fluid that must be drained from holding ponds or tanks increases dramatically. So pumps that maintain holding pond levels must be able to handle storm conditions.

To avoid the high friction losses and maintenance problems that accompany continuous operation or frequent starts of oversized pumps, a plant can install smaller ones, called 'pony pumps,' to handle normal operating conditions. The large pumps would then be used occasionally only to handle severe load conditions, providing considerable cost savings.

##  When To Consider Pony Pumps

Indicators of a need for a smaller pump to handle normal operating conditions include the following:

- ■ Intermittent pump operation
- ■ Excessive flow noise, cavitation, and piping vibrations that disappear during heavy demand periods. (If these conditions persist, then the primary pump may need to be downsized.)

## Related Tip Sheet

Related	information	is	available	in	an	ITP BestPractices	Tip	Sheet	titled Optimize Parallel Pumping Systems. Tip	sheets	can	be	found	in Appendix	C,	accessed	on	the	Web	at www. eere.energy.gov/industry/bestpractices, or obtained	by	contacting	the	EERE	Information Center	at	877-337-3463.

##  Costs of Intermittent Pump Operation

Intermittent pump operation is caused by an unbalanced set of system flows. For example, a pump's high flow rate drains the tank or reservoir to the point where the low-level switch deenergizes or turns off the pump. When the fluid level in the tank rises and activates the high-level switch, the pump is re-energized, turning back on to drain the tank (see Figure 16 on page 48).

Repeatedly stopping and restarting a pump wears out the motor controllers and dynamic surfaces in the pump/motor assembly, and it can lead to unreliable pump operation. This problem is especially severe for large pumps, because of their high starting currents. Each repeated closing and opening of high-voltage contacts also creates a danger of sparking that can damage the contact surfaces. In addition, discontinuous loading of the transformers and switchgear often shortens their operating lives. Some pump/motor assemblies are specially designed to handle repeated starting and stopping. For such applications, this more expensive type of equipment should be specified.

Many pumps do not respond well to start-ups and shutdowns. The mechanical seals used in many pumps rely on a lubricating film of system fluid. This film requires a revolution or two to develop and, over time, repeated start-ups accelerate seal wear. Similarly, bearings that are subjected to cyclical loading tend to have shorter operating lives than those in constant-use applications.

<!-- image -->

##  Costs of High Flow Velocity

An additional penalty for using an oversized pump is the added friction losses which occur during pump operation. Higher flow rates create higher flow velocities which, in turn, lead to higher friction loss. The relationship between velocity and friction loss is provided by the Darcy-Weisbach equation:

<!-- formula-not-decoded -->

where h f = head loss

f

= pipe friction coefficient

V  = fluid velocity g  = gravitational constant

D  = inner diameter of the pipe

L = length of pipe.

The V 2  term shows that pressure loss through a pipe is proportional to the square of the fluid velocity. Consequently, given the same size pipe, a flow rate that is two times higher endures four times more friction loss. This means that it costs much more to pump a gallon of fluid at a higherthan-necessary flow rate.

##  Recovering the Costs of Installing a Smaller Pump

Installing a smaller pump to run parallel to an existing one can provide substantial energy and maintenance cost savings. A simple economic analysis can demonstrate the cost of current power consumption and maintenance intervals in comparison to the capital cost and projected savings associated with operating a smaller, more efficient pump.

Energy-saving alternatives to a pony pump include reducing the impeller size, replacing the existing pump/motor assembly with a smaller one, and installing an adjustable speed drive (ASD) on the pump motor. Depending on the requirements of the application, impeller adjustments and the smaller pump/motor assembly could compromise the capacity of the existing pump during worstcase situations. Although ASDs in general allow a pump to run at lower capacity, variable frequency drives (VFDs) are more suitable for varying demand rather than for continuously low demand.

The VFDs themselves introduce efficiency losses. If normal operation is far below the full load rating of the motor for long operating periods, the cost of these losses can be considerable. A VFD can also introduce harmonics in the motor windings, which increases the winding temperature. Over an extended period of time, this increase in the motor winding temperature accelerates the breakdown of insulation. For more information on VFDs, see the fact sheet in this section titled Controlling Pumps with Adjustable Speed Drives .

A project undertaken by the city of Milford, Connecticut, provides a practical example of the successful use of a pony pump. By adding a pony pump to the city's Welches Point Sewage Lift station, Milford realized substantial energy savings and reduced maintenance costs. This project is described in a case study, Saving Energy at a Sewage Lift Station Through Pump System Modifications , available on DOE's Industrial Technologies Program BestPractices Web site ( www.eere.energy.gov/industry/bestpractices/ motors.html ) or from the EERE Information Center at 877-337-3463.

## Impeller Trimming

Impeller trimming refers to the process of machining the diameter of an impeller to reduce the energy added to the system fluid. Impeller trimming can be a useful correction to pumps that, through overly conservative design practices or changes in system loads, are oversized for their application.

Trimming an impeller represents a level of correction slightly less effective than buying a smaller impeller from the pump manufacturer. In many cases, an impeller at the next smaller size than the original would be too small for the pump load. And in some cases, smaller impellers might not be available for the pump size in the application, so impeller trimming is the only practical alternative short of replacing the entire pump/motor assembly.

##  When To Consider Impeller Trimming

End users should consider trimming an impeller when any of the following conditions occur:

- ■ Many system bypass valves are open, indicating that excess flow is available to system equipment
- ■ Excessive throttling is needed to control flow through the system or process
- ■ High levels of noise or vibration indicate excessive flow
- ■ A pump is operating far from its design point.

Figure 17. Effect of Impeller Trimming on Pump Performance

<!-- image -->

## Related Tip Sheet

A	summary	of	key	issues	presented	in	this fact	sheet	is	available	in	an	ITP	BestPractices Tip	Sheet	titled Trim or Replace Impellers on Oversized Pumps. Tip	sheets	can	be	found	in Appendix	C,	accessed	on	the	Web	at www. eere.energy.gov/industry/bestpractices, or	obtained	by	contacting	the	EERE	Information Center	at	877-337-3463.

##  Why Impeller Trimming Works

Impeller trimming reduces tip speed, which in turn directly reduces the amount of energy imparted to the system fluid and lowers both the flow and pressure generated by the pump (see Figure 17; note that this figure is illustrative and does not represent an actual pump curve). The affinity laws, which describe a centrifugal pump's performance, provide a theoretical relationship between impeller size and pump output (assuming constant pump speed):

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

where

Q  =  flow

H  =  head bhp  =  brake horsepower of the pump motor (bhp  refers to the original pump, 1 bhp2 to the pump after impeller trimming)

D  =  diameter.

In practice, these relationships are not strictly accurate because of nonlinearities in flow; however, the fundamental effect of impeller trimming on flow, head, and bhp holds. For

example, a 2% reduction in the impeller diameter creates about a 2% reduction in flow, a 4% reduction in head, and an 8% reduction in power. This relationship should be used as an approximation for small changes. The final result of trimming depends on the system curve and pump performance changes

##  Benefits of Impeller Trimming

A principal benefit of reducing the size of the impeller is the resulting decrease in operating and maintenance costs. Less fluid energy is wasted in the bypass lines and across throttle valves, or dissipated as noise and vibrations through the system. Energy savings are roughly proportional to the cube of the diameter reduction. This is shown in the fluid power equation discussed in Section 1 (page 9):

<!-- formula-not-decoded -->

The motor power required to generate this fluid power is higher because of motor and pump inefficiencies.

In addition to energy savings, impeller trimming also reduces wear on system piping, valves, and piping supports. Flow-induced piping vibrations tend to fatigue pipe welds and mechanical joints. Over time, welds crack and joints loosen, causing leaks and downtime for repairs.

Excessive fluid energy is also not desirable from a design perspective. Pipe supports are usually spaced and sized to withstand static loads from the weight of the pipe and the fluid, pressure loads from the internal system pressure, and-in thermally dynamic applications-expansion caused by changes in temperature. The vibrations created by excessive fluid energy provide a load that the system is not designed to handle and lead to leaks, downtime, and additional maintenance.

For a practical example of how impeller trimming lowers maintenance requirements, see the case study titled Optimized Pump Systems Save Coal Preparation Plant Money and Energy .

It is available on DOE's Industrial Technologies Program BestPractices Web site ( www.eere.energy. gov/industry/bestpractices/motors.html ) or through the EERE Information Center at 877-337-3463.

##  Limitations

Trimming an impeller changes its operating efficiency, and the nonlinearities of the affinity laws with respect to impeller machining complicate predictions of a pump's performance. Consequently, impeller diameters are rarely reduced below 70% of their original size.

In some pumps, impeller trimming increases the pump's required net positive suction head (NPSHR). To prevent cavitation, a centrifugal pump must operate with a certain amount of pressure at its inlet, the NPSHR. To reduce the risk of cavitation, the effect of impeller trimming on NPSHR should be evaluated using the manufacturer's data over the full range of operating conditions. For more on NPSH, see the fact sheet in this section titled Centrifugal Pumps .

## Controlling Pumps with Adjustable Speed Drives

Centrifugal pumps are often operated over a wide range of conditions. For example, many cooling systems experience variable loads caused by changes in ambient conditions, occupancy, and production demands. To accommodate demand changes, flow can be controlled by any of these four methods: bypass lines, throttle valves, multiple pump arrangements (as discussed in the previous fact sheet), or pump speed adjustments.

## Related Publications

##  Bypass Lines

Bypass lines provide accurate flow control while avoiding the danger of 'deadheading' a pump. Deadheading is the condition in which a pump's flow is completely choked off by closed downstream valves. Unfortunately, bypassing flow is usually the least energy-efficient flow control option.

##  Throttle Valves

Throttle valves provide flow control in two ways: by increasing the upstream backpressure, which reduces pump flow, and by directly dissipating fluid energy. By increasing the backpressure on a pump, throttle valves make a pumping system less efficient. In low-static-head systems, variable speed operation allows the pump to run near its best efficiency point (BEP) for a given head or flow.

##  Pump Speed Adjustments

Pump speed adjustments are the most efficient means of controlling pump flow. Reducing the pump speed means less energy is imparted to the fluid and less energy needs to be throttled or bypassed. There are two primary ways of reducing the pump speed: using multiple-speed pump motors and using adjustable speed drives (ASDs). Although both directly control the pump's output, multiple-speed motors and ASDs serve entirely separate applications.

Multiple-speed motors contain a different set of windings for each motor speed; consequently, they are more expensive and less efficient than singlespeed motors. Multiple-speed motors also lack

Related	information	is	available	in	a	EuropumpHydraulic	Institute	publication, Variable Speed Pumping: A Guide to Successful Applications , as	well	as	in	two	ITP	BestPractices	Tip	Sheets, Adjustable Speed Pumping Applications and Control Strategies for Centrifugal Pumps with Variable Flow Rates .	To	obtain	the	pumping guide,	see	the	Hydraulic	Institute's	Web	site, www.pumps.org ,	or	call	973-267-9700. Tip	sheets	can	be	found	in	Appendix	C, accessed	on	the	Web	at www.eere.energy. gov/industry/bestpractices, or	obtained	by contacting	the	EERE	Information	Center	at 877-337-3463.

subtle speed-changing capabilities within discrete speeds.

In contrast, ASDs allow pump speed adjustments to be made over a continuous range, avoiding the need to jump from speed to speed. ASDs control pump speeds using several different types of mechanical and electrical systems. Mechanical ASDs include hydraulic clutches, fluid couplings, and adjustable belts and pulleys. Electrical ASDs include eddy current clutches, wound-rotor motor controllers, and variable frequency drives (VFDs). VFDs adjust the electrical frequency of the power supplied to a motor to change the motor's rotational speed. VFDs are by far the most popular type of ASD.

Pump speed adjustments are not appropriate for all systems, however. In applications with high static head, slowing a pump could induce vibrations and create performance problems that are similar to those found when a pump operates against its shutoff head. For systems in which the static head represents a large portion of the total head, however, operators should use caution in

<!-- image -->

deciding whether to use ASDs. Operators should review the performance of ASDs in similar applications and consult ASD manufacturers to avoid the damage that can result when a pump operates too slowly against high-static-head conditions.

##  Pump Operating Efficiency Improvements

For many systems, VFDs can help to improve pump operating efficiency despite changes in operating conditions. The effect of slowing pump speed on pump operation is illustrated by the three curves in Figure 18. When a VFD slows a pump, its head/flow and brake horsepower (bhp) curves drop down and to the left, and its efficiency curve shifts to the left. This efficiency response provides an essential cost advantage; keeping the operating efficiency as high as possible across variations in the system's flow demand can reduce the energy and maintenance costs of the pump significantly. VFDs can also be used with positive displacement pumps.

##  System Operating Efficiency Improvements

VFDs can provide operating cost reductions by increasing a pump's operating efficiency. However, the majority of savings derive from the reduction in frictional or bypass flow losses.

Using a system perspective to identify areas in which fluid energy is dissipated in nonuseful work often reveals opportunities for reducing operating costs. For example, in many systems, increasing flow through bypass lines does not have a noticeable impact on the backpressure on a pump. Consequently, in these applications, pump efficiency does not necessarily decline during periods of low flow demand. However, analyzing the entire system allows operators to identify the energy lost in pushing fluid through bypass lines and across throttle valves. Figure 19 depicts energy losses attributable to bypass valve operation; Figure 20 depicts energy losses attributable to throttling. (Note that Figures 19 and 20 are illustrative and do not represent actual pump curves.)

<!-- image -->

Figure 19. Power Lost through a Bypass Line

<!-- image -->

One major benefit of VFDs is that they can reduce energy losses by lowering the overall system flow or head. By slowing down the pump and reducing the amount of fluid energy imparted to the system when it is not needed, VFDs offer substantial savings with respect to the cost per gallon of liquid pumped. Another system-related benefit is that VFDs provide a soft-start capability. During start-up, most motors experience in-rush currents that are 5 to 6 times higher than normal operating currents. This high current fades when the motor achieves normal speed.

VFDs allow the motor to be started with a lower start-up current-usually only about 1.5 times the normal operating current. This reduces wear on the motor and its controller.

##  Maintenance Requirements

As added system equipment, VFDs require maintenance and repairs. However, in many applications, VFDs lower the maintenance requirements for the pump, system piping, and components. The principal factors behind these maintenance savings are the reduced load on the pump and the lower static and dynamic fluid forces imparted to the system.

By reducing a pump's operating speed, a VFD often shifts the BEP to the left of the BEP corresponding to the pump's normal operating speed. In these cases, since the bearing loads on a pump are lowest when the pump is operating at its BEP, this shift of the BEP during periods of low flow allows the pump to operate with lower bearing loads and less shaft deflection. Most pump bearings are roller- or ball-type; their design operating life is a function of the cube of the load. Consequently, using a VFD can extend the interval between bearing maintenance tasks.

In addition, VFDs reduce stress on pipes and piping supports. When the system flow far exceeds equipment demands, excess fluid energy is dissipated in the form of noise and vibration. Vibrations help to loosen mechanical joints and cause cracks in the welds in pipes and pipe hangers. By reducing the fluid energy, VFDs lessen system wear. For more information on indications of excessive system flow and ways to correct it, see the fact sheet in this section titled Indications of Oversized Pumps.

##  Limitations of VFDs

Although using VFDs can help to reduce operating and maintenance costs, they are not appropriate for all applications. As a pump's speed decreases, it generates less pressure. In high-static-head applications, the use of VFDs can slow a pump down so that it operates at or near shut-off head conditions. The pump thus experiences the same harsh conditions that the manufacturer attempts to guard against when setting a minimum flow rate, which usually corresponds to the pump's rated speed. The consequences include greater shaft deflection, high vibration levels, and high bearing loads.

Power quality can also be a concern. VFDs operate by rectifying the alternating current (ac) line power into a direct current (dc) signal, then inverting and regulating this signal into ac power that is sent to the motor. Often, the inverter creates harmonics in the power supplied to the motor. These harmonics can cause motor windings to operate at higher temperatures, which accelerates wear in insulation. To account for the added winding heat, motors are typically derated 5% to 10% when used with VFDs. A classification of motors known as 'inverter-duty' has been developed to better match VFDs with motors.

In some electrical systems, the harmonics created by the inverter can be picked up by other electrical lines that have common connections with the VFD. Systems that are sensitive to minor disturbances in power supply should be served separately from the VFD power supply.

In some applications, VFDs contribute to reduced bearing life. The interaction between the three phases of the power supply from a VFD inverter sometimes induces a small voltage across the motor bearings. As a result, these bearings can experience pitting and accelerated wear. VFD

manufacturers are familiar with this problem, and several methods can be used to correct it. These methods include insulating certain bearings, grounding the shaft, and conditioning the power supply.

Finally, anticipated energy savings are not realized in some applications because some of the losses associated with VFD installation were not taken into consideration. The VFDs themselves are approximately 95% to 97% efficient, and motor efficiency generally begins to decrease at less than 75% of full load. In addition, the quality of electric power supplied to the motor can affect both its efficiency and its power rating.

Although VFDs are an attractive option in many applications, all these considerations should be incorporated into a feasibility study before VFDs are installed.

## Section 3:  The Economics of Improving Pumping Systems

## Overview

## Conduct a Systems Assessment

Pumping systems can be critically important to a plant's operations. In many industrial applications, such as power and petrochemical plants, pumps directly support production processes and run as often as-or even longer than-any other equipment at the facility. The amount of energy consumed by many long-running pumping systems often results in a substantial addition to a plant's annual operating costs. In fact, about 27% of all the energy consumed by motor-driven equipment in manufacturing facilities is used to operate pumps.   Therefore, pumping systems 3 are a natural target in efforts to reduce energy consumption in motor-driven systems.

In some cases, pumping system energy is used quite efficiently; in others, it is not. Facility operators are often very familiar with the controllability, reliability, and availability of pumping system equipment, but they might not be as aware of system efficiency issues-and there are good reasons to increase their awareness. For example, there is a strong correlation between the reliability of pumps and their ef ficiency; that is, pumps that operate close to their best efficiency point tend to perform more reliably and with greater availability.

There are numerous opportunities to improve the reliability, performance, and efficiency of pumping systems in many industrial facilities. This section discusses three basic steps that can help in identifying and implementing pumping system improvement projects:

- ■ Conduct a systems assessment
- ■ Analyze life-cycle costs before making a decision

A systems assessment reviews the operation of a pumping system, often using certain tools to help identify improvement opportunities. Taking a systems approach can be a very effective way to perform the assessment. Consequently, DOE seeks to build industry's awareness of this approach in many key industrial systems, including pumping. The Hydraulic Institute's Pump Systems Matter TM initiative also promotes a systems approach to pumping system assessments.

##  A Systems Approach

A systems approach can be effective in assessing system performance, solving operating problems, and finding improvement opportunities. In a systems approach, engineers and operators analyze both the supply and demand sides of the system and how they interact, essentially shifting the focus from the performance of individual components to that of the system as a whole. In attempting to correct problems or look for ways to improve performance, evaluating only the components rather than the whole system can cause analysts to overlook potential cost savings.

For example, although a pump might be operating efficiently, it could be generating more flow than the system requires. Consequently, it is important to assess system efficiency based on how well the end uses are served by the pumps. Reflecting a systems approach, process system design and manufacturing best practices will first optimize the performance of the entire system and then select the components and control strategies that best match the new process load.

##  Pumping System Assessment Tool (PSAT)

- ■ Sell your projects to management.

DOE studies show that almost two-thirds of the potential energy savings for motor systems

3 United States Industrial Electric Motor Systems Market Opportunities Assessment , DOE/GO-102000-959, U.S. Department of Energy, 1998; see www.eere.energy.gov/bestpractices/ .

involve system optimization. Therefore, DOE's Industrial Technologies Program has developed prescreening guidance documents and assisted in developing a computer-based Pumping System Assessment Tool (PSAT). It is intended to help end users, consultants, and equipment distributors recognize, both qualitatively and quantitatively, opportunities to improve pumping system efficiency. PSAT software can be used to estimate the efficiency of a system based on specific input; accurate field measurements are required.

For example, the usefulness of the input for pressure depends on taking an exact reading along a section of pipe; it also depends on whether the pressure is measured upstream or downstream of a throttling valve. Users must therefore understand their system or process demands to make reasonable use of PSAT. The software relies on all of the following:

- ■ Fundamental electrical, mechanical, and fluid power relationships
- ■ Typical performance characteristics from industry standards and databases
- ■ Field measurements of fluid and electrical parameters.

PSAT estimates the efficiency of an existing motor and pump using field measurements and nameplate information. It also estimates achievable efficiencies if the motor and pump were optimally selected to meet specified flow and head requirements. The software then compares the two results and determines potential power savings. Finally, PSAT estimates potential cost and energy savings, based on user-specified utility rates and operating times.

(flow rate, head, and fluid specific weight) are known, pump efficiency can also be determined.

## Performance Characteristics of Motors. DOE's

Industrial Technologies Program distributes MotorMaster+ software 4  free of charge. Part of the underlying supporting structure for MotorMaster+ is an extensive database of motors. The database, constructed using data supplied by motor manufacturers, includes a fairly comprehensive list of parameters such as motor rated power, efficiency, power factor, speed, full-load current, enclosure style, NEMA design type, rated voltage, and price.

After it was filtered to ensure a homogeneous, representative motor population, this database was used to develop the algorithms used in PSAT. The database was first limited to include only 460-V, NEMA Design B motors, the design type used on most pumps. Next, the database was sorted and classed according to rated power and number of poles, and filtered to exclude inconsistent entries. The motors were then classified as either standard or energy efficient, based on the efficiency standards of NEMA MG 1-2003. 5

After the developers categorized the motor population by size, speed, and efficiency class, they established average performance characteristics (current, power factor, and efficiency versus load). Using these average values, they created curve fits of the performance characteristics.

Fundamental Power Relationships. Motor input power can be measured in the field on low-voltage (e.g., 480-V) busses. With directly coupled equipment, the motor shaft power and the pump shaft power are equal, practically speaking. Pump efficiency is then the ratio of fluid power to shaft power. So, if the parameters that define fluid power

Motor performance can, of course, vary within a given power, speed, and efficiency class. But relative to other uncertainties surrounding pumping system field measurements, variability in the motor data is relatively small. There are, however, many interdependencies in motor performance characteristics. For example, efficiency and current are functions of motor size, number of poles (speed), load, and voltage, among others.

4 For more on the MotorMaster+ software program, see www.eere.energy.gov/industry/bestpractices/

.

5 NEMA MG 1-2003, Section II, Part 12, Table 12-11, 'Full-Load Efficiencies of Energy Efficient Motors.'

MotorMaster+ allows motor efficiency to be estimated based on the motor's size, speed, and either motor input power or current measurements. If power is measured, PSAT determines the shaft power and efficiency that is consistent with the specified motor size and speed. If current is measured, power is estimated from current versus load profiles in PSAT. A full set of motor characteristics (shaft power, current, power factor, and electrical power) can be established, regardless of whether current or power is measured.

Although the motor characteristics used in PSAT were derived exclusively from 460-V motors, the user can select from other nominal voltages, such as 230, 2300, 4160, and 6900 V. The current data is linearly adjusted for nominal voltage. The user also selects from one of three motor efficiency classes: energy-efficient, standard efficiency, and average. If the user selects average, PSAT simply calculates motor performance characteristics based on the average of the standard efficiency and the energy-efficient motor values. Most motors used on pump systems are NEMA Design B.

Performance Characteristics of Pumps. Many different pump designs can be applied to the broad spectrum of pumping applications. For certain applications, such as sewage or stock pumping, service reliability considerations prevent the use of more efficient designs that are used in clean water pumping. For example, the narrow channels used in some high-efficiency impellers might clog if used to pump sewage.

PSAT software uses curve fits of the graphical data included in the HI standard to estimate achievable efficiency. However, it automatically completes the three-step series of actions described earlier.

Based on the input data, PSAT first estimates the existing shaft power from the motor data measurements. It then calculates fluid power from the specified flow rate, head, and specific gravity. At this point, the motor input power, the shaft power, and the fluid power are known, as are the existing motor and pump efficiencies. Given the fraction of time the pump is operated and the electricity cost rate, PSAT also calculates annual energy use and energy costs.

## Field Measurements of Fluid and Electrical

Parameters. Individual motor input power is not usually monitored by permanently installed instruments. Individual motor current is sometimes monitored and displayed at the motor control center or remotely, but usually only for larger motors. Motor input power and/or current can be measured on low-voltage (e.g., 480-V) busses with portable test equipment.

Generally speaking, the fluid viscosity and specific gravity are either essentially constant or they can be readily determined. This determination is made either by direct measurement or from their relationship to some other easily measured parameter, such as temperature.

The Hydraulic Institute (HI) has published a standard 6 that provides guidance on achievable efficiencies. The standard addresses the effects of general pump style, capacity, specific speed, and variability in achievable efficiency from miscellaneous other factors such as surface roughness and internal clearances. The HI standard walks the user through a series of steps, starting with reading a graph to determine efficiency at an optimum specific speed for the selected pump style and flow rate.

Most pump applications include suction and discharge connections for pressure measurementthe most important parameters in pump head calculation. Static head can be readily determined from system drawings, linear measurements, and/ or pressure/level gauges.

Permanently installed instrumentation is used to measure the flow rate in some applications, but it is less commonly available than pressure. When permanent flow rate instruments are not available, temporary test devices can be employed.

6 Hydraulic Institute, ANSI/HI 1.3-2000. For this and other HI standards, see www.pumps.org .

Alternatively, flow rate can be estimated using the measured differential pressure and pump performance curves. This method of estimating the flow rate is not the preferred approach, but in some cases it is the only one available. In many cases, other sources of data can help corroborate or refine flow rate estimates. When using pump performance curves, be sure to measure actual speed. If it is significantly different from the speed at which the curve was developed, adjust the curve using pump affinity laws.

##  Pumping System Energy Costs

To properly evaluate pumping system projects, system operating costs must be quantified; these costs generally include several fixed and variable components. Of these costs, energy is often the largest component. Tools such as PSAT can provide guidance in estimating energy costs and the potential to reduce them. However, other methods can be used to help the user estimate the amount of energy used and the associated cost of this energy. The following sections describe some of these alternative methods.

##  Load Factor

A pump's economics is largely determined by the amount of time that a pump operates and the percentage of full capacity at which it operates. Regardless of how pumping system energy use is measured at any point in time, this 'snapshot' data must be translated to a representative indication of energy use over time. Then, the pumping system's average load factor can be estimated. The term load factor refers to the average percentage of full-load power at which the pump operates over a period of time.

(Actual load ∑ x number of operating hours at this load) Load factor  = (Rated full load x number of operating hours in the period)

Unless operators maintain comprehensive records or are highly familiar with pump operating data, however, it might be difficult to determine the load factor accurately; instead, it might be necessary to rely on a reasonable estimate. If the pump is at full load whenever it is operating, the load factor is just the percentage of time the pump operates within the time period.

##  Calculating Electricity Costs

Electricity costs can be determined by several methods, including any of the following:

- ■ The use of motor nameplate data
- ■ Direct measurement of motor current
- ■ The use of performance curve data.

With any of these methods, the usefulness of the data is limited by the extent to which it represents average system operating conditions. In systems with widely varying operating conditions, taking data just once will probably not provide a true indication of pumping system energy consumption.

Nameplate Data. A quick way to determine energy costs is to use the pump motor nameplate data. In many applications, the pump/motor assembly is oversized, which means the motor operates below its full-load nameplate data. Estimating the load factor allows the pump's annual operating costs to be calculated.

## Simple Calculation

Annual	electricity	costs	= (0.746	kW/hp)	/	(motor	efficiency)	x	(annual	hours

(motor	full-load	brake	horsepower	[bhp])	x of	operation)	x	(unit	electricity	cost)	x	(load	factor)

Use	the	following	data	to	illustrate	this	calculation:

- ·	 Motor	full-load	brake	horsepower	=	100	bhp
- ·	 Annual	hours	of	operation	=	8,760	hours (3-shift,	continuous	operation)
- ·	 Unit	electricity	cost	=	$0.05/kWh
- ·	 Load	factor	=	65%
- ·	 Motor	efficiency	=	95%

(100	hp)	x	(0.746	kW/hp)	x	(1/0.95)	x	(8,760	hours)

Annual	electricity	costs	= x	($0.05/kWh)	x	0.65 Annual	electricity	costs	=	$22,356

Other data needed include annual hours of operation (hours/year) and the unit cost of electricity ($/kWh). The unit cost of electricity is an average value that includes both consumption

and demand costs. Annual electricity costs can be calculated by inserting this information into the equation in the simple calculation shown in the box on page 58.

This simple calculation assumes that the electric motor driving the pump is 95% efficient (the 0.95 in the 1/0.95 factor), which is a reasonable estimate for a pump motor larger than 50 hp. Newer motors may have even higher efficiencies because of provisions of the Energy Policy Act that have been in effect since 1997. If the pump uses an older motor that has been rewound several times or has a smaller motor, then a motor efficiency of 80% to 90% (or the motor nameplate efficiency rating) should be used. The motors used on most centrifugal pumps have a 1.15 continuous service factor. This means that a motor with a nominal nameplate rating of 100 bhp could, in fact, be operated continuously up to 115 bhp, although motor efficiency drops slightly above the rated load. Using nameplate data to calculate energy costs for motors that operate above the rated load will understate the actual costs.

Direct Measurement Method. A more accurate way to determine electricity consumption requires taking electrical measurements. Depending on the availability of instrumentation and measurement access, the direct measurement method requires reading power (kW) with a wattmeter or reading amps and volts and calculating kW using the nameplate power factor.

Wattmeters require two simultaneous inputs (voltage and current), and many motor installations do not offer convenient access to both. To calculate electricity consumption, multiply the measured kW value by the hours of operation and electricity costs, as shown in the calculation for Case I in the box on this page titled 'Direct Measurement.' This calculation is for a motor with a constant load-i.e., one that does not vary over time.

If a wattmeter is not available, or if using a wattmeter is not practical, then amps and volts can be measured separately. If there is a possibility that the motor load is less than

## Direct Measurement

## Assumptions:

3-phase	motor 0.85	power	factor	(nameplate) $0.05/kWh	unit	electricity	cost (3-shift,	continuous	operation)

Annual	hours	of	operation	=	8,760	hours

## Case I. Using a wattmeter

Annual	electricity	costs	= (wattmeter	reading,	using	a	3-phase	setting)	x (annual	hours	of	operation)	x	(electricity	cost	in	$/kWh)

For	example:	Wattmeter	reading	=	77.88	kW

Annual	electricity	costs	= (77.88	kW)	x	(8,760	hours)	x	($0.05/kWh) =	$34,111

## Case II. Using a voltmeter and an ammeter separately

Annual	electricity	costs	= [(load	amps)	x	(volts)	x	(1.732)	x (power	factor)/1,000)]	x	(annual	hours	of operation)	x	(electricity	cost	in	$/kWh)

For	example:	Average	load	amp	measurement	across all	phases	=	115	A

Measured	voltage	=	460	V

Annual	electricity	costs	= [(115	A)	x	(460	V)	x	(1.732)	x	(0.85)/1,000)]

x	(8,760	hours)	x	($0.05/kWh)	=	$34,111

65% of the motor's rated capacity, then calculations using direct measurement of volts and amps will not provide useful results.

Current is measured by using a clamp-on type ammeter. The current is measured on each of the three power cables running to the motor (most industrial motors are three-phase). At some sites, the motor controller is a convenient point at which to take these readings; at other sites, the connection box on the motor itself is more accessible. Line voltage is usually measured at the motor controller and should be measured at the same time as the current reading; in some

facilities, line voltage drops with increases in power usage. A calculation example is shown in Case II in the box titled 'Direct Measurement.' This calculation is also for a motor with a constant load.

Direct measurement of motor current is not always practical, however. Hot measurements of motor current pose safety risks for workers, and these measurements might not be feasible in an industrial environment where power connections are exposed to moisture or contaminants.

Using Pump Curves. Another method of determining a pump's power consumption is to record the pressure readings associated with the pump's operation and use its performance curve to determine the corresponding brake horsepower. Pump performance curves use total head to indicate the pump output; consequently, this method requires pressure instrumentation on the suction and discharge sides of a pump and correction for the velocity head.

Once the pressure on the discharge and suction sides of a pump are known, the engineer can calculate the total head developed by the pump. This corresponds to a horsepower reading, as shown in Figure 21.

To calculate annual energy costs, see the box on page 61 titled 'Using a Pump Performance Curve to Determine Annual Electricity Costs.' This approach might be limited, however, because in many applications there is no gauge on the suction side of the pump. Unless a reasonable assumption of suction pressure is available (for example, the height of a fluid level in a vented tank that feeds directly into the pump suction), the total head developed by the pump cannot be known.

Another potential limitation is the accuracy of pressure gauges used in many industrial applications. These pressure gauges are usually not calibrated regularly, so they might not be sufficiently accurate. In some cases, these gauges also lack the precision required to determine power consumption accurately. This is particu-

Figure 21. Using a Pump Performance Curve to Determine Power Draw

<!-- image -->

larly true for pumps that have relatively flat performance curves, in which a small difference in head makes a big difference in flow and bhp.

If the system gauge does not have the required precision, a test gauge should be installed. In many systems, the pipe fittings used for pressure gauges have secondary connection ports to accommodate calibration equipment. These ports are well suited for a separate test gauge, which is more accurate than the system gauge.

Using pump curves to estimate a pump's power consumption can be inaccurate and should be a last resort, understanding that actual power consumption may be as much as 20% greater or 10% less than estimated. Increases in the clearance in wear rings or other internal restriction devices and wear of the impeller and casing can lead to inaccuracies.

Unless the pump was tested in the factory, standard performance curves represent typical performance. As a result of normal manufacturing variations, actual power measurements may be 5% higher or lower.

To use the pump curve, the engineer must convert the total pressure developed by the pump to a head value. This conversion requires two key factors:  the density of the system fluid and

an estimate of the velocity, or dynamic, head. Fluid density is typically determined by measuring the temperature of the fluid and using a table of properties for that fluid to find the corresponding density.

The velocity head is more difficult to determine, because it requires knowing the pump flow rate; in turn, knowing the flow rate requires knowing the pump head. However, since velocity head is typically much smaller than the static head, by making a reasonable assumption of the fluid velocity, the engineer can determine the approximate velocity head. For example, in some cooling systems, to minimize flow noise, a maximum flow velocity of 10 feet (ft) per second is used as a design guideline. This flow speed corresponds to a velocity head of 1.55 ft. The value of the error associated with this number is probably minor in comparison to other errors associated with estimated annual energy consumption.

## Using a Pump Performance Curve To Determine Annual Electricity Costs

Annual	electricity	costs	=	(pump	bhp)/(motor efficiency)	x	(hours	in	a	year)	x	(unit	electricity	cost) x	(%	of	time	operating)

## Assumptions:

- · Either	total	pump	head	or	pump	flow rate	is	known	(must	be	fairly	constant throughout	the	year)
- · Motor	efficiency	=	95%
- · Percentage	of	time	running	=	65% (operating	65%	of	the	year	at	the	load measured)
- · Unit	electricity	cost	=	$0.05/kWh

For	example:

- · Total	head	=	155	feet
- · Pump	bhp	(reading	from	the	bhp	line)	=	11	hp

Annual	electricity	costs	=	(11	bhp)	x (0.746	kW/hp)	x	(1/0.95)	x	(8,760	hrs)	x	(0.05$/kWh) x	0.65

Annual	electricity	costs	=	$2,459

Alternatively, a pump discharge line that already has a flowmeter provides an ideal opportunity to determine the flow rate; the flow rate, in turn, can be used to determine the pump's operating point along its performance curve. Also, portable flowmeters that clamp onto the pipe can be used to measure flow rate. In general, portable flowmeters work relatively well on systems that have homogeneous fluids and long straight runs of pipe. However, the accuracy of these instruments deteriorates if the fluid contains particulates or vapor, or if the flow profile is not uniform.

##  Energy and Demand ChargesUnderstanding Your Electricity Bill

The calculations shown earlier use simplified electricity rate approximations stated in terms of dollars per kilowatt-hour ($/kWh). However, electric utilities use more complicated rate structures to bill industrial customers. These typically include both energy ($/kWh) and demand charges ($/kW), and they have different rates depending on the level of consumption and the time of year. Demand charges are based on the peak demand for a given month or season and can have significant impacts on some customers' electricity costs. When the economic impacts of efficiency measures are calculated, the marginal cost of the electricity needs to be considered, taking into account energy and demand charges, seasonal rates, and different rates for different levels of consumption.

##  Maintenance Considerations

An important aspect of any system improvement is ensuring that its benefits continue well beyond the payback period. To help prevent the system from performing poorly again, proper operating and maintenance practices need to be followed.

A continuous improvement approach can help to ensure that cost and performance benefits remain in effect over the long term. An important part of this approach is increasing operators' awareness of operating costs and the performance implications of improper operation or maintenance.

Preventive maintenance (PM) is intended to improve system reliability, reduce the risk of

unplanned downtime, and avoid expensive failures. In general, PM is less costly than repair. A well-designed PM schedule minimizes the need for repairs by detecting and resolving a problem before it develops into something more serious.

## Analyze Life-Cycle Costs Before Making a Decision

In much the same way that a PM schedule minimizes expensive repairs, a well-designed system can avoid higher-than-necessary operating costs. Using a life-cycle cost perspective during initial system design, or while planning system upgrades and modifications, can reduce operating costs and improve system reliability. The components of life-cycle costs include the cost of initial equipment, energy consumption, maintenance, and decommissioning; these are discussed in more detail later in this section.

The life-cycle costs of pumps are difficult to summarize because, even among pumps of the same size, initial costs vary widely. Other costssuch as maintenance and disposal or decommissioning-can be difficult to quantify. Several industry stakeholders have participated in efforts to encourage greater consideration of life-cycle costs in pumping system specification and operation. For example, the Hydraulic Institute, a U.S. pump manufacturers trade association, has developed a life-cycle costing guidebook 7 to increase industry experts' awareness of the subject.

Plant and corporate managers are often bound by a concern for a company's profits when considering the investment of capital funds. Decision makers are usually attuned to activities that translate directly to the bottom line, such as projects that increase productivity. Fortunately, many (if not most) energy efficiency projects provide other benefits in addition to energy cost savings, such as the following:

- ■ Increased productivity
- ■ Lower maintenance costs
- ■ Reduced costs of environmental compliance
- ■ Lower production costs
- ■ Reduced waste disposal costs
- ■ Better product quality
- ■ Improved capacity utilization
- ■ Better reliability
- ■ Improved worker safety.

Any potential efficiency improvement project stands a better chance of being funded if it takes into account all these costs and benefits over the project's anticipated lifespan. Understanding all the components that make up the total cost of owning and operating a pumping system helps decision makers more easily recognize opportunities to significantly reduce energy, operating, and maintenance costs.

A highly efficient pumping system is not merely a system with an energy-efficient motor. Overall system efficiency is the key to maximum cost savings. Often, users are concerned only with initial costs, and they accept the lowest bid for a component while ignoring system efficiency. To achieve optimum pumping system economics, users should select equipment based on life-cycle economics and operate and maintain the equipment for peak performance.

Life-cycle cost (LCC) analysis is a management tool that can help companies realize these opportunities. The analysis takes into consideration the cost of purchasing, installing, operating, maintaining, and disposing of all the system's components. Determining the LCC of a system involves using a methodology to identify and quantify all of the components of the LCC equation. As stated in the Hydraulic Institute's LCC guidebook, the equation is as follows:

<!-- image -->

where C = a cost element, and

- ic =  initial cost or purchase price (e.g., of the pump, system, pipe, auxiliary equipment)
- in =  installation and commissioning
- e =  energy costs
- o =  operating costs (the labor costs for normal system supervision)
- m  = maintenance costs (e.g., parts, worker-hours)
- s =  downtime (loss of production)
- env =  environmental costs
- d =  decommissioning.

These elements should also include the costs associated with loans, depreciation, and taxes.

The cost of the energy consumed by pumps is always a significant factor in pump life-cycle costs. But many end users are already stretched thin in carrying out day-to-day facility operations. They lack the time and resources needed to perform a methodical engineering study of the pumps (sometimes hundreds of them) in their facilities that will show their energy costs as well as opportunities for savings.

For most facilities, lifetime energy costs or maintenance costs (or both) dominate life-cycle costs. It is thus important to determine as accurately as possible the current cost of energy and the expected annual escalation in energy prices over the system's estimated life, along with expected labor and material costs for maintenance. Other elements, such as the lifetime costs of downtime, decommissioning, and environmental protection (including disposal costs), can often be estimated using historical data for the facility. Depending on the process, downtime costs can be more important than the energy or maintenance elements of the equation. Careful consideration should thus be given to productivity losses caused by downtime.

Pumping systems often have a lifespan of 15 to 20 years. Thus, some costs will be incurred at the outset and others will be incurred at different times during the lifetimes of the different solutions being evaluated. So it is necessary to calculate a present or discounted value of the LCC to assess the different solutions accurately. As a result, other financial factors need to be taken into consideration in developing the LCC. These include the following:

- ■ Discount rate
- ■ Interest rate
- ■ Expected equipment life (calculation period)
- ■ Expected price increases for each LCC factor over the estimated lifetime of the equipment.

When used as a tool for comparing alternative solutions, the LCC process will indicate the most cost-effective one within the limits of available data. When applying the evaluation process, or selecting pumps and other equipment, the best information concerning the output and operation of the plant must be obtained. Using bad or imprecise information results in a bad or imprecise assessment. The LCC process does not guarantee a particular result, but it does allow plant personnel to make a reasonable comparison between several alternatives.

LCC analysis is concerned with assessments in which the details of the system design are being reviewed. To make a fair comparison, the plant designer or manager should consider the unit of measure used. For example, if two items being evaluated do not reflect the same volume of output, it might be appropriate to express them in terms of cost per unit of output (e.g., $/ton). The analysis should take into account all significant differences between the solutions being evaluated. Finally, the plant designer or manager should consider maintenance or servicing costs, for example, when they will be subcontracted or when spare parts will be provided with the initial supply of equipment. Everything should be considered on a comparable basis. In other words, if the plant designer or manager decides to subcontract maintenance or inventory spare parts strictly for the sake of convenience, this criterion must be used for all the systems assessed. However, if maintenance of a particular component can be carried out only by a subcontracted specialist, or

certain spare parts must be inventoried to prevent downtime, then it is acceptable to include the cost of these measures by themselves.

For additional information on life-cycle cost analysis for pumping systems, refer to the Hydraulic Institute's Pump Life Cycle Costs: A Guide to LCC Analysis for Pumping Systems . This guide also provides substantial technical guidance on designing new pumping systems as well as assessing improvements to existing systems. It includes examples of manual calculations of LCC and a software tool to assist in LCC calculation. The guide and accompanying LCC calculation tool are available through the Hydraulic Institute's Web site ( www.pumps.org ).

## Sell Your Projects to Management

Often, industrial facility managers must convince upper management that an investment in pumping system efficiency is worth making. Communicating this message can be more difficult than the actual engineering behind the concept, however. A corporate audience usually responds more readily to dollars-and-cents impacts than to a discussion of best efficiency points. By adopting a financial approach, the facility manager can relate pumping system performance and efficiency to corporate goals. Finance personnel can help facility managers create the kind of proposal that can 'win over' the corporate officers who make the final decision on capital investments in pumping system upgrades.

Before providing some recommendations to justify pumping system improvement projects, it is useful to gain some insight into corporate priorities.

##  Understanding Corporate Priorities

Corporate officers are accountable to a chief executive, a board of directors, and an owner (or shareholders, if the firm is publicly held). These officers must create and grow the equity value of the firm. The corporation's industrial facilities do so by generating revenue that exceeds the cost of owning and operating the facility. Plant equipment-including pumping system componentsare assets that must generate an economic return.

Dividing the annual earnings attributable to the sale of goods produced by these assets by the value of the assets themselves yields the rate of return on assets. This is a key measure for which corporate decision makers are held accountable.

Finance officers seek investments that are most apt to demonstrate a favorable return on assets. When faced with multiple investment opportunities, these officers will favor options that lead to the largest and fastest returns.

This corporate attitude can impose (sometimes unwanted) priorities on the facility manager: assure reliability in production, avoid surprises by sticking with familiar technologies and practices, and contribute to immediate cost control by, for example, cutting a few corners in maintenance and upkeep. These priorities might lead industrial decision makers to conclude that pumping system efficiency is a luxury that they cannot afford.

Fortunately, the story does not end here. The following discussion describes the ways that industrial pumping system efficiency can save money and contribute to corporate goals while effectively reducing energy consumption. Facility managers can use these facts to form a persuasive case for corporate support of pumping system improvements.

Many organizations consider only the initial purchase and installation costs of a system. However, plant designers and managers will benefit from evaluating the LCC of different solutions before installing major new equipment or carrying out a major overhaul, to identify the most financially attractive alternative. As national and global markets continue to become more competitive, organizations continually seek cost savings to improve the profitability of their operations. Plant operations can be a significant source of savings, especially because energyefficient equipment can minimize energy consumption and plant downtime.

For new pumping system procurements, note that new piping system design technology uses

numerical optimization techniques, which provide a practical way to treat the pipe system as a variable at the design stage. A well-designed system will last longer than other types, and this should be taken into account in an LCC analysis.

The LCC analysis is also a valuable tool to use when comparing alternative retrofit designs for existing pumping systems.  Opportunities for upgrading existing systems can be found in the inefficiencies that develop over time-such as changing system requirements, routine wear and tear, and poorly optimized controls. Furthermore, the installed base of pumping systems exceeds the number of new pumps built each year by a factor of about 20.

##  Measuring the Dollar Impact of Pumping System Efficiency

Pumping system efficiency and performance improvement projects can move to the top of the list of corporate priorities if proposals respond to corporate needs. Corporate challenges are many and varied, and this in turn opens up more opportunities to 'sell' pumping system efficiency as a solution. Many pumping system opportunities for improvement are discussed in this sourcebook. Once selections are made, the task becomes one of communicating the proposals in corporate (dollars-and-cents) language.

The first step is to identify and evaluate the total dollar impact of a pumping system efficiency measure. One proven way to do this is through an LCC analysis, as discussed earlier. The resulta net gain or loss on balance-can be compared with other investment options or with the anticipated outcome of doing nothing.

##  Presenting the Finances of Pumping System Improvements

As with any corporate investment, there are many ways to measure the financial impact of a pumping system investment. Some methods are more complex than others, and presenters might want to use several of them side by side. That choice will depend on the sophistication of the presenter and the audience.

A simple (and widely used) measure of project economics is the payback period. This is the period of time required for a project to 'break even' in terms of costs-the time needed for the net benefits of an investment to accrue to the point where they equal the cost of the initial outlay. For a project that returns benefits in consistent, annual increments, the simple payback equals the initial investment divided by the annual benefit.

The simple payback does not take into account the time value of money; in other words, it makes no distinction between a dollar earned today and a dollar of future (and thus uncertain) earnings. Still, the measure is easy to use and understand, and many companies use simple payback in making a quick 'go/no-go' decision on a project. Here are five important factors to remember when calculating a simple payback:

- ■ It is an approximation, not an exact economic analysis
- ■ All benefits are measured without considering their timing
- ■ All economic consequences beyond the payback are ignored
- ■ Payback calculations will not always identify the best solution (because of the two factors listed before this one) among several project options
- ■ Paybacks do not take into consideration the time value of money or tax consequences.

More sophisticated analyses take into account factors such as discount rates, tax impacts, and the cost of capital. One approach involves calculating the net present value of a project, which is defined in this equation:

Net present value = present worth of benefits present worth of costs.

Another commonly used calculation for determining the economic feasibility of a project is internal rate of return . This is defined as the discount rate that equates future net benefits (cash) to an initial investment outlay. This discount rate can be

compared to the interest rate at which a corporation borrows capital.

Many companies set a threshold (or 'hurdle') rate for projects, which is the minimum required internal rate of return needed for a project to be considered viable. Future benefits are discounted at the threshold rate, and the net present worth of the project must be positive in order for the project to be a 'go.'

##  Relating Pumping System Efficiency to Corporate Priorities

Saving money in itself should be a strong incentive for implementing a pumping system project. Still, that may not be enough for some corporate decision makers. The facility manager's case can be strengthened by relating a positive life-cycle cost outcome to specific corporate needs. Some suggestions for interpreting the benefits of energy cost savings include the following (finance staff can suggest which of these approaches are best, given the current corporate climate):

A new source of permanent capital. Reduced energy expenditures-the direct benefit of pumping system efficiency-can be thought of as a new source of capital to the corporation. The investment that makes this efficiency possible will yield annual savings each year over the economic life of the improved pumping system. Regardless of how the investment is financed-borrowing, retained earnings, or third-party financing-the annual savings will be a continuing source of funds.

Added shareholder value. Publicly held corporations usually embrace opportunities to enhance shareholder value. Pumping system efficiency can be an effective way to capture new value. Shareholder value is the product of two variables: annual earnings and the price-to-earnings (P/E) ratio. The P/E ratio describes the corporation's stock value as the current stock price divided by the most recent annual earnings per share. To take advantage of this measure, a pumping system efficiency proposal should first identify annual savings (or rather, addition to earnings) that the proposal will generate. Multiplying that earnings increment by the P/E ratio yields the total new shareholder value attributable to the pumping system efficiency improvement.

## Improved reliability and capacity utilization.

Another benefit of a pumping system improvement project is the more productive use of pumping system assets. The efforts required to achieve and maintain energy efficiency will largely contribute to operating efficiency. By improving pumping system performance, the facility manager can improve the reliability of plant operations. The flip side, from the corporate perspective, is a greater rate of return on assets employed in the plant.

##  Call to Action

A proposal for a pumping system improvement project can be made attractive to corporate decision makers if the facility manager does the following:

- ■ I dentifies opportunities for improving pumping system efficiency
- ■ Determines the life-cycle cost of attaining each option
- ■ Identifies the option(s) with the greatest net benefits
- ■ Collaborates with financial staff to identify current corporate priorities (for example, added shareholder value and improved capacity utilization)
- ■ Generates a proposal that demonstrates how the pumping system project's benefits will directly respond to current corporate needs.

Developing successful energy projects begins with laying the groundwork to support the project. Ideally, it starts with a facility reward program that has a system for pursuing cost savings projects and compensates employees for their efforts. However, most of the time the groundwork is done by a motivated individual who takes pride in the job and is inspired by what other facilities have done. To overcome the obstacles often encountered and

enhance the chances for success, the following 'pre-presentation tasks' are recommended.

## 1. Get support from a key member of management before pursuing energy projects.

The most successful facility energy evaluations and projects begin with a commitment from management to invest resources in pursuing financial gains through energy efficiency improvements. Without management's commitment, great energy-saving projects can sit on the shelf for years. It might seem obvious that some projects should be pursued immediately, but without support or recognition from management, the extra work and added responsibility may not be worth it to some individuals.

Support from management should also include defining an acceptable cost/benefit ratio and identifying project funding sources. Ultimately, financial parameters for evaluating larger projects using LCC analyses should also be included.

## 2. Obtain input from key department personnel before proposing a project to management.

Discussing projects with key maintenance or operations staff provides insight into issues that can be resolved early. Solutions usually involve accommodating concerns or including features that will help solve existing problems. Case studies can be used to show staff how similar projects were successfully implemented and to help them reach the level of comfort needed to accept new technology or even to enthusiastically support the project.

## 3. Begin with simple projects to increase your

chances of success. Confidence in the success of cost-saving projects can be built by implementing small, 'low-tech' projects that show measurable savings. One of management's greatest fears is approving an expensive energy-savings project that does not deliver the projected savings. This is especially important when considering new technologies. Facility managers who start with small, energy-saving projects with measurable results often find that future cost-saving projects are approved quickly.

## 4. Obtain outside support to validate your

recommendation. In many cases, facility managers who have identified attractive cost savings opportunities find that they need thirdparty input to validate a project for management or to fill in missing details. Sources include consultants, other end users, and technical resources that are often available through electric utility programs and equipment suppliers. The section on resources and tools in this sourcebook can be helpful in guiding the end user to these sources of assistance.

Often, a local utility can help determine what potential financial incentives might be available to improve the cost-effectiveness of a project. DOE BestPractices software-such as MotorMaster+ and the PSAT-can also support savings calculations.

5. Present your project. Projects can be presented as stand-alone efforts or as part of a comprehensive energy project with multiple recommendations developed from a facility energy study. Ultimately, each project should be presented on a one- or twopage project profile that is sometimes called an energy conservation measure, or ECM.

Projects can also be identified as operational measures when minimal investment is required, or energy supply measures when cogeneration or rate schedule changes are pursued. The project profile typically includes a brief description of the project, implementation steps, and a project cost and savings summary. It is also important to include more in-depth calculations, equipment cut sheets, and cost spreadsheets, or to make them available.

These steps are a sample of what can be done to successfully obtain approval for a project. To fully develop a project, additional data collection, financial analysis, development of a performance contract request for proposals, and savings monitoring and verification may also be needed.

In summary, increasing the awareness of all facility personnel about the benefits of improved pumping system efficiency and performance is an important step in increasing the competitiveness of energy-intensive industries.

## Section 4:  Where To Find Help

## Overview

This section lists resources that can help end users improve the performance of pumping systems cost-effectively. Various programs involved in the pump marketplace are described, including these:

## DOE Industrial Technologies Program and BestPractices

- ■ The U.S. Department of Energy (DOE) Industrial Technologies Program (ITP) and its BestPractices activities; this national effort is aimed at improving the performance of industrial energy use, particularly in steam, compressed air, pumping, and process heating systems
- ■ The Hydraulic Institute (HI), a trade association for manufacturers of pumps and suppliers to the pump industry; Pump Systems Matter TM , HI's educational and market transformation initiative, addresses energy optimization and the total cost of pump ownership
- ■ Associations and other organizations involved in the pumping system marketplace.

This section also provides information on books and reports, other publications, government and commercial statistics and market forecasts, software, training courses, and other sources of information. This information is intended to help end users make informed equipment purchase and system design decisions regarding pumping systems.

The information in this section is current as of the publication date of this sourcebook. Please check the ITP BestPractices Web site ( www.eere.energy. gov/industry/bestpractices ) for updates and for the latest versions of DOE publications, software, and other materials referenced here. (Note that DOE cannot guarantee the currency of information produced by other organizations.)

Industrial manufacturing consumes 36% of all the energy used in the United States. Therefore, the DOE Industrial Technologies Program was established to assist industry in achieving significant energy and process efficiency improvements. ITP develops and delivers advanced energy efficiency, renewable energy, and pollutionprevention technologies and practices for many industrial applications. The program works with the nation's most energy- and resource-intensive industries to develop a vision of their future and roadmaps on how to achieve these visions over a 20-year timeframe.

This collaborative process aligns industry goals with federal resources to accelerate research and development (R&amp;D) of advanced technologies that industry has identified as priorities. The advancement of efficient technologies is complemented by ITP energy management best practices for immediate savings results. ITP BestPractices helps industries identify and realize their best energy efficiency and pollution-prevention options from a system and life-cycle cost perspective.

In particular, ITP BestPractices offers several resources for pumping system energy management. These resources complement technology development programs that address motor, fan, compressed air, process heat, combined heat and power, and steam systems, in addition to the activities of the Industrial Assessment Centers and financing assistance efforts. Collectively, these efforts assist industry in adopting near- and longterm energy-efficient practices and technologies. Through activities such as plant-wide energy assessments, implementation of emerging technologies, and energy management of industrial

systems, ITP BestPractices delivers energy solutions for industry that result in significant energy and cost savings, waste reduction, pollution prevention, and enhanced environmental performance.

##  Plant Assessments

Depending on the industry, energy costs can be 10% or more of a plant's total operating costs. Energy assessments identify opportunities for implementing new technologies and system improvements. Many recommendations from energy assessments have payback periods of less than 18 months and can result in significant energy savings.

Plant-wide assessments help manufacturers develop comprehensive plant strategies to increase efficiency, reduce emissions, and boost productivity. Annual competitive solicitations offer matching funds. In addition, small- to medium-sized manufacturers can qualify for free assessments from the university-based Industrial Assessment Centers.

##  Emerging Technologies

Emerging technologies are those that result from R&amp;D and are ready for full-scale demonstration in actual applications. ITP recognizes that companies may be reluctant to invest capital in new technologies, even though they can provide significant energy savings and process improvements. However, through technology implementation solicitations, ITP helps to mitigate the risk associated with using new technologies that are supported by industry partnerships. Shared implementation and third-party validation and verification of performance data allow energy, economic, and environmental benefits to be assessed so that new technologies can be accepted more rapidly.

##  Energy Management

ITP encourages manufacturers to adopt a comprehensive approach to energy use that includes assessing industrial systems and evaluating potential improvement opportunities. Efficiency gains in compressed air, motor, process heating, pumping, and steam systems can be significant, and they usually result in immediate energy and cost savings. ITP offers software tools and training in a variety of system areas to help industry become more energy- and process-efficient while reducing waste and improving environmental performance.

##  Allied Partnerships

Allied Partners are manufacturers, associations, industrial service and equipment providers, utilities, and other organizations that work voluntarily with ITP. Allied Partners seek to increase energy efficiency and productivity for industries that participate in endorsing and promoting ITP programs, products, and services.

Allied Partnerships help ITP achieve the program's industrial energy efficiency goals by extending delivery channels through the partners' existing networks. In turn, the partners benefit by achieving their own corporate, institutional, or plant goals and objectives and by expanding services to customers and suppliers. Allied Partners also gain access to such technical resources as software, technical publications, and training, and they can gain recognition as leaders in implementing energy-efficient technologies and practices. For more on Allied Partnerships, contact the EERE Information Center at 877-337-3463.

##  Technical Resources

ITP offers a variety of resources to help industry increase energy and process efficiency, improve productivity, and enhance competitiveness.

EERE Information Center. The EERE Information Center fields questions on EERE products and services, including those focused on industrial energy efficiency. Staff can also answer questions about such industrial systems as compressed air, motors, process heating, and steam. The EERE Information Center can be the first stop in finding out what's available from EERE and ITP. Contact the EERE Information Center at 877-337-3463 or see www.eere.energy.gov/informationcenter .

ITP and ITP BestPractices Web Sites. The ITP and ITP BestPractices Web pages offer a large array of information, products, and resources

to assist manufacturers who are interested in increasing the efficiency of their industrial operations. You can learn about upcoming events, solicitations, and much more by visiting the ITP site at www.eere.energy.gov/industry. The BestPractices site provides case studies of companies that have successfully implemented energy-efficient technologies and practices, software tools, tip sheets, training events, and solicitations for plant assessments. You can view these and other resources at www.eere.energy.gov/ industry/bestpractices .

Industrial Energy Savers Web Site. Manufacturers will find a number of resources on this site to implement industrial energy efficiency projects and see immediate savings. See www.eere.energy. gov/consumerinfo/industry.

##  Training

Training sessions in industrial system improvements using DOE software tools are offered periodically through Allied Partners. A particularly useful training session involves the Pumping System Assessment Tool (PSAT). See the discussion on the PSAT tool in Appendix B. More information on PSAT training and other training offerings can be found on the BestPractices Web site, www.eere.energy.gov/industry/bestpractices .

##  Software Tools

ITP and its partners have developed several software tools to help plant managers make good decisions about implementing efficient practices in their manufacturing facilities.

- ■ AirMaster+ is a software tool developed by EERE BestPractices and jointly sponsored by the Compressed Air Challenge TM . AIRMaster+ helps end users assess the potential for efficiency and productivity improvements in compressed air systems without bias to any particular technology, organization, or product. The software allows users to run a number of 'what-if' scenarios to determine which energy efficiency measures have the greatest savings potential for their facility.
- ■ MotorMaster+ is an energy-efficient motor

selection and management software tool; it includes a catalog of more than 20,000 ac motors. The software also features motor inventory management tools, maintenance log tracking, efficiency analysis, savings evaluation, energy accounting, and environmental reporting capabilities.

- ■ MotorMaster+ International includes many of the capabilities and features of MotorMaster+ but allows users to evaluate repair/replacement options on a broader range of motors. The user can conduct analyses in different currencies, calculate efficiency benefits for various utility rate schedules with demand charges, edit and modify motor rewind efficiency loss defaults, and determine 'best available' motors. This tool can be operated in English, Spanish, and French.
- ■ The Pumping System Assessment Tool (PSAT) helps industrial users assess the efficiency of pumping system operations. PSAT uses achievable pump performance data from Hydraulic Institute standards as well as motor performance data from the MotorMaster+ database to calculate potential savings in energy and associated costs.
- ■ The Steam System Scoping Tool is designed to help steam system energy managers and operations personnel for large industrial plants. This spreadsheet program will profile and grade steam system operations and management. It will help you evaluate your steam system operations against identified best practices.
- ■ The Steam System Assessment Tool (SSAT) uses a graphical model of a generic steam system for up to three steam pressure headers (high, medium, and low). You can enter data for your own plant conditions, including fuel type and cost, electricity, water costs, initial boiler efficiency, header pressures, and turbine efficiencies.
- ■ 3E-Plus Insulation Appraisal Software. Because insulation is used in many process heating systems and almost all steam systems, restoration, replacement, and/or installation of missing insulation are common improvement

opportunities. A lack of awareness regarding energy losses and associated costs often means assigning a low priority to restoring or properly installing insulation on system surfaces. As a result, a software program known as 3E-Plus was developed by the North American Insulation Manufacturers Association (NAIMA) to inform system operations and management personnel of the benefits of insulation and to assist them in assessing insulation needs.

##  Qualified Specialists

Qualified Specialists have extensive backgrounds in optimizing systems that are being assessed. Individuals become qualified by taking DOEsponsored training on the software and passing a rigorous exam. For more information on how to contact a Qualified Specialist or become one, see www.eere.energy.doe.gov/industry/bestpractices .

##  Newsletters

- ■ The Industrial Technologies Program E-Bulletin is a monthly online newsletter that spotlights technologies, significant project developments, and program activities; new ITP products; training and events; Web updates; and new solicitations. The E-Bulletin provides readers with links to source information on ITP and IAC Web sites. To subscribe, go to www.eere.energy. gov/industry/resources/ebulletin/ .
- ■ Energy Matters is a quarterly online publication written by the Industrial Technologies Program. It contains news, articles, technical tips, and case studies of interest to industrial end users. Energy Matters articles cover energy efficiency opportunities, technical issues, new products and services, and events related to process heating systems and other industrial utilities, such as

## Pump-Specific Resources

Software: The Pumping System Assessment Tool  (PSAT) software	helps	industrial	users	assess	the	efficiency	of pumping	system	operations.	PSAT	uses	achievable	pump performance	data	from	Hydraulic	Institute	standards	as	well as	motor	performance	data	from	the	MotorMaster+	database to	calculate	potential	energy	and	associated	cost	savings. For	more	information	on	PSAT,	see	Appendix	B.

Training: Pumping System Assessment. This	one-day training	session	provides	an	in-depth	discussion	of	energy efficiency	factors	for	pumping	systems,	emphasizing	the system	as	a	whole	rather	than	just	components.	Indicators and	symptoms	of	potential	energy	reduction	opportunities	are discussed.	Application	and	use	of	the	PSAT	software	is	also covered.		This	training	was	developed	to	introduce	users	to the	software	(a	CD	with	the	PSAT	software	is	provided)	and	to provide	guidance	on	field	measurement	considerations.	For more	on	the	PSAT,	see	Appendix	B.

Qualified Pump System Specialist Training. This	twoday	training	session	covers	the	energy	efficiency	factors addressed	in	the	one-day	Pumping	System	Assessment training	session	and	provides	case	studies	and	additional instruction	on	the	use	of	the	PSAT	software.	It	concludes	with a	written	exam,	and	those	successfully	completing	the	exam are	recognized	as	Qualified	Pump	System	Specialists.

Tip Sheets: To	increase	industry's	awareness	about the	wealth	of	opportunities	that	exist	to	improve	many different	kinds	of	industrial	systems,	the	Industrial Technologies	Program	develops	Pumping	Tip	Sheets through	its	BestPractices	activity.

Tip sheets currently available:

- 1.		Conduct	an	In-Plant	Pumping	System	Survey
- 2.		Pump	Selection	Considerations
- 3.		Select	an	Energy-Efficient	Centrifugal	Pump
- 4.		Test	for	Pumping	System	Efficiency
- 5.		Maintain	Pumping	Systems	Effectively
- 6.		Match	Pumps	to	System	Requirements
- 9.		Reduce	Pumping	Costs	Through	Optimum	Pipe	Sizing

Tip sheets in development:

- 7.		Trim	or	Replace	Impellers	on	Oversized	Pumps
- 8.		Optimize	Parallel	Pumping	Systems
- 10.		Reduce	Energy	Losses	Across	Control	Valves
- 11.		Adjustable	Speed	Pumping	Applications
- 12.		Control	Strategies	for	Centrifugal	Pumps	with Variable	Flow	Rates

Tip	sheets	contain	concise	descriptions	of	common opportunities	for	improving	industrial	energy	and	process efficiency.	To	access	the	tip	sheets,	including	the	newest ones,	see www.eere.energy.gov/industry/bestpractices.

motor, steam, and compressed air systems. To subscribe online, go to www.eere.energy.gov/ industry/bestpractices/energy\_matters.html, and click on 'subscribe today.'

- ■ Steaming Ahead is a bimonthly e-mail newsletter published by the Alliance to Save Energy, which coordinates BestPractices Steam outreach and promotion. The newsletter describes the activities and information products of the BestPractices Steam effort, and it promotes bestin-class practices and technology applications in steam system design and management. Additional information on Steaming Ahead can be found at www.steamingahead.org .

## Hydraulic Institute

The Hydraulic Institute (HI) is the largest association of pump producers and suppliers in North America. The Institute's vision is to be a global authority on pumps and pumping systems. Its mission is to be a value-adding resource to member companies and pump users worldwide by

- ■ Developing and delivering comprehensive industry standards
- ■ Expanding knowledge by providing education and tools for the effective application, testing, installation, operation, and maintenance of pumps and pumping systems
- ■ Serving as a forum for the exchange of industry information.

##  Standards

HI develops and publishes pump standards and is certified by the American National Standards Institute (ANSI). Currently, 25 different standards are in print, covering centrifugal, vertical, rotary, reciprocating, and air-operated pumps. Additional ones in development include new standards for viscosity correction, slurry pumps, and controlled volume metering pumps. ANSI/HI pump test standards are also referenced in other pump standards, such as ANSI B-73, API 610, and ISO 13709. More than 80% of pump tests performed in the United States are conducted in accordance with HI pump test standards.

HI maintains the secretariat for the International Standards Organization (ISO)/TC-115 U.S. Technical Advisory Group and votes on behalf of U.S. pump manufacturers on ISO pump standards. HI is also the secretariat to ISO/TC-115 Subcommittee 3(SC3) and thus plays an influential role in the development of international pump standards.

##  Education

HI programs include many educational opportunities for members. Suppliers to the pump industry, eligible to join as associate members, make technical presentations on pump systems and the use of a variety of products, including seals, couplings, drivers, housing, controls and instrumentation, and pump-specific software. Systems integrators are also eligible to join HI.

In cooperation with DOE, HI developed a videobased education program titled 'Energy Reduction in Pumps and Pumping Systems.' HI's e-learning portal, www.pumplearning.org , includes the Institute's first online course: 'Centrifugal Pumps: Fundamentals, Design and Applications.' HI welcomes ideas and outlines for future courses and seeks relationships with other organizations interested in offering or funding future course development under a sponsorship arrangement.

##  Statistics

HI conducts a comprehensive statistics program exclusively for U.S. pump manufacturers who are members. Up to nine different surveys are published that track monthly bookings, quarterly shipments by product and market, quarterly rebuild and overhaul, semiannual market reports of export bookings by geographic region and market, and annual shipments by discharge size (exclusively for HI members). HI has developed a 'load factoring' program for estimating, on a monthly and quarterly basis, pump bookings and shipments for the entire U.S. industry. Two human resources surveys and one operating ratio survey are conducted annually. Working closely with the Bureau of the Census in the U.S. Department of Commerce, HI has been instrumental in refining the Pumps and Compressors Current Industrial Report (MA333P) to better serve the ne eds of the industry.

##  Mutual Cooperation

HI and Europump, a federation of 15 national European pump associations, have a mutual cooperation agreement for exchanging delegates at annual meetings, cooperating on technical documents and standards, and working toward the harmonization of pump industry data worldwide. Several publications, including life-cycle costing and variable speed pumping guidebooks, have been produced under this agreement. HI membership is also represented on technical matters in other U.S. trade associations, including the National Electrical Manufacturers Association (NEMA), the American Society of Mechanical Engineers, the National Fire Protection Association, the American Petroleum Institute, the American Water Works Association, the American Society for Testing and Materials, the American Boiler Manufacturers Association, the Fluid Sealing Association, and the Submersible Wastewater Pump Association.

HI became a DOE Allied Partner on May 1, 2000, and had been a Charter Partner of the Motor Challenge program with DOE for many years. In 2002, HI endorsed the NEMA Premium motor efficiency program. HI also works with DOE to provide Pumping System Assessment Tool (PSAT) training.

##  Pump Systems Matter

HI initiatives that benefit pump users include the educational outreach described above and a new national pump systems education initiative, Pump Systems Matter ™ (PSM), to advance the concepts of life-cycle cost, energy savings, and optimized pump system performance. HI works with DOE and many other organizations to develop educational tools and training, certification programs, and outreach. PSM seeks to provide North American pump users with a more competitive business advantage through strategic, broad-based energy management and pump system performance optimization. Details on PSM can be found at www.pumpsystemsmatter.org.

##  Publications and Standards

The Institute offers for sale an extensive collection of pump standards, guidebooks, the HI Engineering Data Book , and other publications of interest to users, contractors, and pump manufacturers worldwide; these represent nearly 2,000 pages of pump knowledge. Standards are available in hard copy, CD-ROM, downloadable PDF, or Web-based subscription formats. To order, visit the HI Web site, www.pumps.org , which includes a free Master Index to standards and a downloadable brochure. Orders may also be faxed to the publications department at 973-267-9055 or requested via e-mail at publications@pumps.org .

HI regularly updates published ANSI/HI pump standards for centrifugal, vertical, rotary, and reciprocating pumps. The HI Engineering Data Book is essential for those dealing with pumps and fluid-handling characteristics.

Educational products include Energy Reduction in Pumps and Pumping Systems, an eight-hour-long video education program produced with DOE that includes three student workbooks, answer books, and an instructor's manual for use by individuals or in a classroom setting. Launched in 2003, 'Centrifugal Pumps: Fundamentals, Design and Applications' is available at www.pumplearning. org . Other courses are planned as resources become available.

HI and Europump developed two comprehensive users' guides, titled Pump Life Cycle Costs:  A Guide to LCC Analysis of Pumps and Pumping Systems , and Variable Speed Pumping: A Guide to Successful Applications . These guidebooks, available at www.pumps.org , are valuable aids in the selection and procurement of pumps for different applications. They are available through HI; for downloadable executive summaries, visit www.eere.energy.gov/industry/bestpractices or www.pumps.org .

##  Web Sites

The HI Web site, www.pumps.org, is a valuable resource for both pump users and manufacturers. This Web site includes information on HI, its activities, and its publications, as well as a variety of resources on pumping system design and selection, energy savings, and other topics. The HI Supplier Finder feature allows users to quickly locate pump manufacturers and leading suppliers in several different ways. Pump definitions and terminology, pump family trees, and numerous other resources are available on this popular site.

HI's e-learning site, www.pumplearning.org , is a valuable resource for those who design, specify, or apply centrifugal and vertical pumps. And its first online course, 'Centrifugal Pumps: Fundamentals, Design and Application,' is available on the Web and on a CD-ROM. HI is seeking sponsors for other, similar online learning courses, as the Institute continues to build a curriculum of e-learning programs for members and other pump users.

## Directory of Contacts

This section provides a list of associations and other organizations involved in the pump system marketplace. The following organizations can provide more information on improving the performance of pumps and pumping systems.

## United States Department of Energy

1000 Independence Avenue, SW Washington, D.C. 20585 www.energy.gov

DOE produces many reports and studies on energyrelated technologies, including those for industry. DOE is involved in several activities that are related to industrial pumping systems, including the development and publishing of this sourcebook.

## DOE Industrial Technologies Program

1000 Independence Avenue, SW Washington, D.C. 20585 www.eere.energy.gov/industry/

ITP sponsors workshops on pump systems optimization. A software tool is currently available that is designed to help pump users quickly determine whether a pumping system is operating effectively. (See the Pumping System Assessment Tool fact sheet for more information.) Also, ITP works in cooperation with the Hydraulic Institute on pumping efficiency. For more information, see the Hydraulic Institute summary in this section.

## EERE Information Center

P.O. Box 43171

Olympia, WA 98504-3171

Phone: 877-337-3463

www.eere.energy.gov/informationcente / r

The DOE EERE (Energy Efficiency and Renewable Energy) Information Center provides technical information on several industrial utility systems, including pumps, compressed air, motors, combined heat and power, process heating, and steam. The EERE Information Center is staffed by engineers and technical experts who are trained to provide information about DOE resources and tools that are available to industry. To reach the EERE Information Center, call 877-337-3463 or e-mail eereic@ee.doe.gov.

Information is also available on the ITP BestPractices Web site, at www.eere.energy.gov/ industry/bestpractices. This site contains current information on planned workshops and training opportunities in areas such as pumping systems optimization.

## Hydraulic Institute (HI)

9 Sylvan Way

Parsippany, NJ 07054-3802

Phone:  973-267-9700

Fax: 973-267-9055

www.pumps.org and www.pumplearning.org

HI is a nonprofit industry association for manufacturers of pumps and pump systems that promotes the effective, efficient, and economic use of pump products worldwide. HI develops standards that define and control the performance, testing, life, and quality of pumps and pump products for manufacturers, purchasers, and pump users. These voluntary standards help purchasers select the pump best suited to a particular need.

All HI standards are developed in accordance with ANSI guidelines. HI is also a source of other pumprelated publications and educational products.

A DOE BestPractices Allied Partner, HI has worked with the DOE Industrial Technologies Program over the past decade on a variety of cooperative efforts related to pumping systems efficiency and training. EERE contributed to the development of the HI/ Europump life-cycle costing and variable speed pumping guidebooks, and HI has co-sponsored sessions of the DOE-developed PSAT Specialist Qualification workshops. HI's Web site includes an energy savings section that features downloadable DOE tools, resources, software, and case studies. Other HI-DOE projects include a video-based education program on 'Energy Reduction in Pumps &amp; Pumping Systems,' co-authored trade journal articles on energy-efficient pumping systems, and training workshops offered to the municipal water and wastewater industry.

## American National Standards Institute (ANSI)

11 West 42 nd Street

New York, NY 10036

Phone: 212-642-4900

Fax: 212-398-0023

ANSI is a private, nonprofit membership organization whose goal is administration and coordination of standards for a broad range of goods and services for the United States. ANSI maintains a number of codes developed by the Hydraulic Institute and other organizations for centrifugal pumps, positive displacement pumps, and fire-protection pumps.

## American Society of Mechanical Engineers (ASME)

345 E. 47

th Street

New York, NY 10017-2392

Phone: 800-843-2473

Fax: 202-429-9417

ASME is a professional society with interests in the design and operation of machines and components. ASME reports on technology developments that can impact material selection and pump design.

## Resources and Tools

This section provides information on books and reports, other publications, government and commercial statistics and market forecasts, software, training courses, and other sources of information that can help users make informed purchasing and system design decisions. A wide range of information is available on pump applications. This section focuses on resources and tools in the following formats:

- · Books, Manuals, and Reports
- · Magazines and Periodicals
- · Government  and Commercial Statistics and Market Forecasts
- · Software
- · Training Courses
- · Online Technical Information

Note:  The descriptions accompanying the following sources have generally been taken directly from the publisher/author/developer. Inclusion of these sources does not imply endorsement by the U.S. Department of Energy.

## Books, Manuals, and Reports

## Butterworth-Heinemann (Gulf Publishing)

200 Wheeler Road, 6 th floor Burlington MA 01803 Phone: 781-221-2212

www.bh.com

## Centrifugal Pumps:  Design and Application, 2 nd Edition

Authors: Val S. Lobanoff and Robert R. Ross Description: This book includes the following chapters: Specific Speed &amp; Modeling Laws; Impeller Design; General Pump Design; Volute Design; Design of Multi-Stage Casing; Double-Suction Pumps &amp; Side-Suction Design; NPSH; Vertical Pumps; Pipeline, Waterflood &amp; CO2 Pumps; High Speed Pumps; DoubleCase Pumps; Slurry Pumps; Hydraulic Power Recovery Turbines; Chemical Pumps - Metallic &amp; Nonmetallic; Shaft Design &amp; Axial Thrust; Mechanical Seals; Vibration &amp; Noise in Pumps;

Alignment; Rolling Element Bearings &amp; Lubrication; and Mechanical Seal Reliability. Published: May 1992 ISBN: 087201200X

## Hermetic Pumps: The Latest Innovations and Industrial Applications of Sealless Pumps

Editor: Robert Neumaier

Description: This book reviews past achievements and provides the impetus for further development of sealless pumps. Analyses of the present state of technology of hermetic centrifugal pumps and rotary displacement pumps are provided, along with detailed descriptions of the design, performance, and application of such machines.

Published:

July 1997

ISBN:

0884158012

## Practical Machinery Management for Process Plants, Vol. 1-4

Authors:

H.P. Bloch and F.K. Geitner

Description: A four-volume series of books for machinery management at process plants.

Volume 1:

Improving Machinery Reliability (3 rd Edition)

Volume 2: Machinery Failure Analysis and Troubleshooting (3 rd Edition)

Volume 3: Machinery Component Maintenance

and Repair (2 nd Edition)

Volume 4: Major Process Equipment Maintenance and Repair (2 nd Edition)

Each book provides a thorough analysis of its respective title subject with field-proven techniques and includes graphs and illustrations. Pumps are covered in-depth in every volume. Published: September 1998 (Vol. 1); September 1997 (Vol. 2), October 1990 (Vol. 3); April 1985 (Vol. 4)

ISBN: 0884156613 (Vol. 1), 0884156621 (Vol. 2), 0872017818 (Vol. 3), 0872014541 (Vol. 4)

## Pumping Station Design, 2 nd Edition

Author: Robert L. Sanks

Description: This book covers all phases of the design of pumping facilities for water, wastewater, and treatment plant sludges. Topics include hydraulic fundamentals, electricity and theory of pumps, selection of pumps and drivers, system

design, piping layout, instrumentation, heating and ventilating, and noise control. Published: February 2001 ISBN: 0750694831

## Concepts ETI

39 Olympia Avenue

Woburn, MA 01801-2073

Phone: 781-935-9050

www.conceptseti.com

## Centrifugal Pump Design and Performance

Author: David Japikse

Description : This book begins with a survey of various pump designs and describes parameters to order and categorize the diverse field. It describes in detail the physics of various types of flows, how to model them, and how to maintain stable operation. The process of pump design is described, from blade layout and analysis to testing and design optimization.

Published:

September 2000

ISBN:

0471361003

## Hydrodynamics of Pumps

Author: Christopher Brennen

Description: This work from Oxford Science covers the theory of pumps and fluid flow. Among the topics are cavitation damage, parameters and inception; bubble dynamics, damage, and noise; pump vibration; unsteady flow; and radial and rotodynamic forces.

Published:

July 1995

ISBN:

0933283075

## CRC Press

2000 NW Corporate Boulevard Boca Raton, FL 33431 Phone: 561-994-0555 www.crcpress.com

## Centrifugal and Rotary Pumps: Fundamentals with Applications

Author : Lev Nelik

Description: This book relates the fundamental principles of the operation of kinetic and positive displacement pumps to specific applications and

user needs. The book includes information on the historical background, recent trends and developments, and actual field trouble-shooting cases in which the causes for each problem are traced back to pump fundamentals.

Published:

March 1999

ISBN:

0849307015

## Elsevier Science

P.O. Box 945

New York, NY  10159

Phone: 800-545-2522

www.elsevier.com

## Centrifugal Pumps and Allied Machinery, 4 th Edition

Author: Harold Anderson

Description: This book is designed for engineers and designers concerned with centrifugal pumps and turbines and includes statistical information derived from 20,000 pumps and 700 turbines with capacities ranging from 5 gpm to 5,000,000 gpm. The statistical analyses suggest practical methods of increasing pump performance and provide valuable data for new design aspects.

Published:

December 1994

ISBN:

1856172317

## Know and Understand Centrifugal Pumps

Authors: Larry Bachus and Angel Custodio Description: This book is intended for operational technicians and process engineers who must extract the most from their process pumps and keep them running with minimal problems and downtime. It includes basic information which will aid in understanding the rules and laws that govern pumps. It will lead to a more intuitive knowledge of pumps and their problems and will assist anyone who must make decisions with limited information. It is geared to maintenance mechanics and engineers, pump operators, process engineers, purchasing agents, equipment specifiers, and storeroom and maintenance management professionals.

Published:

August 2003

ISBN:

1856174093

## The Practical Pumping Handbook

Author:

Ross Mackay

Description: This practical handbook covers the basics of all types of pumping systems. Mechanics, hydraulics, and cavitation are discussed, as well as pump selection, installation and troubleshooting. Materials, friction losses, and fluid properties are also covered.

Published:

June 2004

ISBN:

1856174107

## Pump Users Handbook, 4 th Edition

Author: R. Rayner

Description: This book assists users in ordering pump equipment and recognizing fundamental operating problems. The principles of pumping, hydraulics, and fluids are discussed, as are the various criteria necessary for pump and ancillary equipment selection.

Published:

December 1995

ISBN:

1856172163

## Pumping Manual, 9 th Edition

Author: Christopher Dickenson

Description: This resource provides information and data on the selection, installation, operation, and maintenance of industrial pumps for most applications. The contents follow a sequence of pump evolution, performance and characteristics, pump types, practice and operation, and much more.

Published:

January 1995

ISBN:

1856172155

## Submersible Pumps and Their Applications

Author: Harold Anderson

Description: In this comprehensive manual, the characteristics and applications of submersible pumps are described in detail. The reader is provided with necessary information for the selection, operation, and maintenance of all submersible pumps.

Published:

December 1986

ISBN:

0854610987

## Sulzer Centrifugal Pump Handbook, 2 nd Edition

Author: Sulzer Pumps, Sulzer Pump Division Description: This handbook discusses the recent progress made in pump construction, looking at experiences gained by CCM-Sulzer and other pump construction industry members. Areas such as cavitation, erosion, selection of materials, rotor vibration behavior, forces acting on pumps, operating performance in various types of circuitry, drives, and acceptance testing are covered in detail. The handbook is directed to planners and operating companies alike. Published: January 1992; Republished 1998 ISBN: 1856173461

## Troubleshooting Centrifugal Pumps and Their Systems

Author: Ron Palgrave, Group Engineering Director, David Brown Guinard Pumps, Textron, Sheffield, UK

Description: Pumps are fine until they malfunction or break down. When that happens, the first priority is to get the pump functioning again and to keep downtime to a minimum. Many problems can be diagnosed and rectified using a combination of knowledge and experience, the latter coming over time. This book, written by a very experienced engineer, guides the reader through diagnostic pathways leading to logical explanations for the malfunctions and their correction.

Published:

November 2002

ISBN:

1856173917

## Energy Center of Wisconsin

595 Science Drive

Madison ,WI 53705

Phone: 608-238-4601

Fax: 608-238-8733

www.ecw.org

Published:

1998

## Performance Optimization Training Manual Fans, Pumps and Blowers

Description: This 300-page comprehensive manual offered by the Energy Center of Wisconsin covers optimization techniques that are applicable to fan, pump and blower systems. The book reviews turbomachinery fundamentals, system fundamentals, performance optimization opportunities, feasibility study methodology, electrical metering, field performance testing, adjustable speed drives in performance optimization, and more.

## Flowserve Corporation

222 W. Las Colinas Boulevard

Suite 1500

Irving, TX 75039

Phone: 972-443-6500

www.flowserve.co m

## Cameron Hydraulic Data, 19 th Edition

Editor: C.C. Heald

Description: This comprehensive text includes hydraulic principles and the properties of liquids, selected formulas and equivalents, friction data, steam and electrical data tables, and a full-color selection guide of products. This edition also provides detailed information on reciprocating pumps, pulsation analysis, and system piping. Published: December 2002

## Hydraulic Institute

9 Sylvan Way

Parsippany, NJ  07054

Phone: 973-267-9700

www.pumps.org

## Engineering Data Book

Author: Hydraulic Institute

Description: This reference book for fluid flow in pipelines is designed to help with problems in transferring and pumping fluids. It includes methods for measuring viscosity and calculating various friction losses and includes the characteristics of different piping materials and vapor pressure charts for many compounds. Published: 1990

ISBN:

1880952017

## Pump Life Cycle Costs: A Guide to LCC Analysis for Pumping Systems

Authors: Europump and the Hydraulic Institute Description: This guidebook presents engineering, design, specification, and analytical methodologies for optimizing pump system designs and maxi-

mizing pumping system lifetime cost savings. The design, operation, maintenance, energy, piping, controls, flows, and fluid dynamics of pump systems can be optimized to minimize total life-cycle costs.

Published:

2001

ISBN:

1880952580

## Pump Standards

Author: Hydraulic Institute

Description: This set of standards is designed to facilitate communication and understanding between manufacturers, purchasers, and users. These standards also assist the purchaser in selecting the proper product for a particular application. Available in hard copy, CD-ROM, or online at www.pumps.org .

Published:

2002

## Variable Speed Pumping:  A Guide to Successful Applications

Authors: Europump and the Hydraulic Institute Description: This educationally oriented guide helps users focus on cost savings and performance optimization of pumping systems with variable speed drive technology. Compiled and written by motor and drive experts in industry and academia, the guide is applicable to both new and retrofit installations. System and performance curves, control principles, selection process, financial justification, tables, illustrations, color photographs, case studies, and flow charts are included to help clarify the appropriate specification methodology. Published: 2004

ISBN:

1856174492

## Industrial Press

200 Madison Avenue

New York, NY 10016

Phone: 212-889-6330

www.industrialpress.com

## Metering Pump Handbook

Authors: Robert E. McCabe, Philip G. Lanckton, and William V. Dwyer, Pulafeed Division/ CLEVEPAK Corporation

Description: This handbook is designed for metering pump designers and engineers working in all industries. It presents the basic principles of the positive displacement pump; develops in-depth analysis of the design of reciprocating metering pumps and their piping systems; and demonstrates the practical implementation of these concepts through examples of actual pump applications. Easily accessible information includes fundamentals of metering pump operation, principles of pump and piping system design, guidelines for selection of pump construction materials, procedures for the installation, operation, and maintenance of metering pumps, and general formulas, tables, charts, and pumping system layouts.

Published:

June 1984

ISBN:

0831111577

## Kluwer Academic Publishers

233 Spring St Fl 7 New York, NY 10013-1522 Phone: 212-620-8000 www.wkap.nl

## Centrifugal Pump User's Guidebook: Problems and Solutions

Author: Shmariahu Yedidiah

Description: Written for designers, manufacturers, and researchers, this reference text provides complete up-to-date information on how to attain and maintain optimum performance from centrifugal pumps. It offers a hands-on approach to diagnosing and solving problems that will help all pump users, from the novice to the experienced. It includes the cause and effect of recirculation as well as its function, specific aspects of cavitation, problems encountered during tests, and more. Published: 1996

ISBN:

041299111X

## Centrifugal Pumps, Second Edition

Authors: Igor J. Karassik and J. Terry McGuire Description: This reference book includes practical information on all aspects of centrifugal pumps. With classifications of various forms of centrifugal pumps and the essential features of pump construction, application, installation, operation, and maintenance, the second edition provides owners,

designers, operators, and maintenance personnel with basic information on how to determine pump ratings that best meet application requirements; operate pumps efficiently; maintain pumps to reduce the number of needed overhauls; and ensure that pumps remain in peak condition. This book is out of print, so availability is limited.

## Krieger Publishing

P.O. Box 9542

Melbourne, FL 32902

Phone: 407-724-9542

www.krieger-publishing.com

## Centrifugal and Axial Flow Pumps: Theory, Design, and Application, 2 nd Edition

Author:

Alexey J. Stepanoff

Description: This pump industry standard includes the ranges of head per stage, total pressure, temper- ature, speed, and size. Theoretical aspects, design procedures, and applications are covered for both

pump types.

Published:

May 1992

ISBN:

0894647237

## Pump Operation &amp; Maintenance

Author: Tyler G. Hicks

Description: This practical guide is designed for plant operating and management personnel. It demonstrates how to operate and maintain pumps used in industrial, municipal, central station, marine, and institutional settings. Specific step-by-step instructions for installing, starting up, operating, maintaining, and overhauling are provided for every major class and type of pump.

Published:

June 1982

ISBN:

0898744091

## The Reciprocating Pump:  Theory, Design, and Use, 2 nd Edition

Author: John E. Miller

Description: This book provides detailed information on reciprocating pumps from the perspective of both the designer and the user. Included are details of special pump applications, theory, design, and much more.

Published:

January 1995

ISBN:

089464599

## Marcel Dekker

270 Madison Avenue

New York, NY 10016 Phone: 212-696-9000 www.dekker.com

## Centrifugal Pump Clinic, 2 nd Edition

Author: Igor Karassik

Description: This volume (#68) of the Mechanical Engineering Series serves as a working guide for plant and design engineers involved with centrifugal pumps. Sections include application, pump construction, installation, operation, maintenance, and field troubles.

Published:

1989

ISBN:

0824710169

## Pump Characteristics and Applications

Author: Michael W. Volk

Description: This reference text provides a practical introduction to pumps and the tools necessary to select, size, operate, and maintain them properly. The book highlights the interrelatedness of pump engineering from system and piping design to installation and start-up. Included is an IBM-compatible disk that illustrates how software can facilitate the sizing and analysis of piping systems.

Published:

January 1996

ISBN:

0824795806

## McGraw-Hill

P.O. Box 182604

Columbus, OH 43272

Phone: 877-833-5524

www.mcgraw-hill.com

## Centrifugal Pump Sourcebook

Authors: John W. Dufour and William E. Nelson Description: This guide to centrifugal pump operation and maintenance also offers advice on installation and troubleshooting. It features guidance on pump technology, curves, hydraulic loads and bearings, mechanical seals, vertical pumps, alignment, and suction performance. Published: September 1992 ISBN: 0070180334

## Pump Handbook, Third Edition

Authors: Igor J. Karassik, Joseph P. Messina,

Paul Cooper, and Charles C. Heald Description: This fully revised, expanded edition provides fast, accurate answers to all kinds of pump-related questions. It includes information on current data on pump design procedures, selection and purchase of pumps, applications, pump drivers, testing procedures, troubleshooting and maintenance, and numerous topics not treated in any other work on pumps. Each section is written by an expert in the field.

Published:

September 2000

ISBN:

0070340323

## Water Pumps and Pumping Systems

Author: James Rishel, P.E.

Description: This book provides guidance for achieving the highest pump performance with the lowest energy and maintenance costs for any type of water pumping system.

Published:

July 2002

ISBN:

0071374914

## Prentice Hall

Route 9W Phone:  800-922-0579 www.prenhall.com

Englewood Cliffs, NJ  07632

## Pump Application Desk Book, 3 rd Edition

Author: Paul N. Garay, P.E.

Description: This guide helps end users solve problems associated with all types of pump applications. It examines in detail pumping viscous fluids, specifying variable speed pumping controls, using pump curves, slurries and their associated problems, pump seals, and pump categories and uses. Illustrated with numerous tables and figures to guide users in selecting the optimum pump and avoiding common problems.

Published: August 1996

ISBN:

0136077714

## Taylor &amp; Francis Group plc

11 New Fetter Lane London, EC4P 4EE, UK www.tandf.co.uk

## Cavitation and the Centrifugal Pump: A Guide for Pump Users

Author:

Edward Grist

Description: This book explains the problem of cavitation in centrifugal pumps and how it can be measured, treated, and most important, avoided. The information provided is based on Grist's extensive experience in the design, manufacture, and operation of centrifugal pumps. Published: June 1998 ISBN: 1560325917

## Magazines and Periodicals

## Elsevier Science

P.O. Box 945 New York, NY  10159 Phone: 800-545-2522

www.elsevier.com

## Pump Industry Analyst

This monthly newsletter is written for suppliers of pumps and associated equipment, distributors, ancillary equipment manufacturers, trade associations, government bodies, financial institutions, consultants, independent market researchers, and major end users of plant equipment. It is designed to help the reader plan sound business strategies for the future based on accurate, impartial data. It provides summaries of market and industry statistics, analyses of market information on pump end user industries, and points out key indicators of emerging trends and their impacts on the marketplace.

## World Pumps

This international technical magazine is devoted to the selection, installation, and maintenance of pumps and pumping machinery, components, and ancillary equipment. It provides purchasers and users of pumps, seals, valves, and motors with an

authoritative source of practical and technical information. Included are feature articles from pump users and manufacturers, news of product developments and applications, case studies, business news, financial reports, exhibition coverage, annual directories, and a monthly product finder service. The World Pumps Web site, www.worldpumps.com , provides many articles and links to the latest relevant literature and software.

## Pumps and Systems

P.O. Box 530067 Birmingham, AL 35253 Phone: 205-212-9402 www.pump-zone.com

## Pumps and Systems

This monthly magazine discusses issues for the industrial pump user. New products and technologies, problem-solving methods, and design practices are described within the context of industrial pump applications. This magazine also compiles an annual Users Guide that lists pump manufacturers by pump type, and a Pumps Handbook CD-ROM that can be ordered from Pumps and Systems' PumpZone Web site, www. pump-zone.com.

## Witter Publishing Corporation

84 Park Avenue Flemington, NJ 08822 Phone: 908-788-0343 Fax: 908-788-3782 www.witterpublishing.com

## Flow Control

This monthly magazine addresses fluid handling and control issues. New products, design issues, and technology developments are discussed, and solutions are provided for system design and operational and maintenance challenges in all process and OEM application.

## Government and Commercial Statistics and Market Forecasts

## Business Trend Analysts, Inc.

2171 Jericho Turnpike Commack, NY  11725-2900 Phone: 516-462-5454 www.businesstrendanalysts.com

## The U.S. Pump and Compressor Industry

This market research report assesses the market for pumps and compressors by gathering data and conducting analyses. The report presents data on U.S. manufacturers' sales and analysis of end-use demand by industry for pumps and compressors. This report also includes pump and compressor industry statistics, U.S. foreign trade figures, corporate profiles, and a directory of pump and compressor manufacturers.

## United States Bureau of the Census

Washington, DC  20233 Phone:  202-512-1800 www.census.gov

## Pumps and Compressors Current Industrial Reports

This annual report provides data on the quantity and value of manufacturers' shipments, number of producers by product type, exports, and imports. These statistics reflect market trends in the pump and compressor industry.

## United States Department of Energy Industrial Technologies Program

1000 Independence Avenue, SW Washington, D.C. 20585 www.eere.energy.gov/industry/bestpractice s

## National Market Transformation Strategies for Industrial Electric Motor Systems, Volume I:  Main Report

This report develops strategic actions for a coordinated and national effort to (1) increase the market penetration of energy-efficient motors

and motor-driven systems and (2) encourage movement from a 'component-focused' to a 'systems-oriented' market. Sections of the report include the following discussions of Process Pump Systems:  'Equipment and Market Overview,' 'Energy Savings PotentialEquipment,' 'Efficiency Data, Standards, and Potential Leverage Points,' 'Specifying Practices and Behavior,' 'System-Level Energy Savings Potential,' and 'Strategy Options.'

## United States Industrial Motor Systems Market Opportunities Assessment

This study, published in December 1998, is based on surveys of motor systems in a probabilitybased sampling of 265 industrial facilities in the United States. It profiles the stock of motor-driven equipment in U.S. industrial facilities and characterizes the opportunities to improve the energy efficiency of industrial motor systems. Designed for manufacturers, distributors, engineers, and others in the supply channels for motor systems, it also provides a profile of current motor system purchase and maintenance practices. It provides a detailed, highly differentiated portrait of end-use markets. The study presents information factory managers can use to identify motor system energy savings opportunities in their facilities and to benchmark their current motor system purchase and management procedures against best practices concepts.

## Software

## ABZ, Incorporated

4451 Brookfield Corporate Drive, Suite 101 Chantilly, VA 20151 Phone: 800-747-7401

www.abzinc.com

## Design Flow Solutions

Complete hydraulic analysis of complex piping systems, including up to 9,000 branches and 1,000 tees. Network branches can consist of any combination of pipes, fittings, and valves, with virtually no limit on the number or type of components. The program uses the Darcy-Weisbach formula with Bernoulli's theorem for liquids and the differential form of Bernoulli's theorem with numerical integration techniques for gases.

## Animated Software Company

625 East Bunker Court

Vernon Hills, IL  60061

Phone: 800-323-4340

www.animatedsoftware.com

## All About Pumps

This interactive Flash program, intended to teach all of the essentials about pumps, includes sections titled 'Where Pumps are Used,' 'How Pumps Work,' 'Types of Pumps,' 'Measuring Pump Performance,' 'The Right Pump for the Job,' 'Historical Background &amp; Some Famous Pumps,' and 'The Most Amazing Pump of All.'  Also included is a glossary of individual pumps.

## Applied Flow Technology

400 W. Highway 24, Suite 201 Woodland Park, CO 80863 Phone: 800-589-4943 www.aft.com

## AFT Arrow

AFT Arrow provides comprehensive, compressible pipe flow analysis and system modeling capabilities. Addressing open- and closed-loop systems, Arrow includes a built-in library of fluids and fittings, variable model configurations, fan/ compressor and control valve modeling, and more. With the optional Chempak add-in, a thermophysical database of approximately 600 gases is available, allowing thermal analysis capabilities including piping heat transfer, heat exchanger modeling, and varying fluid properties.

## AFT Fathom

AFT Fathom provides comprehensive, incompressible pipe flow analysis and system modeling capabilities. Addressing open- and closed-loop systems, Fathom includes a built-in library of fluids and fittings, variable model configurations, pump and control valve modeling and more. With

the optional Chempak add-in, a thermo-physical database of over 600 fluids is available, allowing thermal analysis capabilities such as piping heat transfer, heat exchanger modeling, and varying fluid properties.

## AFT Impulse

Waterhammer analysis tools of the past have been difficult to use and have required extensive specialized knowledge. As a result, this critical aspect of piping system design and operation has often been overlooked. AFT Impulse™ offers the ease of use of a drag-and-drop interface and builtin waterhammer modeling expertise. AFT Impulse helps you design and operate systems with greater reliability and safety by avoiding the effects of waterhammer and other undesirable system transients.

## AFT Mercury

AFT Mercury, powered by IntelliFlow, is the first software product to offer the piping systems engineer intelligent, automated sizing of system piping, ducting, and components to achieve this goal. With comprehensive system modeling capabilities, a flexible graphical interface and an advanced optimization engine, AFT Mercury with IntelliFlow is a new technology that can produce significant cost savings on piping systems.

## Concepts ETI

217 Billings Farm Road White River Junction, VT 05001-9486 Phone: 802-296-2321 www.conceptseti.com

## CCAD

CCAD allows users to design their pump systems down to the smallest detail. The program creates geometries for various inlets, impellers, inducers, diffusers, crossovers, nozzles, and volutes. Included is a quasi-3D flow analysis for testing the designs. CCAD is compatible with other Concepts ETI programs, such as PUMPAL, allowing designs to be transferred with seamless integration.

## PUMPAL

PUMPAL uses a design wizard to create a pump system model. The program analyzes the input and creates integrated performance maps for a quick review of performance and comparison of multiple designs, or analysis vs. test data. The report generator easily formats tables and plots into a report, with a flexible template approach. The program can be integrated with geometries created in CCAD.

## Crane Valves

2129 3 rd Avenue SE Cullman, AL 35055 Phone: 800-323-3679

www.cranevalve.com

## Crane's Flow of Fluids 7.0 Premium Software

Piping system design software optimized for highspeed computers, this program offers enhanced flexibility and customization with piping designs and system modeling. It includes pump and valve sizing wizards, and a new Fluid Zone feature, which allows the user to quickly modify fluid properties across multiple pipelines. The results of software runs are displayed professionally with tabular reports and can be easily imported into spreadsheet programs like Microsoft Excel.

## Electric Power Research Institute

Power Electronics Applications Center 942 Corridor Park Boulevard Knoxville, TN 37932 Phone: 865-218-8000 www.epri-peac.com

## ASDMaster

This software package consists of six modules designed to educate and assist users in the proper application of adjustable speed drives. ASDMaster contains instruction tools that discuss the technology, process effects, and power quality issues associated with ASDs. It analyzes energy consumption and performance differences between ASDs and constant-speed alternatives. ASDMaster also contains a database module that refers the user to manufacturers of ASDs that can meet the needs of the application.

## Engineered Software Inc.

4531 Intelco Loop SE

Lacey, WA  98584-5941

Phone: 360-412-0702

www.eng-software.com

## FLO-SERIES

FLO-SERIES software consists of these four programs: (1) PIPE-FLO: piping system design and hydraulic system analysis containing a graphic flowsheet user interface; (2) PUMP-FLO: centrifugal pump selection and evaluation capable of containing over 50 manufacturer's catalog curves; (3) ORI-FLO: flow meters and orifice sizing; and (4) CON-FLO: control valves. These programs are available individually or as a package. They share and exchange data for complete system analysis but are not interdependent.

## SYSTEK Technologies, Inc.

Phone:  928-453-9587

Fax:  630-214-6951

www.systek.us

## PUMPCALC Centrifugal Pump Analysis

Using affinity laws, PUMPCALC analyzes the performance of a centrifugal pump at different impeller sizes, speeds, and stages from the pump manufacturer's data. The speed or diameter required to meet a specific design condition can be calculated. Performance of pumps in series and in parallel can be predicted. For high-viscosity liquids, the water performance curve is corrected for viscosity using the Hydraulic Institute Method. PUMPCALC, a Web-based program, performs the viscosity correction calculations quickly and accurately using built-in charts. The resulting performance curves can be plotted on the screen as well as on the connected printer.

## Tahoe Design Software

P.O. Box 187 Nevada City, CA 95959 Phone: 530-470-8413

www.tahoesoft.com/index.htm l

## HYDROFLO

This software is a hydraulic system design tool that substantially reduces the time involved in designing systems that convey a fluid from point to point. Up to nine parallels (10 pumps) can be modeled with a drag-and-drop system. In a matter of minutes an engineer can lay out, analyze, and present a number of design alternatives for gravity, pump station, and forced-flow systems. HYDROFLO can launch PumpBase and transfer operating point, project information, and liquid property data with a single click. Detailed reports, diagrams and graphs of system data are available for output to screen, printer, or file.

## PumpBase

This program is an advanced pump specification software package for Windows. Fluid-handling specialists and hydraulic system designers can specify up to 40 different selection criteria and view graphs of the most efficient pump curves that meet their needs. The software includes a database of thousands of curves from dozens of manufacturers as well as an extensive database of liquid properties. It creates a detailed report that can be submitted to pump manufacturers or sales representatives for further application verification and price quotes. Custom selection software for specific product lines is available.

## Unicade, Inc.

P.O. Box 70405 Bellevue, WA 98015, USA Phone/Fax:  425-702-0700 www.unicade.com

## C-MAX Pump Software

The software performs energy and performance calculations for various pump/compressor systems. Economic analyses are also performed and energy savings for different scenarios can be calculated. The program allows the user to set up a pump/ compressor system, including choices for different pipe fittings, valves, and geometries. Energy and performance calculations are then performed. The software readily converts the results to any system of units.

## United States Department of Energy Industrial Technologies Program

1000 Independence Avenue, SW Washington, D.C. 20585

www.eere.energy.gov/industry/bestpractice s

## MotorMaster+

This software package assists users in calculating motor operating costs and tracking the installation and service characteristics of a plant's motor inventory. MotorMaster+ also contains a database of motors from which the user can select an appropriate model. The software allows special service requirements to be considered, such as high starting torque, severe duty, two-speed drives, inverter duty, and medium voltage (2300 and 4000 V) power supplies. MotorMaster+ allows users to track motor loads, maintenance histories, and energy consumption. It is available for downloading from the DOE ITP BestPractices Web site, www.eere.energy.gov/industry/bestpractices .

## MotorMaster+ International

This software includes many of the capabilities and features of MotorMaster+, but it also allows users to evaluate repair/replacement options on a broader range of motors. The user can conduct analyses in different currencies, calculate efficiency benefits for utility rate schedules with demand charges, edit and modify motor rewind efficiency loss defaults, and determine the 'best available' motors. MotorMaster+ International can be modified to operate in English, Spanish, and French.

## Pumping System Assessment Tool (PSAT)

The Pumping System Assessment Tool is designed to help pump users quickly distinguish systems that are operating effectively from those that can be improved in efficiency. This software is based on motor performance characteristics, obtained chiefly from DOE's MotorMaster+ database, and on achievable pump efficiencies from the Hydraulic Institute standard ANSI/HI 1.3, Centrifugal Pump Design and Application. Users provide the nameplate data (e.g., motor size and rated speed), motor current or power, and measured/required flow rate and head. The software reports potential energy and cost savings that could be achieved by applying an optimized pump and motor combination. (For more information, see Appendix C.)  It is available for downloading from the DOE ITP Web site at www.eere.energy. gov/industry/bestpractices.

## Training Courses

## Concepts ETI

217 Billings Farm Road White River Junction, VT 05001-9486 Phone: 802-296-2321 www.conceptseti.com

## Centrifugal Pump Design and Performance

This five-day course, offered by Concepts ETI, Inc., will inform students about centrifugal pump design principles and practice, including performance limits such as cavitation. It will help students understand and assess design tools and understand the process of pump design optimization. Engineers will come to understand the best state-of-the-art design practices and learn about performance, cavitation, dynamic forces, and noise. For more information, visit www.conceptseti.com/education/cor\_pump.htm.

## Engineered Software Inc.

4531 Intelco Loop SE

Lacey, WA  98584-5941

Phone: 360-412-0702

www.eng-software.com

## FLO-SERIES Training Courses

Engineered Software Inc. offers training courses on its FLO-SERIES software (see above).

## Hydraulic Institute

9 Sylvan Way Parsippany, NJ  07054 Phone: 973-267-9700 www.pumps.org

## Centrifugal Pumps: Fundamentals, Design and Applications

The Hydraulic Institute offers this two-part, sixmodule, online training course, available at www. pumplearning.org as well as on a CD-ROM. The course provides a wealth of information designed by industry experts and developed exclusively for pump users, manufacturers, engineers, contractors, specifiers, and others who work with pumps and pumping systems. HI also offers 'Energy Reduction in Pumps and Pumping Systems,' an hourlong video education program produced with DOE that includes three student workbooks, answer books, and an instructor's manual.

## ITC Learning Corporation

13515 Dulles Technology Drive Herndon, VA  22071-3416 Phone: 703-638-3757 Fax: 703-713-0065

## Hydraulic System Video Courses

ITC offers many videos on hydraulic pump systems, including courses on controls and actuators. Introductory and troubleshooting courses are also available from ITC or TWI Press, Inc.

## Pump and Compressor Maintenance Video Courses

ITC offers video courses on pump/compressor maintenance, namely for centrifugal pumps and air compressors. They are available from ITC or TWI Press, Inc.

## Job Training Systems, Inc.

P.O. Box 868

Unionville, PA  19375

Phone: 610-444-0868

www.jobtraining.com

## Centrifugal Pumps

The topics covered in this course include operating characteristics and identification of parts of centrifugal pumps, flow-through pumps, mechanical and packing seals, seal flush, parts of an impeller, identification of impellers, discharge pressure versus flow, power requirements versus flow, effect of specific gravity on power requirements, multistage operation, methods of priming centrifugal pumps, operating characteristics of self-priming centrifugal pumps, types of oil lubrication, grease-lubrication bearings, bearing housing temperatures, and cavitation and gassing of centrifugal pumps.

## Mechanical Solutions, Inc.

1719 Route 10 East, Suite 205

Parsippany, NJ 07054-4507

Phone: 973-326-9920

www.mechsol.com

## Modal Testing

MSI offers an on-site training course on modal testing of pumps, compressors, turbines, motors, and impellers. Real world test data are coupled with a finite element analysis to provide calibrated analytical models. Trainees learn how to use this software to perform 'what-if' analyses and determine the best corrective actions.

## Rotodynamic Analysis

MSI will provide on-site, detailed rotodynamic analysis and training for turbomachinery power trains, including centrifugal pumps, reciprocating pumps, compressors, and motor turbine pumps. Rotor critical speed, undamped and forced responses, and stability are all checked, and users of the equipment are trained in how to check it themselves. Methods of troubleshooting are also discussed.

## Vibration and Noise Testing

MSI offers an on-site training course on vibration and noise testing of pumps, compressors, turbines, and motors. MSI will provide the latest hardware and software for diagnosing vibration problems, explaining how they work and how to treat the problems.

## National Technology Transfer, Inc.

P.O. Box 4558

Englewood, CO  80155

Phone: 800-922-2820

Fax: 800-838-8441

www.nttinc.com

## National Technology Transfer, Inc., Courses

National Technology Transfer offers a wide variety of courses related to pumps and pump applications. From a two-day seminar on centrifugal pumps covering theory, selection, design, maintenance, and troubleshooting to a three-day Pneumatic Training course, National Technology Transfer offers courses nationwide for engineers, consultants, plant and maintenance personnel, and others.

## Ross Mackay Associates Ltd.

240 Portage Rd., Ste. 670 Lewiston, NY 14092 Phone: 800-465-6260 www.rossmackay.com

## Mackay Pump School

The Mackay Pump School is a two-day course covering the integrated areas of system hydraulics, pump mechanics, and seal operation. The course is designed to help operations and maintenance personnel reduce production losses and downtime. Course topics include pump and system curves, NPSH, cavitation, air entrainment, seal problems, shaft deflection, bearing considerations, and piping configurations. A video series from the Mackay Pump School is also available.

## Volk &amp; Associates

3062 Arizona Street

Oakland, CA 94602

Phone: 800-733-8655

## Pump Training - From an Industry Expert

This course offered by Michael Volk covers hydraulic principles, pump selection and sizing, system design and analysis, energy savings, troubleshooting, computer software, and applications.

## United States Department of Energy Industrial Technologies Program

1000 Independence Avenue, SW Washington, D.C. 20585 www.eere.energy.gov/industry/bestpractice s

## Pumping System Assessment

This one-day training session provides an in-depth discussion of energy efficiency factors for pumping systems, emphasizing the system as a whole rather than the components. Indicators and symptoms of potential energy reduction opportunities are discussed. Application and use of the Pumping System Assessment Tool (PSAT) software is also covered (see Appendix B for a description). The training was developed to introduce users to the software (a CD with the PSAT software is provided) and to provide guidance on field measurement considerations. There are three general elements:

- 1.  An overview of pump, motor, adjustable speed drive, and fluid system performance characteristics
- 2.  Practical issues involved in field measurements of fluid and electrical data
- 3.  Use of the PSAT software, including application to real-world situations (case studies).

## Qualified Pump System Specialist Training

This session covers in two and one-half days the energy efficiency factors addressed in the one-day Pumping System Assessment training described above, as well as case studies and additional instruction on the use of PSAT software. It concludes with a rigorous written exam. Those successfully completing the exam are recognized as Qualified Pump System Specialists.

## Online Information

## Elsevier Science

P.O. Box 945

New York, NY  10159

Phone: 800-545-2522

www.elsevier.com

## World Pumps: www.worldpumps.com

The Web site for World Pumps magazine contains a great deal of useful information. The business and product news is kept up-to-date, and new books, reports, and software for pumps are in the Literature Showcase. An online bookstore and buyer's guide is included. World Pumps magazine articles and other features are also included.

## Hydraulic Institute

9 Sylvan Way

Parsippany, NJ  07054

Phone: 973-267-9700

www.pumps.org

## The Hydraulic Institute: www.pumps.org

The Hydraulic Institute's Web site provides a vast array of pump resources, including a supplier finder database. The site also includes press releases, news updates, and a discussion forum for pump users, as well as an e-store where various pump products can be purchased.

## Process Industrial Training Technologies, Inc.

Phone: 513-574-1666

Fax: 513-574-1358

www.iglou.com/pit t

## Process Pumps &amp; Filtration On-Line: www.iglou.com/pitt

This Internet magazine contains articles, product listings and descriptions, and news about the pump industry.

## Pump World

P.O. Box 746 Forrest Hill, MD 21050 www.pumpworld.com

## Pump World: www.pumpworld.com

Through the use of educational tutorials for centrifugal and positive displacement pumps, Pump World is dedicated to the advancement of the pump industry on the Web. The tutorials include information on pump terminology and operation, performance curves, pump selection, troubleshooting, and preventive maintenance. Also included are pump application and system head/pressure forms that end users, pump distributors, and manufacturers can use.

## Pumps &amp; Systems

P.O. Box 530067

Birmingham, AL 35253

Phone: 205-212-9402

www.pump-zone.com

## Pump-Zone: www.pump-zone.com

This Web site is maintained by Pump &amp; Systems magazine. The site includes 'Product Spotlights,' pump application data, feature articles, a software store, links to pump company Web sites, and all the current pump news.

## Thomas Publishing Company

Five Penn Plaza

New York, NY  10001

Phone: 800-222-1900

www.thomasregister.com

## Thomas Register of American Manufacturers: www.thomasregister.com

This searchable online directory lists manufacturers in a variety of industries. Participating companies can include product catalogs, online ordering information, and links to Web sites. It is also available in print.

## United States Department of Energy Industrial Technologies Program

1000 Independence Avenue, SW Washington, D.C. 20585 Phone: 202-586-7547

www.eere.energy.gov/industry/bestpractice s

Many ITP BestPractices resources that are specific to motor systems-e.g., publications, software tools, and training information-are available on the Web at www.eere.energy.gov/industry/ bestpractices.  For more information, you can also contact the EERE Information Center for information by calling 877-337-3463 or by sending an e-mail to eereic@ee.doe.gov.

## Pumping System Equipment Manufacturers

Manufacturers are often a useful source of technical information, not only for product data but also for maintenance practices, troubleshooting, and training. In addition, many manufacturers provide software that can assist purchasers in selecting the proper model for a given set of service requirements. To locate specific pumping system manufacturers, refer to the Thomas Register of American Manufacturers ( www.thomasregister.com ), the member listings of trade association magazines, and the 'Supplier Finder' on the Hydraulic Institute's Web site ( www.pumps.org ).

<!-- image -->

The following appendices are included in the Sourcebook:

## ■ Appendix A: Glossary of Basic Pumping System Terms

This appendix contains a glossary of terms used in pumping systems.

## ■ Appendix B: Pumping System Assessment Tool (PSAT)

This appendix contains a description of the PSAT and how it can be obtained online.

## ■ Appendix C: Pumping Systems Tip Sheets

This appendix contains a series of pumping system tip sheets. Developed by DOE, these tip sheets discuss common opportunities in industrial facilities to improve pump performance and reduce energy use.

## ■ Appendix D: Guidelines for Comments

This appendix contains a form readers can use to comment on ways to correct and improve this sourcebook.

## Appendix A: Glossary of Basic Pumping System Terms

absolute pressure - Total force per unit area in a system (includes vapor pressure and atmospheric pressure).

adjustable speed drives (ASDs) - Devices that allow control of a pump's rotational speed. ASDs include mechanical devices such as hydraulic clutches and electronic devices such as eddy current clutches and variable frequency drives.

affinity laws -  A set of relationships that tie together pump performance characteristics such as pressure, flow, and pump speed.

allowable operating region - The precise limits for minimum and maximum flow in a pump.

axial pump - Sometimes called a propeller pump , this type of pump has a single-inlet impeller; the flow enters axially and discharges nearly axially.

backpressure - The pressure on the discharge side of the pump.

bearing - A device that supports a rotating shaft, allowing it to spin while keeping it from translating in the radial direction. A thrust bearing keeps a shaft from translating in the axial direction.

best efficiency point (BEP) - Commonly used to describe the point at which a centrifugal pump is operating at its highest efficiency, transferring energy from the prime mover to the system fluid with the least amount of losses.

brake horsepower (bhp) - The amount of power (measured in units of horsepower) delivered to the shaft of a motor-driven piece of equipment.

cavitation - A phenomenon commonly found in centrifugal pumps in which the system pressure is less than the vapor pressure of the fluid, causing the formation and violent collapse of tiny vapor bubbles.

centrifugal pump - A pump that relies on a rotating, vaned disk attached to a driven shaft. The disk increases fluid velocity, which translates to increased pressure.

check valve - A valve that allows fluid to flow in one direction only; it is generally used to maintain header pressure and protect equipment from reverse flow.

deadhead - A condition in which all the discharge from a pump is closed off.

dynamic head - The component of the total head that is attributable to fluid motion (also known as velocity head).

gauge pressure - A measure of the force per unit area using atmospheric pressure as the zero reference.

head - A measure of pressure (expressed in feet) indicating the height of a column of system fluid that has an equivalent amount of potential energy.

header - A run of pipe that either supplies fluid to (supply header) or returns fluid from (return header) a number of system branches.

heat exchanger - A device that transfers heat from one fluid to another.

horsepower (hp) - A measure of the work or energy flux per unit time; the rate at which energy is consumed or generated.

impeller - A centrifugal pump component that rotates on the pump shaft and increases the pressure on a fluid by adding kinetic energy.

kinetic energy - The component of energy that is due to fluid motion.

load factor - A ratio of the average capacity to the rated full capacity (in terms of power), determined by the following relationship:

(Actual load ∑ x number of operating hours at this load) Load factor  = (Rated full load x number of operating hours in the period)

mechanical seal - A mechanical device for sealing the pump/shaft interface (as opposed to packing).

minimum flow requirement - A manufacturerspecified limit that represents the lowest flow rate at which the pump can operate without risking damage from suction or discharge recirculation.

motor - An electric machine that uses either alternating current (ac) or direct current (dc) electricity to spin a shaft. Typically, this shaft is coupled to a pump. Occasionally, however, mechanisms such as a slider/crank convert this rotation to axial movement to power piston pumps.

motor controller - An electric switchbox that energizes and de-energizes an electric motor.

packing - A form of a pump seal that prevents or minimizes leakage from the pump stuffing box. Packing is usually a flexible, self-lubricated material that fits around the pump shaft, allowing it to spin while minimizing the escape of system fluid between the shaft and the pump housing.

preferred operating region - The region on a pump curve where flow remains well controlled within a range of capacities. Within this region hydraulic loads, vibration, or flow separation will not significantly affect the service life of the pump.

performance curve - A curve that plots the relationship between flow and head for a centrifugal pump. The vertical axis contains the values of head while the horizontal axis contains flow rates. Since flow rate varies with head in a centrifugal pump, performance curves are used to select pumps that meet the needs of a system.

pony pump - A pump that is usually associated with a larger pump in a multiple-pump configuration. The pony pump typically handles normal system requirements, while the larger pump is used during high demand periods.

positive displacement pump - A pump that pressurizes a fluid using a collapsing volume action. Examples include piston pumps, rotary screw pumps, and diaphragm pumps.

pressure - Force per unit area; commonly used as an indicator of fluid energy in a pumping system (expressed in pounds per square inch).

prime mover - A machine, usually an electric motor, that provides the motive force driving a pump.

radial pump In this type of pump, the liquid enters the impeller at the hub and flows radially to the periphery.

recirculation - A flow condition which occurs during periods of low flow, usually below the minimum flow requirement of a pump. This condition causes cavitation-like damage, usually to the pressure side of an impeller vane.

relief valve - A valve that prevents excessive pressure buildup. Often used on the discharge side of a positive displacement pump and in applications where thermal expansion of a system fluid can damage system equipment.

specific gravity - The ratio of the density of a fluid to the density of water at standard conditions.

specific speed - An index used to measure the performance of an impeller; it represents the speed required for an impeller to pump one gallon per minute against one foot of head and is defined by the equation:

<!-- formula-not-decoded -->

static head - The head component attributable to the static pressure of the fluid.

stiction - Static friction (frictional resistance to initial motion).

stuffing box - The part of a pump where the shaft penetrates the pump casing.

suction specific speed - An index used to describe the inlet conditions of a pump; it is defined by the equation:

<!-- formula-not-decoded -->

total head - A measure of the total energy imparted to the fluid by a centrifugal pump. This value includes static pressure increase and velocity head.

valve - A device used to control fluid flow in a piping system. There are many types of valves with different flow control characteristics, sealing effectiveness, and reliability.

valve seat - The component of a valve that provides the sealing surface. Some valves have just one seat; others have a primary seat, which prevents leakage across the valve, and a back seat, which prevents leakage from the valve to the environment.

vapor pressure - The force per unit area that the fluid exerts in an effort to change the phase from a liquid to a vapor. This pressure is a function of a fluid's chemical and physical properties, and its temperature.

variable frequency drive (VFD) - A type of adjustable speed drive that controls the speed of ac motors by regulating the frequency of the electric power. VFDs are the most common type of adjustable speed drives and can significantly reduce energy use by matching the speed of driven equipment to required output.

velocity head - The component of the total head that is attributable to fluid motion (also known as dynamic head).

viscosity - The resistance of a fluid to flow when subjected to shear stress.

## Appendix B: Pumping System Assessment Tool

The Pumping System Assessment Tool (PSAT) is a software program developed by the Department of Energy's (DOE) Industrial Technologies Program (ITP) to assist engineers and facility operators in performing assessments of pumping system energy usage. PSAT is also well suited for performing plant energy usage surveys by consultants or plant engineers. End users in the field will find PSAT easy to use because it was carefully designed to require only the minimum essential operation data (or requirements) to perform an analysis.

For many industrial facilities, the energy consumed in pumping fluids comprises a large fraction of the total energy consumption of the facility. However, operators are often not aware of how effectively energy is being consumed in pumping systems. The PSAT tool provides a relatively simple and fast means of determining system efficiency and potential alternatives. In addition, the PSAT prescreening filter can identify areas that are likely to offer the greatest savings.

PSAT identifies energy savings opportunities in pumping systems and quantifies those opportunities in both dollars and electrical energy savings. Although PSAT does not tell how to improve systems, it does prioritize attractive opportunities and supports broader or narrower searches for improving efficiency.

PSAT requires three fundamental field measured parameters: flow rate, head, and motor power (or current). Using this data, along with some general design and nameplate information, such as pump style (selected from a list), motor size (hp), rated speed, and fluid density, generally achievable pump and motor efficiencies and optimal power requirements are estimated.

PSAT assesses current pump system operating efficiency by comparing field measurements of the power delivered to the motor with the fluid work

(flow and head) required by the application. It estimates a system's achievable efficiency based on pump efficiencies (from Hydraulic Institute standards) and performance characteristics of pumps and motors (based on the MotorMaster+ database).

PSAT can be used to perform the following key functions:

- ■ Establish system efficiency
- ■ Quantify potential energy savings
- ■ Examine the economic and energy impacts of different operating scenarios
- ■ Provide data for trending system performance
- ■ Clarify impacts of operational changes on demand charges
- ■ Identify degraded or poorly performing pumps.

Additional information on PSAT is provided in Section 3.

## Qualification Program

The U.S. Department of Energy offers a qualification training program for pumping system specialists in the use of its PSAT software. Attendees who successfully complete a PSAT qualification workshop will be recognized as Qualified Pump System Specialists and will receive a certificate from DOE with this designation.

## How to Obtain PSAT

The PSAT and its User Manual can be downloaded from the ITP BestPractices Web site, www.eere.energy.gov/industry/bestpractices . The user can also obtain a version by contacting the EERE Information Center at 877-337-3463.

## Appendix C: Pumping Systems Tip Sheets

A series of tip sheets has been developed to highlight the performance benefits and energy savings that are available in pumping systems. Tip sheet topics include the following:

Conduct an In-Plant Pumping System Survey

Pump Selection Considerations

Select an Energy-Efficient Centrifugal Pump

Test for Pumping System Efficiency

Maintain Pumping Systems Effectively

Match Pumps to System Requirements

Trim or Replace Impellers on Oversized Pumps

Optimize Parallel Pumping Systems

Reduce Pumping Costs Through Optimum Pipe Sizing

Reduce Energy Losses Across Control Valves

Adjustable Speed Pumping Applications

Control Strategies for Centrifugal Pumps with Variable Flow Rates

Several of these tip sheets are included here. The rest are in development and will be available soon from the EERE Information Center and on the ITP BestPracticies Web site, www.eere.energy. gov/industry/bestpractices.

## Conduct an In-Plant Pumping System Survey

Even one pump can consume substantial energy. A continuously operated centrifugal pump driven by a fully loaded 100-horsepower motor requires 726,000 kWh per year. This costs more than $36,000, assuming average electricity costs of 5¢ per kWh. Even a 10% reduction in operating costs saves $3,600 per year. Table 1 summarizes the electrical costs of operating this pump.

| Table 1. Pumping Energy Costs for Pump Driven by 100-hp Motor (assuming a 90% motor efficiency)   | Table 1. Pumping Energy Costs for Pump Driven by 100-hp Motor (assuming a 90% motor efficiency)   | Table 1. Pumping Energy Costs for Pump Driven by 100-hp Motor (assuming a 90% motor efficiency)   | Table 1. Pumping Energy Costs for Pump Driven by 100-hp Motor (assuming a 90% motor efficiency)   | Table 1. Pumping Energy Costs for Pump Driven by 100-hp Motor (assuming a 90% motor efficiency)   | Table 1. Pumping Energy Costs for Pump Driven by 100-hp Motor (assuming a 90% motor efficiency)   |
|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
| Operating Time                                                                                    | Energy Costs for Various Electricity per kWh                                                      | 4¢ per kWh                                                                                        | 6¢ per kWh                                                                                        | Costs 8¢ per kWh                                                                                  | 10¢ per kWh                                                                                       |
| 1 hour                                                                                            | $1.60                                                                                             | $3.30                                                                                             | $4.90                                                                                             | $6.60                                                                                             | $8.20                                                                                             |
| 24 hours                                                                                          | $39                                                                                               | $79                                                                                               | $119                                                                                              | $159                                                                                              | $198                                                                                              |
| 1 month                                                                                           | $1,208                                                                                            | $2,416                                                                                            | $3,625                                                                                            | $4,833                                                                                            | $6,042                                                                                            |
| 1 year                                                                                            | $14,500                                                                                           | $29,000                                                                                           | $43,600                                                                                           | $58,000                                                                                           | $72,600                                                                                           |

##  Surveying Your Pumping Systems

Pumps larger than a minimum size and with significant operating hours should be surveyed to determine a baseline for your current pumping energy consumption and costs, identify inefficient pumps, determine efficiency measures, and estimate the potential for energy savings. The U.S. Department of Energy's (DOE) Pump System Energy Opportunity Screening worksheet will help you identify systems that merit a survey.

The survey team should gather pump and drive motor nameplate information and document operating schedules to develop load profiles, then obtain head/capacity curves (if available) from the pump manufacturers to document the pumping system design and operating points. The team should also note the system flow rate and pressure requirements, pump style, operating speed, number of stages, and specific gravity of the fluid being pumped. If possible, the team should also measure and note the flow rate and the suction and discharge pressures and note conditions that are associated with inefficient pump operation, including indicators such as:

- ■ Pumps with high maintenance requirements
- ■ Oversized pumps that operate in a throttled condition
- ■ Cavitating or badly worn pumps
- ■ Misapplied pumps
- ■ Pumping systems with large flow rate or pressure variations
- ■ Pumping systems with bypass flow
- ■ Throttled control valves to provide fixed or variable flow rates
- ■ Noisy pumps or valves
- ■ Clogged pipelines or pumps
- ■ Wear on pump impellers and casings that increase clearances between fixed and moving parts

## Background

In the United States, more than 2.4 million pumps, which consume more than 142 billion kWh annually, are used in industrial manufacturing processes. At an electricity cost of 5¢ per kWh, energy used for fluids transport costs more than $7.1 billion per year.

- ■ Excessive wear on wear rings and bearings
- ■ Improper packing adjustment that causes binding on the pump shaft
- ■ Multiple pump systems where excess capacity is bypassed or excess pressure is provided
- ■ Changes from initial design conditions. Distribution system cross-connections, parallel main lines, or changes in pipe diameter or material may change the original system curve.
- ■ Low-flow-rate, high-pressure end use applications. An entire pumping system may be operated at high pressure to meet the requirements of a single end use. A booster or dedicated pump may allow system operating pressure to be reduced.

##  Pumping System Efficiency Measures

Measures to improve pumping plant efficiency include:

- ■ Shut down unnecessary pumps. Re-optimize pumping systems when a plant's water use requirements change. Use pressure switches to control the number of pumps in service when flow rate requirements vary.
- ■ Restore internal clearances.
- ■ Replace standard efficiency pump drive motors with NEMA Premium™ motors.
- ■ Replace or modify oversized pumps:
- - Install new properly sized pumps.
- - Trim or change the pump impellers to match the output with system requirements when the pumping head exceeds system requirements. Consult with the vendor to determine the minimum impeller diameter for a pump casing.
- ■ Meet variable flow rate requirements with an adjustable speed drive or multiple pump arrangement instead of throttling or bypassing excess flow.



Suggested Actions



<!-- image -->

- •	 Prescreen	the	pumps	in	your	facility.
- •	 Survey	the	systems	identified	as	priorities.

## Pump Selection Considerations

##  Understanding Your Pumping System Requirements

Pumps transfer liquids from one point to another by converting mechanical energy from a rotating impeller into pressure energy (head). The pressure applied to the liquid forces the fluid to flow at the required rate and to overcome friction (or head) losses in piping, valves, fittings, and process equipment. The pumping system designer must consider fluid properties, determine end use requirements, and understand environmental conditions.

##  Fluid Properties

The properties of the fluids being pumped can significantly affect the choice of pump. Key considerations include:

- ■ Acidity/alkalinity (pH) and chemical composition. Corrosive and acidic fluids can degrade pumps, and should be considered when selecting pump materials.
- ■ Operating temperature. Pump materials and expansion, mechanical seal components, and packing materials need to be considered with pumped fluids that are hotter than 200°F.
- ■ Solids concentrations/particle sizes. When pumping abrasive liquids such as industrial slurries, selecting a pump that will not clog or fail prematurely depends on particle size, hardness, and the volumetric percentage of solids.
- ■ Specific gravity. The fluid specific gravity is the ratio of the fluid density to that of water under specified conditions. Specific gravity affects the energy required to lift and move the fluid, and must be considered when determining pump power requirements.
- ■ Vapor pressure. A fluid's vapor pressure is the force per unit area that a fluid exerts in an effort to change phase from a liquid to a vapor, and depends on the fluid's chemical and physical properties. Proper consideration of the fluid's vapor pressure will help to minimize the risk of cavitation.
- ■ Viscosity. The viscosity of a fluid is a measure of its resistance to motion. Since kinematic viscosity normally varies directly with temperature, the pumping system designer must know the viscosity of the fluid at the lowest anticipated pumping temperature. High viscosity fluids result in reduced centrifugal pump performance and increased power requirements. It is particularly important to consider pump suction-side line losses when pumping viscous fluids.

##  End Use Requirements-System Flow Rate and Head

The design pump capacity, or desired pump discharge in gallons per minute (gpm) is needed to accurately size the piping system, determine friction head losses, construct a system curve, and select a pump and drive motor. Process requirements may be met by providing a constant flow rate (with on/off control and storage used to satisfy variable flow rate requirements), or by using a throttling valve or variable speed drive to supply continuously variable flow rates.

## Background

Pumping applications include constant or variable flow rate requirements, serving single or networked loads, and consisting of open loops (nonreturn or liquid delivery) or closed loops (return systems).

## Reference

Centrifugal/Vertical NPSH Margin (ANSI/HI 9.6.1-1998) , www.pumps. org, Hydraulic Institute, 1998.

The total system head has three components: static head, elevation (potential energy), and velocity (or dynamic) head. Static head is the pressure of the fluid in the system, and is the quantity measured by conventional pressure gauges. The height of the fluid level can have a substantial impact on system head. The dynamic head is the pressure required by the system to overcome head losses caused by flow rate resistance in pipes, valves, fittings, and mechanical equipment. Dynamic head losses are approximately proportional to the square of the fluid flow velocity, or flow rate. If the flow rate doubles, dynamic losses increase fourfold.

For many pumping systems, total system head requirements vary. For example, in wet well or reservoir applications, suction and static lift requirements may vary as the water surface elevations fluctuate. For return systems such as HVAC circulating water pumps, the values for the static and elevation heads equal zero. You also need to be aware of a pump's net positive suction head requirements. Centrifugal pumps require a certain amount of fluid pressure at the inlet to avoid cavitation. A rule of thumb is to ensure that the suction head available exceeds that required by the pump by at least 25% over the range of expected flow rates.

##  Environmental Considerations

Important environmental considerations include ambient temperature and humidity, elevation above sea level, and whether the pump is to be installed indoors or outdoors.

##  Software Tools

Most pump manufacturers have developed software or Web-based tools to assist in the pump selection process. Pump purchasers enter their fluid properties and system requirements to obtain a listing of suitable pumps. Software tools that allow you to evaluate and compare operating costs are available from private vendors.

<!-- image -->

##  Suggested Actions



- •	Accurately	identify	process	flow	rate	and	pressure	requirements.
- •	Measure	actual	head	and	flow	rate.
- •	Develop	a	system	curve.
- •	Select	a	pump	with	high	efficiency	over	the	expected	range	of	operating	conditions.
- •	Specify	electric	motors	that	meet	the	NEMA	Premium™	full-load	efficiency	standards.
- •	Use	life	cycle	costing	techniques	to	justify	acquiring	high	efficiency	pumps	and	designing	efficient	systems.

## Select an Energy-Efficient Centrifugal Pump

Centrifugal pumps handle high flow rates, provide smooth, nonpulsating delivery, and regulate the flow rate over a wide range without damaging the pump. Centrifugal pumps have few moving parts, and the wear caused by normal operation is minimal. They are also compact and easily disassembled for maintenance.

##  Centrifugal Pump Performance

Centrifugal pumps are generally divided into three classes: radial flow, mixed flow, and axial flow. Since they are designed around their impellers, differences in impeller design allow manufacturers to produce pumps that can perform efficiently under conditions that vary from low flow rate with high head to high flow rate with low head. The amount of fluid a centrifugal pump moves depends on the differential pressure or head it supplies. The flow rate increases as the head decreases. Manufacturers generally provide a chart that indicates the zone or range of heads and flow rates that a particular pump model can provide.

Before you select a pump model, examine its performance curve, which is indicated by its head-flow rate or operating curve. The curve shows the pump's capacity (in gallons per minute [gpm]) plotted against total developed head (in feet). It also shows efficiency (percentage), required power input (in brake-horsepower [bhp]), and suction head requirements (net positive suction head requirement in feet) over a range of flow rates.

Pump curves also indicate pump size and type, operating speed (in revolutions per minute), and impeller size (in inches). It also shows the pump's best efficiency point (BEP). The pump operates most cost effectively when the operating point is close to the BEP.

Pumps can generally be ordered with a variety of impeller sizes. Each impeller has a separate performance curve (see Figure 1). To minimize pumping system energy consumption, select a pump so the system curve intersects the pump curve within 20% of its BEP, and select a midrange impeller that can be trimmed or replaced to meet higher or

<!-- image -->

lower flow rate requirements. Select a pump with high efficiency contours over your range of expected operating points. A few points of efficiency improvement can save significant energy over the life of the pump.

## Background

The design of an efficient pumping system depends on relationships between fluid flow rate, piping layout, control methodology, and pump selection. Before selecting a centrifugal pump, we must understand its application.

## Reference

Centrifugal Applications (ANSI/HI 1.3-2000) , Hydraulic Institute, 2000.

##  Example

A process requires 15,000 gpm at a total operating head of 150 feet. Assume the centrifugal pump will be powered by a 700-hp motor, operate for 8,000 hours annually, and transport fluid with a specific gravity of 1.0. One candidate pump has an efficiency ( η 1 ) of 81% at the operating point; a second is expected to operate at 78% efficiency ( η 2 ). What are the energy savings given selection of the first pump?

Reduced Power Requirements (bhp) = {(Head   Flow x x SG) / 3,960} x (100/ η 1  - 100/ η 2 ) where

Head  =  head at operating point in feet

Flow  =  pump discharge at operating point

SG  =  fluid specific gravity bhp Reduction = {(150 feet x 15,000 gpm   1.0) / 3,960} x x (1/0.81 - 1/0.78) = 27 bhp

Assuming an efficiency of 96% for the pump drive motor, the annual energy savings are:

Energy Savings = 27 bhp x 0.746 kW/bhp   8,000 hours/year / 0.96 = 167,850 kWh/year x

These savings are valued at $8,393 per year at an energy price of 5¢ per kWh. Assuming a 15-year pump life, total energy savings are $125,888. With an assumed cost differential between the two pumps of $5,000, the simple payback for purchasing the first pump will be approximately 7 months.

<!-- image -->

##  Suggested Actions 

<!-- image -->

- •	 Develop	an	accurate	system	curve	(see	tip	sheet	'Pump	Selection	Considerations').
- •	 Select	a	correctly	sized	pump	and	drive	motor.
- •	 Select	the	pump	with	the	highest	efficiency	over	the	range	of	expected	system	operating	points.
- ·	 Develop	an	index.	A	useful	index	for	comparing	pumps	in	the	same	application	involves	calculating	the	gallons	of	fluid	pumped per	kilowatt-hour	of	electrical	energy	used	(gal/kWh).	This	index	illustrates	the	fluid	transported	per	unit	of	energy	expended. Calculating	the	inverse-kWh/gal-is	equally	useful,	and	provides	the	basis	for	an	energy	cost	comparison.

## Test for Pumping System Efficiency

Pump efficiencies of 50% to 60% or lower are quite common. Because pump inefficiencies are not readily apparent, however, opportunities to save energy by repairing or replacing components and optimizing systems are often overlooked.

##  Define Pumping System Efficiency

System efficiency incorporates the efficiencies of the pump, motor, and other system components, as shown in the area of the illustration outlined by the dashed line.

Pumping system efficiency ( η sys ) is defined as follows:

$$Q req x H req x SG η sys   =   ------- 5308 x P e$$

where

Qreq =

required fluid flow rate, in gallons per minute

Hreq   =

required pump head, in feet

SG  = specific gravity

Pe   = electrical power input.

<!-- image -->

Only the required head and flow rates are considered in calculating system efficiency. Unnecessary head losses are deducted from the pump head, and unnecessary bypass or recirculation flow is deducted from the pump flow rate.

##  Conduct Efficiency Tests

Efficiency tests help facilities staff identify inefficient systems, determine energy efficiency improvement measures, and estimate potential energy savings. These tests are usually conducted on larger pumps and on those that operate for long periods of time. For details, see Hydraulic Institute standards ANSI/HI 1.6-2000, Centrifugal Pump Tests, and ANSI/HI 2.6-2000, Vertical Pump Tests.

Flow rates can be obtained with reliable instruments installed in the system or preferably with stand-alone tools such as a sonic (Doppler-type) or 'transit time' flow meter or a Pitot tube and manometer. Turbulence can be avoided by measuring the flow rate on a pipe section without fittings at a point where there is still a straight run of pipe ahead .

##  Improve System Efficiency

Internal leaks caused by excessive impeller clearances or by worn or misadjusted parts can reduce the efficiency of pumps. Corrective actions include restoring internal clearances and replacing or refurbishing worn or damaged throat bushings, wear rings, impellers, or pump bowls. Changes in process requirements and control strategies, deteriorating piping, and valve losses all affect pumping system efficiency.

## Background

A pump's efficiency can degrade as much as 10% to 25% before it is replaced, according to a study of industrial facilities commissioned by the U.S. Department of Energy (DOE).

## References

Centrifugal Tests (ANSI/HI 1.6-2000) , Hydraulic Institute, 2000.

Conduct an In-Plant Pumping System Survey , DOE Pumping Systems Tip Sheet, 2005.

Match Pumps to System Requirements , DOE Pumping Systems Tip Sheet, 2005.

Trim or Replace Impellers on Oversized Pumps , DOE Pumping Systems Tip Sheet, 2005.

Potential energy savings can be determined by using the difference between actual system operating efficiency ( η a ) and the design (or optimal) operating efficiency ( η o ), or by consulting published pump curves, as available, for design efficiency ratings.

Software tools like DOE's Pumping System Assessment Tool (PSAT) also provide estimates of optimal efficiency. When the required head and flow rate, as well as actual electrical data, are input into the software, PSAT will account for artificial head and flow losses. The equation for calculating potential energy savings is as follows:

<!-- formula-not-decoded -->

```
where savings  =  energy savings, in kilowatt-hours (kWh) per year kWin  =  input electrical energy, in kilowatts (kW) t  =  annual operating hours η a =  actual system efficiency, calculated from field measurements η o =  optimal system efficiency.
```

##  Example

Efficiency testing and analysis indicate that a 300-horsepower centrifugal pump has an operating efficiency of 55%. However, the manufacturer's pump curve indicates that it should operate at 78% efficiency. The pump draws 235 kW and operates 6,000 hours per year. Assuming that the pump can be restored to its original or design performance conditions, estimated energy savings are as follows:

Savings = 235 kW   6,000 hours/year x x [ 1 - (0.55/0.78) ] = 415,769 kWh/year.

At an energy cost of 5¢ per kWh, the estimated savings would be $20,786 per year.

<!-- image -->

##  Suggested Actions



Survey	the	priority	pumps	in	your	plant	and	conduct	efficiency	tests	on	them.

- •	Identify	misapplied,	oversized,	or	throttled	pumps,	or	those	that	have	bypass	lines.
- ·	Identify	pumps	with	operating	points	below	the	manufacturer's	pump	curve	(if	available);	estimate	energy	savings	of	restoring the	system	to	its	original	efficiency.
- •	Identify	pumps	with	flow	rates	of	30%	or	more	from	the	BEP	flow	rates,	or	with	system	imbalances	greater	than	20%.
- •	Determine	the	cost	effectiveness	of	each	improvement.

## Maintain Pumping Systems Effectively

Effective pump maintenance allows industrial plants to keep pumps operating well, to detect problems in time to schedule repairs, and to avoid early pump failures. Regular maintenance also reveals deteriorations in efficiency and capacity, which can occur long before a pump fails.

The amount of attention given to maintenance depends on how important a system is to a plant's operations. Downtime can be expensive when it affects critical processes. Most maintenance activities can be classified as either preventive or predictive. Preventive maintenance addresses routine system needs such as lubrication, periodic adjustments, and removal of contaminants. Predictive maintenance focuses on tests and inspections that detect deteriorating conditions.

##  Preventive Actions

Preventive maintenance activities include coupling alignment, lubrication, and seal maintenance and replacement. Mechanical seals must be inspected periodically to ensure that either there is no leakage or that leakage is within specifications. Mechanical seals that leak excessively usually must be replaced. A certain amount of leakage is required, however, to lubricate and cool the packing seals. But the packing gland needs to be adjusted if the leakage exceeds the manufacturer's specifications. The packing gland must be replaced if it has to be tightened excessively to control leakage. Overtightening causes unnecessary wear on the shaft or its wear sleeve and increases electric power use. Routine maintenance of pump motors, such as proper lubrication and cleaning, is also vital.

##  Predictive Actions

Predictive maintenance helps minimize unplanned equipment outages. Sometimes called 'condition assessment' or 'condition monitoring,' it has become easier with modern testing methods and equipment. The following methods apply to pumping systems:

Vibration analysis. Trending vibration amplitude and frequency can detect an impending bearing failure. It can also reveal voltage and mechanical imbalances that could be caused by impeller erosion or coupling problems. Changes in vibration over time are more meaningful than a single 'snapshot' of the vibration spectrum.

Motor current signature analysis. Sometimes called 'dynamic analysis,' this reveals deteriorating insulation, rotor bar damage, electrical system unbalance, and harmonics. It can also pick up system problems such as malfunctioning control valves that cause flow rate disturbances. Tracking the signature over time is more valuable than a single snapshot.

Lubrication oil analysis. This applies only to large, oil-lubricated pumps, and is an expensive procedure. Oil analysis can detect bearing problems caused by metal particles or chemical changes that result from overheating, and seal problems caused by pumped fluid in the oil. It also provides guidance on proper oil-change intervals.

## Background

Wear ring and rotor erosions are some of the costly problems that can reduce the wire-to-water efficiency of pumps by 10% or more.

## References

Extend Your Motor's Operating Life,

DOE Motor Systems Tip Sheet, 2005. Test for Pumping System Efficiency, DOE Pumping Systems Tip Sheet, 2005.

Periodic efficiency testing. Testing the wire-to-water efficiency and keeping records to spot trends is useful. Finally, see the checklist of maintenance items below, which can be tailored for many kinds of systems, applications, and facilities.

##  Basic Maintenance Checklist

- ■ Packing. Check for leakage and adjust according to the instructions of the pump and packing manufacturers. Allowable leakage is usually 2 to 60 drops per minute. Add packing rings or, if necessary, replace all the packing.
- ■ Mechanical Seals. Check for leakage. If leakage exceeds the manufacturer's specifications, replace the seal.
- ■ Bearings . Determine the condition of the bearing by listening for noises that indicate excessive wear, measuring the bearing's operating temperature, and using a predictive maintenance technique such as vibration analysis or oil analysis. Lubricate bearings according to the pump manufacturer's instructions; replace them if necessary.
- ■ Motor/Pump Alignment. Determine if motor/pump alignment is within the service limits of the pump.
- ■ Motor Condition . Check the integrity of motor winding insulation. These tests usually measure insulation resistance at a certain voltage or the rate at which an applied voltage decays across the insulation. A vibration analysis can also indicate certain conditions within motor windings and lead to early detection of developing problems.

##  Suggested Actions 

Establish	a	pumping	system	maintenance	program	that	includes	the	following:

- •	Preventive	actions
- •	Predictive	actions
- •	Periodic	efficiency	testing.

## Match Pumps to System Requirements

An industrial facility can reduce the energy costs associated with its pumping systems, and save both energy and money, in many ways. They include reducing the pumping system flow rate, lowering the operating pressure, operating the system for a shorter period of time each day, and, perhaps most important, improving the system's overall efficiency.

Often, a pumping system runs inefficiently because its requirements differ from the original design conditions. The original design might have been too conservative, or oversized pumps might have been installed to accommodate future increases in plant capacity. The result is an imbalance that causes the system to be inefficient and thus more expensive to operate.

##  Correct Imbalanced Pumping Systems

If the imbalance between the system's requirements and the actual (measured) discharge head and flow rate exceeds 20%, conduct a detailed review of your plant's pumping system. Calculate the imbalance as follows:

Imbalance (%) = [(Q meas x H meas )/(Q req x H req ) - 1] x 100%

where

Qmeas =  measured flow rate, in gallons per minute (gpm)

Hmeas   =  measured discharge head, in feet

Qreq =  required flow rate, in gpm

Hreq   =  required discharge head, in feet.

A pump may be incorrectly sized for current needs if it operates under throttled conditions, has a high bypass flow rate, or has a flow rate that varies more than 30% from its best efficiency point (BEP) flow rate. Such pumps can be prioritized for further analysis, according to the degree of imbalance or mismatch between actual and required conditions.

Energy-efficient solutions include using multiple pumps, adding smaller auxiliary (pony) pumps, trimming impellers, or adding a variable-speed drive. In some cases, it may be practical to replace an electric motor with a slower, synchronous-speed motor-e.g., using a motor that runs at 1,200 revolutions per minute (rpm) rather than one that runs at 1,800 rpm.

Conduct quick reviews like this periodically. Especially for multipump systems, this can be a convenient way to identify opportunities to optimize a system at little or no cost.

##  Example

This example shows the energy savings that can be obtained by not using an oversized pump. Assume that a process requires 1,500 tons of refrigeration during the three summer months, but only 425 tons for the remaining nine months. The process uses two chilled water pumps operating at 3,500 gpm and requiring 200 brake horsepower (bhp) each. Both are used in summer, but two-thirds of the flow rate is bypassed during the remaining months.

## Background

When pumps run inefficiently, it is often because actual system requirements are not the same as those specified in the original system design. This can make the whole system more costly to operate.

## References

Variable Speed Pumping: A Guide to Successful Applications , Hydraulic Institute and Europump (www.pumps. org), 2004.

Conduct an In-Plant Pumping System Survey , DOE Pumping Systems Tip Sheet, 2005.

Trim or Replace Impellers on Oversized Pumps , DOE Pumping Systems Tip Sheet, 2005.

Optimize Parallel Pumping Systems, DOE Pumping Systems Tip Sheet, 2005.

Adjustable Speed Pumping Applications , DOE Pumping Systems Tip Sheet, 2005.

One 3,500-gpm pump is therefore replaced with a new 1,250-gpm pump designed to have the same discharge head as the original unit. Although the new pump requires only 50 bhp, it meets the plant's chilled water requirements most of the year (in all but the summer months). The older pump now operates only in the summer. Assuming continuous operation with an efficiency ( η m ) of 93% for both motors, we can calculate the energy savings from operating the smaller pump as follows:

Savings  =  (200 hp - 50 hp)/ η m x 0.746 kW/hp   (9 months/12 months)   8,760 hours/year x x =  790,520 kWh/year.

At an average energy cost of 5¢ per kWh, annual savings would be about $39,525.

<!-- image -->



## Suggested Actions



<!-- image -->

- •	Survey	your	facility's	pumps.
- •	Identify	flow	rates	that	vary	30%	or	more	from	the	BEP	and	systems	imbalances	greater	than	20%.
- •	Identify	misapplied,	oversized,	or	throttled	pumps	and	those	with	bypass	lines.
- •	Assess	opportunities	to	improve	system	efficiency.
- •	Consult	with	suppliers	on	the	cost	of	trimming	or	replacing	impellers	and	replacing	pumps.
- •	Determine	the	cost-effectiveness	of	each	improvement.

## Reduce Pumping Costs through Optimum Pipe Sizing

The power consumed to overcome the static head in a pumping system varies linearly with flow, and very little can be done to reduce the static component of the system requirement. However, there are several energy- and money-saving opportunities to reduce the power required to overcome the friction component.

The frictional power required depends on flow rate, pipe size (diameter), overall pipe length, pipe characteristics (surface roughness, material, etc.), and properties of the fluid being pumped. Figure 1 shows the annual water pumping cost (frictional power only) for 1,000 feet of pipe length for different pipe sizes and flow rates.

## Figure 1. Annual water pumping cost for 1,000 feet of pipe of different sizes

Based	on	1,000	ft	for	clean	iron	and	steel	pipes	(schedule	40)	for	pumping	70°F	water.	Electricity	rate-5¢	per	kWh	and 8,760	operating	hours	annually.	Combined	pump	and	motor	efficiency-70%.

<!-- image -->

##  Example

A pumping facility has 10,000 feet of piping to carry 600 gallons per minute (gpm) of water continuously to storage tanks. Determine the annual pumping costs associated with different pipe sizes.

From Figure 1, for 600 gpm:

6-inch pipe:   ($1,690/1,000 feet) x 10,000 feet  = $16,900

8-inch pipe:

($425/1,000 feet) x 10,000 feet  = $  4,250

10-inch pipe: ($140/1,000 feet) x 10,000 feet  = $  1,400

After the energy costs are calculated, the installation and maintenance costs should be calculated for each pipe size. Although the up-front cost of a larger pipe may be higher, it may still provide the most cost-effective solution because it will greatly reduce the initial pump and operating costs.

## Background

Every industrial facility has a piping network that carries water or other fluids. According to the U.S. Department of Energy (DOE), 16% of a typical facility's electricity costs are for its pumping systems.

## References

Xenergy Inc., United States Industrial Motor Systems Market Opportunities Assessment, prepared for DOE, December 1998.

Piping Handbook , Mohinder K. Nayyar, McGraw-Hill Publications, New York, 1998.

Engineering Data Book , Hydraulic Institute, Second Edition, New Jersey, 1990.

##  General Equation for Estimating Frictional Portion of Pumping Costs

<!-- formula-not-decoded -->

where the friction factor, based on the pipe roughness, pipe diameter, and the Reynolds number, can be obtained from engineering handbooks. For most applications, the value of this friction factor will be 0.015 to 0.0225.

##  Suggested Actions 

- •	Compute	annual	and	life-cycle	cost	for	systems	before	making	an	engineering	design	decision.
- ·	In	systems	dominated	by	friction	head,	evaluate	pumping	costs	for	at	least	two	pipe	sizes	and	try	to	accommodate	pipe	size	with the	lowest	life-cycle	cost.
- ·	Look	for	ways	to	reduce	friction	factor.	If	your	application	permits,	epoxy-coated	steel	or	plastic	pipes	can	reduce	friction	factor by	more	than	40%,	proportionately	reducing	your	pumping	costs.

## Appendix D: Guidelines for Comments

Comments that can correct and improve this sourcebook are appreciated. Please copy this page and provide suggestions to the address listed below.

Improving Pumping System Performance, A Sourcebook for Industry: Comment Form

Page number(s):

Comments:

From:

Mail to:

U.S. Department of Energy Industrial Technologies Program, EE-2F 1000 Independence Ave, SW Washington, DC 20585

## About the Office of Energy Efficiency and Renewable Energy

## A Strong Energy Portfolio for a Strong America

Energy	efficiency	and	clean,	renewable energy	will	mean	a	stronger	economy,	a cleaner	environment,	and	greater	energy independence	for	America.	Working with	a	wide	array	of	state,	community, industry,	and	university	partners,	the	U.S. Department	of	Energy's	Office	of	Energy Efficiency	and	Renewable	Energy	invests	in a	diverse	portfolio	of	energy	technologies.

U.S. Department of Energy Energy Efficiency and Renewable Energy Industrial Technologies Program Washington, DC www.eere.energy.gov/industry

For	more	information	or	to	order additional	copies	contact EERE	Information	Center 1-877-EERE-INF	(1-877-337-3463) eereic@ee.doe.gov

<!-- image -->

<!-- image -->