---
document_id: doe_steam_tip_26b
title: "Steam Tip Sheet #26B: Selecting a Condensing Economizer"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2007
original_file: "doe_steam_tip26b_selecting_condensing_economizer.pdf"
tables_detected: 3
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

A

E

nergy Tips: STEAM

## Considerations When Selecting a Condensing Economizer

Boilers equipped with condensing economizers can have an overall efficiency that exceeds 90%. A condensing economizer can increase overall heat recovery and steam system efficiency by up to 10% by reducing the flue gas temperature below its dew point, resulting in improved effectiveness of waste heat recovery.

This tip sheet is a companion to Steam Tip Sheet 26A, Consider Installing a Condensing Economizer , and discusses two types of condensing economizer: indirect and direct contact.

An indirect contact condensing economizer (see Figure 1) removes heat from hot flue gases by passing them through one or more shell-and-tube or tubular heat exchangers. This economizer can heat fluids to a temperature of 200°F while achieving exit gas temperatures as low as 75°F. The indirect contact economizer is able to preheat water to a higher outlet or process supply temperature than the direct contact economizer. The condensing economizer must be designed to withstand corrosion from condensed water vapor produced by the combustion of hydrocarbon fuels such as natural gas or light oils. The condensed water vapor is acidic and must be neutralized if it is to be discharged into the sewer system or used as process water.

Figure 1. Indirect contact condensing economizer

<!-- image -->

Steam Tip Sheet #26B

## Suggested Actions

- ■ ■ Determine your boiler capacity, combustion efficiency, stack gas temperature, annual hours of operation, and annual fuel consumption.
- ■ ■ Identify in-plant uses for low-temperature heated water (plant space heating, boiler makeup water heating, preheating, or process requirements).
- ■ ■ Verify the thermal requirements that can be met through installing a condensing economizer, and potential annual fuel energy and cost savings.
- ■ ■ Determine the costeffectiveness of a condensing economizer, ensuring that system changes are evaluated and modifications are included in the design (e.g., mist eliminator, heat exchangers). Simple paybacks for condensing economizer projects are often less than 2 years.

A

N

C

V

A

D

Another heat recovery option is to use a direct contact condensing economizer (see Figure 2), which consists of a vapor-conditioning chamber followed by a countercurrent spray chamber. In the spray chamber, small droplets of cool liquid come into direct contact with the hot flue gas, providing a non-fouling heat transfer surface. The liquid droplets cool the stack gas, condense and disentrain the water vapor. The spray chamber may be equipped with packing to improve contact between the water spray and hot gas. A mist eliminator is required to prevent carryover of small droplets. The direct contact design offers high heat transfer coupled with water recovery capability since heated water can be collected for boiler feedwater, space heating, or plant process needs. Recovered water will be acidic and may require treatment prior to use, such as membrane technology, external heat exchangers, or pH control. Water filtration will also be required for fuel types other than natural gas.

The site must have substantial heating requirements for low-temperature process or cold makeup water if a direct contact condensing economizer

Figure 2. Direct contact condensing economizer with packed bed and external heat exchanger

<!-- image -->

is to be a viable heat recovery alternative. Because direct contact condensing economizers operate close to atmospheric pressure, altitude and flue gas temperature limit makeup water temperature to 110°F to 140°F.

When considering whether to install a condensing economizer, evaluate changes in system operating parameters. These economizers preheat boiler makeup water and reduce deaerator steam requirements, thereby providing more steam for plant processes. The energy savings potential is decreased if the majority of the deaerator steam

A

is supplied from blowdown heat recovery. The condensing economizer could also limit or decrease backpressure steam turbine energy production if the turbine discharge is used to balance a low-pressure header. The reduction in stack gas exit temperature reduces plume buoyancy and must be considered when modeling pollutant dispersion. Performance characteristics of both indirect and direct contact economizers are summarized in the table below.

Comparison of Condensing Heat Recovery Economizers

| Performance Characteristic                               | Direct Contact                           | Indirect Contact             |
|----------------------------------------------------------|------------------------------------------|------------------------------|
| Maximum Outlet Water Temperature                         | 140°F                                    | 200°F                        |
| Minimum Flue Gas Temperature                             | 75°F                                     | 75°F                         |
| Percent Removal of Humidity from Flue Gas (Approximate)  | 85%                                      | 35%                          |
| Need for Heat Exchanger                                  | Depends on Application                   | No                           |
| Recovery of Water in Flue Gas                            | Yes (when no heat exchanger is used) 1,2 | Possible (site specific) 1,2 |
| Footprint per MMBtu/hr of Heat Recovery                  | Site specific                            | Site specific                |
| Permissible Fuels Burned in Boiler Natural Gas Light Oil | Yes 1 Yes 2                              | Yes Yes 2                    |

- 1. Water treatment required if water of condensation is reused. Special corrosion-resistant materials or coatings may be required on heat exchange surfaces.
- 2. Water treatment required if water of condensation is reused. More acidic due to SOx in solution. Special corrosion-resistant materials or coatings are required on heat exchange surfaces.

Condensing economizers require site-specific engineering and design, and a thorough understanding of the effect their operation will have on the existing steam system and water chemistry.

For additional information on economizers, refer to the Steam refer to Steam Tip Sheet #3 Use Feedwater Economizers for Waste Heat Recovery . For additional information on industrial steam system efficiency, refer to Improving Steam System Performance: A Sourcebook for Industry .

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3397  •  January 2012

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.