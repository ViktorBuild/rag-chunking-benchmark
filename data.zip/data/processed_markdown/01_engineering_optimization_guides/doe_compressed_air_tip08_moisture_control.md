---
document_id: doe_ca_tip_8
title: "Compressed Air Tip Sheet #8: Prevent Water Intrusion in Compressed Air Lines"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip08_moisture_control.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #8 • August 2004

## Suggested Actions

- ·  Review compressed air applications and determine the required level of air pressure.
- ·  Review your compressed air system's demand patterns to determine which method for stabilizing pressure is most appropriate.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies Program and CAC:

Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Stabilizing System Pressure

Stabilizing system pressure is an important way to lower energy costs and maintain reliable production and product quality. The need to stabilize system pressure should be guided by the compressed air demand patterns and the minimum acceptable pressure level required for reliable production. High-volume intermittent air demand events can cause air pressure to fluctuate, which is often misinterpreted as insufficient pressure. In some cases, improperly set compressor controls will cause another compressor to start, but because of the time required for the new compressor to ramp up, there will be a shortfall of air supply to the system. Such a delay can cause the system pressure to decay, resulting in lost production. Three methods can be used to stabilize system pressure: adequate primary and secondary storage, Pressure/Flow Controllers (P/FCs), and dedicated compressors.

## Primary and Secondary Storage

One or more compressed air applications having large, intermittent air demands can cause severe, dynamic pressure fluctuations in the whole system, with some essential points of use experiencing inadequate pressure. Such demand is often of short duration; properly sized primary and secondary storage can supply the needs of the intermittent demand. The time interval between the demand events is adequate to restore the storage receiver pressure without adding compressor capacity. Primary storage receivers can:

- •  Prevent frequent loading and unloading of compressors
- ·  Collect condensate, which may be carried over from the aftercooler and moisture separator
- ·  Provide some radiant cooling to reduce moisture content and air dryer load if located in a cool location and installed upstream of the dryer
- •  Provide dampening of pressure pulsations from reciprocating compressors.

Secondary storage receivers can be used to:

- ·  Supplement the primary receivers to stabilize system pressure and thus keep unneeded compressors from starting
- ·  Supply adequate compressed air for a single intermittent event of a known duration.

The secondary receiver should be located as close to the end use as is practicable and its pressure rating must be at least equal to that of the primary receiver(s).

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

Pressure fluctuations may also occur due to inadequate storage or because the system pressure is at or near the lowest level of the compressor pressure control band. If a large, intermittent demand event occurs when the pressure is at or near the lowest level in the control band, the pressure in the distribution piping falls even further, affecting critical end-use applications. In such a case, the installation of a relatively small receiver with a check valve upstream of the application causing the demand event may address the problem.

<!-- image -->

## Pressure/Flow Controllers

A Pressure/Flow Controller (P/FC) is a device that serves to separate the supply side of a compressed air system from that system's demand side. P/FCs use the principle of operating compressors to fi  ll and store air in receivers at higher pressures. P/FCs then reduce the pressure and supply it to the system at the pressure required by that system's compressed air applications. P/FCs work with pilot-operated regulators or electronic controls to sense and monitor the system's pressure downstream of the valves. Controlled pressure and adequate upstream storage are critical to satisfactory performance. P/FCs normally respond rapidly to demand fl  uctuations and maintain system pressure within a narrow band.  For peak demand events, suffi  cient storage is necessary to release the stored air quickly into the system to maintain required downstream pressures within an acceptable tolerance. With proper design and system controls, storage can be used to meet air demand and reduce compressor run time.

## Dedicated Compressors

Applications some distance from the main compressor supply or those with pressure requirements that differ from the main system requirements may be served by a dedicated compressor. Small or unit type compressors (generally up to 10 hp maximum) can be very suitable for an application whose pressure level is higher than that of the plant's other applications. Generally, such compressors can be located close to a point of use, avoiding lengthy piping runs and pressure drops; are adaptable to a wide range of conditions such as temperature, altitude, and humidity; and do not require separate cooling systems.

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.

DOE/GO-102004-1976 August 2004 Compressed Air Tip Sheet #8