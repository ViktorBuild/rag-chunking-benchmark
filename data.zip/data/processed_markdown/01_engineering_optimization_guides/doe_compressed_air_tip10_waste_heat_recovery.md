---
document_id: doe_ca_tip_10
title: "Compressed Air Tip Sheet #10: Recover Waste Heat from Compressed Air Systems"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip10_waste_heat_recovery.pdf"
tables_detected: 2
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

## Compressed Air Tip Sheet #10 • August 2004

## Suggested Actions

- ·  Review compressed air end uses and determine the required level of air pressure.
- ·  Review the compressed air end uses' original configurations to determine whether manufacturing processes have evolved in such a way that those end uses are no longer necessary or can be reconfigured more efficiently.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider From DOE's Industrial Technologies Program and CAC: Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Engineer End Uses for Maximum Efficiency

Compressed air is one of the most important utility requirements of many industrial manufacturing plants because it directly serves processes and applications such as pneumatic tools, pneumatic controls, compressed air operated cylinders for machine actuation, product cleansing and blow-off applications. Ensuring an appropriate, stable pressure level at the end-use applications is critical to the performance of any industrial compressed air system. End uses that are engineered for maximum efficiency can help provide the consistent supply of compressed air that ensures reliable production.

To ensure the efficiency of compressed air end-use applications, a number of steps should be taken:

|   Step | Action                                                                                                                                                                                                                                                                                                                                                                                                                                         |
|--------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|      1 | Review the pressure level requirements of the end-use applications. Those pressure level requirements should determine the system pressure level. Because there is often a substantial difference in air consumption and pressure levels required by similar tools available from different manufacturers, request exact figures from each manufacturer for the specific application. Do not confuse maximum allowable with required pressure. |
|      2 | Monitor the air pressure at the inlet to the tool. Improperly-sized hoses, fittings and quick disconnects often result in large pressure drops. These drops require higher system pressures to compensate, thus wasting energy. Reduced inlet pressure at the tool reduces the output from the tool and, in some cases, may require a larger tool for the specified speed and torque.                                                          |
|      3 | Avoid the operation of any air tool at 'free speed' with no load. Operating a tool this way will consume more air than a tool that has the load applied.                                                                                                                                                                                                                                                                                       |
|      4 | Check the useful life of each end-use application. A worn tool will often require higher pressure, consume excess compressed air, and can affect other operations in the immediate area.                                                                                                                                                                                                                                                       |
|      5 | Air tools should be lubricated as specified by the manufacturer, and the air going to all end uses should be free of condensate to maximize tool life and effectiveness.                                                                                                                                                                                                                                                                       |
|      6 | End uses having similar air requirements of pressure and air quality may be grouped in reason- ably close proximity, allowing a minimum of distribution piping, air treatment, and controls.                                                                                                                                                                                                                                                   |
|      7 | Investigate and, if possible, reduce the highest point-of-use pressure requirements. Then, adjust the system pressure.                                                                                                                                                                                                                                                                                                                         |
|      8 | Investigate and replace inefficient end uses such as open blowing with efficient ones such as vortex nozzles.                                                                                                                                                                                                                                                                                                                                  |

## Case Study: A New Compressed Air Application is Configured for Maximum Efficiency

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

A large, custom printing company installed a more technologically-advanced printing machine that could increase the output of its existing units. However, the initial configuration of the new printing machine more than doubled the compressed air demand of the entire site. After a thorough review, the plant personnel realized that it would be more cost-effective for the new machines to be redesigned to consume less air at lower pressures than to increase compressor capacity at all of the

<!-- image -->

company's printing plants. Once the printing machines were reconfi  gured, the total air demand per printing machine was reduced from 27 standard cubic feet per minute (scfm) to 4.5 scfm and the need for 100 pounds per square inch gauge (psig) compressed air was eliminated, resulting in substantial avoided costs in energy and capital expenditures.

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.

DOE/GO-102004-1931 August 2004 Compressed Air Tip Sheet #10