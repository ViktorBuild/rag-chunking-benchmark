---
document_id: doe_steam_tip_9
title: "Steam Tip Sheet #9: Minimize Boiler Blowdown"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_steam_tip09_minimize_boiler_blowdown.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## ADVANCED MANUFACTURING OFICE

Energy Tips: STEAM

## Minimize Boiler Blowdown

Minimizing your blowdown rate can substantially reduce energy losses, as the temperature of the blown-down liquid is the same as that of the steam generated in the boiler. Minimizing blowdown will also reduce makeup water and chemical treatment costs.

As water evaporates in the boiler steam drum, solids present in the feedwater are left behind. The suspended solids form sludge or sediments in the boiler, which degrades heat transfer. Dissolved solids promote foaming and carryover of boiler water into the steam. To reduce the levels of suspended and total dissolved solids (TDS) to acceptable limits, water is periodically discharged or blown down from the boiler. Mud or bottom blowdown is usually a manual procedure done for a few seconds on intervals of several hours. It is designed to remove suspended solids that settle out of the boiler water and form a heavy sludge. Surface or skimming blowdown is designed to remove the dissolved solids that concentrate near the liquid surface. Surface blowdown is often a continuous process.

Insufficient blowdown may lead to carryover of boiler water into the steam, or the formation of deposits. Excessive blowdown will waste energy, water, and chemicals. The optimum blowdown rate is determined by various factors including the boiler type, operating pressure, water treatment, and quality of makeup water. Blowdown rates typically range from 4% to 8% of boiler feedwater flow rate, but can be as high as 10% when makeup water has a high solids content.

## Example

Assume that the installation of an automatic blowdown control system (see page 2) reduces your blowdown rate from 8% to 6%. This example assumes a continuously operating natural gas-fired, 150-psig, 100,000-pound-per-hour (lb/hr) steam boiler. Assume a makeup water temperature of 60°F, boiler efficiency of 80%, with fuel valued at $8.00 per million Btu ($8.00/MMBtu), and the total water, sewage, and treatment costs at $0.004 per gallon. Calculate the total annual cost savings.

Boiler Feedwater:

Initial =

100,000

(1 - 0.08)

Final =

100,000

(1 - 0.06)

=

108,696 lb/hr

=

106,383 lb/hr

Makeup Water Savings =

108,696 - 106,383 = 2,313 lb/hr

Enthalpy of Boiler Water =

338.5 Btu/lb; for makeup water at 60°F= 28 Btu/lb

Thermal Energy Savings =

338.5 - 28 = 310.5 Btu/lb

Annual Fuel Savings =

2,313 lb/hr x 8,760 hr/year x 310.5 Btu/lb x $8.00/ MMBtu /(0.80 x 10 6  Btu/MMBtu)

=

$62,913

Annual Water and Chemical Savings =

2,313 lb/hr x 8,760 hr/yr x $0.004/gal

8.34 lb/gal

=

$9,718

Annual Cost Savings =

$62,913 + $9,718

=

$72,631

t

S

eam Tip Sheet #9

## Suggested Actions

- ■ ■ Review your blowdown practices to identify energysaving opportunities.
- ■ ■ Examine operating practices for boiler feedwater and blowdown rates developed by the American Society of Mechanical Engineers (ASME). Considerations include operating pressure, steam purity, and deposition control.
- ■ ■ Consider an automatic blowdown control system (see page 2).

## Automatic Blowdown Control Systems

These systems optimize surface blowdown by regulating water volume discharged in relation to amount of dissolved solids present. Conductivity, TDS, silica or chlorides concentrations, and/or alkalinity are reliable indicators of salts and other contaminants dissolved in boiler water. A probe provides feedback to a controller driving a modulating blowdown valve. An alternative is proportional control - with the blowdown rate set proportional to the makeup water flow.

## Cycles of Concentration

'Cycles of concentration' refers to the accumulation of impurities in the boiler water. If the boiler water contains 10 times the level of impurities in the makeup water, it is said to have 10 cycles of concentration.

## References

- 1. 'Consensus Operating Practices for Control of Feedwater/Boiler Water Chemistry in Modern Industrial Boilers,' published by the ASME, 1994.
- 2. 'Recommended Rules for the Care and Operation of Heating Boilers,' Section VI of the ASME Boiler and Pressure Vessel Code, 1995.
- 3. 'Recommended Guidelines for the Care of Power Boilers,' Section VII of the ASME Boiler and Pressure Vessel Code, 1995.

Adapted from an Energy TIPS fact sheet that was originally published by the Industrial Energy Extension Service of Georgia Tech.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3406  •  January 2012

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.