---
document_id: ct_soil_thermal_properties_guide
title: "Soil Thermal Properties (STP) for Subsea Cable Design: Best Practice Guide"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "Carbon Trust (UK)"
year: 2024
original_file: "carbon_trust_soil_thermal_properties_guide.pdf"
tables_detected: 40
converted_with: "Docling v2.32 (TableFormer)"
---

## Soil Thermal Properties (STP) for subsea cable design

Cables technical working group

March 2024

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Document information

OWA research area:

Cables technical working group (TWG-C) Soil Thermal Properties (STP) for Subsea Cable Design Cathie, ITP Energised, and University of Southampton karolina.zieba@carbontrust.com

Project title:

Contractor:

Carbon Trust contact email:

## OWA parties

Participants in the Offshore Wind Accelerator (OWA) programme (Stage IV): EnBW Energie Baden-Württemberg AG, RWE Offshore Wind GmbH, Equinor ASA, Ørsted Wind Power A/S, ScottishPower Renewables (UK) Limited, Shell Global Solutions International B.V, SSE Renewables Services (UK) Limited, Vattenfall Wind Power Ltd, TotalEnergies OneTech, and the Carbon Trust.

## Document history

|   Version | Date       | Main modification   | Lead Author         |
|-----------|------------|---------------------|---------------------|
|         1 | 02/05/2023 | Draft               | CATHIE / UoS / ITPE |
|         2 | 16/06/2023 | For comment         | CATHIE / UoS / ITPE |
|         3 | 15/12/2023 | For approval        | CATHIE / UoS / ITPE |

## Delivery partners:

<!-- image -->

<!-- image -->

<!-- image -->

## Disclaimer

This report is issued by the Carbon Trust on behalf of the Offshore Wind Accelerator ('OWA'). While reasonable steps have been taken to ensure that the information contained within this report is accurate, the authors, the Carbon Trust, its agents and consultants and the partners and developers within the OWA (and each of them), to the fullest extent permitted by law, shall not have nor be deemed to have (1) a duty of care to readers and/or users of this report, (2) made or given or to make or give any warranty or representation (in each case whether express or implied) as to its accuracy, applicability or completeness and/or (3) or have accepted any liability whatsoever for any errors or omissions (whether negligent or otherwise) within it. It should also be noted that this report has been produced from information relating to dates and periods referred to in it. Users and readers use this report on the basis that they do so at their own risk. The intellectual property rights in this report shall be deemed, as between readers and users of this report and the Carbon Trust, to belong to the Carbon Trust.

© The Carbon Trust 2024

<!-- image -->

<!-- image -->

## Contents

| 1. Background   | 1. Background                                   | 1. Background                                                              |   1 |
|-----------------|-------------------------------------------------|----------------------------------------------------------------------------|-----|
|                 | 1.1                                             | Introduction                                                               |   1 |
|                 | 1.2                                             | Impacts of the thermal environment on cable rating and cable cost          |   2 |
|                 | 1.3                                             | Characterising the seabed thermal environment for cable design             |   5 |
| 2.              | Thermal soil property collation and measurement | Thermal soil property collation and measurement                            |   7 |
|                 | 2.1                                             | Thermal properties within the site investigation process                   |   7 |
|                 | 2.2                                             | Methods for measuring thermal conductivity                                 |   7 |
|                 | 2.3                                             | Laboratory testing techniques                                              |   8 |
|                 | 2.4                                             | Sample preparation                                                         |   9 |
|                 | 2.5                                             | In situ measurement techniques                                             |  10 |
| 3.              | Selection of soil thermal properties            | Selection of soil thermal properties                                       |  13 |
|                 | 3.1                                             | Introduction                                                               |  13 |
|                 | 3.2                                             | Thermal property geodatabases                                              |  14 |
|                 |                                                 | 3.2.1 Statistical analysis                                                 |  14 |
|                 |                                                 | 3.2.2 Repeatability-correction of TC database for each soil type           |  16 |
|                 |                                                 | 3.2.3 Weighted database according to seafloor soil variation               |  16 |
|                 |                                                 | 3.2.4 Thermal conductivity versus porosity - trend lines per soil type     |  17 |
|                 | 3.3                                             | Pre survey estimation from databases                                       |  18 |
|                 |                                                 | 3.3.1 No site specific data available (Data Scenario 0)                    |  18 |
|                 |                                                 | 3.3.2 Soil type data available (Data Scenario 1)                           |  19 |
|                 | 3.4                                             | Site specific data available excluding thermal properties                  |  19 |
|                 |                                                 | 3.4.1 In situ CPT data available (Data Scenario 2)                         |  19 |
|                 |                                                 | 3.4.2 Lab test data available (Data Scenario 3a)                           |  19 |
|                 | 3.5                                             | Site specific thermal property data available (Data Scenario 3b)           |  20 |
|                 | 3.6                                             | Modelling trench effects - allowing for soil disturbance (Data Scenario 4) |  20 |

<!-- image -->

## List of tables

13

15

21

| Table 1-1: Data scenarios for Thermal Conductivity estimation                                                   | 6                                                                              |
|-----------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------|
| Table 2-1: Comparison of laboratory test methods                                                                | 8                                                                              |
| Table 2-2: Laboratory-based versus in situ geotechnical tests                                                   | 12                                                                             |
| Table 3-1: Data scenarios for Thermal Conductivity estimation (Table 1-1 repeated)                              | 13                                                                             |
| Table 3-2: Normal distribution statistical parameters - geodatabase evaluation                                  | 16                                                                             |
| Table 3-3: Relevant phase relationships to derive porosity from standard laboratory data                        | 17                                                                             |
| Table 3-4: Typical grain thermal conductivities of marine sediments                                             | 18                                                                             |
| List of figures                                                                                                 |                                                                                |
| Figure 1-1: Steady state current vs thermal resistivity - 1200 & 1600 mm 2 cables                               | 3                                                                              |
| Figure 1-2 Schematic representation of cable CSA (vs base case scenario) - steady state                         | 3                                                                              |
| Figure 1-3: Continuous static cable rating for a generic AC cable                                               | 4                                                                              |
| Figure 1-4: Illustration of data scenarios                                                                      | 5                                                                              |
| Figure 2-1: Common methods for evaluating thermal conductivity of marine sediments                              | 7                                                                              |
| Figure 3-1: Illustration of data scenarios (Figure 1-4 repeated)                                                | 13                                                                             |
| Figure 3-2: Combined box, whisker and beeswarm scatter plot - statistical parameters                            | 15                                                                             |
| Figure 3-3: Cable temperature change due to burial-induced seabed properties changes                            | 21                                                                             |
| List of appendices                                                                                              |                                                                                |
| Appendix A.1 Laboratory techniques Appendix A.1.1 Needle probe Appendix A.1.2 Transient plane source (hot disk) |                                                                                |
| Appendix A.1.3 Guarded hot plate                                                                                |                                                                                |
| Appendix A.1.4 Thermal cell                                                                                     |                                                                                |
| Appendix A.2 In situ techniques                                                                                 |                                                                                |
| Appendix A.2.1 Passive and active thermal probes                                                                |                                                                                |
| Appendix A.2.3 Passive method - correlation with conventional CPT measurements                                  | Appendix A.2.3 Passive method - correlation with conventional CPT measurements |

- References

## 1. Background

## 1.1 Introduction

The dissipation of thermal energy from subsea HV cables is a key consideration for:

- (i) the design and manufacture of subsea cables;
- (ii) dynamic rating of the cable during the lifetime of operation;
- (iii) the interpretation of distributed temperature sensor (DTS) data for monitoring cable performance, depth of burial, transgression of the '2K criteria' of temperature rise to protect benthic life, and finally, in extreme circumstances, fault location.

This study demonstrates that a proper consideration of the thermal environment, using geotechnical best practices, could save tens of millions of pounds of capital expenditure, whilst also helping to reduce operational costs. For instance, offshore cables represent 30% of offshore wind farm insurance claims incurred and 50% of the total value of claims between 2010 and 2020 (GCube, 2021).

The environmental factors that control heat dissipation from subsea HV cables are the thermal conductivity, volumetric heat capacity and permeability of the seabed soils as well as the lifetime changes in the depth of cover over the cable. The rate and magnitude of heat dissipation, conductor temperature and ultimately the maximum power transfer possible can be determined by the IEC standards or derived from the fundamental physical laws solved analytically or using numerical methods. The factor that has the greatest influence on heat dissipation is the thermal conductivity in most submarine cable environments. Hughes et al (2015) have demonstrated that the permeability of soils can also impact the heat dissipation by enabling convective heat transfer. However, this only becomes an issue for the higher permeabilities found in unimodal medium to coarse sands and gravels and is therefore not considered in detail within these guidance notes.

With this background, the key objective of this Best Practice Guide is to:

- · Provide an understanding of the impact of thermal conductivity on cable design and identify the influence of the accuracy and precision of these measurements on the cable design and operating condition;
- · Present appropriate engineering practices to support measurement of the thermal conductivity of marine soils, highlighting the different levels of accuracy and precision that can be achieved by different methods;
- · Provide an understanding of the potential changes of these thermal properties in response to installation effects -from trenching or ploughing and cable burial -and the implications of these changes in soil properties for cable design and operation.

These guidelines are relevant at all of the phases of the OWF including design, installation and operation. The guidelines are a deliverable from the Carbon Trust project 'Soil Thermal Properties for Subsea Cable Design'. They have been developed from thre e detailed reports produced earlier in the project which covered 'Cost Implications of Thermal Conductivity Values' (WP1), a 'Testing Methodology Review' (WP2) and 'Trenching Effects on the Design Parameter Framework' (WP3). Selected sections from those reports are provided in Appendix A in this guideline and are referenced within the main text.

<!-- image -->

<!-- image -->

Thermal conductivity, in W/mK, is the key parameter measured or reported during geotechnical testing. However, its reciprocal, thermal resistivity (Km/W), is the form used in all electrical cable design and post installation monitoring software and so both will be referred to within this document. These guidance notes are also solely focused on soils in marine conditions, which results in them being fully and permanently saturated. Landfall sites, which experience spatially and temporally varying saturation states, create a significantly more complex thermal environment and therefore require a different thermal assessment approach. This guidance is not appropriate for unsaturated soils.

## 1.2 Impacts of the thermal environment on cable rating and cable cost

WP1 of this project provided a series of Case Studies designed to illustrate the implications of soil thermal properties on subsea cable design, with specific emphasis on the cable cross sectional areas (CSA's) required to achieve a set rating (i.e. maximum current) and the subsequent cost implications of these choices. Each study is compared against a base case of a generic three phase, AC, 1400mm 2 CSA, export cable buried at 1 m depth within a seabed with a fixed thermal resistivity of 0.7 Km/W (which is the standard value quoted in the international standards, IEC-60287 and 60853, and previously used extensively across the sector). The base case has a rating of 1000A. These Case Studies demonstrate the impacts of the following variables on cable design:

- · Soil type;
- · Uncertainty of thermal measurements;
- · Choice of statistical parameter (i.e. fractile within scattered data) for unitised thermal resistivities;
- · Impact of trenching on the thermal environment.

Figure 1-1 demonstrates that for two different sizes of cable (1200 and 1600mm 2  respectively) the cable rating can vary by between 300-350A (~35%) depending on both the thermal properties of the soil and which thermal resistivity value (Maximum, P90, P75 and Mean) is used to represent the environmental conditions (WP1). Such a variation is financially and operationally important and is comparable to similar ratings improvements in terrestrial environments that have been considered significant in other studies (e.g. Pilgrim et al, 2012).

<!-- image -->

Figure 1-1: Steady state current vs thermal resistivity -1200 &amp; 1600mm 2  cables

<!-- image -->

Note: Plotted are the values for mean, P75, P90 and Max TR values for each soil type

<!-- image -->

Similarly, Figure 1-2 demonstrates that a 20% uncertainty in the thermal conductivity measurement can lead to a cost differential of up to £48.5 million for a 100km cable when compared against the base case scenario (based on October 2021 materials costs -WP1). Even for a 10% uncertainty in the thermal conductivity, the maximum rating for a single cable can vary between approximately ±1.5% (high thermal conductivities more than ~2W/mK) and ~±5% (low thermal conductivities [less than ~1W/mK]). These impacts increase with increasing burial depth (Figure 1-3). It is therefore essential to adopt the most precise measurement methods possible, for both laboratory based and in situ thermal conductivity measurements and understand the uncertainty budget of all methods used.

Figure 1-2 Schematic representation of cable CSA (vs base case scenario) - steady state

Note: including ±20% uncertainty error in thermal resistivity for a range soil types

<!-- image -->

Figure 1-3: Continuous static cable rating for a generic AC cable

<!-- image -->

Notes: Rating satisfying the maximum permissible conductor temperature of 90°C, for a range of varying thermal conductivities and burial depths

<!-- image -->

These observations are based on using thermal conductivity measurements of the pre trenched, ambient soil condition, which is the condition in which soil is tested in the laboratory and in situ. However, it is important  to  consider  how  the  key  thermal  properties  may  change  during  and  after  the  installation process. There are no publicly available direct measurements of thermal conductivity of trenched soils. As an alternative, WP3 modelled the potential impact of trenching on thermal conductivity by estimating the change in thermal properties via extant relationships between relative density [for which pre- and post-trenching data is available] =&gt; void ratio / porosity =&gt; thermal conductivity. These suggest that:

- · Jetting and ploughing of sands result in an increase in void ratio and therefore in conductor temperature with 75% of the modelled scenarios resulting in an increase of more than 5°C. However,  these  relate  to  the  largest  inferred  changes  in  relative  densities  that  occur immediately after installation. It is probable that trench conditions will undergo at least some post installation densification and therefore thermal conductivities will trend back towards the pre installation conditions and hence a smaller increase in conductor temperature;
- · Jetting and ploughing in soft clays also results in a relative increase in conductor temperature relative to the non-trenched condition but at a level (less than 3°C) that is not significant for cable design as it is within the uncertainties of the cable component of all IEC models;
- · Jetting  in  stiff  clays,  which  frequently  results  in  a  blocky  backfill  within  the  trench,  led  to significant  decreases  (between  5°C  and  33°C)  or  increases  (between  1°C  and  7°C)  in temperature depending on a combination of factors: (i) the block to matrix volume ratio, (ii) the block distribution or packing arrangements, and most importantly (iii) the nature of the fluid or consolidated soil material within the matrix;
- · A  cut  trench  in  stiff  clay  that  naturally  backfills  with  marine  sand  has  contrasting  thermal conductivities between the in situ clay material and the backfill. In addition, the fill has higher

<!-- image -->

permeability. Together these factors result in a significant temperature drop of between ~7°C and 11°C. This is due to the enhanced conduction and convection through the sand backfill.

The  idealised  nature  of  the  models  examined  means  the  relevant  results  should  not  be  used  as quantitative values of change in conductor temperature (and therefore cable rating) for any specific project site. Instead, the aim is to highlight the need to accurately characterise soil thermal properties to avoid over- or under-estimating the heat diffusion from the cable, and therefore potentially overheating the cable and soil or overdesigning the cable.

In  addition,  where  these  case  studies  involve  assumptions  about  the  final  state  of  the  ground  after trenching, e.g. the form of any backfill blocks and matrix infill, they highlight the potential value of in situ testing in and around installed cables or analysis of DTS data to help resolve these gaps in knowledge.

The financial gains of optimised cable design through an accurate knowledge of the seabed thermal environment could be further enhanced through understanding the full financial impacts of:

- · Micro routing to optimise the thermal environment;
- · Including  thermal  considerations  in  the  choice  of  trenching  technique  and  potentially proactively pre conditioning soils and cable attachments to enhance the thermal diffusion;
- · Enhancing operational condition monitoring through the confident use of Real Time Thermal Rating (RTTR) and 'Depth of Burial' software thus optimising power transmission and allowing a reduction in the number of post installation geophysical and visual monitoring surveys.

## 1.3 Characterising the seabed thermal environment for cable design

To support optimised cable thermal design, through accurate characterisation of the seabed thermal properties, a sequence of idealised 'data scenarios' is illustrated in Figure 1-4 and summarised in Table 1-1. These staged scenarios broadly represent the evolution of data availability during a project. They represent  the  available  information  about  the  soil  conditions  and  the  soil  thermal  environment  and illustrate the progression of this knowledge during the different phases of site investigation.

Figure 1-4: Illustration of data scenarios

<!-- image -->

<!-- image -->

Table 1-1: Data scenarios for Thermal Conductivity estimation

| Data scenario / survey stage   | Data type                                         | Key data                                                | Basis for estimating Thermal Conductivity                                 | Section                |
|--------------------------------|---------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------------------------|------------------------|
| 0                              | No site specific data                             | None                                                    | Full thermal database scaled for region                                   | Section 3.3.1          |
| 1                              | Geological setting                                | Soil type                                               | Soil type database subset                                                 | Section 3.3.2          |
| 2                              | In situ testing                                   | T-CPT measurement or CPT profile                        | Direct Thermal Conductivity measurement or Correlated porosity & database | Sections 2.5 and 3.4.1 |
| 3a                             | Basic lab testing                                 | Moisture content, specific gravity                      | Correlated soil type, porosity & database                                 | Section 2.3 and 3.4.2  |
| 3b                             | Thermal Conductivity lab test                     | Measurement of Thermal Conductivity                     | Measured soil type, porosity & database                                   | Section 2.3 and 3.5    |
| 4                              | Modelled Effect of trench on Thermal Conductivity | PSD - to estimate change in porosity from in situ value | Changed porosity (using I d ) & isomaterial line                          | Section 3.6            |

This document provides guidance on the measurement of thermal properties and the selection of design values for cable design and condition monitoring software. The guidance is divided as follows:

- · Section 2: Guidance on options for measuring the thermal properties of marine soils.
- · Section 3: Guidance on the selection of design thermal properties, understanding uncertainty, when equipped with different types of data (representing typical different survey stages). This guidance includes approaches for adjusting thermal properties to allow for soil disturbance effects associated with the trenching and burial process of cables.

In  addition,  Appendix A complements the guidelines by discussing currently available techniques for measuring thermal conductivity.

<!-- image -->

## 2. Thermal soil property collation and measurement

## 2.1 Thermal properties within the site investigation process

To properly characterise the soil thermal environment along a cable route section, a sufficient number of thermal conductivity/resistivity measurements should be performed to fully characterise the near seabed geology  and  the  requirements  for  cable  burial  and  cable  protection.  It  is  recommended  that  both preliminary (typically based only on geophysical survey data and desk study geotechnical data) and final (integrated, site specific geophysical and geotechnical data) ground models are consulted to inform the location and frequency of sampling. Thermal measurements should extend to below the target burial depth. Materials that potentially limit the thermal diffusion (e.g. organic or carbonate rich soils) should be specifically targeted.

Due  to  the  variability  in  the  length  and  criticality  of  cables,  and  the  variability  in  the  degree  of  soil heterogeneity, no ideal number or spacing of tests can be provided. Sufficient measurements should be made  to  provide  statistically  significant  sets  that  support  mean  and  low/high  estimates  of  thermal properties for each distinct soil unit. These typically require at least several hundreds to 1000+ tests per OWF, also depending on the cable route length and encountered soil conditions.

## 2.2 Methods for measuring thermal conductivity

The most common approach in site investigation studies has been to measure thermal conductivity on retrieved soil samples in the laboratory using a range of both transient and steady state methods. This approach requires sampling cores from the seabed and either measuring directly on the cores offshore after retrieval, or on samples onshore. The samples tested onshore may be intact or may have been reconstituted/remoulded from disturbed (e.g. bagged) samples. Intact samples still require handling and preparation for laboratory testing, and the testing process can also introduce disturbance.

It can therefore be challenging to recreate the in situ ground conditions -i.e. voids ratio/porosity and soil fabric/structure -in the laboratory and requires sufficient expertise. For this reason, the development of robust and well validated methodologies for in situ measurement of thermal properties is the focus of current research and innovation.

Common methods for evaluating thermal conductivity of marine sediments are shown in Figure 2-1.

<!-- image -->

Figure 2-1: Common methods for evaluating thermal conductivity of marine sediments

<!-- image -->

## 2.3 Laboratory testing techniques

Laboratory techniques are subdivided into two broad groups:

- · Transient methods (needle probe and hot disk) which measure the temperature variation of the sediment in response to an instantaneous heat pulse;
- · Steady state methods (guarded hot plates and thermal cells) that apply a constant heat flux to the sample until a stable temperature distribution is achieved.

Table 2-1 presents a summary of the advantages and disadvantages for the four primary laboratory methods used to measure thermal conductivity. A detailed review of each method and the commonly available systems is provided in Appendix A.

Table 2-1: Comparison of laboratory test methods

| Test Method                                                                                              | Advantages                                                                               | Disadvantages                                                                                                                                                         | Accuracy and Precision            |
|----------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------|
| • Short test duration • Suitable for most soils • Standardised test method                               | • Ensuring good contact with soil sample • Delicate • Not suitable for coarse soil       | ASTM D5344 (2014): Precision ±10-15% (Repeatability and Reproducibility)                                                                                              | Needle Probe                      |
| • Short test duration • Minimal sample preparation • Also determines thermal diffusivity & heat capacity | • Requires two identical specimens • Limited experience in being used for testing soils  | No standards for soils but BS EN ISO, 22007-2 (2015) for plastics & thermal insulation material suggest an accuracy of ±2-5% and a precision (repeatability) of ±1-2% | Transient Plane Source (Hot Disk) |
| • Standardised method • Easy to use • Effective for gravels                                              | • Long test duration • May not be suitable for most soils (< 2W/mK) • Moisture migration | BS 12664 (2001) - Based on Building Materials Accuracy ±2% Precision ±0.5-1% (Repeatability and Reproducibility)                                                      | Guarded Hot Plate                 |
| • Suitable for most soils • Minimal sample disturbance                                                   | • Long test duration • Moisture migration • Bespoke equipment                            | Comparable to Guarded Hot Plate method BS 12664 (2001) Accuracy ±2% Precision ±0.5-1% (Repeatability and Reproducibility)                                             | Thermal Cell                      |

To achieve the highest accuracy and precision of the thermal conductivity measurements the following requirements should be met:

- · Device specification, procedures and calibration steps should meet the relevant standards and the manufacturer's requirements;
- · The sample should be in equilibrium with the ambient temperature prior to testing;
- · All devices should be calibrated with an appropriate medium and the calibration should be applied  to  the  final  results.  It  is  recommended  to  use  Ballotini  as  an  effective  calibration material for marine soils;

<!-- image -->

<!-- image -->

- · A constant and stable power supply should be applied during the test;
- · Metadata of all of these aspects should be well recorded and included in the test reporting.

Additional requirements specifically for needle probe tests, which are the most commonly used test:

- · The device should be fully embedded and have good contact with the soil sample (for example. the insertion process should be a clean direct push without lateral movement);
- · The device should be installed without hammering or excessive force;
- · For  multiple  measurements,  tests  should  be  performed  with  sufficient  distances  between them and from the sample boundary to avoid interaction effects;
- · The needle probe should have a diameter greater than the grain size of the soil sample;
- · Heating  boundary  effects  should  be  avoided.  This  is  often  approximated  by  ensuring  the diameter of the soil sample container is 50x the needle diameter, which gives typical sample diameters of 50-100mm.
- · The sensitivity of the calculated thermal conductivity to the choice of the section of the cooling or warming curve should be quantified and recorded.

In addition, for best practice, it is recommended that:

- · The  results  and  interpretation  (i.e.  the  measured  test  response  and  the  interpretation  or graphical construction used to find thermal properties) should be inspected by the user or report writer visually to identify possible errors or alternative interpretations;
- · T he results should be 'sense checked' against other available data for similar soil conditions and properties, to highlight any gross differences and unexpected results, which merit further investigation;
- · Information relevant to the specific soil conditions should be considered prior to testing to ensure that the test arrangements are appropriate for the soil type;
- · The derived thermal properties should be evaluated in combination with the soil characterisation (for example, by plotting trends of thermal conductivity with moisture content or  voids  ratio  in  each  soil  unit,  to  assemble  sets  of  similar  results  from  which  statistical measures of best, low and high thermal conductivity can be identified).

## 2.4 Sample preparation

Heterogeneity and sample disturbance (either during sampling, transportation or reconstitution in the laboratory) are considerable sources of variability in thermal conductivity measurements and can often exceed  the  uncertainty  associated  with  the  measurement  and  its  interpretation.  Consequently,  it  is suggested that all laboratory samples are prepared with the following considerations:

- · Saturation states should be close to 100% and always above 80%, with saturation ideally being undertaken with a saline solution;
- · Where reconstitution/compaction is attempted, the source of the target densities should be clearly  defined,  and  attempts to recreate the in situ density should avoid creating artificial levels of anisotropy perpendicular to the applied stress planes, which can occur from tamping;
- · Where possible laboratory measurements of density should be compared with measurements taken on the vessel immediately on retrieval of  the specimen.  Even  though  disturbance is inevitable  during  the  sampling  process,  water  loss  is  common  on  retrieval/splitting  of  the

<!-- image -->

<!-- image -->

cores. Therefore, measurements of moisture content and/or density from the vessel provide data closest to the natural condition and therefore a suitable benchmark;

- · The sample being prepared should aim to represent the in situ soil structure and fabric in terms of grain sizes and mineralogy and also small scale heterogeneities such as fine scale bedding. Consideration  should  be  given  to  how  this  structure  and  fabric  could  change  during  the process of sampling and thermal testing, but also how it may change during cable installation (see Section 3.6).

## 2.5 In situ measurement techniques

To make in situ measurements of thermal conductivity there are currently three principal approaches:

- · A heat pulse is produced from an active source that is located along a linear sensor string that is attached to a coring system or solid probe. A range of instruments are available typically derived from an early 'violin bow' design developed for academic research. The temperature decay curve of the heat pulse is recorded at multiple sensors from which a profile of thermal conductivity is calculated along the length of the probe;
- · A passive source, where the heat pulse is generated through friction between the probe and the seabed soil during insertion of the probe. This approach has recently been developed as a modification of a conventional CPT with an added temperature sensor, frequently in the tip, and known as a T-CPT. As for active sources, the sensor records the rate of temperature decay to  calculate  thermal  conductivity  at  a  set  depth.  As  these  systems  only  have  a  single temperature sensor, multiple pushes are required to get measurements at different depths.
- · Conversion from standard CPT parameters (cone resistance and friction ratio) to give bulk thermal conductivity values through correlations. These correlations usually first estimate the bulk density, with correlation parameters being linked to grain mineralogy. The voids ratio and porosity is then estimated from the bulk density, based on an assumed grain specific gravity linked  again  to  the  soil  mineralogy.  From  porosity  the  bulk  thermal  conductivity  is  then estimated, using assumed values for the pore fluid and grain thermal conductivities (with the grain thermal conductivity also being estimated from the soil mineralogy).

For successful deployment and the acquisition of reliable measurements it is important to consider the following, for the active and passive sources:

- · The ambient temperature should be well constrained. For active systems a time lag of several minutes is advised for the frictional heat pulse from installation to dissipate prior to generating the  controlled  heat  pulse.  For  passive  systems  the  ambient  temperature  can  either  be backcalculated  (but  with  inevitable  uncertainty)  or  temperature  measurements  should  be continued until the ambient temperature has been achieved again;
- · The specific thermal properties of the probe (i.e. the parts, their shapes and their thermal properties) and the specific contact thermal resistance with the surrounding soil require all in situ  probe  thermal  measurements  to  be  calibrated  either  against  theoretical  models  or conventional needle probe measurements either in the field or the laboratory. The contact thermal resistance can be affected by liquefaction of the surrounding soil during installation, convection in the pore water and disturbance of the adjacent grains resulting in a local change in  porosity.  As discussed in Sections 2.3 and 2.4, for in situ tests to be calibrated against needle  probe  measurements,  they  should  themselves  be  calibrated  against  appropriate

<!-- image -->

<!-- image -->

standards. Whatever approach to calibration is used it needs to be clearly recorded and set out in the test report;

- 1200 seconds is required to record the full response.
- · A measurement time of at least 500 -For passive systems it is also important to consider that:
- · The initial  temperature  rise ∆ T should  exceed  3°C,  to  provide  a  clear  decay  curve.  This  is usually achieved in sands where probe shaft friction is high, but is difficult in fine grained soil.

There are still few publicly available studies that have tested the accuracy and precision of all of the active and passive in situ techniques. Published results indicate that the 'relative accuracies' of active systems  are  within  ±5%  of  laboratory  thermal  conductivity  measurements  for  the  same  material. Unpublished commercial studies have shown thermal conductivity measurements in sands using an in situ  passive  system  that  are  20%  higher  than  measurements  from  needle  probe  tests on  collocated samples. However, as further experience of the passive in situ CPT systems is gained, this observation may  not  be  universal.  There  is  therefore  an  urgent  requirement  for  such  systems  to  undergo  well documented  benchmark  testing,  comparable  to  that  undertaken  for  the  ASTM  D5344  needle  probe standards.

The CPT correlation approach to estimate thermal conductivity from standard CPT data are attractive due to the simplicity and potential time and cost savings that arise from eliminating any specialised thermal  testing.  However,  at  present  there  are  quite  large  differences  both  when  compared  against laboratory needle probe measurements and collocated in situ T-CPT and certainly at levels that could significantly impact on cable design as described in Section 1.2. Consequently, this approach should at present be treated with caution until a realistic accuracy and precision can be determined. It will remain a useful tool to gain estimates of thermal conductivity from early site investigation campaigns where thermal test data does not yet exist, or to supplement actual measurements across a project or soil unit after  the  correlation  has  been  checked  and/or  recalibrated  against  either  laboratory  or  other  in  situ measurement methods.

A summary of the relative merits of laboratory based and in situ thermal property tests is presented in Table 2-2. This comparison highlights that several factors influence the optimum choice of test and there is no single test type that is preferred.

Our expectation is that in situ testing will become the default approach to measuring thermal conductivity for cable design, with laboratory based measurements being used to further analyse complicated and thermally limiting soils (e.g. gravels, very fine grained over consolidated materials, organic and carbonate rich  materials).  However,  since  active  in  situ  testing  apparatus  is  not  widely  specified  for  site investigations and passive in situ tests are relatively new, with limited published experience, in situ testing is not yet accepted as the default approach, and best practice is currently to use both types of testing. Needle  probe  laboratory  testing  of  tube  samples  remains  currently  the  primary  source  of  thermal conductivity data on projects.

<!-- image -->

Table 2-2: Laboratory based versus in situ geotechnical tests

|                                                       | Laboratory based measurement                                                                                                             | In situ measurement                                                                                                                                                         |
|-------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Control of experimental conditions                    | Easily control both environmental, testing and boundary conditions. NB. Boundary conditions can be restricted depending on the equipment | Experimental environmental, testing and boundary conditions difficult if not impossible to control                                                                          |
| Interpretability                                      | Generally yes as the sample is logged i.e. well characterised                                                                            | Interpretation is difficult without adjacent laboratory soil samples                                                                                                        |
| Representative sample volume                          | Can be restrictive to unrepresentative, small sample volumes introducing uncertainty in laboratory to field scale comparisons            | Generally larger volumes are sampled better approximating a continuous media                                                                                                |
| Preservation of sample quality                        | Possible disturbance due to: Fabric changes, stress relief and desiccation                                                               | Techniques considered here are intrusive generating possible disturbances due to: Generation of excess pore pressure in saturated soils, unavoidable localised disturbance, |
| Ability to vary the properties of the tested material | Possible to simulate e.g. trenching and loading of laboratory samples, parametric sensitivity and long time span studies                 | Not possible to simulate drift in environmental conditions and expensive to simulate long term investigations                                                               |
| Time (test and interpretation duration)               | Time consuming and laborious to conduct. Requires both sampling and laboratory sample preparation and measurement.                       | Can vary depending on ease of deployment and length of time held static at each sampling point.                                                                             |
| Cost                                                  | Can be economic under certain conditions, although time delay relative to in situ testing may offset any cost reduction.                 | Passive systems are low cost as integrated within standard CPT. Active systems less widely used, so can be costly to mobilise and operate.                                  |
| Equipment                                             | Prevalent, well established                                                                                                              | Relative infancy in the commercial sector, though being actively developed. Future developments must include robust determination of accuracy and precision                 |

## 3. Selection of soil thermal properties

## 3.1 Introduction

This section provides guidance on the selection of design values of thermal properties from different data sources -ranging from preexisting databases to project specific sets of measurements (Table 31). These data scenarios are illustrative of different project stages (Figure 3-1). As the data scenarios become  more  advanced,  the  design  range  (or  the  uncertainty)  in  thermal  conductivity  will  reduce. Although each scenario refers to a particular data type, in practice all data types available to the project should be combined or compared, to take most value from the available measurements.

<!-- image -->

Figure 3-1: Illustration of data scenarios (Figure 1-4 repeated)

<!-- image -->

<!-- image -->

<!-- image -->

Table 3-1: Data scenarios for Thermal Conductivity estimation (Table 1-1 repeated)

| Data scenario / survey stage   | Data type                                         | Key data                                                | Basis for estimating Thermal Conductivity                                 | Section                |
|--------------------------------|---------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------------------------|------------------------|
| 0                              | No site specific data                             | None                                                    | Full thermal database scaled for region                                   | Section 3.3.1          |
| 1                              | Geological setting                                | Soil type                                               | Soil type database subset                                                 | Section 3.3.2          |
| 2                              | In situ testing                                   | T-CPT measurement or CPT profile                        | Direct Thermal Conductivity measurement or Correlated porosity & database | Sections 2.5 and 3.4.1 |
| 3a                             | Basic lab testing                                 | Moisture content, specific gravity                      | Correlated soil type, porosity & database                                 | Section 2.3 and 3.4.2  |
| 3b                             | Thermal Conductivity lab test                     | Measurement of Thermal Conductivity                     | Measured soil type, porosity & database                                   | Section 2.3 and 3.5    |
| 4                              | Modelled Effect of trench on Thermal Conductivity | PSD - to estimate change in porosity from in situ value | Changed porosity (using I d ) & isomaterial line                          | Section 3.6            |

## 3.2 Thermal property geodatabases

Thermal property geodatabases can be produced based on available data, for instance needle probe thermal conductivity (TC) measurements, from a range of seabed soils from different projects. These databases can be used in early phases of the project for pre survey estimation of TC (see Section 3.3).

Detailed information on mineralogy, grain size and other physical parameters (bulk and dry densities, moisture content, porosity) should be evaluated together with the TC measurement. For instance, poorly saturated  samples  (saturation  ratio,  Sr &lt; 80%)  should  be  excluded  from  any  dataset,  provided  that sufficient metadata are available.  In case these data are unavailable, the robustness of a geodatabase could be impacted and the range of correlations that could be explored becomes more limited, also hampering the evaluation of quality for each data point.

The  available  data  points  can  be  subdivided  into  five  broad  soil  classifications:  (i)  quartz  sand,  (ii) carbonate sand, (iii) silt, (iv) clay and (v) peat.

## 3.2.1 Statistical analysis

Statistical analysis should be undertaken on the geodatabase, with standard parameters shown in Table 3-2 . An example of presenting the data in scatter plots (combined box, whisker and 'beeswarm') is shown in Figure 3-2.

<!-- image -->

Outlier detection of the normally distributed data can be calculated using a classic approach to calculate 'outlier fences', to identify data points that require further investigation (potentially excluded). Where metadata  are  available  samples  should  be  filtered  to  remove  measurements  that  do  not  meet  the selection criteria or sample preparation standards. Measurements without extensive metadata can be retained, though this might be a source of uncertainties.

<!-- image -->

Figure 3-2: Combined box, whisker and beeswarm scatter plot - statistical parameters

<!-- image -->

<!-- image -->

<!-- image -->

Table 3-2: Normal distribution statistical parameters -geodatabase evaluation

| z                                                       | Definition                                               |
|---------------------------------------------------------|----------------------------------------------------------|
| MAX TC (W/mK)                                           | Maximum value                                            |
| MIN TC (W/mK)                                           | Minimum value                                            |
| MEDIAN [P50] TC (W/mK) Median, 50 th Percentile, middle | value                                                    |
| MEAN TC (W/mK)                                          | Mean Value                                               |
| STDEV (W/mK)                                            | Standard Deviation                                       |
| P10 (W/mK)                                              | 10 th Percentile                                         |
| P90 (W/mK)                                              | 90 th Percentile                                         |
| Upper Quartile (UQ) (W/mK)                              | 75 th Percentile                                         |
| Lower Quartile (LQ) (W/mK)                              | 25 th Percentile                                         |
| Inter Quartile Range (IQR) (W/mK)                       | UQ-LQ                                                    |
| IQR*1.5 (W/mK)                                          | Mild whisker magnitude                                   |
| IQR*3 (W/mK)                                            | Extreme whisker magnitude                                |
| UQ+IQR*3 (W/mK)                                         | Extreme upper whisker threshold - outlier identification |
| UQ+IQR*1.5 (W/mK)                                       | Mild upper whisker threshold - outlier identification    |
| LQ-IQR*1.5 (W/mK)                                       | Mild lower whisker threshold - outlier identification    |
| LQ-IQR*3 (W/mK)                                         | Extreme lower whisker threshold - outlier identification |
| N                                                       | Number of data points                                    |

## 3.2.2 Repeatability-correction of TC database for each soil type

Subsets of any database might include multiple Thermal Conductivity measurements made on the same soil samples. These repeat tests on sub samples of the same soil provide different measurements of TC, indicating the repeatability error associated with the test. Based on the review of TC test repeatability, a coefficient of variance (CoV or v ) per soil type can be applied on the raw database values, considering TC measurements with the same method (e.g. needle probe).

## 3.2.3 Weighted database according to seafloor soil variation

The  database  might  contain  measurements  on  predominantly  specific  soil  class,  e.g.  more  TC measurements from sands compared to clays or other soil classes. When considering a single TC value for  initial  design  phases,  the  actual  distribution of  seafloor soils  might be  different  compared  to the database.  Hence,  a  weighting  must  be  applied  when  combining  the  different  soil  types  within  the database, rather than considering simply the statistics of the available database.

<!-- image -->

<!-- image -->

## 3.2.4 Thermal conductivity versus porosity -trend lines per soil type

The key relationships relevant to the calculation of porosity from standard laboratory measurements are shown in Table 3-3. These are standard relationships that rely only on the assumption of full saturation (i.e. they are written here for two phase materials, water and solid, with no gas phase -extensions apply for partially saturated soils). These relationships provide a route from data of moisture content, 𝑤 , and grain specific gravity, 𝐺𝑠 , to porosity, 𝑛 .

Table 3-3: Relevant phase relationships to derive porosity from standard laboratory data

| Relationship                                                              | Formula        | Notes                                                                                                                                                                                                                                                                                          |
|---------------------------------------------------------------------------|----------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Grain specific gravity, 𝐺 𝑠                                               | 𝐺 𝑠 = 𝜌 𝑠 /𝜌 𝑤 | 𝐺 𝑠 can be estimated based on the soil mineralogy or measured with tests such as the pycnometer (density bottle). There is relatively small variation in 𝐺 𝑠 between soil minerals. Typically values: quartz sand: 2.65, other soil minerals: 2.6 -2.8 Grain density, 𝜌 𝑠 ; water density, 𝜌 𝑤 |
| Voids ratio, 𝑒 , from moisture content, 𝑤 and grain specific gravity, 𝐺 𝑠 | 𝑒 = 𝐺 𝑠 𝑤      | Moisture content: 𝑤 = 𝑊 𝑤 /𝑊 𝑠 , (weight of water / weight of dry solids Assumption: soil fully saturated                                                                                                                                                                                      |
| Porosity, 𝑛 from voids ratio, 𝑒                                           | 𝑛 = 𝑒 1 +𝑒     | By definition: porosity is pore volume relative to total volume, whereas voids ratio is pore volume relative to solid volume                                                                                                                                                                   |

The standard geometric relationship between the thermal conductivity of seawater ( 𝜆𝑓𝑙𝑢𝑖𝑑 : 0.6 𝑊/𝑚𝐾 ), the solid phase thermal conductivity ( 𝜆𝑠𝑜𝑙𝑖𝑑 ) and porosity ( n ), to estimate the bulk thermal conductivity range for marine sediments is presented in Equation 1. Typical values for grain thermal conductivities of marine sediments are presented in Table 3-4.

𝝀𝒃𝒖𝒍𝒌 = 𝝀𝒔𝒐𝒍𝒊𝒅 𝟏-𝒏 𝝀𝒇𝒍𝒖𝒊𝒅 𝒏

Equation 1

<!-- image -->

<!-- image -->

Table 3-4: Typical grain thermal conductivities of marine sediments

| Mineral Phase    | Grain Thermal Conductivity [W/mK]   | Source                               |
|------------------|-------------------------------------|--------------------------------------|
| Quartz           | 7.7                                 | Horai, 1971                          |
| Calcite          | 3.5 - 3.6                           | Clauser & Huenges, 1995; Horai, 1971 |
| K-Feldspar       | 2.3 - 2.4                           | Horai, 1971; Clauser & Huenges, 1995 |
| Illite           | 1.8                                 | Midttømme et al., 1998               |
| Montmorillonite* | 1.4                                 | Knutsson (1983)                      |
| Chlorite         | 3.1 - 5.25                          | Clauser & Huenges, 1995              |
| Kaolinite        | 2.8                                 | Brigaud & Vasseur (1989)             |

Notes : Measurements taken on compacted bentonite with a montmorillonite composition

When the database measurements correlate well with theoretical relationships between porosity and TC, the resulting scatter can be used to establish confidence bounds. Hence, new correlations for estimating TC from porosity and mineralogy can be established, providing initial estimates of thermal conductivity in the absence of direct thermal measurements. Specifically, Equation 1 can be calibrated to the sub database of each soil type of the database, by adjusting 𝜆𝑠𝑜𝑙𝑖𝑑 to find a best fit (P50) value, denoted 𝜇𝜆 , and evaluating the standard deviation of this parameter, 𝜎𝜆𝑠 . By considering a normal distribution for the database, the P10 and P90 values of 𝜆𝑠𝑜𝑙𝑖𝑑 can also be calculated.

## 3.3 Pre survey estimation from databases

## 3.3.1 No site specific data available (Data Scenario 0)

At early stages of a project, when no site specific information is available (Data Scenario 0 in Figure 3-1 and  Table  3-1),  the  Thermal  Conductivity  can  be  estimated  by  assuming  that  available  thermal conductivity database(s) of all soil types is relevant.

Within a specific database the scatter due to measurement repeatability error can be removed based on the repeatability evidence, as described in Section 3.2.2. Moreover, depending on the prevalence of each soil type at the seafloor across the site (for instance UK waters or any specific region of interest), the database can be weighted accordingly (Section 3.2.3).

Based  on  the  distribution  of  sediments,  mean  and  standard  deviation  values  can  be  calculated  by combining weighted populations. From this, the mean, standard deviation, lower (e.g. P10) and upper (e.g. P90) percentile values of Thermal Conductivity can be provided (Section 3.2.1).

<!-- image -->

## 3.3.2 Soil type data available (Data Scenario 1)

In cases where the likely seabed soil type is known (Data Scenario 1 in Figure 3-1 and Table 3-1), without any other site specific data available, the Thermal Conductivity can be estimated by assuming that the available  thermal  conductivity  database  for  that  specific  soil  type  is  relevant.  The  corresponding statistical values can be used, after measurement repeatability error has been removed as described in Section 3.2.2.

For each soil type the statistics of the repeatability corrected database can be used to provide mean, standard  deviation,  lower  (e.g.  P10)  and  upper  (e.g.  P90)  percentile  values  of  Thermal  Conductivity (Section 3.2.1).

In summary, for Data Scenario 1, where the seabed soil type is known or estimated, the repeatability corrected geodatabase statistics provide soil type specific design values.

## 3.4 Site specific data available excluding thermal properties

## 3.4.1 In situ CPT data available (Data Scenario 2)

Data Scenario 2 is where site specific in situ CPT testing has been performed (Figure 3-1 and Table 3-1).

Standard CPT data can be used to estimate soil type, and then bulk density and therefore porosity using correlations based on the CPT parameters (see also Appendix A.2.3). The soil type can be estimated using conventional Soil Behaviour Type charts (e.g. Robertson charts). From this, a soil mineralogy can be estimated, potentially using insight from the regional geology, from which the grain specific density and thermal conductivity can be estimated. Further information is provided in Appendix A.2.3.

Following this step, the Thermal Conductivity can be estimated from thermal conductivity relationships for two phase materials, as discussed in Section 3.2.4. A similar approach to find thermal conductivity from CPT data is set out by Vardon &amp; Peuchen (2021).

In summary, for Data Scenario 2, where CPT data is available, a chain of correlations can be applied to estimate the soil type (including mineralogy) and the porosity. From these values the thermal conductivity can be estimated using porosity-Thermal Conductivity relationships developed for a specific soil type (see Section 3.2.4). The repeatability error correction is incorporated in these trend lines (see Section 3.2.2). For other soil mineralogies, different to the database soil types, Equation 1 can be used directly with the grain mineralogy (with the 𝜆𝑠𝑜𝑙𝑖𝑑 values for various minerals given in Table 3-4).

Where campaigns of direct, in situ, thermal conductivity has been measured, using either passive or active approaches, then significantly more reliable measurement are available at this stage. As described in Section 2.5 these measurements are still in their relative infancy in terms of OWF projects and these techniques still require more research before their accuracy and precision can be fully determined. At present they should be used in tandem with conventional laboratory based measurements which have been prepared in a manner that confidently replicates the in situ conditions. The sector should be striving to  ensure  that  these  approaches  undergo  an  extensive  multi  OWF  testing  campaign  to  provide  this confidence.

## 3.4.2 Lab test data available (Data Scenario 3a)

In Data Scenario 3a, basic soil classification data is available, so the soil type, mineralogy and porosity are assumed to be known -with a reduced uncertainty compared to the CPT based estimates of Data Scenario 2 (Section  3.4.1).  Porosity  can be  calculated  from measures of bulk density or voids ratio, following the relationships given in Table 3-3.

<!-- image -->

<!-- image -->

Following this step, the Thermal Conductivity can be estimated from thermal conductivity relationships for two phase materials (see also Section 3.4.1), using database trend lines as described in Section 3.2.4.

In summary, for Data Scenario 3a, where basic soil lab test data is available, the thermal conductivity can be  estimated  using  porosity-Thermal  Conductivity  relationships  developed  for  a  specific  soil  type

(Section 3.2.4) or grain mineralogy (Table 3-4).

The repeatability error correction is incorporated in the soil type trend lines (see Section 3.2.2).

## 3.5 Site specific thermal property data available (Data Scenario 3b)

In Data Scenario 3b, project specific thermal conductivity measurements have been obtained. These data can be used directly to specify design values, taking statistical estimates of Thermal Conductivity for each soil unit. However, part of the scatter within the measurements is repeatability and the remainder represents the actual natural variability. The repeatability correction method is also applicable to sets of data gathered from the same soil unit during a site survey. It is therefore possible to estimate the actual range of thermal conductivity by correcting the collected data using the same approach (as described in Section 3.2.2).

It is recommended that from these final measurements, and where appropriate these laboratory based measurements  are  combined  with  in  situ  directly  measured  thermal  conductivities.  The  following statistics should be calculated: Maximum, P90 and P75 values are calculated for each soil unit and used for sensitivity testing of different cable designs. Reference should be made to the spatial location of the values in the top 10% of the measurements to identify, from any available ground model, if these values are actually spatially restricted and/or related to a single soil type. Ultimately, these values should drive risk based decision making and should not be seen as single values to which a whole windfarm cabling system is designed. Mitigation strategies such as: changes in cable sizing at different sections of the route; minor cable rerouting; and shallowing depth of lowering (with or without surface protection) should be considered.

## 3.6 Modelling trench effects -allowing for soil disturbance (Data Scenario 4)

Data Scenario 4 represents a situation in which the effect of a trench on the soil thermal conductivity is to be considered. The database and mixture models (Equation 1) can be used to estimate the effect of the trenching process, by linking the mechanical effect of the trenching process to the thermal properties.

For sandy soils, the trenching process may loosen the soil, leading to lower thermal conductivity. The Thermal  Conductivity  porosity  trend  lines  given  by  Equation  1  provide  a  basis  to  link  the  loosening (change in porosity) to the reduction in conductivity. These trend lines represent a single material, with a given mineralogy (so can be referred to as an iso-material line). As the porosity is altered by the trenching process, the thermal conductivity will follow the iso-material line. The limits on porosity change from the trenching process can be estimated through maximum and minimum voids ratio test data, and/or relative density analysis of CPT data.

For clay soils, the trenching process may produce a more complex situation with blocks of intact clay surrounded by muddy water or clay slurry. In the long term, the clay will reconsolidate but now in a normally consolidated condition, at a higher voids ratio (and porosity) compared to the initial condition -but on the same isomaterial line.

<!-- image -->

These concepts for estimating the thermal conductivity (and permeability) of the trenched material were explored in WP3 of this project, through numerical modelling (different trenching and burial methods). A brief summary of key results include:

- · The  burial  process  tends  to  loosen  the  seabed  material,  reducing  the  thermal  conductivity, therefore tending to increase the cable temperature for a given load;
- · Ploughing disturbs a larger zone of soil than jetting, so affects the cable temperature more;
- · An exception is in stiff clay, which forms a blocky backfill with large voids. If these voids remain filled with water, then convection is significantly enhanced, leading to significant cooling of the cable. If the voids fill with sand or reconsolidated clay, then the net effect on cable temperature could be either an increase or a decrease.

Figure  3-3  illustrates  typical  results  of  these  effects  for  sand  and  soft  clay  for  example  installation scenarios.  The  predicted  changes  in  cable  temperature  are  specific  to  the  cable  and  soil  properties modelled in this study, so are only indicative of general trends and should not be relied on for design.

<!-- image -->

<!-- image -->

<!-- image -->

Figure 3-3: Cable temperature change due to burial - induced seabed properties changes

| Scenario   | Scenario                                                                 | A. Wished-in-place - perfect simultaneous lay &burial   | B. Pre-cut plough - post-backfilling   | C. Plough - simultaneous lay &burial   |
|------------|--------------------------------------------------------------------------|---------------------------------------------------------|----------------------------------------|----------------------------------------|
| Legend     | 0< Δ T < |5| O C                                                         | 1.5m                                                    | 1.5m                                   | 4.5m DoB = 1.5m 1 2                    |
| Legend     | |5| < Δ T < |10| O C Δ T > |10| O C                                      | DoB = 1.5m 1 1.2m 1 Width = 0.3m 2                      | DoB = 1.5m 1 2 1.2m                    | 0.8m                                   |
| SAND       | Void ratio: 0.49/0.90 Prosity: 0.31/0.47 TC: 3.49/2.30 W/mK Load: 1400 A | 5.5 O C                                                 | 7.8 O C                                | 8.9 O C                                |
| SAND       | Void ratio: 0.55/0.95 Prosity: 0.36/0.49 TC: 3.11/2.22 W/mK Load: 1370 A | 4.7 O C                                                 | 6.5 O C                                | 7.5 O C                                |
| SAND       | Void ratio: 0.80/1.20 Prosity: 0.44/0.55 TC: 2.48/1.91 W/mK Load: 1300 A | 4.0 O C                                                 | 5.6 O C                                | 6.4 O C                                |
| SAND       | Void ratio: 1.00/1.40 Prosity: 0.50/0.58 TC: 2.15/1.74 W/mK Load: 1265 A | 3.4 O C                                                 | 4.8 O C                                | 5.5 O C                                |
| SOFTCLAY   | Void ratio: 0.45/0.90 Prosity: 0.31/0.47 TC: 3.49/2.30 W/mK Load: 1090 A | 1.6 O C                                                 | 2.1 O C                                | 2.7 O C                                |

<!-- image -->

-Techniques for measuring thermal conductivity for measuring thermal conductivity

<!-- image -->

## Appendix A.1 Laboratory techniques

## Appendix A.1.1 Needle probe

The non steady state (transient) needle probe (NSSP) accounts for the vast majority of published thermal data  for  geomaterials.  It  is  one  of  the  oldest  most  established  techniques,  and  the  only  one  with standards  dedicated  to  geomaterials  (ASTM  D5334-2014  &amp;  IEEE  Std-442-2017).  Needle  probes  are preferred for their short test duration, low levels of sample preparation and the standardised method with accurate results obtained.

The needle probe test consists of heating a wire in addition to a thermocouple temperature sensor and is used  to  solve  analytical calculations  for  the temperature  rise  at  the  thermocouple. During measurement, the probe is inserted and allowed to equilibrate within a sample before a constant power 𝑞 (W/m) is applied for a transient period 𝑡 ℎ𝑒𝑎𝑡 (s) inducing a temperature rise ( ∆θ) in the source.

The  present  standards  outline  the  factors  that  influence  the  results  including  sample  preparation, experimental configuration, contact resistance, calibration, heat time and power (Section 1.1). Several geometries and iterations are available for both laboratory and direct field measurements, e.g. instance TP02/TP08 (Hukseflux) and KD2/KD2-Pro (Decagon).

Figure A.1: Diagram of TP02 needle probe

Notes: 1: Reference temperature sensor pt1000. 2: Heating element (wire) runs across 2/3 needle length. 3: Hot joint thermocouple junction. 4: Cold joint thermocouple junctions. 5: Power supply.

<!-- image -->

Typical, experiments demonstrate an initial nonlinear, transient, section (Figure A.2) which reaches a quasi-steady  state  after  overcoming  contact  resistance  and  the  thermal  properties  of  the  probe (Vos, 1956). After longer periods the temperature variation with time becomes nonlinear again due to edge effects, axial heat flow (Vos, 1956) and potentially moisture migration or convective heat transport (ASTM D5334-14). The influence of convection may be removed by ensuring that the gradient of the slope is calculated from the linear section only. The cooling section of the curve can also be used in addition to the heating curve, providing additional results (Low et al., 2015 and 2016).

In deriving the slope, both IEEE Std 442-2017 &amp; ASTM D5334-14 plot the results on a semi-log graph, i.e. Δ𝜃 against ln 𝑡 .  The  quasi-linear  segment  is  then  determined  by  excluding  the  first  10-30s  for  small diameter  probes  (ASTM  D5334-14)  or  visually  by  selecting  two  appropriate  times  between  which  a straight line can be fitted to the data and its gradient calculated.

<!-- image -->

<!-- image -->

The use of visual inspection introduces interpretive variability. Automated analysis of the results through regression could be beneficial in standardizing interpretation through the selection of the quasi-linear segment. In (Low et al., 2015 and 2016) the propagation of errors method was used to indicate errors of 12.7% due to uncertainty in gradient evaluation.

To  obtain  appropriate  time  ranges  for  accurate  calculations  a  simulation  investigation  using  finite element analysis was undertaken based on the TP02 design matching experimental conditions by the University of Southampton. To define the best calculation periods for different TC ranges, assessment was performed to highlight the overlaps of low error calculation periods:

- · At the lower end of the TC spectrum (0.75 to 1.75W/mK) a 100 seconds measurement window, with a starting time of ~ 150 seconds is best applied.
- · The  middle  range  (1.85  to  2.85W/mK)  the  low  error  calculation  periods  become  more constrained. Periods are closer to the start of the heating cycle, meaning that the transient period is shorter. A starting time of at least 60 seconds and a calculation window of 130 seconds is recommended.
- · The higher end of the TC spectrum (2.95-3.95W/mK), the range of accurate calculation periods can have a starting time anywhere between 30 -70 seconds and a duration of 10 -80 seconds.

## Figure A.2: Example of needle probe test results (Low, 2016)

Notes: TC can be determined by using both heating and cooling phases, but the heating phase is by far the most common approach

<!-- image -->

## Appendix A.1.2 Transient plane source (hot disk)

The transient plane source (Hot Disk) method was developed to determine both TC and diffusivity, which allows the determination of specific heat capacity of a specimen. Two configurations of the probe are available, the hot plate/square or the hot disk onto which a thin bifilar spiral, is applied by a deposition technique or through using thin metal foils enclosed between thin insulating films (BS EN ISO, 22007-2, 2015). This results in the disk acting as both heat source and temperature sensor (Figure A.3).

<!-- image -->

Figure A.3: The Transient Plane Source Technique (Gustafsson, 1991)

<!-- image -->

<!-- image -->

The theory presumes the source is surrounded in an infinite homogeneous medium and the probe is situated  between  two  identical  specimens  of  the  same  solid.  Once  equilibrated,  the  temperature  is increased by 1 to 2K through the application of a constant current therefore as the temperature changes so does the resistance. The heat transfer model for the hot disk method does not have a theoretical analytical solution as it is an absolute technique. Commercially available hot disks come with software developed to solve partial differential heat transfer equations iteratively.

This method is favoured for its speed and low sample disturbance, accuracy and simultaneous resolution of TC and thermal diffusivity. Τ here are no standards for applying hot disk to geomaterials, however (Gustafsson, 1991) demonstrated a 3% uncertainty when applying it to solids. Accurate readings are predicated on good thermal contact, which for coarser unconsolidated geomaterials becomes difficult.

## Appendix A.1.3 Guarded hot plate

The guarded hot plate is a versatile, non intrusive, plane source technique for determining TC with the direct application of Fourier's Law. There are two principal configurations although many geometries are possible: the first sandwiches a hot plate between two samples of the same specimen (Figure A.4a) and the second shown in (Figure A.4b) sandwiches a single sample of the specimen above a hot and below a cold plate. Both rely on the axial generation of a steady state temperature gradient, the first up through the top and down through the bottom samples, the second just axially up through the sample.

The theory is predicated on the development of one directional flow which requires adequate application of insulating guards to prevent losses at the base and radial flow from the sides. Insufficient insulation will result in an overestimation for the applied power and consequently the TC. This effect is reduced in the two specimen configuration.

Guarded hot plate are easy to construct and operate, relying on simple analysis and the generally sample preparation is minimal. However, the variants of this technique are well established in the determination of the thermal conductivity of building materials, while for geomaterials, there are uncertainties related to  the  equipment,  test  procedure,  sample  size  and  sample  preparation.  Ensuring  construction  and operation  follow  the  specified  standards  the  corresponding  accuracies  (±2%  BSI  12664,  2001), repeatability (±0.5% BSI 12664, 2001 and ±1% ISO 8302,1991) and reproducibility (±1% BSI 12664, 2001; ISO 8302,1991) can be achieved. These standards were not written specifically for soils and practicalities of this approach might be challenging on a project basis.

<!-- image -->

## Figure A.4: The two forms of guarded hot plate method

Notes: (a) hot plate sandwiched between two specimens of a sample with steady state temperature gradient being achieved up through the first specimen and down through the lower specimen (ASTM C177-19, 2019). (b) is a single sample, heat is generated by the base plate and transmitted up through the sample to the cold plate generating a steady state temperature gradient

<!-- image -->

<!-- image -->

## Appendix A.1.4 Thermal cell

The thermal cell is also a non intrusive plane source technique and is theoretically identical to the guarded hot plate and so can be considered an iteration of this method. It has been specifically developed to analyse thermal properties of U-100 cores and BS 5930:2015+A1 (2020).

The theory is based on the generation of constant axial (1D) thermal gradient produced by an embedded heater in the base which dissipates heat from the top (Clarke et al, 2008). Once steady state is achieved, if power is measurable, thermal conductivity can be derived through the di rect application of Fourier's Law otherwise, the lumped capacitance method can be used in special circumstances to evaluate power (Clarke et al, 2008).

This  method  is  suitable  for  most  soils  and  relies  on  simple  analysis  directly  suited  to  U-100  cores. Although, there are no official standards for the thermal cell or alternatives, the 'Thermal Pile Design, Installation &amp; Materials Standards' recommends th e thermal cell as the laboratory method along with needle probes. There are uncertainties related to the equipment, test procedure, sample size and sample preparation, noting that the Clarke et al (2008) cell and University of Southampton cell are presently not recommended over transient methods (Low et al, 2017).

Figure A.5: Schematic of a thermal cell (Low, 2016) based on (Clarke et al., 2008)

<!-- image -->

## Appendix A.2 In situ techniques

## Appendix A.2.1 Passive and active thermal probes

The most widely known, actively heated, thermal probe system that is available for commercial use is the Fielax VibroHeat, which can be deployed on a Vibrocorer or integrated into CPT systems above the cone tip. The device combines passive and active heating phases and is deployed into the seabed penetrating the soil. During this process (shown in Figure A.6): during penetration the temperature usually rises from frictional heating but settles on an ambient soil temperature. This allows for relative soil temperature to be recorded as a function of depth determining the temperature gradient. After allowing the dissipation of the frictional heat (at least 10 minutes of stabilisation time), a heat pulse with a 20 second duration is enabled  and  heats  the  sensor  tube  and  surrounding  soil  generating  a  sharp  temperature  spike.  To measure the decay of thermal energy, the probe remains in the soil for at least 20 minutes allowing for a depth dependent result for the TC of the soil. highlights this process.

## Figure A.6: Method of deployment of Fielax VibroHeat system (Evensett et al., 2016)

<!-- image -->

It can be difficult to establish the accuracy and precision for these instruments and often making the information public is not possible. However, the individual components give temperature measurements to an accuracy of &lt; 100mK with a precision of ± 1mK.

<!-- image -->

<!-- image -->

A second heat probe system used in industry with a similar design is the FERITECH FT580 Heat Flow Probe. Real time TC, spot temperature and thermal gradient measurements can be produced from this probe within the seabed. The system is a standalone system with a uniform heat source along the length of the probe including high density (0.05m resolution) array of thermistors. As mentioned, data can be collected  in  real  time  or  collected  automatically  and  stored  internally  and  then  extracted  when  the instrument is recovered. Due to the nature of this system, it can also be left on the seabed for longer periods of  time  in  a  passive  mode  recording  seasonal  changes.  Currently  there  are  no  published  or publicly available work into assessing the performance of this system.

A further active method for in situ TC measurement is the use of a needle probe that is attached to the tip of a conventional cone penetrometer (CPT). The device operates and is interpreted in the same way as a lab based needle probe (see Appendix A.1.1) and is usually of slightly greater dimensions, to be more robust when used offshore. For example, the probe may be 4-8 mm in diameter and extend by 150200  mm  beyond  the  tip  of  a  conventional  35.7  mm  diameter  CPT.  These  devices  are  available  for commercial use, but the passive Thermal-CPT is becoming more commonly used (see Section Appendix A.2.2).

Based on physical experimental investigation and modelling works (undertaken by Emeana et al, 2016; Hughes et al, 2015a and Callender et al, 2021) the following should be considered:

- · Permeability can play a major role within heat dissipation from HV cables. Especially in high permeability  soils,  the  main  mode  of  heat  transportation  is  through  convection,  which  if occurring when undergoing in situ testing would be reflected in higher TC measurements.
- · There might be discrepancies in comparison to the laboratory testing results, especially in silty sand or fine and medium sands with low relative densities (c. &lt; 50%).
- · It  is  considered  that  the  main mode of heat transportation is through convection (for high permeability  soils).  Currently  there  is  no  theoretical  or  experimental  work  into  the  effects convection may have with these in situ probes.
- · Similarly, to date there have been no systematic investigation into the effects of liquefaction and soil disturbance and how these events may affect the permeability of the soil which could impact the measurements (see also remarks on sample preparation for laboratory testing).

## Appendix A.2.2 Passive method -thermal CPT

Thermal-CPT (T-CPT), Figure A.7, uses an added temperature sensor on a standard cone penetrometer and follows the same protocol as a CPT (e.g. ISO, 2021). To measure TC the test is stopped and during this state of static penetration the temperature decay is recorded and from this the temperature time series measurements for TC can be calculated (Vardon et al, 2018).

The T-CPT system generally performs best in sandy sediments with sufficient friction to generate a temperature  difference  between  the  ground.  TC  is  calculated  using  one  of  the  two  mathematical methods presented by Vardon et al (2019) within sufficient time the solution will converge. To generate robust measurements, the critical terms include (see Figure A.8):

- · The temperature change needs to be at least 3°C.
- · Measurement time should be between 500 and 1000 seconds.

<!-- image -->

- · At that time after plotting a ln(T-T0) / ln(t ) graph the gradient should be -1 (Figure A.8).
- · The calibration factor is cone specific and needs to be generated from a 2D axisymmetric model for the deployed cone, including the precise location of the temperature sensor within the cone. Prior knowledge of the material being used is needed as the calibration factor changes with the thermal conductivity of the material being used.
- · Accurate calculation of T0, this can be achieved through either ensuring sufficient time for heat dissipation or using the associated equation.

Figure A.7: Thermal cone penetration test (T-CPT) (Vardon et al., 2018)

<!-- image -->

It is important to recognise that the T-CPT approach offshore is very new within the offshore industry, with limited available information to conclude whether that measurements taken in situ would be any more  representative  of  conditions  around  an  installed  cable  than  those  taken  in  the  laboratory.  For instance, there has to be consideration that the pushing of the T-CPT into the seabed may in itself change the thermal properties, via inducing soil volume changes during both the initial penetration phase and the actual heat dissipation test.

Figure A.8: Example of T-CPT for recorded TC of 1.97W/mK (Vardon et al., 2019)

<!-- image -->

<!-- image -->

## Appendix A.2.3 Passive method -correlation with conventional CPT measurements

Standard measurements from CPT data can be used to estimate TC including tip resistance, sleeve friction and pore water pressure. These parameters are all measured in the CPT tests and can be used to estimate soil type and mechanical properties. The acquired data correspond to continuous profiles and input data is typically taken as part of site investigations; hence they represent a potentially cost effective approach.

The primary measurements during a CPT are (i) tip resistance, qc, (ii) sleeve friction, fs, and (iii) pore water pressure, u2. These parameters are measured during continuous penetration of the cone at a standard rate of 20 mm/s. The parameters provide an indirect indicator of the soil mechanical properties. Many correlations exist to estimate parameters such as soil type, and soil strength and unit weight from CPT data (Lunne et al. 1997). Using these correlations, CPT data can be used to estimate porosity and soil type, and thereafter the methods set out in Section 3.2.4 can be applied to estimate TC from porosity and soil type. The approaches to find porosity and soil type are as follows:

- 1. Estimate the soil unit weight, using correlations based on the CPT parameters
- 2. Estimate porosity from unit weight, using an estimated soil grain specific gravity, 𝐺𝑠
- 3. Estimate the soil type and mineralogy based on the CPT parameters

Based on the calculated porosity and estimated soil type and mineralogy, TC can be estimated following the method set out in Section 3.2.4.

Vardon &amp; Peuchen (2021) used a similar approach to assess TC based on CPT parameters, and examined the reliability of this method. Their study provides additional information including simple look-up charts to estimate thermal properties directly from CPT parameters. Their approach is the same as outlined in this report, but with different values assumed for the apparent solid fraction thermal conductivity to link porosity and TC.

The measured CPT parameters are converted to normalised CPT parameters as follows:

𝑄𝑡𝑛 is the normalised cone resistance, calculated as 𝑄𝑡𝑛 = [ (𝑞𝑡 -𝜎 𝑣𝑜 ) 𝑃𝑎 ] / ( 𝑃𝑎 𝜎𝑣𝑜 ′ ) 𝑚 , where 𝑞𝑡 is the corrected cone resistance, 𝜎𝑣𝑜 is the in situ vertical total stress at the cone tip, 𝜎′ 𝑣𝑜 is the in situ vertical effective stress at the cone tip, 𝑃 𝑎 is atmospheric pressure and 𝑚 is a stress exponent related to the soil type.

𝐹𝑅 is the normalised friction ratio, calculated as 𝐹𝑅 = 100 ∙ 𝑓 /𝑞 𝑛 𝑡 where 𝑓 𝑡 is the corrected sleeve friction and 𝑞𝑛 is the net cone resistance, 𝑞𝑛 = 𝑞𝑡 -𝜎𝑣𝑜 .

Robertson &amp; Cabal (2010) provided the following correlation that provide soil bulk unit weight, 𝛾, as the following ratio of the unit weight of water, 𝛾 𝑤 :

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

Subsequently, an alternative formulation was developed by Lengkeek et al. (2018), using a database that included soils with organic content, and so captures the lower unit weight of these soils:

<!-- image -->

Equation A-2

The reference values in this expression that best fit the database of Lengkeek et al. (2018) are:

<!-- image -->

𝛾𝑟𝑒𝑓 = 19 kN/m 3 , 𝑄𝑛,𝑟𝑒𝑓 = 150, 𝐹𝑟,𝑟𝑒𝑓 = 30 and 𝛽 = 0.412

The bulk unit weight of saturated soil is linked to the unit weight of the solid and fluid phases via following relationship:

<!-- formula-not-decoded -->

## Equation A-3

The grain specific gravity is a parameter that varies only slightly between different mineralogies. If it is assumed that 𝐺𝑠 = 2.65, then the Robertson &amp; Cabal (2010) approach can be used to estimate porosity from the CPT parameters as:

<!-- formula-not-decoded -->

In order to estimate TC from porosity, it is necessary to adopt a value of thermal conductivity for the solid grain  fraction, 𝜆𝑠𝑜𝑙𝑖𝑑 .  This  parameter  varies  significantly  between  clays,  sands  and  peat  due  to  their different mineralogical composition. The soil type and the mineralogical composition may be known based  on  the  geological  setting,  lab  testing  or  other  data,  which  supports  estimation  of 𝜆𝑠𝑜𝑙𝑖𝑑 . Alternatively,  the  CPT  parameters  can  be  used  to  estimate  the  soil  type,  via  methods  such  as  the approach outlined by Robertson (2016).

Two similar approaches were set out by Vardon &amp; Peuchen (2021) to identify correlations for TC and volumetric heat capacity for saturated soils. From these relationships theoretical TC correlations can be developed and similar correlations for volumetric heat capacity. Proposed theoretical correlations from standard CPT measurements are shown in Figure A.9. These have been tested at 7 locations from both in situ T-CPT data and needle probe measurements on the specific materials which is recognised as a very small number of samples. There is a level of uncertainty surrounding them, as CPT measurements are influenced by multiple soil properties. There is no strong bias correlating the results but still a high scatter suggesting the initial tests are producing accurate but not precise measurements.

Figure A.9: Correlations for TC and CPT based on Vardon and Peuchen (2021)

<!-- image -->

<!-- image -->

## - References

ASTM  International:  ASTM  C177-19  (2019).  Standard  Test  Method  for  Steady-State  Heat  Flux Measurements  and  Thermal  Transmission  Properties  by Means  of the Guarded-Hot-Plate Apparatus', Annual Book of ASTM Standards, (C), pp. 123.

ASTM International C1044-12. (2012). Standard Practice for Using a Guarded-Hot-Plate Apparatus or Thin-Heater Apparatus in the Single-Sided Mode. ASTM International, West Conshohocken, PA.

ASTM International: D5334 -14 (2014). Standard test method for determination of thermal conductivity of soil and soft rock by thermal needle probe procedure. ASTM International, West  Conshohocken.

Brigaud, F. and Vasseur, G. (1989). 'Mineralogy, porosity and fluid control on thermal conductivity of sedimentary rocks', Geophysical Journal International, 98(3), pp. 525542.

British Standards Institution (2001a). BS EN 12664:2001 Thermal performance of building materials and products -Determination of thermal resistance by means of guarded hot plate and heat flow meter methods -Dry and moist products of medium and low thermal resistance. BSI, London.

British  Standards  Institution  (2015).  BS  EN  ISO  22007 -2:2015  Plastics -Determination  of  thermal conductivity and thermal diffusivity -Part 2: Transient plane heat source (hot disc) method. BSI, London.

British  Standards  Institution:  BS  5930:2015+A1  (2020).  Code  of  Practice  for  Site  Investigation.  BSI, London.

Callender, G. et al. (2021) 'Low computational cost model for convective heat transfer from submarine cables', IEEE Transactions on Power Delivery, 36(2), pp. 760768. doi: 10.1109/TPWRD.2020.2991783.

Clarke, B. G., Agab, A. and Nicholson, D. (2008). 'Model specification to determine thermal conductivity of soils', Proceedings of the Institution of Civil Engineers: Geotechnical Engineering, 161(3), pp. 161168.

Clauser, C., &amp; Huenges, E. (1995). Thermal conductivity of rocks and minerals. Rock physics and phase relations: a handbook of physical constants , 3 , 105-126.

Decagon Devices, Inc. (2011). KD2 Pro Thermal Properties Analyzer: Operator's Manual Version 10

Emeana, C.J., Hughes, T.J., Dix, J.K., Gernon, T.M., Henstock, T.J., Thompson, C.E.L. and Pilgrim, J.A., (2016).  The  thermal  regime  around  buried  submarine  high-voltage  cables.  Geophysical  Journal International, 206(2), pp.1051-1064.

Evenset, G., Klaer, L.E., Kingman, K., vd Thillart, R., Daniela, D., de Vries, G.T. and Dillon, M., (2016). Thermal characterization of seabed along the NordLink cable route -results and comparison of measurement methods. In CIGRE 2016 Conference Proceedings. B1-313.

GCube (2021). Uncharted Waters -Navigating emerging risks and rising claims in global offshore wind. Q4 2021 Report. GCube Insurance.

Gustafsson,  S.  E.  (1991). 'Transient  plane  source  techniques  for  thermal  conductivity  and  thermal diffusivity measurements of solid materials', Review of Scientific Instruments, 62(3), pp. 797804.

<!-- image -->

Horai, K. I. (1971). Thermal conductivity of rock forming minerals. -Journal of geophysical research 76 , (5), 1278-1308.

Hughes T.J., Henstock T.J., Pilgrim J.A., Dix J.K., Gernon T.M. and Thompson C.E.L. (2015a). Effect of sediment properties on the thermal performance of submarine HV cables. IEEE Transactions on Power Delivery 30(6): 2443-2450. doi: 10.1109/TPWRD.2015.2398351.

Hughes, T.J., Henstock, T.J., Pilgrim, J.A., Dix, J.K., Gernon, T.M. and Thompson, C.E.L. (2015b). Thermal Ratings  of  Submarine  HV  Cables  Informed  by  Environmental  Considerations.  Jicable,  Palais  de Congres, Versailles, France (21st-25th Jun, 2015).

Hukseflux  Thermal  Sensors  (2011). 'TP02  Non -Steady-State  Probe  for  Thermal  Conductivity  URL: Measurement'. Measurement -manual v0908, Hukseflux Thermal Sensors, Delft. http://www.hukseflux.com/products/thermalConductivity/tp02.html

IEC 60287-1-1: 2006+A1 (2014). Electric Cables -Calculation of the Current Rating, IEC, Part 1-1 Current rating equations (100% Load factor) and calculation of losses - General.

IEC 60853-2 (2008).Calculation of the cyclic and emergency current rating of cables -Part 2 Cyclic rating of cables greater than 18/30 (36) kV and emergency rating for cables of all voltages.

IEEE 442-2017 (2018). IEEE Guide for Thermal Resistivity Measurements of Soils and Backfill Materials.

International Organization for Standardization, ISO 22475-1:2021 (2021). Geotechnical investigation and testing  -  Sampling  methods  and  groundwater  measurements  -  Part  1:  Technical  principles  for execution', 3, ISO, Geneva .

International Organization for Standardization (1991). ISO 8302:1991 Thermal insulation -Determination of  steady-state  thermal  resistance  and  related  properties -Guarded  hot  plate  apparatus,  ISO, Geneva.

Knutsson, S. (1983). On the thermal conductivity and thermal diffusivity of highly compacted bentonite. SKB Report, Swedish Nuclear Fuel and Waste Management Co., SKB 83 -72, October 1983.

Lengkeek H.J., de Greef J. &amp; Joosten S. (2018). CPT based unit weight estimation extended to soft organic  soils  and  peat.  Cone  Penetration  Testing  2018  -  Proceedings  of  the  4th  International Symposium on Cone Penetration Testing, CPT 2018, , pp. 389-394.

Low, J. (2016). Thermal conductivity of soils for energy foundation applications (Doctoral dissertation, University of Southampton).

Low, J.  E.  et  al.  (2015). 'A  comparison  of  laboratory  and in  situ  methods  to  determine  soil  thermal conductivity for energy foundations and other ground heat exchanger applications', Acta Geotechnica, 10(2), pp. 209 -218.

Low, J. E., Loveridge, F. A. and Powrie, W. (2017). 'Error  analysis of  the  thermal  cell  for soil  thermal conductivity measurement',  Proceedings  of  the  Institution of Civil Engineers: Geotechnical Engineering, 170(3), pp. 191 -200.

Lunne, T., Robertson, P.K. and Powell, J.J.M. (1997). Cone Penetration Testing in Geotechnical Practice. Blackie Academic &amp; Professional, London, 312 p.

Midttømme, K.,  Roaldset,  E.,  &amp;  Aagaard,  P.  (1998).  Thermal  conductivity  of  selected  claystones  and mudstones from England. Clay Minerals 33 , (1), 131-145.

<!-- image -->

Pilgrim, J.A., Lewin, P.L., Larsen, S.T., Waite, F. and Payne, D. (2012). Rating of cables in unfilled surface troughs. IEEE transactions on power delivery, 27(2), pp.993-1001.

Robertson  P.K.  (2016).  Cone  penetration  test  (CPT)-based  soil  behaviour  type  (SBT)  classification system -an update. Canadian Geotechnical J. 53: 1910 -1927 dx.doi.org/10.1139/cgj-2016-0044.

Vardon, P.J., Baltoukas, D. and Peuchen, J., (2018). June. Thermal Cone Penetration Test (T-CPT). In 4 th International Symposium on Cone Penetration testing. CRC Press. 649-655.

Vardon,  P.J.,  Baltoukas,  D.  and  Peuchen,  J.,  (2019).  Interpreting  and  validating  the  thermal  cone penetration test (T-CPT). Géotechnique, 69(7), pp.580-592.

Vardon, P.J. &amp; Peuchen, J. (2021). CPT correlations for thermal properties of soils. Acta Geotech. 16, 635 -646.

Vos,  B.  H.  (1956). 'Measurements  of  thermal  conductivity  by  a  non -steadystate  method',  Applied Scientific Research, Section A, 5(6), pp. 425 -438.

SOIL THERMAL PROPERTIES FOR SUBSEA CABLE DESIGN

BEST PRACTICE GUIDE

<!-- image -->

The Carbon Trust is a company limited by guarantee and registered in England and Wales under Company number 4190230 with its Registered Office at: Level 5, Arbor, 255 Blackfriars Road, London, England, SE1 9AX. © The Carbon Trust 2024. All rights reserved. Published in the UK: 2024

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->