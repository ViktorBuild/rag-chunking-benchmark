---
document_id: doe_ca_tip_5
title: "Compressed Air Tip Sheet #5: Minimize Pressure Drop in Compressed Air Distribution"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip05_minimize_pressure_drop.pdf"
tables_detected: 2
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #5 • August 2004

## Suggested Actions

- ·  Review compressed air applications and determine the appropriate level of air quality they require.
- ·  Review compressed air treatment equipment to ensure that it is performing adequately.
- ·  Inspect compressor inlet air intakes to make sure they are clear of potential contaminants.
- ·  Consider a professional compressed air system evaluation to validate air quality needs.
- ·  Refer to Tip Sheet #4 'Analyzing Your Compressed Air System'.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies Program and CAC:

Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Determining the Right Air Quality for Your Compressed Air System

Knowing the proper air quality level required for successful production is an important factor in containing compressed air energy and other operating costs, because higher quality air is more expensive to produce. Higher quality air requires additional air treatment equipment, which increases capital costs as well as energy consumption and maintenance needs. The quality of air produced should be guided by the degree of dryness and filtration needed and by the minimum acceptable contaminant level to the end uses.

| Level of Air Quality   | Applications                                                                                     |
|------------------------|--------------------------------------------------------------------------------------------------|
| Plant Air              | Air tools, general plant air                                                                     |
| Instrument Air         | Laboratories, paint spraying, powder coating, climate control                                    |
| Process Air            | Food and pharmaceutical process air, electronics                                                 |
| Breathing Air          | Hospital air systems, diving tank refill stations, respirators for cleaning and/or grit blasting |

## Compressed Air Contaminants

Compressed air contaminants can be in the form of solids, liquids, or vapors. Contaminants can enter a compressed air system at the compressor intake, or can be introduced into the air stream by the system itself.

Air quality class is determined by the maximum particle size, pressure dewpoint, and maximum oil content allowed. For more information, see ISO 8573-1 Compressed Air Quality Classes in the Compressed Air System Best Practices Manual. (See references in sidebar).

One of the main factors in determining air quality is whether lubricant-free air is required. Lubricant-free air can be produced either by using lubricant-free compressors, or with lubricant-injected compressors and additional air treatment equipment. The following factors can help one decide whether lubricant-free or lubricant-injected air is appropriate:

- ·  If only one end use requires lubricant-free air, only the air supply to it should be treated to obtain the necessary air quality. Alternatively, it may be supplied by its own lubricant-free compressor. If the end uses in a plant require different levels of air quality, it may be advisable to divide the plant into different sections so that air treatment equipment that produces higher quality air is dedicated to the end uses that require the higher level of compressed air purification.

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

- ·  Lubricant-free rotary screw and reciprocating compressors usually have higher initial costs, lower efficiency, and higher maintenance costs than lubricantinjected compressors. However, the additional separation, filtration, and drying equipment required by lubricant-injected compressors will generally cause some reduction in system efficiency, particularly if the system is not properly maintained.

<!-- image -->

Careful consideration should be given to the specifi  c end use for the lubricant-free air, including the risks and costs associated with product contamination before selecting a lubricant-free or lubricant-injected compressor. Centrifugal compressors also offer an alternative for plants whose end uses require lubricant-free air.

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.