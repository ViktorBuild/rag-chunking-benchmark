---
document_id: doe_steam_tip_8
title: "Steam Tip Sheet #8: Return Condensate to the Boiler"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_steam_tip08_return_condensate.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

Energy Tips: STEAM

## Return Condensate to the Boiler

When steam transfers its heat in a manufacturing process, heat exchanger, or heating coil, it reverts to a liquid phase called condensate. An attractive method of improving your power plant's energy efficiency is to increase the condensate return to the boiler.

Returning hot condensate to the boiler makes sense for several reasons. As more condensate is returned, less make-up water is required, saving fuel, makeup water, and chemicals and treatment costs. Less condensate discharged into a sewer system reduces disposal costs. Return of high purity condensate also reduces energy losses due to boiler blowdown. Significant fuel savings occur as most returned condensate is relatively hot (130°F to 225°F), reducing the amount of cold makeup water (50°F to 60°F) that must be heated.

A simple calculation indicates that energy in the condensate can be more than 10% of the total steam energy content of a typical system. The graph shows the heat remaining in the condensate at various condensate temperatures, for a steam system operating at 100 pounds per-square-inch-gauge (psig), with makeup water at 55°F.

<!-- image -->

## Example

Consider a steam system that returns an additional 10,000 pounds per hour (lb/ hr) of condensate at 180°F after distribution modifications. Assume this system operates 8,000 hours annually with an average boiler efficiency of 80%, and makeup water temperature of 55°F. The water and sewage costs for the plant are

S

team Tip Sheet #8

## Suggested Actions

Reduce operating costs through maximizing the return of hot condensate to the boiler. Consider the following actions:

- ■ ■ If a condensate return system is absent, estimate the cost of a condensate return and treatment system (as necessary) and install one if economically justified.
- ■ ■ Monitor and repair steam distribution and condensate return system leaks.
- ■ ■ Insulate condensate return system piping to conserve heat and protect personnel against burns.
- ■ ■ Allow data to drive your decision making.

$0.002 per gallon ($/gal), and the water treatment cost is $0.002/gal. The fuel cost is $8.00 per million Btu ($8.00/MMBtu). Assuming a 12% flash steam loss, * calculate overall savings.

Annual Water, Sewage, &amp; Chemicals Savings

- =  (1 - Flash Steam Fraction) x (Condensate Load, lb/hr) x Annual Operating Hours x (Total Water Costs, $/gal)/ (Water Density, lb/gal)
- =  (1 - 0.12) x 10,000 x 8,000 x $0.004

8.34

- =  $33,760

## Annual Fuel Savings

- =  (1 - Flash Steam Fraction) x (Condensate Load, lb/hr) x Annual Operating Hours x (Makeup Water Temperature Rise, °F) x (Fuel Cost, $/MMBtu) x (Heat Capacity of Makeup Water, Btu/lb-°F)/ (Boiler Efficiency x 10  Btu/MMBtu) 6

=  (1 - 0.12) x 10,000 x 8,000 x (180 - 55) x $8.00 x 1 (0.80 x 10 6 )

- =  $88,000

Total Annual Savings Due to Return of an Additional 10,000 lb/hr of Condensate

=  $33,760 + $88,000

=   $121,760

## Condensate Recovery Produces Savings

A large specialty paper plant reduced its boiler makeup water rate from about 35% of steam production to between 14% and 20% by returning additional condensate. Annual savings added up to more than $300,000.

Adapted from an Energy TIPS fact sheet that was originally published by the Industrial Energy Extension Service of Georgia Tech.

*When saturated condensate is reduced to some lower pressure, some condensate flashes off to steam again. This amount is the flash steam loss.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3410  •  January 2012

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.