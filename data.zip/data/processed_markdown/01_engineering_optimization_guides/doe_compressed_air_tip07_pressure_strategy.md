---
document_id: doe_ca_tip_7
title: "Compressed Air Tip Sheet #7: Compressed Air System Pressure Strategy"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip07_pressure_strategy.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #7 • August 2004

## Suggested Actions

- ·  Understand your system requirements by developing a pressure and a demand profile before investing in additional controls.
- ·  Identify end uses that are affected by pressure problems.
- ·  Check existing equipment to ensure that it is in good operating condition.
- ·  Eliminate inappropriate uses, fix major leaks, and implement a leak management program.
- ·  Once these actions have been taken, work with a compressed air specialist to match your control strategy to your actual system needs.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies

Program and CAC: Improving Compressed Air System

Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Compressed Air System Control Strategies

Improving and maintaining compressed air system performance requires not only addressing individual components, but also analyzing both the supply and demand sides of the system and how they interact, especially during periods of peak demand. This practice is often referred to as taking a systems approach because the focus is shifted away from components to total system performance.

## Matching Supply with Demand

With compressed air systems, system dynamics (changes in demand over time) are especially important. Using controls, storage, and demand management to effectively design a system that meets peak requirements but also operates efficiently at part-load is key to a high performance compressed air system. In many systems, compressor controls are not coordinated to meet the demand requirements, which can result in compressors operating in conflict with each other, short-cycling, or blowing off-all signs of inefficient system operation.

## Individual Compressor Controls

Over the years, compressor manufacturers have developed a number of different types of control strategies. Controls such as start/stop and load/unload respond to reductions in air demand by turning the compressor off or unloading it so that it does not deliver air for periods of time. Modulating inlet and multi-step controls allow the compressor to operate at part-load and deliver a reduced amount of air during periods of reduced demand. Variable speed controls reduce the speed of the compressor in low demand periods. Compressors running at part-load are generally less efficient than when they are run at full-load.

## Multiple Compressor Controls

Systems with multiple compressors should use more sophisticated controls to orchestrate compressor operation and air delivery to the system. Network controls use the on-board compressor controls' microprocessors linked together to form a chain of communication that makes decisions to stop/start, load/unload, modulate, and vary displacement and speed. Usually, one compressor assumes the lead role with the others being subordinate to the commands from this compressor. System master controls coordinate all of the functions necessary to optimize compressed air as a utility. System master controls have many functional capabilities, including the ability to monitor and control all components in the system, as well as trending data, to enhance maintenance functions and minimize costs of operation. Most multiple compressor controls operate the appropriate number of compressors at full-load and have one compressor trimming (running at part-load) to match supply with demand.

## Pressure/Flow Controllers

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

Pressure/Flow Controllers (P/FC) are system pressure controls that can be used in conjunction with the individual and multiple compressor controls described above. A P/FC does not directly control a compressor and is generally not part of a

<!-- image -->

compressor package. A P/FC is a device that serves to separate the supply side of a compressor system from the demand side, and requires the use of storage.

Controlled storage can be used to address intermittent loads, which can affect system pressure and reliability. The goal is to deliver compressed air at the lowest stable pressure to the main plant distribution system and to support transient events as much as possible with stored compressed air. In general, a highly variable demand load will require a more sophisticated control strategy to maintain stable system pressure than a consistent, steady demand load.

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.

DOE/GO-102004-1930 August 2004 Compressed Air Tip Sheet #7