---
document_id: doe_ca_tip_3
title: "Compressed Air Tip Sheet #3: Stop Leaks in Your Compressed Air System"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip03_leak_prevention.pdf"
tables_detected: 7
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #3 • August 2004

## Suggested Actions

- ·  Fixing leaks once is not enough. Incorporate a leak prevention program into operations at your facility. It should include identification and tagging, tracking, repair, verification, and employee involvement. Set a reasonable target for cost-effective leak reduction-5%-10% of total system flow is typical for industrial facilities.
- ·  Once leaks are repaired, re-evaluate your compressed air system supply. Work with a compressed air systems specialist to adjust compressor controls. To maximize energy savings, compressor run time must be reduced to match the reduced demand.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies Program and CAC:

Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Minimize Compressed Air Leaks

Leaks are a significant source of wasted energy in a compressed air system, often wasting as much as 20%-30% of the compressor's output. Compressed air leaks can also contribute to problems with system operations, including:

- ·  Fluctuating system pressure, which can cause air tools and other air-operated equipment to function less efficiently, possibly affecting production
- •  Excess compressor capacity, resulting in higher than necessary costs
- ·  Decreased service life and increased maintenance of supply equipment (including the compressor package) due to unnecessary cycling and increased run time.

Although leaks can occur in any part of the system, the most common problem areas are couplings, hoses, tubes, fittings, pipe joints, quick disconnects, FRLs (filter, regulator, and lubricator), condensate traps, valves, flanges, packings, thread sealants, and point-of-use devices. Leakage rates are a function of the supply pressure in an uncontrolled system and increase with higher system pressures. Leakage rates identified in cubic feet per minute (cfm) are also proportional to the square of the orifice diameter. See table below.

| Leakage rates a (cfm) for different supply pressures and approximately equivalent orifice sizes b   | Leakage rates a (cfm) for different supply pressures and approximately equivalent orifice sizes b   | Leakage rates a (cfm) for different supply pressures and approximately equivalent orifice sizes b   | Leakage rates a (cfm) for different supply pressures and approximately equivalent orifice sizes b   | Leakage rates a (cfm) for different supply pressures and approximately equivalent orifice sizes b   | Leakage rates a (cfm) for different supply pressures and approximately equivalent orifice sizes b   | Leakage rates a (cfm) for different supply pressures and approximately equivalent orifice sizes b   |
|-----------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|
| Pressure (psig)                                                                                     | Orifice Diameter (inches)                                                                           | Orifice Diameter (inches)                                                                           | Orifice Diameter (inches)                                                                           | Orifice Diameter (inches)                                                                           | Orifice Diameter (inches)                                                                           | Orifice Diameter (inches)                                                                           |
| Pressure (psig)                                                                                     | 1/64                                                                                                | 1/32                                                                                                | 1/16                                                                                                | 1/8                                                                                                 | 1/4                                                                                                 | 3/8                                                                                                 |
| 70                                                                                                  | 0.29                                                                                                | 1.16                                                                                                | 4.66                                                                                                | 18.62                                                                                               | 74.4                                                                                                | 167.8                                                                                               |
| 80                                                                                                  | 0.32                                                                                                | 1.26                                                                                                | 5.24                                                                                                | 20.76                                                                                               | 83.1                                                                                                | 187.2                                                                                               |
| 90                                                                                                  | 0.36                                                                                                | 1.46                                                                                                | 5.72                                                                                                | 23.10                                                                                               | 92                                                                                                  | 206.6                                                                                               |
| 100                                                                                                 | 0.40                                                                                                | 1.55                                                                                                | 6.31                                                                                                | 25.22                                                                                               | 100.9                                                                                               | 227                                                                                                 |
| 125                                                                                                 | 0.48                                                                                                | 1.94                                                                                                | 7.66                                                                                                | 30.65                                                                                               | 122.2                                                                                               | 275.5                                                                                               |

- a For well-rounded orifices, values should be multiplied by 0.97 and by 0.61 for sharp ones.
- b Used with permission from Fundamentals of Compressed Air Systems Training offered by the Compressed Air Challenge ® .

## Leak Detection

The best way to detect leaks is to use an ultrasonic acoustic detector, which can recognize high frequency hissing sounds associated with air leaks. These portable units are very easy to use. Costs and sensitivities vary, so test before you buy. A simpler method is to apply soapy water with a paintbrush to suspect areas. Although reliable, this method can be time consuming and messy.

## Example

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

A chemical plant undertook a leak-prevention program following a compressed air audit at their facility. Leaks, approximately equivalent to different orifice sizes, were found as follows: 100 leaks of 1/32' at 90 pounds per square inch gauge (psig), 50 leaks of 1/16' at 90 psig, and 10 leaks of 1/4' at 100 psig. Calculate the annual cost

<!-- image -->

savings if these leaks were eliminated. Assume 7,000 annual operating hours, an aggregate electric rate of $0.05 kilowatt-hour (kWh), and compressed air generation requirement of approximately 18 kilowatts (kW)/100 cfm.

Cost savings = # of leaks x leakage rate (cfm) x kW/cfm x # of hours x $/kWh

Using values of the leakage rates from the above table and assuming sharp-edged orifi  ces:

Cost savings from 1/32' leaks = 100 x 1.46 x 0.61 x 0.18 x 7,000 x 0.05 = $5,611 Cost savings from 1/16' leaks = 50 x 5.72 x 0.61 x 0.18 x 7,000 x 0.05 = $10,991

Cost savings from 1/4' leaks = 10 x 100.9 x 0.61 x 0.18 x 7,000 x 0.05 = $38,776

## Total cost savings from eliminating these leaks = $57,069

Note that the savings from the elimination of just 10 leaks of 1/4' account for almost 70% of the overall savings. As leaks are identifi  ed, it is important to prioritize them and fi  x the largest ones fi  rst.

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

• Aluminum

• Forest Products

• Metal Casting

• Petroleum

• Chemicals

• Glass

• Mining

• Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.

DOE/GO-102004-1964 Revised August 2004 Compressed Air Tip Sheet #3