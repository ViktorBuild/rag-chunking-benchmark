---
document_id: doe_ca_tip_4
title: "Compressed Air Tip Sheet #4: Effect of Intake Air on Compressor Performance"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip04_intake_air_temperature.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #4 • August 2004

## Suggested Actions

- ·  Take a training class on system optimization or seek the services of a compressed air system professional who understands these techniques.
- •  Follow the seven-step action plan.
- ·  Consider implementing a leakdetection/repair program using an ultrasonic leak detector. An effective leak-repair program must include a review of system pressure and controls in order to realize energy savings.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies Program and CAC:

Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Analyzing Your Compressed Air System

The first step in analyzing a compressed air system is to determine your compressed air needs. Compressed air needs are defined by the air quality and quantity required by the end uses in your plant. Assessing these needs carefully and understanding the difference between air quality and air quantity will ensure that a compressed air system is configured properly. Determining your pressure and demand load requirements are also important steps in analyzing your compressed air system.

## Air Quality

Air quality is determined by the air dryness and contaminant level required by end uses. Learn the actual dryness level needed and the maximum contaminant level allowed for reliable production. Overtreating air beyond the required dryness and allowable contaminant level wastes money and energy.

## Air Quantity

The required compressed air system volume can be determined by summing the requirements of your compressed air applications and process operations (taking into account load factors) and the duration of such volumes by those applications. The total air requirement is not the sum of the maximum requirements for each tool and process, but the sum of the average air consumption of each.

## Pressure Requirements

The minimum required discharge pressure level must take into account the different pressure ratings of compressed air applications and processes as well as the pressure drops from components in the system. Too often, low or fluctuating pressure at end uses is misdiagnosed as not enough discharge pressure.

Pressure drop is a term used to characterize the reduction in air pressure from the compressor discharge to the actual point of end use. Pressure drop occurs as compressed air travels through the treatment and distribution system. Excessive pressure drop will result in poor system performance and excessive energy consumption. A pressure profile is a series of measurements of compressed air pressure at different points in the system, and allows identification of system components that are causing excessive pressure drop.

## Demand Load Requirements

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

Another key to properly designing and operating a compressed air system is analyzing a plant's compressed air requirements over time, or load profile. The variation of demand for air over time is a major consideration in system design. Plants with wide variations in air demand need a system that operates efficiently under part-load. In such a case, multiple compressors with sequencing controls may provide more economical operation. Plants with a flatter load profile can use simpler control strategies.

<!-- image -->

## Getting Started

The following is a seven-step action plan from CAC Fundamentals of Compressed Air Systems to analyze and improve your compressed air system:

- 1.  Develop a basic block diagram of your compressed air system.
- 2.  Measure your baseline (kW, pressure profi  le, demand profi  le, and leak load) and calculate energy use and costs.
- 3.  Work with your compressed air system specialist to implement an appropriate compressor control strategy.
- 4.  Once controls are adjusted, remeasure to get more accurate readings of kW and pressures, and to determine leak load. Recalculate energy use and costs.
- 5.  Walk through to check for obvious preventive maintenance items and other opportunities to reduce costs and improve performance.
- 6.  Identify and fi  x leaks and correct inappropriate uses - know costs, re-measure, and adjust controls as above.
- 7.  Begin implementation of continuous improvement programs.

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.