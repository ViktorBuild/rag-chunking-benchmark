---
document_id: doe_ca_tip_2
title: "Compressed Air Tip Sheet #2: Eliminate Inappropriate Uses of Compressed Air"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip02_inappropriate_uses.pdf"
tables_detected: 8
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #2 • August 2004

## Suggested Actions

- ·  Walk through your plant and identify all compressed air uses and, if possible, the flow and pressure requirements of each use.
- ·  Take steps to eliminate any inappropriate uses. Consult with a compressed air systems specialist to see if other equipment (blowers, mechanical or hydraulic devices) will be more cost-effective for those applications.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies Program and CAC:

Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Eliminate Inappropriate Uses of Compressed Air

Compressed air generation is one of the most expensive utilities in an industrial facility. When used wisely, compressed air can provide a safe and reliable source of power to key industrial processes. Users should always consider other cost-effective forms of power to accomplish the required tasks and eliminate unproductive demands. Inappropriate uses of compressed air include any application that can be done more effectively or more efficiently by a method other than compressed air. The table below provides some uses of compressed air that may be inappropriate and suggests alternative ways to perform these tasks.

| Potentially Inappropriate Uses                                        | Suggested Alternatives/Actions                                                 |
|-----------------------------------------------------------------------|--------------------------------------------------------------------------------|
| Clean-up, Drying, Process cooling                                     | Low-pressure blowers, electric fans, brooms, nozzles                           |
| Sparging                                                              | Low-pressure blowers and mixers                                                |
| Aspirating, Atomizing                                                 | Low-pressure blowers                                                           |
| Padding                                                               | Low to medium-pressure blowers                                                 |
| Vacuum generator                                                      | Dedicated vacuum pump or central vacuum system                                 |
| Personnel cooling                                                     | Electric fans                                                                  |
| Open-tube, compressed air-operated vortex coolers without thermostats | Air-to-air heat exchanger or air conditioner, add thermostats to vortex cooler |
| Air motor-driven mixer                                                | Electric motor-driven mixer                                                    |
| Air-operated diaphragm pumps                                          | Proper regulator and speed control; electric pump                              |
| Idle equipment*                                                       | Put an air-stop valve at the compressed air inlet                              |
| Abandoned equipment**                                                 | Disconnect air supply to equipment                                             |

- *Equipment that is temporarily not in use during the production cycle.

**Equipment that is no longer in use either due to a process change or malfunction.

## Example

The table below shows inappropriate uses of compressed air in an automobile assembly plant. The plant took several action steps identified in the table to eliminate or reduce these inappropriate uses. Peak flow is identified in cubic feet per minute (cfm).

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

| Operation                | Original Peak Flow (cfm)   | Number of Hours   | Action Taken                     | Revised Peak Flow (cfm)   | Peak Flow Reduction (cfm)   |
|--------------------------|----------------------------|-------------------|----------------------------------|---------------------------|-----------------------------|
| Open hand-held blow guns | 200                        | 6,500             | Installed nozzles                | 50                        | 150                         |
| Vacuum generator         | 1,000                      | 5,000             | Motor-driven vacuum pump         | 0                         | 1,000                       |
| Personnel cooling        | 800                        | 3,500             | Used fans                        | 0                         | 800                         |
| Pneumatic actuators      | 750                        | 3,500             | Replaced with electric actuators | 0                         | 750                         |
| Total CFM reduction:     |                            |                   |                                  |                           | 2,700                       |

<!-- image -->

The plant audit showed that the energy used to generate the compressed air averages 18 kW/100 cfm. The aggregate electric rate at the plant is $0.05 per kWh.

Annual savings

= [kW per cfm] x [cfm savings] x [# of hours] x [$ per kWh] = 18/100 x [(150 x 6,500) + (1,000 x 5,000) + (800 x 3,500) + (750 x 3,500)] x $0.05

- = $102,600

## Net savings:

Calculate electric energy costs for the motor-driven vacuum pump, fans, and actuators, and subtract these costs from the annual savings calculated to determine the net savings. Note that there will be a one-time cost of installation for the added equipment.

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.

DOE/GO-102004-1963 Revised August 2004 Compressed Air Tip Sheet #2