---
document_id: ct_floating_wind_jip_summary
title: "Floating Wind Joint Industry Programme: Technical Summary Report"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "Carbon Trust (UK)"
year: 2025
original_file: "carbon_trust_floating_wind_technical_summary.pdf"
tables_detected: 27
converted_with: "Docling v2.32 (TableFormer)"
---

FLOATING WIND JOINT INDUSTRY PROGRAMME (JIP)

## Floating Wind JIP Stage 3 Phase I Summary report

July 2025

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## INTRODUCTION

## About the report

The Floating Wind JIP is the Carbon Trust's collaborative R&amp;D programme, dedicated to overcoming technological challenges and advancing the commercialisation of floating offshore wind. This summary report provides a high level overview of the eight key research projects that have been carried out between 2022 and 2025. This report was delivered as part of Phase I of the Floating Wind JIP Programme, which was a partnership between the Carbon Trust and 17 offshore wind developers.

## Acknowledgments

This summary report has been produced by the Carbon Trust, with specific sections informed by projects delivered by the following external technical contractors:

- · Dynamic Cable Condition Monitoring: Ove Arup &amp; Partners in collaboration with the University of Exeter
- · Maximum Operating Sea-state Evaluation: AMOG, Sowento, London Marine Consultants (LMC )
- · Commercial Scale Mooring Integrity Management: AMOG, ABS, SOFEC, Skowronnek &amp; Bechnak
- · Prevention of Marine Growth: Endures, KENT
- · Large Static Pitch Angles: Fazer Nash Consultancy
- · Wet Storage and Quick Connectors of Dynamic Cables: 2H Offshore Engineering
- · Guidance for Dynamic Cables: 2H Offshore Engineering, Vekta
- · Power Curve Validation: Technical University of Denmark (DTU)

The Carbon Trust wrote this report based on an impartial analysis of primary and secondary sources, including expert interviews. The Carbon Trust would like to thank everyone that has contributed their time and expertise during the preparation and completion of this report.

Special thanks goes to: MeyGen PLC, Cambridge Marine Ltd, Codan Forsikring A/S, Viper Innovations Ltd, Sonardyne, FibrisTerre, Synaptec Ltd, FEBUS Optics, FBGS, Indeximate Ltd, Ocean Information Services Ltd, NKT A/S, Proserv, Luna Innovations, Shell, Japan Marine United, PelaStar, Glosten, Siemens Gamesa Renewable Energy, General Electric, Aker Solutions, Axess Group, Baker Hughes, Balltec Engineered Solutions, Balmoral Comtec, Benestad, CRP Subsea, DTI Deepsea Technologies, Hellenic Cables, Oceaneering, Apollo, Orient Cable, Principle Power, Quoceant, Siemens, Flexible Engineered Solutions, Polytech, SCM, Ditrel, Encomara, Saipem, Floating Wind Power Plant, Gusto MSC, Olav Olsen, BW Ideol, JDR, SINTEF, Marin, Aurora Offshore Engineering, Bureau Veritas, AMOG, University of Aberdeen, University of Nantes, Scottish Association for Marine Science, Fugro, BP, DNV, Bekaert, FlexiClean, Ming Yang Smart Energy Group Limited, Stiesdal Offshore, Deutsche WindGuard, Movelaser, ZX LiDARs, Vaisala.

Cover image courtesy of Alistair Morris, taken at Hywind Scotland

<!-- image -->

<!-- image -->

## Who we are

Our mission is to accelerate the move to a decarbonised future. We are your expert guide to turn your climate ambition into impact.

We have been climate pioneers for more than 20 years, partnering with leading businesses, governments and financial institutions to drive positive climate action. To date, our 400 experts globally have helped set 200+ science-based targets and guided 3,000+ organisations and cities across five continents on their route to Net Zero.

## Authors

## Sam Strivens

Senior Manager, Carbon Trust sam.strivens@carbontrust.com

## Alistar Morris

Manager, Carbon Trust alistair.morris@carbontrust.com

Karolina Zieba

Associate, Carbon Trust karolina.zieba@carbontrust.com

## Mary Harvey

Manager, Carbon Trust mary.harvey@carbontrust.com

Chapters 1-8 are reproduced from original reports authored by:

## Dynamic cable condition monitoring

George Walker

Associate Director, Arup

Emily Walport

Senior Engineer, Arup

Dr Philip Thies

Progressor of Renewable Energy, University of Exter

Dr Ajit Pillai

Senior Lecturer/Royal Academy of Engineering Research Fellow, University of Exeter

## Roman Svoma

Director, Powersure Technology Ltd.

## Fabrication, infrastructure and logistics: Arup

Oliver Davey Senior Maritime Engineer Arup

## Maximum operating sea-state evaluation

## Jack MacDonald

Senior Engineer, AMOG Consulting

Frank Lemmer

Director, Sowento

Danai Skandali

Senior Engineer, Sowento

Guidance for dynamic cables

Luiza Ferreira

Principal Engineer, 2H Offshore

Wet storage and quick connectors for dynamic cables

Luiza Ferreira

Principal Engineer, 2H Offshore

John Tapley

Senior Principal Engineer, 2H Offshore

## Luisa Amorim

Manager, Carbon Trust luisa.amorim@carbontrust.com

## Michael Archer

Associate, Carbon Trust michael.archer@carbontrust.com

## Arturo Andersen Chinbuah

Senior Associate, the Carbon Trust arturo.andersen@carbontrust.com

## Large static pitch angles

## Jonathan Samson

Group Leader, Fazer-Nash

## William Terry

Senior Consultant, Fazer-Nash

## Commercial scale mooring integrity management

Claire Lazarides

Senior Engineer - Maritime Engineering, Amog

Chris Carra

Director - Offshore Energy, Amog

## John Gumley

Principal Engineer &amp; Team Lead - Maritime Engineering, Among

<!-- image -->

## Prevention of marine growth

## Maria Salta

Project Manager/Senior Researcher, Endures

## Nanni Noël-Hermes

Senior Researcher, Endures

## Ryan Abela

Naval Architect, KENT

## Power curve validation

Nikolas Angelou

Senior Researcher, DTU

Mathieu Nicolas

Development Engineer, DTU

Alan Wai Hou Lio

Associate Professor, DTU

Paula Gómez

Head of Section, DTU

<!-- image -->

## Contents

| Introduction ..............................................................................................................................1                                                                                                                |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| About the report.......................................................................................................................1                                                                                                                    |
| Acknowledgments ...................................................................................................................1                                                                                                                        |
| Who we are ...............................................................................................................................2                                                                                                                 |
| Figures.......................................................................................................................................6                                                                                                             |
| Abbreviations ...........................................................................................................................7                                                                                                                  |
| Foreword...................................................................................................................................9                                                                                                                |
| Floating wind JIP....................................................................................................................11                                                                                                                     |
| About the Floating Wind JIP.................................................................................................11                                                                                                                              |
| Evolution of the Floating Wind JIP ......................................................................................11                                                                                                                                 |
| Objectives of the Floating Wind JIP ....................................................................................12                                                                                                                                  |
| Floating Wind JIP: Stage 3 .......................................................................................... 12                                                                                                                                    |
| The Floating Wind advisory group............................................................................. 13                                                                                                                                            |
| Stage 3 Phase I Projects .......................................................................................................14                                                                                                                          |
| 1. Dynamic cable condition monitoring ..............................................................................14                                                                                                                                      |
| 1.1. Project overview.................................................................................................... 14                                                                                                                                |
| 1.2. Key findings ........................................................................................................... 15                                                                                                                            |
| 1.3. Industry needs/innovations.................................................................................. 18                                                                                                                                        |
| 2. Maximum operating sea-state evaluation.......................................................................20                                                                                                                                          |
| 2.1. Project overview.................................................................................................... 20                                                                                                                                |
| 2.2. Key findings ........................................................................................................... 22                                                                                                                            |
| 2.3. Industry needs/innovations.................................................................................. 25                                                                                                                                        |
| 3. Commercial scale mooring integrity management........................................................27                                                                                                                                                  |
| 3.1. Project overview.................................................................................................... 27                                                                                                                                |
| 3.2. Key findings ........................................................................................................... 31                                                                                                                            |
| Appendix: MIM framework approach details ......................................................................37                                                                                                                                           |
| 4. Prevention of marine growth............................................................................................40                                                                                                                                |
| 4.1. Project overview.................................................................................................... 40                                                                                                                                |
| 4.3. Key findings ........................................................................................................... 43                                                                                                                            |
| 4.4. Industry needs/innovations.................................................................................. 44                                                                                                                                        |
| 5. Large static pitch angles...................................................................................................46 5.1. Project overview.................................................................................................... |
| 5.3. Industry needs/innovations.................................................................................. 52                                                                                                                                        |

<!-- image -->

<!-- image -->

| 6. Wet storage and quick connectors of dynamic cables.................................................54                           |
|------------------------------------------------------------------------------------------------------------------------------------|
| 6.1. Project overview.................................................................................................... 54       |
| 6.2. Key findings ........................................................................................................... 57   |
| 6.3. Industry needs/innovations.................................................................................. 60               |
| 7. Guidance for dynamic cables...........................................................................................62        |
| 7.1. Project overview.................................................................................................... 62       |
| 7.2. Key findings ........................................................................................................... 63   |
| 7.3. Industry needs/innovations.................................................................................. 68               |
| 8. Power curve validation......................................................................................................70  |
| 8.1. Project overview.................................................................................................... 70       |
| 8.2. Key findings ........................................................................................................... 72   |
| 8.3. Industry needs/innovations.................................................................................. 73               |
| Stage 3 Phase II Projects ......................................................................................................75 |
| 9. Floating Wind JIP Stage 3.................................................................................................75    |
| 9.1. Stage 3 programme objectives............................................................................ 75                   |
| 9.2. Stage 3 Phase II programme activity .................................................................. 77                     |

<!-- image -->

## Figures

| Figure 1. Balanced scorecard results for the Developer and Insurer user groups. ......17                                                                                                                                                                                                                                                                                                                                                                    |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Figure 2. MOSS-induced Load Effects ................................................................................23                                                                                                                                                                                                                                                                                                                                      |
| Figure 3. MOSS During the Design Process.......................................................................24                                                                                                                                                                                                                                                                                                                                           |
| Figure 4. MOSS optimisation by including windspeed dependence. Figure modified from Haselsteiner, A. F., Frieling, M., Mackay, E., Sander, A., & Thoben, K.-D. (2021) ..........26                                                                                                                                                                                                                                                                          |
| Figure 5. Assumed Floating Offshore Wind Farm Layout ................................................29                                                                                                                                                                                                                                                                                                                                                     |
| Figure 6. Inspection Task Definition Methodology............................................................38                                                                                                                                                                                                                                                                                                                                              |
| Figure 7. Wind Farm Clustering Layers...............................................................................38                                                                                                                                                                                                                                                                                                                                      |
| Figure 8. Effect of biofouling on man-made structures exposed to seawater environment............................................................................................................................42                                                                                                                                                                                                                                         |
| Figure 9. Trends on foundation mass, tower mass and AEP as a function of increasing mean static pitch angle. ........................................................................................................49                                                                                                                                                                                                                                     |
| Figure 10. a) Total variation of AEP with LSPA as a percentage change with respect to the fixed case. Presented for each farm layout. b) Total variation of AEP with LSPA as a percentage change with respect to the baseline floating case (at a mean static pitch of 3 degrees), for each farm layout. The per-turbine AEP results from WP2 are also plotted (i.e. the summation of single turbine performance exclusive of wake effects)..............50 |
| Figure 11. Simplified illustrations of a) daisy chain array; b) fishbone configuration; and c) star configuration. OSS = offshore substation. Sources: WFO, information from Siemens Subsea.....................................................................................................................57                                                                                                                                          |
| Figure 12: Colour code key for the constituent technology parts described in Table 2.58                                                                                                                                                                                                                                                                                                                                                                     |
| Figure 13. Example of Cable Thermal Analysis Results with Buoyancy Module and inside Bend Stiffener.............................................................................................................64                                                                                                                                                                                                                                          |
| Figure 14. Global, Local and Thermal Cable Fatigue Analysis Flowchart......................67                                                                                                                                                                                                                                                                                                                                                               |

## Abbreviations

| AEP   | Annual energy production                      |
|-------|-----------------------------------------------|
| AI    | Artificial intelligence                       |
| ALS   | Accidental limit state                        |
| BAU   | Business as usual                             |
| CAPEX | Capital expenditure                           |
| CfD   | Contract for difference                       |
| CMIM  | Commercial scale mooring integrity management |
| DAS   | Distributed acoustic sensing                  |
| DLC   | Design load cases                             |
| DOF   | Degrees of freedom                            |
| DTS   | Distributed temperature sensing               |
| FEED  | Front end engineering design                  |
| FLS   | Fatigue limit state                           |
| FOW   | Floating offshore wind                        |
| FOWT  | Floating offshore wind turbine                |
| GW    | Gigawatt                                      |
| HSE   | Health, safety and environment                |
| HV    | High voltage                                  |
| JIP   | Joint Industry Programme                      |
| KPI   | Key performance indicator                     |
| LiDAR | Light detection and ranging                   |
| LCOE  | Levelised cost of energy                      |
| LSPA  | Larger static pitch angles                    |
| MCR   | Marine component replacement                  |
| MIM   | Mooring integrity management                  |
| MOSS  | Maximum operating sea-states                  |
| MW    | Megawatt                                      |
| NREL  | National Renewable Energy Laboratory          |
| NTS   | Natural time-series                           |

<!-- image -->

| O&G   | Oil and gas                      |
|-------|----------------------------------|
| O&M   | Operations and maintenance       |
| OEM   | Original equipment manufacturer  |
| OPEX  | Operational expenditure          |
| OWF   | Offshore wind farm               |
| PSD   | Power spectral density           |
| QA    | Quality assessment               |
| QC    | Quality control                  |
| R&D   | Research and development         |
| RBI   | Risk-based inspection            |
| RFI   | Request for information          |
| RNA   | Rotor nacelle assembly           |
| ROV   | Remote operated vehicles         |
| SEW   | Stakeholder engagement workshops |
| TQB   | Technology qualification basis   |
| TLP   | Tension leg platform             |
| TRL   | Technology readiness level       |
| TTP   | Tow-to-port                      |
| ULS   | Ultimate limit state             |
| WTG   | Wind turbine generator           |

<!-- image -->

<!-- image -->

## FOREWORD

## Setting the scene

Despite a slower than expected pace of development for the floating offshore wind sector since publication of the Floating Wind Joint Industry Programme (Floating Wind JIP) Stage 2 Phase V report, there are positive signs on the horizon. In France, the first of three much anticipated floating offshore wind projects has now reached operation in the waters of the Mediterranean. The Provence Grand Large project, with a capacity of 24 megawatts (MW) is soon to be followed by the 30 MW Golfe du Lion and EolMed projects, both currently under construction. 1  These developments, although they are not the largest floating offshore wind projects installed to date, represent a step-scale from the single unit demonstrators deployed over the past decade and signal a growing momentum in both the sector and region. However, they remain far from the commercial scale required to deliver cost reductions and industrial efficiencies needed to meet the ambitions set by governments worldwide.

Floating offshore wind is also entering a new phase of development in UK. In late 2024, the 400 MW Green Volt project became the first commercial scale floating offshore wind farm to secure an offtake agreement under the UK's flagship contracts for difference (CfD) renewable energy support scheme. Scheduled for commission in 2029, it will become the first commercial scale floating wind farm in the world. 2 Additionally, the UK's Crown Estate recently awarded 3 GW of floating offshore wind capacity under the Celtic Sea leasing round, adding to a growing pipeline of projects from previous ScotWind and INTOG (Innovation and Targeted Oil &amp; Gas) leasing rounds. 3

## Floating Wind JIP Stage 3 Phase I

Stage 3 of the Floating Wind JIP reflects a critical step in efforts to commercialise floating offshore wind projects globally. Building on the foundations that were laid in previous stages of this programme, which demonstrated technical feasibility and cost-reduction potential, these projects focus on enabling large-scale deployment, de-risking technology challenges, identifying innovative solutions, and supporting cost reduction, which are considered fundamental pillars to reach the commercial maturity of floating offshore wind.

The projects covered in this series of eight reports span a broad range of technical focus areas upon which the industry needs clarity in order to progress. This includes electrical systems, mooring systems, logistics, wind farm optimisation, foundation design, and asset integrity and monitoring. Together, these projects provide a comprehensive picture of the challenges that must be overcome for the sector to scale and build the technical and operational knowledge base needed to support future commercial scale floating offshore wind projects.

## Industry collaboration

In recent years, the growth trajectory of floating offshore wind has slowed, with revised targets and project delays and cancellations being experienced. This mirrors a wider trend across the offshore wind sector where inflation, rising interest rates, and supply chain constraints have impacted cost and

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

investor confidence. While floating offshore wind has been proven technologically feasible, it has yet to achieve commercial maturity, making it riskier than bottom-fixed projects.

Nevertheless, global targets for decarbonisation and heightened concerns around energy security continue to drive the long-term outlook of the offshore wind. To ensure that the sector is prepared for the commercial scale deployment of floating offshore wind projects, it is critical that industry collaboration and innovation continue today. Ongoing research and development, as well as collaboration among offshore wind farm developers, technology innovators and the wider supply chain will play a critical role in de-risking the technologies and delivering the cost reductions needed to scaleup floating offshore wind development and support the recovery, and continued growth of the floating offshore wind industry.

## FLOATING WIND JIP

## About the Floating Wind JIP

The Floating Wind Joint Industry Programme (Floating Wind JIP) is a collaborative research and development (R&amp;D) initiative between the Carbon Trust and 16 leading international offshore wind developers: bp, EDF Renouvables, EnBW, Equinor, Kyuden Mirai Energy, Ocean Winds, Parkwind, RWE Renewables, ScottishPower Renewables, Shell, Skyborn Renewables, SSE Renewables, TEPCO, Tohoku Electric Power Company, Total Energies and Vattenfall.

<!-- image -->

The primary objective of the Floating Wind JIP is to overcome technical challenges and advance opportunities for commercial scale floating wind. Since its formation in 2016, the programme scope has evolved from feasibility studies to specific challenges focusing on:

- · Large scale deployment
- · De-risking technology challenges
- · Identifying innovative solutions
- · Cost reduction

## Evolution of the Floating Wind JIP

<!-- image -->

Since its formation in 2016, the programme has been delivered in three distinct stages, each consisting of studies to overcome the challenges and investigate the opportunities of developing commercial scale

<!-- image -->

<!-- image -->

floating wind farms. An initial review of policy needs, cost trends, and technology status for floating wind in Stage 1 resulted in the prioritisation of several key technical challenges which were investigated throughout Stage 2.

The primary objective of Stage 2 was to undertake detailed assessments of the key technology challenges common to multiple floating wind concepts and to support innovation to develop the solutions needed for large scale floating wind arrays. The Stage 2 summary reports can be found here: Phase I, Phase II, Phase III, Phase IV and Phase V.

To reflect the evolution of floating offshore wind from technology demonstration to industrialisation, Stage 3 of the Floating Wind JIP officially launched in 2022, with an objective to advance technology development for the large-scale deployment of floating offshore wind. This is the first summary report under the Stage 3 of the project and comprises of projects delivered as part of Phase I.

## Objectives of the Floating Wind JIP

## Floating Wind JIP: Stage 3

The primary objective for Stage 3 of the Floating Wind JIP is to overcome challenges and advance opportunities for commercial scale floating wind. The programme is technology focused, with a particular emphasis on:

- · Large scale deployment: Floating offshore wind technology has successfully progressed beyond pilot and small-scale demonstration projects, with pre-commercial projects nearing deployment. These developments mark a critical step toward full commercialisation which introduces a new set of technological and logistical challenges associated with increased scale and complexity.
- · Derisking technology challenges: While floating offshore wind is now a proven technology, there are still a number of perceived risks that have yet to be tested under operational conditions. As the industry transitions to commercial-scale deployment, these risks are further amplified by the challenges of scaling up to meet project demand Continued research is needed to address and mitigate these risks, leveraging insights from other sectors while addressing the challenges specific to floating offshore wind.
- · Cost reduction: The programme has a strong focus on cost reduction to ensure floating offshore wind becomes a competitive technology in all major global markets. Cost assessments are included in the scope of most projects to inform cost projections and identify key cost drivers, supporting the development of future commercial projects.
- · Identifying innovative solutions: Overcoming the floating offshore wind industry's technical and commercial challenges, reducing costs, and deploying capacity at scale will require ongoing innovation. Developing optimised and cost-effective innovative solutions will be key to advancing the sector and will create significant opportunities for suppliers, innovators, research bodies, and academia.

<!-- image -->

## The Floating Wind advisory group

In 2020, the Floating Wind JIP Advisory Group was formed. The advisory group creates a technical dialogue between relevant technology suppliers and the Floating Wind JIP projects. The advisory group was initially formed of turbine original equipment manufacturers (OEMs) and floating substructure developers. The advisory group has recently been expanded (in Stage 3) to include cable suppliers, to support the increasing number of cable projects which are being delivered under the programme. The advisory group is currently formed of 16 members, below.

<!-- image -->

## STAGE 3 PHASE I PROJECTS

## 1. Dynamic cable condition monitoring

<!-- image -->

<!-- image -->

## 1.1. Project overview

The dynamic cable condition monitoring (DCCM) project was delivered by Ove Arup &amp; Partners in collaboration with the University of Exeter on behalf of the Floating Wind JIP.

The vulnerability of subsea cables to electrical and mechanical risks due to marine exposure is a critical concern. Even in bottom-fixed offshore wind installations, as indicated by insurance data, cables pose the most common failure risk. Implementing condition-based monitoring can be instrumental in detecting premature failures early and informing design decisions to enhance reliability. However, the lack of consensus on reliable and cost-effective monitoring methods for dynamic cables remains a challenge.

To address this, DCCM aims to identify the most effective condition-based monitoring techniques for dynamic cables in a floating offshore wind context.

## Project objectives

- 1. Evaluate the risks associated with dynamic cables and understand the different mitigation techniques.
- 2. Assess the different dynamic cable motions and lifetime monitoring technologies and their applicability in context to predicting premature failures.
- 3. Determine priority actions to support the development and accelerated deployment of condition monitoring strategies for dynamic cables.
- 4. Establish recommendations on an operation and maintenance (O&amp;M) strategy for dynamic cable condition monitoring systems.

## Methodology

## Literature review and problem definition

Scenarios to capture possible dynamic cable configurations for floating wind applications were defined. These scenarios were then used as the basis of a comprehensive literature review that addressed:

- 1. Current subsea cable designs in bottom fixed offshore wind foundations (OWF);
- 2. Potential improvements based on dynamic cables deployed in the oil and gas (O&amp;G) and floating offshore wind industries; and
- 3. Suitable cable monitoring techniques across all offshore sectors (O&amp;G, fixed and floating offshore wind, and tidal energy).

The review included analysis of cable motions and failure mechanisms, including those caused by the use of static cables in dynamic applications, to identify components of focus for improved cable O&amp;M.

<!-- image -->

The scope of this project encompassed cables, terminations and ancillary equipment such as latches and buoyancy systems.

## Stakeholder engagement

Relevant stakeholders were engaged as required throughout the duration of this project. These included floating offshore wind developers, insurance companies, certification bodies, investors, cable designers and monitoring technology developers.

The engagement with these stakeholders was made by conducting a wide request for information (RFI), followed by workshops and one-to-one interviews facilitated by subject matter experts.

## Technology assessment

A thorough technical assessment and comparison of cable condition monitoring technologies was undertaken. The evaluation considered various factors including feasibility, risk, safety, cost, scalability, robustness, digital implementation, and asset value potential for each system or product. The data was sourced from technology suppliers, as well as insights from previous experimental testing and monitoring studies performed by the University of Exeter.

## GAP analysis and technology road mapping

The results of the technology assessment enabled the identification of gaps in the relevant technologies, and the technical and commercial barriers to addressing these gaps.

Technology roadmaps were developed for the main technologies of interest. The roadmaps focused on the technologies with the highest potential impact, and provided implementation plans for the uptake of those technologies.

## O&amp;M recommendations

Recommendations on an O&amp;M strategy were also provided. These recommendations address the costs incurred during operation, expected maintenance measures, and an indication of where the technology would be located in the cable system.

## 1.2. Key findings

<!-- image -->

Dynamic cables present a potential operational risk for floating offshore wind assets.

- · Even in bottom-fixed offshore wind applications, insurance data indicates that cables present the most common failure risk.
- · A review of common failure modes for existing inter-array and export cables infrastructure identified that the main cable failure modes are mechanical, which often precede other failure modes, such as insulation degradation or thermal failure.
- · The cable components most exposed to mechanical failure were identified as the outer cable sheaths and the integrated optical fibre.

<!-- image -->

<!-- image -->

- · Given the increased cyclic load conditions and higher mechanical stresses for dynamic cable sections, mechanically induced failure is a key risk factor for dynamic submarine cables in floating wind.

itoring across many stakeholder groups. There is clear demand for condition mon

- · All stakeholders interviewed through the course of this project demonstrated a clear demand for cable condition monitoring solutions, further evidencing the prevalence of operational risks that high voltage (HV) cables introduce to operations.
- · Beyond risk reduction, other use cases identified include verification of modelling and datadriven design improvements/optimisation; life extension and/or through asset life health checks to determine residual life and net present value of an asset.
- · The benefit and demand for cable condition monitoring is expected to grow significantly with the deployment of floating offshore wind solutions, and with increased cable power rating for fixed installations.
- · Stakeholders believe that the deployment of DCCM could bring financial benefits to operators in terms of insurance. Providing a risk mitigation strategy that reduces the Estimated Maximum Loss as part of annual reviews is one such mechanism (assuming the technologies can be proven to reliably mitigate a risk).
- · As a risk mitigation solution (rather than revenue generating), there isn't a clear financial driver or business case yet for operators, and the cost/benefit analysis associated with risk reduction requires further analysis and quantification.

<!-- image -->

ologies have been demonstrated in the field. Few HV cable condition monitoring techn

- · To date, risk mitigation approaches for cable assets typically rely on the use of periodic remote operated vehicles (ROV) or other subsea surveying methods.
- · Awareness of different technologies and experience in the adoption of condition monitoring has been variable, with asset developers/operators often influenced by their individual experience to date with cable failures.
- · Two technologies, distributed acoustic sensing (DAS) and distributed temperature sensing (DTS), have been widely applied, with variable success and impact. One operator interviewed described successfully utilising DTS as part of the forensic analysis of a recurring cable failure with subsequent use of the insight within an insurance case, alongside investigative data and modelling. In another instance, a DTS system was taken out of service as it could not demonstrate any value.
- · Beyond these two technologies, there is limited confidence in the maturity of other technologies to accurately and reliably assess cable risk, particularly those related to mechanical failure modes.

<!-- image -->

<!-- image -->

A range of condition monitoring technologies are in development and could support risk mitigation, alongside other value propositions.

- · Measuring temperature (DTS) and acoustic (DAS) signals are the two most developed technologies. These technologies show the highest prevalence of reported technology readiness levels (TRLs) greater than 6 from the technology developers engaged.
- · Some other technologies have achieved commercial adoption in other sectors, such as the rail network. This provides potential for significant knowledge transfer to offshore wind applications, but substantial demonstration and field verification and experience would be required to demonstrate their suitability for cable monitoring for floating offshore wind.
- · Based on the review, no single monitoring technology could cover all potential failure mechanisms.
- · A combination of different technologies could provide an enhanced condition monitoring system and may enable different information aspects of a failure mode to be 'learned' and signatures for early warning and degradation scenarios to be developed.

<!-- image -->

No technology is yet fully mature, but several present significant potential for future delivery of long-term condition monitoring.

Based on analysis of the breadth of technology solutions, from mature to nascent, three technologies were identified as representing the most potential for commercial availability in the short/medium term, with the opportunity to be synergistic when deployed together, namely:

- 1. Distributed Strain Sensing (DSS, Brillouin + Fibre Bragg Grating)
- 2. Motion Sensing (IMU)
- 3. Spread-spectrum Time Domain Reflectometry (SSTDR)

These were identified through use of a Balanced Scorecard (BSC) Approach, combining the findings from engagement with potential users to determine the relative importance of different evaluation criteria, and data from technology developers to understand the maturity and technical capability of each technology. Two examples of the BSC results are shown in Figure 1, for the Developer and Insurer stakeholder groups, with Strain 1 and Strain 2 representing two different suppliers of DSS technology.

Figure 1. Balanced scorecard results for the Developer and Insurer user groups.

<!-- image -->

The more established DAS and DTS technologies are also expected to be used in floating offshore wind projects. The evaluation of these technologies was not prioritized within this study, however, since they have already achieved a higher level of maturity and widespread adoption. In addition, DTS and DAS

<!-- image -->

<!-- image -->

<!-- image -->

technologies are also used to support the monitoring of electrical components, which falls outside the scope of this project, primarily focused on failures in dynamic cables due to motion.

## 1.3. Industry needs/innovations

<!-- image -->

Addressing technology barriers in the early stages of development will be crucial to de-risk dynamic cable condition monitoring technologies and ensure a clear route to adoption.

Perceived knowledge gaps and technical and commercial barriers to the deployment of dynamic cable condition monitoring generally, i.e. not specific to any single technology solution, were identified, including:

- · General lack of awareness of and confidence in possible condition monitoring technologies. Lack of confidence in the business case for condition monitoring and applications and systems.
- · Lack of knowledge sharing, collaboration and common language and metrics across the industry leading to prolonged delivery of prototypical solutions, a general lack of consistency with design and solutions, and a repetition of mistakes.
- · Lack of clear translation of technical data and analysis to meaningful insights and recommendations.
- · Lack of certainty on data storage approaches suitable for vast quantities of data recorded through long-term condition monitoring, and feasibility of developing software to interrogate the monitoring data and provide the analysis.
- · Lack of availability of operational windfarms with the capacity to deploy both a new technology and an established survey method for demonstration and validation.

Many of these industry-wide barriers, among others, need to be addressed upfront, otherwise there is a risk that solutions are developed without clear routes to adoption and/or with limited usefulness in deployment.

<!-- image -->

Collaboration across the supply chain is essential to increase the TRL of key condition monitoring technologies.

- · With no single technology yet mature and proven, and each having varying strengths and weaknesses, it is necessary to continue supporting the development of multiple solutions.
- · It is anticipated certain technologies closer to maturity, such as DSS, may be demonstrated in shorter timescales, which could make more nascent technologies redundant.
- · Given the necessity for testing, from laboratory scale through to trial deployment in the field, there is a significant risk that the development of all technologies will be delayed if suitable facilities and demonstrator projects are not established quickly enough.
- · To enhance system development, it is worth exploring the potential for combined prototype testing of multiple technologies, for example IMU combined with SSTDR.
- · There is further potential for combined solutions and integration in the cable manufacturing process, requiring collaboration between monitoring equipment suppliers and cable

<!-- image -->

<!-- image -->

manufacturers. For example, the combined measurements of acoustic, strain and temperature through multiple fibres could provide a valuable condition monitoring network using established technologies (if fibres are suitably integrated during cable production).

- · An 'agile' approach is envisaged to manage the on -going innovation. This comprises incremental delivery of activities with each designed to validate assumptions regarding technology feasibility, business case viability and / or user desirability, whilst delivering standalone, incremental value along the way.

<!-- image -->

The utilisation of dynamic cable condition monitoring systems can lead to increased O&amp;M costs and needs to be carefully considered in a wind farm's operational strategy .

- · Operational costs associated with continuous monitoring of offshore wind infrastructure are routinely underestimated. A bottom-up assessment of O&amp;M activities and prices for similar systems in fixed offshore wind applications estimates operational cost ranging between £1,500/yr/MW - £9,000/yr/MW (2023 prices), which represents a significant portion of total expected O&amp;M budgets.
- · A focus on operational strategy is required to improve financial viability, in particular potential optimisations of monitoring extent (both in terms of number of assets/length of cable and data collection duration).

## 2. Maximum operating sea-state evaluation

## 2.1. Project overview

<!-- image -->

The maximum operating sea-state evaluation (MOSE) project was delivered by a consortium led by AMOG, together with Sowento and London Marine Consultants (LMC), which provides both floating wind and Oil and Gas experience. The project, delivered through the Floating Wind JIP, investigated the concept of a maximum operating sea-state (MOSS), above which the turbine shuts down (similar to the cut-out windspeed), to reduce the design loads on the floating offshore wind turbine (FOWT).

Reducing the design loads on the system can allow for lighter, cheaper structures, thereby reducing the upfront cost (CAPEX) of a floating wind farm. The MOSE project was initiated to understand trade-offs between load reduction and impact to annual energy production (AEP), as well as to identify the key design considerations when implementing this operating philosophy. This summary report outlines the project's key findings and highlights future requirements for the industry.

## Project objectives

- 1. Understand the potential cost savings for unit design by using maximum operating sea-states.
- 2. Define and outline a process by which MOSS can be optimised during project implementation.
- 3. Evaluate potential implementations of MOSS within the floating wind control and safety system by using robust and reliable sea-state sensors.
- 4. Identify the design considerations, especially metocean conditions and simulation lists, when using MOSS.

## Methodology

## Standards review &amp; gap analysis

Design standards, guidance notes, and recommended practices were reviewed to identify the permissibility of MOSS, design load cases (DLCs) that are affected by MOSS, as well as potential gaps and ambiguities.

## Functional safety analysis

Hazard identification (HAZID) and layers of protection analysis (LOPA) were conducted to determine the required safety integrity level (SIL) for the MOSS system.

## Wave measurement technologies

A broad range of wave measurement techniques and sensors were reviewed. The TRLs, capability, accuracy, and relative cost factors were compared to develop different approaches to measuring the sea-state for the purposes of MOSS limit exceedance detection.

## Stakeholder engagement

Interviews with OEMs, wave sensor manufacturers and floater manufacturers were conducted. These provided inputs at various points during the project, ranging from review of the HAZID activities,

<!-- image -->

<!-- image -->

guidance around governing load cases for tower/floater design and capabilities and limitations of wave sensors.

## Loads analysis

Time-domain analyses of the FOWT were conducted to derive the tower base loads with and without MOSS for comparison and quantification of the load reduction. The Floating Wind JIP 15 MW semi-sub platform was used as reference design. A set of met-ocean data (hindcast) from a North Sea site was used as the basis for the assessment, the scope of which included:

- 1. Derivation of load cases covering the conventional DLCs and additional cases across the environmental contour, to obtain a holistic 'response surface' a response as a function of different combinations of wind and wave conditions;
- 2. Development and tuning of a normal-stop routine in consequence to cut-out sea-state exceedances;
- 3. Coupled analysis using OpenFAST;
- 4. Sensitivity analysis involving comparison of the reference stiff-stiff tower with a soft-stiff tower design and scaled-down environmental conditions (to simulate a more benign region).

## Comparison of MOSS approaches

'Reactive' vs 'proactive' MOSS approaches were compared. 'Proactive' approaches measure the sea -state ahead of the turbine, with sufficient forewarning to shut down before the waves reach the FOWT. A 'Reactive' approach is a risk -based method that involves short-term historical in-situ measurements and statistical analysis to estimate the likelihood of an upcoming MOSS limit exceedance.

Seastate 'rise times', FOWT response correlation with peak wave elevations, and literature around averaging windows were also reviewed to formulate guidance around the most effective strategy, and determine which approach had the lowest impact on the expected uptime. The pairwise comparison was used to evaluate different MOSS implementations across a range of criteria and recommend the preferred approach.

## Development of guidance &amp; recommendations

Design considerations and impacts of MOSS were identified and reviewed, and guidance for MOSS implementation was formulated based on the identified factors and outcomes of the analysis.

## Key assumptions

The following key assumptions were made for simulation studies:

- · The largest loads occurred in normal operation and extreme sea-state (DLC1.6) for the semi-sub platform considered, which was already found in The Carbon Trust's Phase III Numerical Modelling Guidelines Project;
- · The reference designs considered were compliant in fatigue limit state (FLS) and ultimate limit state (ULS)/accidental limit state (ALS). A water depth of 150 m was considered, with site conditions based on a hindcast from a North Sea site;
- · For the purpose of comparison of the two MOSS approaches (proactive vs. reactive), idealised sensors were assumed, with no delays or restrictions on power and communications.

<!-- image -->

## 2.2. Key findings

<!-- image -->

Use of MOSS is permitted by current design standards, however there is some ambiguity and gaps regarding the implementation.

- · Several DLCs can be adjusted with MOSS. Depending on the DLC, it is possible to lower the wave height to the MOSS limit, assess with the turbine idle instead of operating, or apply a lower partial safety factor due to it being considered an abnormal condition. These modified load cases are the primary way by which MOSS can reduce the design loads on the FOWT.
- · It is unclear in standards whether MOSS should be considered part of the control system or protection system. Shutdown events triggered by protection systems are typically subject to limitations on automatic restarts (although this depends on the exceedance condition), which may excessively penalise AEP if the same limitations are applied for MOSS limit exceedances. MOSS, however, is most analogous to the cut-out windspeed, and could be characterised as such by design standards.

<!-- image -->

MOSS has benefits when there is a combination of high operational thrust and high sea-state as the governing design condition.

- · The fundamental of MOSS is that the maximum ULS loads are driven by a combination of high thrust and wave loads, and that the ULS loads are governing the design of the component(s) of interest. Before considering using MOSS, the designer should understand which load case is driving the design. If DLC1.6 (which corresponds DLC 1.6 of IEC 61400-3-2) 4  is the governing case, then MOSS can be considered as a tool to reduce design loads.
- · The optimal MOSS system would limit the operation of the turbine such that DLC 1.6 is no longer the governing load case, as shown in Figure 2. As the overall utilisation of the specific system decreases, a design iteration can then take place to optimise the amount of material required, reducing the cost of each individual unit and therefore reducing project CAPEX.
- · Imposing a MOSS limit on the FOWT will also reduce the expected uptime of the wind turbine generator (WTG) and consequently the average AEP. Therefore, a designer should only implement MOSS when there is a net benefit to the levelized cost of electricity (LCOE); where the trade-off between the lost revenue due to reduced uptime and cost savings from MOSS is favourable.

4  American Bureau of Shipping (2020) Guide for Building and Classing Floating Offshore Wind Turbines - Link

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Figure 2. MOSS-induced Load Effects

<!-- image -->

Integrated loads analysis and a holistic design approach is recommended if using MOSS. Secondary impacts of reducing the structural size must also be considered.

- · MOSS aims at lowering the ultimate design loads on components to reduce the structural sizes and mass. However, reduction in structural size will have secondary impacts on other aspects of the performance of the components, such as fatigue performance, platform stability, platform offset envelope, and AEP, which must be considered when implementing MOSS.
- · The implementation of MOSS also requires the consideration of various load effects and the contribution of different environmental loads to the system's response. A wide range of environmental conditions in the design contour should therefore be assessed. This is to ensure that the response of the FOWT at and above the MOSS limit is well understood by the designer, and allows identification of the governing conditions and accurate assessment of the impact of MOSS.
- · MOSS should be considered early in the design phase, when initial pre-front end engineering design (FEED) analysis shows what is the driving load case. The design-driving load cases for each component of the FOWT, however, depend significantly on MOSS, and thus an iterative approach is recommended when designing a system that utilises MOSS.

<!-- image -->

<!-- image -->

Figure 3. MOSS During the Design Process

<!-- image -->

A proactive approach using an array of wave buoys placed upwave of the farm, at sufficient distance and spacing to ensure directional coverage, was the preferred approach.

- · Reactive (risk-based) approaches inherently require a more conservative MOSS limit to achieve a given probability of non-exceedance (i.e. the probability that the sea-state does not exceed the MOSS limit in the next time period) than a proactive approach. This results in a greater impact on the expected uptime of the turbine and AEP.
- · Furthermore, a reactive approach may fail to predict severe, sudden storm conditions prior to it reaching the FOWT, whereas a proactive system can detect oncoming adverse conditions ahead of time.
- · The up-wave buoy array should be designed to ensure coverage across all of the prevailing wave directions, especially for severe sea-states.

<!-- image -->

Redundancy, calibration and performance integrity requirements should all be considered for a MOSS system.

- · The MOSS system is considered critical to the safe performance and operation of the FOWT. To meet the required performance integrity level, redundancy should be considered and implemented by using multiple wave buoys.
- · Wave buoys are subject to power and communication limits, which restricts how frequently they can communicate with the turbine control system. Constant remote communication (radio, cellular, satellite, or otherwise) is not currently feasible for long-term deployment in a MOSS system.
- · Wave buoys will require calibration throughout the lifetime of the farm and may also require cleaning from biofouling to ensure accurate measurement of the sea-state.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Short term sea-state (height and period) information provides the most accurate and feasible environmental information for a MOSS system

- · Poor correlation was predicted between individual peak wave events and the peak FOWT tower base bending moment response. While there was a phase relationship between 1 st -order wave loads and the tower base bending moment, the overall peak magnitude in the response was driven by low-frequency thrust loads.
- · This finding, combined with the power and communication restrictions for long-term deployment of remote sensors, results in the recommendation that short-term sea-state averaging should be used instead of using individual peak wave events.
- · An average window of 30 minutes is recommended based on literature review of sea-state stationarity, consideration of uncertainty in sea-state measurements, and wave buoy capabilities.

## 2.3. Industry needs/innovations

<!-- image -->

Innovations in WTG control systems could achieve similar load reductions while minimising the impact to AEP.

- · Governing load cases are often driven by the maximum thrust loads from the turbine. Rather than fully idling the turbine above the MOSS limit, modified control systems that derate the turbine (to operate in a lower thrust mode) in these conditions could be used as an alternative. By allowing the turbine to operate in reduced thrust mode above the MOSS limit instead of complete shutdown, which may otherwise be too penalising for the AEP, these modified control systems would minimise the impact on AEP while still providing load reduction.
- · There is further opportunity for hull &amp; mooring cost optimisation if MOSS can be combined with a wind turbine controller tuned to reduce fatigue on the moorings, without the need for additional software or hardware. This could enable a reduction of both ultimate and fatigue design loads. Especially for benign sites, lightweight FOWT designs might be possible with a combination of MOSS and a fatigue-reducing controller and should be further investigated by industry.

<!-- image -->

Multi-variable operational limits could provide a load reduction while minimising the impact to the uptime of the turbine.

- · A MOSS limit defined by significant wave height alone is potentially overconservative. Above rated wind speeds, the control system starts to pitch the blades, which reduces the rotor thrust. For this reason, a more optimal strategy could depend on the combination of wave height and wind speed, as opposed to the wave height alone. Figure 4 illustrates this concept, in which the operational contour (green) is significantly larger when selectively excluding high-utilisation cases based on significant wave height and windspeed combinations, compared to a simple

<!-- image -->

<!-- image -->

wave height limit. Additional parameters, such as wave period and direction (as well as windwave misalignment), are also likely to have an influence and could be considered.

- · A multi-variable operational limit could optimise the selection of shutdown conditions, achieving load reduction while minimising the impact to uptime. However, this will require additional design effort to ensure the turbine response is well understood across the design space and all combinations of variables.
- a) Simple MOSS design with a single HS limit
- b)
- More optimal MOSS design with a HS and windspeed dependence

<!-- image -->

<!-- image -->

Figure 4. MOSS optimisation by including windspeed dependence. Figure modified from Haselsteiner, A. F., Frieling, M., Mackay, E., Sander, A., &amp; Thoben, K.-D. (2021) 5

<!-- image -->

The potential benefits of MOSS for mooring and cable design should be explored further.

- · Whilst the focus of the numerical analyses conducted in the project was for the impact of MOSS on the FOWT structure specifically, there are opportunities for optimising dynamic cable and mooring design by implementing MOSS.
- · If the maximum platform offsets are driven by high thrust loads combined with a severe seastates, then introducing MOSS may enable reduction of the offset envelope, leading to cheaper cable designs, or a reduction in the required size and stiffness of the mooring.

5 Renewable Energy 181 , , 945 -965 (2022) Long-term extreme response of an offshore turbine: How accurate are contour-based estimates? - Link

## 3. Commercial scale mooring integrity management

## 3.1. Project overview

<!-- image -->

As floating wind moves towards gigawatt (GW) scale windfarms, there is a clear opportunity for optimisation and cost reduction of mooring system inspection, monitoring and associated management activities. These currently contribute to a significant amount of project operating costs over an asset's lifetime. While cost reduction appears achievable through sampling techniques, current mooring integrity management approaches require adaptation to transfer from an individual unit focus to a multiple unit risk-based approach. There is a need to clearly define mooring system monitoring and inspection methodologies, along with sampling techniques to consider a risk-based approach that is applicable for multiple floating wind units, accepted by classification societies, and deemed insurable.

The commercial scale mooring integrity management (CMIM) project was delivered by a consortium led by AMOG, together with ABS, SOFEC and Skowronnek &amp; Bechnak. The project, delivered through the Floating Wind JIP, investigated how a mooring integrity management (MIM) strategy would be developed for a commercial-scale floating offshore wind farm. The Floating Wind JIP 15 MW reference mooring system designs, described and updated as part of the preceding  Mooring system redundancy, reliability and integrity (MRR&amp;I) study (delivered in Stage 2 Phase 5) were used as a design basis.

## Project objectives

The project aim was to develop and answer the question of what an integrity management strategy for a commercial scale floating wind array would look like. This was undertaken by:

- 1. Building upon previous Carbon Trust work, in addition to key learnings from marine, oil and gas industries and fixed bottom turbine inspection regimes/standards, to define key differences for floating wind.
- 2. Investigating the cost-benefit of strategies based on different risks and mooring line failure implications for different systems.
- 3. Understanding the implications of mooring line failures, such as predicted loss of production versus occurrence failure rate in floating offshore wind and how they differ from O&amp;G.
- 4. Evaluating potential methods and technologies for mooring system monitoring, inspection and maintenance aimed at managing the mooring system in a cost effective and safe manner.
- 5. Understanding requirements for health, safety, and environment (HSE).
- 6. Proposing key performance indicators (KPIs) to measure mooring integrity, from design to installation and operation.
- 7. Listing relevant technology development requirements and differences from a business as usual (BAU) approach.
- 8. Investigating different levels of integration between digital twins, physical inspections and remote monitoring.

<!-- image -->

<!-- image -->

- 9. Proposing methodologies for defining the sampling rate for inspections on commercial wind farms, including sensitivities on the selected sampling rate and the impact on the total cost versus expected downtime.
- 10. Producing a set of suggested documentation to support mooring integrity management (MIM) standardisation to different industry stakeholders including classification societies, insurance companies and equipment suppliers.
- 11. Identifying how the industry could work together to use data from floating offshore wind farms in the same regional development areas to help inform integrity management of these farms in the wider context, including for example data driven techniques for managing integrity from large data sets.

## Methodology

The study investigated how a mooring integrity management strategy would be developed for a commercial-scale floating offshore wind farm utilising the mooring systems designed in the previous Floating Wind JIP MRR&amp;I study and how a MIM strategy would vary depending on the type of mooring system used.

## Key assumptions

- · The A Base Case (3 × 1 mooring system) assumed a non-redundant mooring system and the Alternative Case (3 × 2 mooring system) assumed a redundant mooring system. Redundancy for this project was defined as the mooring system maintaining station and, therefore, preserving the inter-array cable connection in the event of a single mooring line failure. This was linked back to the fundamental performance requirement of a mooring system, which is to maintain station of a floating foundation within tolerable position limits. The consequence of the loss of a mooring line for the Base Case (3 × 1) resulted in the FOWT unit losing station, exceeding the dynamic cable watch circle offset limits, and resulted in a loss of the inter-array cable; as demonstrated by the MRR&amp;I study.
- · The wind farm project was in the FEED stage of the project life cycle. As such, the mooring components were based on early design configurations and not fully defined. The lack of definition of these designs limited the performance assessment in the study as it required the analysis of the performance and characteristic of, for instance, a generic in-line tensioner device instead of a specific manufacturer's product.
- · A FEED definition level field layout was proposed, including assumptions for water depth and bathymetry, field topology and number of inter-array cables, farm spread and characteristics of the wind farm location (e.g. seabed conditions, exposure to shipping and fishing traffic, and metocean information). Figure 5 presents the assumed wind farm layout, with 50 FOWT units, arranged in 10 sets of 5 daisy-chained units and spanning water depths from 80 m to 130 m. The definition of this layout supported the development of clustering, sampling, inspection and monitoring strategies based on considerations for farm-wide susceptibility to risk.

Figure 5. Assumed Floating Offshore Wind Farm Layout

<!-- image -->

<!-- image -->

<!-- image -->

## Literature review

Applicable standards and best practice for mooring integrity management within both offshore wind and O&amp;G sectors were reviewed.  Additionally, related research and previous mooring integrity management work in the floating offshore wind sector were also reviewed to identify applicable learnings, products, technology, and sampling techniques.

## Stakeholder engagement

Several workshops between delivery consortium members, industry experts and organisations were conducted. These were used to identify key areas and challenges for effective integrity management at commercial scale.

## Failure modes, effects and criticality analysis (FMECA)

Identification of degradation risks for individual system components, and specific localised site risks across an array relevant to floating offshore wind mooring locations was based on the work undertaken in the MRR&amp;I project. Further assessment regarding criticality of mooring degradation threats was undertaken by qualitatively assessing the likelihood of threat occurrence and the severity of resulting consequences.

<!-- image -->

<!-- image -->

<!-- image -->

## Development of mitigation strategies

Degradation controls for each individual degradation mechanism (identified as part of the FMECA) were used to develop key performance indicators.  These indicators enabled effective implementation of control measures that address specific degradation risks, mitigating potential degradation threats and preventing emergences such as a mooring line failure or loss of station. The control measures were considered across all stages of the wind farm (approximately 25-year life cycle), from installation to end-of-life. Examples of mitigation strategies include increasing the frequency of inspection, monitoring, and modelling of high-risk components at specific times in their life cycle, such as installation, close to wear out, or when monitoring and modelling indicate a potential future failure.

## Development of MIM framework suitable for commercial scale floating offshore wind

A risk-based MIM approach was proposed, adapted from the safety case framework (set out in the UK by the UK Health and Safety Executive) to provide a greater focus on system and wind farm performance. This approach considered both a single floating FOWT un it's integrity and the overall susceptibility of the farm to risk. The approach for multiple FOWT units and clustering approach used to inform sampling, including unit monitoring approach variation. More details on the MIM framework approach can be found in the Appendix: MIM framework approach details.

## Comparison of prescriptive and risk-based MIM approaches

The requirements for both extensive prescriptive and risk-based approaches for inspection and monitoring were identified. These requirements were subsequently compared to determine where mooring integrity management planning can benefit the most from the implementation of a risk-based framework, potentially reducing the inspections required.

## Development of class-Accepted MIM plan documentation and templates

MIM plans were developed based on project definition at FEED stage. These comprehensive plans included documentation and templates for:

- · MIM philosophies
- · Risk assessments
- · System controls definition
- · Control test and verification record requirements
- · Emergency response planning
- · Numerical monitoring requirements
- · Monitoring and simulation requirements
- · In-service inspection and monitoring plans on a prescriptive and risk basis

These plans were developed in collaboration with a classification society and the insurance industry, whereby an approval-in-principle was granted by ABS at the concept verification stage. Skowronnek &amp; Bechnak (S&amp;B) provided guidance on the critical aspects that insurers are expected to look for within a MIM plan to assess potential impacts on coverage and insurability.

## Development of Guidance &amp; Recommendations

The challenges expected to arise with the implementation of mooring integrity management at a commercial scale were identified at each life cycle phase, in addition to broader integrity management system challenges. Areas where it would be beneficial to develop additional guidance to support standardised and acceptable implementation of CMIM were also highlighted.

<!-- image -->

<!-- image -->

## 3.2. Key findings

<!-- image -->

The comprehensive mooring integrity management strategy developed was capable of addressing challenges specific to floating offshore wind and met criteria for ABS approval in principle at the concept verification stage.

- · A comprehensive MIM plan was generated at the FEED stage of a project comprising of a detailed MIM strategy, risk assessment, controls for key mooring degradation threats, monitoring and simulation strategy, emergency response plans and risk-based in-service inspection and monitoring plans.
- · The development of an overall commercial-scale MIM framework and subsequent mooring integrity management array plan required a whole-of-life-cycle approach in accordance with foundational MIM guidance documents (API-RP-2MIM, DNV-RP-E308 and The ABS Guide to Mooring Integrity Management), which were generally aligned on effective MIM recommendations. The magnitude of this task should not be underestimated for floating wind projects. Guidance remains limited for the serialised nature and number of floating wind mooring systems in a single commercial-sized project. These arrays will consist of large numbers of individual floating units affected by localised variations in metocean characteristics across the array e.g. varying water depth, exposure and wake effects depending on turbine location in an array.
- · Mooring integrity management is a process that requires continual review throughout the project life cycle. New information from each life cycle phase or inspection is crucial to assure that the mooring system remains reliable and available, whilst being managed in a cost effective and safe manner. As the MIM plan was developed at FEED stage, the documentation will be subjected to continued evolution as the design progressed through subsequent life cycle stages.
- · Multi-disciplinary teams should be engaged throughout the lifetime MIM process to review risks, current condition information, and ultimately review and audit the risk-based inspection and monitoring activities during operation.
- · An insurer's perspective of the MIM plan was provided to identify critical aspects of the approach that may impact coverage and insurability.

<!-- image -->

Implementation of CMIM requires the adaption of single-unit risk-based MIM processes to account for the considerations of wind farms containing multiple FOWT units.

- · The development of the MIM process for commercial-scale wind required the adaptation of current conventional practice based on single floating wind turbine units. Although risk-based approaches have been utilised reliably in other industries, foundational MIM literature does not provide detailed guidance on implementation of a risk-based framework for inspection planning. There is potential for the CMIM project guidance to be integrated into class guidance documents or recommended best practices.

<!-- image -->

<!-- image -->

- · The key benefits of the risk-based approach are only realised when there is continuous and consistent application of the MIM strategy over the life cycle of a wind farm. The lack of detailed guidance raises a significant challenge for floating offshore wind as it is widely recognised by the industry that for commercial projects to be cost effective, these will have a significant reliance on a risk-based inspection and monitoring framework. Guidance from other recommended practices was therefore adapted to address mooring systems and their degradation threats in the context of a multi-unit wind farm.
- · A methodology to adapt existing risk-based single unit MIM processes across commercial-scale wind farms containing multiple FOWT units was developed. This methodology was based on the understanding of the potential degradation threats, locations and timescales throughout the life cycle at which the degradation may occur. An understanding of the dynamic behaviours at a system and component levels is an essential part of the methodology.

<!-- image -->

Proper consideration of potential risks across multiple units in a FOW farm, or clusters, is critical for development of an effective monitoring and inspection strategy.

- · The susceptibility of a FOWT unit's moorings across the wind farm to specific degradation threats needs to be evaluated early in the MIM process, as a common-cause problem across many units in the farm would likely result in substantial rectification costs. The inspection task methodology in Figure 6 (appendix) addresses threat susceptibility on a stand-alone unit, and on a multiple unit farm basis, where the consequence criticality of units within the farm is reflected in the farm-wide inspection and monitoring plan; units with higher derogation and failure risk require higher levels of monitoring and inspection.
- · The clustering approach is expected to have a significant impact on integrity management planning through the application of common inspection and monitoring requirements across a number of units, as further discussed in the Appendix: MIM framework approach details.
- · Due to the cost implication of complete instrumentation of all FOWT units in a wind farm and maintaining those instrumentation packages throughout the farm operating life, monitoring strategies will rely more heavily on simulation of system responses derived from minimal, but reliable instrumentation sources, and the selection of representative units from different permutations of clusters.

<!-- image -->

As the FOW industry is in its infancy, first adopters will be instrumental in driving key learnings and future developments of understanding project cost and risk.

- · Floating offshore wind specific guidance for risk-based implementation of mooring integrity management is limited and thus the first commercial projects will require conservative decisions based on both risk evaluation and engineering judgement derived from offshore O&amp;G related experience and prescriptive inspection practices.
- · As the industry's understanding of degradation threats and system performance improves, and advances in inspection techniques occur, the industry will be better equipped to implement whole-of-life-cycle risk-based MIM strategies that utilise evidence of risk to integrity and can

<!-- image -->

appropriately justify decisions to justify adjustments from the initial conservative approaches used on the first wind farms.

- · FOWT mooring system design is expected to evolve in order to support larger turbine sizes (exceeding 15 MW), exceeding the current supply chain capacity for both mooring chain and synthetic components. Robust integrity management systems will be essential to ensure additional degradation mechanisms are not introduced through new mooring technologies (e.g. nylon rope or load reduction devices), and do not exceed the current limitations in component sizes. In addition, the deployment of new mooring technologies will require modifications to inspection and more rigorous design and manufacturing controls, such as technology qualification, validation and quality assessment (QA) or quality control (QC). The effort associated with these activities will be linked to the perceived cost-benefit of their adoption. The use of first annual surveys and the extent of subsequent inspections in operation will be determined on an individual project-needs basis and will need to consider the risk profile of both the mooring system and the wind farm.
- · Whilst the core inspection tasks may be driven by risk assessments, the final inspection plan may also include other tasks based on opportunity and efficiency considerations, vessel availability and other scheduling optimisations.
- · Lessons learned from the implementation of MIM practices on the first commercial-scale wind farms will drive future decisions of floating offshore wind MIM. These learnings should ideally be shared to advance the understanding and implementation of efficient and effective MIM practice.

<!-- image -->

Establishing a mooring integrity management philosophy early in the project will enable the evaluation of the true cost impact of operational decisions before final investment decision.

- · The definition of the MIM philosophy and strategy are critical for ensuring an effective approach to MIM. Whilst the immediate focus of system designers may be on the sizing and configuration of a mooring system from a mooring performance viewpoint, neglecting integrity management considerations from early stages of a project can lead to suboptimal outcomes in terms of project cost and schedule arising from the implementation of changes needed to satisfy class society, regulator or insurer requirements later in the project life cycle.
- · Developers should ensure that implementation of a MIM program occurs at an early enough stage to ensure all aspects of MIM program are accounted for in the design process, including technology risk considerations, installation considerations, potential for major overhaul and mooring replacement and emergency response.
- · Developers need to understand the cost impact of MIM-related decisions, including factors such as mooring system redundancy, production interruption, inter-array cable loss, shutdown duration and mitigation against escalation of consequences. Redundant mooring systems are expected to provide some advantages by requiring less extensive mooring integrity management approaches.

<!-- image -->

<!-- image -->

- · The selected MIM strategies will have a significant impact on the insurability and premium level during operations. Engagement with insurers will be crucial and should be considered in the early phases of the project life cycle.
- · Many challenges identified in this project are not only related to mooring system design but also broader industry concerns and overall integrity management. For example, managing information is crucial for commercial-scale wind farms. Significant information can be lost between the design, manufacturing, installation, and operational phases. Using risk-based inspection practices that rely on operational measurements and tuned numerical models, instead of or alongside extensive physical inspections, will increase pressure on effective management systems.

## 3.3. Industry needs/innovations

<!-- image -->

There are opportunities to develop alternative approaches to CMIM framework implementation, building on the risk-based MIM approach developed during this project.

- · The MIM literature review on the wider offshore O&amp;G industry highlighted that risk-based planning has been widely accepted in other industries and that there are several solutions and strategies for its implementation. While this project focused on developing a single approach for implementing risk-based mooring integrity management for commercial-scale wind farms, many alternative approaches may merit exploration by developers, given that the industry is still in its pre-commercial stages.
- · Large-scale floating wind turbines (15 MW+) present unique design and load challenges, with unique floater and array locations requiring specific mooring system design makeup. Further work is recommended to understand the level of uncertainty and risk-tolerance given the likelihood of the underlying mooring degradation threat emerging. This analysis should be done on the statistical basis for the work selection matrices (inspection intervals and sampling approaches) and include a benchmark against periodic 100% inspection and monitoring requirements.
- · The proposed framework includes adjustment factors for risk-based inspection planning that are applied to sample size or inspection interval, based on current condition and degradation progression rate. There is an opportunity to further investigate and compare approaches for adjusting sample size and inspection frequency, either from a scientific basis (such as a cost impact study) or exercising engineering judgement on a test case.
- · The monitoring strategy proposed depends on the assumed MIM philosophy and project requirements, focusing on reliable instrumentation and numerical model validation to reduce the need for full instrumentation of FOWT units or extensive inspection regimes. Considering the heavy reliance on monitoring, there is an opportunity to evaluate the practicality, track record and cost of implementation of various monitoring, modelling and instrumentation approaches for broader application across multiple floating offshore wind projects.

<!-- image -->

<!-- image -->

<!-- image -->

to support effective MIM strategy There is significant need for standardisation and agreement of MIM practices between Class, insurers, developers and operators implementation.

- · As more commercial floating wind projects progress through their life cycle, the industry will gain experience and insights into effective mooring integrity management strategies and failure rates. However, these learnings will likely be delayed without industry collaboration to establish consistent best practices. There is a significant need to learn from previous industry failures to improve mooring system integrity, as it reduces the likelihood of repeating mistakes through collaborative knowledge sharing. This is especially important for an emerging industry like floating offshore wind, which needs to quickly turn commercial to be impactful. As such, sharing knowledge from smaller-scale, pre-commercial projects is a crucial step to inform how reliance on prescriptive approaches may be reduced and replaced with a focus on risk for commercial scale wind farms, which would support future standardisation and agreement within the industry.
- · Each organisation has their own internal management procedures, which influence their approach to integrity management based on factors such as design preferences and risk considerations. Standardising MIM practice within the industry would support project outcomes applicable for any floating offshore wind project, rather than developing many varied procedures based on differing approaches taken by individual projects.
- · Standardising inspections and record-keeping would improve information and data management. While the data management requirements have been identified in this project, further assessment of the methodologies and practical considerations is needed to propose a strategy suitable for commercial-scale MIM.
- · There is an opportunity to standardise, inspection, monitoring planning, and data management, by developing software or an industry tool. This would standardise how the outcomes of risk assessments translate into inspection and monitoring plans, including baseline and condition information required to effectively monitor risks during operations.

<!-- image -->

Focused studies on optimisation of MIM would provide greater clarity on key considerations, improve guidance and help plan CMIM implementation.

- · Developing a set of industry-agreed requirements should be considered at the early stages of the project life cycle, when a MIM philosophy is first developed. This would improve the consistency of the approach and aid the interaction between developers, technology providers, class, insurers and regulators.
- · Guidance on the minimum number and location of reference units within a wind farm should consider the associated numerical model simulation and validation approaches. Additionally, as risk-based commercial-scale MIM will be reliant on monitoring and simulation of all units in the farm, minimum requirements for validating numerical models relied upon for system condition assessment should be developed. This includes signals to be generated synthetically by the numerical models for both high-order models, where measured signals would be used to validate

<!-- image -->

the synthetically produced signals, and for low-order models, which generate synthetic signals based on a limited set of input signals.

- · Development of industry consensus on the process for capturing and translating the risk assessment outcomes within the sampling approach and inspection interval setting activities to ensure risk-based implementation of inspection planning is consistent and applicable to commercial-scale wind farms. Reviewing consequence categorisation and likelihood ranges for industry acceptability may be advantageous and could be extended to the risk-based approaches to sampling and inspection interval setting.
- · Developing a minimum set of as-installed survey requirements and guidance on the baseline documentation to be retained at the end of each life cycle phase would improve the definition of the inspection scope and findings. This would include design documentation, fabrication documentation and installation documentation, minimising the uncertainty around the baseline condition for ongoing condition assessment, potential life extension, as well as allowing for a better definition of areas to be targeted during first annual inspections.
- · The objectives and requirements for the first annual inspection should be better defined and linked to the overall MIM strategy and the risk-based inspection and monitoring program. Existing prescriptive guidance for inspection of all mooring legs is inefficient. The first annual inspection scope should consider applying risk-based approaches to the extent of inspection in terms of:
- o Inspection task and sample size and coverage within the farm
- o Addressing gaps in baseline data
- o Accounting for the wind farm installation schedule
- · Since commercial-scale MIM relies on monitoring and simulation, in conjunction with inspection surveying, the scope of the annual review process needs to be modified to reflect those additional review requirements. Current guidance is based on the inspection of typical floating production units, where mooring leg terminations are above water or on deck, and does not adequately address the combined requirements for commercial-scale MIM where reliance on monitoring and simulation will be greater.

<!-- image -->

## Appendix: MIM framework approach details

This riskbased MIM approach considered both a single floating FOWT unit's integrity and the susceptibility of the overall wind farm to risk. The approach was then expanded for multiple FOWT units and a clustering approach was used to inform sampling. More details on this approach framework can be found below.

Inspection and monitoring requirements of a single unit could be developed once the manifestation and progression of applicable mooring degradation threats, and their risk level was understood. These requirements could then be developed in two ways:

- · Prescriptive basis using typical class inspection tasks;
- · Or risk-based approach.

Following the proposed inspection and monitoring task methodology shown in Figure 6, this required an understanding of:

- · The objective evidence requirements to verify condition;
- · The applicable inspection methods across the operating life of system components and the probability of detection using different inspection methods.

The effectiveness and performance of the chosen inspection technique and the quality of the data provided need to be carefully evaluated in developing an efficient strategy for inspection and monitoring, and utilising sampling techniques and simulation to complement the strategy.

The inspection task methodology was then expanded to consider multiple units in a floating offshore wind farm. This included considerations for:

- · Clustering units in the field based on design, operation and condition;
- · Monitoring whereby simulation and digital twins can be relied on;
- · Selection of inspection sample sizes of FOWT units, mooring lines or individual components, along with a series of adjustment factors should the underlying mechanisms be inspectable and monitorable.

Monitoring allows an operator to verify, validate and predict future performance of a mooring system, subsystem or component if current condition can be tracked or inferred. Considering the cost implication of complete instrumentation of all FOWT units in a wind farm and maintaining those instrumentation packages throughout the farm operating life, the monitoring strategy was developed to rely more heavily on simulation of system responses derived from minimal, but reliable instrumentation sources.

This monitoring approach required all the FOWT units being instrumented with a suitable means of determining integrity of the mooring system and identifying that all mooring legs are intact, through monitoring platform position and motions, defined as Minimally Instrumented Units (MIUs). A small subset of FOWT units were additionally instrumented with direct tension monitoring to be utilised primarily for validation, these units defined as Highly Instrumented Units (HIUs). Consequently, direct tension sensors (such as load cells or strain gauges), that currently have a poor reliability record in the offshore industry, did not need to be replaced after failure in operation, on the basis that numerical models had been validated by this time. Data management (baseline, inspection, monitoring and simulation data sets), accuracy of numerical models and selection of reference units (or HIUs) that were

<!-- image -->

instrumented with tension monitoring to enable validation, was therefore crucial for implementing an effective monitoring strategy.

Figure 6. Inspection Task Definition Methodology

<!-- image -->

Clusters may be applied at different levels considering:

- · Risk exposure
- · A single threat
- · Performance or operating characteristics that affect unit performance compared to those outside the cluster

Figure 7 presents the clustering layers derived for the assumed field development layout, whereby each cluster groups units based on performance or behaviour characteristics, risk exposures or consequence outcomes. As these clusters overlap, individual units are able to be assigned to two or more clusters.

Figure 7. Wind Farm Clustering Layers

<!-- image -->

The clustering approach outlined above enables varying treatments of each unit in terms of inspection tasks, sampling and frequency. This cluster approach also extends to monitoring and simulation as different models that represent the range of behaviours across the field will need to be adequately

<!-- image -->

validated. Whilst clustering should be initially applied during the design phase, it should be reviewed during manufacturing, installation, and operation phases - including new clusters where latent degradation mechanisms emerge.

## 4. Prevention of marine growth

<!-- image -->

## 4.1. Project overview

The prevention of marine growth (PoMG) project was delivered by Endures in collaboration with KENT on behalf of the Floating Wind JIP.

Marine growth, also known as biofouling, can significantly affect the performance and structural integrity of offshore assets and its effect is still relatively unknown for large-scale floating wind assets. In the worst-case scenario, it could exacerbate fatigue and ultimate loads on floating wind systems due to factors such as added weight, altered geometry, and changes to surface texture. Over time, this can lead to significant damage, increased downtime, and higher operation and maintenance demands for large-scale commercial floating wind arrays.

The PoMG project aimed to improve understanding and quantification of the effects of marine growth over the lifespan of commercial floating wind assets. The focus of this project was to predict marine growth and its global variability, with the goal of enhancing the understanding of its cumulative impacts throughout a project's lifecycle. The project also reviewed current best practices for design, mitigation, and management strategies. Insights from other marine industries, such as oil and gas, were leveraged to address challenges associated with marine growth in the context of large-scale commercial floating offshore wind developments.

## 4.2. Project objectives

- 1. Map typical marine growth on various materials and surfaces and identify any variation dependant on geographical locations.
- 2. Understand the applicability of approaches and standards from other marine sectors, such as oil and gas, to floating offshore wind.
- 3. Investigate current standards related to marine growth and, where applicable, identify industry needs and knowledge gaps to assist in the development of commercial floating wind projects.
- 4. Identify technology solutions, focusing on passive solutions, that reduce marine growth over the lifetime of an asset.
- 5. Provide an understanding of any additional need for supply chain servicing specific to the floating wind sector.
- 6. Investigate the varying driving factors of different asset makeup such as foundation types, mooring and cable configurations, and varying geographical location.

## Methodology

## Literature review and stakeholder engagement

A literature review and stakeholder engagement were conducted across the offshore wind industry. This aimed to assess the existing data, approaches and standards available in the public domain, and its applicability to the offshore wind industry. The approach adopted is outlined below:

- · Reports, industry standards, case studies, and publicly available data were gathered from reliable sources such as academic publications, government documents, and industry white papers;
- · Representatives from renewable energy systems (with a focus on floating offshore wind) were engaged through a series of four stakeholder engagement workshops (SEW), including academic experts, certifiers, logistics experts, fouling-control companies and mooring systems experts on biofouling. Key knowledge gaps were identified during the SEWs, and the information collected was organised into topic areas to systematically address the key project objectives. This included categorising data into topics such as environmental factors, design practices, and regional variability.

## Critical analysis and modelling approach

The credibility, relevance, and limitations of the information collected were analysed and cross-referenced with findings from different sources to ensure robustness and to highlight knowledge gaps.

The stakeholder engagement and literature review informed the inputs for the modelling process, which drove the decision on marine growth levels and types, as well as foundation types, to be analysed and assessed over the lifetime of an offshore floating wind asset.

The modelling approach was as follows:

- · A coupled hydro-aero-elastic 15 MW turbine model with two irregular sea states (representing the requirements of FLS and ULS checks) was used as part of an assessment of eight mooring configurations (catenary, semi-taut and taut, varying between 70-1000 m), across two floater types (tension-leg platform (TLP) and semi-submersible foundation design), and including inter-array cables.
- · Derived load cases were developed, considering marine growth levels and types, water depth, mooring type, and foundation type. Four levels of marine growth were analysed for each configuration (no marine growth, low, medium and high). Marine growth was considered on the floater, mooring lines and inter-array cables.
- · Mooring line tensions and floater motions from time-domain analysis were compared to understand the effect of marine growth levels against the base case, with no marine growth.

## Comparative studies

Lessons learned and best practices from analogous industries or projects were incorporated to provide context and broader applicability of findings. This included monitoring approaches, modelling findings, and marine growth removal methods.

<!-- image -->

<!-- image -->

## Marine growth mapping

A map of typical worldwide marine growth variation was developed, based on available geographical data, and considering the growth effect on various types of materials and surfaces typically used in floating foundations, mooring systems, and dynamic cables.

## Synthesis of findings

The key insights from the previous steps we used to form a response to the project objectives. This included summarising trends, identifying challenges, and proposing recommendations for next steps.

The synthesis of the project's f indings was based on the process and typical effects of biofouling on manmade structures, outlined in Figure 8 below. As part of the process, the types of biofouling considered and not considered in current modelling and guidelines were identified, and the effects were assessed.

Figure 8. Effect of biofouling on man-made structures exposed to seawater environment.

<!-- image -->

<!-- image -->

## 4.3. Key findings

<!-- image -->

odynamic drag coefficient, mass and Current relevant standards for offshore wind recommend considering marine growth in design calculations (e.g. increase in hydr buoyancy) however, current data are limited and lacks detail.

- · Standards for offshore wind structures, such as DNV-OS-J101 or DNV-OS-E301, as well as standards from other offshore industries like ISO19901 from the oil and gas sector, recommend accounting for biofouling in design calculations.
- · These standards consider increases in hydrodynamic diameter, mass, buoyancy, and variations in the hydrodynamic drag coefficient due to marine growth-induced roughness. Importantly, these standards use information from a single source with data from only two sites in the North Sea, lacking taxa-specific data. This results in limited insights into the impact of relevant taxa like mussels, barnacles or algae.
- · While existing standards emphasise the importance of obtaining site-specific marine growth profiles, including recording and measuring marine growth, they do not provide detailed guidelines for conducting surveys for marine characterisation and may lead to inaccurate or conservative assessments of marine growth in specific environments.

Parameters essential to measure marine growth, including biomass and surface roughness, are missing or inconsistent.

- · Marine growth analyses of an offshore structure require data on parameters such as biomass, thickness of fouling, and surface roughness. However, biomass or surface roughness datasets are often missing, with gaps or limited to specific locations or regions.
- · Published data on fouling thickness should be expressed as density, in kg/ m3, to align with the models. However, it is often reported in kg/ m2, which poses difficulties when adjusting mass as marine growth thickness changes throughout the water column.

Soft fouling such as algae, is not typically included in calculations, leaving its impact unknown.

- · From the limited data available, only hard fouling was found to be characterised by thickness, roughness and biomass, while soft fouling, such as algae (e.g. kelps), is typically excluded from calculations.
- · Literature and guidelines rarely distinguish between hard and soft fouling when describing parameters like thickness, drag coefficient, or roughness. Therefore, the impact of soft fouling is unknown.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Available data on marine growth are highly site-specific and limited to the upper few meters of surface water.

- · Typical values for density, surface roughness, and site-specific formulas for thickness and drag coefficient are mainly available for the North Sea.
- · Engineers often rely on North Sea standards related to the oil and gas industries, which can lead to over-protection or failures due to inaccurate calculations. Marine growth data available is typically limited to the top few meters of surface water, neglecting deeper zones.

<!-- image -->

Marine growth can have a significant negative impact on interarray cable 'lazy wave' -profiles, with the effect being most pronounced in shallow water depths.

- · Static calculations indicate that marine growth can significantly impact the lazy-wave profile of the inter-array cable. Particularly for the shallow water configurations, where the interarray cable 'lazy wave' shape will not be maintained following the a ddition of marine growth. This is due to additional marine growth altering the cable's buoyancy profile, causing it to sink to the seabed and create touchdowns on either side of the cable's buoyant section.
- · In shallower waters, inter-array cables are more sensitive to weight and buoyancy changes than inter-array cables in deeper waters. Shallow waters lead to reduced water columns, which limits lazy wave profile and results in a smaller bending radius. Additionally, marine growth is found to be much more pronounced in the top 30m of the water column.

<!-- image -->

Marine growth can result in significant increases to inter-array cable tensions, with the effect being most pronounced in shallow water depths.

- · Inter-array cables are designed to not interfere with the mooring system and therefore produce little to no lateral load. This means that the tensions exhibited by inter-array cables are primarily due to the cable's self -weight and buoyancy characteristics. Across all configurations, an increase in marine growth resulted in altered cable characteristics, leading to greater inter-array cable tensions.
- · As interarray cable tensions are a product of the cable's self -weight, the greater the cable length the greater the tension. Therefore, increases in inter-array cable tensions appear to be more pronounced in shallow waters as the marine growth weight is proportionally greater when considering a shorter cable. This is further emphasised by the marine growth profile through the water column, as marine growth adherence reduces with an increase in depth.

## 4.4. Industry needs/innovations

<!-- image -->

It is necessary to conduct natural time-series of marine growth to address prediction uncertainties.

- · Commencing with natural time-series (NTS) observations of biofouling growth, including detachment events, will help reduce and eventually eliminate prediction uncertainties.

<!-- image -->

- · Monitoring these processes over extended periods, researchers can gain insights into the dynamics of biofouling and develop more accurate predictive models.
- · Accurate predictive models can enhance the reliability and efficiency of renewable energy installations.
- · Formulating correlations between environmental factors, materials, and the occurrence of biofouling species relevant to renewable energy development is also crucial. Understanding these relationships can inform the selection of materials and the design of structures to minimise biofouling impacts and improve operational longevity.

<!-- image -->

The industry must create innovative tools to fill the knowledge gaps in marine growth parameters that are necessary for accurate predictions.

- · Understanding the weight of biofouling and its impact on buoyancy and stability is crucial for maintaining the integrity of marine structures.
- · It is essential to determine if the weight of biofouling is evenly distributed along cables or concentrated in certain areas, which could pose additional risks.
- · Another important consideration is the timeline for a particular species to dominate a biofouling community, as this can affect maintenance schedules and the overall health of the ecosystem.
- · The influence of electromagnetic fields on the growth rate of biofouling organisms is also a key area of investigation, as it may inform the design and placement of underwater cables and structures.

<!-- image -->

Specific floating wind guidelines and standards should be developed and tailored based on NTS monitoring protocols, mitigation strategies studies and analysis.

- · Standards need to be adjusted to better serve new custom-made design guidelines, instead of adopting practices developed for the oil and gas industry.
- · The unique conditions and challenges faced by the renewable energy sector require tailored solutions that address specific biofouling issues, rather than relying on protocols that may not be fully applicable.
- · A shift towards bespoke guidelines will ensure that the renewable energy industry can effectively manage biofouling, optimise performance, and contribute to the broader goals of sustainability and environmental protection.
- · Through these concerted efforts, the industry can advance its technological capabilities and achieve greater resilience against the challenges posed by biofouling, such as maintaining the inter-array cable's profile and performance .

<!-- image -->

## 5. Large static pitch angles

## 5.1. Project overview

<!-- image -->

<!-- image -->

Static pitch angle refers to the tilt angle of the floating substructure. It plays a key role in the overall efficiency of a wind farm array and is therefore a highly discussed topic in floating wind, due to concerns about its potential impact on annual energy production losses and drive on design loads. This was confirmed in previous studies performed as part of Stage 2 Phase IV of the Floating Wind JIP that concluded that allowing larger static pitch angles (LSPA) of floating offshore WTGs from an early concept design stage can reduce the LCoE by enabling more compact floater designs, with associated reductions in cost. It was noted that increasing static pitch angles needs to be balanced with the resulting power production loss, along with the increased loads and motions during power production which could be experienced under high rotor thrust forces.

However, the effects of reducing the size of a floater are complex and design load case specific, depending on the dominant source of loading (e.g. wind, wave, coupling structural modes). Such changes can bring additional challenges including tower loads, blade clashing, and high rotor nacelle assembly (RNA) accelerations and can be heavily influenced by the WTG controller. It is also important to understand the subsequent impact of a particular concept at a farm level, allowing for a clear trade off on loads and power performance at a turbine level versus farm level where increased tilt can influence wake spreading and wake incidence on downstream turbines.

Quantifying the impact of a chosen mean static pitch angle in terms of AEP, loads and impact on floating foundation design is becoming ever more important, especially in a challenging market that requires certainty and confidence to progress. Therefore, having a set of tools and methodologies to quickly navigate this trade-off space easily at early project stages will help improve confidence in a chosen design, and ultimately inform better engagement with the relevant stakeholders as a project progresses.

## Project objectives

- 1. Understand the effects of static pitch angles and determine the conditions under which a trade-off between power generation and floater mass may justify greater static pitch angles.
- 2. Evaluate the different test case scenarios and floater technologies to determine how flexible the static pitch (loads on the RNA, power generation loss) can be, and how this affects the floating substructure design (mass, dimension, etc.), as well as the LCoE.
- 3. Assess the potential trade-off between power production and floating platform design (mass, dimensions, technology) when allowing higher static floating platform tilt as well as investigating the impact of deflection on wind farm-level wake effects and their influence on LCoE.

## Methodology

## Literature review and problem definition

A literature review was conducted to assess the most viable floating technology to take forward for detailed loads assessment in later stages of this project. This included the definition and impact

<!-- image -->

<!-- image -->

assessment of moving to LSPA against a broad set of criteria related to a floating wind energy system and LCoE.

Through a combination of stakeholder engagement and numeric modelling tools for floating dynamic analysis (Orcaflex) and wind farm energy production analysis (internal proprietary FLORIS tool), this study sought to understand the benefits and challenges of moving to LSPA designs above the current limits defined by the WTG original equipment manufacturers. Noting that stakeholder feedback from WTG OEMs and floating foundation designers during this project put this in the range of 5 to 7 degrees.

## Evaluation criteria

The following set of evaluation criteria was defined for each mean static pitch operating point:

- · Interface Load (ultimate limit state and fatigue limit state) impact: Understanding the impact of the WTG tower -floating foundation interface load as a function of increasing mean static pitch angle;
- · AEP impact: Understanding the impact of the AEP generated from a single WTG as a function of increasing mean static pitch angle;
- · Floating foundation mass savings: Understanding the impact of potential floating foundation mass savings as a function of increasing mean static pitch angle.

## Technology assessment

A detailed numerical analysis on four different LSPA models was created based on the Floating Wind JIP reference semi-submersible model defined in previous work packages 6 . The models were created using an internal scaling approach. This approach focused on characterising a set of potential designs through the modification of the column height, distance and radius (for a given WTG tower and rotor combination). An euclidean norm optimisation function was then defined to choose an applicable design at the following operating points:

- · LSPA3: The baseline (previously defined) Orcaflex model of the semi-submersible, operating at a mean static pitch of 3 degrees, coupled with the IEA 15 MW reference turbine;
- · LSPA6: A scaled model of the semi-submersible, operating at a mean static pitch of 6 degrees, coupled with the IEA 15 MW reference turbine;
- · LSPA9: A scaled model of the semi-submersible, operating at a mean static pitch of 9 degrees, coupled with the IEA 15 MW reference turbine;
- · LSPA12: A scaled model of the semi-submersible, operating at a mean static pitch of 12 degrees, coupled with the IEA 15 MW reference turbine.

The models were then used to perform the following assessments:

- · Behaviour of system mass (i.e. floating foundation mass and WTG tower) as a function of increasing mean static pitch angle;

<!-- image -->

<!-- image -->

<!-- image -->

- · Behaviour of interface loads (i.e. WTG -floating foundation interface) as a function of changing mean static pitch angle, alongside any notable design changes required to accommodate higher load levels;
- · Turbine performance, defined in terms of AEP as a function of changing mean static pitch angle.
- · Farm level assessment of expected yield for each of the four static pitch angle models defined was undertaken using the aforementioned FLORIS tool.
- · An LCoE assessment of the trade-offs of the WTG-floating foundation system against the impact on AEP at a wind farm level.
- · Stakeholder engagement to understand expected impacts and considerations of a given mean static pitch angle.

## Key assumptions

The following key assumptions were made for developing this study:

- · The IEA 15 MW WTG model was used to conduct this analysis.
- · The detailed models were derived in Orcaflex using a 15 MW reference semi-submersible platform defined in previous work packages. Loads were assessed at the global level and no detailed load levels were calculated on specific structural components of the semi-submersible.  Also, assessment of interface risk was kept strictly to the interface loads at the foundation -WTG tower connection;
- · Fullmodel performance was assessed only at a particular set of 'moderate' metocean conditions. 7 Only four models were evaluated; therefore, any 'optimum' point derived from this work should be viewed in the context of site conditions associated with a particular site, the specific dynamics of the sub-structure chosen for that project, and the behaviour of the WTG, chosen alongside the real WTG controller.

## 5.2. Key findings

<!-- image -->

6 degrees (in-line with current limits considered From the mean static pitch angles of 3, 6 , 9 and 12 degrees, the optimal mean static pitch angle was found to be in the range of 3 -for commercial and demonstration projects).

A set of representative design load cases were evaluated using the previously stated moderate environmental conditions for each model against the initial criteria identified. The key conclusions from these assessments were:

- · Interface loads increase as a function of mean static pitch angle, causing potential risk of redesign of WTG components : ULS and FLS WTG -floating foundation interface loads both increased as a function of the increase in the mean static tilt of the system. This results in the need to re-design specific components to handle the increase in ULS loads (i.e. WTG tower);

<!-- image -->

<!-- image -->

<!-- image -->

- · Potential foundation mass savings as a function of mean static pitch angle : There is potential for mass savings on the foundation as a function of the mean static tilt of the system. However, the net mass saving at high angles (i.e. above a mean static pitch of 9 degrees) was marginal because of the need to strengthen the WTG tower to handle the increase in ULS interface loads observed;
- · AEP reduction as a function of mean static pitch angle : There is a significant reduction in expected AEP as a function of increasing the mean static tilt of the system. This effect, at a turbine-level, dominates any potential benefit at a farm level, meaning this will significantly influence the applicability of larger angles.

Illustrate trends for these conclusions are represented in Figure 9 below:

Figure 9. Trends on foundation mass, tower mass and AEP as a function of increasing mean static pitch angle.

<!-- image -->

The conclusion of this assessment is that mass savings above a mean static pitch of 9 degrees would be limited due to the need to re-design and strengthen the turbine tower to handle an increase in ULS loads. Additionally, alongside a significant drop in expected AEP at high mean static pitch angles, there are no expected material benefits of considering angles above the operational limits currently defined as industry standard - typically between 5 and 7 degrees. A more detailed analysis on a project basis to fully understand the given trade-offs within that industry standard range is, however, recommended to better understand the expected system behaviour.

<!-- image -->

The core loss of power from a single turbine dominates the loss in AEP, for a given mean static pitch angle, outweighing any benefits at farm level from floating wind yield effects.

An analysis on floating yield effects (yaw oscillation, streamwise displacement and turbine tilt) was conducted to assess the net improvements in AEP as a function of moving to LSPA. This assessment was performed at a farm level, as opposed to a single WTG -floating foundation. All floating effects were investigated both individually, and in combination, on a hypothetical five by five and ten by ten grid layout at 4 rotor diameter (4D) and 10D spacings, respectively. The outputs of this analysis were compared against

<!-- image -->

<!-- image -->

the conclusions drawn from the single WTG -floating foundation assessment. These were used to inform whether there are any additional drivers missed that offer substantial improvements at larger mean static pitch angles.

The key conclusions of this analysis were:

- 1. When considering each floating effect in isolation, positive impacts on farm level yield were observed for the following effects:
- a. Yaw oscillation: The impact of oscillating yaw wake spreading was shown to be positive regardless of configuration but is greatest at lower spacings (i.e. 4D) when downstream turbines see a larger wake deficit;
- b. Platform Tilt: The tilt function vertically deflects the turbines wake to a degree which is dependent on the turbines tilt angle. This was not observed to have any material impact on AEP until above a mean static pitch angle of 9 degrees. The primary driver for this is that up until 9 degrees - the vertical wake deflection is not significant enough that it positively impacts the incoming wind velocity on multiple downstream rows.
- 2. Any positive impact observed at farm level, regardless of the mean static pitch angle considered, is low in comparison to the AEP loss of the single WTG -floating foundation system. This is shown in Figure 10, where the AEP loss from the assessment of a single WTG -floating foundation is comparable to the loss observed at farm level.

<!-- image -->

<!-- image -->

Figure 10. a) Total variation of AEP with LSPA as a percentage change with respect to the fixed case. Presented for each farm layout. b) Total variation of AEP with LSPA as a percentage change with respect to the baseline floating case (at a mean static pitch of 3 degrees), for each farm layout. The per-turbine AEP results from WP2 are also plotted (i.e. the summation of single turbine performance exclusive of wake effects).

<!-- image -->

For a given WTG -floating foundation combination, the AEP is significantly affected by both mean static pitch angle of the coupled system and pre-rotor tilt of the WTG.

It was well established through Orcaflex modelling that, for a single WTG -floating foundation system, the AEP reduces as a function of increasing mean static pitch angle. This AEP reduction is driven primarily by

<!-- image -->

<!-- image -->

the reduction in effective rotor wind speed, which itself is dominated by two effects: the platform tilt and the pre-tilt applied to the WTG rotor to prevent blade - tower clashing.

At small mean static pitch angles, the platform tilt is low and any impact on effective wind speed will be dominated by the pre-tilt applied on the rotor (which is captured in existing fixed power curves). However, at high mean static pitch angles, this effect becomes more nonlinear and the cumulative effect of platform tilt, plus pre-tilt, has a more material effect on the effective wind speed and hence power output of the WTG system. This conclusion is important for two reasons:

- · When conducting analysis at farm level (i.e. using a tool such as FLORIS for yield calculations) consideration of performance at higher mean static pitch angles must include an explicit characterisation of the pre-rotor tilt. This could either be from the modelled power curve directly or from a fixed-floating representation that accounts for the impact of pre-rotor tilt;
- · In conventional fixed turbine wake loss assessments, the wake direction aspects of pre-tilt are generally disregarded (i.e. small), although the effects of pre-tilt are included within the prescribed power curves and calibrated within the wake models. This warrants further review to ensure the various contributors to tilt are captured and included in a consistent manner at high mean static pitch angles.

<!-- image -->

For large mean static pitch angles the dominating effect on LCoE is the variation in AEP, as opposed to design changes to the turbine or platform.

The LCoE impact was assessed as a function of mean static tilt at turbine and farm level from previous analysis undertaken within the project, namely; AEP changes at farm level, platform mass savings as a function of increasing mean static pitch angle and tower re-design (i.e. mass increase to account for increased ULS loads) impact as a function of increasing mean static pitch angle. The conclusions were as follows:

- · At smaller mean static pitch angles, the loss in AEP is compensated by reductions in mass and thus, relatively little change is observed in overall LCoE;
- · Above a mean static pitch of 6 degrees, the LCOE begins to rise rapidly driven by an increase in AEP loss per degree, alongside diminishing reductions in foundation mass and tower mass increases due to load and not the stiffness of a driven tower.

<!-- image -->

Environmental factors are observed to have a second order impact on the performance of the coupled system at different mean static pitch angles.

The results from the core work packages were determined using the 'moderate' 1 conditions used in previous analysis. This means that the trends identified depend on: the site mean wind speed (and associated Weibull distribution), a single turbulence intensity distribution per wind speed bin, a single wave profile per wind speed bin, and a single turbine model.

<!-- image -->

<!-- image -->

To broaden understanding of the applicability of the conclusions a sensitivity study was conducted to explore the impact of changing the following:

- · Mean site wind speed: through variation of mean wind speed and associated Weibull parameters;
- · Wind variation: through variation of wind speed and turbulence intensity;
- · Wave variation: through variation of wave height and wave period at specific wind speed bins.

The core conclusions from the sensitivity analysis were as follows:

- · At high mean wind speed, sites with higher wave loading and lower extreme winds could benefit from larger mean static pitch angles. These factors could be considered when fine tuning the inclination targets;
- · Lower mean wind speed sites, with highly wind driven loading, will be less favourable for large mean static pitch angles.

These conclusions should be considered alongside RNA mass, turbine thrust, peak thrust wind speed and AEP stability (with respect to inclination) when considering initial mean static pitch angle target and limits.

## 5.3. Industry needs/innovations

<!-- image -->

sessed as a function of tilt angle and preWhen assessing the potential power loss at both turbine and farm level, turbine specific power performance should be as rotor tilt.

The impact of AEP loss coupled with increasing interface loads as a function of increasing mean static pitch angle has been clearly identified as key driver which may limit the adoption of large mean static pitch angle designs. However, AEP, at a given mean static pitch, will also be influenced by the pre-rotor tilt and WTG controller dynamics, both of which are specific to a particular manufacturer and model. This creates dependence on early engagement with turbine manufacturers to properly ascertain the expected impact on AEP for a chosen platform operating point.

Therefore, to help improve early-stage project assessments, the following actions are recommended:

- 1. Definition of an AEP versus platform tilt loss viability curve at the early project stages: explicit consideration of the expected AEP loss as a function of tilt angle from the turbine manufacturer at an early stage will help provide confidence and understanding of the wider trade-offs required to optimise the WTG -floating foundation system;
- 2. Exploring the impact of including pre-rotor tilt in wake calculations: assessing the potential impact of including this effect at farm level should be undertaken when a mean static pitch angle of 6 degrees or more is being considered for a given project.

<!-- image -->

The trade-offs of having lighter floating foundations and maintaining mean static pitch through active trim systems should be better considered.

Currently, there is not an industry-agreed set of methods to fully understand and quantify the benefits and drawbacks of an active ballast system in the context of AEP design optimisation for a floating wind project.

<!-- image -->

<!-- image -->

Better defining and understanding the approach to characterise an active ballast system will allow for a more informed view on the potential net savings of lighter floating foundations at a given target mean static pitch angle. This could include considering non-steady state performance by fully evaluating the following parameters:

- 1. System accuracy and activation strategy;
- 2. Transient response to changing environment;
- 3. System response time and any increase to downtime (i.e. pre-ballasting);
- 4. Ballast system downtime;
- 5. Power consumption.

<!-- image -->

The target and optimal inclination should be considered at a system level (i.e. for a given WTG -floating foundation) and on a site-by-site basis.

Whilst the conclusions of this study suggest that there is no net benefit beyond existing mean static pitch limits, it should be noted that this is in the context of just one WTG -floating foundation combination. In practice, an optimised design will be a function of a thorough assessment of both the chosen WTG and floating foundation, and should be conducted holistically and at a system-level to ensure the appropriate understanding of trade-offs across all components. This would be relevant for the higher end of the industry standard range defined (i.e. a mean static pitch of up to 7 degrees of platform tilt given the trend on observed LCoE / AEP), and could still be viable based on the following second-order observations within the study:

- 1. Load performance of key turbine RNA sensors suggested there is no step change in structural loading on the RNA (i.e. blade/nacelle) when moving to mean static pitch angles beyond 6 degrees. However, this observation may be site-dependent and hence should be considered on a project basis;
- 2. Similarly, accelerations of the nacelle and platform do not have a significant step change as a function of mean static pitch, suggesting that there is no major increase in risk of new failure modes compared to the baseline;
- 3. Between a mean static pitch of 6 and 9 degrees there is still potential for significant mass savings on the floating foundation.

## 6. Wet storage and quick connectors of dynamic cables

<!-- image -->

<!-- image -->

<!-- image -->

## 6.1. Project overview

As the commercial pipeline for floating offshore wind farms grows, there is an increasing need for technologies to improve installation and O&amp;M procedures. One possible route for carrying out major O&amp;M operations is to undergo tow-to-port (TTP) of the floater and turbine. TTP maintenance requires the connection and disconnection of dynamic cables (as well as mooring lines) from the FLW turbine, an activity that needs to be executed with minimal risks, while maintaining the electrical connection in the array string.

The installation and hook-up of floating wind turbines is a timely operation involving multiple equipment owners, multiple physical interfaces, and various installation disciplines. The dynamic power cable is a critical component in the wind turbine setup, as well as the connection system of the dynamic power cable. Failure of these constituent parts of the connection system will jeopardise the wind turbine operation as well as the ability to generate and export energy.

Quick connector technologies can streamline installation by reducing both time and complexity during initial operations. By enabling wet storage, they also provide flexibility during installation as the cables can be installed before the wind turbine, leading to greater efficiency and cost savings in the long term. These technologies can also help reduce operating costs over the life cycle of the FLW turbine by reducing downtime of power generation, should a major repair be required.

The wet storage and quick connectors for dynamic cables (SCC) project delivered by 2H Offshore Engineering built on previous project results to understand the technology options available to enable quick (dis)connection, along with their risks and limiting factors. The project aimed to understand and evaluate the differences between dynamic cable connection technologies and determine factors contributing to these systems' commercial feasibility.

Project objectives

- 1. Understand and evaluate different connection technologies for dynamic cables, focusing on the connection procedure, speed of connection, and duration of connection operations compared to traditional methods;
- 2. Understand different wet storage options when disconnecting the dynamic cable for TTP operations;
- 3. Compare relevant connection technologies to determine the most feasible and safe options for the connection and disconnection of dynamic cables in commercial floating offshore wind farms.

## Methodology

## Problem definition

A technology qualification basis (TQB) was initially developed to define the optimal parameters for the assessment of quick connector technologies and configurations. The TQB, designed to support the evaluation of current and emerging market technologies, was used to identify the functional requirements and constituent components required for effective wet storage and quick connection.

Table 1: The Technology Qualification Basis outlines the optimal parameters for the assessment of connector technologies and configurations.

| Parameter/criteria                 | Qualification requirement                                                                                                                                                                                                   |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Required constituent technology    | All constituent technologies are identified.                                                                                                                                                                                |
| Environment                        | Any environmental limitations for the specific technologies are identified.                                                                                                                                                 |
| Marine growth                      | Marine growth should ideally not be considered a concern for the connection and disconnection process. Identify if cleaning is expected and if the bend stiffener latching mechanism is likely to be remotely disconnected. |
| Service life                       | The desired service life of the connection system is 35 years.                                                                                                                                                              |
| Wet storage duration               | The wet storage will be required for a maximum of 2 years.                                                                                                                                                                  |
| Continued power during wet storage | The connection technology or configuration should provide continued power during wet storage, assessed against the daisy chain and the star and fishbone cable configurations, (Figure 11).                                 |
| Floater type                       | There should be no restriction on the floater type for the connection technology or configuration.                                                                                                                          |
| Water depth                        | The maximum water depth is expected to be 1,500 m. This is applicable if the connection is laid on the seabed for extended periods during O&M operations.                                                                   |
| Voltage rating                     | The target voltage rating is 66 kilovolts (kV) and 132 kV.                                                                                                                                                                  |
| Installation efficiency            | The connection technology or configuration must improve the efficiency of the installation and hook-up connection duration, with a baseline estimated to be 56 hours (site dependent).                                      |
| Disconnection and reconnection     | Capable of up to 50 mates and de-mates for subsea wet mate and dry mate connectors (as per IEC/IEEE 61886-1). Capable of 5 connections and disconnections for the entire cable assembly.                                    |

## Market review and stakeholder engagement

A comprehensive market review was conducted to evaluate the availability of quick connector technologies in the market today. This review involved consulting 18 key industry suppliers, including system-level connector technology providers and companies closely associated with connection technology, such as cable manufacturers, platform designers, turbine OEMs and installation contractors.

The objective was to understand the capabilities of existing technologies, identify gaps in offerings and gather insights into the latest developments. Through this process, valuable information was gained that

<!-- image -->

<!-- image -->

<!-- image -->

informed the selection of potential configurations and technologies, guiding the overall evaluation and decision-making for the project.

## Technology assessment

Three possible connection configurations were identified:

- 1. Disconnectable FLW turbine connections that float on the surface of the water during wet storage;
- 2. Disconnectable FLW turbine connections that are submerged and buoyant during wet storage;
- 3. Modified traditional configuration:
- ➢ Disconnected and laid on the seabed or supported with a temporary floating structure.
- ➢ Disconnected subsea and not at the FLW turbine.

Each configuration requires specific system-level connection technologies, along with constituent level technologies to ensure the wet storage capability. Constituent level technologies including mechanical hang-off, wet mate connectors, dry mate connectors and bend stiffener connectors were investigated, along with several other connector technologies. Analysis of the mooring systems and buoyancy required for wet storage was not included as part of this project.

A shortlist of connector technologies and configurations was selected, and a thorough life assessment conducted against the current methods for dynamic cable termination. The life assessment considered the alignment with the TQB and also the technical and operational feasibility, technology readiness level, manufacturing capabilities, operational considerations (such as safety and risks) and indicative costs of these technologies. The assessment also included the definition of wet storage options for the technologies identified and provided guidance on the maximum length of time and environmental conditions under which wet storage is possible as part of the design criteria.

Figure 11. Simplified illustrations of a) daisy chain array; b) fishbone configuration; and c) star configuration. OSS = offshore substation. Sources: WFO, information from Siemens Subsea. 8

<!-- image -->

8  World Forum Offshore Wind (2024) Floating Offshore Wind Dynamic Cables: Overview of Design and Risks - Link

<!-- image -->

## 6.2. Key findings

<!-- image -->

No existing connection technology addresses all the requirements for quick connection and wet storage of FLW turbines.

- · Currently, no singular technology addresses the requirements for quick connection and wet storage required for floating wind as established in the TQB. Each of the technologies and configurations assessed required integration with technology supplied by other parties, as outlined in Table 2. The connection of the dynamic power cable to a FLW turbine is a complicated system, with multiple physical interfaces (that are the shared responsibility of different hardware suppliers) that must complement one another.
- · Additional constituent technologies can be combined with modified traditional connection configurations to enhance functionality. These combinations can improve efficiency and also be considered a tool to assist wet storage.
- · System-level connection technologies are being developed for the purpose of integrating essential constituent technologies that offer greater functionality for quick connection and wet storage capability. Some of these new technologies are looking beyond the dynamic power cable and are also targeting a comprehensive wet storage solution, including the mooring lines of the floater. The interaction with the mooring lines was not assessed as part of this project.

Table 2: Matrix of FLW turbine connector technologies and configurations and the limiting constituent technology parts. * = site specific

| Constituent technologies                 | Constituent technologies   | Disconnectable FWT connection - floats during wet storage   | Disconnectable FWT connection - submerged and buoyant during wet storage   | Modified traditional connection (disconnect at turbine)   | Modified traditional connection (disconnect subsea)   |
|------------------------------------------|----------------------------|-------------------------------------------------------------|----------------------------------------------------------------------------|-----------------------------------------------------------|-------------------------------------------------------|
| FLW turbine connection assembly hardware | Electrical connector       |                                                             | Wet and dry mate connectors                                                | Dry mate connectors                                       | Wet and dry mate connectors                           |
| FLW turbine connection assembly hardware | Mechanical hang off        |                                                             | Submersible or system-integrated hang off                                  | Submersible mechanical hang off                           |                                                       |
| FLW turbine connection assembly hardware | Bend stiffener connector * |                                                             |                                                                            |                                                           |                                                       |
| FLW turbine connection assembly hardware | Bend stiffener *           |                                                             |                                                                            |                                                           |                                                       |
| FLW turbine connection assembly hardware | I-tube/ interface          | Disconnectable I- tube                                      | Connection system                                                          |                                                           |                                                       |
| Other required hardware                  | Other required hardware    |                                                             | Subsea anchors and mooring lines                                           | Hardware solution to connect two cables                   |                                                       |

<!-- image -->

<!-- image -->

Continued power transmission

Possible with daisy chain configuration

Connection technology dependent

Reconnect cable at surface and lay on seabed

Possible with fishbone or star cable layouts

The constituent technology part is not expected to be a barrier as it is either not applicable, relies on existing hardware or accessible hardware.

Constituent technology is available but may present a potential limitation.

The constituent technology part required is a new or differentiating technology.

Figure 12: Colour code key for the constituent technology parts described in Table 2.

Temporary wet storage of dynamic power cables on the seabed adds significant risk for cable and constituent technology damage.

- · Laying the cable on the seabed during wet storage risks damage to the cable due to interaction with the seabed. Mitigation techniques include detailed seabed survey plants, temporary cable routings to suit local topography and detailed analysis of the expected cable movement due to currents, with the development of relevant mitigation plans. Despite mitigation measures, laying the cable on the seabed will always encounter risk of cable damage and long-term integrity of the cable may be impacted following a period of wet storage on the seabed.
- · In some configurations, the connection assembly - including the mechanical hang-off connected to the power cable - may be submerged for a period of time for wet storage. Additional risks include corrosion of the connectors, marine growth on the mechanical components and compatibility of connection parts with seawater.
- · Another configuration option is to wet store the connection system in the water column, using buoyancy modules to support the power cable or additional constituent technologies in the water column if there is no buoyancy built into the connection system. This solution requires the installation of a dedicated mooring system for station keeping and a market buoy to aid recovery and reconnection.  There is, however, a high risk of compromising cable integrity in the wet storage configuration when suspended in the water column.
- · The design of the subsea power cable must consider the anticipated wet storage scenario along with the in-place configuration connected to the FLW turbine. The design analysis for the power cable should include extreme and fatigue loads. Power cable design feasibility is expected to be challenging in shallow waters and harsh environments such as the northern North Sea.

Technology providers are uncertain about the ownership of the cable connection for future floating offshore wind projects.

<!-- image -->

<!-- image -->

<!-- image -->

- · A common concern raised during the market review and engagement phases of this project is the uncertainty over who will ultimately be responsible for the power cable connection to a FLW turbine. Providing clarity over the ownership and responsibility could ensure future compatibility between constituent parts.
- · As with the oil and gas industry, it is unlikely that a single hardware supplier will assume ultimate design or installation responsibility for the entire connection assembly due to the liability exposure from 'others' hardware.

<!-- image -->

There are connection technologies and configurations that can offer wet storage and increase connection efficiency compared to conventional connection methods.

- · Out of the connection technologies and configurations assessed as part of this project, some solutions can offer wet storage whilst increasing connection efficiency. The connection and hook-up process could be increased by sixfold, taking between 4 and 6 hours, against the baseline of 56 hours. This significantly improves the current method of cutting and removing connection hardware and laying the power cable on the seabed.
- · Based on the market review and responses from suppliers, the system level connection technologies that include wet mate connector technology are estimated to have a significantly higher CAPEX (2 to 6 times) than a traditional connection configuration, which uses dry separable (non-submersible) electrical connectors.
- · O&amp;M strategies will be a driving factor in the technology selection and configuration, and improvements in operational efficiency offer a potential reduction in operational expenditure (OPEX) compared to traditional connection configurations.
- · A full cost analysis should be conducted for each technology and configuration identified, considering the wind farm size, layout and developer operational strategies, such as the requirement for TTP maintenance.

<!-- image -->

The reliance on integration with constituent technologies may be the limiting factor for readiness of 66 kV and 132 kV connection systems.

- · For the category of connector technologies which are disconnectable and can be submerged and buoyant during wet storage, the limiting factor for 66 kV is the qualification of wet mate connector technology. Through industry engagement, it is understood that several wet mate connectors are in the advanced stages of TRL and are on track for qualification in 2025. This would enable connector technologies in this category to be qualified between 2027 to 2030.
- · When considering 132 kV compliant systems, the limiting factor for the connection technology is the 132 kV wet mate connector. Availability of connectors in a 132 kV system requires a 5 to 9 year development period when market conditions are considered favourable for technology suppliers to begin major investment.

<!-- image -->

<!-- image -->

- · A modified traditional connection configuration using dry separable (non-submersible) electrical connectors is type qualified for 66 kV and only requires qualification of some of the constituent hardware to meet 132 kV.
- · Dry separable connectors rated to 132 kV are used in land applications and would not require specific qualification for its use offshore. Enabling wet storage capability would require redesigning constituent components for larger electrical connectors, and a qualification programme for 132 kV would be required.
- · The bend stiffener and bend stiffener connector are not technically designed for a given voltage rating. Therefore, validating existing qualified hardware with respect to size and external loading limits applicable for a 132 kV would likely not require new hardware or qualification.
- · Similarly, a concern raised during the market review and engagement is the uncertainty of future cable layout configurations for commercial floating wind farms to use either a daisy chain layout versus a star or fishbone layout. This challenge was one of the hindering factors for developing a continued power solution with a daisy chain cable layout for certain technologies.

## 6.3. Industry needs/innovations

<!-- image -->

suppliers for each of the constituent parts of The development of a framework for qualification of cable connection systems to FLW turbines would provide more guidance to the overall system.

- · The constituent technologies that make up a dynamic power cable connection system are provided by multiple hardware suppliers, covering multiple disciplines. Each technology has a dedicated design code that is followed in full, or in principle if the scope of the code lags behind the development of the technology.
- · There is not a single design code or industry guidance document for the qualification of the entire connection system of a dynamic power cable. The lack of cohesion in the set of standards followed by each company results in a lack of standardisation of the connection system. A lack of standardisation in the qualification programme can encourage innovative technologies to be developed but can increase risk around the final qualification standard for the technology.

<!-- image -->

Development of a design code for qualification of electrical connectors of voltage higher than 36 kV.

- · The main code for designing and qualifying wet mate electrical connectors is IEC/IEEE 61886- 1, which applies to voltages up to 36 kV. Technology providers currently developing 66 kV wet mate connector technologies each follow their own framework for qualification, the details and results of which are not known.
- · The development of design standards for 66 kV and 132 kV wet mate electrical connectors should be considered a priority task by the industry.
- · The availability of qualified wet mate connector technology is driving the schedule for qualification of 66 kV system level connection technology and should also be prioritised.

<!-- image -->

<!-- image -->

<!-- image -->

Conduct further assessment and validation of wet storage dynamic cable configuration(s).

- · Nearly all system-level technologies for dynamic power cable connection systems state they can provide a submersible wet storage configuration during TTP maintenance of the FLW turbine. However, further analysis is required to assess the dynamic power cable 's response and ensure that the wet storage configuration does not affect cable integrity.
- · Further assessments should be conducted to understand extreme load and fatigue performance, considering a number of lazy wave 66 kV power cable configurations, different mooring systems and different environmental conditions.
- · To achieve the submerged wet storage configuration solution, a mooring system will need to maintain station-keeping of the power cable termination within the water column. The number of mooring lines required, water depth limitations, and whether these systems are permanent fixtures or temporary installations is currently unknown and should be the subject of further analysis.

## 7. Guidance for dynamic cables

## 7.1. Project overview

<!-- image -->

<!-- image -->

The guidance for dynamic cables (GDC) project was delivered by 2H Offshore Engineering in collaboration with Vekta on behalf of the Floating Wind JIP.

Dynamic power cables are critical components in floating offshore wind projects and in offshore wind more broadly, power cable technology has not proved to be as reliable as design outcomes suggest.  Subsea cable failures are one of the main contributors to financial losses in the global offshore wind industry. However, many of these incidents could be avoided with a better understanding of the risks of the system and associated mitigation techniques.

The aim of this project was to examine the existing guidelines, methodologies, and cross-industry standards for dynamic cable fatigue assessment. In addition, a guideline document has been developed for use by Floating JIP developers and their supply chain.

## Project objectives

- 1. Understand and review, within the offshore wind and analogous industries, the existing guidelines for fatigue design in dynamic high voltage power cables.
- 2. Engage  with  the  relevant  stakeholders  across  offshore  wind  and  analogous  industries  to  better understand the design requirements of dynamic cables.
- 3. Develop a dynamic cable fatigue assessment and lifetime prediction guideline document to support the warranty and insurability of this equipment.

## Methodology

## Literature review

A comprehensive review of a range of literature sources, including design codes and academic papers was undertaken. The review captured:

- · existing power cable fatigue prediction methods, including mechanical fatigue, electrical aging, thermal issues, and cyclical stressed on both the power cable as a whole, and the individual components that make up the high voltage power cable;
- · design challenges, including the management of components especially sensitive to fatigue such as the conductor, metallic screen, and tensile armour, and extrapolating data from oil and gas to offshore wind;
- · testing regimes proposed to perform fatigue and lifetime assessments for offshore wind dynamic power cables and in complementary industries such as oil and gas.

## Preliminary guideline document

Based on the outcomes of the literature review, a draft guideline for dynamic power cable fatigue assessment was produced.

<!-- image -->

<!-- image -->

The guideline details the best practices and methods to perform fatigue assessment and lifetime prediction of dynamic power cables, covering both mechanical and electrical design aspects for inter-array and export cables. In addition, it provides guidance on the steps required to undertake a fatigue assessment.

## Stakeholder engagement

A wide range of stakeholders including vendors, certification bodies and offshore wind developers were engaged during this project to give expert input on a range of topics regarding the fatigue of dynamic power cables.

These engagements helped refine the guideline for dynamic cable fatigue assessment and to address gaps and questions previously identified in the literature review.

## Case studies for sample applications

To test the methodology proposed within the draft guideline document, and to identify areas for improvement in this methodology, a fatigue and lifetime case study of a HV floating wind power cable was undertaken.

The case study considered a small wind farm consisting of: four floating wind turbines connected in a daisy chain configuration; a generic 66 kV power cable cross section; a reference 15 megawatt floating offshore wind turbine on an associated semi-submersible substructure; 200m water depth, and typical environmental conditions for the North Sea. Simulations were carried out using a range of tools - including SimScale UFLEX, Orcaflex, and Shear7 - to complete each of the steps in the fatigue and lifetime assessment guideline. Based on these studies, a range of improvements were identified and implemented in the guideline.

## Final industry guideline document

The final version of the power cable fatigue assessment guideline was prepared considering inputs from the Floating Wind JIP partners and additional stakeholder engagement. This document is currently exclusively available for Floating JIP partners who may share it with their supply chains.

## 7.2. Key findings

<!-- image -->

Cable temperature is the predominant factor when considering electrical loading as a cause of mechanical fatigue.

- · Assuming that the HV power cable is adequately designed (free from contaminants, manufacturing defects, installation damage, or operational damage) it is considered that there are no electricalonly failure modes that can cause cable fatigue damage or decrease its lifetime.
- · The variation of effective wind speed over time is directly related to power production of the wind turbine generator. This, in turn, impacts the magnitude of electrical current transmitted through the power cable and therefore its temperature variation.
- · Cable temperature fluctuations caused by these electrical phenomena impact cable properties and exacerbate the mechanical fatigue of cables.

<!-- image -->

<!-- image -->

<!-- image -->

Cable thermal analysis is an important step in assessing the mechanical fatigue of dynamic power cables for floating wind.

- · The power cable properties are significantly affected by temperature and therefore cable thermal analysis should be carried out to establish the temperature in cable cross-section components and how these vary during the wind farm lifetime.
- · Thermal analysis should be conducted to determine the cable's temperature under varying operational loads and environmental conditions, including in the impact of marine growth, presence of ancillary equipment and cooling from sea currents.
- · Geometry, materials and modelling approach for ancillary equipment have an important effect on the cable temperature results, therefore project specific data should be used and care taken to model accurately as well as consider heat transfer along the cable. Examples of cable thermal analysis are shown in Figure 13.
- · Results from the thermal analysis should be used as inputs to the cable local analysis (see Figure 13 below).
- · Load case matrices used for the assessment of cable fatigue should consider temperature associated with both the load case's environmental and operational conditions.

Figure 13. Example of Cable Thermal Analysis Results with Buoyancy Module and inside Bend Stiffener

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

There is a strong interaction between local and global analysis for mechanical fatigue calculation of dynamic power cables for floating wind.

- · Local analysis that focuses on a specific region or component of the structure should be carried out to calculate cable properties such as bending and axial stiffness for input into a global analysis which, in turn, considers mechanical fatigue across the entire system.
- · Local analysis can be used to obtain stress (or strain) transfer functions. These functions help in translating global curvature loads into detailed stress or strain distribution at the component level. This process helps to accurately predict fatigue damage in specific sections of the cable.
- · Factors that influence local analysis outputs and that should be taken into account include temperature, pressure, tension and friction.

<!-- image -->

Project-specific data should be incorporated as early as possible in the fatigue calculation of power cables to minimise assumptions and uncertainties.

- · Fatigue damage calculation of power cables is sensitive to inputs such as cable cross-section and fatigue details (e.g. SN curve, which shows the relationship between the stress applied and the number of cycles to failure the component can endure under cycling loading), marine growth profile, ancillary equipment, metocean conditions, and the overall floater system.
- · Assumptions made during the input phase of fatigue analysis can alter conclusions and lead to results and designs that are either overly or underconservative regarding a cables' resistance to fatigue loading.
- · Although front-end engineering design and earlier stages are typically carried out with some assumed data, it is recommended that wind farm site-specific data is incorporated as early as possible in the design process.

<!-- image -->

e calculation of high voltage power cables in Data gathering, thermal analysis and local and global property analysis should be followed to ensure accuracy in fatigue lif floating offshore wind.

- · The following key steps should be observed in for a fatigue assessment, as summarised in Figure 14:
- a. Input data gathering should be project-specific and provided by equipment vendors to minimise assumptions and reduce uncertainties. Assumed design data should be avoided since it can result in under and over-conservative fatigue results.
- b. Thermal analysis should be carried out to establish the temperature variation at the cable cross-section components for a range of electrical loadings (and wind speeds) expected during the wind farm life.
- c. Local analysis of cable properties should be developed for the range of temperatures established in the thermal analysis, including bending stiffness, axial stiffness, torsional stiffness, and stress and strain transfer functions.
- d. Global analysis should incorporate the cable properties developed in the local analysis and be carried out to calculate fatigue damage at the power cable due to global loads (e.g. wave and wind fatigue analysis and Vortex Induced Vibration (VIV) analysis).
- · The inputs and outputs of the analysis listed above are all interdependent on each other. Managing data exchange between these analysis activities and the iteration of varied datasets is therefore essential to achieving a final design of the power cable.

<!-- image -->

<!-- image -->

- · The level of detail of the fatigue analysis should increase as the project advances from feasibility to detailed design.

<!-- image -->

Figure 14. Global, Local and Thermal Cable Fatigue Analysis Flowchart

<!-- image -->

## 7.3. Industry needs/innovations

<!-- image -->

Further research is needed to quantify the extra heat generated by friction between cable components under dynamic motion.

- · Cable temperature has an impact on the cable properties and fatigue damage accumulation, however there is limited publicly available research about the amount of heat generated by friction between the cable cross-section components due to dynamic motions.
- · Calculations of cable temperature without taking into account the extra heat generated by friction between cable components due to dynamic motion can result in under-conservative temperature results, increasing cable failure risk.
- · Understanding how much extra heat is generated by friction between cable comments is key for accurate cable design.

Guidance for conducting Vortex Induces Vibration (VIV) of dynamic power cables is needed in the industry.

- · VIV is highly dependent on the parameters selected for analysis and there is currently uncertainty as to the set of parameters that give the most accurate results.
- · There is limited published data concerning numerical analysis calibration based on VIV testing results for dynamic power cables.
- · Specific guidance for VIV of dynamic power cables should be developed through further testing and calibration of design tools.

<!-- image -->

Development of best practices for assessing fatigue of individual components within the cable cross section is required.

- · The fatigue assessment (e.g. SN Curves) of power cable conductors is very complex due to the presence of effects such as friction, abrasion, or the notch effect between wires.
- · The metallic screen, a critical component of the cable cross section, also presents significant modelling challenges.
- · Temperature is a critical variable when generating SN curves for power cables, and the inclusion of this parameter adds to the complexity of these fatigue assessments.
- · The development of a standardised methodology for the assessment of fatigue in power cables is recommended to simplify the generation of SN curves (or similar).

<!-- image -->

Further research is needed for the calculation of fatigue damage specific to nonmetallic components.

- · The literature review and stakeholder feedback highlight that non-metallic components of the power cable are less sensitive to fatigue than the metallic components.
- · There is no standard or recommended methodology for calculating the fatigue of non-metallic components such as cable insulation, however current methodologies proposed include SN curves and crack propagation.
- · Fatigue calculation for non-metallic components of power cables is therefore an area that needs further research and guidance.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Benchmarking of all the software tools used in floating wind fatigue assessments must continue.

- · Due to the early nature of floating offshore wind, there is a general need to continue the industry efforts to benchmark and validate the software tools, models, and methodologies used in HV cable fatigue design.
- · It is recommended that this benchmarking and validation is conducted against test data (e.g. a hysteretic curve) and data collected from instrumentation installed on high voltage power cables (e.g. curvature in cable) to identify discrepancies and improve the precision of fatigue life predictions.

## 8. Power curve validation

## 8.1. Project overview

<!-- image -->

<!-- image -->

The power performance assessment of a wind turbine generator is performed following the standards published by the International Electrotechnical Commission (IEC). The standards describe the methodology that should be followed, the atmospheric parameters that should be measured, and the corresponding instruments that should be used in the context of power curve verification and validation (PCV).

Key industry stakeholders, including original equipment manufacturers, wind energy project developers, wind light detection and ranging (LiDAR) manufacturers, floater designers, and technical advisors, recognise the existence of these standards. However, since this methodology has been developed with a focus on fixed-bottom wind turbines, current standards do not address the challenges encountered when performing a PCV of a floating offshore wind turbine. Therefore, there is a need for floating wind specific methodology that will lead to a new standardised practice on how to perform PCV for floating wind turbines.

The Power Curve Validation for Floating Offshore Wind Turbines project was delivered by the Technical University of Denmark (DTU) on behalf of the Floating Wind JIP. The aim of this project is to enhance the understanding of the processes that have an impact on the power curve validation for FOWT and to identify the methods that can be used as a basis for power curve validation in floating wind turbines.

## Project objectives

- 1. Determine the key parameters which need to be considered for power curve validation of FOWTs.
- 2. Propose a wind speed measurement uncertainty assessment for power curve validation.
- 3. Understand which parameters and wind reconstruction methods should be used as a basis for power curve validation on floating wind turbines.

## Methodology

To understand current power curve measurement and validation methods and determine the uncertainties faced by floating offshore wind turbines, as well as model wind measurement scenarios in these assets, the following activities were undertaken.

## Literature review and stakeholder engagement

A literature review focused on identifying the state-of-the-art related to power curve validation of FOWTs was conducted. It aimed to determine the key challenges connected to floating wind turbine power curve validation and identify the most suitable technology for inflow wind measurements.

Key stakeholders were engaged to gather feedback on the development methodology needed to achieve power curve validation of FOWTs.

## Technology assessment and key assumptions

An uncertainty estimation for nacelle-mounted LiDAR wind speed measurements on an FOWT was performed to provide recommendations on which inflow characteristics and wind turbine motion parameters have the largest impact on the accuracy of wind LiDAR observations. This investigation was

<!-- image -->

<!-- image -->

performed by modelling the operation of nacelle-mounted wind LiDARs that were subject to both ideal motions as well as using motion data from the operating Hywind Scotland floating wind farm.

Furthermore, a nacelle LiDAR hub height wind speed estimation for FOWT power curves was conducted using OpenFAST software. This investigation initially focused on the study of the motion of reference FOWT models under various environmental conditions. Subsequently, the nacelle-mounted wind LiDAR uncertainty model was applied to several test cases, corresponding to different FOWT models and wind LiDAR types, as well as the range of environmental conditions.

The estimation of the hub-height wind speed of a nacelle-mounted wind LiDAR installed on a FOWT was compared to the one derived by a wind LiDAR installed on a fixed-bottom wind turbine used as a reference. Deviations between the two are considered a bias, i.e. a systematic error in the estimated hub-height wind speed.

The biases and uncertainties of hub-height wind speed estimations were investigated based on a nacelle-mounted wind LiDAR, assuming:

- · A technology-agnostic wind LiDAR that can acquire at least four measurements at two different heights, with two measurements being below the hub height and two above. This setup enables deriving the hub-height wind speed and direction, as well as the shear and veer of the inflow wind.
- · That the wind LiDAR can provide observations at an upwind distance equal to 2.5 times rotor diameters.

An assessment of the impact of the motion of a FOWT on the measurements acquired by a nacellemounted wind LiDAR was undertaken, with a sensitivity analysis considering three rotational degrees-offreedom (yaw, pitch, and roll) and using the three translational degrees-of-freedom (heave, sway, and surge) to verify the impact motions.

Aeroelastic model simulation of two wind turbine reference models, National Renewable Energy Laboratory (NREL) 5 MW and IEA 15 MW, using OpenFAST was performed. The response of the two wind turbine reference models on two types of floaters, a spar and semi-submersible was investigated through over 6000 simulations. The variations in these simulations included:

- · five different wind turbine and floater configurations, including two turbine types (NREL 5 MW and IEA 15 MW) and three substructures (spar, semi- submersible, in addition to a bottom-fixed structure);
- · two  wind  LiDAR  configurations,  encompassing  pulsed  (constant-size  probe  volume,  and continuous wave), and variable probe volume configurations. These were performed to assess and compare different LiDAR setups and their impact on power curve estimation;
- · twelve  wind  and  wave  conditions  covering  a  spectrum  of  different  offshore  conditions, including varying hub-height wind speeds and wave heights;
- · six  stochastic  realisations  introducing  randomness  in  atmospheric  turbulence  and  wave dynamics to ensure robust statistical representation of uncertainty;
- · three levels of turbulence intensity to investigate the impact of varying turbulence levels  or power output fluctuations and floater dynamics;

<!-- image -->

<!-- image -->

- · three  wind  shear  profiles  in  order  to  examine  the  effects  of  different  vertical  wind  speed gradients on power output fluctuations.

## 8.2. Key findings

<!-- image -->

Nacelle-mounted wind LiDARs  are currently the most suitable wind sensor for the power curve validation of a floating offshore wind turbine.

- · Nacelle-mounted wind LiDARs are identified among the commercially available instruments developed to acquire offshore wind measurements as the most suitable option to provide the necessary inflow wind characteristics for a PCV. The line-of-sight measurements captured using this technology can be used to derive multiple metrics, including hub-height wind speed, wind direction, as well as wind shear and veer.
- · The suitability of this solution is based on existing:
- o Measurement configuration (at least four lines-of-sight to measure wind speed and direction at varying heights);
- o Operation robustness;
- o Cost in relation to other alternatives.
- · The current standard for PCV does not address the key challenges associated with FOWTs:
- o The requirement to acquire measurements at 2.5 rotor diameters in front of wind turbines;
- o The six degrees of freedom (DOFs) motion of the floater, which can greatly affect the accuracy of nacelle-mounted wind LiDAR measurements.
- · A new methodology that includes inputs of the motion of a FOWT over six degrees of freedom (three translational: heave, sway, surge, and three rotational motions: roll pitch, and yaw) is required in the wind LiDAR data processing algorithm.
- · A wind field reconstruction algorithm is necessary for an accurate estimation of the hub-height wind speed. The wind field reconstruction algorithm should be based on a parametrisation of the wind shear and veer, and consider the motion of the FOWT (pitch, yaw and roll).

<!-- image -->

The pitch motion of a floating wind turbine contributes the most in the bias of the hub height wind speed estimation.

- · Among the three rotational motions of an FOWT, the pitch motion induces the largest bias, with its effect being amplified with increasing wind shear. The yaw misalignment could introduce significant biases when large values are observed and should be minimised or revised when performing motion correction. The roll motion contributes to hub-height wind speed bias, particularly when a wind veer is present, but the overall impact remains small.
- · Deviations of the hub-height wind speed between a nacelle-mounted wind lidar installed on a FOWT and the one installed on a fixed-bottom wind turbine range from -3.0% to +1.0%. The

<!-- image -->

<!-- image -->

biases exhibit a wind-speed dependent trend, with the largest underestimation occurring above the rated wind speed range.

- · In general, in the case of a nacelle-mounted wind LiDAR installed on the NREL 5 MW wind turbine, similar biases are observed between continuous-wave and pulsed wind LiDARs for all types of wind turbine configurations and environmental conditions. However, in the case of the IEA 15 MW turbine, larger biases for the case of a continuous-wave wind LiDAR were encountered. This is attributed to the long probe lengths that characterise the measurements of continuous wave wind LiDARs, especially in the case where observations at 600 m in front of wind turbines are required.
- · Overall, the environmental conditions do not have a significant impact on the biases, except for the IEA 15 MW, where both the shear exponent and the turbulence intensity increase the biases at the above-rated wind speed range.

The motion of a floating wind turbine enhances the uncertainty of the hub-height wind speed estimation using a nacelle-mounted wind LiDAR.

- · Nacelle LiDAR wind speed uncertainties are higher for floating than fixed bottom cases due to the greater number of parameters used to estimate the wind speed. This is amplified by the increase in the magnitude of certain sensitivity coefficients in the uncertainty budget, which identifies key contributors to measurement errors, when motion is present.
- · These uncertainties increase as the wind speed at the hub height increases. Pitch motion also increases uncertainty estimates, mostly due to the impact on the sensitivity coefficients.
- · The estimated uncertainties of the hub-height wind speed are in general larger for both wind LiDAR configurations examined in the case of FOWT in comparison with a fixed-bottom wind turbine. The main contributor to these uncertainties is the motion of a FOWT. This finding is consistent for all the examined wind conditions, except for when the wind speed ranges around the rated speed. At these wind speeds, the magnitude of the shear exponent and turbulent intensity plays a role in the computed uncertainties, with its effect being more evident in the case of a FOWT with a spar floater.
- · Power curve sensitivity to wind speed is higher in the region just below and approaching the rated wind speed, which does not typically coincide with the region of highest LiDAR wind speed uncertainty (closer to rated wind speed).

## 8.3. Industry needs/innovations

<!-- image -->

key for nacelle-mounted wind LiDARs. Developing motion correction methods is

- · The findings of this project show that there is a need for a motion correction method to be incorporated into a future standardised power curve validation method for FOWT using nacellemounted wind LiDARs.

<!-- image -->

<!-- image -->

- · A motion correction method should include at least the correction of the measurement position and the magnitude of line-of-sight speed of the wind LiDAR using the information on the yaw, pitch and roll angles, as well as a parametrisation of the wind shear.
- · This requires a wind LiDAR capable of measuring at a minimum of two heights and motion sensors for collecting yaw, pitch and roll rotations data.
- · It is recommended that the measurement of the motion of the nacelle is conducted as close as possible to the nacelle-mounted wind LiDAR to minimise any data collection error.
- · Motion sensor performance under various rotations and accelerations should be examined, as sensor measurement uncertainty may vary under different environmental conditions.

<!-- image -->

needed for reliable wind resource estimation. Enhanced modelling of floater motion is

- · The conclusion and recommendations regarding the hub-height wind speed uncertainty of a wind LiDAR's estimation are influenced by the floater type used, and its motion, as well as by the selected case study - the Hywind Scotland project.
- · The research studies that have been performed so far consider a sinusoidal motion around six degrees of freedom. However, this consideration does not necessarily describe realistically the motion of the FOWT. More complex motions need to be implemented in future simulation studies.
- · In the simulation study conducted for this project, the focus was on two floater types - semisubmersible and spar. However, given the variability reported in the literature regarding the response of different floater models, a consistent sensitivity analysis study across more floater types is needed.

<!-- image -->

Additional field campaigns with nacelle-mounted wind LiDARs on FOWT are essential to improve LiDAR performance validation.

- · The magnitude of the bias and the uncertainty of the hub-height wind speed using a nacellemounted wind LiDAR are dependent on both the measuring scanning geometry and the amplitude and frequency of the nacelle motion.
- · Different floaters exhibit different motions. However, due to the limited published research studies on this field, there is still a need to assess the impact that different floater types have on the measurements of a nacelle-mounted wind LiDAR.
- · A measurement campaign is recommended to further verify the accuracy of the simulation code used in this project. This would enable a deeper understanding of how floating wind turbines respond to real-world conditions.

## STAGE 3 PHASE II PROJECTS

## 9. Floating Wind JIP Stage 3

## 9.1. Stage 3 programme objectives

Stage 3 of the Floating Wind JIP commenced in 2022, and projects are expected to run until 2027. These projects focus on addressing key enablers for the commercialisation of floating offshore wind by exploring technical solutions, reducing risk and building the foundation for large-scale deployment. The 17 Stage 3 Phase I Floating Wind JIP partners agreed on the following Stage 3 ambitions for each focus area, which will guide the focus of Stage 3 projects.

<!-- image -->

|   1 | Define optimal mooring layout and anchoring for different challenging environments and model subsea interactions.                                       |
|-----|---------------------------------------------------------------------------------------------------------------------------------------------------------|
|   2 | Better understand the integrity of mooring lines through improved monitoring techniques.                                                                |
|   3 | Understand how geographical and material selection affect the availability and manufacturing capabilities of different mooring and anchoring solutions. |

<!-- image -->

|   1 | Scale up technologies such as ROVs and wider autonomous systems to improve monitoring and inspection operations.                                            |
|-----|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
|   2 | Improve modelling systems such as the development digital twin and AI solutions to understand lifecycle integrity at component, floater and windfarm level. |

<!-- image -->

|   1 | Understand full electrical system design for commercial scale floating wind farms.                         |
|-----|------------------------------------------------------------------------------------------------------------|
|   2 | Define dynamic array and export cable architecture for commercial scale floating wind.                     |
|   3 | Advance understanding of dynamic cable failures to accelerate towards more reliable and insurable systems. |

<!-- image -->

<!-- image -->

<!-- image -->

| 1 Understand the required port developments for assembly in key markets.                              |   commercial scale floating wind farms |
|-------------------------------------------------------------------------------------------------------|----------------------------------------|
| Understand how water depth and environment affect the entire installation process.                    |                                      2 |
| Remove barriers to allow for commercial scale major component exchange offshore.                      |                                      3 |
| Understand how wet storage will be managed/addressed by the port and the wider industry.              |                                      4 |
| Understand how the increase in ports bearing capacity requirements will be addressed by the industry. |                                      5 |

<!-- image -->

|   1 | Assess technology developments such as ballast, sizing and cost to support with both floater and tower developments.   |
|-----|------------------------------------------------------------------------------------------------------------------------|
|   2 | Understand floating specific windfarm layout and turbine specific developments to maximise yield.                      |
|   3 | Define floating specific controllers and modifications required in context to floating specific turbines.              |

<!-- image -->

|   1 | Understand how different materials and manufacturing processes affect the commercialisation of different floater designs.   |
|-----|-----------------------------------------------------------------------------------------------------------------------------|
|   2 | Improve the modelling and design process for integrated floater designs.                                                    |
|   3 | Improve the understanding of foundation design and performance.                                                             |

<!-- image -->

<!-- image -->

## 9.2. Stage 3 Phase II programme activity

The Floating Wind JIP is running seven projects through Stage 3 Phase II, which kicked off in 2023. Overviews of the seven Stage 3 Phase II projects can be found below. Stage 3 Phase III projects are currently undergoing tendering, and six projects are expected to be run through this phase. For further information on Phase III projects, please visit the Carbon Trust tender website.

## Fixed-to-floating WTG integration requirements

## Contractor: Heerema Engineering Solutions

Uncertainty around the acceptable tolerances for WTG integration on moored substructures still exists. This uncertainty relates to acceptable conditions within the port such as wind speed, wave conditions and tidal range, as well as the corresponding relative motions associated with the moored floating substructure and the technical requirements for mating operations. The outputs of this project will enable further understanding of operational functionality, investigate the acceptable tolerances for fixed-to-floating wind turbine integration at quayside and develop guidelines for successful integration based on expert engagement.

<!-- image -->

## The objectives of the project are to:

- · Define a tolerance range and limiting factors for the safe integration of fixed-to-floating wind turbine generators.
- · Engage with key stakeholders (turbine OEMs and third party specialists) to understand risks and mitigation factors for the proposed tolerances and collaboratively agree on tolerances.
- · Develop guidance for fixed-to-floating WTG integration at quayside, outlining the conditions and parameters where it is feasible to carry out WTG integration procedures.

## Foundation Wet Storage Solutions

## Contractor: Frazer-Nash Consultancy, Tadek and Ryder Geotechnical

<!-- image -->

The increasing scale and size of floating offshore wind projects raises concerns about the requirements and availability of space for the assembly and installation of floating substructures. This project aims to investigate the requirements and limitations associated with floater wet storage, ensuring quick and straightforward access to substructures. The project aims to assess how limiting parameters vary for the storage of substructures which have undergone WTG integration in both grounded and moored scenarios.

<!-- image -->

<!-- image -->

## The objectives of the project are to:

- · Determine the limitations of design, metocean, seabed, and bathymetric conditions to safely wet store structures with a grounded solution.
- · Determine the limitations of metocean and geographical conditions for different mooring configurations to safely and effectively wet-store substructures.
- · Evaluate how these limitations change for floaters without integrated turbines and floaters with integrated turbines.
- · Understand the conditions and the process for gaining consent for wet storage areas and the concerns of relevant stakeholders in pre-defining these areas.

<!-- image -->

<!-- image -->

- · Undertake an assessment comparison of grounded solutions and moored solutions for wet storage, focusing largely on cost, but including other practical limitations.
- · Define the parameter requirements for a wet storage area to successfully carry out storage of substructures.

## Onsite Major Component Replacement Assessment -Alpha Phase

## Contractor: Frazer-Nash Consultancy, Generating Better, FloWave

<!-- image -->

Onsite major component replacement (MCR) has been shown to offer potential cost advantages when compared to tow to port strategies for commercial scale floating offshore wind. However, existing innovations have a low TRL due to a lack of applicability criteria and a framework for the basis of design, testing, manufacturing, and offshore deployment of these technologies.

<!-- image -->

<!-- image -->

This project has been divided into two phases; an Alpha Phase which is building upon previous related Floating Wind JIP projects to evaluate the status of current in-situ MCR technologies available and develop a test specification for wave tank testing. The Alpha Phase will be followed by a Beta Phase, which will evaluate one or more concepts assessed as part of the alpha phase using the developed test specification as a base case, to allow for replicable future in-situ MCR wave tank assessments.

The project will further investigate the status of current onsite major component replacement technologies available and evaluate their suitability as well as developing criteria to be used subsequently as part of a follow-on Beta Phase.

The objectives of the Alpha Phase are to:

- · Identify the current MCR technology gaps using previously completed Floating Wind JIP projects as a basis.
- · Develop an overview of the technical maturity for selected MCR concepts.
- · For selected MCR concepts undertake numerical model simulations for major component exchange using a hydrodynamic model.
- · Develop a test specification and criteria to ultimately feed into the Onsite Major Component Replacement Assessment: Beta Phase.

## Ballast Systems for Stability Control of Floating Platforms

## Contractor: Sowento, Seaplace

<!-- image -->

<!-- image -->

Robust ballast systems help optimise the transportation, operation and generation of floating wind platforms by allowing greater control of the motions and better stability properties.  Such a feature is particularly crucial when operating in regions with harsh marine environments, improving stability and safety in rapid dynamic motions driven by fluctuating environmental conditions. Despite the advantages they may bring, ballast systems have many implications and considerations that require further assessment.

## The objectives of the project are to:

- · Investigate current and emerging state-of-the-art ballast systems for floating offshore wind platforms to understand the advantages, disadvantages and limitations of various advanced

<!-- image -->

<!-- image -->

systems for different wind turbine platform archetypes, with a focus on the post-installation phase.

- · Undertake a cost benefit analysis through various stages of the system lifecycle, considering costs associated with risk mitigation, to understand the benefit of active ballast systems compared to passive ballast systems.
- · Investigate the requirements and procedures for associated equipment and systems and how these need to be adapted for varying metocean conditions and environments.
- · Define an operations and maintenance strategy for the lifetime of the identified ballast systems.

## Pre-stretching and re-tensioning of fibre ropes

## Contractor: Ramboll

<!-- image -->

To enable commercial scale floating offshore wind, mooring systems need to be both cost-effective and conform to the specific load requirements of floating offshore wind turbines. Mooring system design concepts utilising synthetics are a leading solution, but these are potentially sensitive to construction elongation and creep over time, which can lead to damage to the mooring system, power export cable or the failure of the mooring system. To reduce these risks, pre-stretching and re-tensioning methods can be applied.  However, current approaches are based on O&amp;G processes and techniques, which may not be suitable or effective for floating offshore wind turbines or new rope technology.

## The objectives of the project are to:

- · Examine how variations in design and material parameters impact the operational outcome e.g. how the aging of the fibre ropes is affected by pre-stretching -the rope stiffness vs creep material trade-off over time.
- · Understand how technology innovations can improve the effectiveness of pre-stretching and retensioning of fibre ropes, in relation to elongation control and tension maintenance.
- · Understand and predict the need and best practice for re-tensioning events.
- · Optimise offshore operations through an improved understanding of installation and maintenance requirements.
- · Provide a framework for future work to understand the effect on CAPEX and OPEX through a better understanding of the impacts and pre-installation mitigations of fibre rope elongation.

## Resilience of mooring systems exposed to fishing

## Contractor: Ramboll

<!-- image -->

As large numbers of floating offshore wind sites are under initial development worldwide, interactions with other marine spatial users will need to be considered. Fishing in the vicinity of floating offshore wind subsea systems is one such consideration.

Widespread commercial floating offshore wind deployment can cover significant areas of fishing grounds. Restricting fishing in a large number of these areas could be a significant cost. It is currently unclear what the potential damage risk of fishing activities to floating wind assets, in particular to the mooring system and dynamic cable layout. As such, it is crucial to understand what fishing activities can be allowed within FOW farms and what are mitigations strategies can be implemented to inform design decisions and array layout.

The objectives of the project are to:

<!-- image -->

<!-- image -->

- · Increase the understanding of if/how FOW farms can coexist with fisheries from a mooring and dynamic cable system robustness and resilience perspective based on a scenario where fishing activities are unrestricted around a floating wind farm.
- · Understand potential failure mechanisms, risks, and consequences of fishing on a subsea system at the component level. As well as mitigations that can be implemented to reduce risk.

## 132 Dynamic Cable Development

## Contractor: 2H Offshore

<!-- image -->

As the offshore wind sector progresses towards the adoption of 132 kV cables, there is a growing need to develop dynamic cables capable of supporting this transition. A key challenge is to define test specifications for dynamic 132kV cables, with wet or dry, lead-free solutions. Qualifying dynamic cable designs typically takes between 2 to 3 years, leading to long lead times before they can be deployed in commercial projects.

Both Floating wind JIP's 132 dynamic cable development (132 DCD) and the OWA's High Voltage Array Systems (Hi-VAS) project study the transition to 132 kV array systems. However, the 132 DCD project is looking at dynamic array cables, whereas the Hi-VAS project is focused on static array cables.

## The objectives of the project are to:

- · Define a detailed roadmap for qualification and subsequent maturation of the dynamic, lead-free 132kV cables.
- · Define what next steps the Floating Wind JIP could take to push for this development.

## carbontrust.com

## +44 (0) 20 7170 7000

Whilst reasonable steps have been taken to ensure that the information contained within this publication is correct, the authors, the Carbon Trust, its agents, contractors and sub-contractors give no warranty and make no representation as to its accuracy and accept no liability for any errors or omissions. Any trademarks, service marks or logos used in this publication, and copyright in it, are the property of the Carbon Trust. Nothing in this publication shall be construed as granting any licence or right to use or reproduce any of the trademarks, service marks, logos, copyright or any proprietary information in any way without the Carbon Trust's prior written permission. The Carbon Trust enforces infringements of its intellectual property rights to the full extent permitted by law.

The Carbon Trust is a company limited by guarantee and registered in England and Wales under Company number 04190230 with its Registered Office at: Level 5, Arbor, 255 Blackfriars Road, London SE1 9AX, UK.

© The Carbon Trust 2025. All rights reserved.

Published in the UK: 2025

<!-- image -->