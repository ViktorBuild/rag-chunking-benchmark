---
document_id: seai_internal_wall_insulation
title: "Internal Wall Insulation Guidance on Wall Coverage"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "SEAI"
year: 2022
original_file: "seai_internal_wall_insulation_guidance.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Introduction

SEAI  inspectors  have  identified a number of homes  under the  Better  Energy  Homes  programme where only a  portion of the home  has  been  internally insulated.  In  some cases,  homeowners have had their drylining grants declined and contractors have faced de-registration as a  result.

To avoid  similar  outcomes,  we  would  like  to  draw your  attention  to  the  following  requirements which must be satisfied on all internal wall insulation works:

## Whole-surface solution

<!-- image -->

For  insulation  works,  an  optimal  whole-surface  solution  must  be  installed where  physically and  economically feasible.  In  the  case  of wall  insulation, this comprises the insulation of all external  (heat loss) walls of the home.

It is important to remind homeowners of the difference between affordability  and  economic  viability.  Where a homeowner  indicates  that they  cannot  afford  a  whole-element  solution,  this  does  not  diminish  the viability of the installation and  is  not an  acceptable reason to not complete a  whole-surface solution.

Partial solutions are only acceptable in exceptional circumstances and must be detailed in the Declaration of Works (DOW) form.

## Mixed measures

Where  mixed-measure  solutions  are  installed,  (e.g.  part  cavity  insulation,  part internal  insulation),  this  must  be  detailed  on  the  DOW  and  relevant wall  areas included. The  grant application  must  be  for  the  greatest  measure  by wall  area and only one wall grant will  be paid.

Where the  non-grant  aided  insulation  works  are  being  carried  out  by  another supplier, you  must  not  sign  the  DOW  until  all  works  are  completed  and  full coverage has been achieved.

<!-- image -->

<!-- image -->

## Pre-existing  insulation

External  walls  must  be  properly assessed  before works  commence to establish  if there is already insulation present in  the home. Where some of the wall  insulation  is  pre-existing, a  grant can  be  claimed  for further  insulation  works  provided  a  whole-surface  solution  is achieved and the walls already insulated  meet the required U-values.

In all cases, U-value  calculations  must  be  carried  out  to  ensure  achievement  of  the scheme requirements (0.27 W/m'K).

## Further resources

For further information,  please  refer to the Domestic Technical Standards &amp; Specification, Section 6.3, the Contractors Code  of  Practice, Section 5.1 and the Homeowner's  Application Guide, Section 2.2.

w: www.seai.ie e:  info@seai.ie t: 01  8082100

<!-- image -->

<!-- image -->

<!-- image -->