---
document_id: doe_steam_tip_1
title: "Steam Tip Sheet #1: Inspect and Repair Steam Traps"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_steam_tip01_inspect_repair_steam_traps.pdf"
tables_detected: 5
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

Energy Tips: STEAM

## Inspect and Repair Steam Traps

In steam systems that have not been maintained for 3 to 5 years, between 15% to 30% of the installed steam traps may have failed-thus allowing live steam to escape into the condensate return system. In systems with a regularly scheduled maintenance program, leaking traps should account for less than 5% of the trap population. If your steam distribution system includes more than 500 traps, a steam trap survey will probably reveal significant steam losses.

## Example

In a plant where the value of steam is $10.00 per thousand pounds ($10.00/1,000 lb), an inspection program indicates that a trap on a 150-pound-per-square-inchgauge (psig) steam line is stuck open. The trap orifice is 1/8th inch in diameter. The table shows the estimated steam loss as 75.8 pounds per hour (lb/hr). After the failed trap is repaired, annual savings are:

Annual Savings =  75.8 lb/hr x 8,760 hr/yr x $10.00/1,000 lb =  $6,640

Leaking Steam Trap Discharge Rate*

| Trap Orifice Diameter, inches   |   Steam Loss, lb/hr Steam Pressure, psig |   Steam Loss, lb/hr Steam Pressure, psig |   Steam Loss, lb/hr Steam Pressure, psig | Steam Loss, lb/hr Steam Pressure, psig   |
|---------------------------------|------------------------------------------|------------------------------------------|------------------------------------------|------------------------------------------|
| Trap Orifice Diameter, inches   |                                    15    |                                    100   |                                    150   | 300                                      |
| 1/32                            |                                     0.85 |                                      3.3 |                                      4.8 | -                                        |
| 1/16                            |                                     3.4  |                                     13.2 |                                     18.9 | 36.2                                     |
| 1/8                             |                                    13.7  |                                     52.8 |                                     75.8 | 145                                      |
| 3/16                            |                                    30.7  |                                    119   |                                    170   | 326                                      |
| 1/4                             |                                    54.7  |                                    211   |                                    303   | 579                                      |
| 3/8                             |                                   123    |                                    475   |                                    682   | 1,303                                    |

*From the Boiler Efficiency Institute. Steam is discharging to atmospheric pressure through a re-entrant orifice with a coefficient of discharge equal to 0.72.

Steam Tip Sheet #1

## Suggested Actions

Steam traps are tested primarily to determine whether they are functioning properly and not allowing live steam to blow through.

- ■ ■ Establish a program for the regular systematic inspection, testing, and repair of steam traps.
- ■ ■ Include a reporting mechanism to ensure thoroughness and to provide a means of documenting energy and dollar savings.
- ■ ■ Consider online monitoring of the most important steam traps or those associated with your most important processes to quickly identify steam loss trends.

## Steam Trap Testing Facts

Steam traps are tested to determine if they are functioning properly and not cold plugging or failing in an open position and allowing live steam to escape into the condensate return system. There are four basic ways to test steam traps: temperature, sound, visual, and electronic.

## Recommended Steam Trap Testing Intervals

- •  High-Pressure (150 psig and above): Weekly to Monthly
- •  Medium-Pressure (30 to 150 psig): Monthly to Quarterly
- •  Low-Pressure (below 30 psig): Annually

For additional information on monitoring, download the following sub-metering case studies from the AMO publication library:

- ·  Solutia: Utilizing Sub-Metering to Drive Energy Project Approvals Through Data
- ·  Nissan North America: How Sub-Metering Changed the Way a Plant Does Business

Also refer to the following guidebook on the EERE Federal Energy Management website at www.femp.energy.gov :

- ·  Metering Best Practices: A Guide to Achieving Utility Resource Efficiency, Release 2.0

Adapted from an Energy TIPS fact sheet that was originally published by the Industrial Energy Extension Service of Georgia Tech.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3401  •  January 2012

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.