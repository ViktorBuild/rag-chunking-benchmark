---
document_id: doe_steam_sourcebook
title: "Improving Steam System Performance: A Sourcebook for Industry"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2012
original_file: "doe_steam_system_sourcebook.pdf"
tables_detected: 13
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## ADVANCED MANUFACTURING OFFICE

<!-- image -->

Improving Steam System Performance: A Sourcebook for Industry

Second Edition

## ACKNOWLEDGMENTS

Improving Steam System Performance: A Sourcebook for Industry was developed for the U.S. Department of Energy's (DOE) Advanced Manufacturing Office (AMO), formerly the Industrial Technologies Program. AMO undertook this project as a series of sourcebook publications. Other topics in this series include: compressed air systems, pumping systems, fan systems, process heating, and motor and drive systems. For more information about program resources, see AMO in the Where to Find Help section of this publication.

AMO, and the National Renewable Energy Laboratory, wish to thank the staff at the many organizations that so generously assisted in the collection and updates of data for this sourcebook. The Alliance to Save Energy, The American Boiler Manufacturers Association (ABMA), the Council of Industrial Boiler Operators (CIBC), the National Insulation Association (NIA), and the North American Insulation Manufacturers Association (NAIMA) provided valuable assistance in developing, compiling, and reviewing the original and updated versions of the publication.

AMO appreciates the participation of the Steam Technical Subcommittee. Special thanks are extended to its co-chairs, Dr. Anthony Wright of the Oak Ridge National Laboratory (recently retired), and Glenn Hahn of Spirax-Sarco, for providing extensive technical guidance and review throughout the preparation and update of this edition. The efforts of these program and committee participants are greatly appreciated:

Joe Almaguer, Dow Chemical Company William Behr, Kelly Engineering Larry Blanchfield, Northrop Grumman Bill Brayman, Brayman Insulation Consultants, LLC Rolf Butters, U.S. Department of Energy Deborah Bloom, Nalco Company* Sean Casten, Recycled Energy Development* Steve Connor, Cleaver-Brooks Robert Crosby, Baltimore Gas and Electric Dan Dvorak, Dupont Fred Fendt, DOW Chemical Company Bruce Gorelick, Enercheck Systems* Robert Griffin, Enbridge Gas Distribution, Canada* Bill Haman, Iowa Energy Center Dr. Greg Harrell, University of Tennessee-Knoxville* Thomas Henry, Armstrong Service*

Carroll Hooper, Steam Solutions, Inc.*

Michele Jones, National Insulation Association James Kumana, Kumana and Associates* Andrew W. Larkin, Trigen Energy Corporation* David Lofstead, Nalco Company Charles Marsh, U.S. Army Corps of Engineers Michaela Martin, Oak Ridge National Laboratory Lloyd Mason, Condensate Return Specialists* Gil McCoy, EERE Information Center* Sachin Nimbalkar, Oak Ridge National Laboratory William Orthwein, U.S. Department of Energy Kelly Paffel, Swagelok* Vestal Tutterow, Project Performance Corporation Tony Wright, Oak Ridge National Laboratory (Retired) Richard Wells, Bulldog Boiler, Ltd. Tom Wenning, Oak Ridge National Laboratory

Additionally, the contributions of the following participants are appreciated for their review of and suggestions for this sourcebook:

Geoffrey Halley, American Boiler Manufacturers Association Scott Nunnery, Swagelok Energy Advisors, Inc. W. Randall Rawson, American Boiler Manufacturers Association* Douglas Riley, Millennium Chemical* Thomas Scheetz, BASF* John Todd, Yarway Corporation*

Prepared for:  The United States Department of Energy, Advanced Manufacturing Office

Prepared by:  National Renewable Energy Laboratory, Golden, CO Lawrence Berkeley National Laboratory, Washington, DC* Resource Dynamics Corporation, Vienna, VA*

*Contributor to the first edition, published in 2004.

Cover photo from iStock/11893854

## CONTENTS

| QUICK START GUIDE . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                     | . . 1   |
|---------------------------------------------------------------------------------------------------------------------------------------------|---------|
| SECTION 1: STEAM SYSTEM BASICS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                        | . 2     |
| Why Steam? . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .      | . 2     |
| Steam System Operation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                | . 2     |
| Generation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .    | . 4     |
| Distribution . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  | . 9     |
| End Use . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | 14      |
| Recovery . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  | 20      |
| SECTION 2: PERFORMANCE IMPROVEMENT OPPORTUNITIES . . . . . . . .                                                                            | 23      |
| Overview . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  | 23      |
| Systems Approach . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .          | 23      |
| Strategic, Performance Improvement Opportunities-Management-Based Systems                                                                   | 23      |
| Common Performance Improvement Opportunities . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                        | 27      |
| Steam System Training . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .             | 28      |
| Financing Steam System Improvements . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                               | 29      |
| SECTION 3: WHERE TO FIND HELP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                       | 33      |
| Advanced Manufacturing Office Overview . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                | 33      |
| Directory of Contacts . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           | 35      |
| Resources and Tools . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           | 36      |
| Books . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .   | 36      |
| Other Publications: Guides, Manuals, and Standards . . . . . . . . . . . . . . . . . . . . . . . . .                                        | 40      |
| Software . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .      | 42      |
| Periodicals . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .     | 45      |
| Reports and Technical Papers . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                      | 46      |
| Training Courses and Technical Services . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                               | 46      |
| Multimedia Resources . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                  | 49      |
| APPENDICES . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .            | 51      |
| Appendix A: Glossary of Terms . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                     | 52      |
| Appendix B: Steam Tip Sheets . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                    | 56      |

## FIGURES

| Figure 1. Steam System Schematic . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                       | . 3   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| Figure 2. Firetube Boiler . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                            | . 4   |
| Figure 3. Packaged Watertube Boiler . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                          | . 5   |
| Figure 4. Coil Type Watertube Boiler . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                       | . 5   |
| Figure 5. Thermostatic Steam Trap with a Bellows Element . . . . . . . . . . . . . . . . . .                                                                           | . 12  |
| Figure 6. Thermostatic Steam Trap with a Bimetallic Element . . . . . . . . . . . . . . . .                                                                            | . 12  |
| Figure 7. Inverted Bucket Steam Trap . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                         | . 12  |
| Figure 8. Float and Thermostatic Steam Trap . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                | . 13  |
| Figure 9. Thermodynamic Disc Steam Trap . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                | . 13  |
| Figure 10. Shell and Tube Heat Exchanger . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                             | . 16  |
| Figure 11. Components of a Plate and Frame Heat Exchanger . . . . . . . . . . . . . . . .                                                                              | . 17  |
| Figure 12. Configuration of a Jacketed Kettle Heat Exchanger . . . . . . . . . . . . . . . .                                                                           | . 17  |
| Figure 13. Thermocompressor Operation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                              | . 18  |
| Figure 14. Condensate Receiver Tank and Pump Combination . . . . . . . . . . . . . . . .                                                                               | . 21  |
| Figure 15. Flash Steam Recovery Vessel . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                           | . 21  |
| TABLES                                                                                                                                                                 |       |
| Table 1. Steam End-Use Equipment in Energy Intensive Industries . . . . . . . . . . . .                                                                                | . 15  |
| Table 2. Common Performance Improvement Opportunities for the Generation, Distribution, and Recovery Parts of Industrial Steam Systems . . . . . . . . . . . . . . . . | 24    |

This page intentionally left blank

Q

## QUICK START GUIDE

This sourcebook is designed to provide steam system users with a reference that describes the basic steam system components, outlines opportunities for energy and performance improvements, and discusses the benefits of a systems approach in identifying and implementing these improvement opportunities. The sourcebook is divided into three main sections as outlined below.

This sourcebook is not intended to be a comprehensive technical guide on improving steam systems, but rather a document that makes users aware of potential performance improvements, provides some practical guidelines, and directs the user to helpful resources. A systems approach analyzes the supply and the demand sides of the system and how they interact, essentially shifting the focus from individual components to total system performance. The cost-effective operation and maintenance of a steam system require attention not only to the needs of individual pieces of equipment, but also to the system as a whole. Often, operators are so focused on the immediate demands of the equipment, they overlook the broader question of how system parameters affect the equipment.

## Section 1: Steam System Basics

For users unfamiliar with the basics of steam systems, or for users seeking a refresher, a brief discussion of the terms, relationships, and important system design considerations is provided. Users already familiar with industrial steam system operation may want to skip this section. This section describes steam systems using four basic parts: generation, distribution, end use, and recovery.

## Section 2: Performance Improvement Opportunities

This section discusses important factors that should be considered when industrial facilities seek to improve steam system performance and to lower operating costs. This section also provides an overview of the financial considerations related to steam system improvements. Additionally, this section discusses several resources and tools developed through the U.S. Department of Energy's (DOE) Advanced Manufacturing Office (AMO) steam activities to identify and assess steam system improvement opportunities.

## Section 3: Where to Find Help

This section provides a directory of associations and other organizations involved in the steam system marketplace. This section also provides a description of the AMO steam activities, a directory of contacts, technical expertise, and a listing of available resources and tools, such as publications, software, training courses, and videos.

## Appendices

The sourcebook includes two appendices. Appendix A is a glossary defining terms used in steam systems. Appendix B contains links to a series of steam system tip sheets, developed through AMO steam activities. These tip sheets discuss common opportunities that industrial facilities can use to improve performance and reduce fuel use.

## SECTION 1: STEAM SYSTEM BASICS

## Why Steam?

There are three principal forms of energy used in industrial processes: electricity, direct-fired heat, and steam. Electricity is used in many different ways, including mechanical drive, heating, and electrochemical reactions. Direct-fired energy directly transfers the heat of fuel combustion to a process. Steam provides process heating, pressure control, mechanical drive, and component separation, and is a source of water for many process reactions.

Steam has many performance advantages that make it an indispensable means of delivering energy. These advantages include low toxicity, ease of transportability, high efficiency, high heat capacity, and low cost with respect to the other alternatives. Steam holds a significant amount of energy on a unit mass basis (between 1,000 and 1,250 British thermal units per pound [Btu/lb]) that can be extracted as mechanical work through a turbine or as heat for process use. Since most of the heat content of steam is stored as latent heat, large quantities of heat can be transferred efficiently at a constant temperature, which is a useful attribute in many process heating applications.

Steam is also used in many direct contact applications. For example, steam is used as a source of hydrogen in steam methane reforming, which is an important process for many chemical and petroleum refining applications. Steam is also used to control the pressures and temperatures of many chemical processes. Other significant applications of steam are to strip contaminants from a process fluid, to facilitate the fractionation of hydrocarbon components, and to dry all types of paper products.

The many advantages that are available from steam are reflected in the significant amount of energy that industry uses to generate it. For example, in 2006, U.S. manufacturers used about 4,762 trillion Btu of steam energy, which represents about 40% of the total energy used in industrial process applications for product output. 1

1 Manufacturing Energy and Carbon Footprint (for Chemical Manufacturing, Forest Products, Petroleum Refining), prepared for AMO by Energetics, Inc., December 2010, manufacturing.energy.gov ; and Manufacturing Energy Consumption Survey Data, U.S. Department of Energy, Energy Information Administration (2010 Data Release), www.eia.doe.gov .

Steam used by energy intensive industries is especially significant. For example, in 2006 the forest products industry used approximately 2,117 trillion Btu of energy to generate steam, accounting for about 76% of the total onsite energy, excluding feedstocks used by this industry. The chemicals industry used approximately 1,504 trillion Btu of energy to generate steam, which represents about 47% of the total onsite energy, excluding feedstocks used in this industry. The petroleum refining industry used about 915 trillion Btu of energy to generate steam, which accounts for about 28% of this industry's total onsite energy use, excluding feedstocks. 2

## Steam System Operation

This sourcebook uses four categories to discuss steam system components and ways to enhance steam system performance: generation, distribution, end use, and recovery. These four areas follow the path of steam as it leaves the boiler and returns via the condensate return system.

## Generation

Steam is generated in a boiler or a heat recovery steam generator by transferring the heat of combustion gases to water. When water absorbs enough heat, it changes phase from liquid to steam. In some boilers, a superheater further increases the energy content of the steam. Under pressure, the steam then flows from the boiler or steam generator and into the distribution system.

## Distribution

The distribution system carries steam from the boiler or generator to the points of end use. Many distribution systems have several take-off lines that operate at different pressures. These distribution lines are separated by various types of isolation valves, pressure-regulating valves, and, sometimes, backpressure turbines. A properly performing distribution system delivers sufficient quantities of high-quality steam at the right pressures and temperatures to the end uses. Effective distribution system performance requires proper steam pressure balance, good condensate drainage, complete and optimum insulation with regular repair and maintenance, and effective pressure regulation.

2 Ibid.

## End Use

There are many different end uses of steam. Examples of steam's diverse uses include process heating, mechanical drive, moderation of chemical reactions, and fractionation of hydrocarbon components. Common steam system enduse equipment includes heat exchangers, turbines, fractionating towers, strippers, and chemical reaction vessels.

In a heat exchanger, the steam transfers its latent heat to a process fluid. The steam is held in the heat exchanger by a steam trap until it condenses, at which point the trap passes the condensate into the condensate return system. In a turbine, the steam transforms its energy to mechanical work to drive rotating machinery such as pumps, compressors, or electric generators. In fractionating towers, steam facilitates the separation of various components of a process fluid. In stripping applications, the steam pulls contaminants out of a process fluid. Steam is also used as a source of water for certain chemical reactions. In steam methane reforming, steam is a source of hydrogen.

## Recovery

The condensate return system sends the condensate back to the boiler. The condensate is returned to a collection tank. Sometimes the makeup water and chemicals are added here, while other times this is done in the deaerator. From the collection tank the condensate is pumped to the deaerator, which strips oxygen and non-condensable gases. The boiler feed pumps increase the feedwater pressure to above boiler pressure and inject it into the boiler to complete the cycle.

Figure 1 provides a general schematic description of the four principal areas of a steam system. The following sections discuss the components in these areas in greater detail. Consider opportunities to cascade heat recovery from exhaust gases to lower temperature process heating equipment. Develop procedures for regular operations, calibration, and maintenance of process sensors (i.e., pressure, temperature, and flow) and controllers. 3

3 Guidebook to Energy-Related Resources for the Chemical Industry , Coordinated by Ciras, November 2005.

Figure 1. Steam System Schematic

<!-- image -->

## Generation

The generation part of a steam system uses a boiler to add energy to a feedwater supply to generate steam. The energy is released from the combustion of fossil fuels or from process waste heat. The boiler provides a heat transfer surface (generally a set of tubes) between the combustion products and the water. The most important parts of the generating system include the boiler, the fuel supply, combustion air system, feedwater system, and exhaust gases venting system. These systems are related because problems or changes in one generally affect the performance of the others. DOE research partnerships with the industry have resulted in high-efficiency burners and other technologies for industrial boilers. See manufacturing.energy.gov.

## Boilers

There are two basic types of boilers: firetube and watertube. The fundamental difference between these boiler types is which side of the boiler tubes contain the combustion gases or the boiler water/steam.

Firetube boilers. In firetube boilers, the combustion gases pass inside boiler tubes, and heat is transferred to water between the tubes and the outer shell. A representative firetube boiler is shown in Figure 2. Scotch marine boilers are the most common type of industrial firetube boiler. The Scotch marine boiler is an industry workhorse due to low initial cost and advantages in efficiency and durability.

Figure 2. Firetube Boiler Illustration from AESYS Technologies

<!-- image -->

Scotch marine boilers are typically cylindrical shells with horizontal tubes configured such that the exhaust gases pass through these tubes, transferring energy to boiler water on the shell side.

## Selected Energy Efficiency Practices for Steam Systems and Boiler Operations

- ■ ■ Validate  energy  intensity  improvements  with Superior Energy Performance and ANSI or ISO Energy Management Standard.
- ■ ■ Locate savings opportunities and validate energy savings with data from interval monitoring or metering.
- ■ ■ Continuously maintain efficient systems by matching boiler capacities and operations to process load and loading cycles.

Scotch marine boilers contain relatively large amounts of water, which enables them to respond to load changes with relatively little change in pressure. However, since the boiler typically holds a large water mass, it requires more time to initiate steaming and more time to accommodate changes in steam pressure. Also, Scotch marine boilers generate steam on the shell side, which has a large surface area, limiting the amount of pressure they can generate. In general, Scotch marine boilers are not used where pressures above 300 pounds per square inch gauge (psig) are required. Today, the biggest firetube boilers are over 1,500 boiler horsepower (about 50,000 pounds per hour ). 4

Firetube boilers are often characterized by their number of passes, referring to the number of times the combustion (or flue) gases flow the length of the pressure vessel as they transfer heat to the water. Each pass sends the flue gases through the tubes in the opposite direction. To make another pass, the gases turn 180 degrees and pass back through the shell. The turnaround zones can be either dryback or waterback. In dryback designs, the turnaround area is refractory-lined. In waterback designs, this turnaround zone is water-cooled, eliminating the need for the refractory lining.

4 1 boiler horsepower = 33,475 Btu/hr.

Figure 3. Packaged Watertube Boiler

<!-- image -->

Illustration from Cleaver Brooks

Figure 4. Coil Type Watertube Boiler

<!-- image -->

Illustration from Bob Forslund, Vapor Power

Watertube Boilers. In watertube boilers, boiler water passes through the tubes while the exhaust gases remain in the shell side, passing over the tube surfaces. A representative watertube boiler is shown in Figure 3. Because tubes can typically withstand higher internal pressure than the large chamber shell in a firetube, watertube boilers are used where high steam pressures (3,000 psi, sometimes higher) are required. Watertube boilers are also capable of high efficiencies and can generate saturated or superheated steam. In fact, the ability of watertube boilers to generate superheated steam makes these boilers particularly attractive in applications that require dry, high-pressure, highenergy steam, including steam turbine power generation. Another type of watertube boiler is a coil type watertube boiler shown in Figure 4.

The performance characteristics of watertube boilers make them highly favorable in process industries, including chemical manufacturing, pulp and paper manufacturing, and refining. Although firetube boilers account for the majority of boiler sales in terms of units, watertube boilers account for the majority of boiler capacity. 5

Waste Heat Recovery Boiler (WHRB). These boilers may be either firetube or watertube design and use heat that would otherwise be discarded to generate steam. Typical sources of heat for WHRBs include exhaust gases or high-temperature products from an external manufacturing process in refineries and chemical manufacturing facilities, or combustion of a waste fuel in the boiler furnace.

Heat Recovery Steam Generators (HRSGs). HRSGs transfer energy from the exhaust of a gas turbine to an unfired or supplementary fired heat-recovery steam generator to produce steam. Exhaust gases leave the gas turbine at temperatures of 1,000°F (538°C) or higher and can represent more than 75% of the total fuel energy input. This energy can be recovered by passing the gases through a heat exchanger (steam generator) to produce hot water or steam for process needs. If the amount of steam needed by the process exceeds the amount produced by simple heat recovery, then supplementary fuel can be burned in an inline duct burner between the gas turbine and the HRSG.

Superheaters. Superheaters add energy to steam, resulting in a steam temperature that exceeds the saturation temperature at a specific pressure, which is typically known as superheated steam. Superheaters can be convective or

5 Analysis of the Industrial Boiler Population, Final Report No.-96/0200, GRI, 1996.

radiant. Radiative superheaters rely on the energy transferred directly from the combustion flame to increase the energy level of the steam, while convective superheaters rely on the transfer of additional energy from the flue gases to the steam.

Economizers. In many boilers, the flue gases still have useful amounts of energy even after they have passed through the boiler. In many of these applications, economizers provide effective methods of increasing boiler efficiency by transferring the heat of the flue gases to incoming feedwater. There are two principal types of economizers: noncondensing and condensing. Noncondensing economizers are usually air-to-water heat exchangers. Because these economizers are not designed to handle flue gas condensation, noncondensing economizers must be operated at temperatures that are reasonably above the dew points of the flue gas components. The dew point of the flue gases depends largely on the amount of water in the gas, which, in turn, is related to the amount of hydrogen in the fuel. For example, to avoid condensation in the exhaust gases produced by burning natural gas, the exhaust gas temperature should typically be kept above 250°F. Condensing economizers are designed to allow condensation of the exhaust gas components. Due to latent heat recovery, these economizers typically extract more energy than do noncondensing economizers and are used in several industries. Often, special materials are required, such as specialty stainless steels.

For more information on economizers, see the Steam Tip Sheet #3, Use Feedwater Economizers for Waste Heat Recovery at: manufacturing.energy.gov .

Combustion air preheaters. Combustion air preheaters are similar to economizers in that they transfer energy from the flue gases back into the system. In these devices, however, the energy is transferred to the incoming combustion air. The efficiency benefit is roughly 1% for every 40°F increase in the combustion air temperature. 6

## Boiler Insulation

The walls and combustion regions of boilers are typically lined with insulating materials to reduce energy loss and to prevent leakage. There are several types of boiler insulating materials, including brick, refractory, insulation, and lagging. The selection and design of boiler insulating materials depends largely on the age and design of

6 Boiler Efficiency Improvement , Boiler Efficiency Institute, 1991.

the boiler. Since the insulating lining is exposed to high temperatures and is subject to degradation, it should be periodically inspected and repaired when necessary. New materials technologies allow efficient insulation in tight spaces previously impossible to insulate.

## Boiler Control System

Boiler control systems are designed to protect the boiler and to ensure proper boiler operation. These systems include the combustion control system, flame safeguard, water level control, and fuel control.

Combustion control system. The combustion control system regulates the fuel and air mixture to achieve safe and efficient combustion and maintains proper steam system pressure. Control systems have varying levels of sophistication. Simple systems use a fixed linkage between the fuel-regulating valve and the combustion air damper. This is called single point positioning. A change in steam pressure makes a proportional change in the combustion air and fuel. Modern systems rely on signals from digital transmitters to determine independent fuel valve and air damper positions, and it typically provides alarms for outof-specification conditions for investigation and remedy. This is called a full monitoring system.

For more information, see the Steam Tip Sheet #4, Improve Your Boiler's Combustion Efficiency at: manufacturing.energy.gov .

Burner flame safeguard system. A flame safeguard system is an arrangement of flame detection systems, interlocks, and relays which will sense the presence of a proper flame in a furnace and cause fuel to be shut off if a hazardous condition develops. Modern combustion systems are closely interlocked with flame safeguard systems and also pressure-limit switches, low-water level cutoffs, and other safety controls that will stop the energy input to a boiler when an unsafe condition develops. The flame safeguard system senses the presence of a good flame or proper combustion and programs the operation of a burner system so that motors, blowers, ignition, and fuel valves are energized only when they are needed and then in proper sequence.

Safety shut-off valve. Safety shut-off valves isolate the fuel supply to the boiler in response to certain conditions such as low or high gas pressure or satisfied load demand. The type of safety shutoff valves and the settings are often determined by code or insurance requirements.

Water-level control. The boiler water-level control system ensures a safe water level in the boiler. Typically, the control system provides a signal to the feedwater control valve to regulate the feed rate. Simple water-level control systems that only sense water level are single-element systems. More complex systems incorporate additional data such as steam flow rate (dual-element system) and feedwater flow (triple-element system) and will provide better water level control during abrupt load changes.

Safety valve. The safety valve is the most important valve on the boiler and keeps the boiler from exceeding its maximum allowable working pressure (MAWP).

Steam-pressure control. Steam-pressure controls regulate the combustion equipment to maintain a constant pressure in the steam header. As the pressure rises above or falls below the pressure setting, the control adjusts the burner firing rate to bring the pressure back to the setpoint.

Nonreturn valve. The nonreturn valve is a combination shutoff and check valve that allows steam out of the boiler, but prevents backflow from the steam header in the event the boiler pressure drops below that of the header. The valve is opened only when the pressure inside the boiler rises slightly above the steam header pressure.

Steam flow meter. Steam flow meters are helpful in evaluating the performance of the system and can provide useful data in assessing boiler performance, calculating boiler efficiency, and tracking the amount of steam required by the system. In some systems, steam flow meters provide a measurement signal for the boiler control system. Additionally, steam flow meters can be useful in benchmarking efforts.

There are three basic types of steam flow meters: differential pressure (DP), vortex, and Coriolis. Differential pressure flow meters rely on the change in pressure as steam flows by an element such as a nozzle, orifice, or venturi. This pressure difference provides an indication of flow velocity, which, in turn, can be used to determine the flow rate. V ortex flowmeters rely on the principal that flow past an element creates vortices that have frequencies that correspond to the flow velocity. Coriolis flowmeters rely on tubes placed in the steam flow path that twist according to the velocity of the flow. For more information on steam system meters see the metering best practices at femp.energy.gov .

## Boiler Feedwater System

The boiler feedwater system supplies water to the boiler. Sources of feedwater include returning condensate and makeup water. Feedwater is typically stored in a collecting tank to ensure that a steady supply of heated water is available to the boiler regardless of momentary fluctuations in availability of condensate return or fresh water supply pressure.

Feedwater flow control valve. A modulating feedwater flow control valve moves up or down in response to the water level transmitter(s). On smaller firetube boilers, it is not uncommon for the feedwater valve to operate in a closed or open position, depending on the water level transmitter signal. In modern industrial boilers, the controls may also account for significant variations in steam demand.

Softener. Softeners remove hardness minerals, such as calcium, magnesium, and iron, from a water supply. The presence of hardness in boiler water leads to many problems, including scale buildup and foaming, which reduce boiler efficiency and can cause tube failure. Softeners reduce this problem through an ion exchange process. As the hard water passes through a chamber filled with resin, an exchange occurs that removes hardness minerals from the water. The sodium that replaces the hardness minerals has a higher solubility in water and generally will not form scale.

Pretreatment equipment. Pretreatment equipment improves the quality of the incoming water so that it may be used in the boiler without excessive scaling or foaming, which can reduce boiler efficiency and cause tube failure. Pretreatment equipment includes, but is not limited to, clarifiers, filters, softeners, dealkalizers, decarbonators, reverse osmosis (RO) units, and demineralizers.

Deaerator, deaerating heater, and atmospheric deaerator. The presence of oxygen in the boiler system can be a significant problem because of its corrosivity at high temperatures. Deaerators and deaerating heaters use heat, typically steam, to reduce the oxygen content in water. Deaerators and deaerating heaters are typically pressurized tanks that raise the water temperature to the point of saturation. They also break the incoming water into either fine droplets or thin sheets to facilitate the removal of oxygen and other noncondensable gases. Depending on the design, the feedwater oxygen content can be reduced to levels ranging from 7 to 40 parts per billion (ppb).

Atmospheric deaerators are typically found in smaller, lower-pressure boiler systems. They operate at atmospheric pressure, so the maximum operating temperature is 212°F. Most will operate at temperatures lower than this. Atmospheric deaerators cannot achieve the same level of oxygen removal as deaerators and deaerating heaters, typically providing water with oxygen levels of 0.5 to 1 part per million (ppm).

In applications that require lower oxygen levels than achievable with a deaerator, deaerating heater, or open feedwater heater, a chemical agent, known as an oxygen scavenger, can be used to remove more oxygen. In most systems, an oxygen scavenger is part of the system's water treatment program.

For more information on these devices, see the Steam Tip Sheet #18, Deaerators in Industrial Steam Systems at: manufacturing.energy.gov .

Feedwater pump. Feedwater pumps transfer water from the deaerator to the boiler. Feedwater pumps are driven by electric motors or by steam turbines. In a modulating feedwater system, the feedwater pumps run constantly as opposed to an on/off operation in relatively small boilers.

Collecting/Storage tank. The return of condensate is often erratic due to changing steam requirements by the end uses. The condensate is usually returned to a condensate receiver or directly to the deaerator if the system does not have a receiver. Pretreated water may also be stored in a tank prior to use. This provides the boiler system with additional water capacity in case the pretreatment equipment malfunctions. The condensate and pretreated water, or makeup, are transferred from the storage tanks to the deaerator before being sent to the boiler.

## Boiler Combustion Air System

The combustion air system supplies the oxygen necessary for the combustion reaction. To provide enough air for the amount of fuel used in industrial boilers, fans are typically required. Dampers, inlet valves, or variable speed drives typically control the amount of air allowed into the boiler.

Forced draft fan. A forced draft fan is located at the inlet of a boiler and pushes ambient air into the burner region, ensuring that adequate air is delivered to the combustion process. These fans either pull air directly from the boiler room or connect to a duct system that allows outside air to be drawn into the boiler.

Induced draft fan. Induced draft fans are located on the outlet gas side of the boiler and pull flue gases out. The induced draft fan creates a slightly negative furnace pressure that is controlled by outlet dampers on the boiler. In some systems where a bag house, mechanical collector, or precipitator is involved, special considerations should be given in sizing and selection of this fan.

Damper. Dampers control the amount of air allowed into and out of a combustion chamber. Dampers, in combination with fuel regulating devices, are positioned by the combustion control system to achieve certain fuel-to-air ratios. Dampers on the boiler outlet are used to regulate the negative furnace draft.

## Boiler Fuel System

There are many different types of fuels used in boilers, requiring several different types of fuel handling systems. Biomass fuels provide emission options that are carbon neutral. Fossil fuels such as coal, oil, and gas are most commonly used. Waste fuels are used in many industries, particularly the forest products, petroleum refining, and chemical manufacturing industries where there is an available supply of waste products such as bark, wood chips, black liquor, and refinery gas.

Fuel regulating valve. In gaseous and liquid fuels, regulating valves control the fuel delivered to the boiler. In many systems, these valves can be quickly shut in response to an operating problem.

Fuel. The fuel types that are commonly used in boilers include natural gas, coal, propane, fuel oils, and waste fuels (for example, black liquor, bark, and refinery gas). Fuel type significantly affects boiler operation, including efficiency, emissions, and operating cost. In 2005, almost 78% of boiler units and 56% of industrial boiler capacity were identified as natural gas-fired. Some industries use by-product fuel in a large portion of their boiler capacity, including paper (48%), refining (49%), and primary metals (42%). Coal, oil, and wood are important fuels in certain industries and regions, but fuel a small fraction of the boiler capacity on a national basis. More detail is available in the reference below. 7

7 Characterization of the U.S. Industrial Commercial Boiler Population , May 2005, Energy and Environmental Analysis, Inc. (now part of ICF International).

## STEAM SYSTEM BASICS

Fuel flow meter. Fuel meters measure the amount of fuel delivered to a boiler. Fuel meters provide essential data in determining boiler efficiency. Since fuel flow meters measure volume or mass of fuel, it is important to know the energy content of the fuel when determining boiler efficiency.

For more information, see the Steam Tip Sheet #15, Benchmark the Fuel Cost of Steam Generation at: manufacturing.energy.gov .

Burner. Burners combine the fuel and air to initiate combustion. There are many different types of burners due to the many different types of fuels. Additionally, burners have different performance characteristics and control requirements. Some burners are on/off, while others allow precise setting of the fuel:air mixture over a range of conditions. Some burners can fire different types of fuel, allowing boiler operation to continue despite the loss of one fuel supply.

## Boiler Blowdown System

The boiler blowdown system includes the valves and the controls for the continuous blowdown and bottom blowdown services. Continuous blowdown removes a specific amount of boiler water (often measured in terms of percentage of feedwater flow) in order to maintain a desired level of total dissolved solids in the boiler. Setting the flow for the continuous blowdown is typically done in conjunction with the water treatment program. Some continuous blowdown systems rely on the input of sensors that detect the level of dissolved solids in the boiler water.

The bottom blowdown is performed to remove particulates and sludge from the bottom of the boiler. Bottom blowdowns are periodic and are typically performed a certain number of times per shift or according to a set schedule. In some systems, bottom blowdowns are controlled by an automatic timer. Bottom blowdown should never be permitted unless it is recommended by the boiler manufacturer. This is because in higher pressure boilers, especially those above 700 pounds psig, bottom blowdown may cause water starvation in some portions of the boiler circuit.

Boiler blowdown heat exchangers and flash tank. The continuous blowdown water has the same temperature and pressure as the boiler water. Before this high energy water is discharged into the environment, it is often sent to a heat exchanger and flash tank. Flash tanks permit the recovery of low-pressure flash steam, which can be used in deaeration or process heating. They also permit the use of a smaller heat exchanger than would be required without the flash tank. Blowdown heat exchangers are most often used to preheat boiler makeup water.

For more information on boiler blowdown, see the Steam Tip Sheets #9 and #10, Minimize Boiler Blowdown, and Recover Heat from Boiler Blowdown at: manufacturing.energy.gov .

## Distribution

The distribution system transports steam from the boiler to the various end uses. Although distribution systems may appear to be passive, in reality, these systems regulate the delivery of steam and respond to changing temperature and pressure requirements. Consequently, proper performance of the distribution system requires careful design practices and effective maintenance. The piping should be properly sized, supported, insulated, and configured with adequate flexibility. Pressure-regulating devices such as pressure-reducing valves and backpressure turbines should be configured to provide proper steam balance among the different steam headers. Additionally, the distribution system should be configured to allow adequate condensate drainage, which requires adequate drip leg capacity and proper steam trap selection. Steam distribution systems can be broken down into three different categories: buried pipe, above-ground, and building sections, and selection of distribution components (piping, insulation, etc.) can vary depending on the category.

## Selected Energy Efficiency Practices for Steam Distribution Systems

- ■ ■ Validate energy intensity baseline and improvements with ASME Steam System Assessment Standard.
- ■ ■ ocate  improved  profit  opportunities  with  data L sources, such as wireless sensors, near your largest steam traps.
- ■ ■ Configure distribution systems to include adequate condensate drainage in startup and operating modes, for flash steam recovery and for optimized condensate return to the boiler.

## Piping

Steam piping transports steam from the boiler to the enduse services. Important characteristics of well-designed steam system piping are that it is adequately sized, configured, and supported. Installation of larger pipe diameters may be more expensive, but can create less pressure drop for a given flow rate. Additionally, larger pipe diameters help to reduce the noise associated with steam flow. As such, consideration should be given to the type of environment in which the steam piping will be located when selecting the pipe diameter. Important configuration issues are flexibility and drainage. With respect to flexibility, piping (especially at equipment connections), needs to accommodate thermal reactions during system start-ups and shutdowns. Additionally, piping should be equipped with a sufficient number of appropriately sized drip legs to promote effective condensate drainage. Additionally, the piping should be pitched properly to promote the drainage of condensate to these drip lines. Typically, these drainage points experience two very different operating conditions, normal operation and start-up; both load conditions should be considered in the initial design.

## Insulation

Thermal insulation provides important safety, energy savings, and performance benefits. In terms of safety, insulation reduces the outer surface temperature of the steam piping, which lessens the risk of burns. A well-insulated system also reduces heat loss to ambient workspaces, which can make the work environment more comfortable. Consequently, the energy saving benefits include reduced energy losses from the steam system and reduced burden on the cooling systems that remove heat from workspaces. In addition to its safety and energy benefits, insulation increases the amount of steam energy available for end uses by decreasing the amount of heat lost from the distribution system. See the Mechanical Insulation Design Guide , at www.wbdg.org/midg , for more on steam system insulation.

Important insulation properties include thermal conductivity, strength, abrasion resistance, workability, and resistance to water absorption. Thermal conductivity is the measure of heat transfer per unit thickness. Thermal conductivity of insulation varies with temperature; consequently, it is important to know the right temperature range when selecting insulation. Strength is the measure of the insulation's ability to maintain its integrity under mechanical loads. Abrasion resistance is the ability to withstand shearing forces. Workability is a measure of the ease with which the insulation is installed. Water absorption refers to the tendency of the insulation to hold moisture. Insulation blankets (fiberglass and fabric) are commonly used on steam distribution components (valves, expansion joints, turbines, etc.) to enable easy removal and replacement for maintenance tasks.

Some common insulating materials used in steam systems include calcium silicate, mineral fiber, fiberglass, perlite, and cellular glass. The American Society for Testing and Materials (ASTM) provides standards for the required properties of these and other insulation materials. Additionally, the North American Insulation Manufacturers Association (NAIMA) has developed a software program titled 3E Plus that allows users to determine the energy losses associated with various types and thicknesses of insulation. The 3E Plus program facilitates the assessment of various insulation systems to determine the most cost-effective solution for a given installation. See Section 2, for more about 3E Plus Insulation software, which can help steam users assess insulation opportunities.

For more information on insulation, refer to Steam Tip Sheets #2 and #17, Insulate Steam Distribution and Condensate Return Lines and Install Removable Insulation on Uninsulated Valves and Fittings at: manufacturing.energy.gov .

## Selected Energy Efficiency Practice for Valves

- ■ ■ Locate improved profit opportunities with data sources, such as wireless sensors, near your largest valves.
- ■ ■ Use backpressure turbines, where possible, to avoid energy losses associated with pressure reductions through valves. See Steam Tip Sheet #20, Replace Pressure Reducing Valves with Backpressure Turbogenerators .

## Valves

In steam systems, the principal functions of valves are to isolate equipment or system branches, to regulate steam flow, and to prevent over-pressurization. The principal types of valves used in steam systems include gate, globe, swing check, pressure reducing, and pressure relief valves. Gate, globe, and swing check valves typically isolate steam from a system branch or a component.

Pressure reducing valves (PRV) typically maintain certain downstream steam pressure conditions by controlling the amount of steam that is passed. These reducing valves are often controlled by transmitters that monitor downstream conditions. Pressure relief valves release steam to prevent over-pressurization of a system header or equipment.

## Steam Separators

In some steam systems, wet steam is generated. This wet steam contains water droplets that can reduce the effectiveness of the steam system. Water droplets erode piping elbows, turbine blades and passages, and pressure reducing valves, thus reducing efficiency and life. Furthermore, liquid water can significantly reduce heat transfer rates in heat exchange components, as well as result in water hammer. Removing water droplets before they reach end-use equipment is necessary.

Steam separators remove water droplets, generally relying on controlled centrifugal flow. This action forces the entrained moisture to the outer wall where it is removed from the separator. The means of moisture removal could be a steam trap or a drain. Some manufacturers include the trap as an integral part of the unit. Additional accessories include water gauge connections, thermometer connections, and vent connections.

Steam separators can be installed in either a horizontal or vertical line. They are capable of removing 99% of particulate entrainment 10 microns and larger over a wide range of flows. Separators are often designed in accordance with ASME Code, Section VIII, Division 1, with pressures to 300 psig.

## Steam Accumulators

A steam accumulator is a large insulated pressure vessel, partially filled with hot water (saturated liquid). When steam supply exceeds demand, the excess high-pressure steam is charged into the accumulator through special charging nozzles. The steam is condensed, giving up its latent heat, to raise the pressure, temperature, and heat content of the water body. When the steam demand exceeds the supply, the pressure in the accumulator drops and the additional required steam flashes from the water, taking back the heat previously stored. A simple system of control valves and check valves regulates the charging and discharging. The excess steam is charged quietly and smoothly, and when steam is needed, it is available with the speed of a control valve operation. There is also an accumulator design that stores hot water for use as boiler feedwater.

## Steam Traps

Steam traps are essential for proper distribution system performance. During system start-ups, traps allow air and large quantities of condensate to escape. During system operation, the traps allow collected condensate to pass into the condensate return system, while minimizing the accompanying loss of steam. There are three primary types of traps: thermostatic, mechanical, and thermodynamic. 8

## Selected Energy Efficiency Practices for Steam Traps

- ■ ■ Validate  energy  intensity  improvement  oppor -tunities with ASME Steam System Assessment Standard.
- ■ ■ Improve profits with data from wireless sensors at steam traps by continuously monitoring and alarming for leakage. If you try one, chances are you'll want more. Favorable returns on investments have been reported in their use.
- ■ ■ Several types of steam traps, including mechanical traps, are highly sensitive to correct installation arrangement and even insulation quantity to operate properly. Follow the installation and insulation guidance of the trap manufacturer carefully.

## Thermostatic Traps

Thermostatic traps use temperature differential to distinguish between condensate and live steam. This differential is used to open or close a valve. Under normal operating conditions, the condensate must cool below the steam temperature before the valve will open. Common types of thermostatic traps include bellows and bimetallic traps.

Bellows traps. Bellows traps include a valve element that expands and contracts in response to temperature changes. Often a volatile chemical such as alcohol or water is inside the element. Evaporation provides the necessary force to change the position of the valve. At start-up, the bellows trap is open due to the relative cold condition. This operating condition allows air to escape and provides maximum

8 The discussion of steam traps is based extensively on C.B. Oland, Review of Orifice Plate Steam Traps , Oak Ridge National Laboratory, January 2001.

## STEAM SYSTEM BASICS

condensate removal when the load is the highest. Bellows traps can fail either open or closed. The configuration of a bellows steam trap is shown in Figure 5.

Figure 5. Thermostatic Steam Trap with a Bellows Element

<!-- image -->

Bimetallic traps. Bimetallic traps rely on the bending of a composite strip of two dissimilar metals to open and close a valve. Air and condensate pass freely through the valve until the temperature of the bimetallic strip approaches the steam temperature. After steam or relatively hot condensate heats the bimetallic strip and causes it to close the valve, the trap remains shut until the temperature of the condensate cools sufficiently to allow the bimetallic strip to return to its original shape and thereby open the valve. Bimetallic traps can fail in either the open or closed position. The configuration of a bimetallic steam trap is shown in Figure 6.

Figure 6. Thermostatic Steam Trap with a Bimetallic Element

<!-- image -->

## Mechanical Traps

Mechanical traps use the difference in density between condensate and live steam to produce a change in the position of a float or bucket. This movement causes a valve to open or close. There are a number of mechanical trap designs that are based on this principle. They include ball float, float and lever, inverted bucket, open bucket, and float and thermostatic traps.

Ball float traps. Ball float traps rely on the movement of a spherical ball to open and close the outlet opening in the trap body. When no condensate is present, the ball covers the outlet opening, thereby keeping air and steam from escaping. As condensate accumulates inside the trap, the ball floats and uncovers the outlet opening. This movement allows the condensate to flow continuously from the trap. Unless they are equipped with a separate air vent, ball float traps cannot vent air on start-up.

Float and lever traps. Float and lever traps are similar in operation to ball float traps except the ball is connected to a lever. When the ball floats upward due to accumulation of condensate inside the trap body, the attached lever moves and causes a valve to open. This action allows condensate to continuously flow from the trap. If the condensate load decreases and steam reaches the trap, downward ball movement causes the valve to close, thereby keeping steam from escaping. Unless they are equipped with a separate air vent, float and lever traps cannot vent air on start-up. See the discussion on float and thermostatic traps.

Inverted bucket traps. Inverted bucket traps are somewhat more complicated than float and lever traps. At startup, the inverted bucket inside the trap is resting on the bottom of the trap body and the valve to which the bucket is linked is wide open. The trap is initially filled with condensate. As steam enters the trap and is captured inside the bucket, it causes the bucket to move upward. This upward movement closes the valve and keeps steam from escaping. When the condensate collects and cools the steam, the bucket moves downward. This movement causes the valve to open, thereby allowing the condensate to escape. Unlike closed float traps, inverted bucket traps have intermittent discharge. These traps can be depleted of their condensate seal when applied in superheated steam service. If this occurs, the trap will continuously discharge live steam. This trap type is not recommended for superheated steam

Figure 7. Inverted Bucket Steam Trap

<!-- image -->

## STEAM SYSTEM BASICS

service, unless special installation conditions are met. The configuration of an inverted bucket steam trap is shown in Figure 7.

Open bucket traps. Open bucket traps consist of an upright bucket that is attached to a valve. At start-up, the bucket rests on the bottom of the trap body. In this position, the valve is wide open. As condensate accumulates in the trap body on the outside of the bucket, the bucket floats upward, causing the valve to close. When sufficient condensate accumulates outside the bucket, it spills over the top and fills the inside of the bucket. At this time, the bucket sinks, causing the valve to open. This trap is also prone to failure when applied in superheated steam service because of the loss of the condensate seal. Like inverted bucket traps, open bucket traps have intermittent discharge.

Float and Thermostatic (F&amp;T) traps. Float and thermostatic (F&amp;T) traps are similar to float and lever traps except they include a thermostatic element that allows air to be discharged at start-up and during operation. The thermostatic elements used in these traps are the same as those used in thermostatic traps. The configuration of a float and thermostatic steam trap is shown in Figure 8.

Figure 8. Float and Thermostatic Steam Trap

<!-- image -->

## Thermodynamic Traps

Thermodynamic traps use the difference in kinetic energy (velocity) between condensate and live steam to operate a valve. The disc trap is the most common type of thermodynamic trap, but piston or impulse traps are sometimes used.

Disc traps. Disc traps use the position of a flat disc to control steam and condensate flow. When condensate flows through the trap, the disc is raised, thereby causing the trap to open. As steam and air pass through the trap, the disc moves downward. The force that causes the disc to move downward is generated by the difference in pressure between the low-velocity steam above the disc and the high-velocity steam that flows through the narrow gap beneath the disc. Disc traps commonly have an intermittent discharge and, when they fail, they normally fail open. The configuration of a disc steam trap is shown in Figure 9. Generally, the air removal capability of this trap type is poor unless equipped with additional components (like the float and thermostatic trap).

Figure 9. Thermodynamic Disc Steam Trap

<!-- image -->

Piston traps. Piston or impulse traps utilize the heat energy in hot condensate, and the kinetic energy in steam, to open and close a valve. Like disc traps, piston traps are phase detectors that sense the difference between a liquid and gas or vapor. They continuously discharge any air and condensate. Their primary failure mode is open.

Lever traps. Lever traps are a variation of the thermodynamic piston trap. They operate on the same principal as a piston trap but with a lever action to pass large amounts of condensate and air on a continuous basis. Their primary failure mode is open.

Orifice traps. Orifice traps are of two basic types: orifice plate and short tube. Both trap types operate under the exact same principles. A simple orifice plate steam trap consists of a thin metal plate with a small-diameter hole (orifice) drilled through the plate. When installed, condensate that accumulates is continuously removed as the steam pressure forces the condensate through the orifice. During conditions when no condensate is present, a limited amount of steam flows through the orifice. The report Review of Orifice Plate Steam Traps in the Where to Find Help section provides information for making informed

decisions about when orifice plate steam traps should be considered for use in new or existing steam systems.

Additional information regarding steam traps is available in the Steam Tip Sheet #1, Inspect and Repair Steam Traps at: manufacturing.energy.gov .

## Steam Meters

The use of flowmeters within the distribution system can provide important data for monitoring the efficiency of a process or an end use. Tracking the amount of steam required can be particularly useful in benchmarking efforts. The types of steam flowmeters are discussed in the Generation Section. The DOE Federal Energy Management Program has a Metering Best Practices Guide , Release 2.0 , which includes steam use: femp.energy.gov .

## End Use

Steam system end-use equipment transfers steam energy into other forms of useful energy. Common end-use equipment includes heat exchange devices to transfer thermal energy and turbines to recover mechanical energy. In manufacturing industries, steam end uses often directly support production, making their performance and reliability essential to plant productivity. Improvements in end-use efficiency and effectiveness also tend to result in better performance and increased reliability. There is a wide range of end-use equipment, largely because of the advantages of steam that are discussed in the Introduction. Some of the major end-use components are discussed in this section.

For the purposes of this discussion, steam end-use equipment is grouped into three basic categories:

- ·    Industries of key end-use equipment in Energy Intensive Industries
- •    Conditioning and control equipment
- •    Additional equipment

The key equipment category includes the largest uses of steam in those industries. Although facilities use steam for other services as well, the key end uses account for the largest amount of steam use. The conditioning equipment category includes equipment that facilitates the effective use of steam. The additional equipment category includes equipment that is used in other industries and, though significant, does not account for most of the steam use in energy intensive industries.

## Key End-Use Equipment in Energy Intensive Industries

In the three industries of forest products, petroleum refining, and chemicals, steam accounts for the largest amount of end-use energy. In integrated steel production, steam represents a significant amount of end-use energy and is used to generate most of that industry's on-site electric power. Table 1 provides a list of key steam-supplied enduse equipment for energy intensive industries.

## Condensers

In steam applications, condensers are associated with condensing steam turbines and with multiple stage ejector systems. In steam turbine applications, condensers typically operate under a vacuum. They remove energy from the exhaust steam, allowing it to be recovered as condensate. In steam ejector applications, condensers increase the effectiveness of the ejectors by condensing both the motive steam and condensables pulled from the process, reducing the amount of motive steam required.

Condensers can be surface type or barometric. Surface condensers are supplied with cooling water that circulates through condenser tubes, providing a cool surface area that causes steam condensation. The condensate is typically collected in a condensate well, and pumped into the condensate return system. Barometric condensers rely on direct contact between the cooling water and the steam. In petroleum refining and chemical manufacturing applications, condensers are also used to condense components from gaseous mixtures. In these applications, the condensers use a cooling medium to extract energy from the gases and collect the condensed components.

## Distillation Towers

The petroleum refining and chemical manufacturing industries use large amounts of steam to facilitate the separation of crude oil or chemical feedstocks into various components. This separation process relies on differences in the boiling points of these hydrocarbon components. Fractionating towers use a furnace to heat crude oil above 700°F. As the volatile components boil off and rise up the tower, they cool and condense on trays. Steam is injected into the bottom of these towers to reduce the partial pressures of the hydrocarbons, which facilitates their separation, and to reduce coke formation on tray and tower surfaces.

## STEAM SYSTEM BASICS

Table 1. Steam End-Use Equipment in Energy Intensive Industries

| Equipment              | Process Application                                                                                                                                                                                | Industry                                                                                               |
|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|
| Condenser              | Steam turbine operation                                                                                                                                                                            | Aluminum, Chemical Manufacturing, Forest Products, Glass, Metal Casting, Petroleum Refining, and Steel |
| Distillation tower     | Distillation, fractionation                                                                                                                                                                        | Chemical Manufacturing, Petroleum Refining                                                             |
| Dryer                  | Drying                                                                                                                                                                                             | Forest Products                                                                                        |
| Evaporator             | Evaporation/concentration                                                                                                                                                                          | Chemical Manufacturing, Forest Products, Petroleum Refining                                            |
| Process heat exchanger | Alkylation, process air heating, process water heating, gas recovery/light ends distillation, isomerization, storage tank heating, visbreaking/coking                                              | Aluminum, Chemical Manufacturing, Forest Products, Glass, Metal Casting, Petroleum Refining, and Steel |
| Reboiler               | Fractionation                                                                                                                                                                                      | Petroleum Refining                                                                                     |
| Reformer               | Hydrogen generation                                                                                                                                                                                | Chemical Manufacturing, Petroleum Refining                                                             |
| Separator              | Component separation                                                                                                                                                                               | Chemical Manufacturing, Forest Products, Petroleum Refining                                            |
| Steam ejector          | Condenser operation, vacuum distillation                                                                                                                                                           | Aluminum, Chemical Manufacturing, Forest Products, Glass, Metal Casting, Petroleum Refining, and Steel |
| Steam injector         | Agitation/blending, heating                                                                                                                                                                        | Chemical Manufacturing, Forest Products, Petroleum Refining                                            |
| Steam turbine          | Power generation, compressor mechanical drive, hydrocracking, naphtha reforming, pump mechanical drive, feed pump mechanical drive                                                                 | Aluminum, Chemical Manufacturing, Forest Products, Glass, Metal Casting, Petroleum Refining, and Steel |
| Stripper               | Distillation (crude and vacuum units), catalytic cracking, asphalt processing, catalytic reforming, component removal, component separation, fractionation, hydrogen treatment lube oil processing | Chemical Manufacturing, Petroleum Refining                                                             |
| Thermo- compressor     | Drying, steam pressure amplification                                                                                                                                                               | Forest Products                                                                                        |

## STEAM SYSTEM BASICS

## Dryers

Dryers reduce the water content of a solid. Dryers account for the largest end use of steam in the pulp and paper industry.  The chemical manufacturing, textiles, and food 9 processing industries also use large amounts of steam for drying. Dryers can be indirect or direct. Indirect dryers remove moisture thermally as energy is transferred from condensing steam, flue gases, or high temperature process fluid to the product being dried. Common indirect dryer types are coil and rotating drum. Direct dryers use hot gases that have been heated with steam or flue gases to directly contact and dry a product.

Dryers, like evaporators, can be arranged in multiplestage configurations. Multiple-stage steam dryers use a cascading set of steam pressures, allowing steam released from an upstream stage to supply steam to the next stage. In many multiple-stage dryers, thermocompressors are used to increase the steam pressure of downstream-effect stages.

## Evaporators

Evaporators reduce the water content of a liquid, generally by heating it with steam to concentrate the product. Evaporators are used extensively in industries such as food processing, chemical manufacturing, steel, forest products, and textiles.

In most cases, evaporators are shell and tube heat exchangers with the steam on the shell side and the product being concentrated in the tubes. Evaporators can be single effect or multiple effect. A single-effect evaporator uses steam at one set of pressure and temperature conditions to boil off the vapor from a product. Multiple-effect evaporators take the vapor produced from one evaporator and use it to heat the product in a lower-pressure evaporator. Multiple-effect evaporators are generally more efficient at concentrating a fluid than single-effect evaporators.

## Heat Exchangers

Heat exchangers transfer thermal energy from one fluid to another. In manufacturing facilities, steam is a common source of heat for many reasons, some of which are discussed in the Introduction. There is a wide range of heat exchanger designs that use steam, largely due to the wide range of products that are heated with steam.

9 Scoping Study of the Pulp and Paper Industry , Giese &amp; Associates, EPRI, 1988.

Many process and product considerations must be incorporated into the selection of a heat exchanger. Some basic heat exchanger types are discussed below, including:

- •  Tubular
- •  Plate and frame
- •  Jacketed
- •  Coil.

Figure 10. Shell and Tube Heat Exchanger

<!-- image -->

Tubular heat exchanger. Tubular heat exchangers are tube bundles that are surrounded by the heated or heating medium. This type of heat exchanger includes finned tube and shell and tube designs as shown in Figure 10. Finned tube heat exchangers are often used to heat air for drying and space heating applications. Shell and tube heat exchangers are often used for liquid heating and evaporation. Since the tube side of shell and tube heat exchangers can be designed to withstand high pressures, sometimes exceeding 1,500 psig, heat exchangers of this type are often used in high-temperature and high-pressure applications.

Plate and frame heat exchanger. In plate and frame heat exchangers, the two heat exchange fluids are separated by plates. The plates are corrugated, or ridged, as shown in Figure 11, to increase the surface area available for heat transfer. Plate and frame heat exchangers are often used in low-viscosity applications, where the risk of clogging is less severe. The plate ends are typically sealed by covers with gaskets covers that can be removed to allow disassembly and cleaning. This heat exchanger type is used when temperatures and pressures are moderately low, typically below 300°F and 370 psi. Plate and frame heat exchangers also have a common design variation that has the plates welded or brazed together. This allows higher temperature service but eliminates the possibility of mechanical cleaning.

Figure 11. Components of a Plate and Frame Heat Exchanger

<!-- image -->

Figure 12. Configuration of a Jacketed Kettle Heat Exchanger

<!-- image -->

Jacketed heat exchangers. Jacketed heat exchangers use an enclosure to surround the vessel that contains the heated product. A common example of a jacketed heat exchanger is the jacketed kettle. A representation of a jacketed heat exchanger is shown in Figure 12. Jacketed heat exchangers are practical for batch processes and for product types that tend to foul or clog tube bundles or coils.

Coil heat exchangers. Coil heat exchangers characteristically use a set of coils immersed in the medium that is being heated. Coil heat exchangers are generally compact, offering a large heat transfer area for the size of the heat exchanger.

## Reboilers

Reboilers are typically used in distilling processes to increase component separation. Reboilers use heat, often provided by steam, to evaporate the volatile components of a product that has been drawn from a fractionating tower. These volatile components are sent downstream for further processing. The residual components are sent back into the fractionating tower or sent on to a vacuum distillation process. There are several types of reboilers, including jacketed kettle, kettle, internal reboiler, and thermosyphon reboiler. These designs differ from one another in the way the product is heated with steam.

## Reformers

Steam reformers are used to generate hydrogen, typically from a hydrocarbon feedstock such as methane (the largest component of natural gas). In turn, hydrogen is used in many petroleum refining and chemical manufacturing processes. Reformers use steam for both energy and as a source of hydrogen. Steam is injected with the hydrocarbon feedstock to initiate the following reaction:

<!-- image -->

| CH 4    | H 2 O   | CO              | 3H 2     |
|---------|---------|-----------------|----------|
| Methane | Steam   | Carbon monoxide | Hydrogen |

Reformers often have secondary stages that are used to convert the carbon monoxide to carbon dioxide and additional hydrogen. Although large amounts of steam are used throughout the reforming processes, steam is also generated by the reformers and is sometimes exported for other uses.

## Steam Ejectors

Steam ejectors use steam flow through a nozzle to create a vacuum (similar in operation to thermocompressors). They are used in several different types of system applications and process equipment. Low-pressure conditions promote the evaporation of liquids at reduced temperatures.

Consequently, many chemical manufacturing processes use steam ejectors to increase the concentration of a product. In petroleum refining, steam ejectors are commonly used in the vacuum distillation of heavy hydrocarbon products. Steam ejectors are also used to initiate and maintain vacuum condition in the condensers of condensing turbines.

## Steam Injectors

Steam injectors are used to inject steam directly into a tank or a pipe containing a process fluid, generally for heating purposes. Many injector types use a nozzle and a diffuser to pull process fluid into the steam before the mixture is injected into the process fluid, to promote an even distribution of heat. Important performance characteristics of injectors include accurate control of the amount of steam injected and effective mixing of the steam and process.

## Steam Turbines

Steam turbines are used to drive electric generators or other rotating machinery such as compressors, pumps, and fans. Steam turbines are used in many different system designs, depending on the relative requirements for steam, electricity, or other mechanical loads. Steam turbines provide an effective means of stepping down steam pressure while extracting mechanical work.

Additional information regarding steam turbines is available in Steam Tip Sheets #15 and #21, titled Benchmark the Fuel Costs of Steam Generation and Consider Steam Turbine Drives for Rotating Equipment at: manufacturing.energy.gov .

Some turbines have interstage take-offs that allow steam to be extracted at various pressures before reaching the turbine exhaust. These extractions provide flexibility in meeting competing requirements of both the steam system and the mechanical load. For example, if the turbine is connected to an electric generator, adjusting the amount of extracted steam can allow more or less electric power to be generated, while making respectively less or more steam available to the plant.

Backpressure turbines. Backpressure turbines exhaust steam at pressures that are higher than atmospheric, and the exhaust steam is then used for other services. By extracting mechanical work from steam, backpressure turbines can provide an efficient means of supplying lowerpressure steam from a high-pressure header.

Condensing turbines. Condensing turbines exhaust steam to vacuum (sub-atmospheric) conditions. This steam is condensed in a heat exchanger, referred to as a condenser, and transferred to the condensate return system. Condensing turbines typically require a source of cooling water to condense the steam.

## Strippers

Steam strippers are used to remove contaminants from a solution. Strippers are commonly found in petroleum refining and chemical manufacturing applications, where process solutions contain components that have different boiling points and removal of one or more of the components is necessary. Injecting steam into the process solution lowers the partial pressure of volatile components, allowing some of them to vaporize and get transported away with the steam. Steam can also raise the temperature of the mixture, lowering the solubility of the objectionable material and causing it to strip off with the steam. Often, the steam and the contaminants are condensed and separated, allowing recovery of the condensate and disposal or further processing of the contaminant.

## Thermocompressors

Thermocompressors combine high-pressure and lowpressure steam to form an intermediate-pressure steam supply (see Figure 13). Often the low-pressure steam does not have enough energy to be feasibly used; however, discharging it to the condensate return system can be an unnecessary energy loss. Thermocompressors use a highpressure steam source to recover the energy from this lowpressure source, providing an intermediate steam supply that can be feasibly used.

Figure 13. Thermocompressor Operation

<!-- image -->

## Conditioning and Control Equipment

Conditioning equipment is generally used to improve the performance of, or to protect the end-use equipment. For example, desuperheaters are often used to control the energy of a steam supply to end-use equipment to reduce the risk of damage to the equipment or to effectively improve temperature control of the process.

## STEAM SYSTEM BASICS

Desuperheaters. The purpose of a desuperheater is to remove the superheat from steam. The majority of heating and process equipment performs more efficiently using saturated rather than super-heated steam. Desuperheaters inject a very fine mist of high-purity water, such as condensate, into the steam flow. The superheated vapor gives up heat to the water mist, and by doing so, reduces its temperature.

Vacuum breakers. Vacuum conditions can develop in a steam system when steam flow into a component or a branch is throttled or shut off. If the rate of downstream steam use exceeds the steam supply, the pressure decreases and vacuum conditions can form. Vacuum conditions also result when the load on the heat exchanger is significantly less than the heat exchanger capacity. If the pressure in the heat exchanger drops too far, the condensate will not drain from the trap due to a higher pressure on the trap's downstream side. If uncorrected, the condensate level will rise in the heat exchanger, reducing the available heat transfer area and increasing the risk of corrosion by condensate. Vacuum breakers are pressure-controlled devices that essentially vent a heat exchanger or system branch in which a vacuum has formed. By allowing in air when they open, vacuum breakers restore pressure and allow the condensate to drain.

Air vents. Before start-up, the steam system contains air that must be removed. The presence of air in a steam system reduces heat transfer effectiveness and promotes condensate corrosion. Air vents remove this air. Air vents are often thermostatic devices, similar to thermostatic steam traps that rely on the temperature difference between air and steam. When exposed to the lower temperature air in the system side, the vent opens. As the higher temperature steam reaches the vent, it closes, preventing the escape of steam.

Traps. Steam traps are important to the performance of end-use equipment. Traps provide for condensate removal with little or no steam loss. If the traps do not function properly, excess steam will flow through the end-use device or the condensate will back up into it.

Excess steam loss will lead to costly operation, while condensate backup will promote poor performance and may lead to water hammer. Traps can also remove noncondensable gases that reduce heat exchanger effectiveness. There are several different types of steam traps, which are discussed in the Distribution section of this sourcebook.

## Insulation

End-use equipment, such as heat exchangers and turbines, should generally be insulated due to the significant heat loss that the surface areas of this equipment can provide. The various types of insulation are discussed in the Distribution section. Where end-use equipment requires frequent inspection or maintenance, removable insulation should be considered.

## Additional Equipment

The additional equipment category refers to end uses of steam throughout industry; although still significant, these generally account for less steam energy than key end uses.

Absorption chillers. Absorption chillers provide cooling using an interesting variation of the vapor compression cycle. Instead of a compressor, which is generally used in chillers, absorption chillers exploit the ability of one substance to absorb a refrigerant at one temperature and then release it at another. In ammonia-based systems, water is the absorbent and ammonia is the refrigerant. In lithium bromide-based systems, lithium bromide is the absorbent, while water is the refrigerant. An absorption chiller uses a pump instead of a compressor to increase refrigerant pressure. Once it is at the higher pressure, the absorbent/refrigerant solution is heated, often with steam, which releases the refrigerant. Although absorption chillers generally have lower coefficients of performance (COP) (indicating lower thermodynamic efficiency) than traditional chillers, they use less electric power per ton of cooling and are well suited for use with steam systems.

Humidifiers. Humidifiers inject steam into an air or other gas source to increase its water vapor content. In humidification, steam is used as a source of both water and energy. Humidification applications are found in the chemical manufacturing industry where control of ambient temperature and moisture content are critical for product quality.

Preheat/Reheat air handling coils. While steam is occasionally used in space heating applications to preheat and reheat air, there are other more efficient methods of controlling space humidity levels. In many HVAC systems, the conditioned air must have both its temperature and humidity adjusted. In preheat applications, steam is used to heat an air supply, which is typically a mixture of return air and outside air. The air is then conditioned to achieve a certain humidity and temperature. In reheat applications, the air is cooled to a particular dew point to remove water

and achieve a desired humidity. As a result, before the air is delivered back to the workspaces, steam coils must reheat the process air stream up to the proper temperature. In both reheat and preheat applications, finned tube heat exchangers are generally used.

Tracing. In tracing applications, steam is used to maintain the temperature of a fluid in a pipe. A common application of tracing lines is to prevent the freezing of a process fluid in piping that runs outside of a temperature-controlled area. Since tracing lines are exposed to freezing conditions, proper insulation, steam flow, and condensate drainage are essential to prevent freezing of the tracing lines as well as the process piping.

Meters. Steam meters are used to measure steam flow, and are important for tracking the steam use of a particular part of a steam system or a particular end use. Discussion of different meter types is provided in the Steam Generation section.

## Recovery

The recovery components of a steam system collect and return condensate back to the generation part of the system. Condensate recovery provides thermal and water treatment benefits. Condensate that is not returned must be compensated for by the addition of makeup water, which is generally much cooler than condensate, however it is becoming less commonly available. Condensate temperature often exceeds 200°F, while makeup water temperature is typically between 50°F and 80°F. As a result, the enthalpy difference between condensate and makeup water is generally over 120 Btu/lb, an amount of energy that is often more than 10% of the energy in the boiler generated steam.

Additionally, makeup water is generally treated with chemicals that remove minerals and establish certain pH levels in the boiler water and in the system. Reducing the amount of makeup water added to the system reduces chemical use. Additionally, some of the treatment chemicals that are contained in condensate are problematic to a plant's wastewater treatment facility. Industrial steam plants often extend across large areas. Recovering condensate from steam systems requires piping, collecting tanks, pumping equipment, and, in many cases, flash steam separators, meters, and filtration/cleanup equipment. However, the cost savings available from avoiding the purchase, treatment, and heating of makeup water often make investments in condensate recovery systems highly feasible.

For more information on condensate recovery, see the Steam Tip Sheet #8, Return Condensate to the Boiler at: manufacturing.energy.gov.

## Condensate Return Piping

Condensate return piping transports condensate as it drains from distribution and end-use equipment piping back to the boiler. Condensate piping should be adequately sized and insulated. Although the installation of larger pipe diameters is more expensive, larger pipes create less pressure drop for a given flow rate; this reduces the load on the condensate pumps. Larger pipe diameters also reduce the noise associated with condensate flow and are more suitable for carrying flash steam. Insulating the condensate piping helps to retain the thermal energy that provides much of the benefits of a condensate recovery system.

See Pump Tip Sheet #9, Reduce Pumping Costs Through Optimum Pipe Sizing at: manufacturing.energy.gov.

## Insulation

Insulation provides energy savings and safety benefits. In terms of energy savings, insulation reduces heat loss from the condensate piping and recovery equipment surfaces, which can make the surrounding work environment more comfortable. Reducing this heat loss can also reduce the burden on the cooling systems that support surrounding workspaces. In terms of safety, insulation reduces the outer surface temperature of the piping, which lessens the risk of burns. Important insulation properties and characteristics of piping insulation are discussed in the Distribution section. See Tip Sheet #2, Insulate Steam Distribution and Condensate Return Lines at: manufacturing.energy.gov.

## Condensate Receiver Tanks

Condensate receiver tanks collect and store condensate. These tanks are usually located remotely around the condensate system and are configured in conjunction with condensate pumps, as shown in Figure 14. Condensate flows can be highly variable due to changes in steam demand, especially during system start-ups. Receiver tanks minimize the effects of this flow variability on condensate pumps by providing storage, which maintains a minimum water level that prevents downstream condensate pumps from running dry. Since many condensate pumps are centrifugal types, it is important to keep a certain suction pressure to prevent cavitation damage. By maintaining a minimum condensate level, receiver tanks provide enough static pressure to avoid cavitation.

## STEAM SYSTEM BASICS

Most systems also contain a large condensate receiver tank that collects all the condensate returned from the system. This tank may also be used to store pretreated water.

Figure 14. Condensate Receiver Tank and Pump Combination

<!-- image -->

## Condensate Pumps

Condensate pumps move condensate from receiver tanks back to the boiler room. Condensate pumps can be driven by electric motors, steam, or compressed air, depending on the availability of these sources. Motor-driven condensate pumps are usually centrifugal type pumps. In many cases, receiver tanks and motor-driven pumps are packaged together and equipped with a control system that de-energizes the pump under low water level conditions. Steam or compressed air powered condensate pumps are used where electrical pumps would not be suitable, and are generally pressure-powered pumps.

Condensate pumps also can be important to the performance of end-use equipment. Effective use of condensate pumps can eliminate condensate backup into end-use equipment, improving process control and reducing potential equipment problems from condensate acidification and water hammer.

## Flash Steam Vessels

Flash steam vessels allow the recovery of steam from condensate lines, as illustrated in Figure 15. By removing steam from the condensate system, flash steam vessels provide an efficient source of steam to low-pressure end uses. For example, 250°F condensate has a saturation pressure of about 15 psig. Consequently, steam that is separated by flash steam vessels can be used in low-pressure steam applications such as space heating and preheating.

For more information on flash steam vessels, see the Steam Tip Sheet #12, Flash High-Pressure Condensate to Regenerate Low-Pressure Steam at: manufacturing.energy.gov .

## Condensate Meters

Condensate meters measure the flow rate of condensate in the return system. Knowing the condensate flow rate can be helpful in monitoring the condensate system and the condition of steam traps. Condensate meters are often inline rotary types, relying on turbine or scroll rotation to measure flow rate.

## Filtration/Cleanup Equipment

In many systems, the flow of steam and condensate picks up rust, scale, and trace contaminants that are either carried over from the boiler or that form in carbon steel piping and on copper alloy heat exchange surfaces. Although strainers and filters are used to catch the particulate matter, some contaminants are dissolved in the condensate and can cause problems if returned to the boiler. In systems that require a high level of cleanliness, condensate polishers are used. Condensate polishers use ion exchange to remove these contaminants, preventing the redeposition of these contaminants on boiler surfaces.

Figure 15. Flash Steam Recovery Vessel

<!-- image -->

This page intentionally left blank

## SECTION 2: PERFORMANCE IMPROVEMENT OPPORTUNITIES

## Overview

Several important factors should be considered when industrial facilities seek to improve steam system performance and to lower operating costs. Improving steam system performance requires assessing the entire system, identifying opportunities, and selecting and implementing the most feasible projects. In turn, this requires a systems approach. Similarly, proper selection of the best projects requires quantifying the benefits and costs of each project. Successful implementation of these projects requires the participation of all system stakeholders including production, maintenance, and management. Generally, obtaining management participation requires communication of the analyses in economic terms. To address these considerations, this section of the sourcebook discusses:

the broader issue of how system parameters affect the equipment. Similarly, a common engineering approach is to break a system down into its basic components or modules, optimize the selection or the design of these components, and then assemble these components to form the system. An advantage to this approach is that it simplifies problems. However, a disadvantage is that it often overlooks the interaction of these components. In contrast, a systems approach evaluates the entire system to determine how the end-use requirements can be most effectively and efficiently served.

- •  The systems approach
- •    Common performance improvement opportunities
- ·    Resources that can help identify and assess opportunities
- •    The economics related to steam system improvements.

## Energy Efficiency Statistics

The latest statistics for energy efficiency participation can be found at www.eia.gov in the Manufacturing Energy Consumption data, Consumption and Efficiency section under the Sources &amp; Uses tab.

## Systems Approach

Because of the many industrial uses for steam, there are wide ranges of steam system sizes, configurations, end-use applications, and operating practices. As a result, there are many different ways to improve steam system performance and identify improvement opportunities. In general, performance is most effectively optimized when a systems approach is used.

A systems approach analyzes both the supply and demand sides of the system and how they interact, essentially shifting the focus from individual components to total system performance. Often, operators are so focused on the immediate demands of the equipment that they overlook

A systems approach also recognizes that system efficiency, reliability, and performance are closely related. For example, an efficiency loss such as heat loss across uninsulated pipe surfaces reduces energy available to the end uses and requires boilers to work harder to meet a given demand. Often, energy losses create additional system stresses that accelerate wear and that can create loads for which the system was not originally designed.

Common performance improvement opportunities for the generation, distribution, and recovery areas of a steam system are listed in Table 2.

## Strategic, Performance Improvement OpportunitiesManagement-Based Systems

## Systems, Standards, and Certification

AMO works with U.S. industry to support the development of energy management standards and a related certification program anchored to a viable business case. Similar to environmental or quality management systems, changing how energy is managed has resulted in substantial energy performance improvements.

Visit www.eere.energy.gov/energymanagement/ to learn how the various standards are related, as well as information on a web-based toolkit that organizations can use to implement an energy management system consistent with ISO 50001 standards and other existing management standards.

Table 2. Common Performance Improvement Opportunities for the Generation, Distribution, and Recovery Parts of Industrial Steam Systems

| Opportunity                                                                              | Description                                                                                                                                     |
|------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| Generation                                                                               | Generation                                                                                                                                      |
| Minimize excess air                                                                      | Reduces the amount of heat lost up the stack, allowing more of the fuel energy to be transferred to the steam                                   |
| Clean boiler heat transfer surfaces                                                      | Promotes effective heat transfer from the combustion gases to the steam                                                                         |
| Install heat recovery equipment (feedwater economizers and/or combustion air preheaters) | Recovers available heat from exhaust gases and transfers it back into the system by preheating feedwater or combustion air                      |
| Improve water treatment to minimize boiler blowdown                                      | Reduces the amount of total dissolved solids in the boiler water, which allows less blowdown and therefore less energy loss                     |
| Recover energy from boiler blowdown                                                      | Transfers the available energy in a blowdown stream back into the system, thereby reducing energy loss                                          |
| Add/restore boiler refractory                                                            | Reduces heat loss from the boiler and restores boiler efficiency                                                                                |
| Optimize deaerator vent rate                                                             | Minimizes avoidable loss of steam                                                                                                               |
| Distribution                                                                             | Distribution                                                                                                                                    |
| Repair steam leaks                                                                       | Minimizes avoidable loss of steam                                                                                                               |
| Minimize vented steam                                                                    | Minimizes avoidable loss of steam                                                                                                               |
| Ensure that steam system piping, valves, fittings, and vessels are well insulated        | Reduces energy loss from piping and equipment surfaces                                                                                          |
| Implement an effective steam-trap maintenance program                                    | Reduces passage of live steam into condensate system and promotes efficient operation of end-use heat transfer equipment                        |
| Isolate steam from unused lines                                                          | Minimizes avoidable loss of steam and reduces energy loss from piping and equipment surfaces                                                    |
| Utilize backpressure turbines instead of PRVs                                            | Provides a more efficient method of reducing steam pressure for low- pressure services                                                          |
| Recovery                                                                                 | Recovery                                                                                                                                        |
| Optimize condensate recovery                                                             | Recovers the thermal energy in the condensate and reduces the amount of makeup water added to the system, saving energy and chemicals treatment |
| Use high-pressure condensate to make low-pressure steam                                  | Exploits the available energy in the returning condensate                                                                                       |

## Management Standard - ISO 50001-Plant-Level Energy Management

The energy management standard, ISO 50001, provides a method for integrating continuous improvement in energy efficiency into existing management systems. ISO 50001 creates a framework for organizations to manage energy and improve profitability. The forthcoming industrydesigned American National Standards Institute (ANSI)accredited plant-certification program-known as Superior Energy Performance-will include provisions for conforming to the ISO 50001 energy management standard, as well as achieving annual certification by reaching a defined level of annual, energy-intensity performance improvement.

## Superior Energy Performance cm

Superior Energy Performance (SEP) facilities continuously manage their energy consumption, reduce energy intensity, and validate savings using qualified, independent, measurement and verification entities. Visit www.superiorenergyperformance.net for details.

Proven Results . Several facilities have piloted the approach in demonstration projects prior to the launch of Superior Energy Performance. These facilities demonstrated impressive results that are nearly twice the efficiency gains of business as usual. SEP has piloted four Texas plants: Cook Composites and Polymers (Houston); Freescale Semiconductor, Inc. (Oak Hill); Owens Corning (Waxahachie); and Union Carbide, a subsidiary of Dow

Chemical Company (Texas City). The pilot sites provided substantial input into the design of the program, as did other end users on the U.S. Council for Energy-Efficient Manufacturing. The four pilot sites saw verified energy performance improvements from 6.5% to more than 15% over a 2- to 3-year period.

Four pilot sites verified energy performance improvements from 6.5% to more than 15% in a 2- to 3-year period.

Certification: Documenting Results . A central element of SEP is implementation of the ISO 50001 standard, with additional requirements to achieve and document energy intensity improvements. SEP is designed to encourage participation among facilities of all sizes and all levels of experience in managing energy. The program offers flexibility depending on the degree of data validation desired by an organization or facility. Verification bodies will undertake verification for the SEP program and will be accredited by ANSI. A series of complementary professional credentialing programs train and qualify professionals to assist and audit facilities.

Third-party validation of continuous improvement should be beneficial to organizations in many ways, including improving the chances of securing financing for energy efficiency projects.

Supporting Standards for Steam Assessments. The Association for Mechanical Engineers (ASME) provides a standard that supports industrial steam assessment protocols.

## ASME Sidebar PART 1 of 3

## ASME Sidebar PART 2 of 3 Abstracted portions from several sections follow:

The Standard ASME EA-3 2009, Energy Assessment for Steam System s contains detailed sections, including:

Table of Contents

- 1 - Scope and Introduction
- 2 - Definitions
- 3 - References
- 4 - Organizing the Assessment
- 5 - Conducting the Assessment
- 6 - Assessment Data Analysis
- 7 - Report and Documentation
- ' 4.2 Facility Management Support - Facility management support is essential for the successful outcome of the assessment. Facility management shall understand and support the purpose of the assessment. ...'
- ' 5.1 Overall Assessment Method - The overall method to be used in assessing the steam system is a sequential screening process as shown in Fig. 1. This investigation process shall evaluate the operating characteristics of the individual components, subsystems, processes, and the system as a whole ...'
- ' 5.4 Target Areas for Assessment - An assessment includes evaluation of the steam sources ..., distribution, end use, and condensate recovery. Assessment activities shall focus on quantification of energy losses and the identification ...'
- ' 5.7.1 Temperature Measurements ... (a) Boiler makeup water ... (i) Steam trap ...
- ' 5.7.2 Pressure Measurements ... (c) Condensate return tank ... (d) Deaerator ...
- ' '
- ' 5.7.3 Flow Measurements ... a) Boiler fuel ... c) Makeup water ... '
- ' 5.7.4 Chemical Measurements ... (a) Boiler makeup water ... (e) Condensate ... ' Excerpted with permission from ASME.

## PERFORMANCE IMPROVEMENT OPPORTUNITIES

The excerpts on pp. 25-26 summarize the standard ASME EA-3-2009, Energy Assessments for Steam Systems . For more details, visit www.asme.org . (Please note that a complete version of the standard is available for purchase on ASME website.)

System auditors may find the following resources detailing performance improvement options valuable.

ASME has developed several systems-level standards that support the above management-level standards approach. These systems-level standards provide detailed protocols for conducting energy assessments.

Energy Assessment for:

- •  ASME EA-1-2009-Process Heating Systems
- •  ASME EA-2-2009-Pumping Systems
- •  ASME EA-3-2009-Steam Systems
- •    ASME EA-4-2010-Compressed Air Systems

## ASME Sidebar PART 3 of 3

Similarly The guidance to the standard, ASME EA-3G 2010, Guidance for ASME EA-3 , Energy Assessment for Steam Systems contains detailed information related to the standard.

Abstracted portions from several sections follow:

'Again, the methodology used for steam system assessments should involve investigation of every aspect of the steam system. In a comprehensive examination every area is targeted and an expert evaluation including a path forward is prescribed. ...'

## ' 4.2 Facility Management Support

Completing an assessment in a large and complex facility can over-extend resources. As a result, it may be appropriate to divide the assessment of a large facility into subsystems with each subsystem being composed of a complete steam system. As an example, a facility equipped with many production units and multiple steam-power generation facilities could choose to complete an assessment on one steam-power generation facility and a selection of production units. Significant care must be given ...'

## ' 5.1 Overall Assessment Method - General Methodology

Every complete steam system assessment will target the entire steam system (generation, distribution, end-use and recovery). The goal of the evaluation process is to establish the path forward for each aspect of the steam system. The possible ranges of the path forward are very broad. One end of the range would be to maintain the current operating conditions because the system components in question are being operated in an excellent manner and there is minimal incentive to modify operations. Another point within the range could be to ...'

Excerpted with permission from ASME.

## '5.7.1 Temperature Measurements

Temperature measurements are critical to many analyses required in steam system assessments. Temperature is a primary indicator of the energy level of many streams. Temperature is also instrumental in analyzing the condition of insulation covering various equipment components. Commonly temperature is measured with a thermocouple, Resistance Temperature Device (RTD), fluid-in-glass thermometer, or other direct contact thermometer. These devices can be inserted directly in the fluid stream to get a temperature measurement-this is often the case for near atmospheric pressure fluid streams (such as boiler flue gas).'

## '5.7.4 Chemical Measurements

Chemical measurements are primarily necessary in the evaluation of the performance of the boiler. Flue gas chemical composition is a critical analysis in the determination of the boiler stack loss. Often the flue gas chemicals are control parameters for the boiler, for example, combustion zone oxygen control and environmental emissions. The most common flue gas chemical components measured are oxygen ... and particulate matter.'

Guidance documents providing specific examples and information related to each section of the above ASME Standards are also available.

## ASME EA-3 - 2009 - Energy Assessment for Steam Systems ISBN: 9780791832806

'This standard sets the requirements for conducting and reporting the results of a steam system energy assessment that considers the entire system, from energy inputs to the work performed as the result of these inputs. An assessment meeting this standard shall be sufficiently comprehensive to identify the major opportunities for improving the overall energy performance of the steam system. This standard is designed to be applied primarily at industrial facilities, but most of the specified procedures can be used in other facilities such as those in the institutional and commercial sectors.'

## Common Performance Improvement Opportunities

Several steam system improvement opportunities are common to many industrial facilities. These opportunities can be categorized according to the part of the system in which they are implemented. Common performance opportunities for the generation, distribution, and recovery areas of a steam system are listed in the Oak Ridge National Laboratory Report from Save Energy Now Assessments in recent steam system assessments.

## End-Use Improvement Opportunities

There are many ways to optimize steam system energy use depending on the process and the equipment. Specific end uses within energy intensive industries and related steam systems can be found in Table 1 of the End Use section. In some cases, equipment can be installed to make the process more efficient; for example, multiple-stage dryers are often more efficient than single-stage dryers. However, in general, optimizing the efficiency of steam-supplied end uses requires detailed knowledge and experience and a case-by-case assessment. Many of these same energy savings opportunities were identified as practical options at specific industrial plants that received steam assessments. These assessments were conducted by AMO for large industrial energy-consuming plants from 2006 through 2009. Please visit http:/ /info.ornl.gov/sites/publications/ files/Pub25191.pdf ORNL/TM-2010/146 for detailed steam assessments results and to learn how your organization can achieve significant energy savings after implementing recommendations from a steam assessment.

## Steam System Scoping Tool

- 1. Introduction-provides instructions on how to use the guide and what is indicated by the results.
- 2. Basic data-prompts the user to answer general questions such as the amount of fuel used, amount of steam generated, and other general system data.
- 3.   System profiling-assesses how the user tracks steam costs, benchmarks steam use, and measures important general operating parameters.
- 4.   Operating practices of the total system-queries the user regarding practices such as trap maintenance, water treatment, insulation condition, leak repair, and general equipment inspection.
- 5.   Operating practices of the boiler plant-queries the user on boiler efficiency, heat recovery equipment, steam quality, and general boiler operation.
- 6.   Operating practices of the distribution, end-use, and recovery portions of the steam system-queries the user about the use of pressure reducing valves, condensate recovery, and the use of condensate to generate low-pressure steam.
- 7.   Summary sheet-provides scores based on user responses.

## Steam System Survey Guide

The Steam System Survey Guide is a reference document that is intended for use by plant energy managers and system operations personnel. The guide provides a technical basis for identifying and assessing many potential steam system improvement opportunities. Although several of these opportunities can be identified directly with the survey guide, others require more sophisticated measurements and data gathering methods.

The Scoping Tool and the Survey Guide are complementary. The scoping tool allows a user to determine how well the system is performing and is also useful in tracking the effectiveness of system improvements. The survey guide provides a more quantitative description of the system operation and how to quantify some of the potential steam system improvement opportunities. The survey guide includes a Call to Action section in the chapters of Steam System Profiling, Identifying Steam System Properties, Boiler Efficiency, Effectiveness of Resource Utilization, and Distribution System Losses. These tools are available at: manufacturing.energy.gov .

This website also offers an online publications library with links to other resources that can assist end users in improving the performance and efficiency of their energyintensive utility systems.

## Steam System Assessment Tool

The Steam System Assessment Tool allows users to assess potential savings from individualized steam system improvements. Users may input data about the condition of their plant and the Steam System Assessment Tool generates models of various improvement scenarios. Results detail the energy, cost, and emissions savings that a variety of improvements could achieve.

The tool contains all the key features of typical steam systems-boilers, backpressure turbines, condensing turbines, deaerators, letdowns, flash vessels, and feedwater heat exchangers. The model analyzes boiler efficiency, boiler blowdown, cogeneration, steam cost, condensate recovery, heat recovery, vent steam, insulation efficiency, alternative fuels, backpressure turbines, steam traps, steam quality, and steam leaks.

## 3E Plus Insulation Appraisal Software

Because insulation is used in every steam system, its restoration, replacement, or installation are common improvement opportunities. A lack of awareness regarding the energy losses and the associated costs often results in a low prioritization of restoring or properly installing insulation on steam system surfaces. As a result, a software program known as 3E Plus was developed by the North American Insulation Manufacturers Association (NAIMA). The program increases awareness among steam system operations and management personnel of the benefits of insulation and assists these stakeholders in assessing insulation opportunities.

3E Plus assists the user in assessing important insulation project factors such as energy savings, installation cost, and payback period for various insulation materials and thicknesses. Users of 3E Plus can estimate energy losses from uninsulated surfaces, as well as potential savings from various insulation options.

The program has general data for insulation costs by type and can analyze insulation cross-sections that use several different insulation types. It also accounts for labor rates and productivity by region, estimating how difficult the installation process will be based on general piping characteristics. Users can quickly determine the economic feasibility of various insulation thicknesses. Since the program also allows the user to evaluate various combinations of insulation types, 3E Plus can help the user optimize the material thicknesses within an insulation system. Download 3E Plus at manufacturing.energy.gov .

## NIA's Insulation Energy Appraisal Program (IEAP)

The National Insulation Association (NIA), has developed a training program that offers certification to professionals who conduct insulation appraisals or specify insulation requirements. This program is intended to provide credibility to insulation professionals and to increase consistency of the message that is presented to clients. This program has four key components:

- ·  Awareness Building-an important way to increase awareness of the potential cost savings from insulation projects is to effectively promote insulation appraisal as a professional service.
- ·    Information Gathering-determining the parts of the system that have the most attractive insulation improvement opportunities usually requires input from the plant personnel. Improving the interview techniques of insulation professionals can increase the usefulness of these assessments.
- ·  3E Plus-the 3E Plus program is an important tool for insulation professionals and specifying engineers. Learning to effectively use this tool can improve the quality of the assessment findings, presentation of recommendations, and cost-effective specification of new insulation.
- ·  Reporting-accurately and effectively reporting the results of an insulation assessment can significantly increase the probability that the recommendations will be implemented.

Information about IEAP can be obtained at www.insulation.org or www.pipeinsulation.org .

## Steam Tip Sheets

Some improvement opportunities are available to many different systems. To increase industry awareness of several fundamental improvement opportunities, AMO has developed steam tip sheets.

These steam tip sheets provide concise descriptions of common improvement opportunities. Because AMO continues to develop and identify energy improvement programs, additional tip sheets are expected. Steam tip sheet titles can be found in Appendix B. Steam tip sheets can be found at manufacturing.energy.gov .

## Steam System Training

## Online Self-Guided Training

This online course covers the operation of typical steam systems and discusses methods of system efficiency improvement. The training is designed for plant personnel, such as energy managers, steam system supervisors, engineers, and equipment operators, who have steam system responsibilities in industrial and institutional plants. The course covers three key areas of potential system improvement:

- •  Steam Generation Efficiency
- •  Resource Utilization Effectiveness
- •  Steam Distribution System Losses

The course introduces the Steam System Scoping Tool and the Steam System Assessment Tool, both developed by AMO and uses the Steam System Survey Guide as a technical reference. The training also introduces the 3E Plus insulation appraisal software and a course example is presented that uses this software.

## Steam Tool Specialist Training

Industry professionals can earn recognition as specialists in the use of the AMO Steam Tools. DOE offers an in-depth, multiday training for steam system specialists, including two days of classroom instruction and a written exam. Participants who complete the training and pass the written exam and maintain certification are recognized by DOE as Steam Tool Specialists, and are listed on the AMO website. Specialists can assist industrial customers in using the AMO Steam Tools to evaluate their steam systems.

The AMO Steam System Specialist training is primarily designed for steam specialists who are interested in becoming proficient in using the AMO Steam Tools. To successfully complete the Specialist Training course, a participant must understand the full suite of AMO Steam tools, including:

## Steam System Survey Guide

The Steam System Survey Guide provides technical information for steam system operational personnel and plant energy managers on major areas where steam systems can be improved. The guide outlines calculations that can be performed to quantify steam system improvement opportunities.

## Steam System Scoping Tool

- ·  Accurate collection and input of data for use with the tool
- •  Appropriate utilization of the software
- •  Interpretation of the software results.

## Steam System Assessment Tool

- ·  Accurate collection and input of data for use with the tool
- •  Development of representative system models
- •  SSAT limitations
- •  Individual project identification
- ·  Development of practical methods to accomplish the appropriate projects.

## 3E Plus Training

- ·  Accurate data gathering for basic insulation-related evaluations
- ·  Development of evaluation techniques related to common insulation evaluations.

Class participants receive a prerequisite test/study guide before attending the class. This study guide provides an indicator of the skill levels necessary to successfully complete the training. Completion of this study guide is highly recommended, but is not a requirement to take the training. Completion of AMO's Steam End-User training is also recommended prior to participating in the Specialist training because it covers the majority of the prerequisites.

Learn more about the Steam System training at: manufacturing.energy.gov .

## Financing Steam System Improvements

Industrial facility managers often must convince corporate decision-makers that an investment in steam efficiency is worth the effort. Often, communicating this message can be more challenging than the technical implementation of the concept. The corporate audience will respond more readily to a message of economic impact than a discussion of Btu, pounds of steam, and efficiency ratios. By adopting a financial approach, the facility manager relates steam efficiency to corporate goals. Collaboration with financial staff can yield the kind of proposal that is needed to convince corporate officers who have the final word about capital investments such as steam system upgrades.

Before developing recommendations for how to justify steam improvement projects, it is useful to understand the world as the corporate office usually sees it.

## Understanding Corporate Priorities

Corporate officers are held accountable to a chief executive, a board of directors, and an owner (or shareholders, if the firm is publicly held). It is the job of these officers to create and grow the equity value of the firm. The corporation's industrial facilities do so by generating revenue that exceeds the cost of owning and operating the facility itself. Plant equipment-including steam system componentsis an asset that must generate an economic return. The annual earnings attributable to the sale of goods produced by these assets, divided by the value of the plant assets themselves, describe the rate of return on assets.

This is a key measure by which corporate decision-makers are held accountable. Financial officers seek investments that are most certain to demonstrate a favorable return on assets. When faced with multiple investment opportunities, the officers will favor those options that lead to both the largest and fastest returns.

This corporate attitude may impose (sometimes unpleasant) priorities on the facility manager: assure reliability in production, avoid unwanted surprises by sticking with familiar technology and practices, and contribute to cost control today by cutting a few corners in maintenance and upkeep. This may result in industrial decision-makers concluding that steam efficiency is a 'luxury' they cannot afford. Fortunately, the story does not end here. What follows is a discussion of ways that industrial steam efficiency can save money and contribute to corporate goals while effectively reducing energy consumption and cutting noxious combustion emissions.

## Measuring the Dollar Impact of Steam Efficiency

Steam efficiency improvements can move to the top of the list of corporate priorities if the proposals respond to distinct corporate needs. Corporate challenges are many and varied, which in turn open up more opportunities to 'sell' steam efficiency as a solution. Steam systems offer many opportunities for improvement; the particulars are shared elsewhere in this sourcebook. Once the selections are made, the task is one of communicating the proposals in corporate financial language.

The first step is to identify and enumerate the total dollar impact of a steam efficiency measure. One framework for this is known as 'life-cycle cost analysis.' These analyses capture the sum total of expenses and benefits associated with an investment. The result-a net gain or loss on balance-can be compared to other investment options or to the anticipated outcome if no investment is made. As a comprehensive accounting of an investment option, the life-cycle cost analysis for a steam efficiency measure would include projections of:

- ·  Search and selection costs for seeking an engineering implementation firm
- ·  Initial capital costs, including asset purchase, installation, and costs of borrowing
- •  Maintenance costs
- •  Supply and consumable costs
- ·  Energy costs over the economic life of the implementation
- •  Depreciation and tax impacts
- ·  Scrap value or cost of disposal at the end of the equipment's economic life
- ·  Impacts on production such as product quality and downtime.

One revelation that typically emerges from this exercise is that fuel costs may represent as much as 96% of life-cycle costs, while the initial capital outlay is only 3%, and maintenance a mere 1%. These findings may be true for boilers with a 20-year life operating at high rates of capacity utilization. Clearly, any measure that reduces fuel consumption (while not impacting reliability and productivity) will certainly yield positive financial impacts for the company.

## Financing Steam Efficiency Improvements

As with any corporate investment, there are many ways to measure the financial impact of steam efficiency investments. Some methods are more complex than others are, and proposals may use several analytical methods sideby-side. The choice of analyses used will depend on the sophistication of the presenter and the audience.

A simple and widely used measure of project economics is the payback period. This is defined as the period of time required for a project to 'break even.' It is the time needed for the net benefits of an investment to accrue to the point where they equal the cost of the initial outlay. For a project that returns benefits in consistent, annual increments, the simple payback equals the initial investment divided by the annual benefit. Simple payback does not take into account the time value of money; in other words, it makes no distinction between a dollar earned today versus a dollar of future (and therefore uncertain) earnings. Still, the

## PERFORMANCE IMPROVEMENT OPPORTUNITIES

measure is easy to use and understand and many companies use simple payback for a quick 'go/no-go' decision on a project. Five important factors to remember when calculating a simple payback:

- •  It is an approximation, not an exact economic analysis
- ·  All benefits are measured without considering their timing
- ·  All economic consequences beyond the payback are ignored
- ·  Payback calculations will not always find the best solution (for the two reasons immediately above) when choosing among several project options
- ·  Payback does not consider the time value of money or tax consequences.

More sophisticated analyses take into account factors such as discount rates, tax impacts, the cost of capital, etc. One approach involves calculating the net present value of a project, which is defined in the equation below:

## Net present value = Present worth of benefits - Present worth of costs

Another commonly used calculation for determining economic feasibility of a project is internal rate of return, which is defined as the discount rate that equates future net benefits (cash) to an initial investment outlay. This discount rate can be compared to the interest rate at which a corporation borrows capital.

Many companies set a threshold (or hurdle) rate for projects, which is the minimum required internal rate of return for a project to be considered viable. Future benefits are discounted at the threshold rate, and the net present worth of the project must be positive in order for the project to be a 'go.'

## Relating Steam Efficiency to Corporate Priorities

Saving money should be a strong incentive for adopting steam efficiency. Still, that may not be enough for some corporate observers. The facility manager's case can be strengthened by relating a positive life-cycle cost outcome to specific corporate needs. Some suggestions for interpreting the benefits of fuel cost savings include the following (finance staff can suggest which of these approaches are best for the current corporate climate):

A new source of permanent capital. Reduced fuel expenditures-the direct benefit of steam efficiency-can be thought of as a new source of capital for the corporation. The investment that makes this efficiency possible will yield annual savings each year over the economic life of the improved steam system. Regardless of how the steam efficiency investment is financed-borrowing, retained earnings, or third party financing-the annual savings will be a permanent source of funds as long as the steam efficiency savings are maintained on a continuous basis.

Added shareholder value. Publicly held corporations usually embrace opportunities to enhance shareholder value. Steam efficiency can be an effective way to capture new value. Shareholder value is the product of two variables: annual earnings and the price-to-earnings (P/E) ratio. The P/E ratio describes the corporation's stock value as the current stock price divided by the most recent annual earnings per share. To take advantage of this measure, the steam efficiency proposal should first identify annual savings (or rather, addition to earnings) that the proposal will generate. Multiplying that earnings increment by the P/E ratio yields the total new shareholder value attributable to the steam efficiency implementation.

Reduced cost of environmental compliance. Facility managers can proactively seek to limit the corporation's exposure to penalties related to environmental emissions compliance. Steam efficiency, as total-system discipline, leads to better monitoring and control of fuel use. Combustion emissions are directly related to fuel consumption; they rise and fall in tandem. By implementing steam efficiency, the corporation enjoys two benefits: decreased fuel expenditures per unit of production, and fewer incidences of emission-related penalties.

Improved worker comfort and safety. Steam system optimization requires ongoing monitoring and maintenance that yields safety and comfort benefits in addition to fuel savings. The routine involved in system monitoring will usually identify operational abnormalities before they present a danger to plant personnel. Containing these dangers precludes threats to life, health, and property.

Improved reliability and capacity utilization. Another benefit to be derived from steam efficiency is more productive use of steam assets. The efforts required to achieve and maintain energy efficiency will largely contribute to operating efficiency. By ensuring the integrity of steam system assets, the facility manager can promise more reliable plant operations. The flip side, from the corporate perspective, is a greater rate of return on assets employed in the plant.

## PERFORMANCE IMPROVEMENT OPPORTUNITIES

## Call to Action

A proposal for steam efficiency implementation can be made attractive if the facility manager:

- ·  Uses an energy management system that meets the supply chain energy needs of the customer company
- •  Identifies opportunities for achieving steam efficiency
- •  Determines the life-cycle cost of attaining each option
- •  Identifies the option(s) with the greatest net benefits
- ·  Collaborates with financial staff to identify current corporate priorities (for example, added shareholder value, reduction in environmental impact and environmental compliance costs, and improved capacity utilization)
- ·  Generates a proposal that demonstrates how the steam efficiency project's benefits will directly respond to current corporate needs
- ·  Generates a proposal that identifies incentives available from utilities or states or other sources.

## Summary

Increased awareness of the potential improvements in steam system efficiency and performance is an important step toward increasing the competitive capabilities of energy-intensive industries. Some of the useful steam resources and tools developed by AMO have been described in this section. Additional steam resources and tools and where to obtain them are described in the Resources and Tools section.

## SECTION 3: WHERE TO FIND HELP

Here you will find resources that can help industrial steam users increase the cost-effective performance of steam systems.

## Emerging Technologies

## Advanced Manufacturing Office Overview

Industrial manufacturing consumes approximately 33% of all energy used in the United States. AMO has programs to assist industry in achieving significant energy and process efficiencies. AMO develops and delivers advanced energy efficiency, renewable energy, and pollution prevention technologies and practices for industrial applications. Through industry partnerships, AMO works with the nation's most energy- and resource-intensive industries to develop advanced processes and technologies to achieve these goals.

The advancement of energy- and process-efficient technologies is complemented by AMO energy management resources for immediate savings results. AMO assists energy-intensive industrial companies that are willing to implement best practices and technologies. AMO provides technical assistance for the purposes of base year energy intensity determinations and preliminary analyses to identify and realize their best energy efficiency and pollution prevention options from a system and life-cycle cost perspective. Through activities such as energy systems assessments, and energy management of industrial systems, AMO delivers energy solutions for industry that result in significant energy and cost savings, waste reduction, pollution prevention, and enhanced environmental performance.

Depending on the industry, energy can account for 10% or more of total operating costs. Energy assessments identify opportunities for implementing new technologies and system improvements. Many recommendations from energy assessments have simple payback periods of less than 18 months and can result in significant energy savings.

- ·  Assessments help manufacturers develop comprehensive plant strategies to increase efficiency, reduce emissions, and boost productivity.
- ·  Small- to medium-sized manufacturers can qualify for no-cost assessments from the university-based Industrial Assessment Centers.

Emerging technologies result from research and development and are ready for full-scale demonstration in real-use applications. AMO recognizes that companies may be reluctant to invest capital in these new technologies, even though they can provide significant energy and process improvements.

By sharing implementation and providing third-party validation and verification of performance data, the energy, economic, and environmental benefits can be assessed to accelerate new technology to acceptance.

## Energy Management

AMO encourages manufacturers to adopt a comprehensive approach to energy use that includes assessing industrial systems and evaluating potential improvement opportunities. Efficiency gains in fan, compressed air, motor, process heating, pumping, and steam systems can be significant and usually result in immediate energy and cost savings. AMO offers software tools and training in a variety of system areas to help industry become more energy and process efficient, reduce waste, and improve environmental performance.

## Technical Resources

AMO offers a variety of resources to help industry achieve increased energy and process efficiency, improved productivity, and greater competitiveness.

AMO Website. The AMO website offers a wide array of information, products, and resources to assist manufacturers who are interested in increasing the efficiency of their industrial operations. You can gain access to Web pages for the eight Industries of the Future, learn about upcoming events and solicitations, and much more through this site. Visit the AMO website at: manufacturing.energy.gov .

The site offers case studies of companies that have successfully implemented energy efficient technologies and practices, software tools, tip sheets, training events, and solicitations for plant assessments.

Training. Training sessions in industrial systems improvements using AMO software tools are offered periodically. For more information, visit manufacturing.energy.gov .

## WHERE TO FIND HELP

AMO is developing online training to largely replace our former one-day software training events. The steam online user training is the first in a series of planned online training resources.

AMO and its partners have developed several software tools for systems improvements to help you make decisions about implementing efficient practices in your manufacturing facilities.

## Software Tools

- · AirMaster+ provides comprehensive information on assessing compressed air systems, including modeling, existing and future system upgrades, and evaluating savings and effectiveness of energy efficiency measures.
- ·  An energy-efficient motor selection and management tool, MotorMaster+ software, includes a catalog of more than 20,000 AC motors. This program features motor inventory management tools, maintenance log tracking, efficiency analysis, savings evaluation, energy accounting, and environmental reporting capabilities.
- ·  The NOx and Energy Assessment Tool (NxEAT) helps plants in the petroleum refining and chemical industries to assess and analyze NOx emissions and how the application of energy efficiency improvements can reduce NOx. Perform 'what-if' analyses to optimize and select the most cost-effective methods for reducing NOx from systems such as fired heaters, boilers, gas turbines, and reciprocating engines.
- ·  The Process Heating Assessment and Survey Tool (PHAST) provides an introduction to process heating methods and tools to improve thermal efficiency of heating equipment. Use the tool to survey process heating equipment that uses fuel, steam, or electricity, and identify the most energy-intensive equipment. You also can perform an energy (heat) balance on selected equipment (furnaces) to identify and reduce nonproductive energy use. Compare performance of the furnace under various operating conditions and test 'what-if' scenarios.
- ·  The Pumping System Assessment Tool (PSAT) helps industrial users assess the efficiency of pumping system operations. PSAT uses achievable pump performance data from Hydraulic Institute standards and motor performance data from the MotorMaster+ database to calculate potential energy and associated cost savings.

## News

- · The Advanced Manufacturing Office update is a periodic email that spotlights program activities; new AMO products, training and events, Web updates, and solicitations. Subscribe at: manufacturing.energy.gov .

## AMO Steam-Specific Resources

- · Software -DOE's Steam System Tool Suite helps you tap into potential savings in your facility by evaluating and identifying steam system improvements.
- · Steam System Scoping Tool -This tool is designed to help steam system energy managers and operations personnel perform initial self-assessments of their steam systems. This tool will profile and grade steam system operations and management, and will help you to evaluate your steam system operations against best practices.
- · Steam System Assessment Tool (SSAT) -This tool allows users to assess potential savings from individualized steam system improvements. Users input data about their plant's conditions, and the SSAT generates results detailing the energy, cost, and emissions savings that could be achieved through 16 different improvements.
- · 3E Plus -This program calculates the most economical thickness of industrial insulation for user input operating conditions. You can make calculations using the built-in thermal performance relationships of generic insulation materials or supply conductivity data for other materials.
- · Training -Online Self-Guided Steam Software User Training. Industrial steam users can develop skills in determining options for efficiency improvements using the above-mentioned decision support software tools.
- · Steam Tool Specialist Training -Industry professionals can earn recognition as Specialists in the use of the AMO Steam Tools. DOE offers an in-depth 2-day training for steam system specialists, including 2 days of classroom instruction and a written exam. Participants who complete the training and pass the written exam are recognized by DOE as Steam Tool Specialists. Specialists can assist industrial customers in using the AMO Steam Tools to evaluate their steam systems.

- · Case Studies -Steam Case Studies provide practical examples of successful steam system improvement projects. Typically, these case studies describe how a facility assessed its steam system, then identified opportunities to improve its operation and/or performance and implemented one or more of those opportunities. Discussion of successful improvement projects can reduce the uncertainty associated with making steam system improvements. Case studies also increase awareness of the system's approach that is often an essential part of any successful performance or efficiency improvement. Documented steam case studies are available on the AMO website.

## Directory of Contacts

Information on improving the performance of industrial energy systems is available from several resources. To improve the profitability of U.S. industry, AMO offers many resources for steam system management. These resources complement Industries of the Future technology development programs, which address other industrial systems such as motor, compressed air, combined heat and power, and process heating, in addition to efforts by the Industrial Assessment Centers. Collectively, these efforts assist industry in adopting near-term and long-term energy-efficient practices and technologies. For assistance in these areas, contact:

## U.S. Department of Energy Advanced Manufacturing Office (AMO)

## manufacturing.energy.gov

For specific information regarding steam systems, including assistance in locating steam system specialists and equipment vendors, AMO provides an excellent set of helpful resources. Together with industrial end users, equipment suppliers, and resource organizations, AMO helps industry stay competitive and promotes the comprehensive upgrade of industrial steam systems. AMO may also provide technical assistance to manufacturers who have made a commitment to reduce energy intensity in their operations by 25% over 10 years.

AMO Industrial Incentives Database-Visit the AMO website for incentives by states, utilities, and energy efficiency organizations, divided by energy type and energy use.

## Alliance to Save Energy

Phone: 202-857-0666

## www.ase.org

The Alliance to Save Energy is a nonprofit coalition of prominent business, government, environmental, and consumer leaders who promote the efficient and clean use of energy worldwide to benefit the environment, the economy, and national security.

## American Boiler Manufacturers Association (ABMA)

Phone: 703-356-7172

## www.abma.com

ABMA is a trade association of manufacturers of boilers, related fuel-burning equipment, users of boiler and boilerrelated equipment, and companies that provide products and services to the boiler industry.

The ABMA Bookstore is a one-stop source for boiler industry information. Find industry standards, technical references, and more from ABMA, Underwriters Laboratories, and many other publishers.

## Association of Energy Engineers (AEE)

Phone: 770-447-5083

www.aeecenter.org

AEE is a membership organization of more than 8,000 professionals in the energy efficiency, utility deregulation, facility management, plant engineering, and environmental compliance fields. AEE offers a variety of outreach programs including technical seminars, conferences, publications, and certification programs.

## Association for Facilities Engineering (AFE)

Phone: 571-203-7171

www.afe.org

AFE provides education, certification, technical information, and other relevant resources for plant and facility engineering, operations, and maintenance professionals worldwide.

## Boiler Room/Go-Steam Websites

An online community for commercial and industrial boiler operators and engineers. These sites contain boiler company profiles, a career center for steam industry professionals, a classified section for boiler/steam equipment, and a discussion board. See www.boilerroom.com .

## Council of Industrial Boiler Owners (CIBO)

Phone: 703-250-9042

www.cibo.org

CIBO provides information and advocacy to achieve solutions to industrial energy, environmental, and legislative issues and policies. Objectives of CIBO include:

- 1.   Information exchange among members, government, and the public concerning policies, laws, and regulations that affect industrial energy systems.
- 2.   Technically sound, equitable, cost-effective laws and regulations.
- 3.   Improved reliability and cost-effectiveness of industrial energy systems.

## National Association of Power Engineers (NAPE)

Phone: 413-592-6273

www.powerengineers.com

NAPE is a professional association for power engineers. NAPE was established in 1879 and provides education and resources on power and energy engineering.

## National Insulation Association (NIA)

Phone: 703-464-6422

www.insulation.org

NIA is a service organization that promotes the general welfare of the commercial and industrial insulation and asbestos abatement industries and works to improve the service to the general public performed by the commercial and industrial insulation and asbestos abatement industries.

## North American Insulation Manufacturers Association (NAIMA)

Phone: 703-684-0084

www.naima.org

NAIMA is a trade association of North American manufacturers of fiberglass, rock wool, and slag wool insulation products. NAIMA concentrates its efforts on promoting energy efficiency and environmental preservation through the use of fiberglass, rock wool, and slag wool insulation products, while encouraging safe production and use of these products.

## STEAM-LIST

The STEAM-LIST is a discussion forum that promotes the exchange of information, problem solving, and discussion of steam generators, piping, and equipment. Included among the components and issues that are discussed are boilers, boiler feed pumps, water treatment, corrosion and scaling, valves, PRVs, traps, turbines, flow metering, heating coils, condensate pumps, district heating, and system modeling. This list is intended to promote practical discussions, rather than theoretical or academic discussions.

Subscription information can be obtained by contacting: listproc@lists.cc.utexas.edu .

## Resources and Tools

Note: The descriptions accompanying the following sources have generally been taken directly from the publisher/author/developer. Inclusion of these sources does not imply endorsement by the U.S. Department of Energy.

Several other resources are available that describe current tools, technologies, and practices that can help improve steam system operating efficiency and performance. Many of these resources are intended to increase awareness of the benefits of energy improvement projects and to identify where the industry professional can go for more help.

## Books

## American Boiler Manufacturers Association (ABMA)

Phone: 703-356-7172

www.abma.com

ABMA provides a wide range of guides, manuals, and other publications on boiler operations and maintenance:

- · Packaged Boiler Engineering Manual

- · Boiler Operation and Maintenance Safety Manual
- · Fluidized Bed Combustion Guidelines
- · A Guide to Clean and Efficient Operation of Coal-Stoker-fired Boilers
- · Guidelines for Performance Evaluation of Heat Recovery Steam Generating Equipment
- · Guidelines for Boiler Control Systems (Gas/OilFired Boilers)
- · Guidelines for Industrial Boiler Performance Improvement

## Armstrong International, Inc.

Phone: 269-273-1415

www.armintl.com

Handbook N101-Steam Conservation Guidelines for Condensate Drainage

Description: This handbook summarizes general principles of installation and operation of steam traps. It also includes recommendation charts which summarize findings on which type of trap will give optimum performance in a given situation and why.

## ASHRAE

Phone: 800-527-4723

www.ashrae.org

2008 ASHRAE Handbook of HVAC Systems and Equipment

Description: Complete guide to steam systems design and

equipment.

## Association for Facilities Engineering (AFE)

Phone: 571-203-7171

www.afe.org

Boiler Plant and Distribution Optimization Manual

Description: Guide for boiler and plant operators to optimize the efficiency of their boilers and distribution systems.

## Babcock and Wilcox

Phone: 330-753-4511

www.babcock.com

Steam: Its Generation and Use, 2005 Edition

Description: This book is intended to help design, procure, construct, maintain, and/or operate equipment in a way that will provide reliable performance.

## GE Water

Phone: 215-355-3300

www.gewater.com

Handbook of Industrial Water Treatment

Prepared by: Betz Laboratories Inc.

Description: This handbook presents detailed information on external treatment: boiler and cooling water systems, air conditioning, refrigeration and total energy systems, chemical treatment feeding and control, and problems encountered in special industrial cases.

## Boiler Efficiency Institute

Phone: 800-669-6948

www.boilerinstitute.com

Steam Efficiency Improvement

Description: An introductory text for establishing a program for reducing losses in the use of steam. The text is divided into three areas: steam transmission, steam consuming processes, and condensate return systems.

## CANMET Energy Technology Centre

## http:/ /oee.nrcan.gc.ca/home

Environment Primer for Boilers and Heaters

Prepared by: Federal Industrial Boiler Program, CANMET Energy Technology Centre

Description: This guide is intended to provide a basic discussion of combustion processes, their emissions, and techniques for reducing energy consumption and environmental emissions. ISBN: 0777895366

## Council of Industrial Boiler Operators (CIBO)

Phone: 703-250-9042

www.cibo.org

Energy Efficiency Handbook

Description: The Energy Efficiency Handbook was prepared to help owners and operators get the best and most energy-efficient performance out of their boiler systems. Some of the handbook chapters include Water Treatment, Boilers, Controls, Heat Recovery, Energy Auditing, and Steam Systems.

## Energy Institute Press

Phone: 301-946-1196

www.energybooks.com

Energy Efficiency Manual

Energy Efficiency Manual

Author: Donald R. Wulfinghoff

Description: A comprehensive treatment of energy efficiency applications in industrial, commercial, and residential settings. Industrial boiler operators will be interested in Section 1, 'Boiler Plant,' which devotes 225 pages solely to steam systems. Dozens of tips are provided, each with an assessment of its potential for savings, rate of return, reliability, and ease of initiation. ISBN: 0965792676

## The Fairmont Press

## www.fairmontpress.com

Energy Management Handbook, Seventh Edition

Author: Wayne C. Turner

Description: This book discusses steam and condensate systems, waste heat recovery, co-generation, and industrial insulation. ISBN: 0142008870X

Handbook of Energy Audits, Eighth Edition

Author: Albert Thumann, William J. Younger, Terry Niehus Description: Contains information on boilers, steam traps, insulation, and a chapter on computer software for energy audits. ISBN: 0-88173-621-X

Plant Engineer's and Manager's Guide to Energy Conservation, Eighth Edition

Author: Albert Thumann

Description: Provides information on steam tracing, steam generation using waste heat recovery, steam trap maintenance, co-generation, the transition from energy audits to industrial assessment, a review of industrial operations and maintenance energy measures, and an integrated approach to achieving energy cost savings at a corporate headquarters. ISBN: 0-88173-360-1

## International District Energy Association

Phone: 508-366-9339

www.districtenergy.org

District Heating Handbook, Fourth Edition

Description: A guide for engineers to understand district heating and how best to use it. A scanned copy of some of the sections may be viewed online.

## Taylor &amp; Francis Group

## www.taylorandfrancis.com

Steam Plant Calculations Manual

Author: V. Ganapathy

Description: Provides solutions to nearly 200 practical questions related to the planning, design, operation, and maintenance of steam plant systems.

## McGraw-Hill

Phone: 212-512-2000

www.mhprofessional.com

Marks Standard Handbook for Mechanical Engineers, Eleventh Edition

Authors: Eugene Avallone, Theodore Baumeister, III, and Ali Sadegh

Description: Provides descriptions of different heat distribution systems including low-pressure steam systems. ISBN: 0071428674

Steam Turbines: Design, Applications, and Rerating, Second Edition

Author: Heinz P. Bloch

Description: This book is written for plant, mechanical, design, and maintenance engineers, and will assist end users with selecting, operating, and maintaining steamdriven systems. It includes design and manufacturing data for steam turbines and compressors, as well as the other operational components. ISBN: 007150821X

A Working Guide to Process Equipment, Third Edition

Authors: Norman P. Lieberman and Elizabeth T. Lieberman

Description: Explains the basic technical issues that need to be known to troubleshoot process equipment problems. Provides diagnostic tips, worked out calculations, practical examples, and illustrations. ISBN: 978-0-07-149674-2

## Nalco Company

Phone: 630-305-1000

www.nalco.com

Nalco Guide to Boiler Failure Analysis

Authors: Robert D. Port and Harvey M. Herro

Description: This book is a comprehensive field guide to boiler system failures. It is intended to aid in-plant detection and diagnosis. Correction procedures can usually be specified once the cause of system failures has been determined. ISBN: 978-0-07-174300-6

## WHERE TO FIND HELP

## Nalco Water Handbook, Third Edition

Author: Frank N. Kemmer (Editor)

Description: This reference discusses the use of water and steam in water treatment unit operations, the use of water and steam in a number of major process industries, and specialized water treatment technologies in boilers and other systems. ISBN: 978-0-07-154883-0

## Pennwell Publishing

Phone: 918-835-3161

www.pennenergy.com

Petrochemicals in Nontechnical Language, Fourth Edition

Authors: Donald L. Burdick and William L. Leffler

Description: Provides an overview of the key processes and operations in the petrochemicals industry. ISBN: 978-1-59370-216-8

Petroleum Refining in Nontechnical Language, Fourth Edition

Author: William L. Leffler

Description: Provides an overview of the key processes and operations in the petroleum refining industry for professionals in finance and marketing. ISBN: 978-1-59370-158-1

## Spirax Sarco Application Engineering Department

## www.spiraxsarco.com

Steam Engineering Tutorials (Online Guide)

Description: The tutorials explain the principles of steam engineering and heat transfer. The Resources section also includes electronic steam properties calculation tools.

Hook-Ups-Design of Fluid Systems

Description: The Hook-Up book is intended to serve as a reference in the design, operation, and maintenance of steam, air, and liquid systems. The book is a learning tool to teach engineers how to design productive steam systems efficiently and cost effectively.

Steam Utilization-Design of Fluid Systems

Description: The Steam Utilization book is intended to serve as a reference in steam fundamentals to the most efficient use of steam heat content. The book describes proper steam trapping, controls, and condensate recovery.

## TAPPI Press

Phone: 800-332-8685

www.tappi.org

Pulp and Paper Energy Best Practices Guidebook 2006

Prepared by Center for Technology Transfer, Focus on Energy, TAPPI, USDOE/AMO, Wisconsin Paper Council.

Description: Fifty energy best practices for the Pulp and Paper Industry. ISBN: 1595101209

## TLV Company Ltd.

Phone: 704-597-9070

www.tlv.com

Online Steam Theory Guide

Description: This guide includes a series of interactive steam animations. It also includes interactive calculators that can help indicate what steam system losses and steam trap leaks are costing your company, as well as steam e-tables.

Condensate Drainage and Recovery

Description: This handbook provides a practical introduction to draining condensate from equipment and returning it to the boiler system. Publication, 1997.

Efficient Use of Process Steam

Description: This handbook provides a practical introduction to steam properties, and a basic awareness of how steam can be successfully and beneficially used in industry. Publication, 1996.

Steam Trapping Principles

Description: This handbook explains the technology of steam trapping, and provides data to correctly select and install steam traps for the benefit of maximum plant efficiency.

## Tyco Valve &amp; Controls-Yarway www.tycoflowcontrol.com

Industrial Steam Trapping Handbook

Description: This handbook focuses on good steam piping/ system/application practices and includes extensive information on different steam trap technologies, condensate line sizing, and steam trap testing techniques.

## Other Publications: Guides, Manuals, and Standards

Many of the publications and manuals are commercially available for purchase.

## American Boiler Manufacturers Association (ABMA)

Phone: 703-356-7172

www.abma.com

ABMA provides a wide range of guides, manuals, and other publications on boiler operations and maintenance.

## American Gas Association (AGA)

Phone: 202-824-7000

www.aga.org

Examining U.S. Natural Gas Supply, 2011

Description: Previously natural gas as a long-term solution was considered irrational. That view has changed. Natural gas is abundant in North America.

## American National Standards Institute (ANSI)

Phone: 212-642-4900

www.ansi.org

ANSI/MSE-Management System for Energy is a voluntary standard for a management system for energy (MSE). It covers the purchase, storage, use and disposal of primary and secondary energy resources. The standard aligns with the ISO 50001 standard that can be used by any organization to manage energy use and efficiency.

ANSI/Fluid Control Institute 69-1-1989 (revised 1994)

Description: Pressure ratings for steam traps.

ANSI/Fluid Control Institute 85-1-1994

Description: Standard for production testing of steam traps.

ANSI Fluid Control Institute 87-1-1994

Description: Classifications and operating principles of steam traps.

Fluid Control Institute 97.1

Description: Standard for production testing of secondary pressure drainers (condensate return pumps).

## American Society of Mechanical Engineers (ASME)

Phone: 800-843-2763 www.asme.org

ASME-EA-3-2009 Energy Assessment for Steam Systems

Description: A detailed technical protocol for consistently conducting steam system assessments of highest quality.

ASME-EA-3-2010 Guidance for ASME EA-3

See Sidebar in Section 2 for more details.

ANSI/ASME PTC 39.1, Performance Testing

Description: Reviews all the necessary information to conduct performance tests on steam traps for efficient use of plant steam.

ASME B31.1 Power Piping Code, 1995 Edition

Description: Code of standards for pressure piping.

ASME Boiler/Pressure Vessel Code

Description: Construction specifications associated with boilers and their operation.

Consensus on Operating Practices for the Control of Feedwater and Boiler Water Chemistry in Modern Industrial Boilers (CRTD-Vol. 34)

Description: Guidelines aimed at minimizing boiler deposition.

A Practical Guide to Avoiding Steam Purity Problems in the Industrial Plant (CRTD-Vol. 35)

Description: Guidelines aimed at avoiding steam purity related problems.

## Armstrong International, Inc.

Phone: 269-273-1415

www.armintl.com

Armstrong Service Guide Bulletin-301

Description: Steam trap installation and maintenance.

Chart 1101-A Quick Way to Find How Much Steam You Need to Heat Water

Description: Chart showing amount of steam and the boiler horsepower required to heat water.

Chart 1121-How to Size Condensate Return Lines

Description: Sizing condensate return lines presents several problems that differ from those of sizing steam or water lines. The most significant is handling flash steam. The chart contains formulas to size condensate lines and return line capacity data.

Installation and Testing of Inverted Bucket Steam Traps Bulletin-307

Description: Steam trap testing for inverted bucket traps.

Steam Trap Testing Guide for Energy Conservation Description: Trap testing for all trap styles.

## ASTM International

Phone: 610-832-9585 www.astm.org

Annual Book of Standards, Section Four, Volume 04.06, 'Thermal Insulation: Building and Environmental Acoustics.'

Description: Features specifications that establish property requirements for various types of insulation. Also included are tests, practices, and guides that call out procedures for the measurement of insulation properties as well as installation.

## British Standards Institution (BSI)

389 Chiswick High Road London W4 4AL United Kingdom Phone: 845 080 9000

www.bsigroup.co.uk

Water Tube Boiler Requirements for Boiler Feedwater and Boiler Water Quality (BS-EN 12952-12)

Description: The standard gives requirements for boiler feedwater and boiler water quality in water tube boilers.

Recommendations for Treatment of Water for Steam Boilers and Water Heaters (BS 2486:1997)

Description: The standard gives recommendations for the control of waterside conditions in steam boilers and water heaters. It also includes information on the preparation of feedwater required for these systems.

## National Board of Boiler and Pressure Vessel Inspectors

Phone: 614-888-8320

www.nationalboard.org

National Board Inspection Code, ANSI/NB-23 National Board of Boiler and Pressure Vessel Inspectors

Description: The purpose of the National Board Inspection Code is to 'maintain the integrity of pressure retaining items after they have been placed into service by providing rules for inspection, repair, and alteration …'

## National Insulation Association (NIA)

Phone: 703-464-6422

www.insulation.org

National Commercial and Industrial Insulation Standards Description: This is a national standard for designing, specifying, and installing thermal mechanical insulation for commercial and industrial pipe, equipment, vessels, and ducting systems.

The Mechanical Insulation Design Guide ( www.wbdg. org/midg ) is a comprehensive resource for information on mechanical insulation materials and systems.

## Swagelok Energy Advisors, Inc. (formerly Plant Support &amp; Evaluations, Inc.)

Phone: 888-615-3559

www.plantsupport.com

Steam System Specialist Level One-Training Manual

Description: The training manual covers all aspects of the steam system. It provides the necessary basic information on steam, heat transfer, boilers, piping, heat exchangers, insulation, and steam traps.

Steam System Specialist Level Two-Training Manual

Description: The training manual provides more detail on certain aspects of the steam system. Areas of coverage include steam generation, steam turbines, desuperheaters, steam accumulators, piping, expansion, heat transfer, process control, and condensate recovery.

## Process Industry Practices

Phone: 512-232-3041

www.pip.org

Process Industry Practices (PIP) is a consortium of process industry owners and engineering construction contractors who serve the industry. PIP publishes documents called 'practices.' These practices reflect a combination of company engineering standards in many engineering disciplines Specific practices include design, selection and specification, and installation information.

## Spirax Sarco Application Engineering Department

Phone: 800-575-0394

www.spiraxsarco.com

Steam and Condensate Loop Book

Description: A total steam system and condensate design and operation guide showing steam generation, distribution, end-use, and recovery guidelines. Website contains related selection resources for several process industries.

## TAPPI Press

Phone: 800-332-8686

www.tappi.org

Paper Machine Steam and Condensate Systems, Fifth Edition

Description: Provides information to solve dryingrelated problems and gives a basic understanding of paper machine steam and condensate systems.

## Tech Street

Toll free in the US: 1-800-699-9277

Outside US: 1-734-780-8000

www.techstreet.com

IEA-ECBCS Annex 46: Energy Process Assessment Protocol, 2010

Developed by government, institutional, and private-sector contributors for facility energy managers, in-house and other energy assessment groups, and energy service performance contractors. This protocol addresses both technical and non-technical organizational capabilities needed for successful assessments.

Note: The 2010 edition is available for purchase on Tech Street; a preliminary version is available at www.annex46. org/preliminary\_results/ .

## U.S. Army Corps of Engineers

441 G Street, NW Washington, DC 20314-1000 Phone: 202-761-0001

www.usace.army.mil

Industrial Water Treatment Procedures, PWTB 420-49-5

Description: Guide for boiler plant operators to properly set up, maintain, and control boiler system water chemistry. It applies to boiler systems operating below 600 psi and includes guidelines for water treatment for other HVAC systems.

## U.S. Department of Energy Information Bridge

Phone: 800-553-6847 www.osti.gov/bridge

The Information Bridge provides final technical reports on AMO research projects, including industrial combustion burners.

## U.S. Environmental Protection Agency

Phone: 888-782-7937

www.epa.gov

Wise Rules Tool Kit

Description: Rules and measures for estimating potential energy, cost, and greenhouse gas emissions savings with information on boilers, steam systems, furnaces, process heating, waste heat recovery, cogeneration, compressed air systems, and process cooling.

www.energystar.gov - EnergyStar for Industrial Plants and Facilities. The kit contains a number of useful resources to help your company or plant to be more strategic in your planning for energy management.

## Software

## Armstrong International, Inc.

Phone: 269-273-1415

www.armintl.com

Armstrong Sizing Software and Calculators

Developer: Armstrong International

Description: Sizing and selection instructions for specific applications.

## WHERE TO FIND HELP

Armstrong Steam Eye Software &amp; SteamStar

Developer: Armstrong International

Description: Software designed to constantly/wirelessly monitor steam traps in a system.

Armstrong Trap Sizing Software

Developer: Armstrong International

Description: Steam trap sizing and selection instructions for specific applications.

## ChemicaLogic Corporation

Phone: 781-425-6738

www.chemicalogic.com

SteamTab Software

Developer: ChemicaLogic Corporation

Description: SteamTab is a tool designed for steam property users in the scientific, engineering, plant operation, and educational communities. SteamTab uses fundamental equations to calculate all steam properties with interpolation or curve fits to raw steam data. SteamTab products support spreadsheet applications.

## Conserv-It Software

Phone: 704-841-9550

www.conserv-it.com

SteamWorks Pro

Developer: Conserv-It Software, Inc.

Description: This software assists in tracking steam trap maintenance efforts. The system includes analyses of steam losses, maintenance costs, and failure trends. The software allows you to track similar data across multiple sites. A mobile PC version is planned.

## Control Dynamics, Inc.

Phone: 804-858-5800 www.control-dynamics.com

Boiler Control Package Tool

Developer: Licensed by Fisher-Rosemount Performance Solutions

Description: The Boiler Control Package is a preconfigured control strategy for use with control systems for steam generators; i.e., boilers, heat recovery generators, and thermal oxidizers. Controls include the water side for single or three-element drum level controls, air-fuel combustion controls for parallel metering, and cross-limiting of one or more fuels. Steam header pressure controls are included, as well as a simulation for training.

## Field Data Specialists, Inc.

Phone: 800-932-9543

www.trapbase.com

TrapBase for Windows Software

Developer: Field Data Specialists, Inc.

Description: TrapBase was designed as a field tool to assist in developing a systematic steam system program. The software also is available in a version for multiple sites. The software has features for data entry, directed surveys, field reporting, maintenance work orders/history, field data analysis, and savings results analysis. Existing data from other software or from spreadsheets can be imported into TrapBase. A version of the software was written to integrate the desktop version with the TrapTech Palm PC for data capture and barcode reading field inspection and recording system.

## Honeywell Corporation

Phone: 800-343-0228 www.honeywell.com

Plant Performance Optimizer

Developer: Honeywell Corporation

Description: Calculates optimum loading for all boilers at all possible steam loads.

## KBC

## www.kbcat.com

PROSTEAM Software

Developer: KBC (formerly Linnhoff March)

Description: PROSTEAM is an engineering add-in for Microsoft Excel. It provides steam and water thermodynamic and transport property calculations, and steam utility systems modeling.

Also related:

Persimmon-Determines which exchangers to clean and economic benefits.

SuperTarget-Pinch analysis software.

WaterTarget-Software suite enabling the efficient use and re-use of water to minimize the cost.

## National Institute of Standards and Technology

Phone: 303-497-3555

www.nist.gov

NIST/ASME Steam Properties

Developer: National Institute of Standards and Technology Description: Database of steam and water thermodynamic properties.

## Ogontz Corporation

Phone: 800-523-2478

www.ogontz.com

Ogontz Energy Savings Potential

Developer: Ogontz Corporation

Description: This software calculates the dollars that can be saved using steam controls and traps in an existing facility or new construction project. The software provides cost savings information for unit heaters, winterization steam tracing, temperature control of traced process piping, and other temperature control applications.

## Plant Support &amp; Evaluations, Inc.

Phone: 888-615-3559 www.plantsupport.com

Steam Trap Database Software

Developer: Plant Support and Evaluations, Inc.

Description: This free software was developed in Microsoft Access and is an open environment to enable anyone to make changes to meet their plant requirements and includes a system trap survey spreadsheet.

## Spirax Sarco Application Engineering Department

Phone: 800-575-0394

www.spiraxsarco.com

SNAP Steam Needs Analysis Program

Developer: Spirax Sarco

Description: Redesigned as a Web-based application. Total Steam System Software Program for sizing and selecting: piping for steam/condensate/water, steam conditioning stations, pressure reducing stations, temperature control stations, steam traps (all types and applications), condensate recovery stations; flash steam recovery systems; and clean/ pure steam systems. Available at www.snapfour.com .

STMS Steam Trap Management System

Developer: Spirax Sarco

Description: Windows-based software (primarily available through steam system assessment services) designed for the easy collection, storage, organization, and sorting of steam trap data. It lets you create custom databases from survey sheets or a handheld Data Collector, then analyze by maintenance schedules, trap performance, trap application, or cost of steam loss, etc.

## Steam Conservation Systems

Phone: 401-213-3315

www.trapo.com

Steam $$ and the Trapo Demo

Developer: Steam Conservation Systems

Description: Calculates annual steam distribution system costs and efficiency. Demonstrates costs of energy lost through piping insulation, and different costs of managing steam traps. Shows investment, costs, payback, and ROIs for changing to predictive maintenance.

## Thermon Corporation

Phone: 800-654-2583

www.thermon.com

www.thermon.com

Compu-Trace

Developer: Thermon Corporation

Description: Steam heat tracing design software.

TraceView

Developer: Thermon Corporation

Description: Heat tracing monitoring and control software.

## TLV Company, Ltd

Phone: 704-597-9070

www.tlv.com

TLV SE-1 STEAM Software

Developer: TLV Company, Ltd.

Description: Software to perform calculations for steam system components. Modules include engineering calculations, steam trap selection, pressure reducing valve selection, air trap selection, gas trap selection, air vent selection, power trap selection, and separator selection.

## WHERE TO FIND HELP

Online Steam Theory Guide -Includes a series of interactive steam animations. It also includes interactive calculators that can help indicate what steam system losses and steam trap leaks are costing your company.

Pencheck -Pocket PC-based steam trap management system for up to 1000 traps.

## UE Systems

Phone: 800-223-1325

www.uesystems.com

Ultraprobe 15,000

Developer: UE Systems

Description: Ultrasonic inspection and information storage system.

## U.S. Army Construction Engineering Laboratory

Phone: 800-USA-CERL

www.cecer.army.mil

HEATER Software

Description: A computer modeling tool that incorporates the HEATMAP software. HEATER allows steam/condensate/ utility systems to be modeled, and provides inventory and O&amp;M condition indices that can be used to prioritize repairs/replacement. Predictive modeling can estimate time to failure.

## U.S. Department of Energy Advanced Manufacturing Office

manufacturing.energy.gov

3E Plus Insulation Appraisal Software

Developer: North American Insulation Manufacturers Association

Description: Calculates insulation thickness to determine economic, energy, and environmental savings for piping and equipment. Includes calculations for heat gain or heat loss, surface temperature requirements, condensation control, heat loss efficiencies versus bare pipe, payback periods, and emissions reductions.

## Washington State University-Extension Energy Program

Phone: 360-956-2000

www.energy.wsu.edu

HEATMAP Software

Description: HEATMAP is a software program that was specifically developed to help plan, analyze, and operate district heating and cooling systems.

## Tyco Valve &amp; Controls

Phone: 713-466-1176

www.yarway.com

Edge Asset Management

Description: Windows-based software designed for the collection, storage, and tracking of valves and maintenance management.

## Periodicals

## ASHRAE Journal

American Society of Heating, Refrigeration, and Air Conditioning Engineers

Phone: 404-636-8400

www.ashrae.org

## Boiler Systems Engineering

www.hpac.com/BSE/

## Chemical Engineering

Chemical Week Publishing

Phone: 212-621-4900

www.che.com

## Chemical Processing

Putman Media

Phone: 630-467-1300

www.chemicalprocessing.com

Online articles include 'Energy Savings Picking Up Steam.' Also includes a wireless center with articles and case studies on industrial wireless networks.

## Consulting-Specifying Engineer

CFE Media LLC

Phone: 630-571-4070

www.cfemedia.com

## Control Engineer

CFE Media LLC

Phone: 630-571-4070

www.cfemedia.com

## Energy Engineering

Association of Energy Engineers www.aeecenter.org

## Heating/Piping/Air Conditioning, HPAC Engineering

Penton Publishing

Phone: 216-696-7000

## Industrial Maintenance &amp; Plant Operation (IMPO)

Advantage Business Media

Phone: 973-920-7789

www.impomag.com

## Mechanical Engineering, American Society of Mechanical Engineers (ASME)

ASME International

Phone: 800-843-2763

www.asme.org

## Plant Engineering

CFE Media LLC

Phone: 630-571-4070

www.cfemedia.com

## Plant Services

Putnam Media

Phone: 630-467-1300

www.plantservices.com

## Process Heating

Business News Publishing

Phone: 412-306-4351

www.process-heating.com

## Today's Boiler Magazine

American Boiler Manufacturers Association

Phone: 216-696-7000

www.esmagazine.com/boiler

## Reports and Technical Papers

## Armstrong International, Inc.

Phone: 269-273-1415

www.armintl.com

Steam Conservation Guidelines Handbook

## GTI

Phone: 847-768-0500

www.gastechnology.org

Analysis of the Industrial Boiler Population

Description: Report that identifies and characterizes the current industrial boiler population by fuel type and consumption, geographic location, industry, end user, and age. GRI-96/0200

## U.S. Department of Energy Information Bridge

Phone: 800-553-6847

www.osti.gov/bridge

Review of Orifice Plate Steam Traps

Description: This report describes orifice traps and mechanical steam traps. It also provides information to help make decisions regarding applications for which orifice traps should be considered.

## Training Courses and Technical Services

## AESYS Technologies

Phone: 717-755-1081

www.aesystech.com

Topics: AESYS Technologies offers courses in both boiler operation and maintenance, and facility operations and maintenance.

## American Boiler Manufacturers Association (ABMA)

Phone: 703-356-7172

www.abma.com

Topics: ABMA members offer an extensive listing of training courses in many aspects of boiler operations and maintenance.

## American Society of Mechanical Engineers (ASME)

Phone: 800-843-2763

www.asme.org

Topics: The ASME gives courses on repairs and alterations of boilers and pressure vessels, process piping, and tanks.

## Armstrong International, Inc.

Phone: 269-273-1415

www.armintl.com

Topics: Armstrong International has training facilities where it sponsors steam energy seminars and education, and online steam training through Armstrong Steam University.

## Association of Energy Engineers (AEE)

Phone: 770-447-5083

www.aeecenter.org

Topics:

- •  Industrial Energy Conservation
- •  Strategies that Work
- •  Optimizing Boiler Performance

## Babcock and Wilcox

Phone: 330-753-4511

www.babcock.com

Topics: Babcock &amp; Wilcox provide courses in:

- •  Boiler Condition Assessment and Monitoring
- •  Boiler Performance Analysis
- •  Industrial Water-Tube Boiler
- •  Oil/Gas-Fired Boilers

## Boiler Efficiency Institute

Phone: 800-669-6948

www.boilerinstitute.com

Topics:

- •  Boiler and Steam Systems
- •  Workshop Engineering Fundamentals

## CDT Micrographics

Phone: 603-778-6140

www.cdtmicrographics.com

Topic: Hazards of Steam

## Center for Professional Advancement (CFPA)

Phone: 732-238-1600

www.cfpa.com

Topics: The CFPA offers courses in:

- •  Analysis and Control of Industrial Processes
- •  Boiler Water Treatment
- •  Piping Design, Analysis, and Fabrication
- •  Pressure Vessel Design and Analysis
- •  Shell-and-Tube Heat Exchangers
- •  Steam Turbines and Auxiliaries
- •  Power Engineering

## Eclipse Combustion, Inc.

Phone: 815-877-3031

www.eclipsenet.com

Topics: The Eclipse Combustion workshop is an accelerated three-day course covering the theory, design, operation, and application of industrial combustion equipment.

- •    Combustion Fundamentals
- •    Combustion Equipment
- •    Applications
- •    Problem-solving and Troubleshooting
- •    Plant Tour and Lab Demonstrations

## Enercheck Systems, Inc.

## www.enerchecksystems.com

Topics:

- •    Performing a Steam Trap Survey
- •    How to Make a Steam System Efficient

## FIVES North American Combustion, Inc.

## www.namfg.com

Topics:

- •    Combustion and Kiln Control
- •    Effective Combustion and Its Control
- •    Optimizing Gas-Fired Industrial Heating Processes

## Johnson Controls Institute

## Phone: 800-524-8540 www.johnsoncontrols.com

Topics:

- •    Mechanical Systems including:
- •    Boiler Maintenance
- •    Facility Management Systems

## The National Institute for the Uniform Licensing of Power Engineers, Inc. (NIULPE) www.niulpe.org

A third-party certification organization mandated to establish and maintain international standards of education and competency for the power and energy-related trades and professions.

## National Insulation Association (NIA)

Phone: 703-464-6422

www.insulation.org

Topics:

- •    Designing, specifying, and installing insulation
- ·    Accredited certification training in conducting insulation energy appraisals

## New York State Energy Research and Development Authority (NYSERDA)

Phone: 518-862-1090

www.nyserda.org

Topics: NYSERDA offers a variety of opportunities for the commercial and industrial sectors in New York State to become more energy efficient.

## North Carolina State UniversityIndustrial Extension Services

Phone: 800-227-0264

www.ies.ncsu.edu

Topics:

- •    Energy Management Techniques
- •    Customized On-Site Boiler Seminars
- •    Measuring and Improving Boiler Efficiency
- •    An Evaluation of Oil vs. Natural Gas Firing in Boilers
- ·    Improving Boiler Efficiency Through the Use of Natural Gas

## Power Engineering Training Systems LTD (PanGlobal)

www.powerengineering.org

A recognized training organization heavily involved in boiler and boiler operator training.

## Schneider Electric/Energy University

## www.schneider-electric.com

Free online training includes:

- •    Industrial Insulation
- •    Energy Rate Structures
- •    The Economics of Energy Efficiency
- •    Measurement and Verification

## Spirax Sarco

Phone: 800-575-0394

www.spiraxsarco.com

Topics: Spirax Sarco offers an open university program on clean steam utilization, a steam engineering tutorial, and a continuing education program on steam systems.

## Steam Conservation Systems

Phone: 401-213-3315

www.trapo.com

Topics: Steam Conservation Systems offers programs for reducing the costs and hassles of maintaining a steam distribution system.

## WHERE TO FIND HELP

## Steam Economies Company

Phone: 513-874-8444

www.steameconomies.com

Topics:

- •    Boiler &amp; Steam System Fundamentals
- •    Understanding Your Steam Boiler System

## Swagelok Energy Advisors, Inc.

Phone: 888-615-3559 www.plantsupport.com

Topics:

- •    Steam System Training to Four Different Levels
- •    Customized On-Site Boiler Training
- •    Customized On-Site Complete Steam System Training
- •    Steam Trap Examiner Training (two levels)
- •    Utility Optimization Training (steam and compressed air)
- •    Steam Start-up and Shut-down Procedure Training
- •    Defining and Resolving Waterhammer Training
- •    On-site Steam System Assessments

## Tyco Valve &amp; Controls

Phone: 713-466-1176 www.tycoflowcontrol-na.com

Topics: 1- or 2½-day courses covering steam conservation, steam and condensate systems, steam trapping, valves, installation, and maintenance.

## University of Wisconsin-Madison/Extension

Department of Engineering Professional Development Phone: 800-462-0876 epdweb.engr.wisc.edu

Topics: The University of Wisconsin at Madison offers a course in boiler plant operation and maintenance.

## Multimedia Resources

## Armstrong International, Inc.

Phone: 269-273-1415

www.armintl.com

Guidelines for the Prevention of Water Hammer

Description: Video identifies the most likely causes of water hammer and provides solutions that can be implemented to prevent it. (16 minutes)

Guidelines for Steam System Efficiency

Description: Video explaining basic considerations in the design, piping, and trapping of steam systems. (15 minutes)

Guidelines for Steam Trap Troubleshooting and Testing

Description: Video outlining the need for establishing a preventive maintenance program and details on what to look and listen for in testing steam traps. (18 minutes)

## Let's Talk Steam Traps/Update

Description: Video explaining the operating principles of the three types of steam traps: mechanical, thermostatic, and thermodynamic. This tape helps users understand the internal operation of inverted bucket, F&amp;T, thermostatic, and disc traps. (32 minutes)

What Is Steam?

Description: Video explaining the basics of steam. (15 minutes)

## International District Energy Association

Phone: 508-366-9339

www.districtenergy.org

Steam Distribution System Safety-A Video Training Program

Description: The purpose of this video training is to present the operating features of a typical district heating system with special emphasis on hazards and safety procedures. A DVD or video is available on request.

## WHERE TO FIND HELP

## Spirax Sarco Application Engineering Department

Phone: 800-575-0394

www.spiraxsarco.com

How Clean is Your Steam

Description: This video highlights issues related to steam condensate for process equipment.

Steam Boilers: The Inside Information

Description: The video highlights internal boiler response to on/off demand, high steam demand, reduced boiler pressure, and change in total dissolved solids (TDS).

## Additional Multimedia Steam Resources

Find more multimedia and web-based resources from the various companies and associations listed throughout this document. Other suggested sources include:

U.S. DOE Industrial Assessment Center National Webcast Lecture Series

http:/ /iac.rutgers.edu/lectures2006/

ISA 100 Wireless Compliance Standards Institute

www.isa100wci.org

Wireless Industrial Networking Alliance

www.wina.org/

## APPENDICES

The following appendices have been included in the sourcebook:

## Appendix A: Glossary of Terms

This appendix contains a glossary of terms used in steam systems.

## Appendix B: Tip Sheets

This appendix contains REFERENCES to a series of steam system tip sheets. Developed by the U.S. Department of Energy, these tip sheets discuss common opportunities that industrial facilities can use to improve performance and reduce fuel use.

## Appendix A: Glossary of Terms

Absorption chilling -This is a water chilling process in which cooling of a solution is accomplished by the evaporation of a fluid (usually water), which is then absorbed by a different solution (usually lithium bromide), then evaporated under heat and pressure. The fluid is then condensed with the heat of condensation rejected through a cooling tower.

Air vent -A device that allows the release of noncondensable gases from a steam system.

Alkalinity -A measure of the concentration of carbonate, bicarbonate, and hydroxyl ion in water, usually expressed in equivalent parts per million (ppm) of calcium carbonate.

Backpressure turbine -A turbine that exhausts steam above atmospheric pressure. The exhaust steam is usually sent to other services.

Biomass -Organic matter which is available on a renewable basis, including agricultural crops and agricultural wastes and residues, wood and wood wastes and residues, animal wastes, municipal wastes, and aquatic plants.

Blowdown ratio -For boilers, the ratio of water removed by blowdown to the amount of feedwater provided to the boiler in equivalent units for the same time period (both usually reported in pounds per hour).

Boiler -A vessel or tank in which heat produced from the combustion of fuels such as natural gas, fuel oil, wood, or coal is used to generate hot water or steam for applications ranging from building space heating to electric power production or industrial process heat.

Boiler blowdown -The periodic or continuous removal of water from a boiler to remove concentrations of dissolved solids and/or sludge accumulating in the boiler.

Boiler horsepower -A unit of rate of water evaporation equal to the evaporation per hour of 34.5 pounds of water at a temperature of 212°F into steam at 212°F. One boiler horsepower equals 33,475 Btu per hour.

British thermal unit (Btu) -The amount of heat required to raise the temperature of one pound of water one degree Fahrenheit; equal to 252 calories. It is roughly equal to the heat of one kitchen match.

Chlorides -Chemical compounds found in boiler water consisting of metallic ions with chlorine atoms, part of a group of compounds called salts. The most prevalent are magnesium chloride and sodium chloride.

Cogeneration -The simultaneous production of electrical or mechanical work and thermal energy from a process, thus reducing the amount of heat or energy lost from the process. Also known as combined heat and power (CHP).

Combined Heat and Power (CHP) -The simultaneous production of electrical or mechanical work and thermal energy from a process, thus reducing any waste heat or energy lost from the process. Also known as cogeneration.

Combustion efficiency -This measure represents the amount of fuel energy extracted from flue gases. It is a steady state measure and does not include boiler shell losses or blowdown losses. The losses identified in this efficiency calculation are the stack losses. Stack loss is an indication of the amount of energy remaining in the flue gases as they exit the boiler.

Combustion turbine -A turbine that generates electric power from the combustion of a fuel.

Condensate -Condensed steam.

Condensate pump -A pump that pressurizes condensate allowing it to flow back to a collection tank, or boiler plant.

Condenser -A device that condenses steam. Surface condensers use a heat exchanger to remove energy from the steam, and typically operate under vacuum conditions.

Condensing turbine -A turbine that exhausts steam to typically subatmospheric conditions where the steam is condensed. These turbines are usually used in power generation applications.

Continuous blowdown -The process of removing water, on a continuous basis, from a boiler to remove high concentrations of dissolved solids, chlorides, and other products. Water is replaced by treated makeup water added to the condensate return. The withdrawn blowdown water is usually discharged to a sanitary drain.

Deaerator -A device that uses steam to strip feedwater of oxygen and carbon dioxide.

Desuperheater -A device used in steam systems to control the energy level and/or temperature of steam supplied to an end use, typically by injecting a fine mist of condensate into the steam flow.

Dew point -The temperature to which a vapor must be cooled in order for saturation or condensation to occur.

Dissolved solid -The minerals and impurities in boiler makeup water. These increase in concentration as water is boiled into steam.

Distillation column -A device that separates components of a compound relying on differences in boiling points.

Dryer -A device that removes moisture from a solid.

Duty cycle -The duration and periodicity of the operation of a device.

Excess air -Excess air in a combustion process is that amount of air present in excess of the theoretically required air for complete combustion. Excess air absorbs some of the heat of combustion and is carried away as waste heat with the exhaust combusted gases.

Evaporator -A device that removes moisture from a liquid, resulting in increased concentration of the remaining compounds.

Feedwater -Water sent into a boiler or a steam generator. Feedwater typically meets cleanliness criteria, contains treatment chemicals, and has been stripped of oxygen.

Feedwater pump -A pump that sufficiently pressurizes feedwater to supply a boiler or generator.

Full load efficiency -The stated efficiency (in percent) of a process in terms of energy or work output divided by energy input at rated production (full load).

Greenhouse gas emissions -Those gases, such as water vapor, carbon dioxide, tropospheric ozone, methane, and low level ozone that are transparent to solar radiation, but opaque to long wave radiation, and which are believed to contribute to climate change.

Heat exchanger -A device used to transfer heat from one medium by either direct or indirect contact.

## Heating, Ventilating and Air Conditioning (HVAC) -

All the components of the appliance or system used to condition the interior air of a facility.

Heat Recovery Steam Generator (HRSG) -A device that captures the thermal energy in an exhaust stream or a process stream and transfers it to water to generate steam.

Kilowatt hour (kWh) -A unit of measure of electricity supply or consumption of 1,000 Watts over the period of one hour; equivalent to 3,412 Btu.

Latent heat -The change in heat content that occurs with a change in phase and without change in temperature. Changes in heat content that affect a change in temperature are called sensible heat changes.

Life Cycle Cost (LCC) -The sum of all the costs both recurring and nonrecurring, related to a product, structure, system, or service during its life span or specified time period.

Makeup water -Water brought into a boiler system from outside to replace condensate not returned to the boiler plant, water used in blowdown, steam lost through leaks, or water lost through evaporation or mist.

MMBtu -A unit of one million British thermal units (Btu).

Payback -The amount of time required for positive cash flows to equal the total investment costs. This is often used to describe how long it will take for energy savings resulting from using more energy-efficient equipment to equal the premium paid to purchase the more energy-efficient equipment.

Potable water -Water that is suitable for drinking, as defined by local health officials.

Pounds per square inch gauge (psig) -A unit of pressure in pounds force in comparison to local atmospheric pressure (as measured by a gauge).

Pressure Reducing Valve (PRV) -A valve that regulates the amount of steam allowed from a high-pressure service to a low-pressure service.

Radiant energy -Energy (transfer of heat through matter or space by means of electromagnetic waves) that transmits away from its source in all directions.

Reboiler -A heat exchanger used in petroleum refining and chemical manufacturing applications that adds heat to a process stream.

Reformer -A device that produces hydrogen from a hydrocarbon compound such as methane, typically by using steam.

Relative humidity -A measure of the percent of moisture actually in the air compared with what would be in it if it were fully saturated at that temperature. When the air is fully saturated, its relative humidity is 100 percent.

R-Value -A measure of the capacity of a material (or assembly of materials) to resist heat transfer, sometimes called thermal resistance. The R-Value is the reciprocal of the heat transfer coefficient (U-Value). The larger the R-Value, the greater its insulating properties.

Sensor -A device that determines the operational parameter or status of a system or component such as temperature or harmonics within a steam trap to infer proper or improper operational conditions.

Silica -The concentration of silica dioxide found in water measured in parts per million. Silica forms a tenacious scale with low thermal conductance. Silica is soluble in steam and can carry over into steam where it can condense on turbine blades or erode surfaces.

Sludge -A general term applied to a relatively loose accumulation of material that has settled to the bottom of a boiler.

Stack heat loss -Sensible and latent heat contained in combustion gases and vapor emitted to the atmosphere.

Stand-alone -A device that operates independent of or is not connected to other systems.

Standby losses -In boiler systems, standby losses are energy losses that are associated with natural draft through a boiler in a standby operating mode.

Steam ejector -A device that uses a relatively highpressure motive steam flow through a nozzle to create a low-pressure or suction effect.

Steam injector -A device that injects steam into a process, often used in direct steam heating applications.

Steam trap -An automatic control valve that allows for the release of condensate, air, CO , and other non-con2 densable gases, yet keeps live steam in the system.

Stripper -A device that separates components from a compound.

Surface blowdown -Boiler blowdown taken from the upper part of the boiler just below the water surface to reduce the amount of dissolved solids.

Thermal conductivity -This is a positive constant, k, that is a property of a substance and is used in the calculation of heat transfer rates for materials. It is the amount of heat that flows through a specified area and thickness of a material over a specified period of time when there is a temperature difference of one degree between the surfaces of the material.

Thermal load factor -A term used to describe the relative stability of use of heating in a facility or a process. Often used in cogeneration where a 'high' factor denotes a continuous use of steady heating.

Thermocompressor -A device that uses high-pressure steam to increase the pressure of a low-pressure steam supply to generate a more useful steam service.

Throttling -Regulating flow rate by closing a valve in the system.

## APPENDICES

Turbine -A device that converts the enthalpy of steam into mechanical work. See condensing turbine and backpressure turbine.

Vacuum breaker -A device that responds to the formation of vacuum conditions in equipment such as a heat exchanger by allowing in air which promotes condensate drainage.

Variable Frequency Drive (VFD) -A type of variable speed motor drive in which the motor is supplied with electrical power at frequencies other than standard 60 Hertz through a converter.

Variable Air Volume (VAV) -Variable air volume is a term for changing the quantity of air flow to meet heating, cooling, or exhaust loads rather than changing air temperatures.

Waste heat -Heat that is discharged from a mechanical process, wastewater, or ventilation exhaust system that could be reclaimed for useful purposes.

Water hammer -A shock that results from the sudden collapse of a steam pocket in a two phase line such as a condensate return line. Also the impingement of a water slug carried by relatively high velocity steam.

Wireless Sensor Network -A combination of sensors, wireless data transmission, and reception technologies commonly built upon standards such as ISA 100 that results in data systems that reliably and securely monitor efficiency even in Radio Frequency noisy environments that are commonly found in industrial plants. These systems allow plant personnel to improve the management of energy systems by monitoring such parameters as proper steam trap operation, or process heat exchanger temperatures, or condensate or feedwater pump operation and performance, or boiler excess oxygen conditions. These systems provide a low-cost opportunity to improve profits associated with optimum, real-time steam system operation.

## Appendix B: Steam Tip Sheets

Some improvement opportunities are available to many different systems. To increase industry awareness of several fundamental improvement opportunities, the U.S. Department of Energy's Advanced Manufacturing Office (AMO) developed the following tip sheets. Learn more about each of these topics by downloading the steam tip sheets from the AMO website: manufacturing.energy.gov .

- 1.   Inspect and Repair Steam Traps
- 2.   Insulate Steam Distribution and Condensate Return Lines
- 3.   Use Feedwater Economizers for Waste Heat Recovery
- 4. Improve Your Boiler's Combustion Efficiency
- 5. Not available
- 6. Not available
- 7.   Clean Boiler Waterside Heat Transfer Surfaces
- 8. Return Condensate to the Boiler
- 9.   Minimize Boiler Blowdown
- 10.   Recover Heat from Boiler Blowdown
- 11.   Use Vapor Recompression to Recover Low-Pressure Waste Steam
- 12.   Flash High-Pressure Condensate to Regenerate Low-Pressure Steam
- 13.   Use a Vent Condenser to Recover Flash Steam Energy
- 14.   Use Low-Grade Waste Steam to Power Absorption Chillers
- 15. Benchmark the Fuel Costs of Steam Generation
- 16.   Minimize Boiler Short Cycling Losses
- 17.   Install Removable Insulation on Valves and Fittings
- 18. Deaerators in Industrial Steam Systems
- 19.   Cover Heated, Open Vessels
- 20.   Replace Pressure-Reducing Valves with Backpressure Turbogenerators
- 21.   Consider Steam Turbine Drives for Rotating Equipment
- 22.   Consider Installing High-Pressure Boilers with Backpressure Turbine-Generators
- 23. Install an Automatic Blowdown Control System
- 24.   Upgrade Boilers with Energy-Efficient Burners
- 25.   Consider Installing Turbulators on Two- and Three-Pass Firetube Boilers
- 26a. Consider Installing a Condensing Economizer
- 26b. Considerations When Selecting a Condensing Economizer
- 29. Use Steam Ejectors or Thermocompressors

<!-- image -->

Council of Industrial Boiler Operators

Phone: 703-250-9042 www.cibo.org

<!-- image -->

For more information, visit: eere.energy.gov/manufacturing

<!-- image -->

National Insulation Association

Phone: 703-464-6422 www.insulation.org

Co-sponsored by:

<!-- image -->

<!-- image -->

North American Insulation Manufacturers Association Phone: 703-684-0084 www.naima.org

American Boiler Manufacturers Association Phone: 703-356-7172 www.abma.com

About the Office of Energy Efficiency and Renewable Energy

The Office of Energy Efficiency and Renewable Energy (EERE) invests in clean energy technologies that strengthen the economy, protect the environment, and reduce dependence on foreign oil.

Advanced Manufacturing Office

U.S. Department of Energy Energy Efficiency and Renewable Energy Washington, D.C. 20585-0121

Improving Steam System Performance: A Sourcebook for Industry, Second Edition One in a series of industrial energy efficiency sourcebooks.

DOE/GO-102012-3423   •  Revised October 2012