---
document_id: doe_steam_tip_4
title: "Steam Tip Sheet #4: Improve Your Boiler's Combustion Efficiency"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_steam_tip04_boiler_combustion_efficiency.pdf"
tables_detected: 7
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

Energy Tips: STEAM

## Improve Your Boiler's Combustion Efficiency

## Combustion Efficiency

Operating your boiler with an optimum amount of excess air will minimize heat loss up the stack and improve combustion efficiency. Combustion efficiency is a measure of how effectively the heat content of a fuel is transferred into usable heat. The stack temperature and flue gas oxygen (or carbon dioxide) concentrations are primary indicators of combustion efficiency.

Given complete mixing, a precise or stoichiometric amount of air is required to completely react with a given quantity of fuel. In practice, combustion conditions are never ideal, and additional or 'excess' air must be supplied to completely burn the fuel.

The correct amount of excess air is determined from analyzing flue gas oxygen or carbon dioxide concentrations. Inadequate excess air results in unburned combustibles (fuel, soot, smoke, and carbon monoxide), while too much results in heat lost due to the increased flue gas flow-thus lowering the overall boiler fuel-to-steam efficiency. The table relates stack readings to boiler performance.

Combustion Efficiency for Natural Gas

|           | Combustion Efficiency   |                                                           |                                                           |                                                           |                                                           |                                                           |
|-----------|-------------------------|-----------------------------------------------------------|-----------------------------------------------------------|-----------------------------------------------------------|-----------------------------------------------------------|-----------------------------------------------------------|
| Excess, % | Excess, %               | Flue Gas Temperature Minus Combustion Air Temperature, °F | Flue Gas Temperature Minus Combustion Air Temperature, °F | Flue Gas Temperature Minus Combustion Air Temperature, °F | Flue Gas Temperature Minus Combustion Air Temperature, °F | Flue Gas Temperature Minus Combustion Air Temperature, °F |
| Air       | Oxygen                  | 200                                                       | 300                                                       | 400                                                       | 500                                                       | 600                                                       |
| 9.5       | 2.0                     | 85.4                                                      | 83.1                                                      | 80.8                                                      | 78.4                                                      | 76.0                                                      |
| 15.0      | 3.0                     | 85.2                                                      | 82.8                                                      | 80.4                                                      | 77.9                                                      | 75.4                                                      |
| 28.1      | 5.0                     | 84.7                                                      | 82.1                                                      | 79.5                                                      | 76.7                                                      | 74.0                                                      |
| 44.9      | 7.0                     | 84.1                                                      | 81.2                                                      | 78.2                                                      | 75.2                                                      | 72.1                                                      |
| 81.6      | 10.0                    | 82.8                                                      | 79.3                                                      | 75.6                                                      | 71.9                                                      | 68.2                                                      |

Assumes complete combustion with no water vapor in the combustion air.

On well-designed natural gas-fired systems, an excess air level of 10% is attainable. An often-stated rule of thumb is that boiler efficiency can be increased by 1% for each 15% reduction in excess air or 40°F reduction in stack gas temperature.

Steam Tip Sheet #4

## Suggested Actions

Boilers often operate at excess air levels higher than the optimum. Periodically monitor flue gas composition and tune your boilers to maintain excess air at optimum levels.

Consider online monitoring of flue gas oxygen level to quickly identify energy loss trends that can provide early warning of control failures and allow data to drive your decision making.

## Example

A boiler operates for 8,000 hours per year and annually consumes 500,000 million Btu (MMBtu) of natural gas while producing 45,000 lb/hour of 150-psig steam. Stack gas measurements indicate an excess air level of 44.9% with a flue gas minus combustion air temperature of 400°F.  From the table, the boiler combustion efficiency is 78.2% (E1). Tuning the boiler reduces the excess air to 9.5% with a flue gas minus combustion air temperature of 300°F. The boiler combustion efficiency increases to 83.1% (E2). Assuming a fuel cost of $8.00/MMBtu, the annual savings are:

Annual Savings

= Fuel Consumption x (1-E1/E2) x Fuel Cost

= 29,482 MMBtu/yr x $8.00/MMBtu

= $235,856

## Flue Gas Analyzers

The percentage of oxygen in the flue gas can be measured by inexpensive gas-absorbing test kits. More expensive (ranging in cost from $500 to $1,000) hand-held, computer-based analyzers display percent oxygen, stack gas temperature, and boiler efficiency. They are a recommended investment for any boiler system with annual fuel costs exceeding $50,000.

## Oxygen Trim Systems

When fuel composition is highly variable (such as refinery gas, hog fuel, or multi-fuel boilers), or where steam flows are highly variable, an online oxygen analyzer should be considered. The oxygen 'trim' system provides feedback to the burner controls to automati cally minimize excess combustion air and optimize the air-to-fuel ratio.

For additional information on monitoring, download the following sub-metering  case stud ies from the AMO publication library:

- ·  Solutia: Utilizing Sub-Metering to Drive Energy Project Approvals Through Data
- ·  Nissan North America: How Sub-Metering Changed the Way a Plant Does Business

Also refer to the following guidebook on the EERE Federal Energy Management website at www.femp.energy.gov :

- •  Metering Best Practices: A Guide to Achieving Utility Resource Efficiency, Release 2.0

Adapted from an Energy TIPS fact sheet that was originally published by the Industrial Energy Extension Service of Georgia Tech.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3405  •  January 2012

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.