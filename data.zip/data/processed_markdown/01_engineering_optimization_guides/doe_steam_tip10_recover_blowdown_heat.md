---
document_id: doe_steam_tip_10
title: "Steam Tip Sheet #10: Recover Heat from Boiler Blowdown"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_steam_tip10_recover_blowdown_heat.pdf"
tables_detected: 6
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

A

D

V

A

N

C

E

D

Energy Tips: STEAM

## Recover Heat from Boiler Blowdown

Heat can be recovered from boiler blowdown by using a heat exchanger to preheat boiler makeup water. Any boiler with continuous blowdown exceeding 5% of the steam rate is a good candidate for the introduction of blowdown waste heat recovery. Larger energy savings occur with high-pressure boilers. The following table shows the potential for heat recovery from boiler blowdown.

Recoverable Heat from Boiler Blowdown

| Blowdown Rate, % Boiler Feedwater   |   Heat Recovered, Million Btu per hour (MMBtu/hr) Steam Pressure, psig |   Heat Recovered, Million Btu per hour (MMBtu/hr) Steam Pressure, psig |   Heat Recovered, Million Btu per hour (MMBtu/hr) Steam Pressure, psig |   Heat Recovered, Million Btu per hour (MMBtu/hr) Steam Pressure, psig |   Heat Recovered, Million Btu per hour (MMBtu/hr) Steam Pressure, psig |
|-------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------|
| Blowdown Rate, % Boiler Feedwater   |                                                                  50    |                                                                  100   |                                                                 150    |                                                                 250    |                                                                 300    |
| 2                                   |                                                                   0.45 |                                                                    0.5 |                                                                   0.55 |                                                                   0.65 |                                                                   0.65 |
| 4                                   |                                                                   0.9  |                                                                    1   |                                                                   1.1  |                                                                   1.3  |                                                                   1.3  |
| 6                                   |                                                                   1.3  |                                                                    1.5 |                                                                   1.7  |                                                                   1.9  |                                                                   2    |
| 8                                   |                                                                   1.7  |                                                                    2   |                                                                   2.2  |                                                                   2.6  |                                                                   2.7  |
| 10                                  |                                                                   2.2  |                                                                    2.5 |                                                                   2.8  |                                                                   3.2  |                                                                   3.3  |
| 20                                  |                                                                   4.4  |                                                                    5   |                                                                   5.6  |                                                                   6.4  |                                                                   6.6  |

Based on a steam production rate of 100,000 pounds per hour, 60°F makeup water, and 90% heat recovery.

## Example

In a plant where the fuel cost is $8.00 per million Btu ($8.00/MMBtu), a continuous blowdown rate of 3,200 pounds per hour (lb/hr) is maintained to avoid the buildup of high concentrations of dissolved solids. What are the annual savings if a makeup water heat exchanger is installed that recovers 90% of the blowdown energy losses? The 80% efficient boiler produces 50,000 pounds per hour (lb/hr) of 150-pounds-per-square-inch-gauge (psig) steam. It operates for 8,000 hours per year. The blowdown ratio is:

<!-- formula-not-decoded -->

From the table, the heat recoverable corresponding to a 6% blowdown ratio with a 150-psig boiler operating pressure is 1.7 MMBtu/hr. Since the table is based on a steam production rate of 100,000 lb/hr, the annual savings for this plant are:

Annual Energy Savings =

[1.7 MMBtu/hr x (50,000 lb/hr/100,000 lb/hr) x 8,000 hr/yr]/0.80

=

8,500 MMBtu

Annual Cost Savings =

8,500 MMBtu/yr x $8.00/MMBtu

= $68,000

Steam Tip Sheet #10

## Suggested Actions

If there is a continuous blowdown system in place, consider installing a heat recovery system. If there is a noncontinuous blowdown system, then consider the option of converting it to a continuous blowdown system coupled with heat recovery.

## Blowdown Energy Recovery

Blowdown waste heat can be recovered with a heat exchanger, a flash tank, or flash tank in combination with a heat exchanger. Lowering the pressure in a flash tank allows a portion of the blowdown to be converted into low-pressure steam. This low-pressure steam is most typically used in deaerators. Drain water from the flash tank is then routed through a heat exchanger. Cooling the blowdown has the additional advantage of helping to comply with local codes limiting the discharge of high-temperature liquids into the sewer system.

For additional information on heat recovery, refer to the factsheet Unlock Energy Savings with Waste Heat Recovery in the publication library on the AMO website.

Adapted from an Energy TIPS fact sheet that was originally published by the Industrial Energy Extension Service of Georgia Tech.

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3408  •  January 2012