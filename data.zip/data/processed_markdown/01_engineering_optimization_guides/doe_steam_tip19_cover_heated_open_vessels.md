---
document_id: doe_steam_tip_19
title: "Steam Tip Sheet #19: Cover Heated, Open Vessels"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_steam_tip19_cover_heated_open_vessels.pdf"
tables_detected: 6
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

A

D

Energy Tips: STEAM

## Cover Heated, Open Vessels

Open vessels that contain heated liquids often have high heat loss due to surface evaporation. Both energy and liquid losses are reduced by covering open vessels with insulated lids. The table below provides an estimate of the evaporative heat loss per square foot (ft ) of uncovered vessel surface area for various water and 2 dry ambient air temperatures. It is assumed that the ambient air is dry with no wind currents. A fan pulling air over the uncovered tank could more than double the heat losses.

Evaporative Heat Loss from Water in Open Tanks, Btu/hr-ft 2

| Liquid Temperature, °F   | Ambient Air Temperature, °F   | Ambient Air Temperature, °F   | Ambient Air Temperature, °F   | Ambient Air Temperature, °F   | Ambient Air Temperature, °F   |
|--------------------------|-------------------------------|-------------------------------|-------------------------------|-------------------------------|-------------------------------|
| Liquid Temperature, °F   | 65                            | 75                            | 85                            | 95                            | 105                           |
| 110                      | 244                           | 222                           | 200                           | 177                           | 152                           |
| 130                      | 479                           | 452                           | 425                           | 397                           | 369                           |
| 150                      | 889                           | 856                           | 822                           | 788                           | 754                           |
| 170                      | 1,608                         | 1,566                         | 1,524                         | 1,482                         | 1,440                         |

Note: This table is extracted from Steam Efficiency Improvement by the Boiler Efficiency Institute at Auburn University.

## Example

A rinse tank is 4 feet (ft) wide and 10 feet (ft) long. It is maintained at a constant temperature of 170°F. Determine the evaporative heat loss from the tank if the ambient temperature is 75°F.

Area of Evaporating Surface = 4 ft x 10 ft

= 40 ft

2

Total Heat Loss for Uncovered Liquid Surface =

1,566 Btu/hr-ft  x 40 ft 2 2

= 62,640 Btu/hr

## Cover the Tank with an Insulated Top

Assume that the rinse tank is heated during two shifts per day, five days per week, and 50 weeks per year. What are the annual energy savings that may be obtained by covering the tank? What is the heating cost reduction in a plant where the cost of steam is $8.00 per million Btu ($8.00/MMBtu)? Assume that covering the rinse tank with an insulated lid effectively reduces the heat losses from the liquid surface to a negligible value.

Annual Energy Savings =

62,640 Btu/hr x 2 shifts/day x 8 hr/shift x 250 days/yr 250 MMBtu

=

Annual Heating Cost Reduction =

250 MMBtu/yr x $8.00/MMBtu $2,000

=

Steam Tip Sheet #19

## Suggested Actions

- ■ ■ Conduct a survey to determine the number of open vessels that contain heated liquid within your plant. For each tank, determine the operating schedule, liquid temperature, ambient temperature, and square feet of exposed area.
- ■ ■ Estimate the annual heat loss from the uncovered tanks and determine the potential annual fuel cost savings.
- ■ ■ Evaporation and heat losses can be reduced by lowering the liquid temperature, reducing the exposed liquid area, minimizing flow of air over the tank, or installing an insulated cover.
- ■ ■ Obtain cost estimates for insulated covers. Install covers when they are economically justified.

## Heat Loss Detail

- ·  Eliminating internal heat gains will also result in electrical energy savings if the open tanks are located within a conditioned space.
- ·  Heat losses are a strong function of both wind velocity and ambient air humidity. A wind velocity of 3 miles per hour will more than double the rate of heat loss from a tank.
- ·  Radiation heat transfer is a secondary source of tank surface heat losses. Radiation losses increase from 90 Btu/hr-ft 2 at a liquid temperature of 110°F to 290 Btu/hr-ft  at 190°F. 2

Steam Tip Sheet information adapted from an Energy TIPS fact sheet originally published by the Industrial Energy Extension Service of Georgia Tech and reviewed by the AMO Steam Technical Subcommittee.

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3398  •  January 2012