---
document_id: doe_ca_tip_9
title: "Compressed Air Tip Sheet #9: Sizing Compressed Air Receiver Storage Tanks"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip09_storage_tank_sizing.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #9 • August 2004

## Suggested Actions

- ·  Review the plant's compressed air demand patterns to determine whether storage would be beneficial.
- ·  Examine the compressed air applications to determine if they can be supplied by a separate, smaller compressor with storage to reduce the system demand fluctuations caused by their intermittent demand.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies Program and CAC:

Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Compressed Air Storage Strategies

Compressed air storage can allow a compressed air system to meet its peak demand needs and help control system pressure without starting additional compressors. The appropriate type and quantity of air storage depends on air demand patterns, air quantity and quality required, and the compressor and type of controls being used. An optimal air storage strategy will enable a compressed air system to provide enough air to satisfy temporary air demand events while minimizing compressor use and pressure.

The use of air receivers is especially effective for systems with shifting air demand patterns. When air demand patterns are variable, a large air receiver can provide enough stored air so that a system can be served by a small compressor and can allow the capacity control system to operate more effectively. For systems having a compressor operating in modulation to support intermittent demand events, storage may allow such a compressor to be turned off. By preventing pressure decay due to demand events, storage can protect critical end-use applications and prevent additional units from coming online.

Air entering a storage receiver needs to be at a higher pressure level than the system pressure. A good air storage strategy will allow the differential between these two pressure levels to be sustained. To accomplish such a pressure differential, two types of devices can be employed: Pressure/Flow Controllers (P/FC) and metering valves.

A P/FC is a device that serves to separate the supply side of a compressed air system from the demand side. In a system that employs P/FCs, the compressors generally operate at or near design discharge pressure to ensure that the P/FC receives air at a higher pressure level than it will discharge into the system. This allows the pressure in the demand side to be reduced to a stable level that minimizes actual compressed air consumption. P/FCs are added after the primary receiver to maintain a reduced and relatively constant system pressure at points of use, while allowing the compressor controls to function in the most efficient control mode and discharge pressure range. Properly applied, a P/FC can yield significant energy savings in a system with a variable demand load. See Figure 1.

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

<!-- image -->

<!-- image -->

For situations in which just one or a few applications have intermittent air demand, a correctly-sized storage receiver close to the point of the intermittent demand with a check valve and a metering valve can be an effective and lower cost alternative. For this type of storage strategy, a check valve and a tapered plug or needle valve are installed upstream of the receiver. The check valve will maintain receiver pressure at the maximum system pressure; the plug or needle valve will meter the flow of compressed air to 'slow fi  ll' the receiver during the interval between demand events. This will have the effect of reducing the large intermittent requirement into a much smaller average demand. See Figure 2.

## Figure 2. A Compressed Air System with Check and Needle Valves

<!-- image -->

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.