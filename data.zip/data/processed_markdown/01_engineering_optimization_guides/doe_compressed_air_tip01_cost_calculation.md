---
document_id: doe_ca_tip_1
title: "Compressed Air Tip Sheet #1: Determine the Cost of Compressed Air for Your Plant"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip01_cost_calculation.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #1 • August 2004

## Suggested Actions

- ·  Determine the cost of compressed air for your plant by periodically monitoring the compressor operating hours and load duty cycle.
- ·  Use a systems approach while operating and maintaining a compressed air system.
- ·  Adopt a plant-wide compressed air management policy to cut costs and reduce waste by eliminating inappropriate uses, fixing leaks, and matching system supply with demand.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies Program and CAC:

Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Determine the Cost of Compressed Air for Your Plant

Most industrial facilities need some form of compressed air, whether for running a simple air tool or for more complicated tasks such as the operation of pneumatic controls. A recent survey by the U.S. Department of Energy showed that for a typical industrial facility, approximately 10% of the electricity consumed is for generating compressed air. For some facilities, compressed air generation may account for 30% or more of the electricity consumed. Compressed air is an on-site generated utility. Very often, the cost of generation is not known; however, some companies use a value of 18-30 cents per 1,000 cubic feet of air.

Compressed air is one of the most expensive sources of energy in a plant. The overall efficiency of a typical compressed air system can be as low as 10%-15%. For example, to operate a 1-horsepower (hp) air motor at 100 pounds per square inch gauge (psig), approximately 7-8 hp of electrical power is supplied to the air compressor. To calculate the cost of compressed air in your facility, use the formula shown below:

Cost ($) =

## (bhp) x (0.746) x (# of operating hours) x ($/kWh) x (% time) x (% full-load bhp) Motor Efficiency

Where:

bhp -Motor full-load horsepower (frequently higher than the motor nameplate horsepower-check equipment specification) 0.746 -conversion between hp and kW

Percent time -percentage of time running at this operating level Percent full-load bhp -bhp as percentage of full-load bhp at this operating level Motor efficiency -motor efficiency at this operating level

## Example

A typical manufacturing facility has a 200-hp compressor (which requires 215 bhp) that operates for 6800 hours annually. It is fully loaded 85% of the time (motor efficiency = .95) and unloaded the rest of the time (25% full-load bhp and motor efficiency = .90). The aggregate electric rate is $0.05/kWh.

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

Cost when fully loaded =

(215 bhp) x (0.746) x (6800 hrs) x ($0.05/kWh) x (0.85) x (1.0)    = $48,792 .95

Cost when unloaded =

(215 bhp) x (0.746) x (6800 hrs) x ($0.05/kWh) x (0.15) x (0.25)  = $2,272

.90

Annual energy cost = $48,792 + $2,272 = $51,064

<!-- image -->

## Typical Lifetime Compressed Air Costs in Perspective-Costs Over 10 Years

Assumptions in this example include a 75-hp compressor operated two shifts a day, 5 days a week at an aggregate electric rate of $0.05/kWh over 10 years of equipment life.

<!-- image -->

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.

DOE/GO-102004-1926 Revised August 2004 Compressed Air Tip Sheet #1