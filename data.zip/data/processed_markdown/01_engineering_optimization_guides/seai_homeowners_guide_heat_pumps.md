---
document_id: seai_heat_pump_guide
title: "Homeowners Guide to Heat Pump Systems: Efficiency and Sizing"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "SEAI"
year: 2022
original_file: "seai_homeowners_guide_heat_pumps.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## A Homeowner's Guide To Heat Pump Systems

## HOW YOU CAN BENEFIT FROM INVESTING IN A HEAT PUMP SYSTEM?

## HOW DO HEAT PUMPS WORK?

- · Create a more energy efficienty home and reduce energy consumption
- · Maintain a constant temperature and improve home comfort and health.
- · Move away from fossil fuels by switching to clean energy
- · Reduce energy consumption and lower energy bills.

Do you know you can get grant support for installing a heat pump system through SEAI's Home Energy Upgrade grant programmes?

Inefficient heating systems are wasteful of energy and costly to run because of the amount of fuel needed to maintain adequate comfort levels and hot water in the home.

Replacing a conventional heating system with a heat pump system, particularly in a well-insulated dwelling, can transform the comfort levels in the home while reducing energy usage and harmful greenhouse gas emissions. In addition, the heat pump system can eliminate oil and gas bills from the home.

To install a heat pump system, you must ensure your home is well insulated and that you have good double or triple glazed windows. In this way your heat pump system will perform well and your electricity bills will be low.

SEAI's Home Energy Upgrade grant programmes offer supports to help you install a heat pump system in your home and realise these benefits. SEAI also provides funding towards a Technical Assessment of your home by an independent SEAI registered Technical Advisor, who will help you make an informed decision and ensure your home and the heat pump system are a good match. Find out more about the Technical Assessment process in the 'Before You Apply' section here: www.seai.ie/grants/home-energygrants/heat-pump-systems/

A heat pump system harnesses energy from free renewable sources outside the building, for heating your house and producing your hot water.

Electrical heat pumps use a compressor to draw heat from a low temperature source, such as external air or ground to heat the building interior. While conventional heating systems such as storage heaters and boilers cannot produce more heat than that contained in their fuel source, a heat pump typically will produce three to four units of heat for every unit of electricity consumed. The heat pump example in Figure 1 below has a Coefficient of Performance (COP) of 4.

Figure 1: Heat Pump Coefficient of Performance (COP)

<!-- image -->

Most heat pump systems have integrated heating controls, helping you to accurately match your space heating and hot water schedules to the working and living patterns in your home, so when heat and hot water are required, it is there; and when it is not required, it is turned off. Using  the heating controls in your heat pump system will typically reduce your energy usage by up to 20%.

<!-- image -->

## A Homeowner's Guide To Heat Pump Systems

## TYPES OF HEAT PUMP SYSTEMS

Different types of heat pump systems draw heat from different sources: air, water or the ground. Heat generated is distributed via radiators, underfloor heating or warm air units. Heat pump systems will heat radiators to a lower temperature than conventional boiler systems, and this works well when the home is well insulated. Heat pump systems, excluding those providing warm air to the home, can supply most of the hot water needed for baths, showers and sinks.

Air Source: The most common heat pump systems extract heat from external air, typically using an outside unit such as that shown in Figure 2. These heat pump systems do not require underground piping to source heat and so can be cheaper and easier to install compared to ground source heat pump systems.

- · Air to water heat pump systems are the most popular choice of system. Heat is distributed through radiators and underfloor heating and they can also produce hot water.
- · Exhaust-air to water heat pump systems are similar to air to water but include mechanical extract ventilation and recover heat from air drawn from the dwelling.
- · In Air to air heat pump systems the heat is distributed through air units. Air to air heat pump systems do not provide hot water.

Figure 2: Air Source Heat Pump Outdoor Unit

<!-- image -->

Ground Source and Water Source: Ground source and water source heat pump systems are less common than air source units. A ground source heat pump system, also known as a geothermal heat pump system, uses the earth as a source of renewable heat. Heat is drawn from the ground through collector pipework and transferred to the heat pump. The ground collector can be laid out horizontally at a shallow depth below the surface or else vertically to a greater depth.

A very comprehensive guide to ground and water source heat pump systems, published by the Geological Survey of Ireland, is available at this link: www.gsi.ie/documents/ GeothermalHomeownerManual.pdf

Water source heat pump systems use open water (lakes, rivers or streams) as a heat source. While ground and water source heat pump systems have the extra complexity and cost of installing the collector pipework to draw heat from the ground or water, they can have more consistent performance than air source heat pump systems, even in colder weather.

Note: Regardless of the type of heat pump system you choose, it is important to note that you will need leave your heat pump switched on for long periods of time to make sure that it performs well and operates most economically.

<!-- image -->

## Figure 3: Heat pump installations sourcing heat from the ground and from water

Some heat pump systems, such as those requiring the use of oil or gas, or those providing only hot water, cannot avail of the SEAI grant. Please check with your contractor and, if in any doubt, call the Home Energy Grants Helpdesk on 01 8082100.

## HOW DO I CHOOSE?

Selection of the right type of heat pump system can often depend on practical and budgetary limitations. Many people choose air source heat pump systems as they need relatively little space. If you have a large garden or are near a water source you may choose a ground source or water source heat pump. SEAI Registered Heat Pump Contractors and independent SEAI registered Technical Advisors can help you make the right choice. They will outline the pros and cons of each type of heat pump system.

## ENSURE YOUR HOME AND HEAT PUMP SYSTEM ARE A GOOD MATCH: GETTING STARTED

Heat pump systems are at their most efficient and effective when generating heat at a lower temperature. On this basis, one of the requirements for a dwelling to qualify for an SEAI Home Energy grant for a heat pump system is that the dwelling has low heat loss. Some of the measures that can help achieve this are insulation upgrades such roof and wall insulation upgrades, which are grant aided under SEAI's

<!-- image -->

## A Homeowner's Guide To Heat Pump Systems

Home Energy Grants programme. Good insulation is needed to reduce draughts in the home and eliminate heat losses through open chimneys, which will affect the performance of your heat pump system.

If your home is built prior to 2007, you must engage an independent SEAI registered Technical Advisor before applying for the heat pump system grant. They will carry out a technical assessment and Building Energy Rating on the house before guiding you on the energy performance of the dwelling, particularly on the suitability of the dwelling for a heat pump system, based on the dwelling's heat loss. They will provide you with independent guidance on measures that may be necessary to ensure that the dwelling fabric heat loss is lowered to an acceptable level for a heat pump system to perform at its best. If your home is built from 2007 onwards, you have a choice of completing a Technical Assessment or completing and submitting a Self-Declaration form, which forgoes the requirement for a Technical Assessment to be completed. Further details of this process can be found here: https://www. seai.ie/grants/home-energy-grants/heat-pump-systems/

A dwelling with poor insulation and single glazing could cost substantially more to upgrade to the necessary level than, say, a well-insulated dwelling with newer double glazing.  The Technical Advisor can also help you understand the types of heat pump systems available and the options most suitable for your dwelling, before you talk in more depth to a heat pump contractor. It is worth discussing home upgrades with friends and family who may have already carried out the measures to give you a better insight into the advantages, improvements and possible issues they experienced when upgrading their own homes. You should visit an existing heat pump system before proceeding with the installation.

Pre-2007 homes: Techincal Assessment and indentified fabric upgrades are mandatory for both grants to ensure your home meets the required heat loss indicator, allowing your heat pump system to perform efficiently and effectively. Failure to meet the HLI requirement will result in Technical Assessment and Heat Pump grants being declined.

2007 onwards: Technical Assessment is optional and any fabric upgrades recommended in the Assessment are not mandatory in order to avail of the grant.

## QUESTIONS TO ASK YOUR SUPPLIER AND CONTRACTOR

Once the Technical Assessment of Self-Declaration form have been completed and uploaded (depending on your dwellings year of construction), the heat pump application can be created and further discussion with an SEAI registered Contractor about installing the heat pump system can take place. Depending on recommendations from the SEAI registered Technical Advisor, you may also need to contact one of SEAI's registered insulation contractors. Check out our other Homeowner Guides on grant funded fabric measures at: www.seai.ie/grants/home-energygrants/insulation-grants

All SEAI registered contractors follow an approach using high quality workmanship and products ensuring the right standards and regulations are followed for all grant measures. It is worthwhile talking to a few different registered contractors, so you have a better understanding of the options available to you and typical costs. Discussion with contractors can also give better insight into likely additional costs (such as additional electrical works or replacement of existing heat distribution systems with underfloor heating or low temperature radiators).

SEAI has compiled a list of questions you should ask your suppliers and contractors prior to going ahead with the heat pump system purchase. Your Technical Advisor may also help you to identify other useful questions for the heat pump contractor. It is in your best interest to make sure you are satisfied that all your questions are answered. If an answer seems too complicated, then ask for a simpler explanation. If someone is selling you a heat pump system, they will be happy to provide an explanation to your satisfaction.

## EQUIPMENT

- 1. Is this heat pump type eligible for SEAI Home Energy Grants funding?
- 2. Does it meet SEAI's grant specifications in terms of certification, CE marking and other relevant standards?
- 3. Does the system exceed SEAI's heat pump efficiency requirements? By how much?
- 4. What are the heat source options for my dwelling, e.g. air source vs. ground source?
- 5. Do I need a new heat distribution system (e.g. low temperature radiators) or can I use what I have already?
- 6. How noisy is the system in operation? Will it be located near doors or windows?
- 7. Will the heat pump be located close to the house to ensure optimum efficiency of the pump?
- 8. Is the heat pump being located near to saline environments? If so, discuss treatment options with your installer to ensure against rust.
- 9.
- What kind of controls will the system have, e.g. time and

<!-- image -->

## A Homeowner's Guide To Heat Pump Systems

- temperature regulation, zoned heating, weather and load compensation?
- 10. Will the programmer be user-friendly and easy to re-programme, should my schedule change in the future?
- 3. How many years has the contractor been installing heat pump systems? How many systems have they installed? Are any available for viewing locally?
- 11. Will the supplier provide instruction and demonstration on how the installed controls work?
- 12. Do all system components meet manufacturer's specifications?

## SIZING AND DESIGN

- 1. Does the heat pump system need backup for space heating or water heating even in colder outdoor conditions? Grant funded systems must be designed to meet 100% of the dwelling space heating demand and at least 80% of the hot water demand. Hot water requires a higher temperature than space heating so may require some backup heating to reach adequate temperatures.
- 2. Is the system sized correctly? Will it meet demand and has the system designer allowed for fabric upgrade recommendations from the Technical Advisor, where applicable, to ensure the system is not oversized?
- 3. Is the heat source system (e.g. ground loop or external fan) sized and designed to ensure best performance by the heat pump system?
- 4. Is the heat pump system design according to manufacturer's specifications?
- 5. Are there any specific requirements regarding electrical connection, e.g. 3-phase or night rate connection, distribution board or wiring upgrades? What are the resulting cost implications, and who is carrying out this work? Are they qualified to do so?
- 6. How much space is required for the heat pump system inside and outside?
- 7. Are there landscaping or planning restrictions, particularly in the case of the ground/water source heat pump? For example, is there space for the heat collector or is there a need to remove trees/roots which could damage the collector over time?
- 8. Has the contractor contacted the EPA to ensure relevant requirements are met if a water source or vertical ground source heat pump system is being proposed?

## INSTALLING AND COMMISSIONING

- 1. Does the contractor offer system design, delivery, installation, commissioning and after sales service?
- 2. Does the contractor meet SEAI's competence requirements for Better Energy Homes registered Heat Pump contractors and are they registered as such? Registration is mandatory for the grant to be obtained.
- 4. Have they been trained by the manufacturer to install this heat pump system?
- 5. Is the contractor a member of any relevant trade associations or professional organisations?
- 6. Will any of the installation be sub-contracted and who is ultimately responsible for the work?
- 7. How long does installation take?
- 8. Is there provision for appropriate access to the heat pump, manifolds etc. for maintenance purposes?
- 9. What is the commissioning procedure and who signs off on the heat pump installation?
- 10. Who is responsible for making good any disruption to the inside and outside of the dwelling and the grounds of the dwelling?
- 11. Is there a site plan and plans for piping and wiring?
- 12. Is there a contract detailing the above information along with a cost quotation?

## OPERATION AND MAINTENANCE

- 1. Can you ensure that the homeowner will be provided with all required performance data and documentation, so the grant can be claimed successfully? This documentation must also meet BER requirements, so the post-works BER can reflect the performance of the heat pump system?
- 2. Are operation/user and maintenance manuals all provided to the homeowner?
- 3. How does the control system work, and will the homeowner be shown how to operate the system to achieve consistent optimum system performance?
- 4. Are there spare parts available for this system in case they are needed?
- 5. What are typical operating costs in a dwelling such as this for space and water heating?

## INSTALLATION COSTS AND PAYMENT

- 1. What are the parts and labour costs for installation including VAT?
- 2. Does the quotation cover all costs associated with space and water heating system design, installation and equipment costs? (e.g. heat pump, collector, heat distribution, heat storage, hot water system and controls)
- 3. Is there any additional cost to the above quoted figures to complete the installation?
- 4. What are the financing options and payment terms?

<!-- image -->

## A Homeowner's Guide To Heat Pump Systems

## AFTER-SALES SERVICES

- 1. What is the guarantee on parts and labour?
- 2. How is the system maintained professionally and how often? How much does maintenance cost?
- 3. Is an annual service contract available from the supplier/ contractor?

your best interest to make sure you are satisfied that all your questions are answered. If an answer seems too complicated, then ask for a simpler explanation. If someone is selling you a new heat pump they will be happy to provide an explanation to your satisfaction.

- 4. What happens if an emergency service is required?

## I NEED A HEAT PUMP, WHAT DO I DO NEXT?

- 1. You can get more information on the Home Energy Upgrade grant programmes in one of three ways:
- •  Request more information by calling: 01 8082100
- •  Email: info@seai.ie
- •  Visit: www.seai.ie/grants/home-energy-grants
- 2. If your dwelling is built prior to 2007, you must contact engage an independent SEAI registered Technical Advisor as listed here: www.seai.ie/resources/find-a-registeredprofessional/SEAI-Registered-Technical-Advisors.pdf
- 3. If your dwelling is built from 2007 onwards, you must complete a Self-Declaration form. More information regarding the Self-Declaration form process can be found here: https://www.seai.ie/grants/home-energy-grants/heatpump-systems/
- 4. Don't forget to follow the Technical Advisor's recommendations to upgrade the fabric to the required level to qualify for the heat pump grant
- 5. Fabric upgrades (i.e. roof and wall insulation) recommended on the Technical Assessment by the Technical Advisor must be completed on dwellings built before 2007 prior to heat pump installation. Fabric upgrades recommended on a dwelling built from 2007 onwards, where a Homeowner has elected to carry out a Technical Assessment, are not mandatory to complete prior to heat pump installation. Multiple upgrade measures may be included in a single grant application
- 6. Once you are grant approved for the Heat Pump, contact a registered contractor for heat pumps from the SEAI registered contractor list at:

https://hes.seai.ie/GrantProcess/ContractorSearch.aspx

- 7. You should contact a number of registered contractors to ensure you receive the best quality available, at a competitive price.
- 8. Once you have selected an SEAI registered heat pump contractor, follow the steps to complete the Individual Energy Upgrade grants online application form:

www.seai.ie/grants/home-energy-grants/individual-grants/

apply-now

9. The next step is to have the works carried out. It is in

## NOTES:

- · To qualify for a grant you must meet the following criteria:
- · If your home is built prior to 2007 or where you have elected to undertake a Technical Assessment, a Technical Assessment must be completed by an SEAI registered Technical Advisor
- · If your home is built from 2007 onwards, you must complete a Technical Assessment or Self-Declaration form
- · The Technical Assessment or Self-Declaration form, where applicable, must be uploaded through the Online Grant Application Wizard
- · Fabric upgrades (i.e. roof and wall insulation) recommended on the Technical Advisor must be completed on dwellings built before 2007 prior to heat pump installation. Fabric upgrades recommended on a dwelling built from 2007 onwards, where a Homeowner has elected to carry out a Technical Assessment, are not mandatory to complete prior to a heat pump installation
- · The heat pump works must be undertaken by an SEAI registered Contractor in accordance with the technical requirements set out in SEAI's Domestic Technical Standards and Specifications, the Better Energy Homes Contractor's Code of Practice and Quality Assurance &amp; Discipline Procedures (QADP).
- · For more information visit: www.seai.ie/grants/supports-for-contractors

The applicant shall have a formal contract in place with each of their chosen registered Contractors before works commence. The contract should cover compliance of the works with the Individual Energy Upgrades grant requirements.

•

•

The contract of works agreed is between the Homeowner and the Contractor only. SEAI accepts no liability or responsibility   for any breach of contract between the Homeowner and the Contractor.

· For the full list of Terms &amp; Conditions please refer to the Homeowner Application Guide, available at: www.seai.ie/grants/home-energy-grants/how-to-apply