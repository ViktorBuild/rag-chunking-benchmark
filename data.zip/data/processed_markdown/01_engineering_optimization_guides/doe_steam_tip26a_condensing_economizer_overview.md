---
document_id: doe_steam_tip_26a
title: "Steam Tip Sheet #26A: Consider Installing a Condensing Economizer"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2007
original_file: "doe_steam_tip26a_condensing_economizer_overview.pdf"
tables_detected: 8
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

Energy Tips: STEAM

## Consider Installing a Condensing Economizer

The key to a successful waste heat recovery project is optimizing the use of the recovered energy. By installing a condensing economizer, companies can improve overall heat recovery and steam system efficiency by up to 10%. Many boiler applications can benefit from this additional heat recovery, such as district heating systems, wallboard production facilities, greenhouses, food processing plants, pulp and paper mills, textile plants, and hospitals. Condensing economizers require site-specific engineering and design, and a thorough understanding of the effect they will have on the existing steam system and water chemistry.

Use this tip sheet and its companion, Considerations When Selecting a Condensing Economizer , to learn about these efficiency improvements.

A conventional feedwater economizer reduces steam boiler fuel requirements by transferring heat from the flue gas to the boiler feedwater. For natural gas-fired boilers, the lowest temperature to which flue gas can be cooled is about 250°F to prevent condensation and possible stack or stack liner corrosion.

The condensing economizer improves waste heat recovery by cooling the flue gas below its dew point, which is about 135°F for products of combustion of natural gas. The economizer reclaims both sensible heat from the flue gas and latent heat by condensing flue gas water vapor (see Table 1). All hydrocarbon fuels release significant quantities of water vapor as a combustion byproduct. The equation below shows the reactants and combustion products for the stoichiometric combustion in air of methane (CH 4 ), the primary constituent of natural gas. When one molecule of methane is burned, it produces two molecules of water vapor. When moles are converted to pound/mole, we find that every pound of methane fuel combusted produces 2.25 lb. of water vapor, which is about 12% of the total exhaust by weight.

<!-- formula-not-decoded -->

Table 1. Boiler Efficiency of Condensing Economizers

| System                              | Combustion Efficiency @4% Excess O 2 (%)   | Stack Gas Temperature °F   |
|-------------------------------------|--------------------------------------------|----------------------------|
| Boiler                              | 78 to 83%                                  | 350 to 550˚                |
| - with Feedwater (FW) Economizer    | 84 to 86%                                  | 250 to 300˚                |
| - with FW and Condensing Economizer | 92 to 95%                                  | 75 to 150˚                 |

Steam Tip Sheet #26A

## Suggested Actions

- ■ ■ Determine your boiler capacity, average steam production, combustion efficiency, stack gas temperature, annual hours of operation, and annual fuel consumption.
- ■ ■ Identify in-plant uses for heated water, such as boiler makeup water heating, preheating, or domestic hot water or process water heating requirements.
- ■ ■ Determine the thermal requirements that can be met through installation of a condensing economizer. Determine annual fuel energy and cost savings.
- ■ ■ Obtain an installed cost quotation for and determine the cost-effectiveness of a condensing economizer. Ensure that system changes are evaluated and modifications are included in the design (e.g., mist eliminator, additional water treatment, heat exchangers). Simple paybacks for condensing economizer projects are often less than two years.

Since the higher heating value of methane is 23,861 Btu per pound (Btu/ lb), 41.9 lb of methane is required to provide one million Btu (MMBtu) of energy, resulting in 94.3 lb of high temperature water vapor. The latent heat of vaporization of water under atmospheric pressure is 970.3 Btu/lb. When one MMBtu of methane is combusted, 91,495 Btu of water vapor heat of evaporation (94.3 lb x 970.3 Btu/lb) is released up the boiler stack. This latent heat represents approximately 9% of the initial fuel energy content. The bulk of this latent heat can be recovered by cooling the exhaust gas below its dew point using a direct contact or indirect condensing economizer. It is possible to heat water to about 200°F with an indirect economizer or 140°F with a direct contact economizer.

## Energy Savings Potential

The available heat in a boiler's exhaust gases is dependent upon the hydrogen content of the fuel, the fuel firing rate, the percent of excess oxygen in the flue gases, and the stack gas temperature.

Consider a natural gas-fired boiler that produces 100,000 lb/hr of 100-psig saturated steam. At 83% efficiency, the boiler firing rate is about 116 MMBtu/ hr. At its full firing rate, the boiler consumes over 4,860 lb of natural gas each hour while exhausting 10,938 lb of high temperature water vapor each hour. The water vapor in the flue gas contains over 10.6 MMBtu/hr of latent heat. As shown in Table 2, the total heat actually available for recovery is strongly dependent upon the stack gas temperature at the condensing economizer outlet.

Table 2. Exhaust Gas Energy Available from a 100,000 lb/hr Natural Gas-Fired Steam Boiler (MMBtu/hr)

| Flue Gas Temperature Leaving Condensing Economizer   |   75˚F |   100˚F |   125˚F |   150˚F |
|------------------------------------------------------|--------|---------|---------|---------|
| Sensible Heat                                        |   6.46 |    5.75 |    5.03 |    4.31 |
| Latent Heat                                          |   9.51 |    7    |    2.01 |    0    |
| Total Available                                      |  15.97 |   12.75 |    7.04 |    4.31 |

Note: Example in Table 2 assumes an 83% fuel-to-steam efficiency, 4% excess oxygen, a stack temperature of 300°F after feedwater economizer, a blowdown rate of 4%, and a boiler feedwater temperature of 260°F. Makeup water temperature is 55°F.

Assume that an indirect contact condensing economizer is retrofitted onto this 100,000 lb/hr steam boiler to heat 50% of the makeup water from 55°F to 200°F and flue gases are cooled to 100°F.  At these conditions, 12.75 MMBtu/hr of total energy is available in the exhaust, of which 7.55 MMBtu/ hr will be recovered to heat makeup water in the condensing economizer. More energy could be recovered if additional heat sinks are available. Given 8,000 hours per year of boiler operation, and a fuel cost of $8.00/ MMBtu, the annual energy recovered is valued at:

Annual Savings = 7.55 MMBtu/hr x 8,000 hrs/ yr x $8.00/MMBtu/0.83 = $582,170

## Examples

## District Heating System

A boiler plant that provides up to 500,000 lb/hr of steam for a district heating system installed a direct contact condensing economizer. This economizer saves up to 20 MMBtu/hr, depending on the boiler load. Since condensate is not returned from the district heating system, the recovered energy is used to preheat plant makeup water from 45°- 60°F up to 132°F, resulting in a steam system energy efficiency improvement of 6.3%.

## Food Processing Plant

A food processing plant installed an indirect contact condensing economizer on a 20,000-lb/hr boiler. The condensing economizer reduced the flue gas temperature from 300°F to 120°F, while capturing 2.0 MMBtu/hr of sensible and latent heat. Energy recovered by the condensing economizer heated makeup water, reducing deaerator steam requirements from 5,000 lb/hr to 1,500 lb/hr.

For additional information on economizers, refer to the Steam refer to Steam Tip Sheet #3 Use Feedwater Economizers for Waste Heat Recovery . For additional information on industrial steam system   efficiency, refer to Improving Steam System Performance: A Sourcebook for Industry .

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3393  •  January 2012