---
document_id: seai_home_heating_controls
title: "Homeowners Guide to Heating Controls"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "SEAI"
year: 2021
original_file: "seai_homeowners_guide_heating_controls.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## A Homeowner's Guide To Heating Controls

## HOW YOU CAN BENEFIT FROM INSTALLING HEATING CONTROLS:

## DO I NEED HEATING CONTROLS?

- ·  Reduce your heating bills by improving your energy efficiency.
- •  Increase your home comfort levels.
- ·  Support the climate by reducing your own greenhouse gas emissions.

Do you know that you are entitled to a grant through the SEAI  Home  Energy  Grants  programme  to  help  improve your home heating system?

Installing Heating Controls to your home heating system will typically reduce your energy usage by up to 20%.

Home  heating  systems  without  heating  controls  can  be wasteful of energy and costly to run because there is little to no control of the amount of heat being used to heat your home and your hot water. Adding modern heating controls can help you  to  accurately  match  your  space  heating  and  hot  water schedules to the working and living patterns in your home, so when heat and hot water are required, it is there; and when it is not required, it is turned off.

As a minimum, your heating systems should be split into two independently controlled zones. They are your 'Space Heating Zone' and your 'Domestic Hot Water Zone' . This allows you to heat your  domestic hot water without being forced to turn on your space heating. It will also allow you to use your boiler to heat your hot water in the summer time, without using the immersion. Additional zones can also be put in place in large homes  to  split  upstairs  and  downstairs  or  living  areas  and bedrooms.

There  is  a  grant  available  through  the  SEAI  Home  Energy Grants programme to help you improve your home heating system through the installation of  heating controls.

You can do a quick check on your heating control requirements by answering the simple questions below. If you answer NO to some or all of the below questions, it would be beneficial for you to install some heating controls:

- 1. Can you heat your domestic hot water without switching on your radiators or an electric immersion heater?
- 2. Can  you  turn  on  your  heating  without  heating  your domestic hot water?
- 3. Can you easily adjust the heat output from radiators in the rooms you use most often?
- 4. Do you have temperature control on your boiler?
- 5. Have you time control on your boiler that you can set for different days of the week?
- 6. Have  you  a  separate  temperature  control  for  your  hot water cylinder?
- 7. Have  you  a  separate  time  control  on  your  hot  water cylinder?

Choosing  and  installing  heating  controls  should  not  prove to be  a difficult process. However,  there  are  important decisions to make and a few rules to apply to ensure that your heating  controls  will  be  to  your  satisfaction  and  meet  your requirements.  It is vital to look for high quality when choosing your heating controls. To achieve this, products should only be chosen that comply with the appropriate Irish Standards (IS), British Standards (BS) or European Standards (EN).

For a list of registered contractors for this grant programme please visit:

## https://hes.seai.ie/GrantProcess/ContractorSearch.aspx

We recommend that you shop around and view other installed systems before making your final decision in order to get the best product and the best value for money. It is a good idea to discuss the heating controls on offer with any friends, neighbours or workmates who may already have them installed, to give you a better insight of how they are operated, how often you might need to change settings and  also  the  advantages,  improvements  and  any  problems people have experienced when they have had them installed.

<!-- image -->

## A Homeowner's Guide To Heating Controls

## HEATING CONTROLS FACTS AND TIPS

## QUESTIONS  TO  ASK  YOUR  SUPPLIER  AND INSTALLER

## THERMOSTATIC RADIATOR VALVES (TRV'S)

A  TRV  is  a  thermostat  that  regulates  the  amount  of  heat going into a radiator according to the temperature in the room. You can set a specific temperature level for a room that you are comfortable with, and then as the room heats up to that comfortable  temperature,  heat  flow  is  reduced  into  the radiator, stopping when it reaches your comfortable set level. TRV's are particularly useful in rooms where the temperature requirement  is  different  to  that  required  in  the  main  living area bedrooms, or rooms where there are other heat sources such as in kitchens.

## 7-DAY PROGRAMMABLE TIMER

A  7-Day  programmable  timer  will  allow  you  to  set  your heating  system  to  match  your  occupancy  patterns  on  a daily and weekly basis. The separation of space heating and domestic  hot  water  controls  into  zones  will  also  allow  you to  set  each  zone  to  operate  for  required  periods  only.  For example: you can set your boiler to switch on automatically before  you  wake  in  the  morning  to  heat  water  for  showers without turning on the central heating.

## BOILER INTERLOCK

Boiler interlock is a method of interconnecting your heating system controls with your boiler to ensure that the boiler only operates when required.

## TIME AND TEMPERATURE CONTROL OF ELECTRIC IMMERSION HEATER (HOT WATER CYLINDER HEATER)

Time and temperature controls installed on immersion heaters allow householders to pre-set the time period required  for  water  heating  and  the  temperature  to  which water is heated. This means  that water need not be heated for longer than required or to higher temperatures than required.  Temperatures for hot water should  be  set to around 60°C. To heat water above this temperature, only to add  cold  water  to  it  afterwards,  is  a  waste  of  your  energy. Please note that if you have a solar water heating system in place, this temperature may need to be set higher. SEAI also recommend that lagging jackets are fitted to old, uninsulated copper hot water cylinders to ensure that minimum  energy  is  lost.  This  should  not  be  necessary  for factory-insulated cylinders, which should be the norm for new cylinders.

SEAI  has  compiled  a  list  of  questions  you  should  ask  your suppliers and contractors prior to making a purchase. It is in your best interest to make sure you are satisfied that all your questions are answered. If an answer seems too complicated, then ask for a simpler explanation. If someone is selling you new controls, they will be happy to provide an explanation to your satisfaction.

## EQUIPMENT

- 1. Is  the  heating  system  in  my  dwelling  currently  zoned/ divided  according  to  Industry  Best  Practice?  If  not,  will installation of these controls achieve this?
- 2. How  should  I  divide  my  house  into  zones?  What  is Industry Best Practice?
- 3. Do I already have some of these products installed in my home? If so, do they need replacing?
- 4. Are all of the proposed heating controls suitable for my particular requirements?
- 5. What Irish Standard (IS), British Standard (BS) or European Standard (EN) do the controls comply with?
- 6. Will the product improve the Building Energy Rating (BER) of my home?
- 7. Will the  system  allow  me  to  set  different  time  and temperature schedules for different days of the week?
- 8. How often  should  I  change  settings  on  the  controls  to make my house more efficient? Will the products satisfy all rules and requirements for receipt of a grant under the Home Energy Grants programme?
- 9. Do the products have the required CE or Kitemark?
- 10.  Will the programmer  be user-friendly and easy to reprogramme, should my schedule change in the future?

## INSTALLATION AND COMMISSIONING

- 1. Is the contractor on SEAI's list of Registered Contractors? (Remember, if the contractor is not listed you will  not  receive  a  grant  under  the  Home  Energy  Grants programme)
- 2. To what standards will the products be installed?
- 3. Does the contractor offer delivery, installation, commissioning and after sales service?
- 4. What training or accreditation has the contractor received?
- 5. To which trade associations does the contractor belong?
- 6. How many similar systems has the contractor installed? Are local references available?

<!-- image -->

## A Homeowner's Guide To Heating Controls

- 7. Will any of the installation be sub-contracted? How much?
- 8. Who is ultimately responsible for what segments of work?

## I  NEED  HEATING  CONTROLS.  WHAT  DO  I  DO NEXT?

- 9. Does  the  contractor  have  the  plumbing  and  electrical skills required for the installation?
- 10.  How long will the installation take?
- 11.  What  are  the  procedures  and  tests  carried  out  when commissioning the system?
- 12.  Who is responsible for repairing any disruption to walls/ ceilings  etc.,  necessary  during  the  installation  of  the system?
- 13.  What additional pieces of work need to be done to my home to prepare for the installation?
- 14.  Will  the  contractor  provide  all  of  these  services,  and  at what cost?
- 15.  What  work  will  need  to  be  done  to  get  my  home back  into  its'  original  condition  following  installation?

## OPERATION AND MAINTENANCE

- 1. Is  full  documentation,  including  any  operation  manuals and warranties provided in English?
- 2. Will the supplier provide instruction and demonstration on how the installed controls work?
- 3. Will I need to carry out any housekeeping or maintenance tasks once the controls are installed? If so, how often do I need to carry out these tasks?
- 4. Does the supplier have spare parts available if required?
- 5. Will I be charged for subsequent call outs if required?

## COSTS AND PAYMENT

- 1. Does  the  detailed  quotation  cover  all  costs  associated with the works?
- 2. What range of energy savings are these control measures likely to achieve? Approximately how much will this installation save me on my heating bill?
- 3. What are the financing options or payment terms?
- 4. At what stage will I get my SEAI grant payment?
- 5. Are there any additional costs that I should be aware of?

## AFTER-SALES SERVICE

- 1. What after sales service does the contractor provide?
- 2. What  is  the  guarantee  on  labour  and  parts  for  each component of the system?
- 3. Is any ongoing professional maintenance required (by the Contractor or similar)?
- 4. For  how  long  does  the  supplier  provide  emergency service work if required?
- 1. You can get more information on the Home Energy Grants programme in one of three ways:
- • Request more information by ringing 01 808 2100.
- • Contact the programme team directly at: info@seai.ie.
- • Visit: www.seai.ie/grants/home-grants
- 2. Contact a registered contractor for heating controls from the SEAI Registered Contractor list at:

https://hes.seai.ie/GrantProcess/ContractorSearch.aspx.

- 3. It is recommended you contact a number of registered  contractors  to  ensure  you  receive  the  best quality available, at a competitive price.
- 4. Once you have selected a suitable contractor, follow  the  steps  to  complete  the  Home  Energy  Grants programme online application form:
- www.seai.ie/grantshome-grants/how-to-apply
- 5. The  next  step  is  to  have  the  works  carried  out.  It  is  in your best interest to make sure you are satisfied that all your  questions  are  answered.  If  an  answer  seems  too complicated, then ask for a simpler explanation. If someone is selling you a new boiler they will be happy to provide an explanation to your satisfaction.

## NOTES:

- · To  qualify  for  a  grant,  all  works  must  be  undertaken  by  an SEAI  registered  Contractor  in  accordance  with  the  technical requirements set out in SEAI's Domestic Technical Standards and Specifications  and  Better  Energy  Homes  Contractor's  Code  of Practice and Quality Assurance &amp; Discipline Procedures (QADP). For more information visit:
- www.seai.ie/energy-in-business/contractor-supports
- · The applicant shall have a formal contract in place with each of their chosen registered Contractors before works commence.
- · The contract of works agreed is between the Homeowner and the  Contractor  only.  SEAI  accepts  no  liability  or  responsibility for  any  breach  of  contract  between  the  Homeowner  and  the Contractor.
- · For  the  full  list  of  Terms  &amp;  Conditions  please  refer  to  the Home Energy Grants Programme Application Guide, available at:

www.seai.ie/grants/home-grants/how-to-apply