---
document_id: doe_ca_tip_6
title: "Compressed Air Tip Sheet #6: Compressed Air System Controls"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2004
original_file: "doe_compressed_air_tip06_system_controls.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Tips - Compressed Air

Compressed Air Tip Sheet #6 • August 2004

## Suggested Actions

- ·  Establish a regular, well-organized maintenance program in accordance with manufacturer specifications.
- ·  Appoint someone in the plant to have ultimate responsibility for ensuring that all compressed air system maintenance needs are performed properly, on schedule, and are adequately documented.

## References

From Compressed Air Challenge ® (CAC):

The Compressed Air System Best Practices Manual, Guidelines for Selecting a Compressed Air System Service Provider

From DOE's Industrial Technologies Program and CAC:

Improving Compressed Air System Performance: A Sourcebook for Industry

## Training

- · Fundamentals of Compressed Air Systems - 1 day
- · Advanced Management of Compressed Air Systems - 2 days

Offered by the Compressed Air Challenge; for the latest course schedule and locations see www.compressedairchallenge.org

<!-- image -->

Industrial Technologies Program

## Preventive Maintenance Strategies for Compressed Air System

A brewery neglected to perform routine maintenance on its compressed air system for years. As a result, two of its centrifugal compressors, whose impellers had been rubbing against their shrouds, were unable to deliver the volume of air they were rated for and one of those units had burned up several motors during its lifetime. In addition, plant personnel did not inspect the system's condensate traps regularly. These traps were of a type that clogged easily, which prevented the removal of moisture and affected product quality. Also, the condensate drains were set to operate under the highest humidity conditions, so they would actuate frequently, which increased the system's air demand. As a result, energy use was excessively high, equipment repair and replacement costs were incurred unnecessarily, and product quality suffered. All of this could have been avoided through regular maintenance.

Like all electro-mechanical equipment, industrial compressed air systems require periodic maintenance to operate at peak efficiency and minimize unscheduled downtime. Inadequate maintenance can increase energy consumption via lower compression efficiency, air leakage, or pressure variability. It also can lead to high operating temperatures, poor moisture control, excessive contamination, and unsafe working environments. Most issues are minor and can be corrected with simple adjustments, cleaning, part replacement, or elimination of adverse conditions. Compressed air system maintenance is similar to that performed on cars; filters and fluids are replaced, cooling water is inspected, belts are adjusted, and leaks are identified and repaired.

A good example of excess costs from inadequate maintenance can be seen with pipeline filter elements. Dirty filters increase pressure drop, which decreases the efficiency of a compressor. For example, a compressed air system that is served by a 100-horsepower (hp) compressor operating continuously at a cost of $0.08/kilowatt-hour (kWh) has annual energy costs of $63,232. With a dirty coalescing filter (not changed at regular intervals), the pressure drop across the filter could increase to as much as 6 pounds per square inch (psi), vs. 2 psi when clean, resulting in a need for increased system pressure. The pressure drop of 4 psi above the normal drop of 2 psi accounts for 2% of the system's annual compressed air energy costs, or $1,265 per year. A pressure differential gauge is recommended to monitor the condition of compressor inlet filters. A rule of thumb is that a pressure drop of 2 psi will reduce the capacity by 1%.

For additional information on industrial energy efficiency measures, contact the EERE Information Center at 1-877-337-3463 or visit the BestPractices Web site at www.eere.energy.gov/industry/bestpractices.

All components in a compressed air system should be maintained in accordance with the manufacturers' specifications. Manufacturers provide inspection, maintenance, and service schedules that should be strictly followed. Because the manufacturer-specified intervals are intended primarily to protect the equipment rather than optimize system efficiency, in many cases, it is advisable to perform maintenance on compressed air equipment more frequently.

<!-- image -->

One way to tell if a compressed air system is well maintained and operating effi  ciently is to periodically baseline its power consumption, pressure, airfl  ow, and temperature. If power use for a given pressure and fl  ow rate increases, the system's effi  ciency is declining. Baselining the system will also indicate whether the compressor is operating at full capacity, and if that capacity is decreasing over time. On new systems, specifi  cations should be recorded when the system is fi  rst installed and is operating properly.

## Types of Maintenance

Maintaining an air compressor system requires caring for the equipment, paying attention to changes and trends, and responding promptly to maintain operating reliability and effi  ciency. To assure the maximum performance and service life of your compressor, a routine maintenance schedule should be developed. Time frames may need to be shortened in harsher environments. Proper maintenance requires daily, weekly, monthly, quarterly, semi-annual, and annual procedures. Please refer to the Compressed Air System Best Practices Manual for the types of procedures that are relevant to the compressors and components in your system.

Excellent maintenance is the key to good reliability of a compressed air system; reduced energy costs are an important and measurable by-product. The benefi  ts of good maintenance far outweigh the costs and efforts involved. Good maintenance can save time, reduce operating costs, and improve plant manufacturing effi  ciency and product quality.

## About DOE's Industrial Technologies Program

The Industrial Technologies Program, through partnerships with industry, government, and non-governmental organizations, develops and delivers advanced energy effi  ciency, renewable energy, and pollution prevention technologies for industrial applications. The Industrial Technologies Program is part of the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy.

The Industrial Technologies Program encourages industry-wide efforts to boost resource productivity through a strategy called Industries of the Future (IOF). IOF focuses on the following eight energy and resource intensive industries:

- • Aluminum
- • Forest Products
- • Metal Casting
- • Petroleum
- • Chemicals
- • Glass
- • Mining
- • Steel

The Industrial Technologies Program and its BestPractices activities offer a wide variety of resources to industrial partners that cover motor, steam, compressed air, and process heating systems. For example, BestPractices software can help you decide whether to replace or rewind motors (MotorMaster+), assess the effi  ciency of pumping systems (PSAT), compressed air systems (AirMaster+), steam systems (Steam Scoping Tool), or determine optimal insulation thickness for pipes and pressure vessels (3E Plus). Training is available to help you or your staff learn how to use these software programs and learn more about industrial systems. Workshops are held around the country on topics such as 'Capturing the Value of Steam Effi  ciency,' 'Fundamentals and Advanced Management of Compressed Air Systems,' and 'Motor System Management.' Available technical publications range from case studies and tip sheets to sourcebooks and market assessments. The Energy Matters newsletter, for example, provides timely articles and information on comprehensive energy systems for industry. You can access these resources and more by visiting the BestPractices Web site at www.eere.energy.gov/industry/bestpractices or by contacting the EERE Information Center at 877-337-3463 or via the Web at www.eere.energy.gov/informationcenter/.

BestPractices is part of the Industrial Technologies Program Industries of the Future strategy, which helps the country's most energy-intensive industries improve their competitiveness. BestPractices brings together emerging technologies and best energy-management practices to help companies begin improving energy efficiency, environmental performance, and productivity right now.

BestPractices emphasizes plant systems, where significant efficiency improvements and savings can be achieved. Industry gains easy access to near-term and long-term solutions for improving the performance of motor, steam, compressed air, and process heating systems. In addition, the Industrial Assessment Centers provide comprehensive industrial energy evaluations to small- and medium-size manufacturers.

## FOR ADDITIONAL INFORMATION, PLEASE CONTACT:

EERE Information Center 1-877-EERE-INF (1-877-337-3463) www.eere.energy.gov

Industrial Technologies Program Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 www.eere.energy.gov/industry

## A STRONG ENERGY PORTFOLIO FOR A STRONG AMERICA

Energy effi  ciency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Offi  ce of Energy Effi  ciency and Renewable Energy invests in a diverse portfolio of energy technologies.

DOE/GO-102004-1929 August 2004 Compressed Air Tip Sheet #6