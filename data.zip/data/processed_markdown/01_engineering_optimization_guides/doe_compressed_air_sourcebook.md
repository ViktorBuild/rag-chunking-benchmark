---
document_id: doe_compressed_air_sourcebook
title: "Improving Compressed Air System Performance: A Sourcebook for Industry"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2003
original_file: "doe_compressed_air_sourcebook.pdf"
tables_detected: 37
converted_with: "Docling v2.32 (TableFormer)"
---

One in a series of industrial energy efficiency sourcebooks

<!-- image -->

## Improving Compressed Air System Performance

## a sourcebook for industry

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Acknowledgments

Improving Compressed Air System Performance: A Sourcebook for Industry is a cooperative effort of the U.S. Department of Energy's Office of Energy Efficiency and Renewable Energy (EERE) BestPractices and the Compressed Air Challenge ® . EERE originally undertook this project as part of a series of sourcebook publications on industrial systems. Other topics in this series include: pump systems; fan systems; motors; process heating; and steam systems. As work on the first edition progressed, the Compressed Air Challenge ® was formed, bringing together the extraordinary combined talents of compressed air system auditors, trade associations, equipment manufacturers and distributors, utilities, and government agencies in a collaborative effort to improve the performance of industrial compressed air systems. The two programs joined forces in preparing this second edition. For more information about EERE and the Compressed Air Challenge ® , see Section 3: Where to Find Help .

The Compressed Air Challenge ® , EERE's BestPractice Program, Lawrence Berkeley National Laboratory, and Resource Dynamics Corporation wish to thank the staff at the many organizations who so generously assisted in the collection of data for this sourcebook. The contributions, review, and input of the following participants in the Compressed Air Challenge ® are appreciated:

Chris Beals, Air Science Engineering, Inc. Joseph Ghislain, Ford Motor Land Services Corporation Henry Kemp, Strategic Air Concepts David McCulloch, The Compressed Air and Gas Institute Wayne Perry, Kaeser Compressors, Inc. David Prator, Atlas Copco William Scales, Scales Air Compressor Corporation Gary Shafer, Ingersoll-Rand Company Dean Smith, Air Science Engineering, Inc. Tom Taranto, ConservAIR, Inc.

H.P. Van Ormer, Air Power USA

We would also like to thank the following member companies of the Compressed Air and Gas Institute for their input:

Atlas Copco Compressors Inc. Campbell Hausfeld domnick hunter inc. Gardner Denver Machinery Inc. Hankison International Ingersoll-Rand Company Pneumatech/ConservAIR Inc. Quincy Compressor Division, ENPRO Sullair Corporation Zeks Air Drier Corporation

Finally, a special thanks to David McCulloch, William Scales, and Gary Shafer for their extraordinary assistance.

Prepared for:

Compressed Air Challenge ® and the United States Department of Energy

Prepared by:

Lawrence Berkeley National Laboratory Washington, DC

Resource Dynamics Corporation Vienna, VA

## Contents

| Acknowledgements                                                      | i                                                                     |
|-----------------------------------------------------------------------|-----------------------------------------------------------------------|
| Table of Contents                                                     | ii                                                                    |
| List of Figures, Tables, and Appendices Figures                       | iii                                                                   |
| Quick Start Guide                                                     | 1                                                                     |
| Section 1: Introduction to Industrial Compressed Air Systems          | 3                                                                     |
| Components of An Industrial Compressed Air System                     | 3                                                                     |
| Uses of Compressed Air                                                | Uses of Compressed Air                                                |
| Section 2: The Performance Opportunity Roadmap                        | 17                                                                    |
| 1-Analyzing Compressed Air Needs                                      | 19                                                                    |
| 2-Potentially Inappropriate Uses of Compressed Air                    | 23                                                                    |
| 4-Pressure Drop and Controlling System Pressure                       | 4-Pressure Drop and Controlling System Pressure                       |
| 5-Compressed Air System Controls                                      | 5-Compressed Air System Controls                                      |
| 6-Compressed Air Storage                                              | 41                                                                    |
| 7-Proven Opportunities at the Component Level                         | 47                                                                    |
|                                                                       | 53                                                                    |
| 9-Heat Recovery and Compressed Air Systems                            | 59                                                                    |
| 10-Baselining Compressed Air Systems                                  | 61                                                                    |
| 11-Determining Your Compressed Air System Analysis Needs              | 11-Determining Your Compressed Air System Analysis Needs              |
| 12-Compressed Air System Economics and Selling Projects to Management | 12-Compressed Air System Economics and Selling Projects to Management |
| Section 3: Where To Find Help                                         | Section 3: Where To Find Help                                         |
|                                                                       | 75                                                                    |
| BestPractices                                                         | 75                                                                    |
|                                                                       | 80                                                                    |
| Directory of Contacts                                                 | Directory of Contacts                                                 |
| Resources and Tools                                                   | 81                                                                    |
|                                                                       | 95                                                                    |
| Appendix A: Glossary of Basic Compressed                              | Appendix A: Glossary of Basic Compressed                              |
| Appendix B: Packaged Compressor                                       | 101                                                                   |
| Appendix C: CAGI's Compressor                                         | 103                                                                   |
| Appendix D: The Compressed Air System Appendix E: Guidelines for      | 109                                                                   |
| Selecting a Compressed Air System Provider                            | 117                                                                   |

## List of Figures

| Figure 1.1                                          | Components of a Typical Compressed Air System                                                         |   4 |
|-----------------------------------------------------|-------------------------------------------------------------------------------------------------------|-----|
| Figure 1.2                                          | Compressor Family Tree                                                                                |   5 |
| Figure 2.1                                          | Performance Opportunities                                                                             |  18 |
| Figure 2.2                                          | Compressed Air System Block Diagram                                                                   |  20 |
| Figure 2.3                                          | Pressure Profile at a Single Point in Time                                                            |  21 |
| Figure 2.4                                          | Pressure Profile over a Defined Time Period                                                           |  22 |
| Figure 2.5                                          | Effect of Receiver Capacity on Lubricant-Injected Rotary Compressor with Load/Unload Capacity Control |  43 |
| Figure 2.6                                          | Lubricant-Injected Rotary Compressor with Inlet Valve Modulation                                      |  43 |
| Figure 2.7                                          | Lubricant-Injected Rotary Screw Compressor Performance with Variable Displacement                     |  44 |
| Figure 2.8                                          | Lubricant-Injected Rotary Screw Compressor Performance with Variable Speed Control                    |  45 |
| Table 1.1                                           | Industrial Sector Uses of Compressed Air                                                              |  15 |
| Table 1.2                                           | Non-Manufacturing Sector Use of Compressed Air                                                        |  16 |
| Compressor Data Sheet-Rotary Screw Compressors      | Compressor Data Sheet-Rotary Screw Compressors                                                        | 104 |
| Dryer Data Sheet-Refrigerant Dryers                 | Dryer Data Sheet-Refrigerant Dryers                                                                   | 105 |
| Dryer Data Sheet-Regenerative Dessicant-Type Dryers | Dryer Data Sheet-Regenerative Dessicant-Type Dryers                                                   | 106 |
| Dryer Data Sheet-Membrane-Type Dryers               | Dryer Data Sheet-Membrane-Type Dryers                                                                 | 107 |
| Appendix D-1.1 The Air Compressor Marketplace       | Appendix D-1.1 The Air Compressor Marketplace                                                         | 110 |

## Quick-Start Guide

This sourcebook is designed to provide compressed air system users with a reference that outlines opportunities for system performance improvements. It is not intended to be a comprehensive technical text on improving compressed air systems, but rather a document that makes compressed air system users aware of the performance improvement potential, details some of the significant opportunities, and directs users to additional sources of assistance. The sourcebook is divided into the three main sections outlined below.

## Section 1. Introduction to Industrial Compressed Air Systems

This section is intended for readers who want to gain an understanding of the basics of industrial compressed air systems. The components of an industrial compressed air system are described and applications of compressed air systems in different industries are characterized. Compressed air system users already familiar with compressed air fundamentals may want to skip this section.

## Section 2. Performance Improvement Opportunity Roadmap

This section consists of a series of fact sheets that outline specific opportunities for enhancing the performance of a compressed air system. The fact sheets address system-level opportunities such as using heat recovery and fixing leaks as well as individual component-level opportunities. The following fact sheets are included.

- 1Analyzing Compressed Air Needs
- 2Potentially Inappropriate Uses of Compressed Air
- 3Compressed Air System Leaks
- 4Pressure Drop and Controlling System Pressure
- 5Compressed Air System Controls
- 6Compressed Air Storage
- 7Proven Opportunities at the Component Level
- 8Maintenance of Compressed Air Systems for Peak Performance
- 9Heat Recovery and Compressed Air Systems
- 10Baselining Compressed Air Systems
- 11Compressed Air System Assessments and Audits and Selecting a Service Provider
- 12Compressed Air System Economics and Selling Projects to Management

## Section 3. Where To Find Help

The third section of this sourcebook is a directory of resources, tools, and information that are available to compressed air systems users to help them improve their systems. It includes:

- · A description of EERE's BestPractices, a national effort sponsored by the U.S. Department of Energy aimed at improving the performance of industrial systems
- · A description of the Compressed Air Challenge ® , a national effort involving all compressed air market stakeholders aimed at increasing the demand for high performance compressed air systems, primarily through awareness building, education, and training
- · A directory of association and other organization contacts involved in the compressed air system market
- · A listing and description of compressed air systemrelated resources and tools, including books, brochures, periodicals, software, videos, workshops, and training courses.

## Appendices

The sourcebook also contains five appendices. Appendix A is a glossary defining terms used in the compressed air industry. Appendix B contains information on Packaged Compressor Efficiency Ratings. Appendix C contains Data Sheets outlining a common format and style for reporting compressor and dryer performance. Appendix D presents an overview of the compressed air systems marketplace. Appendix E contains Guidelines for Selecting a Compressed Air System Service Provider , a document that offers guidance for selecting a firm to provide integrated services to improve compressed air system performance.

## The Systems Approach

Improving and maintaining peak compressed air system performance requires not only addressing individual components, but also analyzing both the supply and demand sides of the system and how they interact. This practice is often referred to as taking a 'systems approach' because the focus is shifted away from individual components to total system performance. Applying the systems approach usually involves the following types of interrelated actions:

- · Establishing current conditions and operating parameters, including baselining of inefficiencies
- · Determining present and future process production needs
- · Gathering and analyzing operating data and developing load duty cycles
- · Assessing alternative system designs and improvements
- · Determining the most technically and economically sound options, taking into consideration all of the sub-systems
- · Implementing those options
- · Assessing operations and energy consumption and analyzing economics
- · Continuing to monitor and optimize the system
- · Continuing to operate and maintain the system for peak performance.

## Section 1. Introduction to Industrial Compressed Air Systems

This section of the sourcebook is intended for readers who want to gain an understanding of the basics of industrial compressed air systems. A glossary of basic terminology is included in Appendix A for users unfamiliar with the terms used in this chapter.

bellows, used by blacksmiths to intensify the heat in their furnaces. The first industrial compressors were simple, reciprocating piston-driven machines powered by a water wheel.

Compressed air is used widely throughout industry and is often considered the 'fourth utility' at many facilities. Almost every industrial plant, from a small machine shop to an immense pulp and paper mill, has some type of compressed air system. In many cases, the compressed air system is so vital that the facility cannot operate without it. Plant air compressor systems can vary in size from a small unit of 5 horsepower (hp) to huge systems with more than 50,000 hp.

In many industrial facilities, air compressors use more electricity than any other type of equipment. Inefficiencies in compressed air systems can therefore be significant. Energy savings from system improvements can range from 20 to 50 percent or more of electricity consumption. For many facilities this is equivalent to thousands, or even hundreds of thousands of dollars of potential annual savings, depending on use. A properly managed compressed air system can save energy, reduce maintenance, decrease downtime, increase production throughput, and improve product quality.

Compressed air systems consist of a supply side, which includes compressors and air treatment, and a demand side, which includes distribution and storage systems and end-use equipment. A properly managed supply side will result in clean, dry, stable air being delivered at the appropriate pressure in a dependable, cost-effective manner. A properly managed demand side minimizes wasted air and uses compressed air for appropriate applications. Improving and maintaining peak compressed air system performance requires addressing both the supply and demand sides of the system and how the two interact.

## Components of an Industrial Compressed Air System

A compressor is a machine that is used to increase the pressure of a gas. The earliest compressors were

A modern industrial compressed air system is composed of several major sub-systems and many sub-components. Major sub-systems include the compressor, prime mover, controls, treatment equipment and accessories, and the distribution system. The compressor is the mechanical device that takes in ambient air and increases its pressure. The prime mover powers the compressor. Controls serve to regulate the amount of compressed air being produced. The treatment equipment removes contaminants from the compressed air, and accessories keep the system operating properly. Distribution systems are analogous to wiring in the electrical world-they transport compressed air to where it is needed. Compressed air storage can also serve to improve system performance and efficiency. Figure 1.1 shows a representative industrial compressed air system and its components.

## Compressor Types

Many modern industrial air compressors are sold 'packaged' with the compressor, drive motor, and many of the accessories mounted on a frame for ease of installation. Provision for movement by forklift is common. Larger packages may require the use of an overhead crane. An enclosure may be included for sound attenuation and aesthetics.

As shown in Figure 1.2, there are two basic compressor types: positive-displacement and dynamic. In the positive-displacement type, a given quantity of air or gas is trapped in a compression chamber and the volume which it occupies is mechanically reduced, causing a corresponding rise in pressure prior to discharge. At constant speed, the air flow remains essentially constant with variations in discharge pressure. Dynamic compressors impart velocity energy to continuously flowing air or gas by means of impellers rotating at very high speeds. The velocity energy is changed into pressure energy both by the impellers and the discharge volutes or diffusers. In the centrifugal-type dynamic compressors, the shape of

Figure 1.1  Components of a Typical Industrial Compressed Air System.

<!-- image -->

Figure 1.2  Compressor Family Tree.

<!-- image -->

the impeller blades determines the relationship between air flow and the pressure (or head) generated.

## Positive-Displacement Compressors

These compressors are available in two types: reciprocating and rotary. Reciprocating compressors work like bicycle pumps. A piston, driven through a crankshaft and connecting rod by an electric motor, reduces the volume in the cylinder occupied by the air or gas, compressing it to a higher pressure. Singleacting compressors have a compression stroke in only one direction, while double-acting units provide a compression stroke as the piston moves in each direction. Large, industrial reciprocating air compressors are double-acting and water-cooled. Multi-stage, doubleacting compressors are the most efficient compressors available, and are typically larger, noisier, and more costly than comparable rotary units. Reciprocating compressors are available in sizes from less than 1 hp to more than 600 hp.

Rotary compressors have gained popularity and are now the 'workhorse' of American industry. They are most commonly used in sizes from about 30 to 200 hp. The most common type of rotary compressor is the helical-twin, screw-type (also known as rotary screw or helical-lobe). Male and female screw-rotors mesh, trapping air, and reducing the volume of the air along the rotors to the air discharge point. Rotary screw compressors have low initial cost, compact size, low weight, and are easy to maintain. Rotary screw compressors may be air- or water-cooled. Less common rotary compressors include sliding-vane, liquid-ring, and scroll-type.

## Single-Acting, Reciprocating Air Compressors

This type of compressor is characterized by its 'automotive' type piston driven through a connecting rod from the crankshaft. Compression takes place on the top side of the piston on each revolution of the crankshaft. Single-acting, reciprocating air compressors may be air-cooled or liquid-cooled. These may be singlestage, usually rated at discharge pressures from 25 to 125 pounds per square inch gauge (psig), or two-stage, usually rated at discharge pressures from 125 psig to 175 psig or higher.

The most common air compressor in the fractional and single-digit hp sizes is the air-cooled, reciprocating air compressor. In larger sizes, single-acting reciprocating compressors are available up to 150 hp, but above 25 hp are much less common. Two-stage and multi-stage designs include inter-stage cooling to reduce discharge air temperatures for improved efficiency and durability.

Pistons used in single-acting compressors are of the 'automotive' or 'full skirt' design, the underside of the piston being exposed to the crankcase. Lubricated versions have a combination of compression and lubricant-control piston rings, which seal the compression chamber, control the lubricant to the compression chamber, and act (in some designs) as support for piston movement on the cylinder walls.

Lubricant-free, or non-lube designs, do not allow lubricant in the compression chamber and use pistons of self-lubricating materials or use heat resistant, non-metallic guides and piston rings which, are selflubricating. Some designs incorporate a distance piece or crosshead to isolate the crankcase from the compression chamber.

Lubricant-less designs have piston arrangements similar to lubricant-free versions but do not have lubricant in the crankcase. Generally these have a grease pre-packed crankshaft and connecting rod bearings.

Cooling. Single-acting air compressors have different arrangements for removing the heat of compression. Air-cooled versions have external finning for heat dissipation on the cylinder, cylinder head, and in some cases, the external heat exchanger. Air is drawn or blown across the fins and the compressor crankcase by a fan, which may be the spokes of the drive pulley/flywheel.

Liquid-cooled compressors have jacketed cylinders, heads and heat exchangers, through which liquid coolant is circulated to dissipate the heat of compression. Water, or an ethylene glycol mixture to prevent freezing, may be employed.

Drives. The most common drive arrangement is a belt drive from an electric motor. The compressor sheave also acts as a flywheel to limit torque pulsations and its spokes often are used for cooling air circulation. Belt drives allow a great degree of flexibility in obtaining the desired speed of rotation.

Flange-mounted, or direct-coupled motor drives provide compactness and minimum drive maintenance. Belts and couplings must be properly shielded for safety and to meet Occupational Safety &amp; Health Administration (OSHA) requirements in industrial plants.

## Double-Acting, Reciprocating Air Compressors

Double-acting reciprocating compressors use both sides of the piston for air compression, doubling the capacity for a given cylinder size. A piston rod is attached to the piston at one end and to a crosshead at the other end. The crosshead ensures that the piston travels concentrically within the cylinder. These compressors may be single- or multi-stage, depending on discharge pressure and hp size. These can range upwards from 10 hp and with pressures upwards from 50 psig.

Cooling. Double-acting air compressors generally have cooling water jackets around the cylinder body and in the cylinder head. This, combined with their relatively slow speed of operation and water-cooled intercooling, results in excellent compression efficiency.

Lubrication. Cylinder lubrication is generally by means of a forced-fed cylinder lubricator, with a feed rate of several drops per minute, depending on cylinder size and piston speed and as specified by the manufacturer. Lubricant-free versions also are available with polytetrafluorethylene (PTFE) or similar materials for pistons, riders, and compression rings. A distance piece is provided between the crankcase and the cylinder(s) to ensure that no part of the piston rod, which enters the lubricated crankcase, can enter the lubricant-free cylinder area.

Balance. Single- and two-cylinder compressors of this type generally require a substantial foundation due to unbalanced reciprocating forces.

Drives. Below 200 hp, belt drives and flange-mounted induction motors are normally used. For motors larger than 300 hp, flange-mounted, synchronous motors are sometimes used with a 1.0 power factor or 0.8 leading power factor to provide power factor correction to offset other induction-type electrical loads.

## Lubricant-Injected Rotary Screw Compressors

The lubricant-injected rotary screw compressor powered by an electric motor has become a dominant type of industrial compressor for a wide variety of applications.

Compression Principle. The lubricant-injected, rotaryscrew compressor consists of two intermeshing rotors in a stator housing having an inlet port at one end and a discharge port at the other. The male rotor has lobes formed helically along its length while the female rotor has corresponding helical grooves or flutes. The number of helical lobes and grooves may vary in otherwise similar designs.

Air flowing in through the inlet port fills the spaces between the lobes on each rotor. Rotation then causes the air to be trapped between the lobes and the stator as the inter-lobe spaces pass beyond the inlet port. As rotation continues, a lobe on one rotor rolls

into a groove on the other rotor and the point of intermeshing moves progressively along the axial length of the rotors, reducing the space occupied by the air, resulting in increased pressure. Compression continues until the inter-lobe spaces are exposed to the discharge port when the compressed air is discharged.

Lubricant is injected into the compression chamber during compression and serves three basic functions: 1) it lubricates the intermeshing rotors and associated bearings; 2) it takes away most of the heat caused by compression; and 3) it acts as a seal in the clearances between the meshing rotors and between rotors and stator.

Lubrication. The generic term 'lubricant' has been used instead of oil. The lubricant may be a hydrocarbon product, but most compressors now use cleaner and longer life synthetic lubricants, including diesters, polyglycols, polyalphaolefins, polyol esters, and siliconbased lubricants. These newer products are suitable for a wider range of temperatures.

A mixture of compressed air and injected lubricant leaves the air end and is passed to a sump/separator where the lubricant is removed from the compressed air. Directional and velocity changes are used to separate most of the liquid. The remaining aerosols in the compressed air then are separated by means of a coalescing filter, resulting in only a few parts per million (ppm) of lubricant carry-over (usually in the range of 2 to 5 ppm). A minimum pressure device, often combined with a discharge check valve, prevents excessive velocities through the separator element until a normal system pressure is achieved at start-up. Most lubricant-injected rotary screw compressor packages use the air pressure in the lubricant sump/separator, after the discharge of the air end, to circulate the lubricant through a filter and cooler prior to reinjection to the compression chamber. Some designs may use a lubricant pump.

Multi-stage compressors. Multi-stage compressors may have the individual stages mounted side by side, either in separate stators or within a common, multibore stator housing. Alternatively, the stages may be mounted in tandem with the second stage driven directly from the rear of the first stage. Multiple stages are used either for improved efficiency at a given pressure or to achieve higher pressures.

Cooling. The temperature of the lubricant injected into the compression chamber is generally controlled directly to a minimum of 140°F, or indirectly by controlling the discharge temperature. A thermostatic bypass valve allows some or all of the lubricant being circulated to bypass the lubricant cooler to maintain the desired temperature over a wide range of ambient temperatures.

Generally, suitable lubricant temperature and viscosity are required for proper lubrication, sealing, and to avoid condensation in the lubricant sump. It also is necessary to avoid excessive temperatures, which could result in a breakdown of the lubricant and reduced life.

In addition to lubricant cooling, an aftercooler is used to cool the discharged air and a moisture separator removes the condensate. In the majority of applications, air-cooled, radiator-type lubricants and air coolers are employed and provide the opportunity for heat recovery from the compression process for facility heating. In water-cooled designs, water-cooled heat exchangers with water control valves also are available on most rotary screw compressor packages.

In multi-stage designs, lubricant may be removed and air-cooled between the stages in an intercooler, or the air/lubricant mixture may pass through a curtain of lubricant as it enters the next stage.

Single-stage, lubricant-injected, rotary screw compressor packages are available from 3 to 900 hp, or 8 to 5000 cubic feet per minute (cfm), with discharge pressures from 50 to 250 psig. Two-stage versions can reduce specific power and some can achieve discharge pressures up to 500 psig. Lubricant-injected, rotary screw vacuum pumps also are available from 80 to 3,100 inlet cfm and vacuum to 29.7 inches Hg. Lubricant-injected, rotary-vane compressors are a less common type of rotary compressor and are available in a limited size range.

## Lubricant-Free Rotary Screw Compressors

The principle of compression in lubricant-free rotary screw compressors is similar to that of the lubricant-injected rotary screw compressors but, without lubricant being introduced into the compression chamber. Two distinct types are available: the dry-type and the water-injected type.

In the dry-type, the intermeshing rotors are not allowed to touch and their relative positions are maintained by means of lubricated timing gears external to the compression chamber. Since there is no injected fluid to remove the heat of compression, most designs use two stages of compression with an intercooler between the stages and an aftercooler after the second

stage. The lack of a sealing fluid also requires higher rotation speeds than for the lubricant-injected type. Dry-type, lubricant-free rotary screw compressors have a range from 25 to 4,000 hp or 90 to 20,000 cfm. Single-stage units operate up to 50 psig, while two-stage can achieve up to 150 psig.

In the water-injected type, similar timing gear construction is used, but water is injected into the compression chamber to act as a seal in internal clearances and to remove the heat of compression. This allows pressures in the 100 to 150 psig range to be accomplished with only one stage. The injected water, together with condensed moisture from the atmosphere, is removed from the discharged compressed air by a conventional moisture separation device. Similar to the lubricant-injected type, lubricant-free rotary screw compressors generally are packaged with all necessary accessories.

Lubrication. Lubricant-free rotary screw compressors utilize lubricant for bearings and gears, which are isolated from the compression chamber. The lubricant also may be used for stator jacket cooling in air-cooled units. Typically, a lubricant pump is directly driven from a shaft in the gearbox, assuring lubricant flow immediately at start-up and during run-down in the event of power failure. A lubricant filter, typically with 10 micron rating, protects bearings, gears, and the lubricant pump from damage.

Cooling. The cooling system for the dry-type, lubricant-free rotary screw compressor normally consists of an air cooler after each stage and a lubricant cooler. These may be water-cooled or air-cooled, radiator-type. Some older two-stage designs also employ an additional heat exchanger to cool a small portion of the compressed air for recycling to the compressor inlet during the unloaded period.

## Dynamic Compressors

These compressors raise the pressure of air or gas by imparting velocity energy and converting it to pressure energy. Dynamic compressors include centrifugal and axial types. The centrifugal-type is the most common and is widely used for industrial compressed air. Each impeller, rotating at high speed, imparts primarily radial flow to the air or gas which then passes through a volute or diffuser to convert the residual velocity energy to pressure energy. Some large manufacturing plants use centrifugal compressors for general plant air, and in some cases, plants use other compressor types to accommodate demand load swings while the centrifugal compressors handle the base load.

Axial compressors consist of a rotor with multiple rows of blades and a matching stator with rows of stationary vanes. The rotating blades impart velocity energy, primarily in an axial plane. The stationary vanes then act as a diffuser to convert the residual velocity energy into pressure energy. This type of compressor is restricted to very high flow capacities and generally has a relatively high compression efficiency. Mixed flow compressors have impellers and rotors which combine the characteristics of both axial and centrifugal compressors.

## Centrifugal Air Compressors

A centrifugal air compressor has a continuously flowing air stream which has velocity energy, or kinetic energy, imparted to it by an impeller, or impellers, which rotate at speeds that can exceed 50,000 revolutions per minute (rpm). Approximately one half of the pressure energy is developed in the impeller with the other half achieved by converting the velocity energy to pressure energy as the air speed is reduced in a diffuser and volute. The most common centrifugal air compressor is one with two to four stages for pressures in the 100 to 150 psig range. A water-cooled intercooler and separator between each stage returns the air temperature to approximately ambient temperature and removes condensed moisture before entering the next stage. An aftercooler cools the air from the final stage and a moisture separator removes the moisture prior to air delivery to distribution.

The inherent characteristic of centrifugal air compressors is that as system pressure decreases, the compressor's flow capacity increases. The steepness of the pressure head/capacity curve is dependent upon the impeller design. The more the impeller blades lean backwards from the true radial position, the steeper the curve.

Most standard centrifugal air compressor packages are designed for an ambient temperature of 95°F and near sea level barometer pressure. The dynamic nature of the centrifugal compressor results in the pressure head generated by each impeller increasing as the air density increases. The compressor mass flow and actual cubic feet per minute (acfm) capacity at a given discharge pressure increases as the ambient temperature decreases. Typically, a capacity control system is

provided with the compressor to maintain the desired capacity and to operate within the motor horsepower limits. The control system regulates the air flow by means of an inlet throttle valve or inlet guide vanes. The amount of reduction in the flow rate is limited by a minimum point flow reversal phenomenon known as surge. Control systems either unload the compressor or blow off the excess air to atmosphere to avoid this occurrence, which could result in excessive vibration and potential damage to the compressor. Given adequate storage, some manufacturers will operate the compressor controls in a load/unload mode at lower flow conditions.

Centrifugal air compressors range from around 300 to more than 100,000 cfm but the more common air compressors are from 1,200 to 5,000 cfm and with discharge pressures up to 125 psig. These may have several impellers in line on a single shaft or with separate impellers integrally geared.

Centrifugal air compressors provide lubricant-free air delivery as there is no lubricant in the compression chambers. Lubrication for speed increasing gears and the special high-speed shaft bearings is kept away from the compression chambers by means of shaft seals, which may also have air purge and vent connections.

Centrifugal air compressors are high-speed rotating machines and as such, shaft vibration monitoring is mandated to record operational trends and protect the equipment. Automatic control of the compressors is typical and has been greatly improved by the use of microprocessors, which monitor the pressure/capacity/ temperature characteristics as well as main-drive motor current draw. It is important that the manufacturer's recommended maintenance procedures be followed and that certain maintenance procedures be carried out by qualified staff. This is particularly true of attempts to remove an impeller from its shaft, since special procedures and tools may be involved.

Lubrication and Lubrication Systems. Centrifugal compressors use a pressure lubrication system for bearings and drive gears. The main lubricant pump may be driven from the gearbox input shaft with an electric motor-driven auxiliary lubricant pump for pre-lubrication prior to start-up and for post-lubrication during a cool down period. A water-cooled lubricant cooler is also included.

Because of the high rotation speeds, some designs use a high-pressure lubricant supply to the special bearings involved. The manufacturer's recommended lubricant should be used and changed at the specified intervals.

## Compressor Prime Movers

The prime mover is the main power source providing energy to drive the compressor. The prime mover must provide enough power to start the compressor, accelerate it to full speed, and keep the unit operating under various design conditions. This power can be provided by any one of the following sources: electric motors, diesel or natural gas engines, steam turbines and combustion turbines. Electric motors are by far the most common type of prime mover.

Electric motors are a widely available and economical means of providing reliable and efficient power to compressors. Most compressors use standard, polyphase induction motors. In many cases, either a standard- or a premium-efficient motor can be specified when purchasing a compressor or replacement motor. The incremental cost of the premium efficient motor is typically recovered in a very short time from the resulting energy savings. When replacing a standard motor with a premium-efficient version, careful attention should be paid to performance parameters, such as full-load speed and torque. A replacement motor with performance as close as possible to the original motor should be used. When replacing a drive motor in a compressor that uses a variable frequency drive as part of the control system, use an inverter-duty motor.

Diesel or natural gas engines are common compressor power sources in the oil and gas industries. Considerations such as convenience, cost, and the availability of liquid fuel and natural gas play a role in selecting an engine to power a compressor. Although the majority of industrial compressed air systems use electric motors for prime movers, in recent years there has been renewed interest in using non-electric drives, such as reciprocating engines powered by natural gas, particularly in regions with high electricity rates. Standby or emergency compressors may also be engine-driven to allow operation in the event of a loss of electrical power. Maintenance costs for engine-driven systems are significantly higher than those that use electric motors.

The oldest method of driving compressors is through the use of a steam engine or turbine. In general, however, it is not economical to use a steam engine or turbine unless the steam is inexpensively and readily available within the plant for use as a power source.

## Compressed Air System Controls

Compressed air system controls serve to match compressor supply with system demand. Proper

compressor control is essential to efficient operation and high performance. Because compressor systems are typically sized to meet a system's maximum demand, a control system is almost always needed to reduce the output of the compressor during times of lower demand. Compressor controls are typically included in the compressor package, and many manufacturers offer more than one type of control technology. Systems with multiple compressors use more sophisticated controls (network or system master controls) to orchestrate compressor operation and air delivery to the system.

Network controls use the on-board compressor controls' microprocessors linked together to form a chain of communication that makes decisions to stop/start, load/unload, modulate, vary displacement, and vary speed. Usually, one compressor assumes the lead with the others being subordinate to the commands from this compressor.

System master controls coordinate all of the functions necessary to optimize compressed air as a utility. System master controls have many functional capabilities, including the ability to monitor and control all components in the system, as well as trending data, to enhance maintenance functions and minimize costs of operation. Other system controllers, such as pressure/flow controllers, can also improve the performance of some systems.

The type of control system specified for a given system is largely determined by the type of compressor being used and the facility's demand profile. If a system has a single compressor with a very steady demand, a simple control system may be appropriate. On the other hand, a complex system with multiple compressors, varying demand, and many types of end uses will require a more sophisticated control strategy. In any case, careful consideration should be given to compressor system control selection because it can be the most important single factor affecting system performance and efficiency. For information about efficiency and compressor controls, see the fact sheet titled Compressed Air System Controls in Section 2.

## Accessories

Accessories are the various types of equipment used to treat compressed air by removing contaminants such as dirt, lubricant, and water; to keep compressed air systems running smoothly; and to deliver the proper pressure and quantity of air throughout the system. Accessories include compressor aftercoolers, filters, separators, dryers, heat recovery equipment, lubricators, pressure regulators, air receivers, traps, and automatic drains.

Air Inlet Filters. An air inlet filter protects the compressor from atmospheric airborne particles. Further filtration is typically needed to protect equipment downstream of the compressor.

Compressor Cooling. Air or gas compression generates heat. As a result, industrial air compressors that operate continuously generate substantial amounts of heat. Compressor units are cooled with air, water, and/or lubricant. Single-acting reciprocating compressors are typically air-cooled using a fan, which is an integral part of the belt-drive flywheel. Cooling air blows across finned surfaces on the outside of the compressor cylinder's cooler tubes. Larger, water-cooled, doubleacting reciprocating air compressors have built-in cooling water jackets around the cylinders and in the cylinder heads. The temperature of the inlet water and the design and cleanliness of the cooler can affect overall system performance and efficiency. Centrifugal compressors are generally water-cooled.

Lubricant-injected rotary compressors use the injected lubricant to remove most of the heat of compression. In air-cooled compressors, a radiator-type lubricant cooler is used to cool the lubricant before it is reinjected. The cooling fan may be driven from the main motor-drive shaft or by a small auxiliary electric motor. In plants where good quality water is available, shell and tube heat exchangers generally are used.

Intercooling. Most multi-stage compressors use intercoolers, which are heat exchangers that remove the heat of compression between the stages of compression. Intercooling affects the overall efficiency of the machine.

Aftercoolers. As mechanical energy is applied to a gas for compression, the temperature of the gas increases. Aftercoolers are installed after the final stage of compression to reduce the air temperature. As the air temperature is reduced, water vapor in the air is condensed, separated, collected, and drained from the system. Most of the condensate from a compressor with intercooling is removed in the intercooler(s), and the remainder in the aftercooler. Almost all industrial systems, except those that supply process air to heat-indifferent operations require aftercooling. In some systems, aftercoolers are an integral part of the compressor package, while in other systems the aftercooler is a separate piece of equipment. Some systems have both.

Separators. Separators are devices that separate liquids entrained in the air or gas. A separator generally is installed following each intercooler or aftercooler to remove the condensed moisture. This involves changes in direction and velocity and may include impingement baffles. Lubricant-injected rotary compressors have an air/lubricant coalescing separator immediately after the compressor discharge to separate the injected lubricant before it is cooled and recirculated to the compressor. This separation must take place before cooling to prevent condensed moisture from being entrained in the lubricant.

Dryers. When air leaves an aftercooler and moisture separator, it is typically saturated. Any further radiant cooling as it passes through the distribution piping, which may be exposed to colder temperatures, will cause further condensation of moisture with detrimental effects, such as corrosion and contamination of pointof-use processes. This problem can be avoided by the proper use of compressed air dryers.

Atmospheric air contains moisture. The higher the air temperature, the more moisture the air is capable of holding. The term 'relative humidity' is commonly used to describe the moisture content although technically, the correct term is 'relative vapor pressure,' the air and the water vapor being considered as gases. When the air contains all the moisture possible under the prevailing conditions, it is called 'saturated.' Air at 80 percent relative humidity would contain 80 percent of the maximum possible.

When air is cooled, it will reach a temperature at which the amount of moisture present can no longer be contained and some of the moisture will condense and drop out. The temperature at which the moisture condenses is called the dew point. In general, reducing the temperature of saturated compressed air by 20°F will reduce the moisture content by approximately 50 percent.

When air is compressed and occupies a smaller volume, it can no longer contain all of the moisture possible at atmospheric conditions. Again, some of the moisture will drop out as liquid condensate. The result of both of these situations is a difference between the dew point at atmospheric conditions and the dew point at higher pressures. Drying compressed air beyond the required pressure dew point will result in unnecessary energy and costs.

Different types of compressed air dryers have different operating characteristics and degrees of dew point suppression. Dryer ratings usually are based on standard dryer inlet conditions, commonly referred to as 'the three 100s.' That is, 100 psig, 100°F (inlet compressed air temperature), and 100°F ambient temperature. Deviations from these conditions will affect the capacity of a dryer. An increase in inlet temperature or a decrease in inlet pressure will reduce the dryer's rated capacity. Most manufacturers provide correction factors for this.

The most common types of dryers are discussed below.

- · The refrigerant dryer is the most commonly used dryer in the industry, having relatively low initial and operating costs. Refrigerant-type air dryers (cycling and non-cycling) are not recommended for operation in sub-freezing ambient temperatures. The moisture in the compressed air can freeze and damage the dryer. Most refrigerated dryers are equipped with a precooler/reheater that reheats the dried compressed air with an air-to-air heat exchanger using the hot incoming air. This lowers the temperature of the incoming air before it passes through the refrigerant/thermal mass-to-air heat exchanger, reducing the heat load on the refrigerant system. Reheating the dried air prevents condensation on the outside of the compressed air piping in warm humid environments. The refrigerated dryer lowers the dew point of the air to the approximate temperature of the air exiting the refrigerant evaporator. To avoid freezing, the evaporator temperature should not go below 32°F. Allowing for separator efficiency, an air pressure dew point of 35°F, or higher for air leaving the dryer, can usually be obtained.

Cycling dryers cool compressed air indirectly through a thermal storage medium (heat sink, thermal mass, chilled media, etc.) while non-cycling dryers directly cool compressed air in a refrigerant to air heat exchanger. Refrigerant-type cycling dryers are controlled with one or two thermostats to shut off the refrigerant compressor when it is not needed, and a thermal storage medium (sometimes referred to as heat sink, chilled media or thermal mass) prevents rapid cycling of the refrigerant compressor(s). Powdered metal, glycol and water, sand, steel, and aluminum have all been used as this thermal storage medium. The ideal characteristics of this medium would be high specific heat (effective

storage), high coefficient of heat transfer (easy transfer of stored cooling), freezing below 0°F, corrosion protected and low cost. The quantity of medium required is determined by the temperature band of the controlling thermostat(s) and the refrigerant capacity to be stored.

Refrigerant-type, non-cycling dryers cool the air in a refrigerant-to-air heat exchanger. The cooling effect is from the evaporation of a liquid refrigerant causing moisture in the air to condense. The moisture then is removed and drained by a separator and drain. The temperature of the air leaving the refrigerant evaporator is controlled by a hot gas bypass valve.

- · Regenerative-desiccant-type dryers use a porous desiccant that adsorbs the moisture by collecting it in its myriad pores, allowing large quantities of water to be retained by a relatively small quantity of desiccant. Desiccant types include silica gel, activated alumina, and molecular sieves. Use only the type specified by the manufacturer. In some cases, more than one desiccant type can be used for special drying applications. In most of these cases, a larger particle size (1/4 inch or more) is used as a buffer zone at the inlet, while a smaller particle size desiccant (1/8 to 1/4 inch) is used for final drying. Where very low dewpoints are required, molecular sieve desiccant is added as the final drying agent.

Normally, the desiccant is contained in two separate towers. Compressed air to be dried flows through one tower, while the desiccant in the other is being regenerated. Regeneration is accomplished by reducing the pressure in the tower and passing previously dried purge air through the desiccant bed. The purge air may also be heated, either with in the dryer or externally, to reduce the amount of purge air required. Purge air may also be supplied by a blower. Dryers of this type normally have a built-in regeneration cycle, which can be based upon time, dew point, or a combination of the two.

- · Deliquescent-type dryers use a drying medium that absorbs, rather than adsorbs, the moisture in the compressed air. This means that the desiccant medium is used up as it changes from solid to liquid and cannot be regenerated. The most common deliquescent chemicals for compressed air drying are salts of sodium, potassium, calcium, and those with a urea base. Various compounds of these have been developed and sold under a variety of trade names.
- · Heat-of-compression dryers are regenerativedesiccant dryers that use the heat generated during compression to accomplish desiccant regeneration, so they can be considered as heat reactivated. There are two types: the single-vessel and the twin-tower.

The single-vessel, heat-of-compression dryer provides continuous drying with no cycling or switching of towers. This is accomplished with a rotating desiccant drum in a single pressure vessel divided into two separate air streams. One air stream is a portion of the hot air taken directly from the air compressor at its discharge, prior to the aftercooler, and is the source of heated purge air for regeneration of the desiccant bed. The second air stream is the remainder of the air discharged from the air compressor after it passes through the air aftercooler. This air passes through the drying section of the dryer's rotating desiccant bed, where it is dried. The hot air, after being used for regeneration, passes through a regeneration cooler before being combined with the main air stream by means of an ejector nozzle before entering the dryer.

The twin-tower, heat-of-compression dryer operation is similar to other twin-tower, heatactivated, regenerative-desiccant dryers. The difference is that the desiccant in the saturated tower is regenerated by means of the heat of compression in all of the hot air leaving the discharge of the air compressor. The total air flow then passes through the air aftercooler before entering the drying tower. Towers are cycled as for other regenerative-desiccant dryers.

The heat-of-compression dryers require air from the compressor at a sufficiently high temperature to accomplish regeneration. For this reason, it is used almost exclusively with centrifugal or lubricant-free rotary screw compressors.

- · Membrane technology dryers have advanced considerably in recent years. Membranes commonly are used for gas separation, such as in nitrogen production for food storage and other applications. The structure of the membrane allows molecules of certain gases (such as oxygen) to pass through (permeate) a semi-permeable membrane faster than others (such as nitrogen), leaving a concentration of the desired gas (nitrogen) at the outlet of the generator. When used as a dryer in a compressed air system, specially designed membranes allow water vapor (a gas) to pass through the membrane pores

faster than the other gases (air) reducing the amount of water vapor in the air stream at the outlet of the membrane dryer, suppressing the dew point. The dew point achieved is usually 40°F but lower dew points to -40°F can be achieved at the expense of additional purge air loss.

Compressed Air Filters. Depending on the level of air purity required, different levels of filtration and types of filters are used. These include particulate filters to remove solid particles, coalescing filters to remove lubricant and moisture, and adsorbent filters for tastes and odors. A particulate filter is recommended after a desiccant-type dryer to remove desiccant 'fines.' A coalescing-type filter is recommended before a desiccanttype dryer to prevent fouling of the desiccant bed. Additional filtration may also be needed to meet requirements for specific end uses.

Compressed air filters downstream of the air compressor are generally required for the removal of contaminants, such as particulates, condensate, and lubricant. Filtration only to the level required by each compressed air application will minimize pressure drop and resultant energy consumption. Elements should also be replaced as indicated by pressure differential to minimize pressure drop and energy consumption, and should be checked at least annually.

Heat Recovery. As noted earlier, compressing air generates heat. In fact, industrial-sized air compressors generate a substantial amount of heat that can be recovered and put to useful work. More than 80 percent of the electrical energy going to a compressor becomes available heat. Heat can be recovered and used for producing hot water or hot air. See the fact sheet in Section 2 titled Heat Recovery with Compressed Air Systems for more information on this energy-saving opportunity.

Lubrication. In lubricant-injected rotary screw compressors, lubricants are designed to cool, seal, and lubricate moving parts for enhanced performance and longer wear. Important considerations for compressor lubricants include proper application and compatibility with downstream equipment, including piping, hoses, and seals. A lubricator may be installed near a pointof-use to lubricate items such as pneumatic tools. The lubricator may be combined with a filter and a pressure regulator to make up what is commonly called a FRL (filter-regulator-lubricator). The lubricant should be that specified by the point-of-use equipment manufacturer.

Pressure/Flow Controllers. Pressure/flow controllers are optional system pressure controls used in conjunction with the individual compressor or system controls described previously. Their primary function is to stabilize system pressure separate from and more precisely than compressor controls. A pressure/flow controller does not directly control a compressor and is generally not included as part of a compressor package. A pressure/flow controller is a device that serves to separate the supply side of a compressor system from the demand side.

Air Receivers. Receivers are used to provide compressed air storage capacity to meet peak demand events and help control system pressure by controlling the rate of pressure change in a system. Receivers are especially effective for systems with widely varying compressed air flow requirements. Where peaks are intermittent, a large air receiver may allow a smaller air compressor to be used and can allow the capacity control system to operate more effectively and improve system efficiency. An air receiver after a reciprocating air compressor can provide dampening of pressure pulsations, radiant cooling, and collection of condensate. Demand-side control will optimize the benefit of the air receiver storage volume by stabilizing system header pressure and 'flattening' the load peaks. Air receivers also play a crucial role in orchestrating system controls, providing the time needed to start or avoid starting standby air compressors.

Traps and Drains. Traps (sometimes called drains) allow the removal of condensate from the compressed air system. Automatic condensate traps are used to conserve energy by preventing the loss of air through open petcocks and valves. Poorly maintained traps can waste a lot of compressed air.

There are four methods to drain condensate.

- 1. Manual. Operators will manually open valves to discharge condensate. However, this is not automatic, and unfortunately, too often, manual valves are left open to drain condensate from moisture separators, intercoolers, refrigerated dryers, and filters, allowing compressed air to continually escape into the atmosphere.
- 2. Level-operated mechanical traps. Float-type traps do not waste air when operating properly, but they often require a great deal of maintenance and are prone to blockage from sediment in the condensate. Inverted bucket traps may require

less maintenance but will waste compressed air if the condensate rate is inadequate to maintain the liquid level (or prime) in the trap.

- 3. Electrically operated solenoid valves. The solenoid-operated drain valve has a timing device that can be set to open for a specified time and at preset adjustable intervals. There are two issues with using these valves.
- · The period during which the valve is open may not be long enough for adequate drainage of accumulated condensate.
- · The valve will operate even if little or no condensate is present, resulting in the loss of valuable compressed air. Level-operated and electrically operated solenoid valves should have strainers installed to reduce contaminants, which block the inlet and discharge ports of these automatic devices.

Motorized ball valves are also used with programmable timers. However, while fairly reliable, these valves can be even more wasteful as the duration of the valve opening is dependent on the valve actuator and is not adjustable.

- 4. Zero air-loss traps with reservoirs. There are various types of zero air-loss traps.
- · A float or level sensor operates an electric solenoid or ball valve and maintains the condensate level in the reservoir below the high-level point.
- · A float activates a pneumatic signal to an air cylinder to open a ball valve through a linkage to expel the condensate in the reservoir to the low-level point.

Be sure to drain the reservoir often to prevent the accumulation of contaminants, which could foul the mechanisms of these traps.

The potential for freezing must be considered and provision made for heated drains where necessary. The relatively common practice of leaving a manual drain valve cracked open should not be tolerated because it wastes costly compressed air.

Contaminated condensate requires removal of lubricant before the condensate is discharged to a sewer system. It is recommended that the local sewage authority be consulted for allowable contamination levels.

Air Distribution Systems. The air distribution system links the various components of the compressed air system to deliver air to the points-of-use with minimal pressure loss. The specific configuration of a distribution system depends on the needs of the individual plant, but frequently consists of an extended network of main lines, branch lines, valves, and air hoses. The length of the network should be kept to a minimum to reduce pressure drop. Air distribution piping should be large enough in diameter to minimize pressure drop. A loop system is generally recommended, with all piping sloped to accessible drop legs and drain points.

When designing an air distribution system layout, it is best to place the air compressor and its related accessories where temperature inside the plant is the lowest (but not below freezing). A projection of future demands and tie-ins to the existing distribution system should also be considered. Air leaks are an important issue with distribution system and are addressed in the fact sheet in Section 2 titled Compressed Air System Leaks . It is important to note that the majority of system leakage will be at the point of use and not in the distribution piping.

Headers should have a slight slope to allow drainage of condensate and drop legs from the bottom side of the header should be provided to allow collection and drainage of the condensate. The direction of the slope should be away from the compressor.

Piping from the header to points-of-use should connect to the top or side of the header to avoid being filled with condensate. Drainage-drop legs from the bottom of the header should be installed to collect the condensate.

## Uses of Compressed Air

Industrial facilities use compressed air for a multitude of operations. Almost every industrial facility has at least two compressors, and in a medium-sized plant there may be hundreds of different uses of compressed air.

Uses include powering pneumatic tools, packaging and automation equipment, and conveyors. Pneumatic tools tend to be smaller, lighter, and more maneuverable than electric motor-driven tools. They also deliver smooth power and are not damaged by overloading. Air-powered tools have the capability for infinitely variable speed and torque control, and can reach a desired speed and torque very quickly. In addition, they are often selected for safety reasons because they

do not produce sparks and have low heat build-up. Although they have many advantages, pneumatic tools are generally much less energy-efficient than electric tools. Many manufacturing industries also use compressed air and gas for combustion and process operations such as oxidation, fractionation, cryogenics, refrigeration, filtration, dehydration, and aeration. Table 1.1 lists some major manufacturing industries and the tools, conveying, and process operations requiring compressed air. For some of these applications, however, other sources of power may be more cost effective (see the fact sheet titled Potentially Inappropriate Uses of Compressed Air in Section 2).

Compressed air also plays a vital role in many non-manufacturing sectors, including the transportation, construction, mining, agriculture, recreation, and service industries. Examples of some of these applications are shown in Table 1.2.

Table 1.1  Industrial Sector Uses of Compressed Air

| Industry               | Example Compressed Air Uses                                                                                                  |
|------------------------|------------------------------------------------------------------------------------------------------------------------------|
| Apparel                | Conveying, clamping, tool powering, controls and actuators, automated equipment                                              |
| Automotive             | Tool powering, stamping, control and actuators, forming, conveying                                                           |
| Chemicals              | Conveying, controls and actuators                                                                                            |
| Food                   | Dehydration, bottling, controls and actuators, conveying, spraying coatings, cleaning, vacuum packing                        |
| Furniture              | Air piston powering, tool powering, clamping, spraying, controls and actuators                                               |
| General Manufacturing  | Clamping, stamping, tool powering and cleaning, control and actuators                                                        |
| Lumber and Wood        | Sawing, hoisting, clamping, pressure treatment, controls and actuators                                                       |
| Metals Fabrication     | Assembly station powering, tool powering, controls and actuators, injection molding, spraying                                |
| Petroleum              | Process gas compressing, controls and actuators                                                                              |
| Primary Metals         | Vacuum melting, controls and actuators, hoisting                                                                             |
| Pulp and Paper         | Conveying, controls and actuators                                                                                            |
| Rubber and Plastics    | Tool powering, clamping, controls and actuators, forming, mold press powering, injection molding                             |
| Stone, Clay, and Glass | Conveying, blending, mixing, controls and actuators, glass blowing and molding, cooling                                      |
| Textiles               | Agitating liquids, clamping, conveying, automated equipment, controls and actuators, loom jet weaving, spinning, texturizing |

Table 1.2  Non-Manufacturing Sector Use of Compressed Air

| Sector               | Example Compressed Air Uses                                                                                          |
|----------------------|----------------------------------------------------------------------------------------------------------------------|
| Agriculture          | Farm equipment, materials handling, spraying of crops, dairy machines                                                |
| Mining               | Pneumatic tools, hoists, pumps, controls and actuators                                                               |
| Power Generation     | Starting gas turbines, automatic control, emissions controls                                                         |
| Recreation           | Amusement parks - air brakes                                                                                         |
| Recreation           | Golf courses - seeding, fertilizing, sprinkler systems                                                               |
| Recreation           | Hotels - elevators, sewage disposal                                                                                  |
| Recreation           | Ski resorts - snow making                                                                                            |
| Recreation           | Theaters - projector cleaning                                                                                        |
| Recreation           | Underwater exploration - air tanks                                                                                   |
| Service Industries   | Pneumatic tools, hoists, air brake systems, garment pressing machines, hospital respiration systems, climate control |
| Transportation       | Pneumatic tools, hoists, air brake systems                                                                           |
| Wastewater Treatment | Vacuum filters, conveying                                                                                            |

## The Performance Opportunity Roadmap

Improving and maintaining peak compressed air system performance requires not only addressing individual components, but also analyzing both the supply and demand sides of the system and how they interact. This practice is often referred to as taking a 'systems approach' because the focus is shifted away from components to total system performance. Applying the systems approach usually involves the following types of interrelated actions:

- · Establishing current conditions and operating parameters
- · Determining present and future process production needs
- · Gathering and analyzing operating data and developing load duty cycles
- · Analyzing alternative system designs and improvements
- · Determining the most technically and economically sound options, taking into consideration all of the sub-systems
- · Implementing those options
- · Analyzing operations and energy consumption and analyzing economics (i.e., validating performance)
- · Continuing to monitor and optimize the system
- · Continuing to operate and maintain the system for peak performance.

Most compressed air systems use considerably more energy than is needed to support the demand. Compressed air systems usually have a wire-to-work efficiency of around 10 percent, which is very low. In many cases, after a thorough review of a compressed air system and after corrective actions are taken, one or more of the compressors may be shut off and the overall system efficiency improved.

Both systems performance improvement opportunities and component efficiency improvement opportunities are addressed in the series of fact sheets that follow.

## The Fact Sheets

The remainder of the Performance Opportunity Roadmap section of the sourcebook is a collection of 12 fact sheets that address both component and system issues. Each fact sheet details a specific opportunity for improving compressed air system performance. Topics include:

- 1Analyzing Compressed Air Needs
- 2Potentially Inappropriate Uses of Compressed Air
- 3Compressed Air System Leaks
- 4Pressure Drop and Controlling System Pressure
- 5Compressed Air System Controls
- 6Compressed Air Storage
- 7Proven Opportunities at the Component Level
- 8Maintenance of Compressed Air Systems for Peak Performance
- 9Heat Recovery and Compressed Air Systems 10Baselining Compressed Air Systems
- 11Compressed Air System Assessments and Audits and Selecting a Service Provider
- 12Compressed Air System Economics and Selling Projects to Management

The compressed air system diagram shown in Figure 2.1 shows the performance improvement opportunities described in the fact sheets.

Figure 2.1  Performance Opportunities.

<!-- image -->

## Analyzing Compressed Air Needs

Compressed air needs are defined by the air quality, quantity, and level of pressure required by the end uses in your plant. Analyzing needs carefully will ensure that a compressed air system is configured properly.

## Air Quality

As illustrated in the table, compressed air quality ranges from plant air to breathing air.

| Quality        | Applications                                                                                     |
|----------------|--------------------------------------------------------------------------------------------------|
| Plant Air      | Air tools, general plant air                                                                     |
| Instrument Air | Laboratories, paint spraying, powder coating, climate control                                    |
| Process Air    | Food and pharmaceutical process air, electronics                                                 |
| Breathing Air  | Hospital air systems, diving tank refill stations, respirators for cleaning and/or grit blasting |

Industrial applications typically use one of the first three air quality levels. Quality is determined by the dryness and contaminant level required by the end uses, and is accomplished with filtering and drying equipment. The higher the quality, the more the air costs to produce. Higher quality air usually requires additional equipment, which not only increases initial capital investment, but also makes the overall system more expensive to operate in terms of energy consumption and maintenance costs.

One of the main factors in determining air quality is whether or not lubricant-free air is required. Lubricantfree air can be produced with either lubricant-free compressors, or with lubricant-injected compressors that have additional separation and filtration equipment. Lubricant-free rotary screw and reciprocating compressors usually have higher first costs, lower efficiency, and higher maintenance costs than lubricant-injected compressors. However, the additional separation and filtration equipment required by lubricant-injected compressors will cause some reduction in efficiency, particularly if systems are not properly maintained. Before selecting a lubricant-free or lubricant-injected compressor, careful consideration should be given to the specific end use for the lubricantfree air, including the risk and cost associated with product contamination.

## Air Quantity-Capacity

Required compressed air system capacity can be determined by summing the requirements of the tools and process operations (taking into account load factors) at the site. The total air requirement is not the sum of the maximum requirements for each tool and process, but the sum of the average air consumption of each. High short-term demands should be met by air stored in an air receiver. Systems may need more than one air receiver. Strategically locating air receivers near sources of high demand can also be effective. In most cases, a thorough evaluation of system demand may result in a control strategy that will meet system demand with reduced overall compressor capacity.

Oversized air compressors are extremely inefficient because most compressors use more energy per unit volume of air produced when operating at part-load. In many cases, it makes sense to use multiple, smaller compressors with sequencing controls to allow for efficient operation at times when demand is less than peak.

If a system is properly designed and maintained but is still experiencing capacity problems, an alternative to adding another compressor is to re-examine the use of compressed air for certain applications. For some tasks, blowers or electric tools may be more effective or appropriate. See the fact sheet titled Potentially Inappropriate Uses of Compressed Air for more information on this system improvement opportunity.

## Load Profile

Another key to properly designing and operating a compressed air system is analyzing a plant's compressed air requirements over time, or load profile. The variation of demand for air over time is a major consideration in system design. Plants with wide variations in air demand need a system that operates efficiently under part-load. Multiple compressors with sequencing controls may provide more economical

operation in such a case. Plants with a flatter load profile can use simpler control strategies.

## Artificial Demand

Artificial demand is defined as the excess volume of air that is required by unregulated end uses as a result of supplying higher pressure than necessary for applications. Pressure/flow controllers (see the fact sheet titled Compressed Air System Controls ) can help to minimize artificial demand.

## Pressure

Different tools and process operations require different pressures. Pneumatic tool manufacturers rate tools for specific pressures, and process operation pressure requirements should be specified by the process engineers.

unregulated usage, including leaks, open blowing, etc. Although it varies by plant, unregulated usage is commonly as high as 30 to 50 percent of air demand. For systems in the 100 psig range with 30 to 50 percent unregulated usage, a 2 psi increase in header pressure will increase energy consumption by about another 0.6 to 1.0 percent because of the additional unregulated air being consumed. The combined effect results in a total increase in energy consumption of about 1.6 to 2 percent for every 2 psi increase in discharge pressure for a system in the 100 psig range with 30 to 50 percent unregulated usage.

See the fact sheet titled Pressure Drop and Controlling System Pressure for information on ways to reduce system pressure and save energy while maintaining high performance.

Required pressure levels must take into account system losses from dryers, separators, filters, and piping. A rule of thumb for systems in the 100 pounds per square inch gauge (psig) range is: for every 2 pounds per square inch (psi) increase in discharge pressure, energy consumption will increase by approximately 1 percent at full output flow (check performance curves for centrifugal and two-stage, lubricant-injected, rotary screw compressors). There is also another penalty for higher-than-needed pressure. Raising the compressor discharge pressure increases the demand of every

## Using Block Diagrams, Pressure Profiles, and Demand Profiles

Two simple tools that are available to help analyze compressed air systems are block diagrams and pressure profiles. Block diagrams identify all the components in the system. A sample diagram is shown in Figure 2.2.

Another way to analyze a compressed air system is to draw a pressure profile. A pressure profile shows the pressure drops through a system. These pressure measurements give feedback for control adjustments, determine pressure drops across components, and help

Figure 2.2  Compressed Air System Block Diagram.

<!-- image -->

determine system operating pressures. The tools required for measurement are matched, calibrated pressure gauges or differential pressure gauges. The following pressure measurements should be taken:

- · Inlet to compressor (to monitor inlet air filter) versus atmospheric pressure
- · Differential across air/lubricant separator (if applicable)
- • Interstage on multi-stage compressors

Consider pressure differentials, including:

- • Aftercooler
- • Treatment equipment (dryers, filters, etc.)
- • Various points of the distribution system
- · Check pressure differentials against manufacturers' specifications, if available (high-pressure drops indicate service is required).

Figure 2.3 shows an example of a pressure profile (in a system with excessive pressure drop).

This method gives the pressure profile at a single point in time. Taking data at a single point, or even during various shifts, can provide some answers, but not the complete picture. The use of data loggers is important in determining how a system operates over time. Data logging system pressures and flow can indicate intermittent loads, system disruptions and general system conditions. It can also indicate system changes (e.g. production process changes or air leaks) that can affect the compressed air system operation and efficiency. These variations in pressure and flow can be managed through system control strategies and storage to minimize their impact on production. See the fact sheet titled Compressed Air System Controls . An example of pressure and demand (airflow) over a period of 30 minutes is shown in Figure 2.4.

Figure 2.3  Pressure Profile at a Single Point in Time.

<!-- image -->

Figure 2.4  Pressure Profile Over a Defined Time Period.

<!-- image -->

## Potentially Inappropriate Uses of Compressed Air

Compressed air is probably the most expensive form of energy available in a plant. Compressed air is also clean, readily available, and simple to use. As a result, compressed air is often chosen for applications for which other energy sources are more economical. Users should always consider more cost-effective forms of power before considering compressed air.

Many operations can be accomplished more economically using alternative energy sources. Inappropriate uses of compressed air include any application that can be done more effectively or more efficiently by a method other than compressed air. Examples of potentially inappropriate uses of compressed air include:

- • Open blowing
- • Sparging
- • Aspirating
- • Atomizing
- • Padding
- • Dilute-phase transport
- • Dense-phase transport
- • Vacuum generation
- • Personnel cooling
- • Open hand-held blowguns or lances
- • Diaphragm pumps
- • Cabinet cooling
- • Vacuum venturis.

Each potentially inappropriate use and a suggested alternative is described below.

## Open Blowing

Open blowing is using compressed air applied with an open, unregulated tube, hose, or pipe for one of these applications:

- • Cooling
- • Bearing cooling
- • Drying
- • Clean-up
- • Draining compressed air lines
- • Clearing jams on conveyors.

The alternatives to open blowing are vast. Some are:

- • Brushes
- • Brooms
- • Dust collection systems
- • Non-air-loss auto drains
- • Blowers
- • Blowers with knives
- • Electric fans
- • Electric barrel pumps
- • Mixers
- • Nozzles.

## Sparging

Sparging is aerating, agitating, oxygenating, or percolating liquid with compressed air. This is a particularly inappropriate application because liquid can be wicked into a dry gas, increasing the dew point. The lower the dew point of the compressed air, the more severe the wicking effect. This can occur with oil, caustics, water rinse materials, etc. Alternatives to sparging include low-pressure blowers and mixers.

## Aspirating

Aspirating is using compressed air to induce the flow of another gas with compressed air such as flue gas. An alternative is a low-pressure blower.

## Atomizing

Atomizing is the use of compressed air to disperse or deliver a liquid to a process as an aerosol. An example is atomizing fuel into a boiler. Fluctuating pressure can affect combustion efficiency. An alternative is a low-pressure blower.

## Padding

Padding is using compressed air to transport liquids and light solids. Air is dispensed over the material to be moved. The expansion of the air moves the material. The material is usually only moved short distances. An example is unloading tanks or tank cars. Molecular diffusion and wicking are typical problems

with padding. An alternative is low- to mediumpressure blowers.

## Dilute-Phase Transport

Dilute-phase transport is used in transporting solids, such as powdery material, in a diluted format with compressed air. Molecular diffusion and wicking are typical problems with dilute phase transport. An alternative is a low- or high-pressure blower or a lowpressure air compressor designed for 35 psig. The pressure required depends upon the moisture content and size of the material being transported.

## Dense-Phase Transport

Dense-phase transport is used to transport solids in a batch format. This usually involves weighing a batch in a transport vessel, padding the vessel with compressed air, forcing the batch into a transport line, and moving it in an initial plug with a boost of compressed air at the beginning of the transport pipe. Once the material is moving in a plug, the operation may fluidize the material in a semi-dense or moderatedilute-phase using fluidizers or booster nozzles along the transport path. The material is typically transported to a holding vessel that dispenses it on an as-needed basis using pad air from the secondary transport vessel to move it to the use location. A typical application would be the dense-phase transport of carbon black.

There are typically four compressed air elements to the transport. These elements are control air for the equipment, pad air for the initial transporter, transport air to move it in the piping, and fluidizers or booster nozzles along the transport piping. Most dense-phase manufacturers specify 80 to 90 psig with one single line supporting the entire process. The control air and booster nozzles typically use pressures in the 60 to 70 psig range. The actual article psig required for the pad air and the transport air is typically 30 to 45 psig. Because of the lack of storage in most of these applications and the high-volume, short-cycle transport times, the original equipment manufacturers request 80 to 90 psig and use the entire supply system as the storage tank. As this usually has a negative impact on the plant air system, separate compressors, filters, and dryers are applied to this process at the elevated pressure.

Alternatives include supporting the control air, pad air, and boosters with regulated plant air plus metered storage, and using a two-stage, positive- displacement blower (28 psig) or single-stage compressor (40 to 50 psig) for the transport air. Another alternative is to use metered storage for both the pad air and transport cycle. This necessitates providing the entire requirement from storage and metered recovery per cycle, with a metering adjustment to refill the vessel just before the next transport cycle. The storage should be sized to displace the required air first for the pad and then for the transport cycles within an allowable pressure drop to terminate the transport cycle pressure at the required article pressure. This will flatten the volumetric load on the system, eliminate any impact on other users, and reduce the peak energy required to support the process.

## Vacuum Generation

The term vacuum generation describes applications where compressed air is used in conjunction with a venturi, eductor, or ejector to generate a negativepressure mass flow. Typical applications are hold-downs or 55-gallon, drum-mounted, compressed air vacuum cleaners. This is by far the most inefficient application in industry with less than 4 percent total efficiency, although for very intermittent use (less than 30 percent load factor), compressed air can be a reasonably efficient solution. An alternative is a vacuum pump. If a compressed-air-generated vacuum is required, install a solenoid valve on the compressed air supply line to shut this application off when it is not needed.

Vacuum generators are used throughout industry. Some applications for vacuum generators include:

- • Shop vacuums
- • Drum pumps
- • Palletizers
- • Depalletizers
- • Box makers
- • Packaging equipment
- • Automatic die-cutting equipment.

Vacuum generators are selected for safety, ease of installation, physical size of the generator, the fact that no electricity is required at the point-of-use, and low first cost. Vacuum generators are usually less economical to operate than central vacuum systems.

As a rule, in a base load situation, if the vacuum generator is operating less than 30 percent of the time, it will be more economical to operate than a central vacuum system. Otherwise, vacuum generators are, in

general, less effective at pulling a vacuum and cost as much as five times more to operate than a dedicated vacuum pump. Using vacuum generators for shop vacuums and drum pumps, which are typically peak load applications, could cause another compressor to turn on and stay on until it times out. Having to operate a second compressor because of the added demand associated with a vacuum generator eliminates any apparent savings associated with a vacuum generator, even if it operates only once a day for a short period of time.

A dedicated vacuum pump, or the use of central vacuum system will provide more suction force at a fraction of the cost of vacuum produced by compressed air. In this case, it is significantly more cost effective to provide a system that is designed into the machine from the beginning than to retrofit a piece of equipment. This can be accomplished by being proactive at the time the machine specifications are prepared and the purchase orders issued. Vacuum generators must be applied properly and only after taking life cycle costs into consideration.

Vacuum venturis are a common form for vacuum generation with compressed air systems. In a venturi system, compressed air is forced through a conical nozzle. Its velocity increases and a decrease in pressure occurs. This principle, discovered by 18th century physicist G. B. Venturi, can be used to generate vacuum without a single moving part.

Multi-stage venturi devices provide a more efficient ratio of vacuum flow to compressed air consumed than single-stage venturi devices. Where vacuum requirements vary significantly, or are cyclical with a duty cycle of less than 30 percent, multi-stage, venturi-type vacuum generators with pressure regulators and automatic shut-off controls on the compressed air supply may be more efficient than continuously operating mechanical-vacuum pump systems. These devices also can be equipped with a vacuum switch that signals a solenoid valve to shut off the air supply when a set vacuum level is attained, thus reducing air consumption in non-porous applications. They may also be suitable where it is impractical to have a central vacuum system, particularly where the uses may not be confined to one area.

## Personnel Cooling

Personnel cooling is when operators direct compressed air onto themselves for ventilation. This is dangerous because it can shoot particulates into the skin. A 1/4-inch tube blowing air on an operator can consume 15 to 25 brake horsepower (bhp) of compressed air. An alternative is fractional horsepower fans of 1/4 bhp or less.

## Open Hand-Held Blowguns or Lances

Unregulated hand-held blowing is not only a violation of most health and safety codes, but is also very dangerous. Hand-held blowguns that conform to all occupational health and safety standards should be used.

There are different styles of blowguns that can deliver various airflows, velocities, and concentrations. The proper gun must be selected for each application. Pipes installed in the end of hose and unregulated non-approved guns must not be used. Blowguns must have no more than 30 psig discharge nozzle pressure. The nozzle should be constructed to relieve backpressure if the nozzle is plugged or blocked. The blowgun must also have a spring-operated throttle mechanism so it shuts off automatically if it is dropped.

## Diaphragm Pumps

A common error is to not size diaphragm pumps for the maximum viscosity, highest pressure, and highest volume required. The result is poor performance and an increased supply pressure requirement. Diaphragm pumps are commonly found installed without regulators and speed control valves. Those diaphragm pumps that are installed with regulators are found with the regulators adjusted higher than necessary. This is often because of undersized regulators and supply piping or hose. The higher-than-necessary setting of the regulator increases the demand on the compressed air system and increases operating costs. With a higher pressure setting, the amount of compressed air admitted into the diaphragm chamber is increased above that which is actually required to move the product. The amount of product actually transferred remains the same, but the amount of air used increases with the increased pressure.

The regulator should be adjusted to equal the maximum head that the pump is required to provide. A flow control valve installed up stream of the regulator will accomplish the required speed control. Operating

the diaphragm pump without speed control increases the rate of compressed air consumption by increasing the strokes per minute of the diaphragm pump. The speed control should be adjusted to pump product in the maximum allowable time. As a general rule, the regulator and flow control valve are not included with the standard pump package. Also, when the pump has no liquid or slurry to pump, it will rapid cycle, wearing out the diaphragm and wasting air. The pump controls must be configured to turn the pump off when there is nothing to pump.

## Cabinet Cooling

Cabinet cooling should not be confused with panel purging. The following are typical applications where cabinet cooling is found.

- • Programmable controllers
- • Line control cabinets
- • Motor control centers
- • Relay panels
- • Numerical control systems
- • Modular control centers
- • Computer cabinets.

When first cost is the driving factor, open tubes, air bars (copper tube with holes drilled long the length of the tube) and vortex tube coolers are often used to cool cabinets. When life-cycle costs are taken into consideration, these choices prove to be expensive. It is not uncommon to find an open tube or air bar consuming 7-1/2 horsepower (hp) of compressed air to cool a cabinet. Vortex tube coolers can be an improvement over open tubes and air bars because they are often cycled with a thermostat control, which reduces air consumption. However, air to air, air to water and refrigerated cabinet coolers are available that only use 1/3 hp to accomplish the same task.

## Other Potentially Inappropriate Uses

Other improper uses of compressed air are unregulated end uses and those that supply air to abandoned equipment, both of which are described below.

## Unregulated End Uses

A pressure regulator is used to limit maximum enduse pressure and is placed in the distribution system just prior to the end use. If an end use operates without a regulator, it uses full system pressure. This results in increased system air demand and energy use, since the end use is using air at this higher pressure. High pressure levels can also increase equipment wear, resulting in higher maintenance costs and shorter end use equipment life.

## Abandoned Equipment

Many plants undergo numerous equipment configuration changes over time. In some cases, plant equipment is no longer used. Air flow to this unused equipment should be stopped, preferably as far back in the distribution system as possible without affecting operating equipment.

## Using Compressed Air

As a general rule, compressed air should only be used if safety enhancements, significant productivity gains, or labor reductions will result. Typical overall efficiency is 10 to 15 percent. If compressed air is used for an application, the amount of air used should be the minimum necessary quantity and pressure and should be used for the shortest possible duration. Compressed air use should also be constantly monitored and re-evaluated.

## Compressed Air System Leaks

Leaks can be a significant source of wasted energy in an industrial compressed air system, sometimes wasting 20 to 30 percent of a compressor's output. A typical plant that has not been well maintained will likely have a leak rate equal to 20 percent of total compressed air production capacity. On the other hand, proactive leak detection and repair can reduce leaks to less than 10 percent of compressor output.

In addition to being a source of wasted energy, leaks can also contribute to other operating losses. Leaks cause a drop in system pressure, which can make air tools function less efficiently, adversely affecting production. In addition, by forcing the equipment to run longer, leaks shorten the life of almost all system equipment (including the compressor package itself). Increased running time can also lead to additional maintenance requirements and increased unscheduled downtime. Finally, leaks can lead to adding unnecessary compressor capacity.

While leakage can come from any part of the system, the most common problem areas are:

- · Couplings, hoses, tubes, and fittings
- · Pressure regulators
- · Open condensate traps and shut-off valves
- · Pipe joints, disconnects, and thread sealants.

<!-- image -->

<!-- image -->

| Size   | Cost per Year   |
|--------|-----------------|
| 1/16'  | $523            |
| 1/8'   | $2,095          |
| 1/4'   | $8,382          |

Costs calculated using electricity rate of $0.05 per kilowatt-hour, assuming constant operation and an efficient compressor.

## Estimating Amount of Leakage

For compressors that have start/stop or load/unload controls, there is an easy way to estimate the amount of leakage in the system. This method involves starting the compressor when there are no demands on the system (when all the air-operated, end-use equipment is turned off). A number of measurements are taken to determine the average time it takes to load and unload the compressor. The compressor will load and unload because the air leaks will cause the compressor to cycle on and off as the pressure drops from air escaping through the leaks. Total leakage (percentage) can be calculated as follows:

## Leakage (%) = [(T x 100)/(T+t)]

where:

T = on-load time (minutes) t = off-load time (minutes)

Leakage will be expressed in terms of the percentage of compressor capacity lost. The percentage lost to leakage should be less than 10 percent in a wellmaintained system. Poorly maintained systems can have losses as high as 20 to 30 percent of air capacity and power.

Leakage can be estimated in systems with other control strategies if there is a pressure gauge downstream of the receiver. This method requires an estimate of total system volume, including any downstream secondary air receivers, air mains, and piping (V, in cubic feet). The system is started and brought to the normal operating pressure (P1). Measurements should then be taken of the time (T) it takes for the system to drop to a lower pressure (P2), which should be a point equal to about one-half the operating pressure.

Leakage can be calculated as follows:

Leakage (cfm free air) = (V x (P1-P2)/T x 14.7) x 1.25

where:

V is in cubic feet P1 and P2 are in psig T is in minutes

The 1.25 multiplier corrects leakage to normal system pressure, allowing for reduced leakage with falling system pressure. Again, leakage of greater than 10 percent indicates that the system can likely be improved. These tests should be carried out on a regular basis as part of a leak detection and repair program.

## Leak Detection

Since air leaks are almost impossible to see, other methods must be used to locate them. The best way to detect leaks is to use an ultrasonic acoustic detector, which can recognize the high-frequency hissing sounds associated with air leaks. These portable units consist of directional microphones, amplifiers, and audio filters, and usually have either visual indicators or earphones to detect leaks. A simpler method is to apply soapy water with a paint brush to suspect areas. Although reliable, this method can be time consuming.

## Ultrasonic Leak Detection

Ultrasonic leak detection is probably the most versatile form of leak detection. Because of its capabilities, it is readily adapted to a variety of leak detection situations. The principle behind ultrasonic leak detection is simple. In a pressure or vacuum leak, the leak flows from a high-pressure laminar flow to a low-pressure turbulence. The turbulence generates a white noise which contains a broad spectrum of sound ranging from audible to inaudible frequencies. An ultrasonic sensor focuses in on the ultrasonic elements in the noise. Because ultrasound is a short wave signal, the sound level will be loudest at the leak site. Ultrasonic detectors are generally unaffected by background noises in the audible range because these signals are filtered out.

Ultrasonic detectors can find mid- to large-sized leaks. The advantages of ultrasonic leak detection include versatility, speed, ease of use, the ability to perform tests while equipment is running, and the ability to find a wide variety of leaks. They require a minimum of training, and operators often become competent after 15 minutes of training.

Because of its nature, ultrasound is directional in transmission. For this reason, the signal is loudest at its source. By generally scanning around a test area, it is possible to very quickly hone it on a leak site and pin point its location. For this reason, ultrasonic leak detection is not only fast, it is also very accurate.

## How To Fix Leaks

Leaks occur most often at joints and connections. Stopping leaks can be as simple as tightening a connection or as complex as replacing faulty equipment, such as couplings, fittings, pipe sections, hoses, joints, drains, and traps. In many cases, leaks are caused by failing to clean the threads or by bad or improperly applied thread sealant. Select high quality fittings, disconnects, hose, tubing, and install them properly with appropriate thread sealant.

Non-operating equipment can be an additional source of leaks. Equipment no longer in use should be isolated with a valve in the distribution system.

Another way to reduce leaks is to lower the air pressure of the system. The lower the pressure differential across an orifice or leak, the lower the rate of flow, so reduced system pressure will result in reduced leakage rates. Stabilizing the system header pressure at its lowest practical range will minimize the leakage rate for the system. Once leaks have been repaired, the compressor control system must be re-evaluated to realize the total savings potential.

## Establishing a Leak Prevention Program

There are two basic types of leak repair programs, the leak tag program and the seek and repair program. The seek and repair is the simplest. As it states, you simply find the leak and repair it immediately. With the leak tag program, the leak is identified with a tag and logged for repair at a later time. This is often a two-part tag; one part stays on the leak and the other part is turned into the maintenance department, identifying the location, size, and description of the leak to be repaired. The best approach depends on the type, size, and the culture/work practices of the facility. It is more likely that the best solution will be a combination of the two. In any case, there are several key elements for a successful leak program.

- · Baseline compressed air usage . Establish good grounds for comparison on the effectiveness of the compressed air leak repair program. (See the fact sheet titled ' Baselining Your Compressed Air System. ')
- · Establish leak loss . See the section on estimating leak loss in this fact sheet.
- · Determine cost of air leaks . The cost of compressed air leaks is one of the most important aspects of the program. It should be used as a baseline, not only for the effectiveness and promotion of the program,

but also to illustrate the amount of resources that can cost effectively be allocated to the program.

- · Identify leaks . Survey the facility and identify the leaks. Leaks can be identified by many methods. The most common is using an ultrasonic acoustic leak detector. There are many types and price ranges, but for most applications, the inexpensive handheld meter will identify leaks and give an indication of the size or intensity.
- · Document the leaks . Document the location, type, size, and the estimated cost of the leak. Any documentation should be compatible with the facility's predictive maintenance program. Leak tags can also be used but should not take the place of a master leak list. If you are using the seek and repair method, leaks should still be documented so the number and effectiveness of the program can be tracked.
- · Prioritize leak repair . Fix the biggest leaks first to get the biggest savings. This will ensure a good start to the air leak program.
- · Adjust controls . Once the leaks are fixed, adjust the compressor controls.
- · Document repairs . Showing the fixed leaks and the cost savings shows the effectiveness of the program and strengthens support for it. Documenting the repairs and the type of leaks can also indicate equipment that is a reoccurring problem. When this occurs, look at the process for a root cause and develop a permanent solution to stop the reoccurring air leak.
- · Compare baselines and publish results . By comparing before and after results, the effectiveness of the program and the savings can be determined. Then, tell 'the world' about the program and the results that have been achieved. This is very important because showing the savings will solidify support for the program.
- · Start over again . Air leaks continue to occur, so the program must be ongoing. Periodic reviews should be done on the system, and the process repeated as necessary to maintain system efficiency.

A good compressed air system leak repair program is very important to maintaining the efficiency, reliability, stability, and cost effectiveness of any compressed air system.

## Pressure Drop and Controlling System Pressure

Pressure drop is a term used to characterize the reduction in air pressure from the compressor discharge to the actual point-of-use. Pressure drop occurs as the compressed air travels through the treatment and distribution system. A properly designed system should have a pressure loss of much less than 10 percent of the compressor's discharge pressure, measured from the receiver tank output to the point-of-use.

must be recognized and precautionary measures taken. The control range pressure setting must be reduced to allow for actual and potentially increasing pressure drop across the dryers and filters. Provision also must be made to prevent exceeding the maximum allowable discharge pressure and drive motor amps of each compressor in the system.

Excessive pressure drop will result in poor system performance and excessive energy consumption. Flow restrictions of any type in a system require higher operating pressures than are needed, resulting in higher energy consumption. Minimizing differentials in all parts of the system is an important part of efficient operation. Pressure drop upstream of the compressor signal requires higher compression pressures to achieve the control settings on the compressor. The most typical problem areas include the aftercooler, lubricant separators, and check valves. A rule of thumb for systems in the 100 psig range is: for every 2 psi increase in discharge pressure, energy consumption will increase by approximately 1 percent at full output flow (check performance curves for centrifugal and two-stage, lubricant-injected, rotary screw compressors).

There is also another penalty for higher-than-needed pressure. Raising the compressor discharge pressure increases the demand of every unregulated usage, including leaks, open blowing, etc. Although it varies by plant, unregulated usage is commonly as high as 30 to 50 percent of air demand. For systems in the 100 psig range with 30 to 50 percent unregulated usage, a 2 psi increase in header pressure will increase energy consumption by about another 0.6 to 1.0 percent because of the additional unregulated air being consumed. The combined effect results in a total increase in energy consumption of about 1.6 to 2 percent for every 2 psi increase in discharge pressure for a system in the 100 psig range with 30 to 50 percent unregulated usage.

An air compressor capacity control pressure signal is normally located at the discharge of the compressor package. When the signal location is moved downstream of the compressed air dryers and filters to achieve a common signal for all compressors, some dangers

Pressure drop in the distribution system and in hoses and flexible connections at points-of-use results in lower operating pressure at the points-of-use. If the point-ofuse operating pressure has to be increased, try reducing the pressure drops in the system before adding capacity or increasing the system pressure. Increasing the compressor discharge pressure or adding compressor capacity results in significant increases in energy consumption.

Elevating system pressure increases unregulated uses, such as leaks, open blowing, and production applications, without regulators or with wide open regulators. The added demand at elevated pressure is termed 'artificial demand,' and substantially increases energy consumption. Instead of increasing the compressor discharge pressure or adding additional compressor capacity, alternative solutions should be sought, such as reduced pressure drop and strategic compressed air storage. Equipment should be specified and operated at the lowest efficient operating pressure.

## What Causes Pressure Drop?

Any type of obstruction, restriction, or roughness in the system will cause resistance to air flow and cause pressure drop. In the distribution system, the highest pressure drops usually are found at the pointsof-use, including undersized or leaking hoses, tubes, disconnects, filters, regulators and lubricators (FRLs). On the supply side of the system, air/lubricant separators, aftercoolers, moisture separators, dryers and filters can be the main items causing significant pressure drops.

The maximum pressure drop from the supply side to the points-of-use will occur when the compressed air flow rate and temperature are highest. System components should be selected based upon these conditions and the manufacturer of each component should be requested to supply pressure drop information under these conditions. When selecting filters, remember

that they will get dirty. Dirt loading characteristics are also important selection criteria. Large end users who purchase substantial quantities of components should work with their suppliers to ensure that products meet the desired specifications for differential pressure and other characteristics.

The distribution piping system often is diagnosed as having excess pressure drop because a point-of-use pressure regulator cannot sustain the required downstream pressure. If such a regulator is set at 85 psig and the regulator and/or the upstream filter has a pressure drop of 20 psi, the system upstream of the filter and regulator would have to maintain at least 105 psig. The 20 psi pressure drop may be blamed on the system piping rather than on the components at fault. The correct diagnosis requires pressure measurements at different points in the system to identify the component(s) causing the excess pressure drop. In this case, the filter element should be replaced of the filter regulator size needs to be increased, not the piping.

## Minimizing Pressure Drop

Minimizing pressure drop requires a systems approach in design and maintenance of the system. Air treatment components, such as aftercoolers, moisture separators, dryers, and filters, should be selected with the lowest possible pressure drop at specified maximum operating conditions. When installed, the recommended maintenance procedures should be followed and documented. Additional ways to minimize pressure drop are as follows:

- · Properly design the distribution system.
- · Operate and maintain air filtering and drying equipment to reduce the effects of moisture, such as pipe corrosion.
- · Select aftercoolers, separators, dryers and filters having the lowest possible pressure drop for the rated conditions.
- · Reduce the distance the air travels through the distribution system.
- · Specify pressure regulators, lubricators, hoses, and connections having the best performance characteristics at the lowest pressure differential. These components must be sized based upon the actual rate of flow and not the average rate of flow.

## Controlling System Pressure

Many plant air compressors operate with a fullload discharge pressure of 100 psig and an unload discharge pressure of 110 psig or higher. Many types of machinery and tools can operate efficiently with an air supply at the point-of-use of 80 psig or lower. If the air compressor discharge pressure can be reduced, significant savings can be achieved. Check with the compressor manufacturer for performance specifications at different discharge pressures.

Reducing system pressure also can have a cascading effect in improving overall system performance, reducing leakage rates, and helping with capacity and other problems. Reduced pressure also reduces stress on components and operating equipment. However, a reduced system operating pressure may require modifications to other components, including pressure regulators, filters, and the size and location of compressed air storage.

Lowering average system pressure requires caution because large changes in demand can cause the pressure at points-of-use to fall below minimum requirements, which can cause equipment to function improperly. These problems can be avoided with careful matching of system components, controls, and compressed air storage capacity and location. (See the fact sheet titled Compressed Air System Controls. )

For applications using significant amounts of compressed air, it is recommended that equipment be specified to operate at lower pressure levels. The added cost of components, such as larger air cylinders, usually will be recouped from energy savings. Production engineers often specify end-use equipment to operate at an average system pressure. This results in higher system operating costs. First, point-of-use installation components, such as hoses, pressure regulators, and filters, will be installed between the system pressure and the end-use equipment pressure. Secondly, filters will get dirty and leaks will occur. Both result in lower end-use pressure, which should be anticipated in specifying the available end-use pressure.

Pressure/flow controllers can also be used to control system pressure and are discussed in the fact sheet titled Compressed Air System Controls .

If an individual application requires higher pressure, it may be best to replace or modify this application, instead of raising the operating pressure of the whole system. It may be possible to have a larger diameter cylinder, gear ratios may be changed,

mechanical advantage improved, or a larger air motor may be used.  The cost of improvements probably will be insignificant compared to the energy reduction achieved from operating the system at the lower pressure.

It is also important to check if manufacturers are including pressure drops in filters, pressure regulators, and hoses in their pressure requirements for end-use equipment, or if the pressure requirements as stated are after those components. A typical pressure differential for a filter, pressure regulator, and hose is 7 pounds per square inch differential (psid), but it could be much higher in poorly designed and maintained systems.

When demand pressure has been successfully reduced and controlled, attention then should be turned to the compressor control set points to obtain more efficient operation, and also to possible unloading or shutting off a compressor to further reduce energy consumption.

## Compressed Air System Controls

Compressed air system controls match the compressed air supply with system demand (although not always in real time) and are one of the most important determinants of overall system energy efficiency. This fact sheet discusses both individual compressor control and overall system control of plants with multiple compressors. Proper control is essential to efficient system operation and high performance. The objective of any control strategy is also to shut off unneeded compressors or delay bringing on additional compressors until needed. All units that are operating should be run at full-load, except one unit for trimming.

Compressor systems are typically comprised of multiple compressors delivering air to a common plant air header.  The combined capacity of these machines is generally sized to meet the maximum plant air demand.  System controls are almost always needed to orchestrate a reduction in the output of the individual compressor(s) during times of lower demand. Compressed air systems are usually designed to operate within a fixed pressure range and to deliver a volume of air that varies with system demand. System pressure is monitored and the control system decreases compressor output when the pressure reaches a predetermined level. Compressor output is then increased again when the pressure drops to a lower predetermined level.

The difference between these two pressure levels is called the control range. Depending on air system demand, the control range can be anywhere from 2 to 20 psi. In the past, individual compressor controls and non-supervised multiple machine systems were slow and imprecise. This resulted in wide control ranges and large pressure swings. As a result of these large swings, individual compressor pressure control set points were established to maintain pressures higher than needed. This ensured that swings would not go below the minimum requirements for the system. Today, faster and more accurate microprocessor-based system controls and variable speed compressors with tighter control ranges allow for a drop in the system pressure set points. Precise control systems are able to maintain lower average pressure without going below minimum system requirements.

A rule of thumb for systems in the 100 psig range is: for every 2 psi increase in discharge pressure, energy consumption will increase by approximately 1 percent at full output flow (check performance curves for centrifugal and two-stage, lubricant-injected, rotary screw compressors). There is also another penalty for higher-than-needed pressure. Raising the compressor discharge pressure increases the demand of every unregulated usage, including leaks, open blowing, etc. Although it varies by plant, unregulated usage is commonly as high as 30 to 50 percent of air demand. For systems in the 100 psig range with 30 to 50 percent unregulated usage, a 2 psi increase in header pressure will increase energy consumption by about another 0.6 to 1.0 percent because of the additional unregulated air being consumed. The combined effect results in a total increase in energy consumption of about 1.6 to 2 percent for every 2 psi increase in discharge pressure for a system in the 100 psig range with 30 to 50 percent unregulated usage.

Caution must be taken when lowering average system header pressure, because large, sudden changes in demand can cause the pressure to drop below minimum requirements, which can lead to improper functioning of equipment. With careful matching of system controls and storage capacity, these problems can be avoided.

## Controls and System Performance

Few air systems operate at full-load all of the time. Part-load performance is therefore critical, and is primarily influenced by compressor type and control strategy. The type of control specified for a given system is largely determined by the type of compressor being used and the facility's demand profile. If a system has a single compressor with a very steady demand, a simple control system may be appropriate. On the other hand, a complex system with multiple compressors, varying demand, and many types of end uses will require a more sophisticated strategy. In any case, careful consideration should be given to both compressor and system control selection because they can be the most important factors affecting system performance and efficiency.

## Individual Compressor Control Strategies

Over the years, compressor manufacturers have developed a number of different types of control strategies. Controls, such as start/stop and load/unload, respond to reductions in air demand, increasing compressor discharge pressure by turning the compressor off or unloading it so that it does not deliver air for periods of time. Modulating inlet and multi-step controls allow the compressor to operate at part-load and deliver a reduced amount of air during periods of reduced demand.

Start/Stop . Start/stop is the simplest control available and can be applied to either reciprocating or rotary screw compressors. The motor driving the compressor is turned on or off in response to the discharge pressure of the machine. Typically, a simple pressure switch provides the motor start/stop signal. This type of control should not be used in an application that has frequent cycling, because repeated starts will cause the motor to overheat and other compressor components to require more frequent maintenance. This control scheme is typically only used for applications with very low-duty cycles for compressors in the 30 horsepower (hp) and under range. Its advantage is that power is used only while the compressor is running, but this is offset by having to compress to a higher receiver pressure to allow air to be drawn from the receiver while the compressor is stopped.

Load/Unload . Load/unload control, also known as constant-speed control, allows the motor to run continuously, but unloads the compressor when the discharge pressure is adequate. Compressor manufacturers use different strategies for unloading a compressor, but in most cases, an unloaded rotary screw compressor will consume 15 to 35 percent of full-load horsepower while delivering no useful work. As a result, some load/unload control schemes can be inefficient.

Modulating Controls . Modulating (throttling) inlet control allows the output of a compressor to be varied to meet flow requirements. Throttling is usually accomplished by closing the inlet valve, thereby restricting inlet air to the compressor. This control scheme is applied to centrifugal and lubricant-injected rotary screw compressors. This control method cannot be used on reciprocating or lubricant-free rotary screw compressor and when applied to lubricant-injected rotary screw compressors, is an inefficient means of varying compressor output. When used on centrifugal compressors, more efficient results are obtained, particularly with the use of inlet guide vanes, which direct the air in the same direction as the impeller inlet. However, the amount of capacity reduction is limited by the potential for surge and minimum throttling capacity.

Inlet-valve modulation used on lubricant-injected rotary air compressors allows compressor capacity to be adjusted to match demand. A regulating valve senses system or discharge pressure over a prescribed range (usually about 10 psi) and sends a proportional pressure to operate the inlet valve. Closing (or throttling) the inlet valve causes a pressure drop across it, reducing the inlet pressure at the compressor and, hence, the mass flow of air. Since the pressure at the compressor inlet is reduced while discharge pressure is rising slightly, the compression ratios are increased so that energy savings are somewhat limited.

Inlet valve modulation is normally limited to a range of from 100 percent to about 40 percent of rated capacity. When operating at 40 percent rated capacity and when discharge pressure reaches full load pressure plus 10 psi, it is assumed demand is insufficient to require continued air discharge to the system. At this point the compressor will operate fully unloaded, like a compressor using load/unload controls.

Dual-Control/Auto-Dual . For small reciprocating compressors, dual-control allows the selection of either start/stop or load/unload. For lubricant-injected rotary screw compressors, auto-dual control provides modulation to a preset reduced capacity followed by unloading with the addition of an overrun timer to stop the compressor after running unloaded for a pre-set time.

Variable Displacement . Some compressors are designed to operate in two or more partially loaded conditions. With such a control scheme, output pressure can be closely controlled without requiring the compressor to start/stop or load/unload.

Reciprocating compressors are designed as two-step (start/stop or load/unload), three-step (0, 50, 100 percent) or five-step (0, 25, 50, 75, 100 percent) control. These control schemes generally exhibit an almost direct relationship between motor power consumption and loaded capacity.

Some lubricant-injected rotary screw compressors can vary their compression volumes (ratio) using sliding or turn valves. These are generally applied in conjunction with modulating inlet valves to provide more accurate pressure control with improved part-load efficiency.

Variable Speed Drives . Variable speed is accepted as an efficient means of rotary compressor capacity control, using integrated variable frequency AC or switched reluctance DC drives. Compressor discharge pressure can be held to within +/- 1 psi over a wide range of capacity, allowing additional system energy savings.

Rotary screw compressors with fixed-speed drives can only be stopped and started a certain number of times within a given time frame. Depending on the control scheme used, instead of stopping the compressor, it will be unloaded, throttled, or the compressor displacement will be varied in applications where the demand for air changes over time. In some cases, these control methodologies can be an inefficient way to vary compressor output. Compressors equipped with variable speed drive controls continuously adjust the drive motor speed to match variable demand requirements.

In a positive-displacement rotary compressor, the displacement is directly proportional to the rotational speed of the input shaft of the air end. However, it is important to note that with constant discharge pressure, if efficiency remained constant over the speed range, the input torque requirement would remain constant, unlike the requirement of dynamic compressors, fans, or pumps. The actual efficiency also may fall at lower speeds, requiring an increase in torque. Electric motors and controllers are currently available to satisfy these needs, but their efficiency and power factor at reduced speeds must be taken into consideration. Steam turbines and engines also are variable speed drivers but are rarely used to power industrial air compressors.

## Capacity Controls for Centrifugal Type Compressors.

Centrifugal compressors have complex characteristics affected by inlet air density and interstage cooling water temperature. The basic characteristic curve of head (pressure) versus flow is determined by the design of the impeller(s). Radial blades produce a very low rise in head as flow decreases. Backward leaning blades produce a steeper curve. The greater the degree of backward leaning, the steeper the curve.

Two potential occurrences must be avoided. The first is surge, caused by a flow reversal, which can occur at low flow rates and can cause damage to the compressor. Surge is avoided by limiting the amount of flow reduction. The second is choke at flow rates above design, when the velocity of the air at the impeller inlet approaches the speed of sound and flow and head cannot be sustained. Choke, or stonewall, is normally avoided by sensing drive motor amps and using this signal to limit the flow rate.

The flow rate can be reduced by an inlet throttle valve, which reduces the pressure at the inlet to the first stage impeller. This reduces the mass flow in direct proportion to the absolute inlet pressure. The inlet air density also is reduced, resulting in reduced pressure head produced by the impeller.

A variation of this uses inlet guide vanes, which also reduce the mass flow and the inlet air density, but cause the air to be directed radially towards the impeller inlet in the same direction as the impeller rotation. This improves the efficiency compared with simple throttling. In some cases, discharge bypass or blow-off control is used to limit flow delivered to the compressed air system. Compressed air is discharged to the atmosphere through a discharge silencer or cooled and returned to the compressor inlet. This is a waste of energy and should be used only where necessary.

## Multiple Compressor Control

Systems with multiple compressors use more sophisticated controls to orchestrate compressor operation and air delivery to the system. Network controls use the on-board compressor controls' microprocessors linked together to form a chain of communication that makes decisions to stop/start, load/unload, modulate, vary displacement, and vary speed. Usually, one compressor assumes the lead with the others being subordinate to the commands from this compressor. System master controls coordinate all of the functions necessary to optimize compressed air as a utility. System master controls have many functional capabilities, including the ability to monitor and control all components in the system, as well as trending data to enhance maintenance functions and minimize costs of operation. Other system controllers, such as pressure/flow controllers, can also substantially improve the performance of some systems.

The objective of an effective automatic system control strategy is to match system demand with compressors operated at or near their maximum efficiency levels. This can be accomplished in a number of ways, depending on fluctuations in demand, available storage, and the characteristics of the equipment supplying and treating the compressed air.

Network Controls. Less sophisticated network controls use the cascade set point scheme to operate the system as a whole. Those systems are capable of avoiding part load compressors but can still present the problem of approaching production's minimum pressure requirement as more and more compressors are added and the range of compressor load and unload set points increases.

The more sophisticated network control systems use single set-point logic to make their operational decisions to start/stop, etc. In systems with positivedisplacement compressors (reciprocating, rotary screws, etc.) all compressors are kept fully loaded except for one compressor that is operated in some part-load fashion specific to the design of the machine.

Three major disadvantages of network system controls are:

- • They are capable of controlling only air compressors.
- · They cannot be networked with remote compressor rooms without a master control of some type.
- · Typically they only work with compressors of the same brand and configuration because of micro processor compatibility issues.

Expensive upgrades or retrofits may be required to make different brands of compressors or older versions of the same brand work in the system. In some cases, retrofits are not available and a different brand or outdated compressors cannot be used in the control scheme.

There are no network controls available that can coordinate the control of rotary screw, reciprocating, and centrifugal compressors as one system. To do this, system master controls are required, particularly if there is a desire to monitor and operate compressors, cooling systems, dryers, filters, traps, storage, pressure/ flow controllers, and any other part of a compressed air system that a facility might want included in the control scheme.

System Master Controls. If complexity outpaces the capabilities of local and network controls, a system master control is required to coordinate all of the functions necessary to optimize compressed air as a utility. System master controls have many functional capabilities, including the ability to monitor and control all components in the system, as well as to trend data to enhance maintenance functions and minimize costs of operation. System master controls interface with all brands and types of air compressors, and can coordinate the operation of satellite compressor rooms spread around the facility, or in different buildings across an industrial campus. The primary function of these controls, as with the network controls, is to operate a multiple compressor system in harmony. The least sophisticated have few if any of the features mentioned above and use cascading set-point logic to control compressors. The most sophisticated, state-ofthe-art system master controls use single-point control logic with rate-of-change dynamic analysis to make decisions regarding how the compressed air system responds to changes. These changes can occur on the demand side, supply side, or in the ambient conditions. All affect the performance of the system and have a role in how the system should respond. Some of these require short duration support, such as additional storage. Others require additional compressor power to be brought online, and some will require a combination of both.

A properly configured system master control can determine the best and most energy-efficient response to events that occur in a system. The number of things a system master control can interface with is governed by practicality and cost limitations. System master control layout has the capability to perform these functions:

- • Send/receive communications
- • Communicate with a plant information system
- · Monitor weather conditions to adjust operational parameters
- • Adjust pressure/flow controller set points
- • Monitor dryer dew point(s)
- • Monitor filter differential pressure
- • Monitor condensate trap function
- • Start/stop and load/unload compressors
- • Change base/trim duties
- · Select appropriate mix of compressors to optimize efficiency
- · Select which compressor should be started/stopped relative to change in system demand.

Typically it will cost $300 to $1,500 in hardware per data collection point. Some of the latest system master controls integrate the functions of real-time pricing systems, peak shaving with natural gas driven compressors, and aggregate system operation.

## Pressure/Flow Controllers

Pressure/flow controllers are system pressure controls used in conjunction with the individual compressor or system controls described previously. A pressure/flow controller does not directly control a compressor and is generally not included as part of a compressor package. This is a device that serves to separate the supply side of a compressor system from the demand side. This may require compressors to be operated at an elevated pressure and therefore, increased horsepower (but possibly fewer  compressors and/or shorter periods of operation), while pressure on the demand side can be reduced to a stable level to minimize actual compressed air consumption.

Storage, sized to meet anticipated fluctuations in demand, is an essential part of the control strategy. Higher pressure supply air enters the primary storage tanks from the air compressors and is available to reliably meet fluctuations in demand at a constant lower pressure level.

To function properly, pressure/flow controllers require a properly sized primary air receiver located upstream. The pressure swing caused by the multiple compressor control band is relegated to the primary receiver, while the pressure/flow controller controls the plant header pressure in a lower, much narrower pressure range. The primary air receiver shields the compressors from severe load swings, which may keep the next compressor from starting. Lowering and controlling system pressure downstream of the primary receiver can result in reducing energy consumption by 10 percent or more, if most of the end uses had not been properly pressure regulated. This also presumes that compressor controls efficiently handle the decrease in demand.

A well designed and managed system should include some or all of the following:

- • Overall control strategy
- • Demand control
- • Good signal locations
- • Compressor controls
- • Storage.

The goal is to deliver compressed air at the lowest stable pressure to the main plant distribution system and to support transient events as much as possible with stored higher pressure compressed air. Primary storage replacement should utilize the minimum compressor horsepower to restore the primary pressure to the required level.

Each compressed air system differs in supply, distribution, and demand aspects, which require proper evaluation of the benefits to the system of a pressure/flow controller. Additional primary and/or secondary air receivers may also address intermittent loads, which can affect system pressure and reliability, and may allow operating the compressor at the lowest possible discharge pressure and input power.

## Compressed Air Storage

Storage can be used to control demand events (peak demand periods) in a compressed air system by reducing both the amount of pressure drop and the rate of decay. Storage can be used to protect critical pressure applications from other events in the system. Storage can also be used to control the rate of pressure drop to end uses. For some systems, it is important to provide a form of refill control, such as a flow control valve. Many systems have a compressor operating in modulation to support demand events, and sometimes strategic storage solutions can allow for this compressor to be turned off.

## Controls and System Performance

The basic purpose of an air receiver is to store a volume of compressed air for use when needed. The most common example is a small, air-cooled, pistontype compressor, mounted on a tank or air receiver. The compressor operates on a start/stop control system, usually controlled by a pressure switch having a fixed differential. For automotive applications, the compressor is normally stopped at a pressure of 175 psig. The compressor is restarted when the use of the compressed air causes the pressure to fall to about 145 psig (a differential of 30 psi).

On larger compressor sizes, the compressor may be loaded and unloaded in a range of 145 to 160 psig, but it continues to run. The tank provides radiant cooling and requires an automatic drain to remove condensate. The problem from an energy standpoint is that all of the air is being compressed to at least 145 psig and most of it to 160 psig, although most applications require a much lower pressure. Pneumatic tools are normally designed for operation at 90 psig, so energy is being expended to compress the air well beyond what is needed. A rule of thumb for systems in the 100 psig range is: for every 2 psi increase in discharge pressure, energy consumption will increase by approximately 1 percent at full output flow (check performance curves for centrifugal and two-stage, lubricant-injected, rotary screw compressors).

There is also another penalty for higher-thanneeded pressure.  Raising the compressor discharge pressure increases the demand of every unregulated usage, including leaks, open blowing, etc. Although it varies by plant, unregulated usage is commonly as high as 30 to 50 percent of air demand. For systems in the 100 psig range with 30 to 50 percent unregulated usage, a 2 psi increase in header pressure will increase energy consumption by about another 0.6 to 1.0 percent because of the additional unregulated air being consumed. The combined effect results in a total increase in energy consumption of about 1.6 to 2 percent for every 2 psi increase in discharge pressure for a system in the 100 psig range with 30 to 50 percent unregulated usage.

In industrial compressed air systems, the supply side is generally considered to be the air compressors, dryers and related filters, and a primary air receiver. There are two differing points of view on the location of a primary air receiver in a plant air system. If the receiver is located soon after the compressor discharge and the compressor(s) is a piston-type, the receiver acts as a dampener for pressure pulsations. If the receiver is located before the compressed air dryer, the receiver will provide additional radiant cooling and drop out some of the condensate and entrained oil, benefiting the dryer. However, the receiver will be filled with saturated air, and if there is a sudden demand that exceeds the capacity rating of the compressor and matching dryer, the dryer can be overloaded, resulting in a higher pressure dew point.

If the air receiver is located after the compressed air dryer, some of the above advantages are lost. However, the receiver is filled with compressed air (which has been dried), and a sudden demand in excess of the compressor and dryer capacity rating will be met with dried air. The dryer is not overloaded, since it is seeing only the output of the compressor, so the pressure dew point is not affected. One way to resolve this dilemma is to install storage both upstream and downstream of the dryer, remembering that the storage downstream of the dryer must be equal to or larger than the storage upstream of the dryer. In any case, it should be recognized that the compressed air dryer and associated filters will add pressure drop. This must be taken into account when determining the compressor discharge pressure to achieve the desired

pressure that leaves the primary air receiver to the system.

The size of an air receiver can be calculated as follows:

<!-- formula-not-decoded -->

## where:

- V = Receiver volume, cubic feet
- T = Time allowed (minutes) for pressure drop to occur
- C = Air demand, cubic feet per minute (cfm) of free air
- Pa = Absolute atmospheric pressure, psia
- P1 = Initial receiver pressure, psig
- P2 = Final receiver pressure, psig

The formula assumes the receiver volume to be at ambient temperature and that no air is being supplied to the air receiver by the compressor(s). If the compressor(s) is running while air is being drawn from the receiver, the formula should be modified so that C is replaced by C - S, where S is the surplus compressor capacity, cfm of free air. The initial formula also can be used with a known receiver size, to determine the time to restore the air receiver pressure. In this case, C is replaced by S, which is the compressor capacity, cfm of free air.

In the past, mainly with reciprocating compressors, the rule of thumb for sizing a primary air receiver, has been from 1 gallon per cfm to 3 gallons per cfm of compressor capacity. This is no longer regarded as good practice and the recommended primary receiver size will vary with the type of compressor and capacity control used.

Some lubricant-injected rotary screw compressors are sold with load/unload capacity control, which is claimed to be the most efficient. This can also be misleading, because an adequate receiver volume is essential to obtain any real savings in energy.

One solution sometimes proposed is to eliminate modulation and have the compressors operate in a load/unload mode. Certain factors must be recognized before making such a change. The standard fullcapacity, full-load pressure, often has the compressor running at around 110 percent of motor nameplate rating, or using 10 percent of the available 15 percent continuous overload service factor. The remaining 5 percent is meant to cover tolerances and items such as increased pressure drop through the air/lubricant separator before it is required to be changed.

If the discharge pressure is allowed to rise by an additional 10 psi without the capacity being reduced by inlet valve modulation, the bhp will increase by 5 percent and the motor could be overloaded. A reduction in discharge pressure may be necessary to operate in this mode.

In addition, for lubricant-injected rotary screw compressors it is falsely assumed that a straight line, from full-load bhp to unloaded bhp, represents the actual power requirement in this mode of operation. This presumes, for example, that if the average capacity is 50 percent, the compressor would run fully loaded 50 percent of the time and fully unloaded 50 percent of the time. Unfortunately, the compressor is not fully unloaded 50 percent of the time.

When the compressor discharge pressure reaches the unload set point, the inlet valve is closed to reduce the mass flow through the compressor. Simultaneously, the lubricant sump/separator vessel pressure is gradually relieved. Typically, this takes about 40 seconds to prevent foaming of the lubricant with the potential of excessive lubricant carryover. The rate at which blowdown occurs gradually slows as the pressure is reduced. The fully unloaded power is not realized until the pressure in the lubricant sump/separator is fully relieved. In addition, a period of about 3 seconds is required to repressurize the air/lubricant sump/separator vessel when the system calls for the compressor to reload.

In many cases, the system pressure will fall and the compressor will reload before the fully unloaded power is realized. To overcome this, an adequately sized air receiver and/or system volume is essential. Taking the above factors into account, Figure 2.5 shows the effect of different sizes of air receiver/system volume. Some rules of thumb established many years ago for reciprocating air compressors are not adequate for a lubricant-injected rotary screw compressor.

Most lubricant-injected rotary screw compressors are equipped with capacity control by inlet valve modulation designed to match the output from the air compressor with the demand from the points-of-use. On this basis, it has been stated that an air receiver is not needed. At best, this is misleading. An air receiver near the discharge of a rotary screw compressor will shield the compressor control system from pressure fluctuations from the demand side downstream of the receiver, and can allow the compressor to be unloaded for a longer period of time, during periods of light

Figure 2.5  Effect of Receiver Capacity on Lubricant-Injected, Rotary Compressor with Load/Unload Capacity Control.

<!-- image -->

demand. The addition of an over-run timer (automatic dual control) can stop the compressor if it runs unloaded for a preset time, saving additional energy.

The top line in Figure 2.6 shows what would happen if inlet valve modulation was used without unloading the compressor.

Approximately 70 percent of full-load power would still be used when modulation had reduced compressor output to zero. The second line shows inlet valve throttling to 40 percent capacity and unloading at that point. Figure 2.7 shows variable displacement (slide/turn/spiral/poppet valve)

Figure 2.6  Lubricant-Injected Rotary Compressor with Inlet Valve Modulation.

<!-- image -->

Figure 2.7  Lubricant-Injected Rotary Compressor Performance with Variable Displacement.

<!-- image -->

capacity reduction to 50 percent capacity followed by throttling to 40 percent capacity and unloading at that point.

of 10 to 15 percent. The appropriate amount of storage volume should be considered for each of these scenarios.

Variable speed may be achieved by variable frequency AC drives, or by switched reluctance DC drives. Each of these has its specific electrical characteristics, including inverter and other losses. Figure 2.8 shows how input power varies by percent capacity output for a lubricant-injected rotary screw compressor with variable speed control.

Air-end displacement is directly proportional to rotor speed, but air-end efficiency depends upon male rotor tip speed. Most variable speed drive (VSD) package designs involve full capacity operation above the optimum rotor tip speed, at reduced air-end efficiency and increased input power, when compared with a constant speed compressor of the same capacity, operating at or near its optimum rotor tip speed. Efficiency with VSD is generally improved at reduced capacities. The best energy savings are realized in applications where the running hours are long, with a high proportion in the mid- to low-capacity range. Some designs stop the compressor when a lower speed of around 20 percent is reached, while others may unload at 40 to 50 percent, with an unloaded power

Field conversion of an existing compressor to variable speed drive must consider the electric motor, the proposed male rotor tip speed at 100 percent capacity and the reduction of air-end efficiency at reduced speeds and capacity. The potential impacts of harmonics on other end-use equipment must also be considered.

It should be noted that in systems with multiple compressors and sequencing controls, it is possible to have most of the compressors running fully loaded on base load with only one compressor modulating (operating as the 'trim' compressor), providing the most efficient mode for the system. In addition, it is not necessary to have the air receiver/system storage capacity based upon the total capacity of all the compressors, provided they are not all on the same load and unload pressure settings.

A primary air receiver allows the compressor(s) to operate in a given discharge pressure range (usually 10 psi) from load to unload. Multiple compressors also can be sequenced as needed and with all but one operating in the most efficient, fully loaded mode. The capacity of the one compressor is modulated or

Figure 2.8  Lubricant-Injected Rotary Compressor Performance with Variable Speed Control.

<!-- image -->

operated in load/unload control. This is also a good application for variable displacement, or compressors with variable displacement or VSD control to match system demand.

## Secondary Air Receivers

unfired pressure vessel requirements and have appropriate pressure relief valves. An automatic drain device, with manual bypass for service, should also be included. Condensate removed should be decontaminated to meet appropriate federal, state and local codes.

In many industrial plants, there will be one or more applications with an intermittent demand of relatively high volume. This can cause severe dynamic pressure fluctuations in the whole system, with some essential points-of-use being starved, impacting the quality of the end product. Usually, this can be relieved by the correct sizing and location of a secondary air receiver close to the point of high intermittent demand. Such demand is often of short duration, and the time between the demand events is such that there is ample time to replenish the secondary receiver pressure without adding compressor capacity. A check valve before the secondary air receiver will prevent back flow to the rest of the system and ensure that the required volume is stored to meet the anticipated event(s).

Correctly sized and located air receivers can provide major advantages in a compressed air system and require little maintenance. They should meet the American Society of Mechanical Engineers (ASME)

Additional pressure/flow controls can be added after the primary receiver to maintain a reduced and relatively constant system pressure and at points-of-use, while allowing the compressor controls to function in the most efficient control mode and discharge pressure range, with significant energy savings.

## Proven Opportunities at the Component Level

In some cases, taking a systems approach to analyzing compressed air systems can facilitate the analysis of an individual component as well as performance issues relating to individual system components. In general, compressed air systems contain five major sub-systems: 1) compressors; 2) prime mover; 3) controls; 4) air treatment equipment and other accessories; and 5) the air distribution sub-system. Performance aspects of each of these sub-systems are discussed in detail below.

## Compressors

reduced vibration and noise; reduced floor space requirements; and the ability to be installed on a level industrial plant floor. Rotary screw compressors provide continuous flow and do not have the type of pressure pulsations typically associated with reciprocating compressors. Two-stage rotary screw compressors are generally more efficient than single-stage units. Lubricant-injected rotary screw compressors are typically less efficient than two-stage, double-acting reciprocating compressors or three-stage centrifugal compressors. In general, rotary screw compressors are also less efficient at part-load than reciprocating compressors.

While there are many different types of compressors, all compressor types theoretically operate more efficiently if they are designed to include multiple stages. With multiple stages, the final discharge pressure is generated over several steps, thereby saving energy. Many multi-stage compressors save energy by cooling the air between stages, reducing the volume and work required to compress the air. In spite of this, many industrial compressors only have a single stage because equipment manufacturing costs are lower. Performance and efficiency issues of the three most common types of compressors-single- and double-acting reciprocating compressors, rotary compressors, and centrifugal compressors-are discussed below.

Single- and Double-Acting Reciprocating Compressors. In the past, reciprocating air compressors were the most widely used in industrial plant air systems. Single-acting reciprocating compressors are generally air-cooled, in the smaller hp sizes, and do not require substantial foundations. However, these compressors are less efficient than other types. Double-acting reciprocating air compressors are generally watercooled and require substantial foundations. Multi-stage versions are usually considered to be the most efficient air compressors but have high initial and installation costs and higher maintenance requirements.

Rotary Compressors. Today, lubricant-injected rotary screw compressors are used in most industrial plant air applications and for large applications in the service industries. They have some advantages over reciprocating compressors, including lower initial installation and maintenance costs; smaller size;

A wide range of models is usually available from different manufacturers for any given application. Users should try to select the most efficient model available. (See Appendix B titled Packaged Compressor Efficiency Ratings .)

Centrifugal Compressors. The use of centrifugal compressors is usually limited to higher volume industrial plant applications, such as chemical manufacturing, textile plants, petroleum refining, or general plant air systems in larger manufacturing facilities. The compressors operate at high speeds and therefore use smaller, more compact equipment. In larger sizes, three-stage centrifugal compressors are generally more efficient than rotary screw compressors and can approach the efficiency levels of double-acting reciprocating compressors. Centrifugal air compressors typically have 100 to 125 psig discharge pressures and are generally available from 150 hp or larger, with an increasing number of stages and improving efficiency as size increases. Centrifugal compressors are best suited to applications where demand is relatively constant or in industrial plants where they can be used primarily for base-load operation, allowing other compressor types to be as used as trim machines to meet peak demands.

Lubricant-Free Compressors. Lubricant-free versions of reciprocating and rotary air compressors are available. Centrifugal air compressors are inherently lubricantfree. Lubricant-free compressors may be appropriate for specific applications or to meet specific environmental regulations. Lubricant-free rotary screw and reciprocating compressors are generally less efficient than lubricant-injected machines.

## Advantages and Disadvantages of Each Compressor Type

Advantages and disadvantages of any compressor are based on its characteristics and application. Advantages and disadvantages listed below are for a typical compressed air system in an industrial plant. The estimated full-load bhp requirement of each compressor type at 100 psig discharge pressure at the compressor, a main drive motor typical efficiency of 92 percent and 0.746 kilowatts (kW)/bhp, the approximate operating costs of operation are obtained.

## Single-Acting, Air-Cooled Reciprocating Air Compressors

Advantages include:

- • Small size and weight
- · Generally can be located close to point-of-use avoiding lengthy piping runs and pressure drops
- • Do not require separate cooling systems
- • Simple maintenance procedures.

Disadvantages include:

- · Lubricant carryover as piston rings wear, which should be avoided
- • Relatively high noise
- • Relatively high cost of compression
- · Generally are designed to run not more than 50 percent of the time, although some can be at 80 percent
- · Generally compress and store the air in a receiver at a pressure higher than required at the point-ofuse. The pressure then is reduced to the required operating pressure but without recovery of the energy used to compress to the higher pressure.

Operating Efficiency:  22 to 24 kW/100 cfm*

## Double-Acting, Water-Cooled Reciprocating Air Compressors

Advantages include:

- · Efficient compression, particularly with multi-stage compressors
- · Three-step (0-50-100 percent) or five-step (0-25-5075-100 percent) capacity controls, allowing efficient part-load operation
- • Relatively routine maintenance procedures.

Disadvantages include:

- · Relatively high first cost compared with equivalent rotary air compressors
- • Relatively high space requirements
- · Relatively high vibrations require high foundation costs
- • Seldom sold as complete independent packages
- · Require flywheel mass to overcome torque and current pulsations in motor driver
- • Repair procedures require some training and skills.

Operating Efficiency:  15 to 16 kW/100 cfm*

## Lubricant-Injected Rotary Screw Compressors

Advantages include:

- • Compact size and complete package
- • Economic first cost
- · Vibration-free operation does not require special foundation
- · Part-load capacity control systems can match system demand
- · Routine maintenance includes lubricant and filter changes.

Disadvantages include:

- · Less efficient full- and part-load operation compared with water-cooled reciprocating air compressors
- · Lubricant carryover into delivered air requires proper maintenance of air/lubricant separator and the lubricant itself.

Operating Efficiency:

18 to 19 kW/100 cfm, single-stage* 16 to 17 kW/100 cfm, two-stage*

## Lubricant-Free Rotary Screw Air Compressors

Advantages include:

- • Completely packaged
- • Designed to deliver lubricant-free air
- • Do not require any special foundations.

Disadvantages include:

- • Significant premium over lubricant-injected type
- • Less efficient than lubricant-injected type
- • Limited to load/unload capacity control and VSD
- · Higher maintenance costs than lubricant-injected type over the life of the machine.

Operating Efficiency: 18 to 22 kW/100 cfm*

## Centrifugal Air Compressors

Advantages include:

- · Completely packaged for plant or instrument air up through 500 hp
- • Relative first cost improves as size increases
- • Lubricant carryover on lubricant cooled units
- • Designed to deliver lubricant-free air

* By taking the estimated full-load bhp requirement of each compressor type at 100 psig discharge pressure at the compressor, a main-drive motor with a typical efficiency of 92 percent and 0.746 kW/bhp, the approximate efficiencies are obtained.

- · Do not require any special foundations. Disadvantages include:
- · Limited capacity control modulation, requiring unloading for reduced capacities
- · High rotational speeds require special bearings, sophisticated monitoring of vibrations and clearances
- • Specialized maintenance considerations.
- Operating Efficiency: 16 to 20 kW/100 cfm*

## Prime Movers

The majority of industrial compressed air systems use electric motors as the prime mover. Standard, three-phase, squirrel-cage induction motors are used in 90 percent of all industrial compressor applications because of their reliability, level of efficiency (85 to 95 percent, depending on size), and excellent starting torque, despite their high inrush current requirements when used with across-the-line magnetic starters. Inrush current is the amount of current required to start the motor and motor-driven equipment, which will exceed 6 times the running current. This inrush can be reduced with the use of  reduced voltage starters. Most major manufacturers of industrial packaged compressed air systems now offer both standard and energy-efficient motors. As of October 24, 1997, standard three-phase induction motors between 1 and 200 hp are required to meet minimum federal efficiency levels. This means that all general-purpose motors are at the efficiency levels of those formerly labeled 'high efficiency' or 'energy-efficient.' Even with these new minimum efficiency levels, there is a range of efficiencies available for any given application, and manufacturers will likely offer lines of premium-efficiency motors that have higher efficiencies than standard-efficiency motors.

Motors can be flange-mounted, connected with a V-belt, or direct-coupled. Proper alignment is critical for all applications. Direct coupling or flange mounting results in the least loss of efficiency, while V-belt applications may allow for more compact packaging. V-belts should always be inspected and tensioned per manufacturer's specification to avoid increased power transmission losses.

Because of the heavy-duty and load cycles on most compressors, it almost always makes sense to buy the most efficient motor available. The incremental cost for a more efficient motor is typically paid back in less than one year from the resulting energy savings. Users should be aware that new energy-efficient motors sometimes have lower available starting torque than standard motors and often have slightly higher operating speeds because of reduced slip. Match operating speeds and torque requirement as closely as possible when replacing a motor.

## Controls

Compressor control mechanisms are used to match the compressed air volume and pressure delivered by the compressor with facility demand. Compressor controls are often the most important factor determining a compressor's ability to perform efficiently at partload. Controls are frequently configured poorly, and proper control strategies can lead to substantial reductions in energy consumption.

For more information on controls and compressed air system performance, see the fact sheet titled Compressed Air System Controls .

## Air Treatment Equipment and Other Accessories

Air treatment equipment must provide for both contaminant removal and preparation of the air for equipment use. The level of air conditioning and accessories needed is often dependent on air quality requirements. For optimum performance, air treatment equipment should be operated as close to manufacturers' design conditions as possible. A discussion of important compressor system accessory equipment and performance follows.

Dryers. Compressed air system performance is typically enhanced by the use of dryers, but since they require added capital and operating costs (including energy), drying should only be performed to the degree that it is needed for the proper functioning of the equipment and the end use.

Single-tower, chemical deliquescent dryers use little energy, but provide pressure dew point suppression of 15 to 50°F below the dryer inlet temperature, depending on the desiccant selected. They are not suitable for some systems that have high drying needs. The approximate power requirement, including pressure drop through the dryer and any associated filtration, but excluding the cost of replacement desiccant, is approximately 0.2 kW/100 cfm.

Refrigerant-type dryers are the most common and provide a pressure dew point of 35 to 39°F, which is acceptable for many applications. In addition to the pressure drop across the dryer (usually 3 to 5 psid), the energy to run the refrigerant compressor must be

considered. Some refrigerant-type dryers have the ability to cycle on and off based on air flow, which may save energy. The power requirement, including the effect of pressure drop through the dryer, is 0.79 kW/100 cfm. Cylinder head unloading dryers are also available (single and two-step) and offer improved part-load performance over conventional refrigerated dryers. Cylinder head unloaders allow discreet steps of control of the refrigerant compressor, just as unloaders allow capacity control of reciprocating air compressors.

Twin-tower, desiccant-type dryers are the most effective in the removal of moisture from the air and typically are rated at a pressure dew point of -40°F. In a pressure-swing regenerative dryer, the purge air requirement can range from 10 to 18 percent of the dryer's rating, depending on the type of dryer. This energy loss, in addition to the pressure drop across the dryer, must be considered. The heated-type requires less purge air for regeneration, as heaters are used to heat the desiccant bed or the purge air. The heater energy must also be considered against the reduction in the amount of purge air, in addition to the pressure drop. Approximate power requirement, including pressure drop through the dryer, is 2.0 to 3.0 kW/100 cfm.

Heat-of-compression dryers are regenerativedesiccant dryers, which use the heat generated during compression to accomplish desiccant regeneration. One type has a rotating desiccant drum in a single pressure vessel divided into two separate air streams. Most of the air discharged from the air compressor passes through an air aftercooler, where the air is cooled and condensed moisture is separated and drained. The cooled air stream, saturated with moisture, passes through the drying section of the desiccant bed, where it is dried and it exits from the dryer. A portion of the hot air taken directly from the air compressor at its discharge, prior to the aftercooler, flows through the opposite side of the dryer to regenerate the desiccant bed. The hot air, after being used for regeneration, passes through a regeneration cooler before being combined with the main air stream by means of an ejector nozzle before entering the dryer. This means that there is no loss of purge air. Drying and regeneration cycles are continuous as long as the air compressor is in operation. This type of dryer requires air from the compressor at sufficiently high temperature to accomplish regeneration. For this reason, it is used almost exclusively with centrifugal or lubricant-free rotary screw compressors. There is no reduction of air capacity with this type of dryer, but an entrainment-type nozzle has to be used for the purge air.

The twin-tower, heat-of-compression dryer operation is similar to other twin-tower, heat-activated, regenerative desiccant dryers. The difference is that the desiccant in the saturated tower is regenerated by means of the heat of compression in all of the hot air leaving the discharge of the air compressor. The total air flow then passes through the air aftercooler before entering the drying tower. Towers are cycled as for other regenerative desiccant-type dryers.

The total power requirement, including pressure drop and compressor operating cost, is approximately 0.8 kW/100 cfm.

Membrane-type dryers can achieve dew points of 40°F but lower dew points to -40°F can be achieved at the expense of additional purge air loss.

Advantages of membrane dryers include:

- • Low installation cost
- • Low operating cost
- • Can be installed outdoors
- • Can be used in hazardous atmospheres
- •
- No moving parts.

Disadvantages of membrane dryers include:

- • Limited to low-capacity systems
- · High purge air loss (15 to 20 percent) to achieve required pressure dew points
- · Membrane may be fouled by oil or other contaminants and a coalescing filter is recommended before the dryer.

The total power requirement, including pressure drop and compressor operating cost is approximately 3 to 4 kW/100 cfm.

Dryer Selection. The selection of a compressed air dryer should be based upon the required pressure dew point and the estimated cost of operation. Where a pressure dew point of less than 35°F is required, a refrigerant-type dryer cannot be used. The required pressure dew point for the application at each pointof-use eliminates certain types of dryers. Because dryer ratings are based upon saturated air at inlet, the geographical location is not a concern. The dryer has a lower load in areas of lower relative humidity, but the pressure dew point is not affected. Typically, the pressure

drop through a compressed air dryer is 3 to 5 psi and should be taken into account in system requirements. Compressed air should be dried only where necessary and only to the pressure dew point required.

Compressed Air Filters. These include particulate filters to remove solid particles, coalescing filters to remove lubricant and moisture, and adsorbent filters for removal of odors and taste. A particulate filter is recommended after a desiccant-type dryer to remove desiccant 'fines.' A coalescing-type filter is recommended before a desiccant-type dryer to prevent fouling of the desiccant bed. A one micron after-filter is necessary to prevent desiccant fines from entering the distribution piping. Additional filtration may also be needed to meet requirements for specific end uses.

Compressed air filters downstream of the air compressor are generally required for the removal of contaminants, such as particulates, condensate, and lubricant. Filtration only to the level required by each compressed air application will minimize pressure drop and resultant energy consumption. Elements should also be replaced as indicated by pressure differential, and at least annually, to minimize pressure drop and energy consumption.

Air Receivers. Air receivers are designed to provide a supply buffer to meet short-term demand spikes that can exceed the compressor capacity. They also serve to dampen reciprocating compressor pulsations, separate out particles and liquids, and make the compressed air system easier to control. In some cases, installing a larger receiver tank to meet occasional peak demands can even allow for the use of a smaller compressor.

In most systems, the receiver will be located just after the dryer. In some cases, it makes sense to use multiple receivers, one prior to the dryer and one closer to points of intermittent use.

Storage. Storage can be used to control demand events (peak demand periods) in the system by controlling both the amount of pressure drop and the rate of decay. Storage can be used to protect critical pressure applications from other events in the system. Storage can also be used to control the rate of pressure drop in demand while supporting the speed of transmission response from supply. Many systems have a compressor operating in modulation to support demand events, and sometimes, strategic storage solutions can allow for this compressor to be turned off. Storage can also help systems ride through a compressor failure or short energy outages.

## Condensate/Lubricant Separators. It is no longer

acceptable to discharge condensate from a compressed air system to sewer lines without treatment to remove contaminants such as entrained lubricants (except for condensate from some lubricant-free compressor systems). Condensate/lubricant separators are available in the marketplace to achieve separation by means of settling tanks and/or permeable membranes. This equipment helps to avoid the potentially high costs of contaminated waste disposal.

Air/Lubricant Separators. The air/lubricant separator in a lubricant-cooled, rotary screw compressor generally starts with a 2 to 3 psid pressure drop at full-load when new. Maintenance manuals usually suggest changing them when there is a 10 to 12 psid pressure drop across the separator. In many cases it may make sense to make an earlier separator replacement, especially if electricity prices are high.

Heat Recovery Systems. Most systems do not employ heat recovery, even though economics can be good, with typical paybacks of less than one year. Heat recovery systems require electricity for fans or pumps, but can decrease the need for fossil fuels usually used for heating. See the fact sheet titled Heat Recovery with Compressed Air Systems for more information on this energy saving opportunity.

## The Air Distribution Sub-System

The air distribution sub-system, which connects the major components, is one of the most important parts of the compressed air system. It is made up of main trunk lines, hoses and valves, drops to specific usage points, pressure regulators and lubricators, additional filters and traps, and supplementary air treatment equipment. It is throughout this sub-system that most leaks occur, energy is lost, and maintenance is required. Equipment should be chosen to avoid excessive pressure drops and leakage.

In addition, consideration of appropriate sizing of equipment and layout will provide for proper air supply, good tool performance, and optimal production. The complete drying, filtration, and distribution system should be sized and arranged so that the total pressure drop from the air compressor to the pointsof-use is much less than 10 percent of the compressor discharge pressure.

Some users bypass automatic condensate traps and leave valves partially open at all times to allow for constant draining. This practice wastes substantial

energy and should never be undertaken. If a floatoperated, automatic condensate drain is not functioning properly, clean and repair it instead of bypassing it. If maintenance of float-operated drain traps is a burden, consider replacing them with more reliable demandtype drain traps.

The efficiency of the entire system can be enhanced by the proper selection, application, installation, and maintenance of each component.

## Maintenance of Compressed Air Systems for Peak Performance

Like all electro-mechanical equipment, industrial compressed air systems require periodic maintenance to operate at peak efficiency and minimize unscheduled downtime.  Inadequate maintenance can have a significant impact on energy consumption via lower compression efficiency, air leakage, or pressure variability. It can also lead to high operating temperatures, poor moisture control, and excessive contamination. Most problems are minor and can be corrected by simple adjustments, cleaning, part replacement, or the elimination of adverse conditions. Compressed air system maintenance is similar to that performed on cars; filters and fluids are replaced, cooling water is inspected, belts are adjusted, and leaks are identified and repaired.

All equipment in the compressed air system should be maintained in accordance with manufacturers' specifications. Manufacturers provide inspection, maintenance, and service schedules that should be followed strictly. In many cases, it makes sense, from efficiency and economic standpoints, to maintain equipment more frequently than the intervals recommended by manufacturers, which are primarily designed to protect equipment.

One way to tell if a system is well-maintained and operating properly is to periodically baseline the system by tracking power, pressure, flow, and temperature. If power use at a given pressure and flow rate goes up, the system's efficiency is degrading. This baselining will also indicate if the compressor is operating at full capacity, and if the capacity is decreasing over time. On new systems, specifications should be recorded when the system is first set up and operating properly. See the fact sheet titled Baselining Compressed Air Systems for more information.

Proper maintenance is essential to compressed air system efficiency and reliability. The key to success requires compressor operators to determine the requirements for each piece of equipment, the necessary resources, and to schedule the maintenance based on the manufacturer's manuals and trend analysis of recorded data. All observations and meter readings should be recorded for compressors, dryers, filters, and any components in the compressor plant. The combination of equipment control panel data, frequent inspections, and log sheets are required to avoid unscheduled system shutdowns, and to utilize the principles of preventive and predictive maintenance. Record the dates of all maintenance and repairs, including a list of all parts that were replaced or serviced.

The maintenance schedules provided in this fact sheet are intended to be used only as a guide. For more exact procedures, always refer to the manufacturer's manuals.

## Stopping for Maintenance

The following procedures should be followed when stopping the compressor for maintenance or service.

Step 1. Per Occupational Safety &amp; Health Administration (OSHA) regulation 1910.147: The Control of Hazardous Energy Source (Lockout/Tagout) , disconnect and lockout the main power source. Display a sign in clear view at the main power switch stating that the compressor is being serviced.

## WARNING!

Never assume a compressor is safe to work on just because it is not operating. It could restart at any time.

Step 2. Isolate the compressor from the compressed air supply by closing a manual shutoff valve downstream (and upstream, if applicable in booster service) from the compressor. Display a sign in clear view at the shutoff valve stating that the compressor is being serviced. Be certain that a pressure relief valve is installed upstream of any isolation valve.

Step 3. Lock open a pressure relief valve within the pressurized system to allow the system to be completely depressurized. NEVER remove a plug to relieve the pressure!

Step 4. Shut off the water cooling supply (watercooled compressors).

Step 5. Open all manual drain valves within the area to be serviced.

Step 6. Wait for the unit to cool before starting to service. (Temperatures of 125°F can burn skin. Some surface temperatures exceed 350°F when the compressor is operating, and just after it is shut down).

Step 7. Refer and give preference to the manufacturer's manuals over these typical maintenance procedures.

## Maintenance Schedules

To assure maximum performance and service life of your compressor, a routine maintenance schedule should be developed. Sample schedules have been included here to help you to develop a maintenance schedule designed for your particular application. Time frames may need to be shortened in harsher environments.

The documentation shipped with your compressor should contain a maintenance schedule checklist. Make copies of this checklist and retain the master to make more copies as needed. On each copy of the checklist, enter dates and initials in the appropriate spaces. Keep the checklist and this fact sheet readily available near the compressor.

## General Maintenance Discussion

Maintenance issues for specific system components are discussed below.

## Compressor Package

The main areas of the compressor package that need maintenance are the compressor, heat exchanger surfaces, air-lubricant separator, lubricant, lubricant filter, and air-inlet filter. The compressor and intercooling surfaces need to be kept clean and foul-free. If they are dirty, compressor efficiency will be adversely affected. Fans and water pumps should also be inspected to ensure that they are operating at peak performance.

The air lubricant separator in a lubricant-cooled, rotary screw compressor generally starts with a 2 to 3 psid pressure drop at full-load when new. Maintenance manuals usually suggest changing them when there is about a 10 psid pressure drop across the separator. In many cases it may make sense to make an earlier separator replacement, particularly if electricity prices are high.

The compressor lubricant and lubricant filter should be changed per manufacturer's specification. Lubricant can become corrosive and degrade both the equipment and system efficiency.

For lubricant-injected rotary compressors, the lubrication is provided to bearings, gears, and intermeshing rotor surfaces. The lubricant also acts as a seal and removes most of the heat of compression. Only a lubricant meeting the manufacturer's specifications should be used.

Inlet filters and inlet piping should also be kept clean. A dirty filter can reduce compressor capacity and efficiency. Filters should be maintained at least per manufacturer's specifications, taking into account the level of contaminants in the facility's air.

## Compressor Drives

If the electric motor driving a compressor is not properly maintained, it will not only consume more energy, but will be apt to fail before its expected lifetime.  The two most important aspects of motor maintenance are lubrication and cleaning.

Lubrication. Too much lubrication can be just as harmful as too little and is a major cause of premature motor failure. Motors should be lubricated per the manufacturer's specification, which can be anywhere from every 2 months to every 18 months, depending on annual hours of operation and motor speed. On motors with bearing grease fittings, the first step in lubrication is to clean the grease fitting and remove the drain plug. High-quality new grease should be added, and the motor should run for about an hour before the drain plug is replaced. This allows excess grease to be purged from the motor without dripping on the windings and damaging them.

Cleaning. Since motors need to dissipate heat, it is important to keep all of the air passages clean and free of obstruction. For enclosed motors, it is vital that cooling fins are kept free of debris. Poor motor cooling can increase motor temperature and winding resistance, which shortens motor life and increases energy consumption.

Belts. Motor V-belt drives also require periodic maintenance. Tight belts can lead to excessive bearing wear, and loose belts can slip and waste energy. Under normal operation, belts stretch and wear and therefore, require adjustment. A good rule of thumb is to examine and adjust belts after every 400 hours of operation. Follow manufacturers recommended tension requirements.

## Air Treatment Equipment

Fouled compressed air treatment equipment can result in excessive energy consumption as well as

poor-quality air that can damage other equipment. All filters should be kept clean. Dryers, aftercoolers, and separators should all be cleaned and maintained per manufacturer's specifications.

Automatic Traps. Most compressed air systems have numerous moisture traps located throughout the system. Traps need to be inspected periodically to ensure that they are not stuck in either the open or closed position. An automatic trap stuck in the open position will leak compressed air; a trap stuck in the closed position will cause condensate to backup and be carried downstream where it can damage other system components. Traps stuck in the open position can be a major source of wasted energy.

End-Use Filters, Regulators, and Lubricators. Point-ofuse filters, regulators, and lubricators are needed to ensure that a tool is receiving a clean, lubricated supply of air at the proper pressure. Filters should be inspected periodically because a clogged filter will increase pressure drop, which can either reduce pressure at the point-of-use or increase the pressure required from the compressor, thereby consuming excessive energy. A filter that is not operating properly will also allow contaminants into a tool, causing it to wear out prematurely. The lubricant level should also be checked often enough to ensure that it does not run dry. Tools that are not properly lubricated will wear prematurely and use excess energy.

## Leaks

Leak detection and repair is an important part of any maintenance program. For more information on finding and fixing leaks, see the fact sheet Compressed Air System Leaks .

## Maintenance Schedules

Establishing a regular, well-organized maintenance program and strictly following it is critical to maintaining the performance of a compressed air system. One person should be given the responsibility of ensuring that all maintenance is performed properly, on schedule, and is adequately documented.

The following are typical recommended minimum maintenance procedures for air-cooled reciprocating compressors; water-cooled, double-acting reciprocating compressors; lubricant-injected rotary compressors; lubricant-free rotary compressors; and centrifugal compressors.

## Routine Maintenance for Air-Cooled Reciprocating Compressors

## Every 8 Hours (or Daily)

- · Maintain lubricant level between high- and low-level marks on bayonet gauge. (Discoloration or a higher lubricant level reading may indicate the presence of condensed liquids). If lubricant is contaminated, drain and replace.
- · Drain receiver tank, drop legs and traps in the distribution system.
- · Give compressor an overall visual inspection and be sure safety guards are in place.
- • Check for any unusual noise or vibration.
- · Check lubricant pressure on pressure lubricated units. Maintain 18 to 20 psig when compressor is at operating pressure and temperature. High-pressure rated compressors should maintain 22 to 25 psig of lubricant pressure.
- • Check for lubricant leaks.

## Every 40 Hours (or Weekly)

- • Be certain pressure relief valves are working.
- · Clean the cooling surfaces of the intercooler and compressor.
- • Check the compressor for air leaks.
- · Check the compressed air distribution system for leaks.
- · Inspect lubricant for contamination and change if necessary.
- · Clean or replace the air intake filter. Check more often under humid or dusty conditions.

## Every 160 Hours (or Monthly)

- • Check belt tension.

## Every 500 Hours (or 3 Months)

- · Change lubricant (more frequently in harsher environments).
- · Check lubricant filter on pressure lubricated units (more frequently in harsher environments).
- • Torque pulley-clamp screws or jam-nut.

## Every 1,000 Hours (or 6 Months)

- · When synthetic lubricant is used, lubricant change intervals may be extended to every 1,000 hours or every 6 months, whichever occurs first (change more frequently in harsher conditions).

- · Inspect compressor valves for leakage and/or carbon build-up. The lubricant sump strainer screen inside the crankcase of pressure-lubricated models should be thoroughly cleaned with a safety solvent during every lubricant change. If excessive sludge build-up exists inside the crankcase, clean the inside of the crankcase as well as the screen. Never use a flammable or toxic solvent for cleaning. Always use a safety solvent and follow the directions provided.

## Every 2,000 Hours (or 12 Months)

- · Inspect the pressure switch diaphragm and contacts. Inspect the contact points in the motor starter.

## Lubrication

Compressors may be shipped without lubricant in the crankcase. Before starting the compressor, add enough lubricant to the crankcase to register between the high and low marks on the dipstick or on bull's eye sight gauge. Use the specified lubricant or consult the manufacturer for recommendations.

Certain synthetic lubricants have proven under extensive testing to minimize friction and wear, limit lubricant carryover, and reduce carbon and varnish deposits. They will support the performance characteristics and life and are highly recommended. Refer to the manufacturer's specifications to determine the correct amount of lubricant and viscosity to use for your model and application. Use the supplier's lubricant analysis program.

## Routine Maintenance for Water-Cooled, Double-Acting Reciprocating Compressors

The following are typical minimum maintenance requirements for this type of compressor.

## Every 8 Hours (or Daily)*

- · Check compressor lubricant level in crankcase and cylinder lubricator and, if necessary, add to level indicated by sight gauge.
- · Check cylinder lubrication feed rate and adjust, as necessary.
- • Check cylinder jacket cooling water temperatures.
- · Check capacity control operation. Observe discharge pressure gauge for proper LOAD and UNLOAD pressures.
- • Drain control line strainer.
- · Check operation of automatic condensate drain trap (intercooler and aftercooler).
- · Drain condensate from discharge piping as applicable (dropleg and receiver).
- · Check intercooler pressure on multi-stage machines, and refer to manufacturer's manual if pressure is not as specified.

## Every 360 Hours (or Monthly)*

- · Check piston rod packing for leaks and for blow-by at gland. Repair or replace as necessary per manufacturer's manual.
- · Inspect lubricant scraper rings for leakage. Replace as necessary per manufacturer's manual.
- • Inspect air intake filter. Clean or replace as necessary.
- • Drain lubricant strainer/filter sediment.
- · Lubricate unloader mechanism per manufacturer's manual.
- · Check motor amperes (amps) at compressor fullcapacity and pressure.

## Every 3,000 Hours (or Semi-Annually)*

- • Perform valve inspection per manufacturer's manual.
- · Inspect cylinder or cylinder liner, through valve port, for scoring.
- • Change crankcase lubricant, if required.
- • Clean crankcase breather, if provided.
- • Change lubricant filter element.
- • Remove and clean control air filter/strainer element.
- • Check all safety devices for proper operation.
- · Perform piston ring inspection on non-lubricated design. Replace as necessary per manufacturer's manual.

## Every 6,000 Hours (or Annually)*

- • Remove and clean crankcase lubricant strainer.
- · Check foundation bolts for tightness. Adjust as necessary.
- · Perform piston ring inspection. Replace as necessary per manufacturer's manual.
- · Check lubricant pressure and adjust as necessary to meet specified operating pressure.
- * Whichever interval is sooner. Experience gained from a well-kept maintenance log may allow the recommended times to be adjusted.

## Routine Maintenance for Lubricant-Injected Rotary Compressor

The following are typical minimum maintenance requirements.

## Periodically/Daily (8 Hours Maximum)

- · Monitor all gauges and indicators for normal operation.
- • Check lubricant level and top off as necessary.
- • Check for lubricant leaks.
- • Check for unusual noise or vibration.
- • Drain water from air/lubricant reservoir.
- • Drain control line filter.

## Weekly

- • Check safety valve operation.

## Monthly

- · Service air filter as needed (daily or weekly if extremely dusty conditions exist).
- • Wipe down entire unit to maintain appearance.
- · Check drive motor amps at compressor full capacity and design pressure.
- • Check operation of all controls.
- · Check operation of lubricant scavenger/return system. Clean, as necessary.

## 6 Months Or Every 1,000 Hours

- • Take lubricant sample.
- • Change lubricant filter.*

## Periodically/Annually

- • Go over unit and check all bolts for tightness.
- • Change air/lubricant separator.
- • Change air filter.
- • Lubricate motors per manufacturer's instructions.
- · Check safety shutdown system. Contact authorized serviceperson.

## Routine Maintenance for Lubricant-Free Rotary Screw Compressor

relatively minimal. The microprocessor control panel monitors the status of the air and lubricant filters. When maintenance to either device is required, the control panel may display the appropriate maintenance message and flash the location on the display as a visual remainder.

Do not remove caps, plugs, and/or other components when compressor is running or pressurized. Stop compressor and relieve all internal pressure before doing so.

## Daily

Following a routine start, observe the various control panel displays and local gauges to check that normal readings are being displayed. Previous records are very helpful in determining the normalcy of the measurements. These observations should be made during all expected modes of operation (i.e., full-load, no-load, different line pressures, and cooling water temperatures).

## After Initial 50 Hours of Operation

Upon completion of the first 50 hours of operation, essential readings of operating conditions should be verified and any necessary adjustments made.

## Every 3,000 Hours of Operation

The following items should be checked every 3,000 hours of operation, although service conditions, such as relative cleanliness of process air or quality of cooling water, may require shorter inspection intervals.

- • Check/change lubricant charge and filter element.
- • Check/change air filter element.
- • Check/change sump-breather filter element.
- • Check/clean control line filter element.
- • Check/clean condensate drain valve.
- · Check condition of shaft coupling element and tightness of fasteners.
- · Measure and record vibration signatures on compressor, gearbox, and motor (optional).
- · Annual rebuilding of the inlet valve is normally recommended.

The following are typical minimum requirements for this type of compressor. Routine maintenance is

Note: Please refer to the motor manufacturer's documentation for recommended maintenance. Keep in mind that the specified type and quantity of lubricating grease for motor bearings is crucial.

* Manufacturers may recommend changing the lubricant filter within the first week of operation to rid the system of foreign matter which may have collected during initial assembly and start-up.

## Every 15,000 Hours of Operation

In addition to those items covered in the 3,000-hour maintenance interval, the following items must also be checked every 15,000 hours of operation, depending upon conditions of service.

- • Operate/test all safety devices.
- • Check/clean heat exchangers.
- • Check/clean blowdown valve.
- • Check operation of balancing switch/valve assembly.
- • Check/clean water regulating valve.
- • Check/clean check valve.
- • Check/clean galvanized interstage pipe work.
- · Check condition of isolation mounts under compressor unit and motor.
- · Check/clean strainer and check valve included in lubricant pump suction line, inside lubricant sump.

Be aware that work on the compressor stages and gearbox must be conducted by manufacturer's personnel only. Any work done by unauthorized personnel can render the manufacturer's equipment warranty null and void.

## Parts Replacement and Adjustment Procedures

Familiarize yourself with the safety guidelines offered in the safety section of the manufacturer's manual before attempting any maintenance on the package.

## Routine Maintenance for Centrifugal Air Compressors

The following are typical maintenance requirements for this type of compressor.

## Daily

- · Record operating air inlet, interstage and discharge pressures and temperatures.
- · Record cooling water inlet and outlet pressures and temperatures.
- • Record lubricant pressure and temperatures.
- • Record all vibration levels.
- • Check air-inlet filter differential pressure.
- • Check proper operation of drain traps.
- • Drain control air filter.
- · Check for leaks, air, water, and lubricant. Repair and clean as necessary.
- • Check lubricant sump level and adjust as necessary.
- · Check drive motor for smooth operation and record amps.

## Every 3 Months

- · Check lubricant filter differential pressure. Replace element as necessary.
- · Check lubricant sump venting system. Replace filter elements as necessary.
- • Check operation of capacity control system.
- • Check operation of surge control system.
- • Check main-drive motor amps at full-load operation.
- · Check automatic drain traps and strainers. Clean and/or replace as necessary.

## Every 6 Months

- · Check air-inlet filter and replace element as necessary.
- · Take oil sample for analysis. Replace lubricant as necessary.

## Annually

- · Inspect intercooler, aftercooler, and lubricant cooler. Clean and/or replace as necessary.
- · Inspect main drive motor for loose mounting bolts, frayed or worn electrical cables, and accumulated dirt. Follow manufacturer's recommendations, including lubrication.
- · Inspect main drive coupling for alignment and required lubrication.
- · Inspect gearbox for loose mounting bolts, vibration, unusual noise or wear and axial clearances per manufacturer's manual.
- · Check impeller inlets and diffusers for signs of wear, rubbing or cracking.
- · Check control panel for complete and proper operation.
- • Check all control valves for proper operation.
- · Check all safety devices for proper settings and operation.
- • Inspect check valve; replace worn parts.

Keep all components/accessories clean and follow all recommended safety procedures.

## Heat Recovery and Compressed Air Systems

As much as 80 to 93 percent of the electrical energy used by an industrial air compressor is converted into heat. In many cases, a properly designed heat recovery unit can recover anywhere from 50 to 90 percent of this available thermal energy and put it to useful work heating air or water.

Typical uses for recovered heat include supplemental space heating, industrial process heating, water heating, makeup air heating, and boiler makeup water preheating. Recoverable heat from a compressed air system however, is usually not hot enough to produce steam directly.

Caution should be applied if the supply air for the compressor is not from outside, and the recovered heat is used in another space, because this can cause a decrease in the static pressure in the cabinet and reduce the efficiency of the compressor. If outside air is used, some return air may be required to avoid damaging the compressor with below freezing air.

Heat recovery systems are available for both airand water-cooled compressors.

## Heat Recovery with Air-Cooled, Rotary Screw Compressors

Heating Air. Air-cooled, packaged, rotary screw compressors are very amenable to heat recovery for space heating or other hot air uses. Ambient atmospheric air is heated by passing it across the system's aftercooler and lubricant cooler, where it extracts heat from both the compressed air and the lubricant that is used to lubricate and cool the compressor.

Because packaged compressors are typically enclosed in cabinets and already include heat exchangers and fans, the only system modifications needed are the addition of ducting and possibly another fan to handle the duct loading and to eliminate any back pressure on the compressor cooling fan. These heat recovery systems can be modulated with a simple, thermostatically controlled hinged vent. When heating is not required -such as in the summer months-the hot air can be ducted outside the building. The vent can also be thermostatically regulated to provide a constant temperature for a heated area.

Hot air can be used for space heating, industrial drying, preheating aspirated air for oil burners, or any other application requiring warm air. As a rule, approximately 50,000 British thermal units (Btu) per hour of energy is available for each 100 cfm of capacity (at full-load).  Air temperatures of 30 to 40°F above the cooling air inlet temperature can be obtained. Recovery efficiencies of 80 to 90 percent are common.

Heating Water. Using a heat exchanger, it is also possible to extract waste heat from the lubricant coolers found in packaged water-cooled, reciprocating or rotary screw compressors and produce hot water. Depending on design, heat exchangers can heat non-potable (gray) or potable water. When hot water is not required, the lubricant is routed to the standard lubricant cooler.

Hot water can be used in central heating or boiler systems, industrial cleaning processes, plating operations, heat pumps, laundries, or any other application where hot water is required. Heat exchangers also offer an opportunity to produce hot air and hot water, and allow the operator some ability to vary the hot air/hot water ratio.

## Heat Recovery with Water-Cooled Compressors

Heat recovery for space heating is not as common with water-cooled compressors because an extra stage of heat exchange is required and the temperature of the available heat is lower. Because many water-cooled compressors are quite large, however, heat recovery for space heating can be an attractive opportunity. Recovery efficiencies of 50 to 60 percent are typical.

## Calculating Energy Savings

When calculating energy savings and payback periods for heat recovery units, it is important to compare heat recovery with the current source of energy for generating thermal energy, which may be a low-price fossil fuel, such as natural gas. The equations in the text box on the next page illustrate the annual energy and costs savings available by recovering heat for space heating from an air-cooled, rotary screw compressor. Applications where the existing heater is less than 85 percent efficient will see proportionally higher savings.

Example:

Example:

## Energy Savings Calculations

Energy savings (Btu/yr) = 0.80 x compressor bhp x 2,545 Btu/bhp-hour x hours of operation

A 100-hp compressor running two shifts, 5 days per week

(0.80) x (100 bhp) x (2,545 Btu/bhp-hour) x (4,160 hours per year) =

846,976,000 Btu per year

where:

0.80 is the recoverable heat as a percentage of the unit's output

2,545 is a conversion factor

Cost savings ($/yr) = [(Energy savings in Btu/yr)/(Btu/unit of fuel) x ($/unit fuel)]/ Primary heater efficiency

Waste heat will be displacing heat produced by a natural gas forced-air system with an efficiency of 85% [(846,976,000 Btu per year)/(100,000 Btu/therm)x($0.60/therm)]/0.85 =

$5,979 per year

- * Cost of operating an additional fan for duct loading has not been included.

## Baselining Compressed Air Systems

The purpose of baselining or benchmarking is to establish current performance levels and costs of a compressed air system, and to correlate the results with your plant's present production levels. As you make improvements to your system, it will be possible to estimate the success by comparing the new measurements with the original baseline.

First, measurements of the system need to be taken. This requires the measurement of power, pressure, flow, and temperature. These measurements will be used in calculations to baseline system performance and energy consumption correlated to the plant production levels. Correlation to plant production levels is required to normalize data and perform an 'apples-to-apples' comparison.

Energy saving measures implemented on both the supply and demand sides of the system, combined with proper compressor controls, will result in reduced energy consumption. This should be documented through continued measurements, again correlated to your plant's production levels.

Some companies will also benchmark their compressed air systems against similar plants in their company, and sometimes even compare individual compressors.

## Tools You Will Need

Properly baselining and monitoring a compressed air system requires the right tools. The following tools are required.

- · Infrared gun-Infrared guns measure heat radiated from a piece of equipment in order to determine the surface temperature.
- · Matched, calibrated pressure gauges or differential pressure gauges.
- · Hook-on amp/volt meter (or kW meter).
- · Data logger-Data loggers are used in conjunction with other measurement devices to record multiple readings over a period of time. Data loggers are used to create plant pressure and energy consumption profiles, and can be important tools in developing a control strategy for a compressed air system.
- · Ultrasonic leak detector-These portable units consist of directional microphones, amplifiers, and audio filters, and usually have either visual indicators or earphones to detect leaks.
- · Flow meter-Factors to consider in selecting flow meters include type (in-line or insertion), ease of installation, life cycle cost (including possible pressure drop, such as orifice plates and maintenance), and accuracy (repeatability and turndown range).

## What To Measure

Baselining a system requires measurement of power, pressure, flow, and temperature under different operating conditions, and also estimating leak load. Each is discussed below. Please refer to all operation and safety instructions provided with measurement equipment before using it.

## Power

Energy is measured in order to estimate the annual electricity consumption of a compressed air system. A hook-on amp/volt meter or a wattmeter will be required. The current and voltage into the compressor should be measured. Full-load and no-load input power to the compressor should be measured.

For three-phase systems, power can be estimated by the following equation.

## kW = 1.73 x volts x amps x power factor* 1,000

(*Assume 0.85 power factor at full-load for 1,800 rpm motors, check with motor manufacturer for more accurate calculations.)

Using a wattmeter provides a direct reading of kW with no calculation or power factor adjustment.

## Pressure

Pressure is measured to give feedback for control adjustments, and to determine pressure drops across equipment. A calibrated pressure gauge is required. The following pressure measurements should be taken when baselining a system.

- • Inlet to compressor (monitor inlet filter)
- · Differential across air/lubricant separator for a lubricated rotary compressor
- • Interstage on multistage machines
- • Pressure differentials, including,
- - Aftercooler
- - Treatment equipment (dryers, filters, etc.)
- - Various points in the distribution system.

## Flow

Flow meters are necessary to measure total flow and to determine consumption. Flow should be measured:

- · During various shifts
- · As energy saving measures are implemented
- · For leaks during non-production periods.

Flow meters should be of the mass flow design to compensate for pressure and temperature variations and, if practical, should be suitable to measure the output of each individual compressor in the system. The mass flow is based upon standard reference conditions, which should be checked for the specific instrument used .

## Temperature

Temperature measurements help to indicate if equipment is operating at peak performance. Generally, equipment that runs hotter than specified parameters is not performing at peak efficiency and requires service. The following temperature measurements should be taken when baselining a system.

- · Aftercooler and intercoolers cold temperature difference or approach temperature of cold water inlet to cooled air outlet. Because dryers are normally designed at 100°F maximum inlet air temperature, some remedial action may be required if aftercooler outlet temperatures exceed 100°F.
- · For rotary-lubricated compressors, the air discharge temperatures must be maintained for reliable compressor performance. Normal operation requires temperatures below 200°F.
- · Inlet air temperature.

## Using Power, Pressure, and Flow to Baseline System Performance and Energy Consumption

Using the techniques described previously, determine both cfm at psig and energy consumption (kW x hours) per unit of production. Always correlate to production levels for a true measure of air compressor system performance.

Other parameters to monitor over time include:

- • cfm at psig per kW
- • psig
- • Pressure drop across various components.

The expectation is that energy use will go down, assuming, of course, that production does not rise with a corresponding increase in the compressed air loads. If production does not rise, and the pressure goes up, adjust controls appropriately.

## Estimating Leak Load

For compressors that use start/stop controls, there is an easy way to estimate the amount of leakage in the system. This method involves starting the compressor when there are no demands on the system (when all the air-operated, end-use equipment is turned off). A number of measurements are taken to determine the average time to load and unload the compressor. The compressor will load and unload because the air leaks will cause the compressor to cycle on and off as the pressure drops from air escaping through the leaks. Total leakage (percentage) can be calculated as follows:

Leakage (%) = [(T x 100)/(T+t)]

where: T=on-load time (minutes) t=off-load time (minutes)

Leakage will be expressed in terms of the percentage of compressor capacity lost. The percentage lost to leakage should be less than 10 percent in a wellmaintained system. Poorly maintained systems can have losses as high as 20 to 30 percent of air capacity and power.

Leakage can be estimated in systems with other control strategies if there is a pressure gauge downstream of the receiver. This method requires an estimate of total system volume, including any downstream secondary air receivers, air mains, and piping (V, in cubic feet). The system is then started and

brought to the normal operating pressure (P1). Measurements should then be taken of the time (T) it takes for the system to drop to a lower pressure (P2), which should be a point equal to about one-half the operating pressure.

Leakage can be calculated as follows:

Leakage (cfm free air ) = (V x (P1-P2)/T x 14.7) x 1.25

where:

V is in cubic feet P1 and P2 are in psig T is in minutes

The 1.25 multiplier corrects leakage to normal system pressure, allowing for reduced leakage with falling system pressure. Again, leakage of greater than 10 percent indicates that the system can likely be improved. These tests should be carried out quarterly as part of a regular leak detection and repair program.

## Determining Your Compressed Air System Analysis Needs

A compressed air system analysis can highlight the true costs of compressed air and identify opportunities to improve efficiency and productivity.

This information is also taken from the CAC's Guidelines for Selecting a Compressed Air Service Provider .

Compressed air system users should consider using an auditor to analyze their compressed air system. A number of firms specialize in compressed air system analysis. System analysis is also performed by electric utilities, equipment distributors and manufacturers, energy service companies, and engineering firms. An informed consumer should be aware that the quality and comprehensiveness of system analysis can vary. Independent auditors should provide recommendations that are systems-neutral and commercially impartial. Independent auditors should neither specify nor recommend any particular manufacturer's products.

A comprehensive compressed air system analysis should include an examination of both air supply and usage and the interaction between the supply and demand. Auditors typically measure the output of a compressed air system, calculate energy consumption in kilowatt-hours, and determine the annual cost of operating the system. The auditor may also measure total air losses caused by leaks and locate those that are significant. All components of the compressed air system are inspected individually and problem areas are identified. Losses and poor performance caused by system leaks, inappropriate uses, demand events, poor system design, system misuse, and total system dynamics are calculated, and a written report with a recommended course of action is provided.

The Compressed Air Challenge ® (CAC) has developed guidelines to define three levels of system analysis services, independent of the type of firm offering these services. These three levels of service include: a walkthrough evaluation (1/2 to 2 days), a system assessment (2 to 5 days), and a fully-instrumented audit (3 to 10 days). More information on these services can by found in the CAC's Guidelines for Selecting a Compressed Air Service Provider. (See Appendix E ) .

## Selecting a Service Provider

In selecting a service provider, a compressed air user should consider the following outlined below.

Familiarity with the Systems Approach. The CAC provides Fundamentals of Compressed Air Systems and Advanced Management of Compressed Air Systems training to end users and service providers. One way to gauge a service provider's commitment to the systems approach is whether they have staff who have received CAC training. If they do, ask whether these individuals will be providing or supervising services for your facility. Providers who are familiar with using a systems approach are much more likely to address situations, both inside and outside the compressor room, that affect the reliability of your compressed air supply.

## Availability of Compressed Air System Analysis Services.

Does the provider offer compressed air system analysis services? If yes, how well do these services fit your needs? If no, can the provider outsource these services to an experienced system specialist? How experienced are the individuals who will be providing these services? Once a walk-through, assessment, or audit is performed, what kind of follow-up services are available to ensure that the recommendations are properly implemented and produce the desired results? Ask for a sample of similar work that the provider has done for others, resumés of the personnel who will be performing the work, and client references. Please note that while leak detection is a useful element of a system assessment, a true system assessment should include much more. See www.compressedairchallenge.org for additional guidance.

Important Note: Recommendations resulting from system analysis activities should provide productneutral solutions to system problems and include, only if needed, performance-based rather than brandbased equipment recommendations.

Compressor Knowledge and Expertise. Does the service provider have the expertise to work on your equipment? Can the service provider work on all types of compressors in your facility? How much experience do the service technicians have? How are the service technicians trained? Is formal schooling involved? Knowledgeable service technicians are worth the

premium price they may demand because of their ability to troubleshoot and get equipment back on line efficiently and effectively.

## System Components and Controls Knowledge and Expertise.

- · Treatment, accessory, and ancillary equipmentDoes the service provider have the expertise to perform refrigeration and other work on dryers and related equipment? Is the service provider capable of servicing the types of filters, drains, distribution and point-of-use equipment found in your facility?
- · System controls-Does the service provider have the diagnostic and technical controls capability to determine how to optimize your existing control configuration and make recommendations for improvements? Can they help network compressors together or remotely monitor, if necessary? Advanced controls can save energy as well as improve reliability through automatic start and stop, as well as turning compressors off that can then serve as back-ups. Advance warning through remote monitoring may help identify a problem before it turns into a major shutdown.

Company Capabilities. Ask about the standards of performance that the prospective service provider has established for:

- · Emergency service response
- · Parts shipments
- · Other factors which may influence your decision, such as:
- - Installation capabilities internally or through a mechanical contractor
- - Emergency rental fleet availability-electric or portable diesel driven.
- · Your company may request information on the service provider's:
- - Financial stability
- - Insurance coverage
- - Compliance with specific government regulations or those of your company.

Service Facilities. Visit the facilities of two or three service providers under consideration to see first hand the type of repair shop and parts warehouse with which you will be dealing.

Important aspects of a basic compressed air system audit are discussed below.

## System Issues

System issues go beyond examining the performance of an individual compressed air system component and, instead, examine how components on both the supply and demand sides of the system interact. Auditors typically address a number of systems issues. These are discussed below, and many are addressed in more detail in other compressed air systems fact sheets.

Level of Air Treatment. The auditor typically examines the compressed air applications and determines the appropriate level of air treatment required for proper operation of the equipment. Actual air quality levels are then measured. If the air is not being treated enough, alternative treatment strategies are recommended. If the air is being overtreated (an indication of energy being wasted), recommendations are made to modify the system. In some cases, only certain end-use equipment requires highly treated air, and the auditor may recommend a system that allows for different treatment levels at different points in the system.

Leaks. The auditor should identify and quantify leaks in the system and recommend a leak management program.

Pressure Levels. An auditor also typically determines the lowest possible pressure level required to operate production equipment effectively.  In many cases, system pressure can be lowered, thereby saving energy. Most systems have one or more critical applications that determine the minimum acceptable pressure in the system. In some cases, the application of dedicated storage or differential reduction on the critical applications will allow a reduction in overall system pressure.

Controls. The existing control system is evaluated to determine if it is appropriate for the system demand profile. Performance gains available from operating the system in a different mode or using an alternative control strategy should be estimated.

Heat Recovery. Auditors will identify potential applications for the use of heat recovery, if it is not already being used.

## Demand-Side Issues

The demand side of the system refers to how compressed air is actually used in the plant.

Distribution System. The overall layout of the distribution system (piping) is examined. Pressure drop and efficiency are measured or estimated, and the effectiveness of the condensate removal system is

evaluated. Simple changes that can enhance system performance are suggested if appropriate.

Load Profile. Auditors typically estimate the compressed air load profile in terms of how the demand in cfm changes over time. A facility with a varying load profile will likely benefit from advanced control strategies. A facility with short periods of heavy demand may benefit from implementing storage options.

To establish the load profile, an auditor will measure system flow and pressure across the system under different demand conditions, while observing the loading effect on the existing compressors. This may require a number of measurements over a 24-hour period (or even several days) if demand varies significantly over time. Auditors may use data logging equipment to obtain both demand and power consumption profiles.

End-Use Equipment. The equipment and processes that use compressed air will also be examined. In some cases, recommendations, such as specifying equipment that operates at a lower pressure, will be made. An auditor may also recommend replacing existing compressed air-powered equipment with equipment that uses a source of energy other than compressed air. (See the fact sheet titled Potentially Inappropriate Uses of Compressed Air. ) Critical pressure applications are examined in detail. Local storage and other modifications may be recommended.

## Supply-Side Issues

The supply side refers to how the compressed air is generated and treated.

Compressor Package. The compressors are evaluated in terms of appropriateness for the application and general appearance and condition. Compressor efficiency is usually estimated based on manufacturersupplied data, corrected to site conditions. The installation is also evaluated in terms of its location, connection to cooling water, and ventilation. A general appraisal and any recommendations for alternative systems are also made.

Filters. Filters are examined for cleanliness and suitability for the application. Pressure drop across the filters is measured to estimate energy losses from the filter. A maintenance schedule for changing the filters, and possibly higher performance filters, may be recommended.

Aftercooler. Aftercooler and separator efficiency, cooling effectiveness, and condensate separation effectiveness are all measured and evaluated, and feasible modifications or alternative systems are recommended.

Dryer. Dryer appropriateness is assessed based on the facility's end-use applications. Dryer size, pressure drop, and efficiency are measured and evaluated. Modifications and replacements are recommended if needed.

Automatic Drains. Location, application, and effectiveness of both supply-side and demand-side drains are evaluated and alternatives recommended if necessary.

Air Receiver/Storage. The effectiveness of the receiver tank is evaluated in terms of location and size, and the receiver drain trap is examined to see if it is operating properly. Storage solutions to control demand events should also be investigated.

## More Comprehensive Evaluations

A comprehensive evaluation may also include extensive measurements and analysis of supply and demand interactions. Some auditors will also prepare a detailed systems flow diagram. A financial evaluation may also be performed, including current and proposed costs after retrofits are taken.

## Compressed Air System Economics and Selling Projects to Management

Delivering compressed air to a manufacturing facility is an expensive operation. Delivery requires costly equipment that consumes significant amounts of electricity and needs frequent maintenance. In spite of this, many facilities have no idea how much their compressed air systems cost on an annual basis, or how much money they could save by improving the performance of these systems.

Costs are by far the largest expense of owning and operating a compressed air system. The initial cost for a 100-hp compressor is $30,000 to $50,000, depending on the type of compressor and manufacturer, while annual electricity charges for the same system can reach $50,000. Added to this are annual maintenance costs, which can be 10 percent or more of the initial cost of the system.

This fact sheet shows a simple calculation to estimate annual electricity costs and a more accurate calculation requiring electrical measurements.

## Calculating Electricity Costs

Full-Load Operation. Even if an air compressor is not separately metered, estimating annual electricity cost is simple. For more analysis techniques, see the AIRMaster+ software referenced in the Resource and Tools section, and/or call the Compressed Air Challenge ® number listed in the Directory section.

A Simple Calculation. The following data is needed for a quick calculation of electricity costs for a compressor operating at full-load.

- · Compressor motor nameplate rating (bhp)
- · Motor nameplate efficiency (or an estimate of efficiency)
- · Annual hours of operation (hours/year)
- · Cost of electricity in dollars per kilowatt-hour ($/kWh).

Annual electricity costs can be calculated by inserting this information into the equation as follows:

## Simple Calculation (100-hp Compressor)

Annual electricity costs = (Motor full-load bhp) x (0.746 kW/hp) x (1/0.90) x (Annual hours of operation) x (Electricity cost in $/kWh)

For example:

Compressor full-load bhp = 100 hp Annual hours of operation = 8,760 hours (3-shift, continuous operation)

Cost of electricity = $0.05/kWh

Annual electricity costs = (100 hp) x (0.746 hp/kW) x (1/0.9) x (8,760 hours) x ($0.05/kWh) = $36,305

This equation assumes the electric motor driving the compressor is 90 percent efficient (the 90 in the 1/0.90 factor). Newer energy-efficient motors have even higher efficiencies, especially since the Energy Policy Act minimum motor efficiency levels went into effect in late 1997. If the system uses an older motor that has been rewound several times, or has a smaller motor, 80 percent efficiency (or the motor nameplate efficiency rating) should be used. For a more accurate analysis, add the horsepower ratings for the parasitic loads from any auxiliary motors to the compressor motor rating.

It should be noted that the common practice in the industry is to apply motors having a 15 percent continuous service factor and to use about two-thirds of this service factor. This means that a motor having a nominal nameplate rating of 100 hp may, in fact, be loaded to 110 bhp at compressor full capacity and pressure. This may not be expressed in the manufacturer's sales literature, however, engineering data sheets for the specific compressor should be consulted. If the motor is running into the service factor, the higher horsepower estimate should be used instead of the nameplate horsepower rating.

A Calculation with Measurements. A more accurate way to determine electricity consumption and costs involves taking electrical measurements of both full-load amps and volts. Motor full-load bhp and efficiency are not required for this calculation, although full-load power factor, which can be obtained from motor manufacturers, is required. The calculation measures voltage and full-load amps, converts to full-load kW, and then multiplies by hours of operation and electricity costs. A calculation is shown below.

## More Detailed Calculation (100-hp Compressor)

Annual electricity costs = [(Full-load amps) x (volts) x (1.732) x (power factor)]/1000) x (Annual hours of operation) x (Electricity cost in $/kWh)

For example:

Full-load amps = 115 amps

Voltage = 460 volts Full-load power factor = 0.85* Annual hours of operation = 8,760 hours (3-shift, continuous operation)

Cost of electricity = $0.05/kWh

Annual electricity costs = [(115 amps) x (460 volts) x (1.732) x (0.85)]/1000) x (8,760 hours) x ($0.05/kWh)

= $34,111

*from motor manufacturer

Part-Load Operation. If the compressed air system operates below full-load at times, and has a good control system, electricity costs will be less than if the compressor ran at full-load during all hours of operation. Estimate the percentage of time the compressor is running at full-load, and add the percentage as another multiplier in the equation shown previously. Repeat the calculation for the percentage of time the compressor is running unloaded (or at partload) and include a factor to compensate for the reduced load on the motor (0.20 to 0.30 is a good estimate for fully unloaded operation for rotary screw compressors and 0.10 to 0.15 for reciprocating compressors-0.30 is used in the equation in the next text box). Add the two results for total energy costs.

For a more accurate calculation of energy costs for compressors running at part-load, create a number of

'tiers' with the percentage of time running at different percentages of load. Manufacturers' data on energy consumption for the different percentages of load will be needed.

The text box below shows an example calculation taking into account unloaded operation.

Remember, the calculations shown will only provide a good estimate of energy consumption, not an exact number.

## Calculation With Part-Load Operation (100-hp Compressor)

Annual electricity costs =

[(Motor full-load brake horsepower) x (0.746 kW/hp) x (1/0.90) x (Annual hours of operation) x (Electricity cost in $/kWh)] x [(Percent of time running fully loaded) + (0.30) x (Percent of time running fully unloaded)]

For example:

Motor full-load bhp = 100 hp

Annual hours of operation = 8,760 hours (3-shift, continuous operation)

Runs 65% of the time fully loaded, 35% of the time unloaded Fully unloaded operation consumes 30 percent of the electricity of fully loaded operation

Cost of electricity = $0.05/kWh

Annual electricity costs = [(100 hp) x (0.746 hp/kW) x (1/0.9) x (8,760 hours) x ($0.05/kWh)] x [0.65 + (0.30) x (0.35)]

= $27,410

## Energy and Demand Charges-Understanding Your

Electricity Bill. The calculations shown previously use electricity rates stated in terms of $/kWh. Electric utilities bill industrial customers using more complicated rate structures that typically include both energy ($/kWh) and demand charges ($/kW), and have different rates depending on the level of consumption or seasons. Demand charges are based on the peak demand for a given month or season and can have significant impacts on electricity costs for some customers. When the economic impacts of efficiency measures are calculated, the actual marginal cost of the electricity needs to be considered, taking into account energy and demand charges, seasonal rates, and different rates for different levels of consumption.

## Pressure and Electricity Cost

High-pressure air is more expensive to produce and deliver than low-pressure air. A rule of thumb for systems in the 100 psig range is: for every 2 psi increase in discharge pressure, energy consumption will increase by approximately 1 percent at full output flow (check performance curves for centrifugal and two-stage, lubricant-injected, rotary screw compressors). There is also another penalty for higher-than-needed pressure. Raising the compressor discharge pressure increases the demand of every unregulated usage, including leaks, open blowing, etc. Although it varies by plant, unregulated usage is commonly as high as 30 to 50 percent of air demand. For systems in the 100 psig range with 30 to 50 percent unregulated usage, a 2 psi increase in header pressure will increase energy consumption by about another 0.6 to 1.0 percent because of the additional unregulated air being consumed. The combined effect results in a total increase in energy consumption of about 1.6 to 2 percent for every 2 psi increase in discharge pressure for a system in the 100 psig range with 30 to 50 percent unregulated usage.

Savings From Performance Improvements. Because of the relatively low initial cost of the compressor when compared to lifetime electricity expenses, users should utilize life-cycle cost analysis when making decisions about compressed air systems. In addition, a highly efficient compressed air system is not merely a system with an energy-efficient motor or efficient compressor design. Overall system efficiency is the key to maximum cost savings. Too often users are only concerned with initial cost and accept the lowest bid on a compressed air system, ignoring system efficiency.

Thorough analysis and design will be required to obtain an efficient system. Many compressed air system users neglect these areas, thinking they are saving money, but end up spending much more in energy and maintenance costs.

Following the steps outlined in this sourcebook can lead to substantial energy savings for most compressed air systems. A system that has undergone numerous modifications and has only been maintained enough to keep it running can frequently achieve energy savings of 20 to 50 percent or more. For the 100-hp system described previously, this represents annual savings of $7,000 to $18,000. Larger systems will have correspondingly greater energy savings.

Too many decisions regarding compressed air systems are made on a first-cost basis, or with an 'if it ain't broke, don't fix it' attitude. To achieve optimum compressed air system economics, compressed air system users should select equipment based on lifecycle economics, properly size components, operate equipment at the lowest possible pressure, turn off unneeded compressors, use appropriate control and storage strategies, and operate and maintain the equipment for peak performance.

## Selling Projects to Management

Once you have defined your project and potential benefits and are ready to start work, what do you do next? If you are in the same situation as most plant engineering personnel, you need to request funding for the project from your management. Few individuals have the ability to make a major expenditure of funds without approval. All of the work done to create a block diagram, perform baselining, locate opportunities to save money, and organize a plan of action to reduce costs could be a waste of time if sufficient funding cannot be obtained from management to implement the change. Factors to consider to secure funding will be discussed. Topics will be covered in general, rather than specifics, since each firm potentially requires a different approval process.

Financial management in any firm is focused on maximizing profit in that firm's or that plant's operation. Any money spent to improve a process or system in the plant is an expenditure that erodes the short-term profitability of that operation. This does not mean that management is opposed to spending money. It does mean that management will select to spend funds on projects that will increase profitability within a period of time that they set. If you offer suggestions or recommendations for a project that will save more money than it costs, you will get attention from your management. For example, if you have a project in mind that will cost $100,000, and it will decrease energy consumption by $125,000 per year, you are helping to improve profitability.

The easiest way to look at a project is annual savings and simple payback. Simple payback is simply the cost of the project divided by the projected annual savings. Let's look at this concept by using two examples.

## Example 1

Cost of the project: $100,000 Projected annual savings: $125,000 per year Payback period: 9.6 months (100,000/125,000 x 12)

## Example 2

Cost of the project: $100,000 Projected annual savings: $10,000 per year Payback period: 120 months (100,000/10,000 x 12)

These simple calculations demonstrate two ways to measure the projected return of the cost of an improvement, annual savings, and simple payback period. These are usually used for smaller expenditures or to determine if the project is feasible. In general, projects with short paybacks (such as Example 1 above) can easily be approved.

Your financial management team will use the financial data that you submit to calculate other financial views of the expense. They may calculate the projected savings based on the net present value of the investment. Similarly, they may calculate the internal rate of return on the investment in a project. We will not go into discussion of these financial calculations or tools, since each firm has a different view and different requirements. If you have a project that meets simple payback criteria, work with your financial management to determine the methodology and expected results that the firm utilizes.

If your proposed project passes one of the simple tests, read on. If not, go back and look for other opportunities to save money.

You are now to the point that you have determined that your project will add to the operation's profitability, at least in simple terms. What do you do next? You will most likely want to create a written presentation to your management asking for the approval to spend the money you need. It must be concise, outline specific actions to be taken, list the expected return or cost saving, and provide documentation to support the conclusions you made.

Many firms have a set format to use in a Capital Expenditure Request, to answer questions and supply information. If your company uses this method, your job is easier. Simply complete the form, attach the requested information, and send it for approval. You would be wise to have additional information and possibly a formal presentation via slides or overheads to use to present the project to management if you are so requested. This will include all of the information in the Expenditure Request, plus other information, such as photos and excerpts from articles and publications. If your firm does not use a standard format, you will have to create your written presentation from scratch.

Creating your own presentation/request can be done quite simply if you think and act logically. It most likely will include the following.

- 1. An 'executive overview' that states the problem, the actions to be taken, the cost of the project, and the projected return. All of this should fit on one page of paper.
- 2. Detailed information on current operating data and costs. This is where you use your baseline information. You will want to describe the methodology that you used to establish your baseline.
- 3. A detailed list of the actions you plan to take, the equipment you need to buy, and a detailed cost summary. Make sure you include any internal costs for engineering, project management, and downtime. When possible, provide vendor quotes to back up your cost data.
- 4. A detailed summary of the projected savings. What will change in operating cost, how did you calculate it, and what you considered. The presentation needs to be based on facts, and with full calculations to support the projected savings.
- 5. A statement of risks that outlines what may not go exactly per the plan, and the contingencies you have included to quickly remove barriers that may affect the project as it progresses.
- 6. A time schedule listing the start and end date of all actions.
- 7. Photos, diagrams, and drawings to demonstrate the current state of operation, and what the end product will look like upon completion.
- 8. A statement of results verification. In this section, you will outline the process and procedure that you will use to measure and document the actual cost savings.
- 9. A list of references to articles, books, or presentations that support the action that you plan to take. Case studies of similar actions that achieved the planned results can be very useful.
- 10. A summary, which will include a request for action by your management.

- 11. A copy of the appropriate approval form that is fully completed except for management signatures.
- 12. This documentation should be high-quality and use color copies when and where appropriate, and should be bound per the normal system used by your firm. Anything less than first class will not get the first-class reply, which is the approval for the project.
- 13. Depending on your firm and the budget of the project, you may want to have a formal slide show or overheads in order to make a formal presentation if your management requests that.
- 14. Finally, maintain complete and detailed records on any action related to the project and plan to keep them for a number of years after completion of the project. Documentation of project results is important.

## Where To Find Help

This section of the sourcebook is a directory of resources and information that can help compressed air system users improve the performance of their systems. It is organized into four sections. A brief summary of each section is provided below.

## BestPractices

This section describes the BestPractices, a national effort sponsored by the U.S. Department of Energy (DOE) aimed at improving the performance of industrial systems.

## Compressed Air Challenge ¤

This section describes a national effort involving all compressed air market stakeholders aimed at improving compressed air system performance.

## Directory of Contacts

This section provides lists of associations and other organizations involved in the compressed air system market.

## Resources and Tools

This section provides information on books and reports, brochures, periodicals, software, videos, workshops, and training courses that are currently available to help compressed air system users understand and improve the performance of their compressed air systems.

## BestPractices

Industrial manufacturing consumes 36 percent of all energy used in the United States. DOE's Office of Energy Efficiency and Renewable Energy (EERE) has programs to assist industry in achieving significant energy and process efficiencies. EERE's Industrial Technologies Program (ITP) develops and delivers advanced energy efficiency, renewable energy, and pollution prevention technologies and practices for industrial applications. Through an industry-driven initiative called the Industries of the Future, ITP works with the nation's most energy- and resource-intensive industries to develop a vision of their future and roadmaps on how to achieve these visions over a 20-year timeframe. This collaborative process aligns industry goals with federal resources to accelerate research and development of advanced technologies identified as priorities by industry.

The advancement of energy- and process-efficient technologies is complemented by ITP's energy management best practices for immediate savings results. ITP's BestPractices assists the eight Industries of the Future-aluminum, chemicals, forest products, glass, metal casting, mining, petroleum, and steel-to identify and realize their best energy efficiency and pollution prevention options from a system and lifecycle cost perspective. Through activities, such as plant-wide energy assessments, implementation of emerging technologies, and management of industrial systems, BestPractices delivers solutions for industry that result in significant energy and cost savings, waste reduction, pollution prevention, and enhanced environmental performance.

## Information Sources

DOE offers a variety of information resources to help industry achieve increased energy and process efficiency, improved productivity, and greater competitiveness.

Industrial Technologies Clearinghouse. The Industrial Technologies Clearinghouse fields questions on the program's products and services. They can also answer questions about industrial systems, such as compressed air, motors, pumping, process heating, and steam. The Clearinghouse can be the first stop in finding out what resources are available. Contact the Clearinghouse at (800) 862-2086 or clearinghouse@ee.doe.gov.

ITP and BestPractices Web Sites. The ITP and BestPractices Web sites offer a large array of information, products, and resources to assist manufacturers who are interested in increasing the efficiency of their industrial operations. Gain access to Web pages for the Industries of the Future, learn about upcoming events and solicitations, and more. Visit the ITP Web site at www.eere.energy.gov/industry.

The BestPractices site offers case studies of companies that have successfully implemented energy efficiency technologies and practices, software tools,

tip sheets, training events, and solicitations for plantwide assessments. See these and other resources at www.eere.energy.gov/industry/bestpractices.

Newsletters. See the Resources and Tools section to learn about the Energy Matters newsletter.

Tip Sheets. These two-page tip sheets provide quick advice on how to keep your compressed air systems running at their maximum efficiency. See the Resource and Tools section.

Case Studies. More than 20 case studies have been developed, highlighting compressed air system improvement projects. See the Resource and Tools section.

## Plant Assessments

Depending on the industry, energy can account for 10 percent or more of total operating costs. Energy assessments identify opportunities for implementing new technologies and system improvements. Many recommendations from energy assessments have payback periods of less than 18 months and can result in significant energy savings.

- · Plant-wide assessments help manufacturers develop comprehensive plant strategies to increase efficiency, reduce emissions, and boost productivity. Annual competitive solicitations offer a 50 percent cost share of up to $100,000 in matching funds.
- · Small- to medium-sized manufacturers can qualify for free assessments from the university-based Industrial Assessment Centers.

## Emerging Technologies

Emerging technologies are those that result from research and development and are ready for full-scale demonstration in real-use applications. DOE recognizes that companies may be reluctant to invest capital in these new technologies, even though they can provide significant energy and process improvements. However, through technology implementation solicitations, DOE helps mitigate the risk associated with using new technologies. Solicitations provide cost-shared opportunities to verify performance data and document savings on technologies of interest to the Industries of the Future to help ease the hurdles of new technology acceptance.

## Energy Management

ITP encourages manufacturers to adopt a comprehensive approach to energy use that includes assessing industrial systems and evaluating potential improvement opportunities. Efficiency gains in compressed air, motor, process heating, pumping, and steam systems can be significant and usually result in immediate energy and cost savings. ITP offers software tools and training in a variety of system areas to help industry become more energy and process efficient, reduce waste, and improve environmental performance.

## Allied Partnerships

Allied Partners are manufacturers, associations, industrial service and equipment providers, utilities, and other organizations that voluntarily work with DOE. Allied Partners seek to increase energy efficiency and productivity for the Industries of the Future by participating in, endorsing, and promoting DOE's industrial programs, products, and services. Allied Partnerships help DOE achieve industrial energy efficiency goals by extending delivery channels through the partners' existing networks. In turn, partners achieve their own corporate, institutional, or plant goals and objectives by expanding services to customers and suppliers. Allied Partners also gain access to technical resources, such as software, technical publications, and training, and can gain recognition as leaders in the implementation of energy-efficient technologies and practices. Allied Partners who successfully complete training and a qualifying exam on the use of DOE software programs are recognized as Qualified Specialists. For more on Allied Partnerships, contact the Industrial Technologies Clearinghouse at (800) 862-2086.

## Software Tools

ITP and its partners have developed several software tools for systems improvements to help you make decisions about implementing efficient practices in your manufacturing facilities. The following software tools are available from DOE.

- · AirMaster+ provides comprehensive information on assessing compressed air systems, including modeling,

existing and future system upgrades, and evaluating savings and effectiveness of energy efficiency measures. AIRMaster+ is a stand-alone Windows-based software tool used to analyze industrial compressed air systems. AIRMaster+ is intended to enable auditors to model existing and future improved system operation, and evaluate savings from energy efficiency measures with relatively short payback periods. AIRMaster+ provides a systematic approach

to assessing compressed air systems, analyzing collected data, and reporting results. Users include companies or distributors of compressed air equipment, compressor system auditors, industrial plant personnel, and utility representatives.

AIRMaster+ is but one tool in a large portfolio of Compressed Air Challenge® (CAC) offerings designed to assist the end user in improving the performance of compressed air systems. AIRMaster+ allows for objective and repeatable compressed air system assessment results, and can be used to improve the performance and efficiency of operation. However, AIRMaster+ is not meant to replace an experienced auditor in the evaluation of a compressed air system. AIRMaster+ is intended to model airflow and associated electrical demands as seen by the supply side of the system. AIRMaster+ does not model the dynamic effects of the distribution and end uses. Such issues should be addressed through consultation with an experienced auditor before implementing efficiency recommendations.

- · An energy-efficient motor selection and management tool, MotorMaster+ 4.0 software includes a catalog of more than 20,000 AC motors. The tool features motor inventory management tools, maintenance log tracking, efficiency analysis, savings evaluation, energy accounting, and environmental reporting capabilities.
- · Process Heating Assessment and Survey Tool (PHAST) provides an introduction to process heating methods and tools to improve thermal efficiency of heating equipment. Survey process heating equipment that uses fuel, steam, or electricity, and identify the most energy-intensive equipment. Perform an energy (heat) balance on selected equipment (furnaces) to identify and reduce non-productive energy use. Compare performance of the furnace under various operating conditions and test 'what-if' scenarios.
- · The Pumping System Assessment Tool (PSAT) helps industrial users assess the efficiency of pumping system operations. PSAT uses achievable pump performance data from Hydraulic Institute Standards and motor performance data from the MotorMaster+ database to calculate potential energy and associated cost savings.
- · The Steam System Scoping Tool (SSST) is designed to help steam system energy managers and operations personnel for large industrial plants. This spreadsheet program will profile and grade steam
- system operations and management. This tool will help you to evaluate your steam system operations against identified best practices.
- · Steam System Assessment Tool (SSAT) allows you to assess potential savings from individualized steamsystem improvements. Input data about your plant's conditions, and the tool generates results detailing the potential energy, cost, and emissions savings from various improvements.
- · With 3E Plus software you can easily determine whether boiler systems can be optimized through the insulation of boiler steam lines. The program calculates the most economical thickness of industrial insulation for a variety of operating conditions. You can make calculations using the built-in thermal performance relationships of generic insulation materials or supply conductivity data for other materials.

## Training

Training sessions in industrial systems improvements using DOE software tools are offered periodically through Allied Partners. Visit the BestPractices Web site for more information:

www.eere.energy.gov/industry/bestpractices .

DOE and CAC have developed a training program to prepare compressed air system professionals to use AIRMaster+ effectively in assessing compressed air systems. Individuals who have successfully completed the training and a rigorous qualifying exam are recognized as Qualified AIRMaster+ Specialists. Used properly, AIRMaster+ is a powerful tool for modeling 'what if' scenarios for possible improvements to compressed air systems. A Qualified Specialist can apply AIRMaster+ to assist industrial end users in identifying compressed air system improvement opportunities. For a listing of Qualified AIRMaster+ Specialists, see the BestPractices Web site at www.eere.energy.gov/industry/ bestpractices .

## Compressed Air System Background

DOE began compressed air system-focused activities at its Roundtable on Market Transformation Strategies in April 1995. During the roundtable, a wide range of stakeholders participated in one of three breakout groups, one of which was Air Compressor Systems. The group discussed possible actions to accelerate the

transformation of the compressed air system market, reviewed key market deficiencies, and identified leading actions that could be taken to move the process forward. Participants concluded that the DOE should emphasize the benefits of efficient systems, such as increased productivity and reduced downtime, rather than energy efficiency, since end users generally make system changes because it makes economic sense, not because it will improve energy efficiency.

The group identified the following actions to bring about transformation of the market for energy-efficient compressed air systems.

- · Develop Compressed Air and Gas Institute (CAGI) test procedure fact sheet and standardized reporting of performance data.
- · Improve the consistency and availability of plant energy audits.
- · Prepare a directory of market stakeholders.
- · Develop a directory of services and information
- · Prepare in-plant air distribution guidelines and checklists.
- · Publish case studies of cost savings and performance improvements.
- · Initiate customer awareness program to provide questions and talking points for use when purchasing equipment.
- · Develop standardized purchasing specification boilerplate.

DOE has worked in collaboration with others to implement these ideas in three areas.

## Collaboration with the Compressed Air and Gas Institute

CAGI formed an Energy Awareness Committee and became an Allied Partner. Related projects being developed by CAGI include:

- · Standard performance reporting forms (data sheets) that allow consumers to compare products more easily (see Appendix B )
- · A consumer fact sheet explaining compressor testing methods and the importance of standard reporting forms
- · An Internet-accessible database containing information from the standard performance data sheets, and participation in CAC.

## Improving Compressed Air System Performance Sourcebook (1st Edition)

This document updates this effort.

## Organization of and Participation in the New Compressed Air Challenge ¤

This is a national effort involving all relevant stakeholders aimed at improving the performance of compressed air systems. This initiative is described in detail in the next subsection.

Further information on BestPractices is available from:

Industrial Technologies Clearinghouse

P.O. Box 43171

Olympia, WA 98504-3171

Phone: (800) 862-2086

Fax: (206) 586-8303

www.eere.energy.gov/industry/bestpractices

## The Compressed Air Challenge ¤

A national collaborative, the CAC was formed in October of 1997 to assemble state-of-the-art information on compressed air system design, performance, and assessment  procedures. This collaborative is delivering compressed air system best practices information to the plant floor, creating a consistent national market message that supports the application of these best practices, providing a technically sound and professionally delivered training program for plant operating personnel, and will, through a certification program, recognize plant personnel's skills in operating compressed air systems. Participants include: large industrial users of compressed air, manufacturers and distributors of compressed air equipment and their associations, facility engineers and their associations, compressed air system consultants, state research and development agencies, energy efficiency organizations, and utilities. The goals of the CAC are to:

- · Increase the reliability and quality of industrial production processes
- · Reduce plant operating costs
- · Expand the market for high quality compressed air services
- · Save energy: a 10 percent improvement over current usage, resulting in annual savings of approximately 3 billion kilowatt-hours of electricity nationwide.

The purpose of the CAC is to initiate a national collaborative that develops materials, a training curriculum, a certification program, and other information that can be used by the project sponsors in cooperation with others to:

- · Raise awareness of the importance of efficient, effective plant air systems
- · Train industrial plant operating personnel on best practices for plant air systems
- · Expand the market for expert plant air assessment services
- · Help build the local market infrastructure to deliver these services.

The CAC has developed two training workshops that are being taught across the United States.

- · Fundamentals of Compressed Air Systems, (Level 1), is a 1-day introductory course designed to teach facility engineers, operators and maintenance staff how to achieve 15 to 25 percent cost savings through more effective production and use of compressed air.
- · Advanced Management of Compressed Air Systems, (Level 2), is an intensive 2-day training that provides in-depth technical information on troubleshooting and making improvements to industrial compressed air systems.

See the Resources and Tools section for more information on these workshops.

The CAC has developed two documents: Guidelines for Selecting a Compressed Air System Service Provider (see Appendix E) and Best Practices for Compressed Air Systems . These are described in the Resources and Tools section.

The Best Practices for Compressed Air Systems manual was developed to provide the tools needed to reduce the operating costs associated with the use of compressed air and improve the reliability of the entire system. This manual addresses the improvement opportunities from the air entering the compressor inlet filter to the end uses, including hoses, quick couplers, air tools, cylinders and other devices.

The CAC created the Best Practices for Compressed Air Systems manual to provide 'how to' information to implement recommendations, which will achieve peak performance and reliability of the system at the lowest operating cost. Following these recommendations will:

- • Reduce energy and repair costs
- • Improve system reliability
- • Increase productivity
- • Reduce unscheduled down time.

The manual begins with the considerations for analyzing existing systems or designing new ones, and continues through the compressor supply to the auxiliary equipment and distribution system to the end uses. Determine how to use measurements to audit his own system, calculate the cost of compressed air, and even how to interpret utility electric bills. Best practice recommendations for selection, installation, maintenance, and operation of all the equipment and components within the compressed air system are in bold font and easily selected from each section.

## Organizational Structure

The CAC includes:

- · An Advisory Board comprised of the project sponsors
- · A Project Development Committee, which includes a representative from each key stakeholder group and is responsible for overall project coordination
- · Working Groups, which will provide essential technical input to the project.

## Project Sponsors

Association of Ingersoll-Rand Distributors Compressed Air and Gas Institute Compressor Distributors Association Consortium for Energy Efficiency Energy Center of Wisconsin Honeywell, Inc. Illinois Department of Commerce and Economic Development Iowa Energy Center National Grid USA New York State Energy Research and Development Authority Northeast Utilities Northwest Energy Efficiency Alliance NSTAR Electric and Gas Corp. Pacific Gas &amp; Electric U.S. Department of Energy

## For More Information

The CAC is seeking additional participants interested in sponsorship or contributing to materials development. For general information, call the CAC at (800) 862-2086. If you would like to join, see www.compressedairchallenge.org .

## Directory of Contacts

The following organizations can provide more information on improving the performance of compressed air systems.

## BestPractices

Industrial Technologies Clearinghouse

P.O. Box 43171

Olympia, WA 98504-3171

Phone: (800) 862-2086

Fax: (206) 586-8303

www.eere.energy.gov/industry/bestpractices

The Clearinghouse is a one-stop shop for resources and information on improving electric motor systems, including compressed air systems.

## The Compressed Air Challenge ¤

www.compressedairchallenge.org

The CAC is a national collaborative formed in October of 1997 that assembles state-of-the-art information on compressed air system design, performance, and assessment procedures. For additional information, contact Bruce Medaris, Executive Director, at (613) 673-0666.

## The Compressed Air and Gas Institute

1300 Sumner Avenue Cleveland, OH 44115-2861 Phone: (216) 241-7333 Fax: (216) 241-0105 cagi@cagi.org

www.cagi.org

Since 1915, CAGI has been the leading organization representing manufacturers of compressed air system equipment, including air compressors, blowers, pneumatic tools and air and gas drying and filtration equipment. For more than 80 years, the Institute has been working to improve production and proper use of equipment used in compressed air and gas systems.

CAGI continues to strive to increase the satisfaction of compressed air system users. This is accomplished in a variety of ways, primarily through education and training of users so that they better understand compressed air systems and through development of improved equipment and related standards.

## Compressed Air Equipment Distributor Associations

Compressed air equipment distributor associations represent the companies that sell compressed air equipment to end users. Compressor distributor associations usually focus around one compressor manufacturer. Several of these associations coordinate their activities for the CAC through an umbrella group named the Compressor Distributors Association. The following is a listing of the individual associations.

( Note: points of contact often change. )

## Atlas Copco Compressors, Inc.

Atlas Copco Industrial Compressor Association (ACIDA)

c/o Power Service Inc.

5625 West Yellowstone Highway

Casper, WY 82604

Attn: Tony Cercy

Phone: (307) 235-4700

Fax: (307) 472-7726

## CompAir

North American Association of Compressor

Distributors (NAACD) c/o Universal Air Products Corporation 1135 Lance Road Norfolk, VA 23502-2429 Attn: Kurt Kondas, President Phone: (757) 461-0077 Fax: (757) 461-0808

kkondas@uapc.com

## Gardner Denver

Industrial Compressor Distributors Association (ICDA) c/o Atlas Machine &amp; Supply, Inc. 7000 Global Drive Louisville, KY 40258 Attn: Rich Gimmel, President Phone: (502) 584-7262 Fax: (502) 589-0310

rfgimmel@atlasmachine.com

## Ingersoll-Rand

Association of Ingersoll-Rand Distributors (AIRD)

632 West Avenue

Milford, CT 06460

Attn: Ed Fusco, Manager

Phone: (203) 878-6531

Fax: (203) 874-3123

## Quincy

Association of Independent Compressor Distributors (AICD)

16409 West Desert Wren Court

Surprise, AZ 85374

Attn: Shirley McCoy, Administrator

Phone and Fax: (602) 975-9100

## Sullair

Sullair North American Distributor Council

c/o Blake &amp; Pendleton

269 North Street

Macon, GA 31202

Attn: Allen King, President

Phone: (912) 746-7645

Fax: (912) 745-1452

blakepen@accucomm.net

## Compressor Distributors Association

656 Southern Hills

Eureka, MO 63025

Attn: Margot Gravel

Phone: (636) 938-3957

Fax: (636) 938-3965

Mjgilliam1@aol.com

## Resources and Tools

A wide range of information is available on the application and use of compressed air systems. This section of the sourcebook focuses on resources and tools in the following categories.

- · Books and reports
- · Brochures
- · DOE tip sheets
- · DOE case studies
- · Periodicals
- · Software
- · Videos
- · Workshops and training courses

The resources and tools presented here are not intended to represent all available information pertaining to compressed air systems. Instead, this list presents the reference material and tools that would be of interest to those involved in energy-efficient compressed air systems. Neither DOE nor the CAC imply any endorsement of the information included in this section.

## Books and Reports

The books and reports listed are grouped into one of the following three categories.

- · Documents on compressed air systems focusing on performance improvement
- · Specialty books on compressors (e.g., compressor design)
- · Information on the compressed air market.

## Documents Focusing on Performance Improvement

## Air Compressors and the Compressed Air System

Author:

William Scales, P .E. A comprehensive text on maintaining compressed air systems for peak performance.

Description:

Available from:

Scales Air Compressor Corporation 110 Voice Road Carle Place, NY 11514 Phone: (516) 248-9096 x 611 Fax: (516) 248-3500

## Assessing Processes For Compressed Air Efficiency

Author:

Bill Howe, P .E. and William Scales, P .E.

Description:

The report presents 11 questions managers should answer about their compressed air applications to understand whether compressed air is the right tool for the job, how compressed air is applied, how it is delivered and controlled, and how the compressed air system is managed.

Available from:

E SOURCE Reprints Service

1033 Walnut Street Boulder, CO 80302-5114 Phone: (303) 440-8500 Fax: (303) 440-8502

## Best Practices for Compressed Air Systems

Author:

Compressed Air Challenge ® with William Scales, P .E., and David M. McCulloch, C. Eng., M.I. Mech E.

Description:

A 'how to' volume, comprised of more than 300 pages of original text and reference appendices, photos and performance data, for use to help compressed air end users and service providers to improve operating efficiencies and reliability of installed compressed air systems.

Available from:

The Compressed Air Challenge ® c/o ORC Macro International, Inc. Attn: Andrea Cole, Accounting 11785 Beltsville Drive, Suite 300 Calverton, MD 20705 Phone: (888) 260-0052

## Compressed Air and Gas Handbook, Sixth Edition

Author:

Various Compressed Air and Gas Institute members with David McCulloch, editor A comprehensive reference work on all phases of compressed air and gas, this handbook covers reciprocating, rotary, and dynamic compressors; pneumatic tools; air quality and treatment; construction equipment; pneumatic controls; materials handling equipment; and many other topics.

Description:

Available from:

Compressed Air &amp; Gas Institute

1300 Sumner Avenue Cleveland, OH 441155 Phone: (216) 241-7333 Fax: (216) 241-0105 cagi@cagi.org

www.cagi.org

## Compressed Air Management, Energy Efficiency in Compressed Air Systems Seminar Workbook

Author:

T. F . Taranto

Description:

Used in seminars, this workbook is a resource for the industrial compressed air user. Topics include concepts of compressed air system management, compressed air system investment, cost of compressed air, system performance modeling, benchmarking system

performance with data measurement, and system management strategies.

Available from:

Data Power, Inc. 8417 Aswego Road PMB 213 Baldwinsville, NY 13027 Phone: (315) 635-1895 Fax: (315) 635-1898

## Compressed Air Systems

Author:

H. P. Van Ormer

Description:

This handbook discusses compressed air systems, including departmental and central air systems. It covers topics such as compressor types; application, selection, and installation of rotary and centrifugal air compressors; compressor capacity controls; compressor terminology; determination of air requirements; compressed air dryers; and optimization of systems.

Available from:

Air Power USA, Inc. P.O. Box 292 Pickerington, OH 43147

Phone and Fax: (614) 862-4112

## Compressed Air Systems Solution Series

Author:

Scot Foss

Description:

This comprehensive text discusses ways to improve the performance of compressed air systems. It is published as a two-year, bi-monthly subscription series. It covers topics such as design issues, troubleshoot ing, instrumentation, storage, piping, controls, demand issues, and supply issues.

Available from:

Bantra Publishing

Phone: (704) 372-3400

## Compressed Air Systems: A Guidebook on Energy and Cost Savings

Author:

E.M. Talbott

Description:

This guidebook covers topics ranging from compressed air equipment and distribution system layout to final application and system operation.

Available from:

Prentice-Hall Publishers

Englewood Cliffs, NJ

Phone: (800) 223-1360

Fax: (800) 445-6991

## Compressed Air Technology Seminar Workbook:

## Opportunities and Solutions

Author:

H. P. Van Ormer

Description:

Used in Mr. Van Ormer's compressed air seminars, this workbook serves as a good resource for those looking to improve the efficiency of their compressed air systems. Topics discussed include compressed air basics, supply equipment, regulation and controls, system design, receiver demand flow regulation, maintenance and reliability, power savings, leak surveys, and flow meters.

Available from:

Air Power USA, Inc.

P.O. Box 292

Pickerington, OH 43147

Phone and Fax: (614) 862-4112

## Compressor Engineering Data

Author:

William Scales, P .E.

Description:

A handbook of reference material on compressed air systems.

Available from:

Scales Air Compressor Corporation 110 Voice Road

Carle Place, NY 11514

Phone: (516) 248-9096

Fax: (516) 248-9639

## Compressors and Expanders: Selection and Application for the Process Industry

Author:

Heinz P. Bloch

Description:

This book identifies preferred equipment types for specific uses, provides easy-to- understand explanations and examples, examines the limitations of the machinery, and compiles data that is scattered throughout the literature. The potential audience includes engineers interested in gas separation, cryogenic processes, and compression stations; manufacturers and purchasers of compressors and turbo- expanders; and contractors involved in plant design and machinery selection.

Available from:

Marcel Dekker, Inc.

270 Madison Avenue New York, NY 10016 Phone: (212) 696-9000

Fax: (212) 685-4540

## Compressors: Selection and Sizing, Second Edition

Author: Description:

Royce N. Brown

This reference text provides information on compression principles, equipment, applications, selection, sizing, installation, and maintenance, allowing proper estimation of compressor capabilities and selection of designs. Updated with new American Petroleum Institute standards and current technology in areas of efficiency, 3-D geometry, electronics, and plant computer use, this guide covers reciprocating, rotary, and centrifugal compressors and compares their reliability.

Available from:

Gulf Publishing Company

P.O. Box 2608

Houston, TX 07675

Phone: (713) 520-4444

Fax: (713) 520-4433

## Guidelines for Selecting a Compressed Air System Service Provider

Author:

Compressed Air Challenge ®

Description:

This document offers guidance for select ing a firm that offers integrated services to improve compressed air system perform ance. It also explains the different levels of system analysis service.

Available from:

Compressed Air Challenge ®

www.compressedairchallenge.org

## Plant Engineer's Guide to Specifying a Compressed Air System Audit

Author:

T.F. Taranto

Description:

A reference book designed to help the plant engineer focus on the information to be gained from the audit process. Key informational objectives, the degree of detail, and study methods for a compressed air system audit are described. The book also includes suggestions for the type of measurements to be made, key locations to measure, and suggested measurement techniques.

Available from:

Data Power, Inc. 8417 Aswego Road PMB 213 Baldwinsville, NY 13027 Phone: (315) 635-1895 Fax: (315) 635-1898

## Pumps/Compressors/Fans: Pocket Handbook

Author:

Nicholas P. Cheremisinoff and Paul N.

Cheremisinoff

Description:

This handbook provides a concise presentation of the fundamentals-design, function, and applications-of pumps, compressors, and fans. It is organized for easy reference and illustrated with more than 80 photographs, diagrams, and other schematics. This text will help engineers and other plant operations personnel in their selection and utilization of pump, fan, and compressor equipment.

Available from:

Technomic Publishing Company, Inc.

851 New Holland Avenue P.O. Box 3535 Lancaster, PA 17604 Phone: (800) 233-9936

Fax: (717) 295-4538

## Specialty Books

## Centrifugal Compressor Design and Performance

Author:

David Japikse

Description:

This publication is both a state-of-the-art review of the technology base of centrifugal compressors and a practical guide to designers.

Available from:

Concepts ETI, Inc. White River Junction, VT 05001

4 Billings Farm Road Phone: (802) 296-2321 Fax: (802) 296-2325

## Compressor Handbook

Author:

Paul C. Hanlon (editor)

Description:

Provides information on design procedures, practical application, and maintenance of compressors-from top experts on these widely used machines. Details on everything from fundamentals and theory to advanced applications and techniques, including sought-after data on compressors that inflate tires, spray paint, and increase the density of natural gas.

Available from:

McGraw-Hill

1221 Avenue of the Americas New York, NY 10020 Phone: (800) 352-3566

www.bookstore.mcgraw-hill.com

## Compressor Performance, Aerodynamics for the User

Author:

Pe Gresh and Theodore Gresh This book covers the full spectrum of information needed for an individual to select, operate, test and maintain axial or centrifugal compressors. It includes some basic aerodynamic theory to provide the user with the 'how's' and 'why's' of compressor design. Maintenance Engineers especially will appreciate the troubleshoot- ing guidelines offered.

Description:

Available from:

Newnes

Elsevier Science/Harcourt 200 Wheeler Road, 6th floor Burlington, MA 01803 Phone: (781) 221 2212 Fax: (781) 221 1615

www.bhusa.com/newnes

## Compressor Performance: Selection, Operation, and Testing of Axial and Centrifugal Compressors

Author:

Theodore Gresh

Description:

This book is divided into two main sections. In the theory section of the book, the author introduces aerodynamics, thermodynamics, aerodynamic components, and compressor character- istics. In the application section, the author discusses equipment selection, operation, field performance testing, troubleshooting, and flow meters. Butterworth Heinemann 225 Wildwood Avenue Woburn, MA 01801 Phone: (617) 928-2500 or (800) 366-2665 Fax: (617) 933-6333

Available from:

www.bh.com

## Compressor Surge and Rotating Stall: Modeling and Control (Advances in Industrial Control)

Author:

Description:

Jan Tommy Gravdahl and Olav Egeland This book gives a comprehensive overview of the achievements in the field of modeling and active control of instabilities in compressions systems over the last decade. Models of unstable compression systems are usually restricted to constant speed compressors. But here, two models are derived that take time varying rotational speed into account-one for

centrifugal compressors and one for axial compressors.

Available from:

Springer-Verlag

Springer-Verlag New York, Inc.

175 Fifth Avenue

New York, NY 10010

Phone: (212) 460 1500

Fax: (212) 473 6272

## Compressor Surge and Stall

Author:

Ronald C. Pampreen

Description:

This text discusses the stability, surge and stall of axial and centrifugal compressors. Both theory and applications are discussed. The book includes multi-stage compressor designs and various methods for extending stable operation.

Available from:

Concepts ETI/NREC

Product Center

39 Olympia Avenue

Woburn, MA 01801-2073

Phone: (781) 935 9052

Fax: (781) 935 9052

www.conceptseti.com

## Control of Centrifugal Compressors

Author:

Ralph L. Moore

Description:

This text provides comprehensive information on the techniques for controlling centrifugal compressors. In addition to compressor control issues, optimization of compressor operation and multiple compressor systems are topics also discussed.

Available from:

Instrument Society of America 67 Alexander Drive P.O. Box 12277 Research Triangle Park, NC 27709 Phone: (919) 549-8411 Fax: (919) 549-8288

www.isa.org

## Fluid Movers, Second Edition

Author:

Nicholas P. Chopey and Chemical Engineering Magazine Editors This text is a compilation of current articles on the movement of fluids with pumps, compressors, fans, and blowers from Chemical Engineering Magazine .

Description:

Available from:

McGraw-Hill

P. O. Box 546

Blacklick, OH 43004-0546

Phone: (800) 722-4726

Fax: (614) 755-5654

www.bookstore.mcgraw-hill.com

## Leak-Free Pumps and Compressors, 1st Edition

Author:

Gerhard Vetter

Description:

As environmental regulations concerning leaks and emissions become more stringent, this practical reference manual targets those concerned with systems using leak-free pumps or compressors. This handbook explains the various designs and properties of leak-free pumps and helps you select the right pump or compressor to ensure leak-free systems, whatever the application.

Available from:

Elsevier Advanced Technology

Mayfield House 256 Banbury Road Oxford OX2 7DH England Phone: 01865-512242 Fax: 01865-310981

www.elsevier.nl

Optimization of Industrial Unit Processes: Boilers, Chemical Reactors, Chillers, Clean Rooms, Compressors, Condensers, Heat Exchangers, HVAC Systems, Pumping Stations, Reboilers, and Vaporizers

Author:

Bela G. Liptak

Description:

The optimization of various processes is discussed in detail. Describes real-world occurrences-where pipes leak, sensors plug, and pumps cavitate-offering practical solutions to real problems. Krause Publications 700 E. State Street Iola, WI 54990 Phone: (888) 457-2873 Fax: (715) 445-4087

Available from:

www.krause.com

## Optimization of Unit Operations: Boilers, Chemical Reactors, Chillers, Clean Rooms, Compressors, Condensers, Heat Exchangers, HVAC Systems, Pumping Stations, Reboilers, and Vaporizers

Author:

Bela G. Liptak

Description:

This text examines the technical and practical applications of plant multivariable development control. Optimization of various systems is discussed in detail.

Available from:

Krause Publications

700 E. State Street Iola, WI 54990

Phone: (888) 457-2873

Fax: (715) 445-4087

www.krause.com

## Reciprocating Compressors: Operation and Maintenance

Author:

Heinz P. Bloch and John J. Hoefner This book discusses the theory of operation and describes methods of proper installation, troubleshooting, overhauling, and repairing of all types of reciprocating compressors. Engineers and maintenance personnel in the process industries such as mining, food processing, pharmaceuticals, and petrochemicals will find this text useful.

Description:

Available from:

Gulf Publishing Company

P.O. Box 2608 Houston, TX 77252-2608 Phone: (713) 520-4444 Fax: (713) 520-4433 www.gulfpub.com

## Rotary Screw Air Compressors

Author:

H. P. Van Ormer

Description:

This guide provides a close look at the lubricant-cooled rotary compressor and its role in construction and industrial applications. It discusses the history, development, basic technology, applica- tion, selection, installation, and general maintenance of rotary screw air compressors.

Available from:

Air Power USA, Inc. P.O. Box 292 Pickerington, OH 43147 Phone and Fax: (614) 862-4112 www.airpowerusainc.com

## Information on the Compressor Marketplace

## Assessment of the Market for Compressed Air Efficiency Services

Author:

U.S. DOE

Description:

The U.S. DOE, with technical support furnished by the CAC published the Assessment of the Market for Compressed Air Efficiency Services . The assessment provides a comprehensive view of the market for engineering and consulting services to improve the energy efficiency of plant compressed air systems. These services include plant assessments to identify improvement opportunities for compressed air systems, preventive maintenance services, and redesign of system components to reduce energy use.

Available from:

www.eere.energy.gov/industry/ bestpractices

## Compressors-Air &amp; Gas Wholesale

Description:

This annual directory features information on 4,180 wholesalers of air and gas compressors.

Available from:

American Business Information, Inc. 5711 South 86th Circle P.O. Box 27347 Omaha, NE 68127-0347 Phone: (402) 593-4500 Fax: (402) 331-5481

## Compressors, Vacuum Pumps, and Industrial Spraying Equipment

Author:

Description:

Specialists in Business Information, Inc. The U.S. market for air and gas compressors, vacuum pumps, and industrial spraying equipment strengthened in 1995 and 1996. Specialists in Business Information (SBI) has compiled and analyzed data on U.S. factory shipments, imports, exports, industry costs structure, and the competitive environment to uncover strategies that will allow manufacturers and marketers to penetrate growing markets in this $4 billion industry. SBI has also profiled worldwide manufacturers and reviewed their recent develop-

ments as part of an exhaustive effort to provide competitor intelligence. In addition, SBI has extracted sales and profit trends for 16 manufacturers in order to compare company performance with industry averages. Some of the major producers profiled include Dresser-Rand, Gardner Denver, Nordson, and Sunstrand.

Available from:

Specialists in Business Information, Inc. 3375 Park Avenue Wantagh, NY 11793

## Pumps and Compressors

Author:

U.S. Department of Commerce, Bureau of the Census

Description:

This annual Current Industrial Report provides statistics on the quantity and value of manufacturers' shipments, number of producers by product type and industry, exports, and imports. These statistics reflect market trends in the pump and compressor industry.

Available from:

U.S. Department of Commerce

Bureau of the Census

Gaithersburg, MD

Phone: (301) 457-4100

Fax: (301) 457-4794

Download from www.census.gov

## The U.S. Pump and Compressor Industry

Author:

Business Trend Analysts, Inc.

Description:

This market research report assesses the market for pumps and compressors, including reciprocating, rotary, and centrifugal air compressors, by gathering data and conducting analyses. The report presents data on U.S. manufacturers' sales and analysis of end-use demand by industry for pumps and compressors. Additional information includes pump and compressor industry statistics, trade, corporate profiles, and a directory of manufacturers.

Available from:

Business Trend Analysts, Inc. 2171 Jericho Turnpike Commack, NY 11725-2900 Phone: (516) 462-5454 Fax: (516) 462-1842

www.businesstrendanalysts.com

## The 2000-2005 World Outlook for Pumps, Valves and Compressors (Strategic Planning Series)

Author:

The Research Group, Valves and Compressors and the Pumps, Compressors Research Group

Description:

Worldwide market potential for pumps, valves and compressors, broken down by country. Timely and reliable market information as a complement to strategic planning processes.

Available from:

Icon Group International, Inc.

4 Stamford Plaza, 15th Floor 107 Elm Street Stamford, CT 06902 Phone: (203) 328-2300 Fax: (203) 328-2333

www.icon-intl.com

## Educational Brochures

The following educational brochures are available from the CAGI at:

1300 Sumner Avenue Cleveland, OH 44115-2851 Phone: (216) 241-7333 Fax: (216) 241-0105 cagi@cagi.org

www.cagi.org

## Air Compressor Selection and Application: 1/4 HP through 30 HP

Description:

This publication provides a detailed summary of the types of compressors available, their intended application, and selection criteria for a variety of industries.

## Compressed Air and Gas Drying

Description:

This brochure explains the need for air and gas drying. It includes a step-by-step dryer specifying guide, technical illustrations, and appropriate technical appendices.

## Rotary Air Compressor Selection Guide

Description:

This publication covers the complete range of rotary air compressors and discusses selection criteria, capacity control, compressor accessories, and examples of applications.

## CAGI/HACA 100:  Safety and Performance Standards for Home Air Compressors

Description:

This standard provides a defined uniform method for checking safety and measuring performance of small air compressors.

## B186.1 Safety Code for Portable Air Tools

Description:

This illustrated publication prescribes minimum safety standards for air tool manufacturers and users.

## CAGI-PNEUROP PN2CPTC1 Acceptance Test Code for Bare Displacement Compressors

Description:

This publication defines and describes acceptance tests for bare displacement air compressors, which are constructed to specifications determined by the manufacturer and which are sold against performance data published in the manufacturer's sales documentation.

## CAGI-PNEUROP PN2CPTC2 Acceptance Test Code for Electrically Driven Packaged Displacement Compressors

Description:

This publication defines and describes acceptance tests for electrically driven packaged air compressors of standard types, which are constructed to specifications determined by the manufacturer and which are sold against performance data published in the manufacturer's sales documentation.

## CAGI-PNEUROP PN2CPTC3 Acceptance Test Code for I.C. Engine Driven Package Displacement Air Compressors

Description:

This publication defines and describes acceptance tests for engine driven pack aged air compressors of standard types, which are constructed to specifications determined by the manufacturer and which are sold against performance data published in the manufacturer's sales documentation.

## ANSI/CAGI ADF 100 Refrigerated Compressed Air DryersMethods for Testing and Rating

Description:

This standard provides a uniform procedure to measure and rate the performance of refrigerated compressed air dryers.

## ANSI/CAGI ADF 200 Dual-Tower, Regenerative Desiccant Compressed Air Dryers-Methods for Testing and Rating

Description:

This standard provides a uniform basis for measuring the performance of dual-tower regenerative-desiccant, compressed air dryers. It also provides a uniform basis on which to rate the performance of these dryers.

## ANSI/CAGI ADF 300 Single-Tower, (Non-Regenerative) Desiccant, Compressed Air Dryers-Methods for Testing and Rating

Description:

This standard provides a uniform basis of measuring the performance of singletower, (non-regenerative) desiccant compressed air dryers and their corresponding desiccants. It also provides a uniform basis on which to rate the performance of these dryers.

## ANSI/CAGI ADF 400 Standards for Testing and Rating Coalescing Filters

Description:

This standard provides a uniform basis for measuring the performance of coalescing filters. It also provides a uniform basis on which to rate the performance of these filters.

## ANSI/CAGI ADF 500 Standards for Measuring the Adsorption Capacity of Oil Vapor Removal Adsorbent Filters

Description:

This standard provides a uniform basis of measuring the adsorption capacity of oil vapor removal adsorbent filters.

## ANSI/CAGI ADF 700 Membrane Compressed Air Dryers Methods for Testing and Rating

Description:

This standard provides a uniform basis of measuring the performance of membrane compressed air dryers. It also provides a uniform basis on which to rate the performance of these dryers.

## DOE Tip Sheets

These two-page tip sheets provide quick advice on how to keep your systems running at their maximum efficiency.

For a complete list of available tip sheets, see the publications section at www.eere.energy.gov/industry/ bestpractices. A number of additional tip sheets are being developed.

## DOE Case Studies

The following case studies have been developed.

- · Implementing a Compressed Air Leak Management Program at an Automotive Plant
- · Compressed Air System Modifications Improve Efficiency at a Plastics Blow Molding Plant
- · Compressed Air System Upgrade Results in Substantial Energy Savings
- · Compressed Air System Renovation Project Improves Production at a Food Processing Facility
- · Upgrade of Compressed Air Control System Reduces Energy Costs at Michelin Tire Plant
- · Compressed Air System Retrofitting Project Improves Productivity at a Foundry
- · Compressed Air System Retrofit Improves Productivity at a Petroleum Packaging Facility
- · Compressed Air System Improvements Increase Production at a Tin Mill
- · Compressed Air System Upgrade Improves Production at a Steel Mill
- · Compressed Air System Enhancement Increases Efficiency and Provides Energy Savings at a Circuit Board Manufacturer
- · Compressed Air System Optimization Saves Energy and Improves Production at a Textile Manufacturing Mill
- · Compressed Air System Project Improves Production at a Candy-Making Facility
- · Compressed Air System Redesign Results in Increased Production at a Fuel System Plant
- · Compressed Air System Optimization Saves Energy and Improves Production at Synthetic Textile Plant
- · Compressed Air System Improvements at an Auto Plant
- · Consolidated Compressed Air System Reduces Power Consumption and Energy Costs
- · Compressed Air System Overhaul Improves Production at a Powdered Metal Manufacturing Plant
- · Compressed Air System Optimization Project Improves Production at a Metal Forging Plant
- · Compressed Air System Upgrade Generates Significant Energy Savings at a Steel Mill
- · Compressed Air System Retrofit Reduces Energy Costs at a Newspaper Printing Facility
- · Motor Assembly Plant Saves $85,000 with Compressed Air System Improvements
- · Compressed Air System Optimization Improves Production and Saves Energy at a Satellite Manufacturer
- · Compressed Air Project Improves Efficiency and Production at Harland Publishing Facility
- · Compressed Air System Improvement Project Saves Foundry Energy and Increases Production

These case studies highlight projects where industrial plants have improved the performance of their compressed air systems. Copies of the case studies can be downloaded from www.eere.energy.gov/ industry/bestpractices

## Periodicals

The following periodicals often contain articles about improving compressed air systems, and can be very good sources of state-of-the-art information.

## AFE Facilities Engineering Journal

Description:

This technical journal provides practical, in- depth information on key on-the-job issues, covering the topics of maintenance, man- agment, safety, compliance, and professional development for facility operations.

Available from:

Association for Facilities Engineering 8160 Corporate Drive, Suite 125 Cincinnati, OH 45242 Phone: (513) 489-2473

www.afe.org

## Energy Engineering

Description:

A professional journal that chronicles the latest advancements in energy engineering, now available online through

www.aeecenter.org .

Available from:

Association of Energy Engineers Lilburn, GA Phone: (770) 447-5083 ext. 210 Fax: (770) 446-3939 www.aeecenter.org

## Energy Matters

Description:

Energy Matters is a quarterly newsletter produced by DOE's Industrial Technologies program. The newsletter informs industrial

end users of energy efficiency opportunities, technical issues, new products and services, and events related to motor, steam, and compressed air systems, and DOE's Industrial Assessment Centers.

Available from:

www.eere.energy.gov/industry/bestpractices

## Industrial Maintenance &amp; Plant Operation

Description:

A periodical chronicling the latest industrial maintenance and power plant operation strategies, techniques, and equipment.

Available from:

Cahners Publishing Company

275 Washington Street Newton, MA  02158-1630 Phone:  (617) 964-3030

www.cahners.com

## Maintenance Technology

Description:

A business and technical information source for managers, engineers and super- visors responsible for plant equipment maintenance, reliability, and asset management. Maintenance Technology is published monthly except for a combined July/August issue.

Available from:

Applied Technology Publication, Inc. 1300 South Grove Avenue, Suite 105 Barrington, IL 60010 Phone: (847) 382-8100

www.mt-online.com

## Plant Engineering

Description:

Plant Engineering provides unique informa- tion for men and women who operate and maintain industrial plants. It bridges the information gap between engineering education and practical application, providing valuable knowledge and insight to plant operators.

Available from:

Reed Business Information 360 Park Avenue South New York, NY 10014 Phone: (646) 746-7764 www.reedbusiness.com

## Plant Services

Description:

Information for successful plant systems and management, including equipment

Available from:

performance, maintenance, and operation. Plant Services also publishes a Buyer's

Guide for plant systems and equipment. Putnam Media 555 West Pierce Road, Suite 301 Itasca, IL 60143 Phone: (630) 467-1300

www.putnam.net

## Software

## AIRMaster+: Compressed Air System Assessment Software

Description:

AIRMaster+ is a Windows-based software tool used to analyze industrial compressed air systems. AIRMaster+ enables auditors to model existing and future improved system operation, and evaluate savings from energy efficiency measures with relatively short payback periods. AIRMaster+ provides a systematic approach to assessing compressed air systems, analyzing collected data, and reporting results. Users include companies or distributors of compressed air equip- ment, compressor system auditors, industrial plant personnel, and utility representatives. More information on AIRMaster+ can be found in the BestPractices section of this document. Industrial Technologies Clearinghouse P.O. Box 43171 Olympia, WA 98504-3171 Phone: (800) 862-2086

Available from:

Fax: (206) 586-8303

clearinghouse@ee.doe.gov

## Compressed Air Analysis Tool (CAAT)

Description:

This tool performs an analysis of potential energy savings, and assists in estimating the implementation cost of energy efficiency opportunities associated with air compressors and compressed air applications. Use the tool to calculate the energy and cost savings for various types of modifications in compressor and compressed air applications. It includes a comprehensive database of U.S. compressor manufacturers. A free limited copy of this tool is available at www.baseco.com/software.shtml

Available from:

BASE Energy, Inc. 5 Third Street, Suite 530 San Francisco, CA 94103 Phone: (415) 543-1600 Fax: (415) 543-1601

www.baseco.com

## C-MAX Engineering Software

Description:

C-MAX ™ software's compressor module is designed for systems analysis of centrifugal compressors, reciprocating compressors, and rotary screw compressors. Multiple compressors and 'what if' case studies can be modeled for pure gases or gaseous mixtures, such as dry or wet air, hydrogen, nitrogen, refinery gas mixture, fuel gas, and natural gas. The software allows users to perform 'offline' modeling of compressor performance, energy, and flow capacity calculations, and to create case studies by changing process, mechanical, or load variables. An evaluation copy is available on the Unicade Web site.

Available from:

UNICADE INC.

13219 NE 20th Street, Suite 211

Bellevue, WA 98005-2020

Phone: (425) 747-0353

Fax: (425) 747-0316

unicade@unicade.com

www.unicade.com

## CHEMCALC 15: Centrifugal Compressor Design and Rating

Description:

Based on the theories of Elliott and Ingersoll-Rand, CHEMCALC 15 will: 1) design a compressor and analyze a multi-stage compressor with up to four stages of compression; 2) analyze the performance of an existing compressor by calculating new operating conditions based on design operating conditions and curve and actual process conditions; and 3) calculate the thermodynamic properties of a gas mixture, including molecular weight, critical temperature, critical pressure, specific heat ratio, and gas constant.

Available from:

Gulf Publishing Company Software P.O. Box 2608 Houston, TX 77252-2608

Phone: (800) 231-6275 or (713) 520-4448 Fax: (713) 520-4433 www.gulfpub.com

## Videos

The following videos are available from CAGI at:

The Compressed Air and Gas Institute 1300 Sumner Avenue Cleveland, OH 44115-2851 Phone:  (216) 241-7333 Fax: (216)  241-0105 cagi@cagi.org www.cagi.org

## Compressed Air: Industry's Fourth Utility

Description:

This video presents a broad overview of air compression, distribution, and treatment. It describes key considerations in designing and specifying a compressed air system, including compressor selection, distribution considerations, air dryers, and filters. (Running time: 13 minutes)

## Performance Under Pressure

Description:

This video discusses the role of compressed air and gas in various applications ranging from residential to industrial. (Running time: 16 minutes)

## Principles of Air Compression

Description:

This video explains in non-technical terms, the theory and principles involved in air compression. It illustrates the operation of both positive-displacement and dynamic-type compressors and introduces key terms, such as PSIG, SCFM, relative humidity, and dew point. (Running time: 14 minutes)

## How to Select an Air Compressor

Description:

This video focuses beyond the compressor and encourages buyers to look at their complete air system. The video provides answers to some key questions that should be considered before making a compressor purchase. The video is accompanied by datasheets that provide a standardized format for manufacturers to use to

provide basic information about

compressor and dryer performance and efficiency. (Running time: 18 minutes)

## Air Treatment

Description:

This video provides an excellent overview of compressed air treatment. It introduces the viewer to the different ISO air quality classes. The video is divided into three major sections: cooling, drying and cleaning. Descriptions of the components and equipment used to treat the air are provided.

(Running time: 17 minutes)

Other videos available:

## Safety and Use of Air Compressors

Description:

This video program shows how to operate an air compressor system safely and efficiently. Topics include moving the air compressor, compressor parts, lubrication, and maintenance. This video was not developed by CAGI.

(Running time: 13 minutes)

Available from:

SafetyCare Inc.

26161 La Paz Road, Suite A Mission Viejo, CA 92691 Phone: (714) 452-1555 Fax: (714) 452-1556

www.safetycare.com.au

## Workshops and Training Courses

Workshops focusing on energy efficiency and performance improvement in compressed air systems are developed and presented by independent consultants, equipment manufacturers, distributors, and others. Many compressed air system consultants offer workshops and training courses on improving the performance of compressed air systems. In addition, some equipment manufacturers and distributors offer training to their customers. Workshops are sometimes sponsored by electric utilities, universities, and state energy offices.

CAC has developed two courses.

Fundamentals of Compressed Air Systems, (Level 1), is a 1-day introductory course designed to teach facility engineers, operators and maintenance staff how to achieve 15 to 25 percent cost savings through more effective production and use of compressed air. Participants will learn how to:

- · Calculate the energy cost of compressed air in their facility
- · Improve compressed air system efficiency and reliability
- • Identify inappropriate uses of compressed air
- · Establish a baseline by which they can measure improvements in compressed air performance and efficiency
- · Match system supply to actual production requirements for pressure and flow;
- • Find and fix leaks
- • Establish a leak prevention program
- · Better control compressed air to improve productivity and profitability.

## (Level 2),

Advanced Management of Compressed Air Systems, is an intensive 2-day training seminar that provides indepth technical information on trouble-shooting and making improvements to industrial compressed air systems. This training is designed to help end users as well as industry solution providers learn how to:

- · Collect and use data and tools to assess the efficiency and cost-effectiveness of a compressed air system
- · Develop and use a system profile
- · Implement a system maintenance program
- · Address air quality, highest pressure requirements and high-volume intermittent applications
- · Understand complex control system strategies
- · Align the supply side to demand side operation
- · Explain the value of heat recovery
- · Successfully sell compressed air improvement projects to management.

For more information, see www.compressedairchallenge.org .

## Appendices

The following five appendices have been included in the sourcebook:

## Appendix A

This appendix is a glossary defining terms used in the compressed air industry.

## Appendix B

This appendix contains information on packaged compressor efficiency ratings.

## Appendix C

This appendix contains Data Sheets outlining a common format for reporting compressor and dryer performance.

## Appendix D

This section presents an overview of the compressed air systems marketplace, including market size and dynamics, and a description of the stakeholders.

## Appendix E

This section offers guidance for selecting a firm that offers integrated services to improve compressed air system performance. It also explains the different levels of system analysis service.

## Appendix A: Glossary of Basic Compressed Air System Terminology

Absolute PressureTotal pressure measured from zero.

Capacity, ActualSee Actual Capacity.

Absolute TemperatureSee Temperature, Absolute.

AbsorptionThe chemical process by which a hygroscopic desiccant, having a high affinity with water, melts and becomes a liquid by absorbing the condensed moisture.

Actual CapacityQuantity of gas actually compressed and delivered to the discharge system at rated speed and under rated conditions. Also called Free Air Delivered (FAD).

Adiabatic CompressionSee Compression, Adiabatic.

AdsorptionThe process by which a desiccant with a highly porous surface attracts and removes the moisture from compressed air. The desiccant is capable of being regenerated.

Air ReceiverSee Receiver.

Air BearingsSee Gas Bearings.

AftercoolerA heat exchanger used for cooling air discharged from a compressor. Resulting condensate may be removed by a moisture separator following the aftercooler.

Atmospheric PressureThe measured ambient pressure for a specific location and altitude.

Automatic SequencerA device that operates compressors in sequence according to a programmed schedule.

Brake Horsepower (bhp)See Horsepower, Brake.

CapacityThe amount of air flow delivered under specific conditions, usually expressed in cubic feet per minute (cfm).

Capacity GaugeA gauge that measures air flow as a percentage of capacity, used in rotary screw compressors

Check ValveA valve which permits flow in only one direction.

ClearanceThe maximum cylinder volume on the working side of the piston minus the displacement volume per stroke. Normally it is expressed as a percentage of the displacement volume.

Clearance PocketAn auxiliary volume that may be opened to the clearance space, to increase the clearance, usually temporarily, to reduce the volumetric efficiency of a reciprocating compressor.

CompressibilityA factor expressing the deviation of a gas from the laws of thermodynamics.

Compression, AdiabaticCompression in which no heat is transferred to or from the gas during the compression process.

Compression, IsothermalCompression is which the temperature of the gas remains constant.

Compression, PolytropicCompression in which the relationship between the pressure and the volume is expressed by the equation PVn is a constant.

Compression RatioThe ratio of the absolute discharge pressure to the absolute inlet pressure.

Constant Speed ControlA system in which the compressor is run continuously and matches air supply to air demand by varying compressor load.

Critical PressureThe limiting value of saturation pressure as the saturation temperature approaches the critical temperature.

Critical TemperatureThe highest temperature at which well-defined liquid and vapor states exist. Sometimes it is defined as the highest temperature at which it is possible to liquefy a gas by pressure alone.

Cubic Feet Per Minute (cfm)Volumetric air flow rate.

cfm, free aircfm of air delivered to a certain point at a certain condition, converted back to ambient conditions.

Actual cfm (acfm)Flow rate of air at a certain point at a certain condition at that point.

Inlet cfm (icfm)cfm flowing through the compressor inlet filter or inlet valve under rated conditions.

Standard cfmFlow of free air measured and converted to a standard set of reference conditions (14.5 psia, 68°F, and 0 percent relative humidity).

Cut-In/Cut-Out PressureRespectively, the minimum and maximum discharge pressures at which the compressor will switch from unload to load operation (cut-in) or from load to unload (cut-out).

CycleThe series of steps that a compressor with unloading performs 1) fully loaded; 2) modulating (for compressors with modulating control); 3) unloaded; and 4) idle.

Cycle TimeAmount of time for a compressor to complete one cycle.

Degree of IntercoolingThe difference in air or gas temperature between the outlet of the intercooler and the inlet of the compressor.

DeliquescentMelting and becoming a liquid by absorbing moisture.

DesiccantA material having a large proportion of surface pores, capable of attracting and removing water vapor from the air.

Dew PointThe temperature at which moisture in the air will begin to condense if the air is cooled at constant pressure. At this point the relative humidity is 100 percent.

DemandFlow of air at specific conditions required at a point or by the overall facility.

DiaphragmA stationary element between the stages of a multi-stage centrifugal compressor. It may include guide vanes for directing the flowing medium to the impeller of the succeeding stage. In conjunction with an adjacent diaphragm, it forms the diffuser surrounding the impeller.

Diaphragm CoolingA method of removing heat from the flowing medium by circulation of a coolant in passages built into the diaphragm.

DiffuserA stationary passage surrounding an impeller, in which velocity pressure imparted to the flowing medium by the impeller is converted into static pressure.

Digital ControlsSee Logic Controls.

Discharge PressureAir pressure produced at a particular point in the system under specific conditions.

Discharge TemperatureThe temperature at the discharge flange of the compressor.

DisplacementThe volume swept out by the piston or rotor(s) per unit of time, normally expressed in cfm.

DroopThe drop in pressure at the outlet of a pressure regulator, when a demand for air occurs.

Dynamic Type CompressorsCompressors in which air or gas is compressed by the mechanical action of rotating impellers imparting velocity and pressure to a continuously flowing medium (can be centrifugal or axial design).

EfficiencyAny reference to efficiency must be accompanied by a qualifying statement which identifies the efficiency under consideration, as in the following definitions of efficiency:

Efficiency, CompressionRatio of theoretical power to power actually imparted to the air or gas delivered by the compressor.

Efficiency, IsothermalRatio of the theoretical work (as calculated on a isothermal basis) to the actual work transferred to a gas during compression.

Efficiency, MechanicalRatio of power imparted to the air or gas to brake horsepower (bhp).

Efficiency, PolytropicRatio of the polytropic compression energy transferred to the gas, to the actual energy transferred to the gas.

Efficiency, VolumetricRatio of actual capacity to piston displacement.

ExhausterA term sometimes applied to a compressor in which the inlet pressure is less than atmospheric pressure.

ExpandersTurbines or engines in which a gas expands, doing work, and undergoing a drop in temperature. Use of the term usually implies that the drop in temperature is the principle objective. The orifice in a refrigeration system also performs this function, but the expander performs it more nearly isentropically, and thus is more effective in cryogenic systems.

FiltersDevices for separating and removing particulate matter, moisture or entrained lubricant from air.

Flange ConnectionThe means of connecting a compressor inlet or discharge connection to piping by means of bolted rims (flanges).

FluidicsThe general subject of instruments and controls dependent upon low rate of flow of air or gas at low pressure as the operating medium. These usually have no moving parts.

Free AirAir at atmospheric conditions at any specified location, unaffected by the compressor.

Full-LoadAir compressor operation at full speed with a fully open inlet and discharge delivering maximum air flow.

GasOne of the three basic phases of matter. While air is a gas, in pneumatics the term gas normally is applied to gases other than air.

Gas BearingsLoad carrying machine elements permitting some degree of motion in which the lubricant is air or some other gas.

Gauge PressureThe pressure determined by most instruments and gauges, usually expressed in psig. Barometric pressure must be considered to obtain true or absolute pressure.

Guide VaneA stationary element that may be adjustable and which directs the flowing medium approaching the inlet of an impeller.

Head, AdiabaticThe energy, in foot pounds, required to compress adiabatically to deliver one pound of a given gas from one pressure level to another.

Head, PolytropicThe energy, in foot pounds, required to compress polytropically to deliver one pound of a given gas from one pressure level to another.

Horsepower, BrakeHorsepower delivered to the output shaft of a motor or engine, or the horsepower required at the compressor shaft to perform work.

Horsepower, IndicatedThe horsepower calculated from compressor indicator diagrams. The term applies only to displacement type compressors.

Horsepower, Theoretical or IdealThe horsepower required to isothermally compress the air or gas delivered by the compressor at specified conditions.

Humidity, RelativeThe relative humidity of a gas (or air) vapor mixture is the ratio of the partial pressure of the vapor to the vapor saturation pressure at the dry bulb temperature of the mixture.

Humidity, SpecificThe weight of water vapor in an air vapor mixture per pound of dry air.

HysteresisThe time lag in responding to a demand for air from a pressure regulator.

ImpellerThe part of the rotating element of a dynamic compressor which imparts energy to the flowing medium by means of centrifugal force. It consists of a number of blades which rotate with the shaft.

Indicated PowerPower as calculated from compressorindicator diagrams.

Indicator CardA pressure-volume diagram for a compressor or engine cylinder, produced by direct measurement by a device called an indicator.

InducerA curved inlet section of an impeller.

Inlet PressureThe actual pressure at the inlet flange of the compressor.

IntercoolingThe removal of heat from air or gas between compressor stages.

Intercooling, Degree ofThe difference in air or gas temperatures between the inlet of the compressor and the outlet of the intercooler.

Intercooling, PerfectWhen the temperature of the air or gas leaving the intercooler is equal to the temperature of the air or gas entering the inlet of the compressor.

Isentropic CompressionSee Compression, Isentropic.

Isothermal CompressionSee Compression, Isothermal.

LeakAn unintended loss of compressed air to ambient conditions.

Liquid Piston CompressorA compressor in which a vaned rotor revolves in an elliptical stator, with the spaces between the rotor and stator sealed by a ring of liquid rotating with the impeller.

Load FactorRatio of average compressor load to the maximum rated compressor load over a given period of  time.

Load TimeTime period from when a compressor loads until it unloads.

Load/Unload ControlControl method that allows the compressor to run at full-load or at no-load while the driver remains at a constant speed.

Modulating ControlSystem which adapts to varying demand by throttling the compressor inlet proportionally to the demand.

Multi-Casing CompressorTwo or more compressors, each with a separate casing, driven by a single driver, forming a single unit.

Multi-Stage Axial CompressorA dynamic compressor having two or more rows of rotating elements operating in series on a single rotor and in a single casing.

Multi-Stage Centrifugal Compressor-

A dynamic compressor having two or more impellers operating in

series in a single casing.

Multi-Stage CompressorsCompressors having two or more stages operating in series.

Perfect IntercoolingThe condition when the temperature of air leaving the intercooler equals the temperature of air at the compressor intake.

Performance CurveUsually a plot of discharge pressure versus inlet capacity and shaft horsepower versus inlet capacity.

Piston DisplacementThe volume swept by the piston; for multistage compressors, the piston displacement of the first stage is the overall piston displacement of the entire unit.

Pneumatic ToolsTools that operate by air pressure.

Polytropic CompressionSee Compression, Polytropic.

Polytropic HeadSee Head, Polytropic.

Positive Displacement CompressorsCompressors in which successive volumes of air or gas are confined within a closed space and the space mechanically reduced, resulting in compression. These may be reciprocating or rotating.

Power, Theoretical (Polytropic)The mechanical power required to compress polytropically and to deliver, through the specified range of pressures, the gas delivered by the compressor.

PressureForce per unit area, measured in pounds per square inch (psi).

Pressure, AbsoluteThe total pressure measured from absolute zero (i.e. from an absolute vacuum).

Pressure, CriticalSee Critical Pressure.

Pressure Dew PointFor a given pressure, the temperature at which water will begin to condense out of air.

Pressure, DischargeThe pressure at the discharge connection of a compressor. (In the case of compressor packages, this should be at the discharge connection of the package.)

Pressure DropLoss of pressure in a compressed air system or component due to friction or restriction.

Pressure, IntakeThe absolute total pressure at the inlet connection of a compressor.

Pressure RangeDifference between minimum and maximum pressures for an air compressor.  Also called cut-in/cut-out or load/no-load pressure range.

Pressure RatioSee Compression Ratio.

Pressure RiseThe difference between discharge pressure and intake pressure.

Pressure, StaticThe pressure measured in a flowing stream in such a manner that the velocity of the stream has no effect on the measurement.

Pressure, TotalThe pressure that would be produced by stopping a moving stream of liquid or gas. It is the pressure measured by an impact tube.

Pressure, VelocityThe total pressure minus the static pressure in an air or gas stream.

Rated CapacityVolume rate of air flow at rated pressure at a specific point.

Rated PressureThe operating pressure at which compressor performance is measured.

Required CapacityCubic feet per minute (cfm) of air required at the inlet to the distribution system.

ReceiverA vessel or tank used for storage of gas under pressure. In a large compressed air system there may be primary and secondary receivers.

Reciprocating CompressorCompressor in which the compressing element is a piston having a reciprocating motion in a cylinder.

Relative Humiditysee Humidity, Relative.

Reynolds NumberA dimensionless flow parameter ( η ∆ &lt; /:), in which η is a significant dimension, often a diameter, &lt; is the fluid velocity, ∆ is the mass density, and : is the dynamic viscosity, all in consistent units.

RotorThe rotating element of a compressor. In a dynamic compressor, it is composed of the impeller(s) and shaft, and may include shaft sleeves and a thrust balancing device.

SealsDevices used to separate and minimize leakage between areas of unequal pressure.

SequenceThe order in which compressors are brought online.

ShaftThe part by which energy is transmitted from the prime mover through the elements mounted on it, to the air or gas being compressed.

Sole PlateA pad, usually metallic and embedded in concrete, on which the compressor and driver are mounted.

Specific GravityThe ratio of the specific weight of air or gas to that of dry air at the same pressure and temperature.

Specific HumidityThe weight of water vapor in an air-vapor mixture per pound of dry air.

Specific PowerA measure of air compressor efficiency, usually in the form of bhp/100 acfm.

Specific WeightWeight of air or gas per unit volume.

SpeedThe speed of a compressor refers to the number of revolutions per minute (rpm) of the compressor drive shaft or rotor shaft.

StagesA series of steps in the compression of air or a gas.

Standard AirThe Compressed Air &amp; Gas Institute and PNEUROP have adopted the definition used in ISO standards. This is air at 14.5 psia (1 bar); 68°F (20°C) and dry (0 percent relative humidity).

Start/Stop ControlA system in which air supply is matched to demand by the starting and stopping of the unit.

SurgeA phenomenon in centrifugal compressors where a reduced flow rate results in a flow reversal and unstable operation.

Surge LimitThe capacity in a dynamic compressor below which operation becomes unstable.

Temperature, AbsoluteThe temperature of air or gas measured from absolute zero. It is the Fahrenheit temperature plus 459.6 and is known as the Rankin temperature. In the metric system, the absolute temperature is the Centigrade temperature plus 273 and is known as the Kelvin temperature.

Temperature, CriticalSee Critical Temperature.

Temperature, DischargeThe total temperature at the discharge connection of the compressor.

Temperature, InletThe total temperature at the inlet connection of the compressor.

Temperature Rise RatioThe ratio of the computed isentropic temperature rise to the measured total temperature rise during compression. For a perfect gas, this is equal to the ratio of the isentropic enthalpy rise to the actual enthalpy rise.

Temperature, StaticThe actual temperature of a moving gas stream. It is the temperature indicated by a thermometer moving in the stream and at the same velocity.

Temperature, TotalThe temperature which would be measured at the stagnation point if a gas stream were stopped, with adiabatic compression from the flow condition to the stagnation pressure.

Theoretical PowerThe power required to compress a gas isothermally through a specified range of pressures.

TorqueA torsional moment or couple. This term typically refers to the driving couple of a machine or motor.

Total Package Input PowerThe total electrical power input to a compressor, including drive motor, belt losses, cooling fan motors, VSD or other controls, etc.

Unit Type CompressorsCompressors of 30 bhp or less, generally combined with all components required for operation.

Unload(No-load) compressor operation in which no air is delivered because the intake is closed or modified not to allow inlet air to be trapped.

Vacuum PumpsCompressors which operate with an intake pressure below atmospheric pressure and which discharge to atmospheric pressure or slightly higher.

ValvesDevices with passages for directing flow into alternate paths or to prevent flow.

VoluteA stationary, spiral shaped passage which converts velocity head to pressure in a flowing stream of air or gas.

Water-Cooled CompressorCompressors cooled by water circulated through jackets surrounding cylinders or casings and/or heat exchangers between and after stages.

## Appendix B: Packaged Compressor Efficiency Ratings

Evaluating and comparing industrial air compressor capacities and efficiencies can be a daunting task. Standards exist for testing the performance of a compressor, but they have not always been applied in a consistent manner, and performance test results and efficiency ratings are not always published in consistent, standard formats. The result is that purchasers of air compressors can find it difficult to compare the equipment performance.

- · International Standards Organization (ISO)-ISO 1217, Displacement Compressors Acceptance Tests [distributed in the United States by the American National Standards Institute (ANSI)]

The Compressed Air and Gas Institute (CAGI), the primary compressed air industry trade association in the United States, has developed performance testing standards.  CAGI, in conjunction with its European counterpart PNEUROP, has developed simplified performance testing standards which have been incorporated as addenda in International Standards Organization (ISO) Standard ISO 1217, Displacement Compressors Acceptance Tests. These Simplified Test Codes were adopted by the membership of CAGI and will be reflected in performance data published in manufacturers' literature. Some CAGI members also have ISO 9001 Certification which requires documentation of compliance with published performance and procedures.

Compressed air system users should be aware that not all manufacturers marketing compressors in the United States are members of CAGI, and some may test their compressors using different standards.

The following standards have been developed for measuring air compressor performance.

- · CAGI/PNEUROP-Acceptance Test Code for Bare Displacement Air Compressors (PN2CPTC1)
- · CAGI/PNEUROP-Acceptance Test Code for Electrically-Driven Packaged Displacement Air Compressors (PN2CPTC2)
- · CAGI/PNEUROP-Acceptance Test Code for I.C. Engine-Driven Packaged Displacement Air Compressors (PN2CPTC3)
- · American Society of Mechanical Engineers (ASME)Power Test Code 9, Displacement Compressors, Vacuum Pumps, and Blowers

The revised ISO 1217 with Simplified Test Codes will likely be the most commonly used standard in the future. CAGI has also developed data sheets outlining a common format and style for reporting compressor performance, including efficiency. For more information on CAGI Data Sheets, see Appendix C .

The industry norm for comparison of compressor efficiency is given in terms of brake horsepower per actual cubic feet per minute (bhp/100 acfm) at a compressor discharge pressure of 100 pounds per square inch gauge (psig). A typical single-stage, lubricant-injected, rotary screw compressor will have a rating of approximately 22 bhp/100 acfm (referenced to standard inlet conditions). Users should remember that performance at site conditions will be different from test data because of differences in factors such as ambient temperature, pressure, and humidity.

Even when accurate, consistent efficiency information is available, it may only be specified for full-load operation (i.e., full capacity and specified full-load discharge pressure). Since most systems operate at part-load much of the time, it is also important to compare part-load efficiencies when evaluating the performance of different compressors. The variety of control methods can, however, make this difficult.

When gathering information on compressor performance and comparing different models, users should make sure the compressors have been tested using the same standard, at the same conditions, and that the data is being reported in a consistent manner. Some situations can lead to 'apples-and-oranges' comparisons. For example:

- · Manufacturers may test their compressors under different 'standard' conditions. Standard conditions should be at 14.5 psia (1 bar); 68°F (20°C) and dry (0 percent relative humidity).

- · The actual full-load power required by a typical air compressor package might exceed the nominal nameplate rating of the main-drive electric motor. Such motors have a continuous service factor, usually 15 percent, which allows continuous operation at 15 percent above the nominal rating. Most manufacturers use up to two-thirds of the available service factor, so that full-load power will be 10 percent above the nominal motor rating. It is therefore important to use the bhp rating, not the motor nameplate horsepower (hp) rating, when comparing efficiency ratings in hp/acfm. To include the motor efficiency and all package accessories and losses, use a rating in total kilowatt input per acfm to provide more precise data.
- · Manufacturers may use a flange-to-flange rating that does not include inlet, discharge, and other package losses. This can affect overall efficiency by 5 percent or more.
- · Energy consumption for accessory components, such as cooling fan motors, may not be treated consistently.
- · Manufacturers may apply ranges or tolerances to performance data.
- · Performance is usually based on perfect intercooling, which may not be realized under actual operating conditions. Perfect intercooling requires the air inlet temperature at each stage to be the same, requiring a cooling water temperature approximately 15°F below the ambient air temperature. Poor intercooling will adversely affect compressor performance.

As the revised ISO standard and CAGI Compressor Data Sheets become more commonly used, these equipment comparison problems should become less significant.

## Appendix C: CAGI's Compressor and Dryer Data Sheets

These data sheets have been developed by the Compressed Air &amp; Gas Institute (CAGI) as an aid to the end user/customer in the selection of pneumatic equipment for the planned operating conditions. The data sheets can be used to compare like equipment under equal operating parameters. Data sheets for rotary screw compressors, refrigerant dryers, and regenerative desiccant type dryers are included in this appendix.

The members of the Compressed Air &amp; Gas Institute (CAGI) have long been involved in standards for the equipment manufactured by the industry. CAGI has worked closely with the European Committee of Compressors, Vacuum Pumps and Pneumatic Tools (PNEUROP), the International Organization for Standardization (ISO), and other standards development bodies to develop appropriate standards for compressed air and gas equipment.

CAGI and PNEUROP developed Simplified Test Codes which have been incorporated as appendices to ISO 1217. CAGI members agreed that published performance of their products would be based upon the Simplified Test Codes, and Performance Data Sheets were developed to provide a standardized method of presenting the performance data. The attached data sheets allow a common basis for comparison of rotary screw compressors, a type of displacement compressor.

For displacement type compressors, including rotary screw compressors, American Society of Mechanical Engineers (ASME) Power Test Code 9 has been the recognized performance standard in the United States and ISO 1217 in Europe. These are too complex for performance testing in volume production.

CAGI has also developed similar Performance Data Sheets for Refrigerant Type, Regenerative Desiccant Type, and Membrane Type Compressed Air Dryers to allow a common basis for performance comparison. As a sponsor of the Compressed Air Challenge ® , CAGI agreed to include these Performance Data Sheets in the sourcebook for use by those involved with the performance characteristics of compressors and dryers. Additional Performance Data Sheets will be added for centrifugal air compressors and other compressed air equipment as they become available. CAGI is also preparing a consumer fact sheet that will assist consumers in using the Performance Data Sheets.

## Compressor Data Sheet Rotary Screw Compressor

## Model Data

| 1   | Manufacturer                                                                      | Manufacturer                                                                      | Manufacturer   |
|-----|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|----------------|
| 2   | Model Number                                                                      | Model Number                                                                      |                |
|     | Air-cooled                                                                        | Water-cooled                                                                      |                |
|     | Oil-injected                                                                      | Oil-free                                                                          | UNIT           |
| 3   | Rated Capacity at Full-Load Operating Pressure a, e                               | Rated Capacity at Full-Load Operating Pressure a, e                               | acfm a, e      |
| 4   | Full-Load Operating Pressure b                                                    | Full-Load Operating Pressure b                                                    | psig b         |
| 5   | Maximum Full Flow Operating Pressure c                                            | Maximum Full Flow Operating Pressure c                                            | psig c         |
| 6   | Drive Motor Nameplate Rating                                                      | Drive Motor Nameplate Rating                                                      | hp             |
| 7   | Drive Motor Nameplate Nominal Efficiency                                          | Drive Motor Nameplate Nominal Efficiency                                          | percent        |
| 8   | Fan Motor Nameplate Rating (if applicable)                                        | Fan Motor Nameplate Rating (if applicable)                                        | hp             |
| 9   | Fan Motor Nameplate Nominal Efficiency (if applicable)                            | Fan Motor Nameplate Nominal Efficiency (if applicable)                            | percent        |
| 10  | Total Package Power Input at Rated Capacity and Full-Load Operating Pressure d    | Total Package Power Input at Rated Capacity and Full-Load Operating Pressure d    | kW d           |
| 11  | Specific Package Input Power at Rated Capacity and Full-Load Operating Pressure f | Specific Package Input Power at Rated Capacity and Full-Load Operating Pressure f | kW/100 cfm f   |

## NOTES:

- a. Measured at the discharge terminal point of the compressor package in accordance with the CAGI/PNEUROP PN2CPTC2 Test Code (Annex C to ISO 1217). ACFM is actual cubic feet per minute at inlet conditions.
- b. The operating pressure at which the Capacity (Item 3) and Electrical Consumption (Item 10) were measured for this data sheet.
- c. Maximum pressure attainable at full flow, usually the unload pressure setting for load/no-load control or the maximum pressure attainable before capacity control begins. May require additional power.
- d. Total package input power at other than reported operating points will vary with control strategy.
- e, f.Tolerance is specified in the CAGI/PNEUROP PN2CPTC2 Test Code (Annex C to ISO 1217) as follows:

| Volume Flow Rate at specified conditions   | Volume Flow Rate at specified conditions   | Volume Flow Rate e   | Specific Energy Consumption f   |
|--------------------------------------------|--------------------------------------------|----------------------|---------------------------------|
| m 3 /min                                   | ft 3 /min                                  | %                    | %                               |
| Below 0.5                                  | Below 15                                   | +/- 7                | +/- 8                           |
| 0.5 to 1.5                                 | 15 to 50                                   | +/- 6                | +/- 7                           |
| 1.5 to 15                                  | 50 to 500                                  | +/- 5                | +/- 6                           |
| Above 15                                   | Above 500                                  | +/- 4                | +/- 5                           |

<!-- image -->

This form was developed by the Compressed Air and Gas Institute for the use of its members. CAGI has not independently verified the reported data.

## Dryer Data Sheet Refrigerant Dryers

| Model Data   | Model Data                | Model Data   | Model Data   |
|--------------|---------------------------|--------------|--------------|
| 1            | Manufacturer              |              |              |
| 2            | Model Number              |              |              |
| 3            | Cycling/Non-Cycling       |              |              |
| 4            | Refrigerant               |              |              |
|              | Type                      |              | psig         |
|              | Description               | Full Flow    | Units        |
| 5            | Tested Flow*              |              | scfm**       |
| 6            | Outlet Pressure Dewpoint  |              | ¡F           |
| 7            | Pressure Drop             |              | psi(d)       |
| 8            | Total Dryer Input Power   |              | kW           |
| 9            | Specific Package Power*** |              | kW/100 scfm  |

- * Dryer ratings at the following inlet conditions to the dryer (as per adopted CAGI Standard ADF 100):
- ¥ Inlet Compressed Air Temperature:100¡F (37.78¡C)
- ** SCFM defined as the volume of free air in cubic feet per minute measured at 14.5 psia (1.0 Bar), 68¡F (20¡C) temperature and 0% R.H. (0 WVP).
- *** (Total Dryer Input Power/tested flow) x 100

¥ Inlet Compressed Air Pressure:

100 psig (6.9 Bar)

¥ Max. Ambient Air Temperature:

100¡F (37.78¡C)

¥ Inlet Compressed Air Relative Humidity

100% (Saturated)

<!-- image -->

This form was developed by the Compressed Air and Gas Institute for the use of its members. CAGI has not independently verified the reported data.

## Dryer Data Sheet Regenerative Desiccant-Type Dryers

| Model Data             | Model Data                 | Model Data             | Model Data   |
|------------------------|----------------------------|------------------------|--------------|
| 1                      | Manufacturer               |                        |              |
| 2                      | Model Number               |                        |              |
| 3                      | Unit Type                  |                        |              |
| 4                      | Desiccant Type             |                        | psig         |
| Description            | Description                | Full Flow              | Units        |
| 5                      | Maximum Design Flow*       |                        | scfm**       |
| 6                      | Outlet Pressure Dewpoint   |                        | ¡F           |
| 7                      | Pressure Drop              |                        | psi(d)       |
| 8                      | Purge Flow (average)       |                        | scfm         |
| Calculated Power-Purge | Calculated Power-Purge     | Calculated Power-Purge | kW           |
| 9                      | Total Dryer Input Power*** |                        | kW           |
| 10                     | Specific Package Power**** |                        | kW/100 scfm  |

- * Dryer ratings at the following inlet conditions to the dryer (as per adopted CAGI Standard ADF 200):
- ¥ Inlet Compressed Air Temperature:100¡F (37.78¡C)
- ¥ Inlet Compressed Air Pressure:

100 psig (6.9 Bar)

- ¥ Inlet Compressed Air Relative Humidity

100% (Saturated)

- ** SCFM defined as the volume of free air in cubic feet per minute measured at 14.5 psia (1.0 Bar), 68¡F (20¡C) temperature and 0% R.H. (0 WVP).
- *** This total includes Calculated Power-Purge, Input Power for Blower and/or Heater (if any), and Control Power

## ****(Total Dryer Input Power/Max. Design Flow) x 100

## Assumptions:

- 1. Average purge flow power calculation: (Purge Flow/4.2) x .746
- 2. Blower run time is average over one half a cycle.
- 3. Heater run time is average over one half a cycle.

<!-- image -->

This form was developed by the Compressed Air and Gas Institute for the use of its members. CAGI has not independently verified the reported data.

## Dryer Data Sheet Membrane-Type Dryers

## Model Data-For Compressed Air

| 1   | Manufacturer                                                                        | Manufacturer                                                                        | Manufacturer   |
|-----|-------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|----------------|
| 2   | Model Number                                                                        | Model Number                                                                        | Model Number   |
|     | Air-cooled                                                                          | Water-cooled                                                                        |                |
|     | Oil-injected                                                                        | Oil-free                                                                            | UNIT           |
| 3   | Rated Capacity at Full-Load Operating Pressure a,e                                  | Rated Capacity at Full-Load Operating Pressure a,e                                  | acfm a,e       |
| 4   | Full-Load Operating Pressure b                                                      | Full-Load Operating Pressure b                                                      | psig b         |
| 5   | Maximum Full Flow Operating Pressure c                                              | Maximum Full Flow Operating Pressure c                                              | psig c         |
| 6   | Drive Motor Nameplate Rating                                                        | Drive Motor Nameplate Rating                                                        | hp             |
| 7   | Drive Motor Nameplate Efficiency                                                    | Drive Motor Nameplate Efficiency                                                    | percent        |
| 8   | Fan Motor Nameplate Rating (if applicable)                                          | Fan Motor Nameplate Rating (if applicable)                                          | hp             |
| 9   | Fan Motor Nameplate Efficiency (if applicable)                                      | Fan Motor Nameplate Efficiency (if applicable)                                      | percent        |
| 10  | Total Package Power Input at Rated Capacity and Full-Load Operating Pressure d      | Total Package Power Input at Rated Capacity and Full-Load Operating Pressure d      | kW d           |
| 11  | Specific Package Input Power at Rated Capacity and Full-Load Operating Pressure e,f | Specific Package Input Power at Rated Capacity and Full-Load Operating Pressure e,f | kW/100 cfm e,f |

- a. Measured at the discharge terminal point of the compressor package in accordance with the CAGI/PNEUROP PN2CPTC2 Test Code (Annex C to ISO 1217). ACFM is actual cubic feet per minute at inlet conditions.
- b. The operating pressure at which the Capacity (Item 3) and Electrical Consumption (Item 10) were measured for this data sheet.
- c. Maximum pressure attainable at full flow, usually the unload pressure setting for load/no-load control or the maximum pressure attainable before capacity control begins. May require additional power.
- d. Total package input power at other than reported operating points will vary with control strategy.
- e, f. Tolerance is specified in the CAGI/PNEUROP PN2CPTC2 Test Code (Annex C to ISO 1217) as follows:

| Volume Flow Rate at specified conditions   | Volume Flow Rate at specified conditions   | Volume Flow Rate e   | Specific Energy Consumption f   |
|--------------------------------------------|--------------------------------------------|----------------------|---------------------------------|
| m 3 /min                                   | ft 3 /min                                  | %                    | %                               |
| Below 0.5                                  | Below 15                                   | +/- 7                | +/- 8                           |
| 0.5 to 1.5                                 | 15 to 50                                   | +/- 6                | +/- 7                           |
| 1.5 to 15                                  | 50 to 500                                  | +/- 5                | +/- 6                           |
| Above 15                                   | Above 500                                  | +/- 4                | +/- 5                           |

<!-- image -->

This form was developed by the Compressed Air and Gas Institute for the use of its members. CAGI has not independently verified the reported data.

## Appendix D: The Compressed Air System Marketplace

Compressed air is used in a wide variety of commercial and industrial applications. It is used to lift, hold, and position pneumatic and hydraulic devices; to operate air cylinder devices such as rivet guns and chipping hammers; to pressurize and atomize paint in spray guns; to operate air motors on grinders and drills; and to agitate liquids. In these applications, compressed air offers the advantages of being flexible, versatile, safe, and lightweight.

processing, pharmaceuticals, and electronics. Lubricantinjected, rotary screw air compressors are the dominant type used in applications above 25 hp, accounting for 75 percent of unit sales. The popularity of the rotary screw air compressor is because of its low initial and maintenance costs and lower noise and vibration.

## Market Size and Energy Consumption

More than 1 million air compressors are sold in the United States each year, the majority of which are powered by small motors of 5 horsepower (hp) or less. These small compressors are sold primarily to the commercial and residential markets to operate portable tools, air pumps, and pneumatic heating, ventilation, and air conditioning (HVAC) controls. Although these small compressors account for approximately 98 percent of all air compressors sold, they account for only 12 percent of annual electricity consumption. Larger air compressors (25 hp or above) on the other hand, are sold primarily to the industrial and institutional sector. Although they account for less than 1 percent of annual sales, they represent an estimated 80 percent of the annual electricity consumption.

Industrial sector air compressors are typically plant air compressors in the range of 10 to 350 hp. Compressors larger than 350 hp are typically used to supply air for large process applications or plant air for very large manufacturing facilities. According to a recent analysis by Easton Consultants, Inc., energy consumption by these two populations of air compressors is approximately 27 to 32 terawatt hours per year, equivalent to about 6 percent of all motordriven electricity consumption in the industrial sector.

There are three basic types of (plant) air compressors: reciprocating, rotary screw, and centrifugal. Within the compressor types, options such as lubricated and lubricant-free designs are available. For example, lubricant-free rotary screw compressors are used in applications that require clean air, such as food

Although tools driven by compressed air can consume 10 times as much energy as comparable electric tools, they are used because of their ability to provide high torque in a small, light, and safe package, and because they usually have significantly lower maintenance costs than electric tools in manufacturing environments. The primary benefits of using compressed air in applications instead of alternative approaches include flexibility, versatility, and safety.

## Compressed Air System Marketplace

The air compressor marketplace (see Figure D-1.1) is somewhat complex, with at least five key players or stakeholders.

- • Air compressor manufacturers
- • Air compressor auxiliary equipment manufacturers
- • Air compressor and auxiliary equipment distributors
- • Contractors and architect-engineering (A&amp;E) firms
- • Compressed air system users.

In addition to influencing each other, these stakeholders are affected by trade associations, auditors, governmental entities, and electric utilities.

Each of the stakeholder groups is discussed below.

## Air Compressor Manufacturers

Rotary compressor or 'air-end' manufacturers play a primary role in the air compressor industry. Since they are involved in component design and manufacturing, packaging, and assembly, they determine the effort applied to compressor engineering and the overall level of efficiency of compressor packages.  A standard air compressor package consists of an electric motor, motor starter, compressor, controls,

Figure D-1.1  The Compressed Air System Marketplace.

<!-- image -->

filter, lubricant and air coolers, and lubricant/air separator. An air-end accounts for a significant portion of a packaged air compressor's initial cost.

The market structure for plant air compressors is a mature market that has, in recent years, made the transformation from reciprocating to rotary screw compressors. A number of factors led to this transformation, including the lower first cost, lower maintenance requirements, and ease of installation of rotary screw units compared with reciprocating compressors. The market is fairly well concentrated and competitive, and the number of companies that manufacture industrial compressors continues to decline. Single-stage, lubricant-injected, rotary screw type compressors account for about 70 percent of the market. The industrial compressor market is dominated by a handful of manufacturers. Most domestic manufacturers are members of the Compressed Air and Gas Institute (CAGI). In addition, a few nondomestic companies also market compressors in the United States. Since compressor equipment is perceived as a commodity, competition is high. Taking inflation into account, industrial compressor prices have fallen over the past 5 years.

## Auxiliary Equipment Manufacturers

Auxiliary equipment manufacturers produce components such as filters, dryers, aftercoolers, receiver tanks, pneumatic tools, lubricant separators, and distribution system components. There are thousands of different equipment manufacturers, ranging in size from small, family-owned businesses to large, multi-national corporations.

## Air Compressor Distributors

A group of 500 to 600 distributors dominate the plant air compressor market, representing 85 to 90 percent of sales. The remainder are sold directly from the manufacturer to the compressed air system user, specifying engineer, or design-build contractor. Sales to other original equipment manufacturers are rare.

Distributors provide many useful services to compressed air system users and specifying engineers by offering information on new products, responding to requests for bids, supplying sample specifications, providing compressed air system design recommendations, and offering parts and service.

Although many distributors furnish detailed technical proposals with sound engineering design,

they are often not able to convince the user to purchase a higher-cost compressed air system design based on energy efficiency, even though total life-cycle costs are lower on the energy efficient system. This is in part because of the way requests-for-proposals are issued by compressed air system users. Often decisions are made purely on the lowest initial cost. Depending on customer specifications, distributors may offer a high-cost, energy-efficient compressed air system, along with a low-cost, less efficient system.

There are three types of distributors who provide different levels of service to the market: compressed air specialists, general industrial distributors, and warehouse distributors.

Compressed Air Specialists. Compressed air specialists work with complete compressed air systems, including the compressor and all ancillary components. These firms typically offer assistance with layout, specification, and sizing of components, storage, and controls. They offer a wide variety of maintenance programs, complete parts and service facilities, and locally stocked parts inventories. Compressed air specialists may also test, audit, and redesign systems, or install the complete system including the distribution network.

General Industrial Distributors. General industrial distributors offer limited assistance in system design; most of their business is responding to bids or specifications. These distributors also depend on parts and service business, but they do not generally service or install complete compressed air systems or offer consulting services on existing systems like distributors that specialize in compressed air systems or professional compressed air system auditors.

Warehouse Distributors. Warehouse distributors offer little or no technical support services, and do not provide repair, maintenance, or other services. Their sales tend to lean toward smaller equipment.

## Contractors and Architect-Engineering Firms

Contractors and architect-engineering (A&amp;E) firms are typically concerned with designing and specifying systems for reliability, ease of maintenance, and low noise, but not for efficiency. Other than a small number of national firms, regional and local consulting engineering firms generally lack an air compressor system department or specialist. Contractors and A&amp;E firms often do, however, play an important role in writing equipment bid specifications. Since it is often difficult to compare the performance of equipment offered by different manufacturers, consulting engineers may oversize equipment by using high-safety factors.

## Compressed Air System Users

Industrial users of compressed air systems possess a wide range of expertise. While a small number of large, sophisticated firms have compressed air specialists in-house and proactively manage and control their plant's compressed air systems, many manufacturers do not, although the situation is improving. Compressed air system users often misdiagnose problems in air systems and do not recognize the amount of energy wasted due to poor compressed air system design, equipment selection, and operation and maintenance (O&amp;M) practices. In addition, users are not represented by an industry or professional organization that emphasizes compressed air system issues.

Compressed air system users often do not consider energy costs when buying new air compressors. Because of a focus on lowest first cost, which is driven by separate budgeting and accounting for operating and capital costs, energy-efficient options (such as premium efficiency motors, the best microprocessor and partload controls, and the most efficient equipment type or model for the applications) are usually not purchased.

## Rebuilders

Compressor rebuilders are a rather minor force in the air compressor market with less than 5 percent of unit sales. Rebuilders were a larger influence 2 decades ago when reciprocating compressors dominated the plant air market and rebuilt equipment accounted for 25 percent of sales. Today, users are more likely to replace their defunct reciprocating compressor with a low-cost rotary compressor instead of rebuilding it. Remanufacturing is performed by some manufacturers and distributors and by a few independent rebuilders.

## Compressed Air System Audit Firms

Compressed air system audit firms audit, analyze and troubleshoot a plant's compressed air systems and then recommend improvements to equipment, systems, and O&amp;M practices. Audits can frequently decrease energy consumption by 20 to 50 percent or more with actions such as revised operation and maintenance plans, leak programs, equipment downsizing, and

other efficiency upgrades. Auditors may be independent consultants or affiliated with manufacturers of controls, compressors, or auxiliary equipment.

## Other Stakeholders

The other stakeholders that play a major role in the compressed air system marketplace by influencing it include trade associations, crosscutting organizations, government entities, and electric utilities. Each is discussed below.

## Trade Associations.

CAGI -The most important trade association in the compressed air industry is the Compressed Air and Gas Institute (CAGI). CAGI is a nonprofit organization of 45 companies that manufacture air and gas compressors, pneumatic machinery and air and gas drying equipment; products which have a myriad of applications worldwide in construction, manufacturing, mining, and the process and natural gas industries.

The principal objectives of the CAGI are:

- · To promote cooperation among its members for the improved production, proper use and increased distribution of air and gas compressors and related equipment
- · To develop and publish standards and engineering data for air and gas compressors and related equipment
- · To increase the amount, and improve the quality of service of air and gas compressors and related equipment to the general public
- · To collect and distribute information of value to CAGI members and to the general public
- · To engage in cooperative educational and research activities
- · To cooperate with governmental departments and agencies and other bodies in matters affecting the industry.

Many of CAGI's activities are carried out in its separate sections, which are categorized by product scope. Individual member companies may affiliate with one or more of these sections, depending upon their product lines.

In addition, important work of the Institute is carried out by committees, whose membership is composed of one representative from each section. These ongoing committees include the Energy

Awareness, Educational and Promotional, Standards, Statistical Coordinating, and Technical.

More information on CAGI can be found in the sections of this sourcebook on BestPractices and the Compressed Air Challenge ®  (CAC), and in the fact sheet titled Packaged Compressor Efficiency Ratings . CAGI contact information can be found in the section titled Directory of Contacts .

Compressor Distributor Associations -Another important group of trade associations serves compressed air equipment distributors. Compressor distributor associations usually focus around one compressor manufacturer. Several associations coordinate their activities for the CAC through an umbrella group named the Compressor Distributors Association (CDA). Distributor association contact information can be found in the section titled Directory of Contacts .

Crosscutting Organizations. The CAC is a national effort involving all compressed air system stakeholders aimed at improving compressed air system performance. This collaborative will: deliver best-practice compressed air system information to the plant floor; create a consistent national market message that supports the application of these best practices; provide a technically sound and professionally delivered training program for plant operating personnel; and through a certification program, recognize plant personnel's skills in operating compressed air systems. Participants include large industrial users of compressed air; manufacturers and distributors of compressed air equipment and their associations; facility engineers and their associations; compressed air system consultants; state research and development agencies; energy efficiency organizations; and utility companies. The CAC is described in detail in the Where To Find Help section of this sourcebook.

Government Entities. The major governmental influence on the compressed air systems marketplace is the U.S. Department of Energy's (DOE) BestPractices program, which is an industry/government partnership designed to help industry improve the performance of their  systems (including compressed air systems). BestPractices activities are described in the Where To Find Help section of this sourcebook.

Electric Utilities. During the past 10 to 15 years, electric utilities have influenced the compressed air system marketplace primarily through their demandside management programs, largely under the influence

of state utility regulatory boards. Many electric utilities offered programs, such as compressor rebates that paid the incremental cost difference between a highperformance compressor and one of an an average efficiency, or offered free or reduced-priced audits of compressed air systems. Most of these programs have now been discontinued, however.

As the electric utilities industry continues to deregulate and evolve, many utilities are interested in providing value-added energy services to their industrial customers. Compressed air systems offer a good opportunity for such services. Under the unregulated environment, utilities may offer anything from assistance with audits to complete outsourcing of a customer's compressed air operations.

## The Market for Compressed Air System Efficiency Services

The Assessment of the Market for Compressed Air Efficiency Services 1 is a report commissioned by DOE with technical support provided by CAC. The objective of this report is to provide a comprehensive and balanced view of the market for engineering and consulting services to improve the energy efficiency of plant compressed air systems. These services include plant assessments or audits to identify opportunities to improve compressed air system operations, preventive maintenance services, such as leak detection and repair that are aimed at reducing energy use, and redesign of controls and other system components to reduce energy use. The report is intended for use by the CAC and other industrial energy efficiency program operators in developing strategies to encourage the growth of the compressed air system efficiency industry and enhance the quality of the services it offers. Compressed air system vendors and designers may also find it useful in charting their own approach to providing energy efficiency services.

- · To what extent are customers in key end-use sectors aware of compressed air usage, costs, and savings opportunities?
- · What practices do these customers follow to monitor, maintain, and enhance the efficiency of compressed air systems?
- · What, if any, services do these customers purchase to maintain or enhance the efficiency of compressed air systems?
- · What barriers do customers experience in purchasing such services?

The key research questions on the supply-side of the market were:

- · What efficiency services do compressed air distributors, installers, and consultants currently offer?
- · What is the current volume of sales for these services (number of customers, number of projects, dollar volumes)? How has volume changed over the past few years? What are vendors' expectations regarding growth?
- · What role do these services play in the overall business strategy of manufacturers, distributors, and consultants?
- · What barriers do these businesses face in developing and selling compressed air system efficiency services?

## Key Findings

## Demand-Side Findings

The project was designed to answer a number of key questions concerning the demand and supply sides of the market for compressed air efficiency services. Among the key research questions to be addressed on the demand side of the market were:

- · Customer awareness of and concern for compressed air efficiency is low. Only 9 percent of customers interviewed for the program identified controlling energy costs as the primary objective in compressed air system maintenance and management. Only 17 percent mentioned efficiency at all as a system management objective. This low level of interest and knowledge was echoed in findings from the regional studies and interviews with compressed air system efficiency consultants.
- · Maintenance of consistent, reliable compressed air supply is the principal objective of system manage ment. Seventy-one percent of customers reported that ensuring adequate air supply is their primary objective in system management. According to

1 XENERGY, Inc. (June 2001) Assessment of the Market for Compressed Air Efficiency Services , U.S. DOE in cooperation with Lawrence Berkeley National Laboratory and Oak Ridge National Laboratory.

- consultants interviewed for this project, concern about operating consistency provides an effective route to selling efficiency-oriented services.
- · A large portion of customers report serious problems in compressed air system operation and maintenance. Thirty-five percent of those interviewed reported that they had experienced unscheduled shutdowns of their compressed air systems during the previous 12 months. For 60 percent of these establishments, or 21 percent of all establishments, the shutdown had lasted 2 days or more. Two-thirds of the customers reported experiencing potentially serious operating problems in their compressed air systems. Excess moisture and inadequate air pressure were the most frequently reported problems.
- · A significant portion of customers report having service contracts for their compressed air systems, but few of these contracts address system efficiency. Thirty percent of customers reported that they had service contracts for their compressed air systems. However, only one-third of these (or 10 percent of all participants) reported that efficiency-oriented services such as leak detection, energy-use monitor ing, or assessment of control strategies were included in the service contract. There was no difference in the incidence of unscheduled system shutdowns or operating problems between customers with service contracts and those without such contracts.
- · Thirty-five percent of customers interviewed reported that they conducted leak prevention programs.
- · Reported implementation of compressed air efficiency measures is very low. The United States Industrial Electrical Motor Market Opportunities Assessment 2 Assessment found that 57 percent of manufacturing plants had taken no action to improve compressed air system efficiency-including repairing leaksin the 2 years prior to the survey. A 1999 survey of 270 large industrial users served by Pacific Gas &amp; Electric obtained a similar finding.
- · Seventy-five percent of operators of the systems installed had had no formal training in compressed air system efficiency.
- · Seventeen percent of customers reported that they had undertaken a compressed air system audit over the past 7 years. Most of the audits had been conducted in the past 6 years; and six audits were underway at the time of the interview. While most
- of the audits included estimates of energy use and identified potential energy-saving measures, fewer than half included estimated savings and costs for recommended measures. Two-thirds of the customers who conducted system audits reported that they had implemented at least one of the recommended measures.
- · One-third of the customers reported that vendors selling 'services specifically designed to reduce energy costs in compressed air systems' had approached them. The nature of these services varied widely. The most frequently mentioned were preventive maintenance for compressors, assessment of control strategies, and identification of energy-saving measures. No one service was mentioned by more than 46 percent of those interviewed. This result reflects the formative state of the market for compressed air system efficiency services. Vendors have not defined the nature of such services consistently. Only 3 percent of customers reported that they had purchased compressed air efficiency services in response to these sales approaches. The most frequent objections to these services were high cost and the customers' view that they could undertake such activities with in-house staff.

## Supply-Side Findings

- ¥ A large portion of distributors report that they offer compressed air efficiency services. Over three-quarters offer system-efficiency measures, while over one-half offer end-use analyses and leak services.
- · Over one-half of vendors feel that the demand for efficiency services has increased in the last year.
- · Most distributors that offer efficiency-related services have entered the market within the past 10 years; one-third have entered in the past 4 years.
- · Most distributors interviewed consider efficiency services essential to their competitive positions. Sixty-seven percent of distributors rate efficiency services as being important to their competitive position. Their major motivation to enter the market is customer retention. With the number of firms that offer efficiency services increasing, vendors believed that they needed to reply in kind to maintain satisfaction among their equipment purchasers. Access to additional revenue streams from consulting was not mentioned at all as a motivating factor.

2 XENERGY, Inc. (1998) United States Industrial Electrical Motor Market Opportunities Assessment , U.S. DOE and Oak Ridge National Laboratory.

- · Most distributors identified customers' lack of understanding of the benefits of compressed air efficiency measures as the major barrier to their increased sale. These findings mirror the experience of compressed air efficiency consultants. Forty-five percent of the vendors identified customer perceptions that compressed air efficiency services were already being provided by in-house staff as an objection to sales efforts. This finding, combined with the reported low incidence of specific measure implementation, further reinforces the consultants' observation that customers are largely in the dark about the nature of compressed air system efficiency measures and maintenance practices.

## Appendix E: Guidelines for Selecting a Compressed Air System Provider

Compressed air is one of the most important utility requirements of the typical industrial manufacturer. Compressed air is used throughout many processes, such as pneumatic tools, pneumatic controls, compressed air operated cylinders for machine actuation, product cleansing, and blow-offs. Without a consistent supply of quality compressed air, a manufacturing process can stop functioning.

The Compressed Air Challenge ® (CAC) is a national collaboration that was created to assist industrial facilities in achieving greater reliability, improved quality control, and lower operating costs for their compressed air systems. The CAC encourages facilities to take a systems approach to optimizing compressed air operation. Taking a systems approach means looking beyond individual components to assess how well your compressed air system meets actual production needs. This is known as 'matching supply with demand.' It also means identifying the root causes of system problems, rather than treating the symptoms.

the type of firm offering these services. These three levels of service include: a walk-through evaluation, a system assessment, and a fully instrumented system audit. More information on analysis services guidelines can be found under the CAC Levels of Analysis of Compressed Air Systems in this Guidelines document, or you can visit the CAC Web site at www.compressedairchallenge.org . In selecting a service provider, a compressed air user should consider the guidelines that follow.

For most industrial facilities, this approach will require specialized knowledge and equipment, both to assess system needs and to continue to service those needs over time. Outside assistance frequently is required. System assessment services and ongoing system maintenance may require the use of separate firms, although there is a growing market trend toward more fully integrated services. The process of selecting the right mix of services can be confusing. The CAC is working with the compressed air industry to help industrial compressed air users become informed consumers. Guidelines for Selecting a Compressed Air System Service Provider offers guidance to assist you in selecting a firm that offers integrated services. Independent compressed air system specialists typically provide comprehensive system assessment services as their principal business; many are not involved in sales of equipment, other products, or maintenance.

The CAC also is developing guidelines to define three levels of system analysis services, independent of

## WHAT TO LOOK FOR WHEN SELECTING A SERVICE PROVIDER

In selecting a service provider, a compressed air user should consider the following guidelines.

## I. Familiarity with the Systems Approach

The Compressed Air Challenge ¤ (CAC) provides Fundamentals of Compressed Air Systems and Advanced Management of Compressed Air Systems training to end users and service providers. One way to gauge a service provider's commitment to the systems approach is whether they have staff who have received CAC training. If they do, ask whether these individuals will be providing or supervising services for your facility. Providers who are familiar with using a systems approach are much more likely to address situations, both inside and outside the compressor room, that are having an effect on the reliability of your compressed air supply.

## II. Availability of Compressed Air System Assessment Services

Does the provider offer compressed air system analysis services? If yes, how well do these services fit your needs? If no, can the provider outsource these services to an experienced system specialist? How experienced are the individuals who will be providing these services? Once a walk-through, assessment, or audit is performed, what kind of follow-up services are available to ensure that the recommendations are properly implemented and produce the desired results? Ask for a sample of similar work that the provider has done for others, resumés of the personnel who will be performing the work, and client references. Please note that while leak detection is a useful element of a system assessment, a true system assessment should include much more. See www.compressedairchallenge.org for additional guidance.

Important Note: recommendations resulting from system analysis activities should provide product-neutral solutions to system problems and include, only if needed, performancebased rather than brand-based equipment recommendations.

## III. Compressor Knowledge and Expertise

Does the servce provider have the expertise to work on your equipment? Can the service provider work on all types of compressors in your facility? How much experience do the service technicians have? How are the service technicians trained? Is formal schooling involved? Knowledgeable service technicians are worth the premium price they may demand because of their ability to troubleshoot and get equipment back on line efficiently and effectively.

## IV. System Components and Controls Knowledge and Expertise

Treatment, accessory, and ancillary equipmentDoes the service provider have the expertise to perform refrigeration and other work on dryers and related equipment? Is the service provider capable of servicing the types of filters, drains, distribution and point of use equipment found in your facility?

System controlsDoes the service provider have the diagnostic and technical controls capability to determine how to optimize your existing control configuration and make recommendations for improvements? Can they help network compressors together or remotely monitor, if necessary? Advanced controls can save energy and improve reliability through automatic start and stop, as well as turning compressors off that can then serve as back-ups. Advance warning through remote monitoring may help identify a problem before it turns into a major shutdown.

## V. Company Capabilities

Ask about the standards of performance that the prospective service provider has established for:

- ¥ Emergency service response
- ¥ Parts shipments
- ¥ Other factors which may influence your decision, such as:
- -Installation capabilities internally or through a mechanical contractor
- -Emergency rental fleet availability-electric or portable diesel-driven
- ¥ Your company may request information on the service provider's
- -Financial stability
- -Insurance coverage
- -Compliance with specific government regulations or those of your company.

## VI. Service Facilities

Visit the facilities of two or three service providers under consideration to see first hand the type of repair shop and parts warehouse with which you will be dealing.

## COMPRESSED AIR CHALLENGE ¤ LEVELS OF ANALYSIS OF COMPRESSED AIR SYSTEMS

## OVERVIEW

The Levels of Analysis of Compressed Air Systems listed below have been developed in an effort to provide commonality of terminology, methods, and procedures to be used by service providers and the results to be expected by end users. This overview is essentially brief. More detailed versions of these Levels of Analysis are under development, at this time, and will be available through the CAC Web site at

## www.compressedairchallenge.org.

Energy utilities are actively involved in these efforts and some provide incentives to use these analyses to improve the energy efficiency of compressed air systems.

Conducting a walk-through evaluation is the first step in analyzing a compressed air system. Depending on individual needs, this can be conducted either by plant personnel or by

## LEVELS OF ANALYSIS

## Walk-through Evaluation (1/2 to 2 days)

A walk-through evaluation is an overview of a plant compressed air system by identifying the types, needs, and appropriateness of end uses, pressures and air quality requirements.

- ¥ The distribution system is analyzed for any apparent problems of size, pressure drops, storage, leaks, and drains.
- ¥ The supply side is analyzed for types of compressors, and the types, suitability and settings of capacity controls.
- ¥ A simple block diagram of the system is drawn.
- ¥ Maintenance procedures and training are also analyzed.
- ¥ Written report of findings and proposed solutions is submitted.
- ¥ Solution and product neutrality should be maintained with any recommendations.

## System Assessment (2 to 5 days)

A system assessment is more detailed than a walk-through evaluation of a plant compressed air system.

- ¥ In addition to identifying the items and problems of the walk-through evaluation, readings are taken at appropriate locations to identify the dynamics of the system.
- ¥ A simple block diagram of the system is drawn, also a pressure profile and a demand profile, to help identify potential problems and how they could be resolved.
- ¥ Again, maintenance procedures and training are reviewed.
- ¥ A written report of findings and recommendations is submitted.
- ¥ Solution and product neutrality should be maintained with any recommendations.

## System Audit (3 to 10 days)

A system audit is similar to a system assessment but in more depth and detail.

- ¥ Data logging of readings throughout the system is conducted for more in-depth analysis of the dynamics of the system and resulting problems.
- ¥ Again, maintenance procedures and training are reviewed.
- ¥ The objective is a proper alignment of the supply side and the demand side for optimum efficiency, energy savings, and reliability. A baseline is established, against which the results of any proposed changes are measured.
- ¥ A comprehensive written report of all findings, recommendations, and results is submitted.
- ¥ Solution and product neutrality should be maintained with any recommendations.

an experienced compressed air system services provider. A walk-through evaluation is not intended to provide the level of detail found in a system assessment or a system audit but significant reductions in energy (25 percent or more) and lower maintenance costs frequently have resulted from a walk-through evaluation alone. Once initial opportunities have been identified, a decision should be made concerning whether additional analysis services are required to further define system dnamics and corresponding system improvement opportunities. This decision will depend, in part, on the size and complexity of the system being examined (both supply and demand) and whether critical issues surfaced during the Evaluation that require further investigation to understand the root cause and suggest potential remedies.

## Notes

## Notes

## Notes

## About Compressed Air Challenge ¤

A national collaborative, the Compressed Air Challenge ® , was formed in October of 1997 to assemble state-of-the-art information on compressed air system design, performance, and assessment  procedures. This collaborative is delivering best-practice compressed air system information to the plant floor, creating a consistent national market message that supports the application of these best practices, providing a technically sound and professionally delivered training program for plant operating personnel, and will, through a certification program, recognize plant personnel's skills in operating compressed air systems. Participants include: large industrial users of compressed air, manufacturers and distributors of compressed air equipment and their associations, facility engineers and their associations, compressed air system consultants, state research and development agencies, energy efficiency organizations, and utilities. The goals of the Compressed Air Challenge ® are to:

- · Increase the reliability and quality of industrial production processes
- • Reduce plant operating costs
- • Expand the market for high quality compressed air services
- · Save energy; a 10 percent improvement over current usage, resulting in annual savings of approximately 3 billion kilowatt hours of electricity nationwide.

The purpose of the Compressed Air Challenge ® is to initiate a national collaborative that develops materials, a training curriculum, a certification program, and other information that can be used by the project sponsors in cooperation with others to:

- · Raise awareness of the importance of efficient, effective plant air systems
- · Train industrial plant operating personnel on best practices for plant air systems
- • Expand the market for expert plant air assessment services
- · Help build the local market infrastructure to deliver these services.

The Compressed Air Challenge ® includes:

- • A Board of Directors comprised of the project sponsors
- · A Project Development Committee, which includes a representative from each key stakeholder group and is responsible for overall project coordination
- · Working Groups, which provide essential technical input to the project.

The Compressed Air Challenge ® is seeking additional participants interested in sponsorship or contributing to materials development. For general information, call the Compressed Air Challenge ® at (800) 862-2086. If you would like to join the Challenge, see www.compressedairchallenge.org .

## About the Office of Energy Efficiency and Renewable Energy

## A Strong Energy Portfolio for a Strong America

## Federal Energy Management Program

Energy efficiency and clean, renewable energy will mean a stronger economy, a cleaner environment, and greater energy independence for America. By investing in technology breakthroughs today, our nation can look forward to a more resilient economy and secure future.

Far-reaching technology changes will be essential to America's energy future. Working with a wide array of state, community, industry, and university partners, the U.S. Department of Energy's Office of Energy Efficiency and Renewable Energy invests in a diverse portfolio of energy technologies that will:

- · Conserve energy in the residential, commercial, industrial, government, and transportation sectors
- · Increase and diversify energy supply, with a focus on renewable domestic sources
- • Upgrade our national energy infrastructure
- · Facilitate the emergence of hydrogen technologies as a vital new 'energy carrier.'

## The opportunities

## Biomass Program

Using domestic, plant-derived resources to meet our fuel, power, and chemical needs

## Building Technologies Program

Homes, schools, and businesses that use less energy, cost less to operate, and ultimately, generate as much power as they use

## Distributed Energy &amp; Electric Reliability Program

A more reliable energy infrastructure and reduced need for new power plants

Leading by example, saving energy and taxpayer dollars in federal facilities

## FreedomCAR &amp; Vehicle Technologies Program

Less dependence on foreign oil, and eventual transition to an emisions-free, petroleum-free vehicle

## Geothermal Technologies Program

Tapping the earth's energy to meet our heat and power needs

## Hydrogen, Fuel Cells &amp; Infrastructure Technologies Program

Paving the way toward a hydrogen economy and net-zero carbon energy future

## Industrial Technologies Program

Boosting the productivity and competitiveness of U.S. industry through improvements in energy and environmental performance

## Solar Energy Technology Program

Utilizing the sun's natural energy to generate electricity and provide water and space heating

## Weatherization &amp; Intergovernmental Program

Accelerating the use of today's best energy-efficient and renewable technologies in homes, communities, and businesses

## Wind &amp; Hydropower Technologies Program

Harnessing America's abundant natural resources for clean power generation

To learn more, visit www.eere.energy.gov.

## Contact Information:

Compressed Air Challenge ¤ www.compressedairchallenge.org

U.S. Department of Energy Energy Efficiency and Renewable Energy Industrial Technologies Program www.eere.energy.gov/industry

Cover photos, from top to bottom: Top and bottom photos:

Dryer and desiccant dryer, courtesy American Water Heaters, Johnson City, TN Compressors in centralized location, courtesy Visteon Corporation, Nashville, TN

Middle photo:

Prepared for: Compressed Air Challenge ¤ and The United States Department of Energy

Prepared by: Lawrence Berkeley National Laboratory Washington, D.C.

Resource Dynamics Corporation Vienna, VA

Industrial Technologies Program

To order additional copies of this sourcebook, please contact:

Industrial Technologies Clearinghouse (800) 862-2086

U.S. Department of Energy Energy Efficiency and Renewable Energy Washington, D.C. 20585

<!-- image -->

DOE/GO-102003-1822 November 2003