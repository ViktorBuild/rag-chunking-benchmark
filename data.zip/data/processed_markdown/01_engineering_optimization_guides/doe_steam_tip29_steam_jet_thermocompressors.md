---
document_id: doe_steam_tip_29
title: "Steam Tip Sheet #29: Use Steam Jet Ejectors or Thermocompressors to Reduce Venting"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2007
original_file: "doe_steam_tip29_steam_jet_thermocompressors.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

A

D

Energy Tips: STEAM

## Use Steam Jet Ejectors or Thermocompressors to Reduce Venting of Low-Pressure Steam

Large industrial plants often vent significant quantities of low-pressure steam to  the atmosphere, wasting energy, water, and water-treatment chemicals. Recovery of the latent heat content of low-pressure steam reduces the boiler load, resulting in energy and fuel cost savings. Low-pressure steam's potential uses include driving evaporation and distillation processes, producing hot water, space heating, producing a vacuum, or chilling water. If the steam pressure is too low for the intended application, a steam jet thermocompressor can boost the pressure and temperature to the required level.

## Operating Principles

Thermocompressors and ejectors operate on the same thermodynamic and physical principle:  energy contained in high-pressure steam can be transferred to a lower pressure vapor or gas to produce a mixed discharge stream of intermediate pressure. These devices are known for:

- •	Simple	construction
- •	Insensitivity	to	fouling
- •	Easy	installation
- •	Low	capital	and	installation	costs
- •	Easy	maintenance	with	no	moving	parts
- •	Long	useful	operating	lives

If the objective is to recover the latent heat content of the low-pressure suction vapor for process use, the device is called a thermocompressor . If the objective is to pull a vacuum on a process vessel, the device is called an ejector .

## Boosting Steam Pressure and Temperature with Thermocompressors

Single- or multi-stage thermocompressors are used to boost low-pressure vent steam to a useful higher pressure and temperature. When high-pressure motive steam is available, thermocompressors can be economically used for compression ratios up to 6:1 (absolute pressure of supply steam/suction steam).

Typical Thermocompressor Application

<!-- image -->

High-pressure motive steam supplied to the thermocompressor expands in a convergingdiverging nozzle to convert pressure energy to kinetic energy. Vent steam supplied to the suction port is entrained into this low-pressure/high-velocity jet, where mixing occurs. The diffuser portion of the thermocompressor shown in the figure reconverts the

Steam Tip Sheet #29

## Suggested Actions

- ■ ■ Investigate thermocompressors where significant venting of low- pressure steam occurs, higher-pressure motive steam is available, and a modest pressure boost could convert waste steam to useful steam. Examine waste recovery potential by determining:
- -   Flow rate and pressure of vented steam
- -   Flow rate and pressure for sources of motive steam
- -   Process or heating needs that can be met by boosting the pressure and temperature of vented steam
- -   Equipment size and motive to suction steam ratio
- -   Annual energy savings and installation costs of selected device
- ■ ■ Consider vacuum jet ejectors in situations where:
- -   Mild vacuum conditions1 to 3 psig below ambientwould help the process operation
- -   Waste steam at pressures greater than 15 psig are vented to the atmosphere

kinetic energy of the mixture back into pressure. The intermediate discharge pressure is between the pressures of the motive and low-pressure suction steam. Discharge pressure is determined by the compression ratio (i.e., the ratio of the pounds per hour [lb/hr] of motive steam supplied to the lb/hr of low-pressure suction steam entrained). Thermocompressor capacity of the device is dictated by the availability of motive steam, motive and suction steam pressure, and discharge steam pressure requirements. Applications include drying and heating, multi-effect evaporators, vulcanizers, reboilers, strippers, condensate receiver tanks, and solvent extraction processes.

## Producing a Vacuum with Steam Jet Ejectors

In a vacuum jet ejector, the low-pressure vent steam is the motive energy source. Air and/or water vapor are sucked from the process into the mixing chamber at near-vacuum conditions. Both the motive vent steam and the suction vapors/gases pass through a venturi throat and are released through a diffuser. Although steam jet ejectors can be used to pull a vacuum with motive steam pressure as low as 5 pounds per square inch gauge (psig), higher pressures of 15 to 50 psig are more practical.

## Example

An industrial facility vents 10,000 lb/hr of steam at near atmospheric pressure [0.3 psig, 212.9°F, 1,150.7 Btu per pound (Btu/lb)]. Wasted steam can be converted into useful low-pressure process steam by boosting its pressure to 15.3 psig (250.3°F, 1,164.1 Btu/lb). Saturated motive steam at a pressure of 200 psig is available (387°F, 1,199.7 Btu/lb).

For a required compression ratio of 2:1 (15.3 + 14.7 psia)/(0.3 + 14.7 psia), 1.1 lb of high-pressure motive steam per lb of low-pressure suction steam is required. The thermocompressor requires 11,000 lb/hr of 200-psig steam to produce a discharge of 21,000 lb/hr of 15.3-psig intermediate-pressure steam. Elimination of steam venting saves:

Energy Savings = Vent Flow Rate (lb/hr) x Enthalpy of the Vented Steam less the Enthalpy of Makeup Water (Btu/lb)

- = 10,000 lb/hour x (1,150.7 - 77) Btu/lb x (MMBtu/10 6  Btu)
- = 10.7 MMBtu/hr

For a continuously operating facility, annual energy savings are approximately

94,000 MMBtu. For natural gas fuel priced at $8.00 per MMBtu ($8.00/MMBtu) with a boiler efficiency of 80%, fuel savings are valued at:

Annual Savings

= 94,000 MMBtu/yr x $8.00/MMBtu/0.80

= $940,000

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3414  •  January 2012

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.