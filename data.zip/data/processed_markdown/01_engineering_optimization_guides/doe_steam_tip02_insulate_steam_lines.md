---
document_id: doe_steam_tip_2
title: "Steam Tip Sheet #2: Insulate Steam Distribution and Condensate Return Lines"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_steam_tip02_insulate_steam_lines.pdf"
tables_detected: 5
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

A

Energy Tips: STEAM

## Insulate Steam Distribution and Condensate Return Lines

Uninsulated steam distribution and condensate return lines are a constant source of wasted energy. The table shows typical heat loss from uninsulated steam distribution lines. Insulation can typically reduce energy losses by 90% and help ensure proper steam pressure at plant equipment. Any surface over 120°F should be insulated, including boiler surfaces, steam and condensate return piping, and fittings.

Insulation frequently becomes damaged or is removed and never replaced during steam system repair. Damaged or wet insulation should be repaired or immediately replaced to avoid compromising the insulating value. Eliminate sources of moisture prior to insulation replacement. Causes of wet insulation include leaking valves, external pipe leaks, tube leaks, or leaks from adjacent equipment. After steam lines are insulated, changes in heat flows can influence other parts of the steam system.

Heat Loss Per 100 Feet of Uninsulated Steam Line

| Distribution Line Diameter, inches   | Heat Loss Per 100 Feet of Uninsulated Steam Line, MMBtu/yr Steam Pressure, psig   | Heat Loss Per 100 Feet of Uninsulated Steam Line, MMBtu/yr Steam Pressure, psig   | Heat Loss Per 100 Feet of Uninsulated Steam Line, MMBtu/yr Steam Pressure, psig   | Heat Loss Per 100 Feet of Uninsulated Steam Line, MMBtu/yr Steam Pressure, psig   |
|--------------------------------------|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|
| Distribution Line Diameter, inches   | 15                                                                                | 150                                                                               | 300                                                                               | 600                                                                               |
| 1                                    | 140                                                                               | 285                                                                               | 375                                                                               | 495                                                                               |
| 2                                    | 235                                                                               | 480                                                                               | 630                                                                               | 840                                                                               |
| 4                                    | 415                                                                               | 850                                                                               | 1,120                                                                             | 1,500                                                                             |
| 8                                    | 740                                                                               | 1,540                                                                             | 2,030                                                                             | 2,725                                                                             |
| 12                                   | 1,055                                                                             | 2,200                                                                             | 2,910                                                                             | 3,920                                                                             |

Based on horizontal steel pipe, 75˚F ambient air, no wind velocity, and 8,760 operating hours per year.

## Example

In a plant where the fuel cost is $8.00 per million Btu ($8.00/MMBtu), a survey of the steam system identified 1,120 feet (ft) of bare 1-inch-diameter steam line, and 175 feet of bare 2-inch line, both operating at 150 pounds per square inch gauge (psig). An additional 250 ft of bare 4-inch-diameter line operating at 15 psig was found. From the table, the quantity of heat lost per year is:

1-inch line:

1,120 ft x 285 MMBtu/yr per 100 ft =

3,192 MMBtu/yr

2-inch line:

175 ft x 480 MMBtu/yr per 100 ft =

840 MMBtu/yr

4-inch line:

250 ft x 415 MMBtu/yr per 100 ft

=

1,037 MMBtu/yr

Total Heat Loss =

5,069 MMBtu/yr

Given a boiler efficiency of 80%, the annual cost savings from installing 90% efficient insulation is:

(0.90 x $8.00/MMBtu x 5,069 MMBtu/yr)/0.80  =  $45,620

Steam Tip Sheet #2

## Suggested Actions

Conduct a survey of your steam distribution and condensate return piping, install insulation, and start to save.

## Insulation Optimization Software Available

The North American Insulation Manufacturers Association has developed a software package (3E Plus) that determines the optimum thickness for a wide variety of insulating materials. Outputs include the simple payback period, surface heat loss, and surface temperature for each specified insulation thickness. 3E Plus is available at no cost on AMO's website at manufacturing.energy.gov

## Use Insulating Jackets

Removable insulating jackets are available for valves, flanges, steam traps, and other fittings. Remember that a 6-inch gate valve may have more than 6 square feet of surface area from which to radiate heat.

Install insulating jackets on steam traps according to steam trap manufacturer's directions to maintain proper trap operation.

For additional information on removable insulation, refer to the related steam tip sheet #17 Install Removable Insulation on Valves and Fittings in the publication library on the AMO website.

Adapted from an Energy TIPS fact sheet that was originally published by the Industrial Energy Extension Service of Georgia Tech.

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3404  •  January 2012