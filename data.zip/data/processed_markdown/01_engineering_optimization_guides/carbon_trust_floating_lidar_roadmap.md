---
document_id: ct_floating_lidar_roadmap
title: "Offshore Wind Accelerator: Floating LiDAR Roadmap and Performance Criteria"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "Carbon Trust (UK)"
year: 2025
original_file: "carbon_trust_floating_lidar_roadmap.pdf"
tables_detected: 70
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## The Carbon Trust Offshore Wind Accelerator roadmap for the commercial acceptance of floating LiDAR technology

Version 3.0 | June 2025

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Foreword

Floating  lidar  has  the  potential  to  replace  meteorological  (met)  masts  for  the  measurement  of primary wind resource data -wind speed and wind direction, and lately also turbulence intensity (TI).

The purpose of this document is to present a roadmap for floating lidars to become commercially accepted as a source of data to support financial investment decisions. The roadmap was originally published  in  2013,  with  version  2.0  released  in  October  2018,  which  was  based  on  industry experience gained in the interim period with clarifications, updates, extensions and new material included based on industry engagement to ensure the roadmap continues to be fit for purpose for several user groups into the future. This version has been published in 2025 to reflect a need to provide guidance in the assessment of TI.

Since the release of the original roadmap, the criteria presented have become widely adopted within the wind industry community with the key performance indicators (KPIs) now also being used in other implementations of lidar. The clear stage maturity system has also been well received with several floating lidar systems (FLS) original equipment manufacturers (OEMs) achieving independently verified stage 3 maturity. This version of the roadmap adds an enhancement to the stage  maturity  to  show  whether  a  system  has  additionally  been  assessed  for  the  accuracy  of acquired TI data.

The roadmap has been prepared by the Carbon Trust Offshore Wind Accelerator (OWA), a joint industry  project  involving  ten  developers  representing  an  estimated  three-quarters  of  Europe's licensed capacity -Ørsted, Equinor, SSE Renewables, ScottishPower Renewables, Shell, Vattenfall, RWE, TotalEnergies, EnBW and BP.

An  important  element  of  ensuring  trust  in  data  from  floating  lidar  systems  continues  to  be  a comparison to an IEC compliant met mast, or in some part alternatively in comparison with another trusted reference source (e.g. a fixed lidar) of similar measurement uncertainty, by an independent third party, and according to the guidelines set out in this document.

Acknowledgement is made to past contributors to this body of work, including Statkraft, DNV, FrazerNash Consultancy, Multiversum Consulting and Fraunhofer IWES.

This  version  is  produced  by  Oldbaum  Services  and  Fraunhofer  IWES  in  close  collaboration  with OEMs and the OWA partners listed above.

| 2

## Document history

|   Version | Date             | Authors                                                                              |
|-----------|------------------|--------------------------------------------------------------------------------------|
|         1 | 21 November 2013 | Garrad Hassan & Partners Ltd, DNV KEMA, Mott MacDonald, ECN, Frazer-Nash Consultancy |
|         2 | 9 October 2018   | DNV GL, Frazer-Nash Consultancy, Multiversum Consulting, Fraunhofer IWES             |
|         3 | June 2025        | Oldbaum Services, Fraunhofer IWES                                                    |

## Important notice and disclaimer

This report is issued by the Carbon Trust on behalf of the Offshore Wind Accelerator ('OWA'). While reasonable steps have been taken to ensure that the information contained within this report is accurate, the authors, the Carbon Trust, its agents and consultants and the partners and developers within the OWA (and each of them), to the fullest extent permitted by law, shall not have nor be deemed to have (1) a duty of care to readers and/or users of this report, (2) made or given or to make or give any warranty or representation (in each case whether express or implied) as to its accuracy, applicability or completeness and/or (3) or have accepted any liability whatsoever for any errors or omissions (whether negligent or otherwise) within it. It should also be noted that this report has been produced from information relating to dates and periods referred to in it. Users and readers use this report on the basis that they do so at their own risk. The intellectual property rights in this report shall be deemed, as between readers and users of this report and the Carbon Trust, to belong to the Carbon Trust.

© The Carbon Trust 2025

| 3

## Contents

1

Introduction

| Foreword                        | Foreword                        | Foreword                                          | 2   |
|---------------------------------|---------------------------------|---------------------------------------------------|-----|
| Document history                | Document history                | Document history                                  | 3   |
| Important notice and disclaimer | Important notice and disclaimer | Important notice and disclaimer                   | 3   |
| List of tables                  | List of tables                  | List of tables                                    | 6   |
| List of abbreviations           | List of abbreviations           | List of abbreviations                             | 6   |
| Abbreviation                    | Abbreviation                    | Abbreviation                                      | 6   |
| Meaning                         | Meaning                         | Meaning                                           | 6   |
| Acknowledgements                | Acknowledgements                | Acknowledgements                                  | 6   |
| Introduction                    | Introduction                    | Introduction                                      |     |
| 1                               |                                 |                                                   | 8   |
|                                 | 1.1                             | Background                                        | 8   |
|                                 | 1.2                             | Note on use of this document                      | 9   |
|                                 | 1.3                             | Cautionary note                                   | 9   |
| 2                               | Stages of maturity              | Stages of maturity                                | 11  |
| 2.1                             | FLS                             | type related considerations                       | 12  |
| 2.2                             |                                 | Summary                                           | 13  |
|                                 | 2.3                             | Stage 1: Baseline                                 | 18  |
|                                 |                                 | 2.3.1 Definition                                  | 18  |
|                                 |                                 | 2.3.2 Prerequisites                               | 18  |
|                                 |                                 | 2.3.3 Offshore application                        | 18  |
|                                 |                                 | 2.3.4 Limitations of offshore application         | 19  |
|                                 |                                 | 2.3.5 Expected levels of measurement uncertainty  | 19  |
|                                 | 2.4                             | Stage 2: Pre-commercial                           | 20  |
|                                 |                                 | 2.4.1 Definition                                  | 20  |
|                                 |                                 | 2.4.2 Prerequisites                               | 20  |
|                                 | 2.4.3                           | Offshore application                              | 21  |
|                                 |                                 | 2.4.4 Limitations of offshore application         | 21  |
|                                 |                                 | 2.4.5 Assessment of uncertainties for Stage 2 FLS | 22  |
|                                 |                                 | 2.4.6 Stage 2+ Assessment                         | 23  |
| 2.5                             |                                 | Stage 3: Commercial stage                         | 23  |
|                                 |                                 | 2.5.1 Definition                                  | 23  |
|                                 |                                 | 2.5.2 Prerequisite                                | 23  |
|                                 |                                 | 2.5.3 Offshore application                        | 24  |
|                                 |                                 | 2.5.4 Limitations of offshore application         | 25  |
|                                 |                                 | 2.5.5 Assessment of uncertainties for Stage 3 FLS | 25  |
|                                 |                                 | 2.5.6 Stage 3+ assessment                         | 25  |

| 2.6               | Other considerations                                                                        |   25 |
|-------------------|---------------------------------------------------------------------------------------------|------|
|                   | 2.6.1 Length of measurements and power supply                                               |   25 |
|                   | 2.6.2 Reliability of turbulence intensity measurements from FLS units                       |   26 |
|                   | 2.6.3 Replacement of faulty components or system during a wind resource assessment campaign |   27 |
|                   | 2.6.4 Site Acceptance Tests                                                                 |   27 |
| 3 Conclusions     | 3 Conclusions                                                                               |   29 |
| Appendix 1        | Appendix 1                                                                                  |   31 |
| Trusted Reference | Trusted Reference                                                                           |   42 |
| Other Parameters  | Other Parameters                                                                            |   42 |

42

## List of tables

| Table 1.1:   | Summary of FLS scenarios examined   |   14 |
|--------------|-------------------------------------|------|
| Table 1.2:   | Summary of roadmap                  |   16 |

## List of abbreviations

| Abbreviation   | Meaning                         |
|----------------|---------------------------------|
| CNR            | Carrier-to-Noise Ratio          |
| FLS            | Floating Lidar System           |
| KPI            | Key Performance Indicator       |
| NaN            | Not a Number (IEEE symbol)      |
| OEM            | Original Equipment Manufacturer |
| OWA            | Offshore Wind Accelerator       |
| QA             | Quality Assurance               |
| QC             | Quality Control                 |
| TI             | Turbulence Intensity            |
| WRA            | Wind Resource Assessment        |

## Acknowledgements

The Carbon Trust would like to thank the following companies for their contribution to this report:

Ørsted, Equinor, SSE Renewables, ScottishPower Renewables, Shell, Vattenfall, RWE, TotalEnergies, EnBW and BP.

The delivery team Oldbaum Services and Fraunhofer IWES.

In the development of version 2 of this document a wide range of industry stakeholders have been consulted via a questionnaire process and a dedicated 1-day workshop in London on 23 January 2018. The authors would like to thank those contributors for their invaluable contributions, those contributors being floating lidar system developers (9 different organisations), research organisations and universities (3), lidar suppliers (1), consultancies/banks' engineers (8), as well as the OWA partner organisations (11) and other wind farm developers (2).

Version 3 was developed after the detailed analysis of floating lidar trials, industry stakeholder and manufacturers. The authors would like to thank the FLS manufacturers who donated data and analysis time to the project and for their time in giving their opinion during the market consultation. In addition to the datasets and trial information supplied by OEMs, questionnaires targeted at the OEMs and data end-users was used to inform this update. Thank you to the participants who took part in this initiative.

The Carbon Trust would like to acknowledge the significant prior research into the development of floating lidar for offshore application . 1

1 Papers including

Oldroyd, A; Kindler D: Wind Measurements using floating lidar Best Practice June 2011

IEA Wind, Expert Group Report on Recommended Practices, 18. Floating LiDAR Systems, First Edition 2017. O. Bischoff, I. Würth, J. Gottschall, B. Gribben, J. Hughes, D. Stein, H. Verhoef. https://community.ieawind.org/publications/rp

IEC61400-TS-50-4: Wind Energy Generation Systems Part 50-4: Use of Floating LiDAR Systems for Wind measurements.

## ARTICLE I. INTRODUCTION

## Section 1.01 Background

As part of the OWA programme,  Carbon Trust, along with a consortium of industry partners, previously developed a guide or ' roadmap ' for the steps required for floating lidar technology to become commercially accepted within the industry. Since the publication of version 1 of the roadmap in 2013 and version 2.0 in 2018, floating lidar has become the default method of wind data acquisition for offshore wind, with a number of OEMs having achieved the 'mature' definition Stage 3.

The Carbon Trust has commissioned an update to the original roadmap to reflect the latest status of floating lidar systems using input from stakeholders across the industry, as reported in this document (version 3.0). This document retains much of the original material set out in version 2.0 with the addition of TI evaluation and testing methods to establish a new  +  designation to the ' ' existing stage maturity definitions. The assessment of TI, as proposed here, is based on close collaboration between the industry as represented by the OWA, OEMs and Oldbaum Services in partnership with Fraunhofer IWES.

The purpose of this document is not to re-define the stage maturity criteria. It is recognised that consistency of targets is key to encouraging old and new suppliers to develop their systems.

In this context, "commercial acceptance" is defined as the stage at which measurement data recorded using a particular floating lidar technology is accepted by funders of commercial scale offshore wind projects. In broad terms, the following stages are envisaged:

- 1. Baseline: As a pre-requisite, the lidar measurement unit itself should have achieved widespread acceptance within the onshore wind industry as "proven" in the field of wind resource characterisation for non-complex terrain sites at least. Industry-proven lidars are lidar types that are commercially available and have a widespread accepted track record in the wind industry onshore, reliably and repeatedly producing wind data in benign terrain conditions at an accuracy comparable to that of classical mast-based anemometry.
- 2. Pre-commercial: Following a successful Type Verification trial, the floating lidar technology may be utilised commercially in limited circumstances - specifically in conditions similar to those experienced during the trial. In this application, where the performance and sensitivities of the device in certain environmental conditions has previously been captured in a trial, accuracy can, in principle, be considered to be approximate to that of a conventional meteorological (met) mast, albeit with a level of residual uncertainty relating to site-specific deployment conditions. Where the environmental conditions at a deployment site are different from those during the type verification trial, elevated measurement uncertainty assumptions may be expected given the lack of evidence regarding sensitivity of performance to difference environmental conditions at this stage.
- 3. Commercial: At this stage, a significant body of operational evidence and verification has been accumulated across a range of environmental conditions leading to a good understanding of any environmental performance sensitivities thus increasing certainty in the performance of the FLS. Furthermore, the floating lidar system has consistently demonstrated significantly more demanding reliability performance and data availability.

To these definitions, this version of the roadmap document adds the '+' stage designation . The '+' designation (for example Stage 2+) means that as part of their stage maturity assessment the FLS has been assessed for the accuracy of the acquired TI measurement.

Please note: TI is a very application-specific parameter that can be used, for example, in site condition or wake propagation studies. The nature of how TI is presented in these cases is very different (either as mean value, time series or bin averaged with wind speed, for example).

As the use of TI is very closely dependent on the application, this document does not attribute pass or fail criteria to the proposed error metrics and suggests the end user of the data should assess an FLS documented TI measurement capability and the implication to their study or analysis.

## Section 1.02 Note on use of this document

Versions 1.0 and 2.0 of this document were widely used and referred to by the wind energy industry, and it is anticipated that this will continue to be the case for version 3.0. Experience with previous versions is that assertions of maturity stage claims are most effective when carried out by independent, experienced and trusted third party organisations. It is also expected that this will continue to be the case for the use of this version. Where the requirements to achieve a maturity stage are set out in this document, there is in some cases flexibility in how these requirements are met and evidenced, which must be left to the judgement of the participating third party organisation.

For clarity, although this roadmap document is provided by the Carbon Trust on behalf of the OWA research partnership, the Carbon Trust nor the other partners expect to act as the third party evaluators of maturity claims. It is noted that some industry groups may use this roadmap document to inform procurement procedures and tender requirements for floating lidar measurement campaigns. As outlined in the following sections of this document, whilst industry should expect a higher reliability performance and significant operational experience across a range of environmental conditions from Stage 3 devices, this document is not intended to close the door on consideration of Stage 2 or even Stage 1 devices in commercial deployments. This roadmap sets out expectations with regards to wind speed measurement accuracy, availability and reliability for each maturity stage. On the basis of this framework, Stage 2 devices can achieve similar wind speed accuracy as Stage 3.

This version (3.0) specifically addresses the assessment of TI and the presentation of error metrics to be used when examining the performance of a floating lidar system. To address this, a '+' designation is added to the well understood stage maturity presented in previous versions. As is the case for wind speed and wind direction assessment, a Stage 3+ device is not necessarily more accurate than a Stage 2+ device, however the Stage 3+ has been tested in a wider range of environmental and operational conditions . The lack of a '+' designation makes no statement as to an FLS' s capability to measure windspeed and wind direction as defined in previous versions. It only means it has not been assessed for TI measurement.

This roadmap does not intend to provide instruction for procurement-based decisions. However, as for any commercial decision, it is strongly recommended that consideration is given to the risks associated with the use of FLS at different maturity stages on accuracy, reliability and acceptance of results.

## Section 1.03 Cautionary note

It is important to note that this roadmap was designed to focus on the capabilities of floating lidar technology to replace met masts in measuring primary wind data, namely wind speed, wind direction and TI. There are other secondary but important parameters required for a

comprehensive offshore wind resource assessment (WRA) such as hub-height air temperature, air pressure, relative humidity, air density (not measured directly but derived from atmospheric measurements), etc. which are not addressed in this document. Additionally, complementary oceanographic measurements are also required to achieve a full metocean measurement campaign. Therefore, while some floating lidars currently feature additional measurement capabilities and while future developments might add even more comprehensive measurement capabilities, it is important to bear in mind that this document is only a roadmap towards replacing primary wind data measured from offshore met masts with floating lidars, and that secondary wind data and metocean measurements are still very likely to be required to complete a comprehensive offshore wind resource and metocean measurement campaign.

Lastly, the geographical context of the body of work and experience leading to this document should be understood. Most floating lidar deployments, as trials or in support of WRAs, have been still conducted in Northern Europe. Wave climates and sea state conditions in other parts of the world may be different to the test conditions and could offer additional challenges as the system performance may not be enveloped by the existing body of experience. Therefore, in employing the roadmap in different territories to the type or unit test experience it is recommended to review how similar or otherwise the metocean conditions are, and how this may modify interpretation of the roadmap in general and reliability maturity in particular. As guidance, please refer to Clause 7.5 in IEC 61400-TS-50-4 which describes the creation of a FLS evidence base to document the test conditions experienced by an FLS type.

## Article II. Stages of maturity

Floating Lidar Systems (FLS) are based on laser anemometry known as lidar (or LiDAR Light Detection And Ranging) technology which has been developed for various industries, including the wind energy industry. In addition to a body of onshore verification data for the type of lidar employed on a floating structure itself, it is also important that the performance of the complete FLS is rigorously validated within the offshore environment to demonstrate that it can operate effectively across a range of dynamic conditions.

There are potentially significant issues requiring careful consideration regarding the accuracy of the measurements when the device is deployed on a moving support structure. From an engineering perspective, there appear to be three main approaches to address these issues. The first is to minimise the movement of the support structure such that all, or at least the majority, of the measurements are made when the amplitude of device movement is sufficiently small so that the impact on the accuracy of the measurements may be negligible (mechanical motion compensation). The second approach is to measure that movement and correct for its impact on the measurements using numerical algorithms (algorithm motion compensation).  A third approach is simply to allow such movements and to demonstrate that the system produces sufficiently accurate data nonetheless (no motion compensation). Although some FLS have shown that their ten-minute wind data accuracy does not seem very sensitive to movement, for limited evidence this cannot yet be assumed valid for all systems available on the market and in particular not for the provision of TI data.

The use of FLS in place of or in combination with conventional offshore met masts offers potential benefits for the industry in terms of development costs, consenting timescales and the uncertainty associated with wind resource estimates. However, a significant body of supporting verification data must be established for each FLS to enable the confidence to be gained in measurement accuracy and reliability to move through the 3 stages of maturity defined in this roadmap document: Baseline Pre-commercial , and Commercial . The following subsections provide definitions, application limitations and milestones for each of these stages.

It is recognised that effort and investment are required to progress through these maturity stages, so it is useful here to summarise the advantage attained should progressive stages be reached:

- · The advantage of the Pre-commercial maturity stage over the Baseline stage is that a user of that system will have a significant additional degree of confidence on the accuracy and reliability performance that the FLS has demonstrated, and therefore can be expected to achieve, in a manner which is possible to compare with the performance of other measurement systems.
- · The advantage in attaining the Commercial stage over the Pre-commercial stage consists of accuracy, reliability, uncertainty and cost of deployment aspects. To attain the Commercial maturity stage, the FLS has to demonstrate the best practice accuracy criteria associated with Stage 2; and the minimum accuracy performance criteria are no longer applicable.  With regards to reliability, the FLS has to demonstrate significantly more demanding reliability performance, in terms of repeatedly proving high system and data availability during shorter or longer pre- and post-deployment verifications and in particular during early commercial project applications typically lasting at least 12 months. With regards to uncertainty, a key aspect which has been considered since the earliest days of FLS technology is how to understand the uncertainty of FLS data in a deployment environment which will be different, and quite possibly more demanding, than the environment which it experienced during verification. This is addressed through the Stage 3 maturity requirement that the FLS

must have been subject to 3 trials, which therefore provides a rational route to uncertainty assessment. For TI evaluation a new '+' stage is presented in this version o f the roadmap . The '+' designation shows that the TI measurement capability has been assessed using the metrics detailed in Section 2.6.2, for FLS types that have achieved Stage 2 or Stage 3 maturity already, it is proposed that the trusted reference  and trial data is evaluated by an independent third party to assess if the existing historical data can be used to upgrade the FLS type to the new '+' additional designation. In the event of it not being suitable, new trials are required and are detailed Appendix I. For unit evaluation, it is possible to evaluate reliably the performance of TIFLS data within the data criteria previously presented within the roadmap.

## Section 2.01 FLS type related considerations

It should be recognised, in general, that all statements, prerequisites and rankings related to the maturity stage of an FLS as treated and prescribed in this roadmap document shall be understood as being assigned to a specific 'type' of a n FLS and hence be valid for each FLS 'unit' of this 'type' assuming no major changes exist from unit to unit as compared to the type unit originally tested. This means for example, that the prescribed stage 2 type verification trial needs to be performed only once and for a single unit for each 'type' of FLS.

In this context considerations must be made as to when a design change to an FLS type constitutes a different type. A type verification of a certain type of FLS refers to a suite of devices that are effectively identical in design as manufactured by an OEM. It is therefore important to understand whether any applied design changes constituting a new FLS design will invalidate the type verification that has been undertaken for the original FLS design. If this was the case, then the new design would effectively be considered as a new FLS type and would require a further type verification for a period of six months as prescribed in this roadmap.

Typical type-critical design changes seen in the past, and that have the potential to constitute a new FLS type, are primarily considered to be related to the following fundamental components and aspects:

- · Type of lidar device (including version of processing software).
- · Type of buoy/floating platform employed by the FLS.
- · Type of motion compensation, and in case of algorithm motion compensation, the specific software version.
- · Power supply, fuelling capabilities and related change in buoyancy distribution.
- · the dynamic response of the whole FLS buoy to various sea states and weather conditions (for example related to weight distribution, centre of gravity, centre of buoyancy etc.),
- · The reliability of the overall system.
- · Significant overall software changes which offer a different method to calculate key wind data.

In principle, the FLS must be considered of a new type if a design change has occurred including where a component (such as, but not limited to, those listed above) previously used is exchanged for an alternative component of a different specification. If there is a reasonable case to assert that the risk of such a change invalidating the previous type verification is so small as to be negligible, this can be asserted by a suitably qualified and experienced, independent third party organisation, taking consideration of:

- 1. The specific design changes that have occurred.
- 2. The results of previously declared type verifications.

- 3. An examination of whether the design changes would invalidate the accuracy or reliability of the system, taking into account any margins available from the previous type verification and the specific requirements of the type verification.
- 4. Any changes to software versions against the release used by the OEM at the point of the maturity evaluation.

In principle, it does not matter which stakeholders action this process, although in practice it is more likely to be practicable for the FLS OEMs to do so, as it is considered they will own the FLS configuration control process.

It is further noted that in the case of any changes made to the FLS during a measurement campaign (e.g. replacement of a lidar device), further recommendations are given in Section 2.6.3 (need for pre- or post-deployment verification trials).

## Section 2.02 Summary

The prerequisites, possible modes of application, requirements for and limitations of deployment for each maturity stage, as part of a future WRA measurement campaign, are summarised on the following page. This roadmap diagram in Table 1.1 serves as a summary guide to the remainder of this section, which provides the detailed rationale.

An important aim of this document is to increase confidence in the wind industry with regards to the performance and accuracy of floating lidar technology, in the context of WRA campaigns, when used to support final investment decisions for proposed offshore wind farms. A key metric here is the uncertainty associated with the measurements from the FLS.

Indicative scenarios of plausible FLS deployments as part of a WRA are summarised below in Table 1.2.

Table 1.1  Summary of roadmap

| Maturity stage            | Pre-requisites (type verification)                                                                                                                                                            | Wind resource assessment campaign requirements                         | Wind resource assessment campaign requirements                                                                                                                                                                                                                                                                                                                               |
|---------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Maturity stage            | Pre-requisites (type verification)                                                                                                                                                            | Possible applications                                                  | Limitations                                                                                                                                                                                                                                                                                                                                                                  |
| Baseline (Stage 1)        |  Lidar type considered as 'proven technology' in onshore wind industry.                                                                                                                      | Scenario A Fixed met mast supplemented by one or more FLS deployments. |  FLS data used only in a relative sense to support wind flow modelling used to estimate horizontal and vertical variation in wind resource across site.                                                                                                                                                                                                                     |
| Pre- commercial (Stage 2) |  As above, plus:  Pilot verification trial for FLS type completed successfully including independent scrutiny and confirmation of acceptance criteria.                                      | Scenario B Single FLS deployment.                                      |  Two-phase FLS Validation 2 required.  Metocean conditions during campaign must be demonstrated to be within the Unit Validation and Type Verification.  Independent and reliable wind data source (regional measurements or modelling) and / or high level of industry experience of wind resource in region required to cross-check results.  Two-phase FLS Validation |
| Pre- commercial (Stage 2) |  As above, plus:  Pilot verification trial for FLS type completed successfully including independent scrutiny and confirmation of acceptance criteria.                                      | Scenario C Multiple FLS deployments.                                   |  Two-phase FLS Validation 2 required.  Metocean conditions during campaign must be demonstrated to be within the Unit Validation and Type Verification.  Independent and reliable wind data source (regional measurements or modelling) and / or high level of industry experience of wind resource in region required to cross-check results.  Two-phase FLS Validation |
| Pre- commercial (Stage 2) |  As above, plus:  Pilot verification trial for FLS type completed successfully including independent scrutiny and confirmation of acceptance criteria.                                      | Scenario D Fixed met mast supplemented by one or more FLS deployments. | required. Phase 2 can be carried out on target site.                                                                                                                                                                                                                                                                                                                         |
| Commercial (Stage 3)      |  As above, with elevated availability acceptance criteria, plus:  Good operational experience and accuracy achieved across a number of pre-commercial deployments.  Residual environmental | Scenario E Single FLS deployment.                                      |  Scenario B and C limitations recommended for lowest uncertainty, although not essential.                                                                                                                                                                                                                                                                                   |
| Commercial (Stage 3)      |  As above, with elevated availability acceptance criteria, plus:  Good operational experience and accuracy achieved across a number of pre-commercial deployments.  Residual environmental | Scenario F Multiple FLS deployments.                                   | For two-phase FLS Validation, ideally at least phase 2 to be performed, or phase 1 plus a risk-based approach as described in the IEA recommended practices 3 .                                                                                                                                                                                                              |
| Commercial (Stage 3)      |  As above, with elevated availability acceptance criteria, plus:  Good operational experience and accuracy achieved across a number of pre-commercial deployments.  Residual environmental | Scenario G Fixed met mast supplemented by one                          | Two-phase FLS Validation recommended for lowest uncertainty, but not essential. Phase 2 can be carried out on target site.                                                                                                                                                                                                                                                   |

2 Two-phase FLS unit verification is described further in Section 2.4.2.

3 Pre-deployment verification defined in the IEA Wind, Expert Group Report on Recommended Practices, 18. Floating LiDAR Systems, First Edition 2017. O. Bischoff, I. Würth, J. Gottschall, B. Gribben, J. Hughes, D. Stein, H. Verhoef. https://community.ieawind.org/publications/rp

|                           | understood and documented.                                                                                                                                                                                                                                                                | or more FLS deployments.   |                                                                                                                                                                                                                                               |
|---------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pre-commercial (Stage 2+) |  As per Stage 2 above.  A documented TI FLS process shall be available.  A software version number shall be recorded and documented.  No additional trials are required as long as the Stage 2 trial reference meets the trusted reference criteria as defined in Appendix 1.         | Scenarios As above.        |  TI FLS error metrics shall be evaluated against a trusted reference (Appendix 1).  If a Stage 2 trial has taken place against an uncorrected fixed lidar system a further Type trial is required against a trusted reference (Appendix 1). |
| Commercial (Stage 3+)     |  As per Stage 3 above  A documented TI FLS process shall be available.  A software version number shall be recorded and documented,  No additional trials are required as long as the Stage 3 trials trusted reference meets the trusted reference criteria as defined in Appendix 1. | Scenarios As above.        |  TI FLS error metrics shall be evaluated against a trusted reference - Appendix 1.  If a Stage 3 trial has taken place against an uncorrected fixed lidar system a further Type trial is required against a trusted reference (Appendix 1). |

Table1.2:  Summary of FLS scenarios examined

|                                                           | Maturity stage   | Maturity stage   | Maturity stage   |
|-----------------------------------------------------------|------------------|------------------|------------------|
| type                                                      | Baseline         | Pre- commercial  | Commercial       |
| One FLS unit replacing a met mast                         | N / A            | Scenario B       | Scenario E       |
| Multiple FLS units replacing a met mast                   | N / A            | Scenario C       | Scenario F       |
| Fixed met mast supplemented by one or more floating lidar | Scenario A       | Scenario D       | Scenario G       |

Important notes

It is stressed that for each scenario a case-specific uncertainty is to be estimated following the procedure and principles outlined in IEC TS 61400-50-4 . Past studies have shown that FLS measurement uncertainties are generally dominated by the uncertainty of the reference device used in the unit verification test and a classification uncertainty that may be applied if environmental conditions at the verification and the application site are not sufficiently similar. For Scenario D and G, the classification uncertainty can be neglected completely if the unit verification is carried out at the target site and concurrently with the target application.

As detailed in Table 1.2, Scenarios C and F differ not with respect to their limitations. The benefit of using multiple FLS deployments may be in making use of the data redundancy (and the fact that one system may still be available if the other fails) or the potential to assess horizontal variation in wind resource if the systems are further distributed over the target site. Both items may have a beneficial effect on the overall confidence in a final wind resource or energy yield estimate.

Further note that the achievement of Stage 3 (Commercial) does not in itself necessarily entail a lower uncertainty than Stage 2 (Pre-commercial) as this will depend on the magnitude of the classification uncertainty which may or may not be available for a Stage 2 device (see Section 2.4.5). However, it is expected that the FLS types that are pushed to Stage 3 are likely to be those systems that are characterised by a lower uncertainty -and generally better performance in terms of measurement accuracy -than other types.

In either case, measured uncertainties should be estimated following a well-defined procedure (as outlined in IEC TS-61400-50-4). Requirements for Stage 3 (see Section 2.5) include an advanced assessment of the FLS type under consideration -with further shorter verification trials as well as more detailed tests -and with this potentially a better understanding of the system performance across a range of environmental conditions. It can be expected that this improved understanding, evidenced through the requirements listed in Section 3.5.2 and independently verified by a third party, may result in less conservative uncertainty estimates and lower 'penalty' values for so far non-observed system behaviour.

For a particular FLS unit which has been verified for a first WRA deployment, the question arises as to whether verification for a second WRA deployment needs to be as stringent or required at all. It is recommended that on this topic the advice from Clause 6.7 of IEC 61400-50-4 is reviewed.

For TIFLS it is recognised that there is no current recommended practice for the evaluation of TI uncertainty. Instead, error metrics have been proposed that match the common TI application within WRA or site condition assessment. It is for the end user to evaluate and decide as to whether the error level is acceptable for their application.

## Section 2.03 Stage 1: Baseline

## Definition

At this stage, operational devices are available and some preliminary demonstration tests have been carried out or are in progress. An FLS is considered to be within the Baseline stage as long as no independent and thorough offshore verification test as defined in Section 2.3.2, has been successfully completed.

## Pre-requisites

As a pre-requisite, the lidar product used in the FLS -including its hardware and firmware -should have achieved widespread acceptance within the onshore wind industry as "proven technology" in the field of wind resource characterisation for non-complex terrain sites. Currently, not all lidar types are considered as proven technology, while a few have indeed reached this stage and therefore individual units of the lidar product in question can be deployed for wind resource measurement with a reasonable level of confidence.

To be considered as proven technology for onshore applications, the lidar must be commercially available and have a widespread accepted track record for being capable of routinely providing measurements of wind speed and direction with height. More precisely, multiple independent reports should be available supporting its successful verification against high-quality mechanical anemometry in benign terrain/flow under various atmospheric conditions and at measurement heights relevant to modern wind turbines at an accuracy comparable to that of classical anemometry.

A milestone is reached when one or more production units have been successfully tested at one or more suitable and recognised test facilities against data recorded from a high-quality conventional wind measurement met mast, or alternatively against a trusted reference lidar, whose accuracy is traceable to high-quality conventional anemometry over a range of heights, operational, atmospheric and simple flow/terrain conditions relevant to wind energy applications. The tests will have demonstrated that the accuracy achieved through remote sensing is similar to that which would have been achieved with conventional anemometry for measuring ten-minute average wind speed and wind direction.  The results of the tests must be published in a suitable technical paper or report.

Once the above-mentioned milestone is reached, the lidar type gains wide use and an increasing number of production units are deployed on a range of sites with different met characteristics. Additionally, more operational experience is gained and more is learned about the set-up, robustness and consistency of the measurement equipment when comparing various units. Confidence is gained that lidar units provide robust, continuous and accurate data over the full spectrum of operational conditions. Alternatively, specific conditions where the lidar type, and its individual units, do not provide robust data become well understood and can be excluded from analyses.  Data from individual units of the lidar type may be used quantitatively within an onshore formal wind speed and energy assessment in non-complex terrain/flow although, in some instances, site-specific verifications for a given unit against conventional anemometry data may be required. At this stage, the lidar type is considered as proven technology and it is common that in onshore non-complex terrain and flow, the measurement uncertainties associated with measurements provided by individual lidar units are similar to those of high-quality mechanical anemometry.

## Offshore application

Data from FLS at this stage is not deemed reliable enough to be used quantitatively in the context of a formal wind resource assessment. However, it is expected that they can provide qualitative

information to supplement fixed offshore wind measurement sensors and these circumstances are assessed quantitatively under Scenario A (Table 1-2).

## Limitations of offshore application

There are no formal requirements for FLS at this stage as they are not expected to provide acceptably validated wind data. However, it is recommended that metocean conditions be measured and documented to help build a body of knowledge on the performance of the technology and its sensitivity to external and operational parameters.

## Expected levels of measurement uncertainty

At this stage, the FLS data shall only be utilised in a relative sense, to support wind flow modelling and potentially other sources used to estimate horizontal and vertical variation in wind resource across the site. Absolute wind resource estimates will be anchored to analysis of the primary source of on-site wind data which is assumed to be from a trusted reference system and therefore uncertainty levels shall be primarily driven by this primary source.

## Section 2.04 Stage 2: Pre-commercial

## Definition

At this stage, FLS units are commercially available in the sense that FLS units can be purchased from OEMs, have fulfilled the Baseline stage requirements and an independent third party has issued a Type Verification document for the technology (as described below).  However, operational requirements and limitations may be insufficiently studied and documented so that there is a significant level of uncertainty as per their performance on any given offshore site, especially where the expected environmental conditions differ significantly from those experienced during the pilot verification trial(s), which in the end may result in a higher uncertainty estimate.

## Pre-requisites

For a floating lidar technology at Baseline stage, a milestone is reached when at least one unit has successfully completed at least one pilot verification trial. The FLS is then said to have achieved Type Verification. For the pilot verification trial, a two-phase protocol as described below is required.

The two-phase protocol is designed to:

- · Validate the lidar performance onshore in a fixed frame of reference and in the absence of any motion; and
- · To validate the floating lidar performance offshore under dynamic conditions and under changing wind and sea conditions.

The onshore verification of the unit should be performed against high-quality conventional anemometry, or alternatively against a trusted reference lidar whose accuracy is traceable to highquality conventional anemometry. Indeed, at this preliminary stage, it is considered that even though the lidar unit belongs to a proven lidar type; the specific performance of the unit at hand should be precisely determined before any offshore test is undertaken.

The offshore verification would need to be undertaken at an actual offshore site against a reliable and traceable fixed offshore met mast designed in accordance with relevant industry standards and best practice, or against another suitable trusted reference system. However, caution is noted that the use of a lidar as the trusted reference source is not currently considered a reliable source to assess the performance of the FLS in accurately measuring TI as discussed further below. The offshore verification test is to determine the accuracy achieved by the FLS is traceably referenced ultimately to that achieved with fixed cup-anemometry already accepted for formal WRA and energy yield assessments. Metocean conditions should be documented and relevant sensitivity analyses should be undertaken to show the extent to which external parameters and conditions affect FLS performance. However, suggested acceptance criteria have previously been introduced in previous versions, and these are reproduced in Appendix 1.

The results of the Type Verification test must be published in a suitable technical report to serve as a reference document for the FLS technology.

It is noted that in some circumstances detailed turbulence and gust information may be a formal requirement of certification bodies or turbine manufacturers for site feasibility assessment and structural design; therefore, careful consideration should be given to this point in the specification of a measurement campaign.  TI is also of relevance for wake modelling when assessing Annual Energy Production (AEP).

This roadmap focusses on the capabilities of floating lidar technology to replace met masts in measuring primary wind data, namely wind speed, wind direction and TI.

The above pre-requisites are summarised in tabular form in Appendix 1.

## Offshore application

Once the above-mentioned milestone is reached and the FLS is considered to have achieved Type Verification, it is expected that it could be deployed on offshore sites to supplement fixed offshore wind sensors (Scenario D) or as a standalone source of wind data (Scenarios B and C) provided the requirements of the next subsection are met.

Limitations of offshore application

Two-phase verification of each unit

During this stage, FLS units to be deployed for offshore WRA are to follow the two-phase verification protocol (see Section 2.4.2) before the actual measurement campaign may begin. The purpose of the preliminary two-phase verification is twofold:

- · To avoid tracing back the performance of all units to a single test, namely the Type Verification trial results; and
- · To gain confidence that different units provide consistent, robust, continuous and accurate data over a variety of operational, atmospheric and sea conditions.

Metocean conditions are to be accurately measured and documented during the two-phase verification protocol to help understand FLS performance during the tests and later during the actual offshore measurement campaign.

If the outcome of the two-phase verification protocol is not consistent with previous such tests, notably those of the Type Verification (pilot) trial, the FLS unit may not be suitable for use in the context of a formal uncertainty analysis. In such circumstances, the causes of unexpected performance should be investigated and explained. Please see IEC TS 61400-50-4 for further guidance.

Metocean conditions

For standalone applications (Scenarios B and C), it is required that the metocean conditions which have prevailed during the two-phase verification described above be representative of those expected on site during the measurement campaign. More precisely, it is expected that the external and operational parameters which are deemed to affect the FLS performance do not significantly exceed the envelope of these environmental parameters observed during the twophase verification trial. Otherwise, it must be demonstrated that either the impacts of these parameters on wind speed error are negligible or that they can be reliably quantified based on evidence from available FLS Type Classification, where available. This should be backed by literature or acceptable data analyses.

A list of parameters which may affect the performance of the FLS is presented in Clause 7.3.3 of IEC TS 61400-50-4. Measurement of these quantities is recommended to perform sensitivity analyses of the statistics of the FLS errors as a function of the listed parameters to drive conclusions.

As a first approximation, verification test conditions may be deemed representative of site conditions if the magnitudes of environmental parameters potentially impacting the wind data quality during the measurement campaign (referred to above) remain within the envelope observed during the verification tests. Recorded wind data during periods where such tertiary parameters fall outside of the verification envelope should be considered with care and potentially rejected.

Independent source of site wind data

During the Pre-commercial stage, it is important to monitor the consistency of the performance of the FLS during the measurement campaign. It is therefore required that an independent and reliable source of site wind data be available to perform periodic and regular sanity checks. Examples of validation sources are presented in Clause C.5 of IEC TS 61400-50-4. 4 .

The presence of such an independent source of wind data would also serve to mitigate risks associated with a lack of redundancy, risks of systematic errors and other issues such as those related to measuring on-site TI with a lidar -provided the said source of wind data does indeed provide this information.

In case a standalone application is sought (Scenarios B and C), it is required that a good level of regional wind climatology knowledge be available. Such a body of knowledge may be based on previous studies and modelling including reanalysis data or come from nearby reliable sources of fixed wind data sources.

Need for pre- or post-deployment verification trials

Should an inconsistent performance of the FLS be observed during a measurement campaign, a post-deployment verification trial of the FLS unit may be required to determine the cause, explain the observations and, if possible, attempt to salvage the measurement campaign in case a serious anomalous behaviour is detected.

Those inconsistencies may consist in failure and replacement of the employed lidar device or the whole FLS buoy, incidents of impact to the buoy during deployment and operation (e.g. collision with drifting debris or fisheries), extreme weather and sea states, longer lasting outage of power supply for example. It is recommended that on this topic of whether pre- or post-deployment verifications of an FLS unit are required, the advice from IEC TS 61400-50-4 Clause 9.4.3 is relevant.

## Assessment of uncertainties for Stage 2 FLS

The measurement uncertainties of an FLS (irrespective of which stage it has achieved) are to be assessed by following the procedure outlined in IEC TS 61400-50-4.

The Type Calibration trial that is required to achieve Stage 2 may (at this stage) be evaluated as a verification test in order to derive a verification/calibration uncertainty. Unit verification trials (i.e. pre-deployment verifications) can also be used to derive the verification/calibration uncertainty.

At the completion of the Stage 2 trial a sensitivity analysis shall be carried out and the output used to establish the initial evidence base of the FLS type as per IEC TS 61400-50-4 Clause 7.  Note that for a complete classification test, several trials at different locations and with different units are required which is a pre-requisite for achieving Stage 3. A classification test and the corresponding uncertainty which is based on fewer trials and related evidence should include some added uncertainty.

In principle, a Stage 2 FLS can have the same uncertainty as a Stage 3 FLS. However, it is expected that the assessment for a Stage 2 FLS is typically based on less evidence in terms of performed trials and that uncertainty values, particularly relating to the classification uncertainty, are estimated or assumed on another basis. This may lead to an elevated (and more conservative) level due to the lack of evidence for Stage 2 FLS.

4 IEC TS 61400-50-4 Clause C.5: Wind Energy Generation Systems Part 50-4: Use of floating lidar systems for wind measurements.

## Stage 2+ Assessment

Stage 2+ confirms that the FLS has been subject to one long trial, experiencing continuous offshore conditions, where the trusted reference is traceable to a cup anemometer TI value.

It is possible that the FLS OEM may provide two data products. Data product one is focused on wind speed accuracy and data product two focused on TI data quality. The difference may exist when an already qualified FLS is assessed for TI retrospectively. To achieve TIFLS the data may be post processed in a different manner to the normal FLS wind speed and direction datasets.

## Section 2.05 Stage 3: Commercial stage

## Definition

At this stage, the FLS type is considered to have achieved commercial acceptance with respect to formal WRA and energy yield assessment reports, incorporating uncertainty analyses and quantification of confidence limits in terms of energy yield expectations at various levels of probability such as 90% (P90), 95% (P95) and 99% (P99) commonly used for project financing. Wind data from FLSs at this stage may be used quantitatively with only limited or even in the absence of site-specific verification. Expected measurement uncertainties should be comparable to those assigned to conventional offshore met masts provided best practice are followed and robust data quality control and uncertainty analyses have been undertaken and documented. In addition, FLSs at this stage have demonstrated significantly more demanding reliability performance, to a criteria higher than Stage 2, and in a range of metocean conditions, supported by a sufficient body of evidence. The reliability performance, number of trials and duration required for each maturity stage are summarised in Appendix 1.

## Pre-requisite

At this stage, units of a specific FLS type, such as using a specific lidar type and being sufficiently similar in technical configuration to the type tested version as discussed in Section 2.1, are commercially available. Furthermore, an independent third party has issued a Type Verification document for the technology as described in Section 2.4.2, fulfilling the requirements for Stage 2 maturity.

In addition, a body of evidence is available that demonstrates the capability of the particular FLS type to achieve higher levels of availability and reliability beyond that expected of Stage 2 devices and across a range of conditions. This is evidenced through further successful trials as well as early commercial deployments as part of WRAs covering a range of operational, site and metocean conditions. As discussed in Section Section 1.02, it is expected that Stage 3 maturity claims will be independently verified by a suitably qualified and experienced third party organisation.

In particular, an FLS is considered to reach Stage 3 maturity when the following specific requirements are fulfilled in addition to the Stage 2 Type Verification:

- 1. A number of at least six trials of this FLS type, consisting of three longer trials of at least three months continuous duration and three shorter pre- or post-deployment verifications have been completed against a suitable trusted reference, successfully meeting:
- a. All data accuracy KPIs at AC level (see Appendix 1), for heights above sea level that are representative of typical offshore hub heights).
- b. All availability KPIs at Stage 3 AC level, see KPI tables in Appendix 1.
- 2. A number of three (3) FLS type Classification Trials have been completed, as recommended in the IEC TS 61400-50-4. These should be performed for a minimum of two

- devices of a specific type of FLS at a minimum of two different sites for a sufficiently long period. A period of between three to six months is anticipated to be sufficient, although this will be dependent upon the range of conditions captured during the trial. These Classification Trials shall provide consistent results for FLS error sensitivity to offshore typical environmental variables, covering a sufficient significant range of sea states and other relevant external conditions.
- 3. A number of at least five early commercial project deployments (using the same FLS type as discussed in Section 2.1) covering an un-interrupted duration of 12 or more months have been completed successfully, meeting all availability KPIs at Stage 3 Acceptance Criteria level as defined in Appendix 1 . 5
- 4. For all the above (1) to (3)c, evidence on logistical management should be collected, documented and provided. This should comprise scheduled and unscheduled service visits, any occurring issues or faults and related risk mitigation measures as part of an operations management plan to assure maximum reliability and maintainability, all whilst maintaining the KPI for availability in order to prove the logistical capabilities of the FLS.

The above pre-requisites are summarised in tabular form in Appendix 1. It is noted that the trials listed for requirement 1. above could include the Stage 2 Type Verification trial and Classification Trials as defined in requirement 2.

For devices that have reached maturity Stage 3, it is recommended that availability requirements for overall system availability campaign average (OSACA), monthly system availability (MSA1M) and overall post-processed data availability (OPDACA) are fulfilled by all trial or project deployment campaigns.

Furthermore, the envelope of operational, site and metocean conditions covered by these trials and deployments is considered sufficient and the performance of the FLS in a range of conditions becomes well understood. In particular, from the body of evidence gathered, certain environmental conditions may be identified in which the FLS is known not to perform correctly. In these specific conditions where the technology is known not to provide robust data, these can be excluded from analyses either through removing affected periods entirely, or through filtering the dataset for the specific conditions.

An FLS which has reached Stage 3 maturity is expected to have demonstrated a track record for serviceability during deployments of varying durations. This requires a documentation of collected evidence on logistical management as recommended above under item (4). To ensure safe and repeatable operations during the deployment phase, a robust and tested methodology should be considered and adopted for the deployment and retrieval of the FLS. This should include operations for transport, repair and servicing strategies in order to meet the required KPI criteria for data availability as described in Appendix 1.

## Offshore application

It is expected that at this stage, FLS data can be used quantitatively as a stand-alone data source (Scenarios E and F) or to supplement data from offshore met mast(s) (Scenario G), provided the requirements below are met. For stand-alone applications, as previously mentioned, attention should be paid to such concerns as redundancy, performance consistency, potential systematic errors and TI measurement.

5 It is acknowledged that the maintenance strategy can strongly influence the achieved availability KPIs. For example, a maintenance strategy ensuring highly responsive service vessels could achieve significantly greater availability KPIs than a less responsive service, where the underlying reliability of the FLS may be identical. To avoid this affecting the criterion unduly, in evaluating this criterion adjustments can be made to account for varying maintenance strategy, so long as the principle of attaining availability KPIs is retained.

## Limitations of offshore application

It is expected that for the FLS technology to continue on track to become a mature and widely accepted means of offshore WRA, a set of best practice will be needed to ensure a consistent and high level of quality. It is intended that this document, shall help inform industry best practice.

As a general rule, the following recommendations are seen as best practice rules which would bring additional confidence in the reliability and accuracy of the FLS data:

- · FLS sanity or consistency checks using an independent source of wind data during the campaign. Typically referred to as validation tests -see IEC61400-TS-50-4.
- · Two-phase verification trial before an offshore wind resource campaign begins is recommended for lowest uncertainty.
- · Additional confidence in the reliability and accuracy of the FLS when operated within metocean ranges where its performance has been proved.

The same comments as made previously in Section 2.4.4.4 and 2.6.3 regarding pre- and postdeployment verification trials of the FLS unit as part of a wind measurement campaign still apply.

## Assessment of uncertainties for Stage 3 FLS

It is expected that following the recommendations presented in the previous subsection, an increased level of confidence would be gained in the results and the related uncertainty levels of FLS wind data. It is expected that under ideal conditions, the FLS measurement uncertainty could be similar to those of a proven lidar device deployed onshore in benign terrain. However, the actual uncertainty levels will be site-specific and would eventually need to be evaluated based on available information and data and by following industry standards.

As for an FLS that has achieved Stage 2, the measurement uncertainties of an FLS that has achieved Stage 3 are to be assessed by following the procedure outlined in IEC 61400-50-4.  A preverification is required for each individual FLS unit, independent from which maturity stage has been achieved by the type. The type classification is based on a larger number of trials (cf. Stage 2 with only one trial available in some cases), which may result in a better knowledge of the device performance and most likely less conservative estimates of the uncertainty contribution according to type classification.  If the FLS is deployed in connection with a met mast (Scenario G in Table 2.2) the verification can, again, be obtained from the application campaign itself.

## Stage 3+ assessment

A larger number of trials have shown the data quality of the TI dataset against different references and different sites, over a series of long and short trials. The Stage 3+ designation should be thought of as a more reliable quantification of TI performance than Stage 2+ as testing has taken place in different locations and I different environmental conditions.

Please note some care needs to be taken when evaluating the impact of different trusted reference sources to ensure there is a consistent basis of error assessment.

## Section 2.06 Other considerations

## Length of measurements and power supply

Regardless of the level of maturity or acceptance of the technology, the length of the data set and achieved data coverage rates at hub height are key considerations in measurement campaigns. FLS campaigns should span a similar period as those undertaken with conventional masts and

both should also take account of the availability of suitable long-term reference data for use in Measure-Correlate-Predict type analyses.

In particular, care should be given to circumstances, if any, where specific operational or metocean conditions may reduce data availability or reliability and therefore may result in systematic errors or uncertainties. Also, it is important to deploy a device with a sufficient power supply and an appropriate operations and maintenance (O&amp;M) program such that it can be recommended that data coverage rates up to hub height will be high (see appendix for availability KPIs).

In addition, it is important that the equipment and power supply are such that the FLS may operate for extended periods without interruption in very challenging environments. Given the substantial cost of offshore platform installation, consideration should be made as to how data redundancy might be achieved, through for example a second remote sensing device, or any other scenario which might be appropriate given the site-specific conditions prevailing at the offshore project site in question.

## Reliability of turbulence intensity measurements from FLS units

It is noted that some lidar and FLS OEMs use different methods for calculating, processing and filtering the raw measured FLS data to calculate TI. It is therefore expected that clarity will be provided by the OEM regarding any processing algorithms implemented by the FLS. Where refinements and developments have been made by the OEM, it is expected that the impact of such changes be demonstrated as part of a trial.

As a minimum, it is expected that the profile of TI with wind speed and direction is measured by the FLS and compared to the TI measurements obtained at the reference source as part of a verification trial. Given the reliance of existing design standards on measurement from cup anemometry, it is recommended that, where possible, the reference source is a met mast. It is recommended that the verification trial be performed under similar atmospheric stability conditions as expected in the WRA campaign in order to identify any trends or conditions which impact the accuracy of the TI measurements.

There is no difference in the length of trial required for each level of maturity for TI that results in a '+' addition. It is hoped that existing FLS maturity trials can be assessed and the results reprocessed to enable the '+' designation. However, this is only the case if the original Type evaluation is deemed valid by a third party.

TIFLS evaluation normally involves a processing of data to account for the motion of the FLS hull on the FLS lidar measurement normally defined as motion compensation or correction. This may be mechanical, numerical or mechanical + numerical in nature. If the compensation method was part of the original maturity trial(s) then it is possible that no new trial is required.

If a compensation process is applied, then it is possible for the FLS OEM to present two data products. Data product 1 is consistent with the original maturity designation (software version and mechanical mounting of the FLS lidar). Data product 2 is a new post processed data product for the presentation of TI data. In this instance, so long as the trusted reference is assessed as suitable, no new trials are required.

For  +  designation new type trials, there is no modification to the campaign duration for the stage ' ' maturity trials.

For  +  designation for units, there is no modification to the performance verification campaign ' ' duration, i.e. the same wind speed bin filling criteria are suitable for TI error assessment.

It is recommended that each unit that will be used for TI data acquisition should be assessed according to the '+' designation. The testing of each unit extends the evidence base associated with that unit and type in being able to measure TI with a known error in different campaign conditions. This is aligned with the treatment of uncertainty and envelope of operational conditions in IEC 61400-50-4.

For the evaluation of TI, the performance of an FLS Type and FLS unit shall be evaluated by correlation analysis and via TI distribution binned by wind speed against a trusted reference (Appendix 1) which is traceable to a cup equivalent TI.

The details of this analysis and evaluation are given in Appendix 1.

Replacement of faulty components or system during a wind resource assessment campaign

In cases where a key component such as the lidar device needs to be replaced during a WRA campaign (for example due to an observed failure or malfunction) specific measures should be taken to mitigate the risk of losing wind data traceability and increasing uncertainty. Those measures may consist of checks to ensure the correct function of the replaced component in conjunction with the whole FLS such as:

- · Onshore sanity checks against a suitable reference.
- · Onsite in-situ comparisons against a suitable on-board or external reference sensor.
- · Where a pre-deployment verification of the replaced configuration has not been performed, then assess whether a post-deployment verification of the whole FLS is required.

For further guidance please refer to Clause 9.4.3 of IEC TS 61400-50-4.

## Site Acceptance Tests

It is recommended that a Factory Acceptance Test (FAT) and Site Acceptance Test (SAT) are undertaken as part of any successful FLS deployment to ensure that the device has been configured correctly and thus mitigate the risk of lost time or wind data associated with correcting any erroneous configurations during a deployment.

The SAT should be undertaken prior to commencement of the campaign deployment and with both the FLS OEM and the project developer to which the deployment pertains in attendance. To ensure transparency and traceability of the deployment, it is further recommended that the SAT is witnessed and documented, ideally by a suitably qualified and experienced independent third party.

SATs should include an inspection of the main components of the FLS, testing of the equipment and plausibility checks of the measurements recorded by all sensors on the FLS. The serial numbers of all equipment sensors should also be documented for transparency (for example, buoy, lidar device, data logging equipment, software version numbers, on-board met and metocean sensors etc.).

SAT checklists can vary between FLS OEMs, however, it is recommended that as a minimum the following topics are assessed and tested as part of a SAT:

- 1. Visual inspection of the buoy to include, but not limited to:
- a. Buoys, sensors and equipment.
- b. Mooring.
- 2. Power systems like batteries, solar panels, wind turbines and the fuel powered generator.
- 3. Met and ocean state instrumentation.
- 4. Communication systems like telemetry, location systems (GPS) and on-board compass.

- 5. Lidar system:
- a. Installation position, mounting and orientation.
- b. Measurement height configuration.
- c. In situ validation of data.
- 6. Calibration of the compass and DGPS (as available) for heading.
- 7. Logging of firmware, software, and serial numbers of all measurement components.
- A proposed required documentation checklist is presented in Table C.1 in IEC TS 6140050-4.

## Article III. Conclusions

The Carbon Trust OWA has produced this roadmap for the steps required for FLS technology to become commercially accepted within the offshore wind industry. Version 3.0 of this document was developed in 2025 and is highly consistent with versions 1.0 and 2.0 from 2013 and 2018 respectively. An important material difference is that an appropriate trusted wind speed reference (which is not an anemometer mounted on a mast) is now explicitly permitted and more clearly defined for the application of TI assessment. The major development of version 3.0 is to provide much more information on TI assessment requirements and some alignment with the recently published IEC TS 61400-50-4 on floating lidar systems.

Broad guidance is provided for the three stages envisaged for an FLS product to reach commercial acceptance , with the addition of a '+' designation to cater for TI assessment . On the basis of this work, the following conclusions are drawn.

- · Prior to the deployment of FLS technology, the lidar measurement unit itself should be considered as proven technology and have broad commercial acceptance within the onshore wind industry. At this ' b aseline' stage of maturity, no formal verification trials have been completed, but the FLS technology still may be used to contribute to a commercial energy production assessment in a supporting role, when deployed in parallel to a conventional offshore met mast.
- · An FLS product may be considered to have reached a second stage of maturity (' precommercial') once a pilot verification trial has been successfully completed, including independent scrutiny and confirmation of appropriate acceptance criteria and trial design. At this stage, FLS technology may be used with or without an onsite met mast but should minimally undertake a pre-campaign two-phase (i.e. onshore and offshore see Section 2.4.2) unit verification to prove the accuracy of the lidar unit and FLS system against a trusted reference source prior to full deployment. If deployed without an onsite met mast, the FLS wind data can only be considered valid for periods when metocean conditions remain within the verification envelope experienced in the type and unit trials.
- · Commercial maturity is considered as a third stage for FLS products and is reached once a significant body of operational experience and verification has been established across a range of environmental conditions. Any residual environmental performance sensitivities are assumed to have been well documented and are understood by the manufacturer and the broader industry at this stage. With regards to reliability, the FLS has to demonstrate significantly more demanding reliability performance. At this stage FLS accuracy can be considered to approximate that of conventional fixed onsite met masts, albeit with a marginal level of residual uncertainty relating to site-specific deployment conditions.
- · A '+' designation to Stage 2 or Stage 3 is achieved once a FLS has been assessed using the presented metrics in Appendix 1 against a suitable reference, consisting of a met mast, a met mast and lidar, or a corrected/calibrated lidar output.

It is important to note that this roadmap was designed to focus on the capabilities of floating lidar technology in measuring primary wind data, namely wind speed, wind direction and TI. There are other secondary but important parameters required for a comprehensive offshore wind measurements such as wind shear, gusts, temperature, air density, relative humidity etc. Additionally, complementary oceanographic measurements are also required to achieve a full metocean measurement campaign. Therefore, while some floating lidars currently feature additional measurement capabilities and while future developments might add even more comprehensive measurement capabilities, it is important to bear in mind that this document is only

a roadmap towards replacing primary wind measured from offshore met masts with floating lidars, and that secondary wind data and metocean measurements will still need to be taken to complete a comprehensive offshore wind resource and metocean measurement campaign.

Additionally, although system availability is one of the KPIs used in this roadmap, this document does not directly address or cover the seaworthiness of the floating lidar devices.

## Appendix 1

Suggested acceptance criteria for type verification trials and for pre- or post- deployment verification trials

Recommended guidelines are presented below for the assessment of the performance of the floating lidar units under trial against a suitable reference, or during project deployments. They are based on the following definitions:

- · KPIs,  being  the  parameters  derived  from  analysis  of  the  data  gathered,  which  will specifically be used to assess performance.
- · Acceptance Criteria (ACs), being specific benchmark values defined for a sub-set of the KPIs  which  constitute  the  required  minimum  level  of  performance  for  each  FLS  to  be considered as achieving Maturity Stage 2, Stage 2+ (pre-commercial) or Maturity Stage 3 and Stage 3+ (commercial).

These parameters are divided into those representing the availability / reliability and accuracy of the systems in question.

The reliability of an FLS is to be assessed in conjunction with data accuracy for all verification trials against a suitable trusted reference, be it for a Stage 2 Type Verification trial, or for any post- or pre-deployment trial of a Stage 2 or Stage 3 FLS. When looking at reliability measures during project deployments, system and data availabilities may be treated in isolation from the data accuracy, if no wind data reference is available.

Note, that for FLSs that have reached Stage 3, higher acceptance criteria for system and data availability KPIs are imposed.

Generally, it is expected that the KPIs are evaluated for heights being representative for a typical state-of-the-art offshore wind turbine covering a height range over the full rotor disk. This means covering heights of modern turbine's upper tip heights of 200m and above. If this is not possible the upper measurement key height shall -as minimum requirement -be representative for a typical offshore hub height, and several other lower heights, down to a project relevant lower measurement height, shall be taken into account.

The performance assessment of the given KPIs and respective acceptance criteria regarding availability and accuracy shall be executed at each reference level present, in this case at each of the trusted reference source's measurement levels.

All data collected from the date of commissioning of each FLS until its decommissioning shall be taken into account in the overall data processing scheme, regardless of the environmental conditions.

Finally, the duration of the campaign should be considered. The conclusions will be valid for the metocean conditions experienced during the trial(s), and so longer trials may be preferred to increase the probability of experiencing rougher sea states.

For a Stage 2 Type Verification trial it is recommended that at least six months of continuous offshore data are available from a single campaign to provide confidence with respect to the measured KPIs described below. It is required that this total of six  months of data is gathered within a single, uninterrupted trial campaign.

For Stage 3 Type acceptance, six  trials are required consisting of three long trials (three-month minimum duration) and three short trials (three campaign pre-deployment verification trials) are

performed. The Stage 2 trial is valid as one  long trial. The tests should provide continuous offshore data, with all data passing the necessary trial KPIs as presented in Appendix 1 accuracy assessment.

In addition to trial data, five continuous single campaigns of at least 12-months duration in different locations are required. Here the key KPI are system and data availability KPIs in Appendix 1 accuracy assessment.

For Stage 2+ designation, the long trial should be against a suitable reference, verified and traceable to a cup anemometer TI value. The system shall be assessed according to all error metrics as presented in the accuracy assessment section of this report.

For Stage 3+ qualification, all trials should be against a suitable reference meaning a reference that is traceable to a cup anemometer TI value. The system shall be assessed according to all error metrics as presented in the accuracy assessment section of this report.

Availability / reliability

The KPIs and Acceptance Criteria relating to availability, all of which are applicable to all measurement heights under consideration, are defined in the following tables.

Attention is drawn to the footnote within Section 0 regarding consideration of the influence of maintenance strategy in assessing the availability Acceptance Criteria in the context of WRA campaigns, listed as pre-requisite (c) for maturity Stage 3.

Availability KPIs are listed for both Overall System Availability and Post-processed Data Availability. It is acknowledged that in the context of WRAs, the Post-processed Data Availability KPI will be of most interest. The Overall System Availability KPI is included to inform the industry on the capability of an FLS to be fully functional and ready to collect data in an offshore environment. Distinction is made between overall and monthly availability KPIs to allow for seasonal effects.

| KPI    | Definition / rationale                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Acceptance Criteria Across total campaign length   |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------|
| MSA 1M | Monthly System Availability - one month average The lidar system is ready to function according to specifications and to deliver data, taking into account all time stamped data entries in the output data files including flagged data (e.g. by NaNs or 9999s) for the given month. The Monthly Overall System Availability is the number of those time stamped data entries relative to the maximum possible number of (here ten minute) data entries including periods of maintenance (regarded as 100%) within the respective month.                               | ≥90% for Stage 2 ≥95% for Stage 3                  |
| OSA CA | Overall System Availability - campaign average The lidar system is ready to function according to specifications and to deliver data, taking into account all time stamped data entries in the output data files including flagged data (e.g. by NaNs or 9999s) for the pre-defined total campaign length. The Overall System Availability is the number of those time stamped data entries relative to the maximum possible number of (here ten minute) data entries including periods of maintenance (regarded as 100%) within the pre-defined total campaign period. | ≥95% for Stage 2 ≥97% for Stage 3                  |

| KPI     | Definition / rationale                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Acceptance Criteria Across total campaign length   |
|---------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------|
| MPDA 1M | Monthly Post-processed Data Availability - one month average The Monthly Post-processed Data Availability is the number of those data entries remaining:  After system internal (unseen) filtering, i.e. excluding (NaN or 999) flagged data entries; and  After application of quality filters based on system own parameters, to be defined and applied in a post processing step on the basis of lidar contractor guidelines. relative to the maximum possible number of (here ten minute) data entries (regarded as 100%) within the respective month, regardless of the environmental conditions within this period. For a ten-minute record to be considered valid, both wind speed and yaw corrected wind direction shall be        | ≥80% for Stage 2 ≥85% for Stage 3                  |
| OPDA CA | Overall Post-processed Data Availability The Overall Post-processed Data Availability is the number of those data entries remaining:  After system internal (unseen) filtering, i.e. excluding (NaN or 999) flagged data entries; and  After application of quality filters based on system own parameters, to be defined and applied in a post processing step on the basis of lidar contractor guidelines. relative to the maximum possible number of (here ten minute) data entries (regarded as 100%) within the pre-defined total campaign period regardless of the environmental conditions within this period. For a ten-minute record to be considered valid, both wind speed and yaw corrected wind direction shall be available. | ≥85% for Stage 2 ≥90% for Stage 3                  |

The following KPIs are considered to have an impact on the overall reliability of the FLS. However, due to their nature, it is not considered appropriate to assign Acceptance Criteria to these KPIs. However, it is recommended these KPIs be reported on and their impact included in availability KPIs listed in the tables above.

| KPI   | Definition / rationale                                                                                                                                                                                                                                                                                                                                                            | Considerations                                                                                                                                                                                                         |
|-------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| MV    | Number of Maintenance Visits Number of Visits to the FLS by either the supplier or an authorised third party to maintain and service the system. This is to be documented and reported by the supplier and confirmed by an independent third party.                                                                                                                               | See pre-requisite (c) given in Section 0 for further discussion. Although listed as a pre-requisite for Stage 3 maturity, it is considered good practice to follow the approach outlined regardless of maturity stage. |
| UO    | Number of Unscheduled Outages Number Unscheduled Outages of the FLS in addition to scheduled service outages. Each outage needs to be documented regarding possible cause of outage, exact time / duration and action performed to overcome the unscheduled outage. This is to be reported by the supplier and independently confirmed and checked by an independent third party. | See pre-requisite (c) given in Section 0 for further discussion. Although listed as a pre-requisite for Stage 3 maturity, it is considered good practice to follow the approach outlined regardless of maturity stage. |
| CU    | Uptime of Communication System To be documented and reported by the supplier and independently checked/confirmed by an independent third party.                                                                                                                                                                                                                                   | See IEC 61400-50-4 for guidance on reporting.                                                                                                                                                                          |

In the above tables, during periods of maintenance, the system is deemed unavailable.

Preconditions for accuracy assessment

All comparisons and regression analysis are to be based on ten-minute average values returned from the sensors on the trusted reference measurement system.

The data from both the FLS and the trusted reference measurement system are to be filtered for external parameters such as:

- · Wind flow distorting effects from the ground / terrain (in the case of an onshore / coastal reference system) or from platform structures potentially influencing the undisturbed wind flow up to a certain height at the trusted reference measurement system.
- · Wind direction in order to avoid non-valid wind speed measures from sectors where either the trusted reference measurement system or the floating lidar itself is influenced by mast wake effects. Final valid sectors are to be defined by taking into account:
- -Boom directions for the side mounted cup anemometry at the reference mast, where used;
- -Any lightning protection components that may wake effect top mounted cups on the mast, where used;
- -Test site relevant filtering rules due to wake affected wind sectors; and
- -Each floating lidar position relative to the mast, where used.
- · Wind speed: application of clipping below 2 m/s. The rational for such low wind speed cutoff are that remote sensing techniques are known to suffer from possible weak signals in low wind speed conditions.
- It should also be noted that wind speeds below 4m/s is outwith the normal cup anemometer calibration range. Therefore, such wind speeds should be treated with caution when examining the performance relationship between the test FLS and the reference.
- · Air temperature taken from on-board measurements in order to avoid unpredictable conditions such as icing of cups that could violate the representativeness of the reference measurements. Hence the data should be clipped for air temperature with T &lt; 0.5°C.

Data coverage requirements for accuracy assessment

The data coverage requirements set out below prescribe the minimum required number of valid data points after the final filtering for allowable conditions required for data quality assessment, i.e. after filtering for wake affected wind direction sectors, ground or structure effected height levels, low wind speeds and low temperatures. By defining such data coverage requirements, it shall be assured that results from the performance assessment are statistically relevant.

The requirements on data coverage are based on ten-minute average values as returned from the FLS.

The following data coverage definitions are prescribed as follows:

- 1. Minimum number of 40 data points required in each 1 m/s bin wide reference wind speed bin centred between 2.5 m/s and 11.5 m/s, i.e. covering a range between 2 and 12 m/s.
- 2. Minimum number of 40 data points required in each 2 m/s bin wide reference wind speed bin centred on 13 m/s and 15 m/s, i.e. covering a range 12 m/s and 16 m/s.

- 3. Minimum number of 40 data points in each 2 m/s bin wide reference wind speed bin centred on 17 m/s and above, i.e. covering a range above 16 m/s only if such number of data is available. This is not mandatory.

Those data coverage requirements are regarded as achievable for the planned six months deployment period but also for considerably shorter verification tests.

It is accepted that at certain test sites filling all the bins at lower (or higher) wind speeds can be challenging, without necessarily there being a deleterious impact on the accuracy assessment. Subject to review and approval of a suitably qualified and experienced independent third party, these data coverage requirements can be waived if the lidar (lidars if using a fixed lidar reference) itself has been verified at the missing wind speed bins, and if the data which has been obtained can be demonstrated to have sufficient coverage to assure that the overall accuracy requirements are met. It is noted that the impact of any unfilled bins will have a bearing on measurement uncertainty estimation.

Accuracy assessment

The KPIs and Acceptance Criteria relating to accuracy are defined in the following table. To assess the accuracy a statistical linear regression approach has been selected which is based on:

- 1. A two-variant regression y = mx+b (with m slope and b offset) to be applied to wind speed, wind direction, and TI data comparisons between FLS and reference measurement system (for the wind direction's the circular nature of the data set should be accounted for prior to undertaking the regression analysis, and;
- 2. A single variant regression, with the regression analysis constrained to pass through origin (y=mx+b; b = 0) to be applied to wind speed, TI and wind shear data comparisons between floating instrument and reference.

In addition, Acceptance Criteria is presented in the form of ' minimum criteria ' where allowable tolerances have been imposed on slope and offset values as well as on correlation coefficients returned from each reference height for KPIs related to the primary parameters of interest, wind speed and wind direction.

| KPI     | Definition / rationale                                                                                                                                                                                                                                                                                                                                        | Acceptance Criteria Minimum requirement   |
|---------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------|
| X mws   | Mean Wind Speed - slope Slope returned from single variant regression with the regression analysis constrained to pass through the origin. Slope for unconstrained 2-parameter linear regression. A tolerance is imposed on the slope value. Analysis shall be applied to wind speed ranges: a) 4 to 16 m/s. b) All above 2 m/s. given achieved data coverage | 0.98 - 1.02                               |
| R 2 mws | Mean Wind Speed - coefficient of determination Correlation coefficient returned from single variant and multi-regression A tolerance is imposed on the correlation coefficient value. Analysis shall be applied to wind speed ranges: a) 4 to 16 m/s. b) All above 2 m/s. given achieved data coverage requirements.                                          | > 0.98                                    |
| OFF mws | Mean Wind Speed - offset In terms of the calculated offset when undertaking a two-parameter linear regression analysis.                                                                                                                                                                                                                                       | +/- 0.2 m/s                               |

| KPI     | Definition / rationale                                                                                                                                                                                                                          | Acceptance Criteria Minimum requirement   |
|---------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------|
| M mwd   | Mean Wind Direction - slope Slope returned from a two-variant regression. A tolerance is imposed on the slope value. Analysis shall be applied to: a) All wind directions. b) All wind speeds above 2 m/s. regardless of coverage requirements. | 0.97 - 1.03                               |
| OFF mwd | Mean Wind Direction - offset In terms of mean difference between FLS and reference (between 0° and 360°). (same as for M mwd ).                                                                                                                 | < 5°                                      |
| R 2 mwd | Mean Wind Direction - coefficient of determination (same as for M mwd ).                                                                                                                                                                        | > 0.97                                    |

Turbulence intensity error metrics

Turbulence  intensity  error  metrics  are  presented  in  this  section.  No  acceptance  criteria  are presented. It is recommended that a subject matter expert that aims to utilise the TI dataset examine the TI type and unit error metrics in order to understand and account of the error in any subsequent analysis.

It  is  noted  that  due  to  the  previously  noted  limitations  of  lidars  to  accurately  measure  TI,  a comparison of TI measurement against conventional anemometry is recommended until there is sufficient understanding in the industry on this topic.

| KPI    | Definition / rationale                                                                                                                                                                                                                                                                                                                                                                                                                       |
|--------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| X TI   | Turbulence Intensity - slope Slope returned from single variant (constrained C TI =0) and multi-variant (C TI unconstrained) linear regression.                                                                                                                                                                                                                                                                                              |
| C TI   | Turbulence Intensity - intercept Linear correlation intercept value (only for C TI unconstrained).                                                                                                                                                                                                                                                                                                                                           |
| R 2 TI | Turbulence Intensity - correlation coefficient Correlation coefficient returned from single (constrained C TI =0) and multi- variant (C TI unconstrained) variant linear regression with the regression analysis constrained to pass through the origin.                                                                                                                                                                                     |
| TI MBE | Mean Bias Error The mean of the difference between the recorded TI FLS and TI REF shall be evaluated for both all-data and wind speed binned (0.5m/s bin widths) data. For all data and for each wind speed bin, calculate the Mean Bias Error as follows: 𝑇𝐼 𝑀𝐵𝐸 = 1 𝑛 ∑𝑇𝐼 𝐹𝐿𝑆 𝑖 -𝑇𝐼 𝑅𝐸𝐹 𝑖 𝑛 𝑖=1 the mean of all TI differences, used to assess the accuracy of the measurement. Mean bias error is expressed as an absolute % error in TI. |

| KPI      | Definition / rationale                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| TI RMSE  | Root-Mean-Square-Error The root of the mean of the square of the difference between the recorded TI FLS and TI REF shall be evaluated for both all-data and wind speed binned (0.5m/s bin widths) data. For all data and for each wind speed bin calculate the Root Means Square Error as follows: 𝑇𝐼 𝑅𝑀𝑆𝐸 = √ 1 𝑛 ∑(𝑇𝐼 𝐹𝐿𝑆 𝑖 -𝑇𝐼 𝑅𝐸𝐹 𝑖 ) 2 𝑛 𝑖=1 the square root of the mean squared TI FLS - TI REF differences, assessing the precision (error spread) of the TI measurements. The Root Mean Square Error is an absolute % error in the TI measurement. |
| TI RMBE  | Relative Mean Bias Error The mean of the difference between the recorded TI FLS and TI REF shall be evaluated for wind speed binned (0.5m/s bin widths) data and expressed as a % value relative to the Reference TI. For each wind speed bin calculate the Relative Mean Bias Error as follows: 𝑇𝐼 𝑅𝑀𝐵𝐸 = 100 × 1 𝑛 ∑(𝑇𝐼 𝐹𝐿𝑆 𝑖 -𝑇𝐼 𝑅𝐸𝐹 𝑖 )/𝑇𝐼 𝑅𝐸𝐹 𝑖 𝑛 𝑖=1 The calculated mean difference of the TI values measured by the FLS and the reference, relative to the TI REF value. Relative Mean Bias Error is expressed as a % relative to the reference.    |
| TI RMSRE | Root Mean Squared Relative Error The root of the mean of the square of the difference between FLS TI and TI REF values. It is expressed as a % value which is relative to the TI REF value. For each wind speed bin calculate the Root Mean Square of the Relative Error as follows: 𝑇𝐼 𝑅𝑀𝑆𝑅𝐸 = 100 ×√ 1 𝑛 ∑((𝑇𝐼 𝐹𝐿𝑆 𝑖 -𝑇𝐼 𝑅𝐸𝐹 𝑖 )/𝑇𝐼 𝑅𝐸𝐹 𝑖 ) 2 𝑛 𝑖=1                                                                                                                                                                                                      |

| KPI      | Definition / rationale                                                                                                                                                                  |
|----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| TI REP-D | Representative TI Error This is a bin wise analysis when the Representative TI is: 𝑇𝐼 𝑅𝐸𝑃 𝑖 [%] = 𝑇𝐼 𝐴𝑉𝐺 𝑖 +1.28.𝑇𝐼 𝑠𝑡𝑑 𝑖 Then for each bin 𝑇𝐼 𝑅𝐸𝑃-𝐷 𝑖 [%] = 𝑇𝐼 𝑅𝐸𝑃 𝐹𝐿𝑆,𝑖 -𝑇𝐼 𝑅𝐸𝑃 𝑅𝐸𝐹,𝑖 |

The correlation analysis is consistent with previous recommendations for TI evaluation provided in the OWA roadmap (version 2.0) (i.e., r-squared from single variant linear regression), in addition to recommended TI error metrics presented in the CFARS literature 6   IEC-TS-61400-50-4 7 and the DNV recommended practice for lidar TI 8  .

## Trusted reference

A trusted reference for wind speed measurement is defined in Clause 6.4.2 of IEC TS 61400-50-4.

For the testing and evaluation of FLS TI data a trusted reference is further defined as:

- 1. A fixed offshore met mast that conforms to IEC61400-50-1 equipped with Class I, wind tunnel calibrated, cup anemometers.
- 2. A fixed offshore lidar where the lidar TI output has been calibrated/corrected against a fixed met mast.

An ideal setup should be thought of as a reference location where both a fixed reference mast and fixed vertical profiling lidar is available.

Please note by calibrated/corrected against a met mast in point 2, we mean that the output has been corrected using some mathematical relationship which is robust and has been verified by an independent third party. We recognise that the correction methodology for vertical profiling lidars for accurate TI datasets is not well established and that further work is required within the wind energy community to establish a  robust process such that a vertical profiling lidar can be thought of as a reference for TI.

An uncorrected fixed vertical profiling lidar is not suitable as a trusted reference but may become so once it in turn is evaluated against a fixed reference mast and a suitable TI correction process is applied.

## Other parameters

Other directly measured parameters or derived parameters may be of interest in a measurement campaign as is required by the intended application of the data acquired in the measurement campaign.

6 CFARS 2011 : An open-source approach to evaluate the performance of remote sensing device (RSD) turbulence intensity measurement &amp; accelerate industry adoption of RSDs for Turbine Suitability Assessment. (https://cfars.github.io/)

7 IEC 61400-50-4: Wind Energy Generation Systems Part 50-4: Use of floating lidar systems for wind measurements

8 DNV : DNV-RP-0661 Lidar measured turbulence intensity for wind turbines (https://www.dnv.com/energy/standards-guidelines/dnv-rp0661-lidar-measured-turbulence-intensity-for-wind-turbines/)

Wind  shear  is  an  important  parameter  and  is  presented  here.  No  acceptance  criteria  are presented.

| KPI   | Definition / rationale                                                                                                                                                                                                                                                                                                                                     |
|-------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| A     | Wind Speed Shear - Shear Exp onent Alpha related to Hellman's power law. a) Alpha to be calculated using reference heights that are representative of turbine rotor tip bottom and top heights, where possible. If limited by the measurement heights available at the reference source, then ensure the height interval assessed is as large as possible. |

Maturity stages: overview of pre-requisites and trial durations

The pre-requisites for attaining the respective stages of maturity are summarised in the table below. Note that this table does not indicate recommendations  for subsequent pre-deployment verifications  for  an  FLS  unit  in  the  context  of  a  WRA.  This  topic  is  more  appropriate  for,  and  is covered in, IEC TS 61400-50-4 . To support the reader's understanding of this and the implication of the application of the recommended practices on pre-deployment verifications for FLS units which have reached Stage 3 maturity.

The pre-requisites outlined in the table below are significantly more demanding for Stage 3 than for Stage 2. However, it is pointed out that deployments of Stage 2 devices in  WRAs will entail predeployment  verifications,  and  if  this  continues  successfully  for  a  number  of  units  then  the requirements for Stage 3 will, in the main, mostly be accumulated as a matter of course.

Stage 2+ and Stage 3+ requirements are also presented.

| Maturity level   | FLS Type Verification (1 long trial)                                                                                                 | FLS Unit Verification (3 long and 3 short trials)   | FLS offshore classification (3 long trials)   | Early commercial project deployments   |
|------------------|--------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------|-----------------------------------------------|----------------------------------------|
| Stage 1          | Not required.                                                                                                                        | Not required.                                       | Not required.                                 | Not required.                          |
| Stage 2          | Number: At least one. Duration: At least six months. Continuous single campaign. Availability KPIs:  Meet AC.  Data accuracy KPIs. | Not required.                                       | Not required.                                 | Not required.                          |

| Stage 2+   | Number: At least one.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | Not required.   | Not required.   | Not required.   |
|------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|-----------------|-----------------|
|            | Duration: At least six months. Continuous single campaign. Availability KPIs:  Meet AC.  Data Accuracy KPIs. All tests will be against an assessed trusted reference suitable for TI data (TI REF ). Past trials may be used if and only if: 1. The trusted reference is assessed as being suitable by a third party. 2. That if a new motion correction process is presented in additional to the original qualifying datasets. 3. Wind data is acquired in line with the original stage maturity evaluation. 4. If there is no change to the mechanical mounting of the FLS in line with the original stage maturity evaluation. If these conditions are not met, additional trials are required to evaluate the TI measurement capability of the FLS (TI FLS ). This does NOT affect the FLS current maturity status. |                 |                 |                 |

| Maturity level   | FLS Type Verification (1 long trial)                                                                                                            | FLS Unit Verification (3 long and 3 short trials)                                                                                                                                                          | FLS offshore classification (3 long trials)                                                                                                                                                                                                                                                                         | Early commercial project deployments                                                                                   |
|------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------|
| Stage 3          | Stage 2 Type Verification completed. May count as one of three long trials if KPIs meet:  Stage 3 AC for availability.  AC for data accuracy. | Number: Six (minimum three short and three long). Duration: At least three months for long trials. Continuous single campaign. Availability KPIs:  Meet Stage 3 AC.  Data accuracy KPIs.  Meet Stage 2. | Number: At least three. Duration: At least three months (typically). Two individual units are trialled at the same test site. One unit trialled at two different test sites. Continuous single campaign. May count towards long trials if KPIs meet:  Stage 3 AC for availability.  Stage 2 AC for data accuracy. | Number: At least five. Duration: At least 12 months. Continuous single campaign. Availability KPIs:  Meet Stage 3 AC. |

| Maturity level   | FLS Type Verification (1 long trial)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | FLS Unit Verification (3 long and 3 short trials)                            | FLS offshore classification (3 long trials)                                  | Early commercial project deployments   |
|------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------|------------------------------------------------------------------------------|----------------------------------------|
| Stage 3+         | Stage 2+ Type Verification completed. May count as one of three long trials if KPIs meet: 1. Stage 3 AC for availability. 2. AC for data accuracy. Past trials may be used if and only if: 1. The trusted reference is assessed as being suitable by a third party. 2. That if a new motion correction process is presented in additional to the original qualifying datasets. 3. If there is no change to the mechanical mounting of the FLS lidar in line with the original stage maturity evaluation. If these conditions are not met, additional trials are required to evaluate the TI measurement capability of the FLS. This does NOT affect the FLS current maturity status. | As above. Trial should be assessed against a trusted reference (Appendix 1). | As above. Trial should be assessed against a trusted reference (Appendix 1). | As above.                              |

Note 1:  Assumes trial is undertaken against a trusted reference source as defined in this document.

Note 2: It is possible for an FLS to hold two classifications. An example would be Stage 3 for wind speed and Stage 2+ for wind speed and TI .

## carbontrust.com

## +44 (0) 20 7170 7000

Whilst  reasonable  steps  have  been  taken  to  ensure  that  the  information  contained  within  this publication is correct, the authors, the Carbon Trust, its agents, contractors and subcontractors give no warranty  and  make  no  representation  as  to  its  accuracy  and  accept  no  liability  for  any  errors  or omissions. Any trademarks, service marks or logos used in this publication, and copyright in it, are the property of the Carbon Trust. Nothing in this publication shall be construed as granting any licence or right  to  use  or  reproduce  any  of  the  trademarks,  service  marks,  logos,  copyright  or  any  proprietary information in any way without the Carbon Trust's prior written permission. The Carbon Trust enforces infringements of its intellectual property rights to the full extent permitted by law.

The  Carbon  Trust  is  a  company  limited  by  guarantee  and  registered  in  England  and  Wales  under Company number 4190230 with its Registered Office at: Level 5, Arbor, 255 Blackfriars Road, London SE1 9AX.

© The Carbon Trust 2025. All rights reserved.

Published in the UK: 2025