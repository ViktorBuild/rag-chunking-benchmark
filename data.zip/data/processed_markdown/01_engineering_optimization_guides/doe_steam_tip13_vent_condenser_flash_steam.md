---
document_id: doe_steam_tip_13
title: "Steam Tip Sheet #13: Use Vent Condensers to Recover Flash Steam"
category_id: 1
category_name: "Engineering & Optimization Guides"
source_organization: "US DOE / AMO"
year: 2006
original_file: "doe_steam_tip13_vent_condenser_flash_steam.pdf"
tables_detected: 6
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

A

Energy Tips: STEAM

## Use a Vent Condenser to Recover Flash Steam Energy

When the pressure of saturated condensate is reduced, a portion of the liquid 'flashes' to low-pressure steam. Depending on the pressures involved, the flash steam contains approximately 10% to 40% of the energy content of the original condensate. In most cases, including condensate receivers and deaerators, the flashing steam is vented and its energy content lost. However, a heat exchanger can be placed in the vent to recover this energy. The following table indicates the energy content of flash steam at atmospheric pressure.

Energy Recovery Potential of a Vent Condenser

| Pipe Diameter (inches)   | Energy Content, MMBtu/year* Steam Velocity, feet/min   | Energy Content, MMBtu/year* Steam Velocity, feet/min   | Energy Content, MMBtu/year* Steam Velocity, feet/min   | Energy Content, MMBtu/year* Steam Velocity, feet/min   | Energy Content, MMBtu/year* Steam Velocity, feet/min   |
|--------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|
| Pipe Diameter (inches)   | 200                                                    | 300                                                    | 400                                                    | 500                                                    | 600                                                    |
| 2                        | 90                                                     | 140                                                    | 185                                                    | 230                                                    | 280                                                    |
| 4                        | 370                                                    | 555                                                    | 740                                                    | 925                                                    | 1,110                                                  |
| 6                        | 835                                                    | 1,250                                                  | 1,665                                                  | 2,085                                                  | 2,500                                                  |
| 10                       | 2,315                                                  | 3,470                                                  | 4,630                                                  | 5,875                                                  | 6,945                                                  |

*Assumes continuous operation, 70°F makeup water, and condensed steam at 100°F.

## Example

Consider a vent pipe with the following conditions:

Velocity of flash steam:

300 feet per minute

Diameter of vent pipe:

4 inches

Hours of operation:

8,000 hours per year (hr/yr)

Boiler efficiency:

80%

Cost of fuel:

$8.00 per million Btu ($8.00/MMBtu)

A vent condenser could condense the flashed steam, transfer its thermal energy to incoming makeup water, and then return it to the boiler. Energy is recovered in two forms: hotter makeup water and clean, distilled condensate ready for productive use in your operation.

Referring to the table above, the potential energy recovered from the flashed steam is 555 MMBtu, based on 8,760 hours of annual operation. Correct this value for actual operating hours and boiler efficiency:

Annual Energy Recovered =

555 MMBtu/yr x (8,000 hr/yr / 8,760 hr/yr)

=

507 MMBtu

Annual Fuel Cost Savings =

(507 MMBtu/yr x $8.00/MMBtu) / 0.80 $5,070**

=

**Note that the annual fuel savings are per vent. Often, there are several such vents in a steam facility, and the total savings can be a significantly larger number. The additional heat exchanger cost still needs to be considered, but available literature shows a quick payback for the measure.

Steam Tip Sheet #13

## Suggested Actions

- ■ ■ Inspect vent pipes of receiver tanks and deaerators for excessive flash steam plumes.
- ■ ■ Reexamine deaerator steam requirements.
- ■ ■ Eliminate remaining flash steam energy loss with a vent condenser.
- ■ ■ Consult manufacturers for materials specifications, as well as size and cost recommendations for the vent condenser.

## Distilled Water Recovery

A useful rule of thumb is that every 500 lb/hr of recovered flash steam provides 1 gallon per minute of distilled water.

## Materials Considerations

Depending on the specific application, the vent condenser materials can be either all stainless or mild steel shell with copper tubes. For deaerator vent condensing, a stainless steel heat exchanger is recommended to avoid corrosion due to the high concentrations of gases. Mild steel can be used for receiver tank vent condensing.

Adapted from an Energy TIPS fact sheet that was originally published by the Industrial Energy Extension Service of Georgia Tech.

## Resources

U.S. Department of EnergyDOE's software, the Steam System Assessment Tool and Steam System Scoping Tool , can help you evaluate and identify steam system improvements. In addition, refer to Improving Steam System Performance: A Sourcebook for Industry for more information on steam system efficiency opportunities.

Visit the Advanced Manufacturing Office website at manufacturing. energy.gov to access these and many other industrial efficiency resources and information on training.

<!-- image -->

Advanced Manufacturing Office Energy Efficiency and Renewable Energy U.S. Department of Energy Washington, DC 20585-0121 manufacturing.energy.gov

The Advanced Manufacturing Office (AMO) works with diverse partners to develop and deploy technologies and best practices that will help U.S. manufacturers continually improve their energy performance and succeed in global markets. AMO's Better Plants program works with U.S. corporations through a CEO-endorsed pledge to improve energy efficiency. AMO's tools, training, resources, and recognition programs can help build energy management capacity within the industrial sector and supply chains. Use these resources to comply with requirements of the ISO 50001 standard and the Superior Energy Performance program.

With our partners, AMO leverages additional federal, state, utility, and local resources to help manufacturers save energy, reduce climate and environmental impacts, enhance workforce development, and improve national energy security and competitiveness throughout the supply chain.

DOE/GO-102012-3416  •  January 2012